"""
cgm_namespaces.py - the namespaces of the CGM XML that the pipeline reads directly (L7 of the NCP 2.2 legacy form).

The cim prefix of an EQ file is CGMES 3.0 (cim.ucaiug.io or the CIM100 URI) or CGMES 2.4.15 (the cim16 URI). The EIC of a
ControlArea is an attribute of the entsoe extension, in the 3.0 form (CIM100-European) or the 2.4.15 form (SchemaExtension).
"""

CIM_NAMESPACES = (
    "https://cim.ucaiug.io/ns#",
    "http://iec.ch/TC57/CIM100#",
    "http://iec.ch/TC57/2013/CIM-schema-cim16#",
)
ENTSOE_NAMESPACES = (
    "http://iec.ch/TC57/CIM100-European#",
    "http://entsoe.eu/CIM/SchemaExtension/3/1#",
)
EIC_PROPERTY = "IdentifiedObject.energyIdentCodeEic"
