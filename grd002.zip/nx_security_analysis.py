"""nx_security_analysis.py — N-X branch currents (one pypowsybl security analysis for all
must-study contingencies) and the TATL per secured branch.

The security analysis applies each contingency to an internal working copy: the live
network's connectivity is unchanged afterwards. _get_must_study_contingencies and
_register_contingencies are also used by nx_sensitivity.
"""

import csv
import logging
import math
import re
from pathlib import Path
from typing import Optional

from data_model import AEType, AssessedElement, Contingency, select_by_side
from milp.milp_builder import _get_monitored_branch_sides
from pre_milp import cgmes_loader, log_summary
from pre_milp.cra_preprocessing import TATL_FALLBACK_DURATION_S_DEFAULT
from pre_milp.lf_parameters import build_security_analysis_parameters
from text_encoding import TEXT_ENCODING

log = logging.getLogger(__name__)


def _get_must_study_contingencies(
    co_flat_list: list[Contingency], timestamp: str,
) -> list[Contingency]:
    """Contingencies with must_study[timestamp] True ({TSO}_CO.xml normalMustStudy), sorted by
    mRID (stable matrix_id naming and CSV row order)."""
    return sorted(
        (c for c in co_flat_list if c.must_study.get(timestamp, False)),
        key=lambda c: c.mrid,
    )


def _register_contingencies(container, contingencies: list[Contingency]) -> None:
    """Register each Contingency on a pypowsybl ContingencyContainer (security or sensitivity
    analysis): one equipment mRID -> single-element contingency, several (e.g. a double-circuit
    tower) -> add_multiple_elements_contingency."""
    for contingency in contingencies:
        equipment_mrids = list(contingency.equipment_mrids)
        if len(equipment_mrids) == 1:
            container.add_single_element_contingency(equipment_mrids[0], contingency.mrid)
        else:
            container.add_multiple_elements_contingency(equipment_mrids, contingency.mrid)


def _contingency_result_is_usable(
    contingency: Contingency,
    status_name: str,
    branch_ids_present: set[str],
    expected_branch_ids: set[str],
    baseline_present: Optional[set[str]] = None,
) -> tuple[bool, Optional[str]]:
    """(usable, reason) for one contingency's result. Skipped when:
    1. the status is neither CONVERGED nor NO_IMPACT (NO_IMPACT is a valid outcome), or
    2. a monitored branch is missing from the results: pypowsybl reports no island count, so a
       missing branch is taken as a likely network split. The contingency's own tripped
       equipment is excluded from this check (it has no flow by definition), and so is a branch
       that the N-0 result (baseline_present) does not have either: that is no split.
    """
    if status_name not in ("CONVERGED", "NO_IMPACT"):
        return False, f"non-convergent (status={status_name})"

    if baseline_present is not None:
        expected_branch_ids = expected_branch_ids & baseline_present
    own_equipment_mrids = set(contingency.equipment_mrids)
    missing_branch_ids = expected_branch_ids - branch_ids_present - own_equipment_mrids
    if missing_branch_ids:
        return False, (
            f"likely network split — {len(missing_branch_ids)} monitored branch(es) "
            f"missing from results: {sorted(missing_branch_ids)}"
        )

    return True, None


# ---------------------------------------------------------------------------
# N-X branch currents (lf_nx)
# ---------------------------------------------------------------------------


def log_skipped_contingencies(skipped: dict[str, str]) -> None:
    """One warning for the skipped must-study contingencies: the count, the first 5 ids and how many per reason
    (the reason up to its first "(" or dash); every contingency with its full reason at debug level."""
    if not skipped:
        return
    reasons: dict[str, int] = {}
    for reason in skipped.values():
        kind = re.split(r" \(| — ", reason, maxsplit=1)[0]
        reasons[kind] = reasons.get(kind, 0) + 1
    log_summary.warn_ids(
        log, "compute_lf_nx: %d must-study contingency(ies) skipped (" + ", ".join(f"{n} {kind}" for kind, n in reasons.items()) + ")",
        sorted(skipped),
    )
    for mrid in sorted(skipped):
        log.debug("compute_lf_nx: contingency %s skipped — %s", mrid, skipped[mrid])


def _index_branch_results(
    branch_results, value_columns: tuple = ("i1", "i2"),
) -> tuple[dict[str, set], dict[tuple[str, str], tuple]]:
    """One pass over the security analysis branch_results (index contingency_id,
    operator_strategy_id, branch_id): ({contingency: branch ids present},
    {(contingency, branch): raw (i1, i2) of its FIRST row}), as a per-contingency selection
    followed by .xs(branch).iloc[0] would give. Values are converted where they are read.
    value_columns ("p1", "p2") for the DC analysis: the raw values are then MW."""
    present: dict[str, set] = {}
    first_currents: dict[tuple[str, str], tuple] = {}
    contingency_ids = branch_results.index.get_level_values("contingency_id")
    branch_ids = branch_results.index.get_level_values("branch_id")
    i1_values = branch_results[value_columns[0]].to_numpy()
    i2_values = branch_results[value_columns[1]].to_numpy()
    for contingency_id, branch_id, i1, i2 in zip(contingency_ids, branch_ids, i1_values, i2_values):
        present.setdefault(contingency_id, set()).add(branch_id)
        first_currents.setdefault((contingency_id, branch_id), (i1, i2))
    return present, first_currents


def compute_lf_nx(
    network,
    co_flat_list: list[Contingency],
    ae_flat_list: list[AssessedElement],
    timestamp: str,
    lf_initial: Optional[dict[str, dict[int, float]]] = None,
    output_path: Optional[Path] = None,
    use_reactive_limits: bool = False,
    extra_lf_params: dict = None,
    dc_converter=None,
) -> tuple[dict[str, dict[str, dict[int, float]]], dict[str, str]]:
    """N-X branch currents of every must-study contingency from one security analysis run.
    Returns (lf_nx, skipped): lf_nx = {contingency: {branch: {1: A, 2: A}}} (both sides, the
    side is selected where used), skipped = {contingency: reason} (non-convergent or likely
    split). lf_initial only fills the ae_type/limit_ka/loading_pct/tso CSV columns.
    use_reactive_limits / extra_lf_params: the pipeline's load-flow settings (lf_parameters).
    dc_converter (calculation_mode dc): DC security analysis; the currents are computed from its
    p1/p2 by dc_converter (dc_conversion), not taken from its i1/i2. None = the AC analysis."""
    must_study_contingencies = _get_must_study_contingencies(co_flat_list, timestamp)
    if not must_study_contingencies:
        raise ValueError(f"No must-study contingencies found for timestamp {timestamp}")

    branch_sides = _get_monitored_branch_sides(ae_flat_list)
    if not branch_sides:
        raise ValueError("No monitored branch IDs found in AEFlatList")

    try:
        import pypowsybl as pp
    except Exception as exc:
        raise ImportError("pypowsybl is required to compute N-X load flows") from exc

    security_analysis = pp.security.create_analysis()
    _register_contingencies(security_analysis, must_study_contingencies)
    security_analysis.add_monitored_elements(branch_ids=sorted(branch_sides.keys()))

    # same load-flow parameters as the initial load flow (lf_parameters)
    security_parameters = build_security_analysis_parameters(use_reactive_limits, extra_lf_params)
    if dc_converter is None:
        result = security_analysis.run_ac(network, parameters=security_parameters)
        present_by_contingency, first_currents = _index_branch_results(result.branch_results)
    else:
        result = security_analysis.run_dc(network, parameters=security_parameters)
        present_by_contingency, first_currents = _index_branch_results(result.branch_results, ("p1", "p2"))

    lf_nx: dict[str, dict[str, dict[int, float]]] = {}
    skipped_contingencies: dict[str, str] = {}
    expected_branch_ids = set(branch_sides.keys())
    # the N-0 result (contingency id "") tells which monitored branches have a result at all (an open branch has none)
    baseline_present = present_by_contingency.get("")
    if baseline_present:
        for branch_mrid in sorted(expected_branch_ids - baseline_present):
            log_summary.warn_once(
                log, ("nx-branch-not-in-n0", branch_mrid),
                "compute_lf_nx: monitored branch %s has no result in the N-0 analysis (not connected?) - "
                "excluded from the N-X monitoring", branch_mrid,
            )
        expected_branch_ids &= baseline_present
    else:
        baseline_present = None

    for contingency in must_study_contingencies:
        post_contingency_result = result.post_contingency_results.get(contingency.mrid)
        if post_contingency_result is None:
            skipped_contingencies[contingency.mrid] = "no post-contingency result returned"
            continue

        status_name = str(getattr(post_contingency_result.status, "name", post_contingency_result.status))

        branch_ids_present = present_by_contingency.get(contingency.mrid, set())

        is_usable, skip_reason = _contingency_result_is_usable(
            contingency, status_name, branch_ids_present, expected_branch_ids, baseline_present=baseline_present,
        )
        if not is_usable:
            skipped_contingencies[contingency.mrid] = skip_reason
            log.debug(
                "compute_lf_nx: contingency %s (%s) skipped — %s",
                contingency.mrid, contingency.name, skip_reason,
            )
            continue

        # A branch without a usable current is LEFT OUT of lf_nx (never given 0.0 A):
        # the N-X constraint of that (branch, contingency) pair is then not built.
        # The contingency's own tripped equipment has no flow by definition (debug
        # only); any other missing or NaN branch is reported once per contingency.
        own_equipment_mrids = set(contingency.equipment_mrids)
        per_branch_currents: dict[str, dict[int, float]] = {}
        tripped_branches: list[str] = []
        unusable_branches: list[str] = []
        for branch_mrid in sorted(expected_branch_ids):
            currents = first_currents.get((contingency.mrid, branch_mrid))
            if currents is None:
                (tripped_branches if branch_mrid in own_equipment_mrids else unusable_branches).append(branch_mrid)
                continue
            i1, i2 = float(currents[0]), float(currents[1])
            if dc_converter is not None:
                i1, i2 = dc_converter.current(branch_mrid, 1, i1), dc_converter.current(branch_mrid, 2, i2)
            if math.isnan(i1) or math.isnan(i2):
                unusable_branches.append(branch_mrid)
                continue
            per_branch_currents[branch_mrid] = {1: i1, 2: i2}
        if tripped_branches:
            log.debug(
                "compute_lf_nx: contingency %s: %d monitored branch(es) are its own tripped equipment "
                "- no current recorded: %s", contingency.mrid, len(tripped_branches), tripped_branches,
            )
        if unusable_branches:
            log.warning(
                "compute_lf_nx: contingency %s (%s): %d branch(es) without a usable current "
                "(missing or NaN) left out of lf_nx - their N-X pairs are skipped: %s",
                contingency.mrid, contingency.name, len(unusable_branches), unusable_branches,
            )

        lf_nx[contingency.mrid] = per_branch_currents

    log_skipped_contingencies(skipped_contingencies)

    if lf_initial is not None:
        branch_ae_types_log = {
            str(ae.branch_mrid): ae.ae_type for ae in ae_flat_list if ae.branch_mrid
        }
        secured_count = sum(1 for t in branch_ae_types_log.values() if t == AEType.SECURED)
        scanned_count = sum(1 for t in branch_ae_types_log.values() if t == AEType.SCANNED)
        log.info(
            "compute_lf_nx: %d/%d must-study contingencies usable (%d skipped) — "
            "monitored branches by ae_type: %d secured, %d scanned",
            len(lf_nx), len(must_study_contingencies), len(skipped_contingencies),
            secured_count, scanned_count,
        )
    else:
        log.info(
            "compute_lf_nx: %d/%d must-study contingencies usable (%d skipped)",
            len(lf_nx), len(must_study_contingencies), len(skipped_contingencies),
        )

    if output_path is not None:
        branch_ae_types = None
        limit_by_branch = None
        branch_tso = None
        branch_mrid_to_name = {}

        if lf_initial is not None:
            from milp.milp_builder import _get_monitored_branch_limits_and_ae_types
            from pre_milp import cgmes_loader

            limit_by_branch, branch_ae_types = _get_monitored_branch_limits_and_ae_types(
                ae_flat_list, timestamp, lf_initial,
            )
            branch_tso = {str(ae.branch_mrid): ae.tso for ae in ae_flat_list if ae.branch_mrid}
            branch_mrid_to_name = cgmes_loader.build_branch_mrid_to_name(network)

        write_lf_nx_csv(
            lf_nx, branch_sides, branch_mrid_to_name, must_study_contingencies,
            output_path, timestamp,
            branch_ae_types=branch_ae_types,
            limit_by_branch=limit_by_branch,
            branch_tso=branch_tso,
        )

    return lf_nx, skipped_contingencies


# ---------------------------------------------------------------------------
# TATL per secured branch
# ---------------------------------------------------------------------------


def compute_tatl_data(
    network,
    ae_flat_list: list[AssessedElement],
    timestamp: str,
    output_path: Optional[Path] = None,
    fallback_duration_seconds: int = TATL_FALLBACK_DURATION_S_DEFAULT,
) -> dict[str, dict]:
    """TATL per monitored SECURED branch on its AssessedElement.branch_side, from
    network.get_operational_limits(): {branch: {"tatl_limit_ampere", "tatl_duration_seconds",
    "side", "was_corrected"}}.
    - no TATL row: TATL = the branch's PATL at `timestamp` (kA -> A), duration
      fallback_duration_seconds (the duration the curative reaction times are compared with;
      such a branch gets no TATL constraint, TATL = PATL);
    - several TATLs on one side: no entry (warning; real data is not discarded);
    - TATL below PATL: raised to PATL (counted, one summary line);
    - neither TATL nor PATL: no entry (logged).
    Permanent limits have acceptable_duration -1 here (2147483647 in
    limit_violations), so `acceptable_duration > 0` selects the TATLs.
    """
    secured_branch_sides: dict[str, int] = {
        str(ae.branch_mrid): int(getattr(ae, "branch_side", 1))
        for ae in ae_flat_list
        if ae.ae_type == AEType.SECURED and ae.branch_mrid
    }
    if not secured_branch_sides:
        raise ValueError("No monitored SECURED branch IDs found in AEFlatList")

    # resolved PATL (kA) per branch at this timestamp: the source when the CGM has no TATL
    patl_ka_by_branch: dict[str, float] = {
        str(ae.branch_mrid): ae.patl_ka[timestamp]
        for ae in ae_flat_list
        if ae.ae_type == AEType.SECURED and ae.branch_mrid and timestamp in ae.patl_ka
    }

    # the limits of the branches (dangling lines on side 1, tie lines by their two dangling lines): build_branch_limits
    limits_df = cgmes_loader.build_branch_limits(network)

    limits_df_has_rows = limits_df is not None and not limits_df.empty
    if not limits_df_has_rows:
        log.info(
            "compute_tatl_data: network has no operational limits at all — "
            "every SECURED branch will fall back to its own PATL (or be "
            "absent, if PATL is also unresolved)",
        )

    side_number_to_name = {1: "ONE", 2: "TWO"}

    tatl_data: dict[str, dict] = {}
    tatl_corrected_count = 0
    own_patl_as_tatl: list[str] = []          # branches without a CGM TATL, logged as one summary
    no_tatl_no_patl: list[str] = []
    for branch_mrid, side in secured_branch_sides.items():
        side_name = side_number_to_name.get(side, "ONE")

        if limits_df_has_rows:
            branch_rows = limits_df[
                (limits_df["type"] == "CURRENT")
                & (limits_df["acceptable_duration"] > 0)
                & (limits_df["branch_id"] == branch_mrid)
                & (limits_df["side_number"] == side)
            ]
        else:
            branch_rows = None  # no operational limits data at all — same as "no rows for this branch"

        if branch_rows is None or branch_rows.empty:
            # no TATL row: TATL = the branch's own PATL
            fallback_patl_ka = patl_ka_by_branch.get(branch_mrid)
            if fallback_patl_ka is None:
                no_tatl_no_patl.append(branch_mrid)
                continue
            own_patl_as_tatl.append(branch_mrid)
            tatl_data[branch_mrid] = {
                "tatl_limit_ampere": fallback_patl_ka * 1000.0,
                "tatl_duration_seconds": int(fallback_duration_seconds),
                "side": side,
                "was_corrected": False,
            }
            continue

        if len(branch_rows) > 1:
            log.warning(
                "compute_tatl_data: branch %s side %s has %d TATL entries "
                "(exactly one expected) — skipped",
                branch_mrid, side_name, len(branch_rows),
            )
            continue

        row = branch_rows.iloc[0]
        tatl_limit_ampere = float(row["value"])

        # A TATL below the PATL is raised to the PATL (a temporary rating is never lower).
        # Counted and reported in one summary line (it can hit most branches of a dataset)
        # and marked per row in tatl_data.csv.
        fallback_patl_ka = patl_ka_by_branch.get(branch_mrid)
        was_corrected = False
        if fallback_patl_ka is not None and tatl_limit_ampere < fallback_patl_ka * 1000.0:
            tatl_limit_ampere = fallback_patl_ka * 1000.0
            was_corrected = True
            tatl_corrected_count += 1

        tatl_data[branch_mrid] = {
            "tatl_limit_ampere": tatl_limit_ampere,
            "tatl_duration_seconds": int(row["acceptable_duration"]),
            "side": side,
            "was_corrected": was_corrected,
        }

    if no_tatl_no_patl:
        log_summary.warn_ids(
            log, f"compute_tatl_data: %d branch(es) have no CGM TATL AND no resolvable PATL for timestamp {timestamp} — "
                 "no TATL constraint possible for these", no_tatl_no_patl)
    if own_patl_as_tatl:
        log_summary.log_ids(
            log, logging.INFO, f"compute_tatl_data: %d branch(es) have no CGM TATL — falling back to their own PATL as TATL, "
                               f"duration={int(fallback_duration_seconds)}s", own_patl_as_tatl)
    log.info(
        "compute_tatl_data: resolved TATL for %d/%d monitored SECURED branch(es)",
        len(tatl_data), len(secured_branch_sides),
    )
    if tatl_corrected_count:
        log.warning(
            "compute_tatl_data: %d of %d resolved TATL value(s) were LOWER than "
            "that branch's own PATL (physically backwards — TATL should never be "
            "less permissive than PATL) — corrected to TATL = PATL. See "
            "tatl_data.csv's own was_corrected column for exactly which branches.",
            tatl_corrected_count, len(tatl_data),
        )

    if output_path is not None:
        write_tatl_data_csv(tatl_data, {}, output_path)

    return tatl_data


# ---------------------------------------------------------------------------
# CSV export
# ---------------------------------------------------------------------------


def write_lf_nx_csv(
    lf_nx: dict[str, dict[str, dict[int, float]]],
    branch_sides: dict[str, int],
    branch_mrid_to_name: dict[str, str],
    must_study_contingencies: list[Contingency],
    output_path: Path,
    timestamp: str,
    branch_ae_types: Optional[dict[str, "AEType"]] = None,
    limit_by_branch: Optional[dict[str, float]] = None,
    branch_tso: Optional[dict[str, str]] = None,
) -> None:
    """lf_nx_initial.csv — one row per (contingency, branch), side-aware. limit_ka is the
    limit_by_branch value (PATL for secured, effective limit for scanned) and loading_pct is
    computed against it; tso/loading_pct/limit_ka/ae_type are blank when their map is None.
    `converged` is always TRUE: compute_lf_nx leaves unusable contingencies out of lf_nx.
    """
    branch_ae_types = branch_ae_types or {}
    limit_by_branch = limit_by_branch or {}
    branch_tso = branch_tso or {}

    output_path.parent.mkdir(parents=True, exist_ok=True)
    contingency_names = {c.mrid: c.name for c in must_study_contingencies}
    with open(output_path, "w", newline="", encoding=TEXT_ENCODING) as f:
        writer = csv.writer(f)
        writer.writerow([
            "timestamp", "contingency_mrid", "branch_mrid", "branch_name",
            "tso", "ae_type", "side", "i_ka", "loading_pct", "limit_ka", "converged",
        ])
        for contingency_mrid in sorted(lf_nx):
            per_branch_currents = lf_nx[contingency_mrid]
            for branch_mrid in sorted(per_branch_currents):
                side = branch_sides.get(branch_mrid, 1)
                current_ampere = select_by_side(per_branch_currents[branch_mrid], side, branch_mrid)
                i_ka = float(current_ampere) / 1000.0 if current_ampere is not None else ""
                branch_name = branch_mrid_to_name.get(branch_mrid, branch_mrid)

                tso = branch_tso.get(branch_mrid, "")
                ae_type = branch_ae_types.get(branch_mrid)
                ae_type_str = ae_type.value if ae_type is not None else ""

                limit_ampere = limit_by_branch.get(branch_mrid)
                limit_ka = limit_ampere / 1000.0 if limit_ampere else ""
                loading_pct = (
                    (float(current_ampere) / limit_ampere) * 100.0
                    if (current_ampere is not None and limit_ampere) else ""
                )

                writer.writerow([
                    timestamp, contingency_mrid, branch_mrid, branch_name,
                    tso, ae_type_str, side, i_ka, loading_pct, limit_ka, "TRUE",
                ])

    log.info("Written N-X initial load flow CSV: %s", output_path)


def write_tatl_data_csv(
    tatl_data: dict[str, dict],
    branch_mrid_to_name: dict[str, str],
    output_path: Path,
) -> None:
    """tatl_data.csv — [branch_mrid, branch_name, side, tatl_limit_ka, tatl_duration_seconds,
    was_corrected], one row per branch with a TATL. was_corrected: a CGM TATL below the PATL was
    raised to the PATL (False for a TATL set from the PATL because no TATL row exists)."""
    output_path.parent.mkdir(parents=True, exist_ok=True)
    with open(output_path, "w", newline="", encoding=TEXT_ENCODING) as f:
        writer = csv.writer(f)
        writer.writerow(["branch_mrid", "branch_name", "side", "tatl_limit_ka", "tatl_duration_seconds", "was_corrected"])
        for branch_mrid in sorted(tatl_data):
            entry = tatl_data[branch_mrid]
            branch_name = branch_mrid_to_name.get(branch_mrid, branch_mrid)
            writer.writerow([
                branch_mrid, branch_name, entry["side"],
                float(entry["tatl_limit_ampere"]) / 1000.0, entry["tatl_duration_seconds"],
                entry.get("was_corrected", False),
            ])

    log.info("Written TATL data CSV: %s", output_path)
