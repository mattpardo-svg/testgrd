"""
ncp_header.py - profile and creator of an NCP file, read from its header.

The header is the first md:FullModel or dcat:Dataset of the file; its fields are found by local name, whatever their
namespace URI (the legacy files end the dcterms and dc namespaces with "#"). The profile is its dcat:keyword (AE, CO, RA, SIS, SHS,
SSI, IAM, PS, ER; CD for the organisation file, OR for its object registry), else the profile name in a
dcterms:conformsTo URL (".../<Profile>/<version>" or ".../<Profile>-EU/<version>"). The creator is the last path
segment of the dcterms:creator URI, given as text or as rdf:resource, any base, hyphens kept (the EIC of the sending TSO;
creator_problem says why none was read). A file that is not XML or has no header gives None.
"""

from __future__ import annotations

import xml.etree.ElementTree as ET
from dataclasses import dataclass, field
from pathlib import Path
from typing import Optional

KEYWORD_PROFILES = ("AE", "CO", "RA", "SIS", "SHS", "SSI", "IAM", "PS", "ER")
_PROFILE_BY_NAME = {
    "AssessedElement": "AE",
    "Contingency": "CO",
    "RemedialAction": "RA",
    "StateInstructionSchedule": "SIS",
    "SteadyStateHypothesisSchedule": "SHS",
    "SteadyStateInstruction": "SSI",
    "ImpactAssessmentMatrix": "IAM",
    "PlannedSchedule": "PS",
    "EquipmentReliability": "ER",
    "ObjectRegistry": "OR",
}
_HEADER_TAGS = ("FullModel", "Dataset")
_RDF_RESOURCE = "{http://www.w3.org/1999/02/22-rdf-syntax-ns#}resource"


@dataclass(frozen=True)
class NcpHeader:
    profile: Optional[str]          # keyword of the profile, "CD", "OR", or None when the header names none
    creator: Optional[str]          # last path segment of dcterms:creator, None when missing or unreadable
    creator_problem: Optional[str] = field(default=None, compare=False)   # why creator is None (never the value)


def _creator_of(value: Optional[str]) -> tuple[Optional[str], Optional[str]]:
    """(EIC, None) from the URI in dcterms:creator (any base, hyphens kept), else (None, reason)."""
    if value is None:
        return None, "missing"
    value = value.strip()
    if not value:
        return None, "empty"
    if "://" not in value:
        return None, "not a URI"
    segment = value.rsplit("/", 1)[-1].strip()
    return (segment, None) if segment else (None, "empty segment")


def _profile_of_url(url: str) -> Optional[str]:
    parts = url.rstrip("#/").split("/")
    if len(parts) < 2:
        return None
    return _PROFILE_BY_NAME.get(parts[-2].removesuffix("-EU"))


def _profile(keywords: list[str], conforms_to: list[str]) -> Optional[str]:
    if "OR" in keywords:
        return "OR"
    for keyword in keywords:
        if keyword in KEYWORD_PROFILES:
            return keyword
    if "CD" in keywords:
        return "CD"
    for url in conforms_to:
        profile = _profile_of_url(url)
        if profile is not None:
            return profile
    return None


def read_header(path: Path) -> Optional[NcpHeader]:
    """The header of an NCP file (stops reading at the end of the header), None for a file without one."""
    keywords: list[str] = []
    conforms_to: list[str] = []
    creator_value: Optional[str] = None
    depth = 0
    in_header = False
    try:
        for event, element in ET.iterparse(str(path), events=("start", "end")):
            local = element.tag.rsplit("}", 1)[-1]
            if event == "start":
                depth += 1
                if depth == 2 and local in _HEADER_TAGS:
                    in_header = True
                continue
            depth -= 1
            if in_header and depth == 1:
                break
            if not in_header:
                if depth == 1:
                    return None           # the first object is not a header
                continue
            if local == "keyword" and (element.text or "").strip():
                keywords.append(element.text.strip())
            elif local == "conformsTo":
                conforms_to.append(element.get(_RDF_RESOURCE) or (element.text or "").strip())
            elif local == "creator" and creator_value is None:
                creator_value = element.get(_RDF_RESOURCE) or element.text or ""
    except (ET.ParseError, OSError, UnicodeDecodeError):
        return None
    if not in_header:
        return None
    creator, problem = _creator_of(creator_value)
    return NcpHeader(profile=_profile(keywords, conforms_to), creator=creator, creator_problem=problem)
