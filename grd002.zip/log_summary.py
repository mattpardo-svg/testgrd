"""
log_summary.py - short log lines for long lists of ids: the count and the first 5 ids at the given level, the full list at
debug level; and a warning that is given once per run.
"""

import logging

SHOWN_IDS = 5
_ONCE: set = set()


def first_ids(ids, shown: int = SHOWN_IDS) -> str:
    """"a, b, c, d, e and 7 more" for the first `shown` ids and the number of the others."""
    ids = [str(item) for item in ids]
    more = f" and {len(ids) - shown} more" if len(ids) > shown else ""
    return ", ".join(ids[:shown]) + more


def log_ids(log: logging.Logger, level: int, message: str, ids) -> None:
    """`message` (with a %d for the count) and the first ids at `level`; the full list at debug level."""
    ids = [str(item) for item in ids]
    text = message % len(ids) if "%d" in message else message
    log.log(level, "%s: %s", text, first_ids(ids))
    if len(ids) > SHOWN_IDS:
        log.debug("%s - all ids: %s", text, ", ".join(ids))


def warn_ids(log: logging.Logger, message: str, ids) -> None:
    log_ids(log, logging.WARNING, message, ids)


def warn_once(log: logging.Logger, key, message: str, *args) -> bool:
    """Log the warning the first time `key` is seen in a run; True when it was logged."""
    if key in _ONCE:
        return False
    _ONCE.add(key)
    log.warning(message, *args)
    return True


def reset_once() -> None:
    """Forget the warnings given so far (called at the start of a run)."""
    _ONCE.clear()
