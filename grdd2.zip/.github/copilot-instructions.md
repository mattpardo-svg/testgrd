# Instructions for contributors

This repo is a prototype of an iterative MILP security-constrained remedial action optimisation (RAO) on CGMES data (pypowsybl, Pyomo, HiGHS).

## Source of truth
1. Code and tests are the source of truth.
2. Then `docs/DECISIONS.md` and `docs/ASSUMPTIONS.md`: decisions that cannot be seen from the code. Read both before changing behaviour.
3. You may read `reference/spec/` (the functional specification and implemented requirement specs) to check a requirement; search it by CORNET or BUC number. Never edit anything in `reference/`. Never read or search the rest of `reference/`: it is background only, may be outdated, and conflicts with it are not your problem. Do not follow links into it.
4. If code and a document in `docs/` disagree, stop and ask. Do not guess which is right.

## Scope
- Change only code under `src/rao/` and the tests under `tests/` that test it, plus the files in `docs/` and the generators in `mock_data/` (generators and golden-run scripts only: nothing in `src/` imports `mock_data`, and the GUI never does).
- Never change the GUI (`src/rao_pages/`), `input/`, `output/` or the root config files, unless asked to. Never edit anything in `reference/`; you may read `reference/spec/` only.
- A new requirement spec is drafted in `docs/` while it is open. When it is implemented and accepted, the maintainer moves it to `reference/spec/`. Contributors do not move it.
- The GUI imports from `src/rao`. Do not rename or move any module, function, class or constant that `src/rao_pages/` imports. If a change in `src/rao` would break the GUI, stop and ask.

## How to work
- One small increment at a time. Write a failing test first, then the fix, then run the full suite.
- For a rule that matters, add a test. Tests test code only. Never write a test that reads markdown or any document.
- No behaviour change inside a refactor. The test count may drop only for tests of removed code or true duplicates.
- Do not add silent defaults. A missing or invalid input must halt, exclude with a warning, or fall back with a warning.
- Do not change results-affecting behaviour (model, objective, convergence, defaults) without asking. State the question and wait.
- Keep modules small and readable. Do not create new markdown files except those listed below.

## After every task
1. Add a short entry to `docs/CHANGELOG.md`: date, what changed (file, function), tests added, suite result, open items.
2. If you made or changed a decision, add or update it in `docs/DECISIONS.md` (ask first).
3. If you learned or confirmed an assumption about the data or the spec, update `docs/ASSUMPTIONS.md`.
4. If you rename or add an output file or a config key, update `docs/User_Guide.md` and `src/rao/config/rao_config.default.yaml`.
5. Every new, changed or deferred requirement gets a row in `docs/Spec_Coverage.md` with its CORNET or BUC reference, and every deviation from the specification is listed there.
Keep entries short: facts, no history.

## Commands (from the repo root)
- Tests: `python -m pytest tests -q` (about 9 min); the whole gate (suite in parallel, 52-run golden matrix against `mock_data/golden/baseline.zip`, fingerprints, link check of the docs) is `python mock_data/golden/run_gate.py OUTDIR TAG none`. Tests use only `tests/fixtures` (the ReliCapGrid case is built from `CGM_package.zip` and `NCP_sample_generic_2_4.zip`); none reads `input/`.
- Run: `python src/rao/run_pipeline.py` (see `docs/README.md`).
- Modules import each other flat (`from data_model import ...`); `tests/conftest.py` adds `src/rao` to `sys.path`. Do not convert to package imports unless asked. Shared test builders live in `tests/helpers.py` (fixtures stay in `tests/conftest.py`); a test file never imports another test file.

## Hard rules for this code
- Real data is never committed: it is placed by hand in `input/` (one `cgm*.zip`, one `ncp*.zip`) for a real run. `input/` currently holds the HVDC mock pair (`CGM_package_hvdc.zip`, `NCP_mock_hvdc.zip`); the previous pair is in `input_old/` and `tests/fixtures/`.
- Contingency propagation must stay off. Load-flow and sensitivity parameters come only from `pre_milp/lf_parameters.py`.
- `ACTIVATE_CRA_XNE_LINKAGE` stays hardcoded in `run_pipeline.py` on purpose.
- Every run deletes the registered output files from `output/`. Keep nothing there that matches a registered name.
- Comments and docstrings must not cite documents (no "see R3_NX_CRA.md"); say the rule in the comment itself.
- Comments describe the current code in 1 to 6 lines. History and decisions go to docs/DECISIONS.md. No personal or tool names anywhere.
- For the next steps (first run on the full input, parser check, performance) follow docs/Next_Steps.md.

## Tests and data

- Write every test against the Relicapgrid mock data in `tests/fixtures/`, or against small networks or XML built inside the test.
- Never use real data in a test. Never copy real values, names, mRIDs or file contents into `tests/`, fixtures, docs, logs or comments.
- If a real-data run shows a bug, rebuild the same case on the mock data, or as a small synthetic case, and write the test on that. The test must fail before the fix and pass after it.
- If the mock data cannot show the case (for example a different XML structure), build a minimal synthetic input with fake values in the test. Do not add real data to `tests/fixtures/`.
- Test names start with `test_rao_`. Tests check the code's behaviour, not the text of docs.