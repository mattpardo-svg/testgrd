> Original plan. Current status per row: see `Spec_Coverage.md` (section 3). Where this file and that one differ, `Spec_Coverage.md` is right.

# R2 — Redispatch PRA: Basic Constraints

**Goal:** Add preventive redispatch (RD) as the second degree of freedom alongside PSTs.
Introduces the RD sensitivity matrix, GLSK mapping, power balance constraint,
Pmax/Pmin limits, sensitivity threshold pruning, penalty/price costs, and
RA count and group volume limits.

> **Update after the loop redesign.** In every solve after the first, RD is
> **cumulative against the original network**: bid headroom is
> `availability − used` in the same direction and `used` in the opposite
> direction, the RA activation binary is linked to the absolute cumulative net
> volume (so a fully retracted RA no longer counts), and cost is priced on the
> cumulative volume (`MILP_Mathematical_Formulation.md` §7). The preventive RD
> result file is `results_preventive_rd.csv` (formerly `results_rd.csv`); curative
> RD is `results_curative_rd.csv`. The exported "activated" flag in the RA-count
> file is derived from `|net volume| > 1e-6 MW`, because the binary has no lower
> link and no penalty unless a count limit is configured. **Known gap:** bid
> activation cost (spec eq. 3.38) and generating-unit start-up cost (eq. 3.39,
> BUC14#102/#103) are not part of the objective.

**Prerequisite:** R1 complete — N-0 single-timestamp PST PRA MILP working. R2 operates
on a single timestamp — multi-timestamp generalisation is deferred to R4.

**Stack:** pypowsybl 1.15.0 (AC LF + AC sensitivity), Pyomo + HiGHS via `highspy`
(`solver_name="appsi_highs"`, `solver_io=None`), rdflib/ElementTree. No new dependencies.

**Solver note:** Use `solver_name="appsi_highs"` with `solver_io=None`. Do not use
`solver_io="python"` (raises `NotImplementedError` on the current Pyomo/highspy version).

**Side-awareness note (critical — inherits from R1):** All branch current lookups,
PATL comparisons, and sensitivity computations must remain side-aware throughout R2.
`current_limit_side_map` from `ncp_parser.build_current_limit_side_map()` must be
propagated to all new sensitivity calls. RD sensitivity uses `BRANCH_CURRENT_1` or
`BRANCH_CURRENT_2` depending on each AE's resolved side — see R2.1 for the confirmed
API pattern.

**NCP file note:** All NCP inputs come from per-TSO static files via the `NCP_FILES`
registry from R0.3: `{TSO}_SIS.xml` (participation factors, operating schedules) and
`{TSO}_RA.xml` (RA definitions, GLSK links). There are no per-hour IAM files.

---

## Cross-cutting requirement: composable RA-type workflows

**Approved during R2.4 development — applies to `milp_builder.py` and `run_pipeline.py`
from R2.4 onwards. This is an architectural decision, not scoped to a single increment.**

### Motivation

The MILP must support three independently selectable workflows depending on which RA
types participate:
1. **PST-only** — identical to today's R1.5 behaviour
2. **RD-only** — no PST preprocessing, no PST variables, no PST constraints
3. **PST + RD together** — both fully present

Selecting workflow 2 must mean PST-specific preprocessing (`parse_psts`,
`compute_sensitivity_pst_n0`, degrees-per-tap conversion) **never executes** —
not run-and-discarded. Symmetrically, selecting workflow 1 means RD preprocessing
never executes. Inside the MILP itself, selecting workflow 2 means **zero** PST
Pyomo components (`Var`, `Constraint`, `Expression`) exist on the model object —
not present-but-fixed-to-zero, genuinely absent.

### Control parameters (added to `run_pipeline.py` config section)

```python
enable_pst_remedial_actions: bool   # default True
enable_rd_remedial_actions: bool    # default True
```

Two independent booleans — consistent with existing control-parameter style
(e.g. `pst_taping_discrete`). Both `False` must raise a clear error before any
model-building begins — there is nothing to optimise.

### Preprocessing gating (wired in `run_pipeline.py` at R2.5)

```python
if enable_pst_remedial_actions:
    pst_list = ncp_parser.parse_psts(...)
    pst_degrees_per_tap = cgmes_loader.build_pst_degrees_per_tap(...)
    sensitivity_pst_n0 = sensitivity.compute_sensitivity_pst_n0(...)
    sensitivity_pst_n0_pruned = sensitivity.prune_sensitivity_by_threshold(
        ..., sensitivity_threshold_pct=SENSITIVITY_THRESHOLD_PCT_PST,
    )
    pst_inputs = PstMilpInputs(...)
else:
    pst_inputs = None   # parse_psts never called

if enable_rd_remedial_actions:
    rd_list, bid_list = ncp_parser.parse_rd_units(...)
    glsk_resolved = glsk.resolve_glsk(...)
    sensitivity_rd_n0 = sensitivity.compute_sensitivity_rd_n0(...)
    sensitivity_rd_n0_pruned = sensitivity.prune_sensitivity_by_threshold(
        ..., sensitivity_threshold_pct=SENSITIVITY_THRESHOLD_PCT_RD,
    )
    rd_inputs = RdMilpInputs(...)
else:
    rd_inputs = None    # parse_rd_units, resolve_glsk, compute_sensitivity_rd_n0 never called
```

Note: `SENSITIVITY_THRESHOLD_PCT_PST` and `SENSITIVITY_THRESHOLD_PCT_RD` are separate
config constants — PST sensitivity is in A/degree and RD sensitivity is in A/MW;
a shared threshold would silently over-prune one type (confirmed empirically: 5% excluded
all 12 real RD branches on Jotunheim because A/MW sensitivities are ~0.1–0.5 while the
threshold at 5% translates to ~50–100 A).

Network loading, AE/PATL parsing, and `lf_initial` remain unconditional in all workflows.

### `milp_builder.py` refactor (approved modification to R1.5's `build_n0_milp_model`)

This is a deliberate, approved architectural extension to committed R1 source — not a
bug fix. The PST-only behavioural contract is unchanged (regression-tested). Only the
function signature and internal structure change.

`build_n0_milp_model` becomes composable:

```python
def build_n0_milp_model(
    ae_flat_list,
    timestamp,
    lf_initial,
    min_loading_threshold_pct,
    pst_inputs: Optional[PstMilpInputs] = None,
    rd_inputs: Optional[RdMilpInputs] = None,
    penalty_cost_overload_n0: float = ...,
):
```

Internal structure (single function, not three near-duplicate functions):

1. **Base scaffold (unconditional):** `model`, `branch_ids`, `overload_slack_n0`.
   `branch_ids` covers the combined secured+scanned candidate set from
   `_get_monitored_branch_sides()` (see "Architecture note: unified branch candidate
   set" section) — not secured-only. No RA-type-specific content at this stage.
2. **`if pst_inputs is not None:`** — run the existing PST variable/constraint logic
   (tap changes, tap bounds, group equality), producing
   `model.pst_effect_on_branch[branch_mrid]` as a reusable Pyomo `Expression`.
3. **`if rd_inputs is not None:`** — run R2.4's RD variable/Pmax-Pmin logic,
   producing `model.rd_effect_on_branch[branch_mrid]` and
   `model.rd_net_injection_g[gu_mrid]` as `Expression`s.
4. **XNE loading constraint, built once at the end**, referencing whichever
   `Expression`s exist on the model:
   ```python
   def xne_loading_n0_rule(m, branch_mrid):
       pst_term = m.pst_effect_on_branch[branch_mrid] \
                  if hasattr(m, 'pst_effect_on_branch') else 0.0
       rd_term  = m.rd_effect_on_branch[branch_mrid] \
                  if hasattr(m, 'rd_effect_on_branch') else 0.0
       return (initial_current[branch_mrid] + pst_term + rd_term
               <= patl_ampere[branch_mrid] + m.overload_slack_n0[branch_mrid])
   ```
5. **Objective, same pattern** — PST penalty-cost terms only summed if
   `hasattr(model, 'tap_change_upward')`; RD terms only summed if RD components exist.

### Workflow acceptance criteria (apply from R2.4 onwards)

- **Given** `enable_pst_remedial_actions=True` and `enable_rd_remedial_actions=False`,
  **When** `build_n0_milp_model` is called,
  **Then** the model has zero `rd_volume_upward`, `rd_volume_downward`, or
  `rd_net_injection_g` components AND the result is behaviourally identical to
  pre-refactor R1.5 output (regression criterion — explicit regression test required).

- **Given** `enable_pst_remedial_actions=False` and `enable_rd_remedial_actions=True`,
  **When** `build_n0_milp_model` is called,
  **Then** the model has zero `tap_change_upward`, `tap_change_downward`,
  `tap_upper_bound`, `tap_lower_bound`, or `pst_group_equality` components.

- **Given** both `True`,
  **When** `build_n0_milp_model` is called,
  **Then** both PST and RD components are present and correctly summed in
  `xne_loading_n0` and the objective.

- **Given** both `False`,
  **When** `build_n0_milp_model` is called,
  **Then** a clear `ValueError` (or equivalent) is raised before any Pyomo model
  object is created.

**Forward reference (R5):** This two-flag architecture is extended to a third flag,
`enable_rd_generator_physics`, in R5 — see R5's "Cross-cutting requirement: Full RD
Optimization workflow" section. R5 introduces a distinction between what will
eventually be renamed "Simple RD Optimization" (today's RD-only workflow, unchanged)
and "Full RD Optimization" (RD-only plus the generator physics layer). No renaming
happens in R2 or at R5's introduction — the workflow names in this document remain
"PST Optimization" / "RD Optimization" / "PST+RD Optimization" until an explicit
future documentation pass renames them consistently across all release files.

---

## Architecture note: unified branch candidate set for sensitivity and MILP Expressions

**Established during R2.12 development — applies retroactively to R2.1, R2.2, R2.4, R2.5,
and forward to R2.12. This corrects an initial scope restriction, not a new feature.**

`_get_monitored_branch_sides()` (introduced in R2.1) determines which branches are
candidates for sensitivity computation, based on `min_loading_threshold_pct` (Filter 1).
This filter is independent of AE type — it asks "is this branch loaded enough to deserve
sensitivity computation," which applies equally to `secured` and `scanned` AEs. Restricting
the candidate set to `AEType.SECURED` only (as initially built in R2.1) was a scope gap,
not a deliberate design choice, and has been corrected:

- `_get_monitored_branch_sides()` returns the side-map for **every** AE in `AEFlatList`
  (secured and scanned) that passes `min_loading_threshold_pct` against its own respective
  limit (`patl` for secured, `effective_limit` for scanned)
- `sensitivity_pst_n0` / `sensitivity_rd_n0` (R2.1) and their pruned versions (R2.2)
  therefore contain entries for both AE types
- `branch_ids` (the Pyomo `Set` underlying `pst_effect_on_branch` / `rd_effect_on_branch`
  from R2.4) is built over this same combined set — one `Set`, one pair of `Expression`s,
  not separate parallel sets per AE type
- `xne_loading_n0` (R2.5) filters its constraint-building loop to the `AEType.SECURED`
  subset of `branch_ids`
- The scanned-element constraint (R2.12) filters its loop to the `AEType.SCANNED` subset
  of the same `branch_ids`, and reuses the same `pst_effect_on_branch[b]` /
  `rd_effect_on_branch[b]` Expressions — no separate Expression-building logic for
  scanned branches

Filter 2 (`sensitivity_threshold_pct_pst` / `sensitivity_threshold_pct_rd`, R2.2) is then
applied uniformly to this combined candidate set — it does not distinguish AE type either;
it prunes individual (branch, RA) pairs regardless of whether the branch is secured or
scanned.

**Impact on already-written R2.1 tests:** any test asserting that scanned branches are
absent from `sensitivity_pst_n0` / `sensitivity_rd_n0` reflected the initial (incorrect)
scope restriction and must be updated to reflect the corrected, wider scope. This is a
scope correction, not a regression in R2.1's actual sensitivity computation logic.

---

| Item | Reason deferred |
|------|----------------|
| CORNET-4595/45/46/47/48/49/50/69/70 — Generator physics (gradients, min-up/down, ramps) | Added in R5 |
| CORNET-4596/91 — Lead and lag times | Added in R5 |
| BUC14#103 — Start-up costs | Added in R5 |
| CORNET-3626/3711 — Energy limits per bid | Added in R5 |
| CORNET-3632 — RD step sizes (integer variables) | Added in R5 |
| BUC14#102 — Power bid activation costs | Added in R5 |
| CORNET-4614 — PRAs and CRAs for same generating unit | Added in R3 (CRA scope) |

---

## R2.1 — N-0 AC sensitivity matrix for RD units (CORNET-4836 / CORNET-102)

**Spec ref:** CORNET-4836, CORNET-102 — extended to generating units

**What it delivers:**
- Compute `dI_b / dP_g` (A per MW injection change) for each generating unit `g`
  linked to an available preventive RD RA in `RDList`, evaluated at `lf_initial`
- Candidate branches `b` are determined by `_get_monitored_branch_sides()` — this
  covers **all** AEs in `AEFlatList` (both `secured` and `scanned`) that pass
  `min_loading_threshold_pct` against their own respective limit (`patl` for secured,
  `effective_limit` for scanned). See the "Architecture note: unified branch candidate
  set" section above — AE type does not restrict sensitivity computation.
- Use the confirmed pypowsybl AC sensitivity API:
  ```python
  sa = pp.sensitivity.create_ac_analysis()
  sa.add_factor_matrix(
      functions_ids=branch_mrids_side1,       # branches whose AE resolves to side 1
      variables_ids=generator_mrids,
      contingencies_ids=[],
      contingency_context_type=pp.sensitivity.ContingencyContextType.NONE,
      sensitivity_function_type=pp.sensitivity.SensitivityFunctionType.BRANCH_CURRENT_1,
      sensitivity_variable_type=pp.sensitivity.SensitivityVariableType.INJECTION_ACTIVE_POWER,
      matrix_id='ptdf_rd_side1'
  )
  # Repeat with BRANCH_CURRENT_2 for branches whose AE resolves to side 2
  result = sa.run(network)
  matrix = result.get_sensitivity_matrix('ptdf_rd_side1')
  # matrix.index = generator_mRIDs, matrix.columns = branch_mRIDs
  # lookup: matrix.loc[gu_mrid, branch_mrid]
  ```
  `INJECTION_ACTIVE_POWER` (not `TRANSFORMER_PHASE` — that is PST-only). Values are
  in A/MW directly — no degrees-per-tap conversion needed.
- Store as `sensitivity_rd_n0: dict[(branch_mrid, gu_mrid), float]` — covers both
  secured and scanned branches

**Dataset note:** On the current Jotunheim dataset cut, only Belgovia has real RD units
(2 generating units: `3a3b27be-...` and `550ebe0d-...`). Espheim and Svedala have zero
RD units. The sensitivity matrix will be non-empty but small (12 branches × 2 units = 24
pairs before pruning).

**Inputs:**
- `network` (pypowsybl `Network` from R0.1)
- `lf_initial` (from R1.1)
- `RDList` (from R0.7), `AEFlatList` (from R0.4)
- `current_limit_side_map` (from `ncp_parser.build_current_limit_side_map()`)
- `sensitivity_threshold_pct: float` (default 0.0)

**Outputs:**
- `sensitivity_rd_n0: dict[(branch_mrid, gu_mrid), float]` (in-memory, A/MW)
- `sensitivity_rd_n0.csv`: columns `[branch_mrid, branch_name, gu_mrid, gu_name,
  tso, side, di_dp_ampere_per_mw]`

**Acceptance criteria:**
- Given `RDList` contains at least one available preventive RD unit,
- When `sensitivity_rd_n0` is computed via pypowsybl,
- Then every `(branch_mrid, gu_mrid)` pair for an available preventive RD unit has a
  non-null sensitivity value AND `sensitivity_rd_n0.csv` contains at least one
  non-zero entry AND side-1 and side-2 branches are handled by separate matrix calls
  AND branches classified as `scanned` in `AEFlatList` are included in the candidate
  set on equal footing with `secured` branches (subject only to `min_loading_threshold_pct`).

---

## R2.2 — Sensitivity threshold pruning (CORNET-3624)

**Spec ref:** CORNET-3624 — Sensitivity Threshold

**What it delivers:**
- Apply `sensitivity_threshold_pct_pst` and `sensitivity_threshold_pct_rd` separately
  (two distinct config constants — PST sensitivity is in A/degree, RD in A/MW;
  a shared threshold silently over-prunes one type):
  - For each branch `b`, if `max_τ |sensitivity_pst_n0[b,τ]| < sensitivity_threshold_pct_pst
    × patl_or_effective_limit[b] / 100` → exclude PST `τ` from the loading constraint
    for branch `b`
  - For each branch `b`, if `max_g |sensitivity_rd_n0[b,g]| < sensitivity_threshold_pct_rd
    × patl_or_effective_limit[b] / 100` → exclude unit `g` from the loading constraint
    for branch `b`
  - The limit used is `patl[b]` for `secured` branches and `effective_limit[b]` for
    `scanned` branches — the threshold logic itself does not distinguish AE type,
    only the limit value it compares against does
- Also prune branches where initial loading < `min_loading_threshold_pct` (default 0%)
  — applied identically regardless of AE type
- Log pruning statistics: pairs removed per threshold, percentage reduction in MILP size,
  broken down by AE type for visibility

**Dataset note:** On Jotunheim, `sensitivity_threshold_pct_rd = 5.0` excluded all 12 real
RD branches (confirmed empirically) because A/MW sensitivities (~0.1–0.5) are far below
the ~50–100 A threshold that 5% implies. Use a lower `sensitivity_threshold_pct_rd` (e.g.
0.0 or 0.1) for live-data runs. 5% is appropriate for PST (A/degree scale), not RD (A/MW).

**Inputs:**
- `sensitivity_pst_n0`, `sensitivity_rd_n0`, `AEFlatList` (PATL values via `patl`)
- RAO control parameters: `sensitivity_threshold_pct_pst: float`,
  `sensitivity_threshold_pct_rd: float`, `min_loading_threshold_pct: float`

**Outputs:**
- `sensitivity_pst_n0_pruned`, `sensitivity_rd_n0_pruned` (in-memory)
- Console log: pairs pruned per threshold, percentage reduction in MILP size

**Acceptance criteria:**
- Given `sensitivity_threshold_pct_pst = 5.0` and a PST with `|dI/ds| = 0.001 A/tap`
  on a branch with `patl = 1000 A`,
- When pruning is applied,
- Then that (branch, PST) pair is removed AND the total (branch, RA) coefficient count
  in the MILP is strictly less than before pruning AND setting both thresholds to 0.0
  produces zero pruning (all pairs retained).

---

## R2.3 — GLSK participation factor mapping (CORNET-4848)

**Spec ref:** CORNET-4848 — Definition of GLSK in RAO

**What it delivers:**
- For each RD RA in `RDList`, resolve the linked participation factor schedule from
  `{TSO}_SIS.xml`
- **CIM class note:** The functional spec refers to this conceptually as "GLSKSchedule"
  but the actual CIM class in the NC profile is `PowerShiftKeySchedule` with child
  `ParticipationFactorTimePoint.participationFactor` per generating unit. There is no
  class literally named `GLSKSchedule` in this dataset — parse `PowerShiftKeySchedule`.
- Linkage path: `RD RA → PowerBidSchedule.PowerRemedialAction →
  PowerShiftKeyDistribution.PowerBidSchedule →
  PowerShiftKeyDistribution.PowerShiftKeySchedule →
  ParticipationFactorTimePoint.PowerShiftKeySchedule →
  PowerShiftKeySchedule.GeneratingUnit`
- Apply normalisation: if any generating unit is not in `network.get_generators().index`
  → remove and redistribute participation factors proportionally among remaining units
- Build `glsk: dict[ra_mrid, dict[gu_mrid, float]]`
- Log any GLSK that resolves to zero valid units (RA excluded from optimisation)

**Dataset note (confirmed by direct file inspection):** The real Belgovia RD RA
(`d874f8e3-...`, "Redispatch", preventive, available=True, covering generating units
`3a3b27be-...` and `550ebe0d-...`) does NOT appear in `Belgovia_SIS.xml`. The
`PowerShiftKeySchedule` data present in the SIS file is linked to a different, unrelated
RA mRID — the same illustrative spec-example fragment already identified in the power bid
finding. Net result: `glsk` will be empty for both real Belgovia RD units on this dataset
cut. This is a dataset boundary condition, not a parsing bug. Build `glsk.py`
spec-faithfully with an explicit empty-GLSK guard and log — same pattern as R1's PST
availability guard and R2's bid guard.

**Inputs:**
- `{TSO}_SIS.xml` files (from `NCP_FILES`)
- `RDList` (from R0.7)
- `network` (pypowsybl `Network` — `network.get_generators().index` for validation)

**Outputs:**
- `glsk: dict[ra_mrid, dict[gu_mrid, float]]` (in-memory; empty on current dataset)
- `glsk_resolved.csv`: columns `[ra_mrid, ra_name, gu_mrid, gu_name, tso,
  participation_factor_original, participation_factor_normalised]`

**Acceptance criteria:**
- Given a GLSK with 4 generating units where one is not in `network.get_generators()`,
- When `glsk` is built,
- Then the excluded unit does not appear AND the remaining three participation factors
  sum to 1.0 (±0.001) AND the RA is not excluded unless all units are invalid AND
  on the current Jotunheim dataset `glsk` is empty with a logged WARNING.

---

## R2.4 — RD MILP variables and Pmax/Pmin constraints (CORNET-36, CORNET-37)

**Spec ref:** CORNET-36 — Upper active power limits; CORNET-37 — Lower active power limits

**Architecture note:** This increment also implements the `build_n0_milp_model`
composability refactor described in the cross-cutting section above. The R1.5 function
signature changes here. A regression test confirming PST-only behaviour is unchanged
is required before proceeding to R2.5.

**What it delivers:**
- Implement the `RdMilpInputs` dataclass grouping all RD-specific MILP inputs:
  `rd_list`, `bid_list`, `glsk`, `sensitivity_rd_n0_pruned`, `generator_data`
  (from `network.get_generators()`)
- Implement the `PstMilpInputs` dataclass grouping all PST-specific MILP inputs:
  `pst_list`, `pst_tap_bounds`, `pst_group_equality_pairs`, `sensitivity_pst_n0_pruned`,
  `pst_degrees_per_tap`
- Refactor `build_n0_milp_model` to accept `pst_inputs: Optional[PstMilpInputs]` and
  `rd_inputs: Optional[RdMilpInputs]` (see cross-cutting section for full signature)
- Add the RD block (`if rd_inputs is not None`) inside `build_n0_milp_model`:
  - `model.bid_ids` — Pyomo `Set` from `PowerBid.mrid`
  - `model.rd_volume_upward[bid_mrid]` and `model.rd_volume_downward[bid_mrid]`
    (`domain=pyo.NonNegativeReals`)
  - Upper bounds per bid direction: a bid with `direction=UP` gets
    `rd_volume_upward.setub(available_mw)` and `rd_volume_downward.setub(0.0)`;
    mirror for `direction=DOWN` — each `PowerBidSchedule` is one-directional
  - `model.rd_net_injection_g[gu_mrid]` — Pyomo `Expression`:
    `Σ_bid participation_factor[gu, ra] × (rd_volume_upward[bid] − rd_volume_downward[bid])`
    built once here so R2.5–R2.12 can reference it directly
  - `model.rd_effect_on_branch[branch_mrid]` — Pyomo `Expression`:
    `Σ_g sensitivity_rd_n0_pruned[branch, g] × rd_net_injection_g[g]`
  - `model.pmax_pmin_constraint[gu_mrid]` — hard constraint:
    `min_p ≤ target_p + rd_net_injection_g[gu_mrid] ≤ max_p`
    for every generating unit reachable through any RA's resolved GLSK
    (`target_p`, `max_p`, `min_p` from `network.get_generators()`)
  - **Empty-GLSK guard:** if `bid_list` is empty or no generating unit has any
    non-empty GLSK participation, log a WARNING and add no RD variables/constraints
    — this will fire on the current Jotunheim dataset

**Inputs:**
- `pst_inputs: Optional[PstMilpInputs]` (from R1.2–R1.4 preprocessing)
- `rd_inputs: Optional[RdMilpInputs]` (from R2.1–R2.3 preprocessing)
- `AEFlatList`, `lf_initial`, `patl`
- RAO control parameters: `enable_pst_remedial_actions`, `enable_rd_remedial_actions`,
  `penalty_cost_overload_n0`, `min_loading_threshold_pct`

**Outputs:**
- `milp_model` — refactored Pyomo `ConcreteModel` with composable RA blocks

**Acceptance criteria:**
- Given `rd_inputs` is provided with two bids (one UP, one DOWN) and two generating units,
- When `build_n0_milp_model` is called,
- Then `model.rd_volume_upward` and `model.rd_volume_downward` exist with correct upper
  bounds per direction AND `model.rd_net_injection_g` is an Expression indexed by
  generating unit mRID AND `model.pmax_pmin_constraint` exists for each reachable unit.
- **Regression:** Given only `pst_inputs` is provided (`rd_inputs=None`),
- When `build_n0_milp_model` is called,
- Then the model is behaviourally identical to pre-refactor R1.5 output (same variables,
  constraints, and objective value on the same synthetic test case).

---

## R2.5 — RD N-0 loading constraints extension

**Spec ref:** CORNET-1790 — XNE loading constraints extended with RD terms

**⚠ Confirmed gap, found late and now fixed — recorded here because this is
where the original deferral was made.** At the time this increment was first
implemented, `run_post_rao_linearisation_loop` (R1.7) was left genuinely
PST-only — its own code comment stated explicitly: *"This loop is PST-only in
its internals... and is NOT extended to RD in R2.5 — a composable, RD-aware
iterative AC-validation loop is a separate, larger, explicitly-deferred piece
of work, not part of this increment."* This was a **deliberate, correctly
labelled deferral at the time**, not a silent oversight — but this MD never
carried that deferral note forward into the spec record, which is why it
resurfaced as a surprise much later rather than as a tracked, known item.

**What this meant in practice, confirmed directly against live
`run_pipeline.py` branching logic:** the loop was only ever called when
`pst_inputs is not None and rd_inputs is None`. The moment RD was active at
all — RD-only or PST+RD — the code took a different branch entirely: a single
`build_n0_milp_model(...)` call followed by one raw solve. **No AC load flow
re-verification, no convergence check, no iteration** — every RD-involving
single-timestamp result produced by this path was a linear MILP approximation
that was never checked against a real AC load flow. This is a materially
different (and more serious) gap than "the loop exists but doesn't track RD"
— it was a complete absence of any AC-verification loop for that entire code
path.

**Fixed via a new sibling function, not a modification of R1.7's original
loop** (which stays byte-for-byte unchanged, confirmed by regression test —
its PST-only behaviour is untouched): `run_post_rao_ac_verification_loop`.
Built by reusing four already-correct, already-tested functions rather than
writing new apply/restore/extract logic a third or fourth time:
- `apply_preventive_solution_to_network` / `restore_network_state` (from R3's
  `completeness_loop.py`, confirmed genuinely contingency-agnostic and already
  handling both PST taps and generator `target_p`)
- `extract_pst_tap_solution` / `extract_rd_target_p_solution` (from
  `post_ra_congestion_check.py`, confirmed to already implement the
  `hasattr`-gating discipline this loop needs — a PST-only model naturally
  returns `{}` for RD and vice versa, with no new gating logic required)

**The RD "current operating point" anchor — confirmed by reading it directly
out of the RD MILP's own Pmax/Pmin constraint**, not inferred from naming
convention:
```python
gu_data = rd_inputs.generator_data.get(gu_mrid, {})
target_p = float(gu_data.get("target_p", gu_data.get("initial_p", 0.0)))
return (min_p, target_p + m.rd_net_injection_g[gu_mrid], max_p)
```
This is structurally identical to PST's `pst.r0 + tap_change_upward -
tap_change_downward` — a baseline plus a solved delta. Confirmed
`generator_data[gu_mrid]["target_p"]` is genuinely the RD equivalent of
`pst.r0`, refreshed after each converged AC LF via a new, narrowly-scoped
helper `_extract_generator_target_p` (reading only `target_p` from
`network.get_generators()`, mirroring `_extract_phase_tap_positions`'s own
narrow scope — deliberately not reusing the heavier `extract_equipment_dicts()`
just because it happens to contain the right field).

**Convergence tracking:** two independent terms — `total_tap_change_sum` (PST,
unchanged from R1.7) and a new RD MW-change term, gated the same way: a
PST-only run's RD term is trivially always below threshold (never blocks); an
RD-only run's PST term likewise. **Known, dated simplification:** the RD
convergence threshold currently reuses the existing
`MAX_CHANGE_RA_SUM_THRESHOLD` config value rather than introducing a dedicated
RD-specific one, to avoid reopening broader config work. Flagged explicitly in
code; a dedicated threshold can be split out later if independent tuning turns
out to matter.

**⚠ Near-miss worth naming as a recurring risk category for this codebase,
not just this instance.** During development, an early version of this fix
reused a single `sensitivity_threshold_pct` for both PST and RD refresh —
violating this project's own confirmed rule (established during R3.2's
pruning work) that PST and RD must never share a sensitivity threshold, since
a shared 5% threshold once excluded every real RD branch entirely. Caught and
fixed before merge, but this is now the second time this exact mistake has
surfaced independently. **Any future PST/RD-adjacent code in this project
should default to checking "did I accidentally reuse one threshold for both"
the same way "used a balanceable RD bid pair" and "asserted actual values not
just presence" became standing defaults after recurring.**

`run_pipeline.py`'s branching updated: PST-only, RD-only, and PST+RD all now
route through `run_post_rao_ac_verification_loop`. Only genuine N-X-only (no
preventive PST or RD active at all) still uses the old single-solve path —
correctly, since there is nothing to iterate on in that case.

**⚠ Second, later finding on this same function — see R1.7's own entry for
the full record; cross-referenced here since `run_post_rao_ac_verification_loop`
is this increment's function, not R1.7's.** A subsequent investigation (started
from an unrelated question about PST tap-change limits) found that this loop's
non-convergence handling — reverting the network to the pre-RA baseline — was
always correct and spec-compliant, but **the CSV export layer never reflected
which of the possible outcomes (at the time of writing four: `CONVERGED`/`REVERTED_NON_CONVERGENT`/
`MAX_ITERATIONS_REACHED`/`NOT_APPLICABLE`; the enum now has seven members, see `AC_Verification_Loop_Technical_Reference.md`) actually occurred.** `results_preventive_rd.csv`
was one of the five files affected — confirmed to unconditionally report the
MILP's *proposed* RD dispatch even on a run where the network had been fully
reverted to pre-RA state, with no signal anywhere in the file that this had
happened. Fixed as part of the same `AcVerificationStatus` fix documented in
full in R1.7 — `results_preventive_rd.csv` now carries the same `ac_verification_status`
column as the other four affected files. See R1.7 for the complete
investigation record, including the confirmed-wrong initial hypothesis
(CORNET-3653/3654), the CORNET-106 spec finding, and the process near-miss
from a separate, related fix attempt during the same investigation.

**Known follow-up, explicitly out of scope for this fix, flagged not
forgotten:** R3.8's completeness loop does its own sequential rebuild-and-raw-solve
per iteration with no AC re-verification either — an already-documented,
separate deferral ("NOT jointly-converging in one combined loop," see R3.10).
Once an RD-aware linearisation loop exists, that completeness-loop closure
would eventually want an RD-aware equivalent too, for full consistency. Not
addressed by this fix; recorded here as a known next step.

**Composability note:** This increment wires the `pst_effect_on_branch` and
`rd_effect_on_branch` Expressions into the XNE loading constraint. Both PST-only,
RD-only, and PST+RD workflows must continue to work correctly after this increment.

**What it delivers:**
- Replace the hardcoded PST-only `xne_loading_n0` constraint from R1.5 with the
  composable version described in the cross-cutting section. This constraint iterates
  only over the `AEType.SECURED` subset of `branch_ids` — `branch_ids` itself is wider
  (covers secured + scanned per the "Architecture note" above), but XNE loading
  constraints apply only to secured branches. Scanned branches are handled separately
  in R2.12, reusing the same `pst_effect_on_branch` / `rd_effect_on_branch` Expressions.
  ```python
  def xne_loading_n0_rule(m, branch_mrid):
      pst_term = m.pst_effect_on_branch[branch_mrid] \
                 if hasattr(m, 'pst_effect_on_branch') else 0.0
      rd_term  = m.rd_effect_on_branch[branch_mrid] \
                 if hasattr(m, 'rd_effect_on_branch') else 0.0
      return (lf_initial[branch_mrid] + pst_term + rd_term
              <= patl_ampere[branch_mrid] + m.overload_slack_n0[branch_mrid])
  ```
- Wire the `run_pipeline.py` preprocessing gating:
  ```python
  if enable_pst_remedial_actions:
      pst_inputs = PstMilpInputs(...)
  else:
      pst_inputs = None

  if enable_rd_remedial_actions:
      rd_inputs = RdMilpInputs(...)
  else:
      rd_inputs = None

  if not enable_pst_remedial_actions and not enable_rd_remedial_actions:
      raise ValueError("At least one of enable_pst_remedial_actions or "
                       "enable_rd_remedial_actions must be True")
  ```

**Inputs:**
- `milp_model` (from R2.4), `sensitivity_pst_n0_pruned`, `sensitivity_rd_n0_pruned`
- `lf_initial`, `patl`, `AEFlatList`

**Outputs:**
- Updated `milp_model` with composable combined PST+RD loading constraints

**Acceptance criteria:**
- Given an XNE overload that PST alone cannot resolve but RD can,
- When the MILP is solved with both enabled,
- Then the RD unit with the highest sensitivity on the overloaded branch is activated
  AND `overload_slack_n0` for that branch is zero (overload resolved).
- Given `enable_rd_remedial_actions=False`,
- When `run_pipeline.py` preprocessing runs,
- Then `parse_rd_units`, `resolve_glsk`, and `compute_sensitivity_rd_n0` are never called.
- Given `rd_inputs` is real (RD-only or PST+RD),
- When `run_pipeline.py` is run,
- Then `run_post_rao_ac_verification_loop` is genuinely called — not the old
  single-raw-solve path — confirmed via a test that first proves the pre-fix
  bypass against real code, then proves the fix closes it.
- Given a scenario where the linear sensitivity approximation and a real AC
  load flow disagree enough to change RD dispatch on a second iteration,
- When the loop runs,
- Then RD dispatch genuinely changes between iterations and convergence is
  correctly gated on the RD term, not just the PST term — proving the fix
  does something, not merely that it runs without error.
- *(Historical — the byte-for-byte comparison no longer applies: the old PST-only function is no longer part of the flow after the loop redesign.)*
- Given identical PST-only inputs,
- When `run_post_rao_ac_verification_loop` and the original `run_post_rao_linearisation_loop`
  are each run,
- Then their outputs are byte-for-byte identical — confirming R1.7's original
  behaviour is genuinely unchanged, not just "probably fine."
- Given a scenario where this loop reverts to the pre-RA baseline
  (non-convergent AC LF),
- When `results_preventive_rd.csv` is inspected,
- Then `ac_verification_status == REVERTED_NON_CONVERGENT` on every row and no
  RD dispatch value is presented as if it were applied — see R1.7 for the full
  investigation and the other four affected files.

**⚠ A second, later investigation on this same function — the tap-mismatch
baseline bug and the incremental-fallback mechanism it produced. Recorded in
the order actually discovered.**

**Starting symptom:** on a real multi-PST scenario, `run_post_rao_ac_verification_loop`
failed on iteration 2 with a specific, informative message: re-solving
iteration 2's own starting operating point (the state iteration 1 had already
reached and verified) did not converge — a state confirmed convergent earlier
in the same run failing to re-converge moments later.

**Diagnosis, traced precisely rather than patched on symptom:** iteration 2's
own direct jump to its newly-proposed target was attempted first, and failed
— leaving the network's voltage state at whatever a diverged Newton-Raphson
solve left behind, not a valid state. The fallback's own revert step reset
tap positions and generator setpoints back to `iteration_start`, but **not**
the network's voltage values, which remained corrupted from the failed jump.
The subsequent "confirm `iteration_start` is still valid" re-solve then used a
flat start (`UNIFORM_VALUES`, the configured default) rather than any warm
start — attempting to re-derive a complex, multi-PST operating point from
scratch, when the only reason it had converged the first time was reaching it
incrementally, one warm-started step at a time.

**The real design issue, stated precisely: `iteration_start` was never a
state that could be cheaply re-derived with a flat solve — it was only
reachable via the same incremental, warm-started process that produced it in
the first place.** Treating it as a trivial checkpoint to re-confirm was the
actual mistake, not a missing solver parameter.

**Two options considered and rejected before the one actually built:**
- **Re-solve `iteration_start` with `voltage_init_mode=PREVIOUS_VALUES`** —
  rejected. `PREVIOUS_VALUES` reads whatever is currently live on the network
  object, which at that exact moment is the diverged output of the failed
  jump, not a known-good prior state. This could warm-start from garbage and
  produce a worse failure than the flat start it was meant to replace, not
  merely "move the failure elsewhere."
- **Ramp incrementally from `original_tap_positions`** (the one state always
  guaranteed valid, being the true pre-loop starting point) **all the way to
  the final target, in one longer sequence, never attempting to cheaply
  re-confirm an intermediate point at all** — correct, but with a real,
  flagged cost tradeoff: the fallback's cost grows with how far the loop has
  already progressed, since a later iteration's failure means ramping the
  full original distance, not just the most recent step.

**What was actually built — an explicit voltage-state snapshot, confirmed
implementable before committing to it:** rather than trusting the network
object's own live state or ramping the full original distance, the loop now
explicitly snapshots the converged bus voltage state at the end of every
successfully converged iteration — alongside the tap-position and
generator-setpoint state it already snapshots — before any risky jump is
attempted. On a jump's failure, both the explicit voltage snapshot and the
tap/generator state are restored together, and the retry is genuinely
warm-started from a point captured at the moment it was known good, not from
ambiguous "previous" state or a flat guess. Confirmed cheaper than the
full-ramp alternative (no growing cost with iteration count) and correct in a
way the `PREVIOUS_VALUES` option could not be, since it restores a value
captured deliberately rather than trusting whatever the network object
happens to hold at an arbitrary later moment.

**Implementation:** `_snapshot_bus_voltage_state`/`_restore_bus_voltage_state`
(explicit per-bus voltage magnitude/angle capture and restore) and
`_apply_changes_incrementally` (bounded step-by-step ramp toward a target,
re-verifying AC convergence at each step, falling back to the explicit
snapshot on failure) — built first in this loop, later generalised and moved
to a shared location for reuse by the completeness loop (see R3.8's own
Finding #4 for that reuse and the further gap it uncovered downstream).

---

## R2.6 — RD balancing constraint (CORNET-73)

**Spec ref:** CORNET-73 — Balancing of Redispatch Remedial Actions

**Composability note:** This constraint references `model.rd_net_injection_g`. It must
only be added when `rd_inputs is not None` — do not add it in PST-only workflow.

**What it delivers:**
- Add a hard per-timestamp balancing constraint:
  `Σ_g rd_net_injection_g[g] = 0` (no slack, no relaxation)
- Only added when RD components exist on the model (`hasattr(model, 'rd_net_injection_g')`)

**Inputs:**
- `milp_model` (RD variables from R2.4)

**Outputs:**
- Updated `milp_model` with balancing constraint

**Acceptance criteria:**
- Given any feasible solution with at least one RD unit activated,
- When the MILP is solved,
- Then `|Σ_g rd_net_injection_g[g]| < 0.01 MW`.
- Given PST-only workflow (`rd_inputs=None`),
- Then no balancing constraint is added to the model.

---

## R2.7 — RD penalty and price costs in objective (CORNET-4606)

**Spec ref:** CORNET-4606 — Considered costs of redispatch RA in preventive mode

**Composability note:** RD cost terms are only added to the objective when
`hasattr(model, 'rd_volume_upward')`. PST cost terms remain unchanged.

**What it delivers:**
- Extend the Pyomo objective with RD cost terms per bid:
  ```
  rd_cost_per_bid[b] =
    (rd_penalty_factor[b] * penalty_reference_rd_pra + price_rd_upward[b])
    * rd_volume_upward[b]
    + (rd_penalty_factor[b] * penalty_reference_rd_pra + price_rd_downward[b])
    * rd_volume_downward[b]
  ```
  where `rd_penalty_factor[b]` from `RemedialAction.penaltyFactor` in `{TSO}_RA.xml`
  and prices from `PowerBidSchedule` in `{TSO}_SIS.xml`
- Apply TSO-specific `penalty_reference_rd_pra_per_tso` override if defined (CORNET-4339)

**Inputs:**
- `PowerBidList` (price, penalty factor per bid)
- RAO control parameters: `penalty_reference_rd_pra: float`,
  optional `penalty_reference_rd_pra_per_tso: dict[tso, float]`

**Outputs:**
- Updated `milp_model` objective
- `results_preventive_rd.csv`: columns `[ra_mrid, bid_mrid, tso, rd_volume_net_mw,
  price_eur_mw, rd_penalty_factor, penalty_cost_eur, rd_cost_eur]`

**Acceptance criteria:**
- Given two bids with `price_rd_upward = 10 EUR/MW` and `price_rd_upward = 20 EUR/MW`
  both capable of resolving the same congestion,
- When the MILP is solved,
- Then the cheaper bid (10 EUR/MW) is preferred (activated first or more).

---

## R2.8 — RA count limit per TSO per timestamp (BUC14#119, CORNET-3649)

**Spec ref:** BUC14#119; CORNET-3649

**Composability note:** Binary `ra_activated` variables and RA count constraints only
added when RD components exist on the model.

**Update (loop redesign):** in later solves the binary is linked to the absolute
cumulative net volume of the RA's bid(s) with big-M = original availability, not
fixed to 1; in a run with no count limit configured the binary has no lower link, so
the export derives activation from the net volume (see the box at the top of this file).

**What it delivers:**
- Add binary activation variable `ra_activated[ra_mrid] ∈ {0,1}` linked via big-M:
  `rd_volume_upward[bid] + rd_volume_downward[bid] ≤ big_m * ra_activated[ra_mrid]`
- Per-TSO per-timestamp RA count constraint (BUC14#119):
  `Σ_{ra ∈ TSO_k} ra_activated[ra] − ra_count_slack_per_timestamp[k] ≤ max_ra_count_per_timestamp_tso[k]`
  hard if `ra_limit_constraint_hard=True`; soft (penalised by `ra_limit_penalty`) if False
- Per-TSO per-timeframe constraint (CORNET-3649):
  `Σ_{ra ∈ TSO_k} ra_activated[ra] − ra_count_slack_per_timeframe[k] ≤ max_ra_count_per_timeframe_tso[k]`
  penalised by `ra_limit_penalty`
- Skip constraint for any TSO without a defined limit

**Inputs:**
- RAO control parameters: `max_ra_count_per_timestamp_tso: dict[tso, int]`,
  `max_ra_count_per_timeframe_tso: dict[tso, int]`,
  `ra_limit_penalty: float`, `ra_limit_constraint_hard: bool`

**Outputs:**
- Updated `milp_model` with binary variables and RA count constraints
- `results_preventive_rd_ra_count.csv` (was `results_ra_count.csv`): columns `[tso, activated_ra_count, limit_per_timestamp,
  slack_per_timestamp, limit_per_timeframe, slack_per_timeframe]`

**Acceptance criteria:**
- Given `max_ra_count_per_timestamp_tso = 2` for a TSO with 4 available RD RAs
  and `ra_limit_constraint_hard = True`,
- When the MILP is solved,
- Then no more than 2 RD RAs are activated for that TSO.

---

## R2.9 — RA group volume limits (CORNET-4838)

**Spec ref:** CORNET-4838 — Limitation of Redispatch and Countertrade for Remedial Action Groups for PRAs

**Composability note:** Group volume constraints only added when RD components exist.

**What it delivers:**
- Parse `RemedialActionGroup` and `RemedialActionDependency` from `{TSO}_RA.xml`
- For groups where `RemedialActionDependencyKind == restrictive`, add constraints:
  ```
  Σ_{b ∈ group} rd_volume_upward[b] ≤ max_regulating_up[group]
  Σ_{b ∈ group} rd_volume_downward[b] ≤ max_regulating_down[group]
  ```
  Limits from `{TSO}_SIS.xml` keyed by `atTime`
- Skip groups without `restrictive` dependency

**Inputs:**
- `{TSO}_RA.xml` files — `RemedialActionGroup`, `RemedialActionDependency`
- `{TSO}_SIS.xml` files — `max_regulating_up`, `max_regulating_down`

**Outputs:**
- Updated `milp_model` with group volume constraints
- `results_preventive_rd_ra_groups.csv` (was `results_ra_groups.csv`): columns `[group_mrid, total_volume_upward_mw,
  max_volume_upward_mw, total_volume_downward_mw, max_volume_downward_mw]`

**Acceptance criteria:**
- Given a RA group with `max_regulating_up = 100 MW` containing two bids,
- When the MILP is solved,
- Then `rd_volume_upward[bid1] + rd_volume_upward[bid2] ≤ 100 MW`.

---

## R2.10 — RD lead time enforcement (CORNET-3616)

**Spec ref:** CORNET-3616; CORNET-3447

**Composability note:** Lead time enforcement only runs when RD components exist.

**What it delivers:**
- Compute `radp` from `raart` control parameter (default: timestamp before `START_HOUR`)
- For each bid with `bid_lead_time_hours > 0`:
  earliest usable timestamp = first `t` where `radp + bid_lead_time_hours ≤ t`
- Fix bounds via `model.rd_volume_upward[bid_mrid].setub(0.0)` and
  `model.rd_volume_downward[bid_mrid].setub(0.0)` for unusable timestamps
  (Pyomo `setub()` — not HiGHS-specific calls)

**Inputs:**
- `PowerBidList` (`bid_lead_time_hours` per bid)
- `TIMESTAMP_LIST`
- RAO control parameter: `raart: str` (optional)

**Outputs:**
- Updated variable bounds in `milp_model`
- `results_lead_times.csv`: columns `[bid_mrid, ra_mrid, bid_lead_time_hours,
  radp, earliest_usable_timestamp]`

**Acceptance criteria:**
- Given `raart = "2200Z"` and a bid with `bid_lead_time_hours = 3` and
  `START_HOUR = "0030Z"`,
- When lead time enforcement is applied,
- Then `rd_volume_upward` and `rd_volume_downward` upper bounds are 0 for timestamps
  `0030Z` and `0130Z` AND non-zero values are permitted from `0230Z` onwards.

---

## R2.11 — Combined PST+RD results output (BUC14#132 general results)

**Spec ref:** BUC14#132 — General Optimisation results (prototype subset)

**Composability note:** Results export adapts to which RA types are active.
PST-only workflow exports PST results only; RD-only exports RD results only;
both exports both. Summary metrics are zero (not absent) for inactive RA types.

**What it delivers:**
- Export combined summary after the MILP solves:
  - `sum_rd_volume_upward_mw`, `sum_rd_volume_downward_mw` (MW; 0.0 if RD inactive)
  - `sum_rd_cost_eur`, `sum_rd_penalty_cost_eur` (EUR; 0.0 if RD inactive)
  - `sum_pst_penalty_cost_eur` (EUR; 0.0 if PST inactive)
  - `objective_value`
  - `remaining_overload_count`
- Export generating unit results (BUC14#137 subset):
  per unit: `initial_production_mw`, `rd_volume_net_mw`, `result_production_mw`,
  `rd_cost_eur`, `rd_penalty_cost_eur`

**Outputs:**
- `results_summary.csv`: columns `[metric, value]`
- `results_generating_units.csv`: columns `[gu_mrid, gu_name, tso,
  initial_production_mw, rd_volume_net_mw, result_production_mw,
  rd_cost_eur, rd_penalty_cost_eur]`

**Acceptance criteria:**
- Given the MILP has solved optimally with at least one RD unit activated,
- When results are exported,
- Then `|sum_rd_volume_upward_mw − sum_rd_volume_downward_mw| < 0.01 MW`
  (balancing satisfied in reported totals).
- Given PST-only workflow,
- When results are exported,
- Then `sum_rd_volume_upward_mw == 0.0` and `sum_rd_volume_downward_mw == 0.0`.

---

## R2.12 — Scanned element MILP constraints (CORNET-439)

**Spec ref:** CORNET-439 — Scanned Elements

**Composability note:** Scanned element constraints reference the **same**
`pst_effect_on_branch` / `rd_effect_on_branch` Expressions built once in R2.4 — see
the "Architecture note: unified branch candidate set" section above. No separate
Expression-building logic exists for scanned branches; this increment only adds a
constraint-building loop filtered to the `AEType.SCANNED` subset of `branch_ids`,
plus the effective-limit lookup and hard/soft branching.

**What it delivers:**
- For each scanned element in the `AEType.SCANNED` subset of `branch_ids` (from
  `ScannedElementList`, R0.9), add a loading constraint using the effective limit:
  - Hard (default, `scanned_element_constraint_hard=True`):
    ```python
    def scanned_element_loading_rule(m, branch_mrid):
        pst_term = m.pst_effect_on_branch[branch_mrid] \
                   if hasattr(m, 'pst_effect_on_branch') else 0.0
        rd_term  = m.rd_effect_on_branch[branch_mrid] \
                   if hasattr(m, 'rd_effect_on_branch') else 0.0
        return (lf_initial[branch_mrid] + pst_term + rd_term
                <= effective_limit[branch_mrid])
    ```
  - Soft (`scanned_element_constraint_hard=False`): same expression with
    `+ scanned_overload_slack[branch_mrid]` added to the right-hand side, penalised
    by `scanned_element_penalty_eur_per_ka` in the objective
- All currents and limits are side-aware (same `current_limit_side_map` used
  throughout R2)
- No additional sensitivity pruning step needed here — pruning already happened in
  R2.2 against the combined candidate set, which included scanned branches from the
  start (see "Architecture note")

**Inputs:**
- `ScannedElementList` (from R0.9) — determines which `branch_mrid`s in `branch_ids`
  are `AEType.SCANNED`
- `model.pst_effect_on_branch`, `model.rd_effect_on_branch` (built in R2.4 — reused,
  not rebuilt)
- RAO control parameters: `scanned_element_constraint_hard: bool`,
  `scanned_element_penalty_eur_per_ka: float`

**Outputs:**
- Updated `milp_model` with scanned element constraints
- `results_scanned_elements.csv` — **no longer produced**: the writer and extractor were dead code (never called, not in `output_file_registry.py`) and were removed in the clean-up pass; the scanned N-X file is `results_nx_scanned_elements.csv`. Original planned columns `[branch_mrid, branch_name, tso, side,
  effective_limit_ka, loading_before_rao_ka, loading_after_rao_ka,
  slack_ka, constraint_type]`

**Acceptance criteria:**
- Given a scanned element with `effective_limit_ka = 1.1` and initial loading of
  `0.9 ka` modelled as a hard constraint,
- When the MILP is solved,
- Then the post-optimisation linearised loading does not exceed `1.1 ka`.
- Given PST-only workflow (`rd_inputs=None`),
- When scanned element constraints are built,
- Then only `pst_effect_on_branch` appears in the constraint (no RD terms) — verified
  via the same `hasattr` pattern used in R2.5, not a separate code path.
- Given a scanned branch and a secured branch both pass `min_loading_threshold_pct`,
- When `sensitivity_pst_n0` / `sensitivity_rd_n0` are inspected (from R2.1),
- Then both branches have sensitivity entries computed via the same code path — no
  branch is silently missing sensitivity data due to its AE type.
