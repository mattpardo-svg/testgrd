> Original plan. Current status per row: see `Spec_Coverage.md` (section 3). Where this file and that one differ, `Spec_Coverage.md` is right.

# R6 — HVDC, Countertrade, and System Constraints

**Goal:** Complete the set of RA types and network constraint types in scope for the
prototype. Adds HVDC (modelled as equivalent injections with balanced group constraint),
countertrade (with all three GLSK strategies), and system constraints
(active power and current limits on corridor aggregates).

**Prerequisite:** R5 complete — full generator physics layer working.

**Stack:** Same as R5. No new solver dependencies.

---

## Deferred items (R6 scope)

| Item | Reason deferred |
|------|----------------|
| Topological RAs (BUC14#84/85/105/146) | Deferred entirely from prototype scope |
| CORNET-2586 — RTE-specific TATL handling | Deferred (standard TATL only) |
| Multi-terminal HVDC | Spec formulation TBD for 3+ terminals; two-terminal HVDC PRA and CRA implemented in R6.1–R6.4 |

---

## R6.1 — HVDC equivalent injection parsing (BUC14#55)

**Spec ref:** BUC14#55 — RAO considers HVDC PRAs modelled as Equivalent Injections

**What it delivers:**
- Identify HVDC equivalent injections in the CGM:
  `EquivalentInjection` objects where the connected `Terminal.description` or
  `ConnectivityNode.description` starts with `"HVDC"`
- For each HVDC converter: extract `maxP` (maximumSetpoint), `minP` (minimumSetpoint)
  — `minP` may be negative (power flow reversal)
- Extract the operating setpoint range from `GridStateAlteration.RangeConstraint`:
  absolute (`absolute`) or relative (`incremental`) from current setpoint,
  per direction (`up`, `down`)
- Convert from load sign convention (CGMES default) to generation sign convention
  (RAO internal): flip sign of `P` and `minP`/`maxP`
- Resolve RA group membership: HVDC converter pairs linked by a `balanced`
  `RemedialActionGroup` (one RA per converter, both in same group)
- Build `HVDCList: list[HVDCConverter]` with paired converter references

**Inputs:**
- CGM EquipmentProfile (`EquivalentInjection` — `maxP`, `minP`, description)
- IAM files (RA profile — `GridStateAlteration` with `equivalentInjectionAction`,
  `RemedialActionGroup` with `balanced` dependency)

**Outputs:**
- `HVDCList: list[HVDCConverter]` (in-memory)
- `hvdc_list.csv`: columns `[converter_mrid, converter_name, tso, partner_converter_mrid, ra_group_mrid, min_setpoint_mw, max_setpoint_mw, initial_p_mw, available]`

**Acceptance criteria:**
- Given an HVDC connection represented by two `EquivalentInjection` objects in the same `balanced` RA group,
- When `HVDCList` is built,
- Then both converters appear as a linked pair with `min_setpoint_mw ≤ initial_p_mw ≤ max_setpoint_mw` AND the sign convention is generation (positive = injection into AC grid).

---

## R6.2 — HVDC sensitivity computation

**Spec ref:** Custom increment — HVDC treated as generating units for sensitivity purposes (BUC14#55 §description)

**What it delivers:**
- Treat each HVDC converter as a generating unit for sensitivity computation:
  call VeraGridEngine sensitivity API for each converter's `EquivalentInjection` node
- Compute `dI_b / dP_HVDC` (A per MW setpoint change) for N-0 and for each N-X contingency
  (same API calls as R3.1 and R4.1, with converter node as the injection point)
- Store in `S_HVDC[t]: dict[(branch_id, converter_mrid), float]`
  and `S_HVDC_NX[t][c]: dict[(branch_id, converter_mrid), float]`

**Inputs:**
- `HVDCList`, `network`, `lf_initial[t]`, `AEFlatList`
- `SENSITIVITY_THRESHOLD_PCT`

**Outputs:**
- `S_HVDC[t]`, `S_HVDC_NX[t][c]` (in-memory)
- `sensitivity_hvdc_n0.csv`: columns `[timestamp, branch_id, converter_mrid, di_dp_a_per_mw]`

**Acceptance criteria:**
- Given an HVDC converter with non-zero sensitivity on at least one monitored branch,
- When `S_HVDC` is computed,
- Then the converter appears in at least one `(branch_id, converter_mrid)` pair with a non-zero value.

---

## R6.3 — HVDC MILP variables and balanced group constraint (BUC14#55, §3.6.11 eq. 3.61)

**Spec ref:** BUC14#55 — HVDC variables and balanced constraint; BUC14#109 — HVDC costs

**What it delivers:**
- Add HVDC setpoint change variables per timestamp:
  `dP_HVDC_pos[t, converter_mrid]` ≥ 0 — positive setpoint change (MW)
  `dP_HVDC_neg[t, converter_mrid]` ≥ 0 — negative setpoint change (MW)
  bounded by operating range from `RangeConstraint` (absolute or relative)
- Technical setpoint bounds: `minP ≤ P_0 + dP_HVDC_pos − dP_HVDC_neg ≤ maxP`
- Balanced group constraint per timestamp (eq. 3.61):
  `(dP_HVDC_pos[t,g1] − dP_HVDC_neg[t,g1]) − (dP_HVDC_pos[t,g2] − dP_HVDC_neg[t,g2]) = 0`
  (net setpoint change at converter 1 equals net setpoint change at converter 2)
- Include HVDC terms in N-0 and N-X loading constraints (same structure as RD in R3.5/R4.2)
- Add HVDC penalty costs to objective (BUC14#109):
  `c_HVDC_τ = penaltyFactor_τ · penaltyReferenceHVDC` (RAO control parameter)

**Inputs:**
- `HVDCList`, `S_HVDC[t]`, `S_HVDC_NX[t][c]`
- RAO control parameters: `penaltyReferenceHVDC` (EUR/MW), optional TSO-specific override

**Outputs:**
- Updated `milp_model` with HVDC variables, balanced constraint, loading constraint terms
- `results_hvdc.csv`: columns `[converter_mrid, converter_name, tso, timestamp, initial_p_mw, delta_p_mw, result_p_mw, penalty_cost_eur]`

**Acceptance criteria:**
- Given an HVDC converter pair in a balanced group,
- When the MILP is solved,
- Then `|net_dP(t, g1) − net_dP(t, g2)| < 0.01 MW` for every timestamp AND setpoints stay within `[minP, maxP]`.

---

## R6.4 — HVDC curative remedial actions (BUC14#55 CRA extension)

**Spec ref:** BUC14#55 — HVDC PRAs modelled as Equivalent Injections (CRA extension)

**What it delivers:**
- Extend HVDC from PRA-only (R6.1–R6.3) to also support curative mode:
  parse curative HVDC RA entries from the IAM RA profile (`kind == curative`),
  linked contingencies and optional linked XNEs (same structure as PST/RD CRAs in R4.5/R4.6)
- Add per-contingency HVDC curative setpoint change variables:
  `dP_HVDC_cur_pos[t, converter_mrid, c]` ≥ 0
  `dP_HVDC_cur_neg[t, converter_mrid, c]` ≥ 0
- Balanced group constraint applied per contingency:
  `(net_dP_cur(t,g1,c)) − (net_dP_cur(t,g2,c)) = 0` for each contingency `c`
- Combined setpoint bounds (PRA + CRA) per contingency:
  `minP ≤ P_0 + net_dP_PRA(t) + net_dP_cur(t,c) ≤ maxP`
- Include HVDC curative terms in N-X loading constraints (after R4.2/R4.7):
  `I_b,0^c(t) + Σ S_HVDC_NX[b,conv,c,t] · (dP_HVDC(t) + dP_HVDC_cur(t,c)) + ... ≤ PATL_b + slack`
- Curative objective cost: same penalty structure as preventive (BUC14#109),
  maximum over contingencies approach consistent with RD CRA (SF3077 eq. 3.40–3.44)
- CRA linkage: respect `linkedContingencies` and `linkedElements` from RA profile;
  `activateLinkCRA_XNE` control parameter applies (same as R4.5)

**Inputs:**
- `HVDCList` (extended with curative entries), `S_HVDC_NX[t][c]` (from R6.2)
- IAM RA profile (curative HVDC entries, linked contingencies/elements)
- RAO control parameters: `penaltyReferenceHVDC`, `activateLinkCRA_XNE`

**Outputs:**
- Updated `milp_model` with curative HVDC variables and N-X constraints
- Extended `results_hvdc.csv` with additional columns `[contingency_mrid, delta_p_mw_curative, result_p_mw_curative]`

**Acceptance criteria:**
- Given a curative HVDC RA linked to contingency CO1 only,
- When the MILP is solved and CO1 causes an overload,
- Then the curative HVDC setpoint change appears only in the CO1 N-X loading constraint AND `|net_dP_PRA(t,g1) + net_dP_cur(t,g1,CO1) − net_dP_PRA(t,g2) − net_dP_cur(t,g2,CO1)| < 0.01 MW` (balanced group holds in curative mode too).

---

## R6.5 — Countertrade parsing and GLSK strategies (CORNET-4847, CORNET-4848)

**Spec ref:** CORNET-4847 — Consideration of Countertrade; CORNET-4848 — GLSK strategies for CT

**What it delivers:**
- Parse `CountertradeRemedialAction` objects from the IAM RA profile
- For each CT RA: extract `mRID`, `name`, `systemOperatorCode`, `available`, `kind`,
  linked `GLSKSchedule`, `gLSKStrategy` (`explicitInstruction`, `proportionalForGenerator`,
  `proportionalForRemainingCapacity`)
- Implement all three GLSK strategies per timestamp:
  - `explicitInstruction`: use fixed `participationFactor` from GLSK (same as RD, R3.3)
  - `proportionalForGenerator`: `PF_g = actPROD_g / Σ_{g ∈ BZ} actPROD_g`
    where `actPROD_g = initialP_g + ΔP_PRA_g` (actual production including PRAs)
  - `proportionalForRemainingCapacity`: `PF_g = (Pmax_g − actPROD_g) / Σ (Pmax_g − actPROD_g)`
- General CT assumptions (per spec §CORNET-4848):
  - CT cannot start a unit from off (`actPROD == 0` → unit excluded from CT GLSK)
  - CT cannot shut a unit down
  - Only generating units linked by a single GLSK are considered
- Build `CT_GLSK: dict[ct_ra_mrid, dict[t, dict[gu_mrid, float]]]`

**Inputs:**
- IAM files (RA profile — CountertradeRemedialAction, GLSKSchedule)
- Current RA solution for `actPROD` (needed for dynamic GLSK strategies)
- CGM `initialP`, `maxP` per unit

**Outputs:**
- `CTList: list[CTUnit]` (in-memory)
- `CT_GLSK` (in-memory)
- `ct_glsk_resolved.csv`: columns `[ct_ra_mrid, timestamp, gu_mrid, glsk_strategy, participation_factor]`

**Acceptance criteria:**
- Given a CT RA with `proportionalForGenerator` strategy and three generating units with
  `actPROD = [100, 200, 300]` MW,
- When `CT_GLSK` is built,
- Then participation factors are `[100/600, 200/600, 300/600]` = `[0.167, 0.333, 0.500]` (±0.001).

---

## R6.6 — Countertrade MILP variables and constraints

**Spec ref:** CORNET-4847 — CT in MILP; CORNET-73 — Balancing extended to CT

**What it delivers:**
- Add CT bid variables per timestamp (same structure as RD in R3.4):
  `dP_CT_pos[t, ct_bid_mrid]` ≥ 0, `dP_CT_neg[t, ct_bid_mrid]` ≥ 0
  bounded by available CT volume from `PowerBidSchedule`
- Extend the balancing constraint (CORNET-73) to include CT:
  `Σ_g (ΔP_RD_g(t) + ΔP_CT_g(t)) = 0`
- Include CT in N-0 loading constraints (same sensitivity as RD units — both affect
  generating unit injections, so `dI_b/dP_g` applies)
- CT objective cost: penalty and price terms (same structure as CORNET-4606 for RD)
  with `penaltyReferenceCT_PRA` RAO control parameter
- Apply CORNET-4838 group volume limits to CT bids in `restrictive` RA groups
  (same constraint structure as R3.9, extended to CT variables)

**Inputs:**
- `CTList`, `CT_GLSK`, `S_RD[t]` (CT units share the RD sensitivity — same injection nodes)
- `PowerBidList` (CT bid volumes, prices, penalty factors)
- RAO control parameters: `penaltyReferenceCT_PRA`, optional TSO-specific override

**Outputs:**
- Updated `milp_model` with CT variables and constraints
- `results_ct.csv`: columns `[ct_ra_mrid, bid_mrid, tso, timestamp, delta_p_mw, ct_cost_eur, penalty_cost_eur]`

**Acceptance criteria:**
- Given a CT RA and an RD RA both activated at the same timestamp,
- When results are exported,
- Then `|Σ_g (ΔP_RD_g + ΔP_CT_g)| < 0.01 MW` (combined balancing holds).

---

## R6.7 — CT technical limits for generating units (CORNET-4849)

**Spec ref:** CORNET-4849 — Consideration of technical limits of generating units of CT RAs

**What it delivers:**
- For each generating unit `g` linked to a CT RA via its GLSK, enforce Pmax/Pmin bounds
  on the combined RD+CT adjustment (same structure as CORNET-4614 for PRA+CRA):
  ```
  Pmin_g ≤ P_prod(g,t) + ΔP_RD(g,t) + ΔP_CT(g,t) ≤ Pmax_g
  ```
  where `ΔP_CT(g,t) = Σ_{ct_ra} PF_CT(g,ct_ra,t) · (dP_CT_pos[t,ct_ra] − dP_CT_neg[t,ct_ra])`
- Apply prototype simplification: enforce the combined bound as a hard constraint
  (the spec's full adaptive GLSK recalculation when units hit limits is not implemented —
  instead the optimiser will naturally respect the bound and adjust CT volume accordingly)
- Log any timestamp where a CT unit's combined dispatch hits Pmax or Pmin
  (this signals that the GLSK participation factors would need rebalancing in a full implementation)

**Inputs:**
- `CTList`, `CT_GLSK`, `RDList` (for combined RD+CT adjustment per unit)
- CGM generating unit `maxP`, `minP`, `initialP`
- `milp_model`

**Outputs:**
- Updated `milp_model` with CT Pmax/Pmin constraints per generating unit per timestamp
- `results_ct_technical_limits.csv`: columns `[gu_mrid, gu_name, tso, timestamp, initial_p_mw, rd_delta_mw, ct_delta_mw, combined_result_mw, pmax_mw, pmin_mw, limit_hit]`

**Acceptance criteria:**
- Given a generating unit with `Pmax = 400 MW` and `initialP = 350 MW` linked to both an RD PRA and a CT RA,
- When the MILP is solved and both are activated simultaneously,
- Then `initialP + ΔP_RD + ΔP_CT ≤ 400 MW` for that unit at every timestamp.

---

## R6.8 — System constraints — active power limits (CORNET-498)

**Spec ref:** CORNET-498 — System Constraints with active power limits

**What it delivers:**
- Parse `PowerTransferCorridors` from the ER-Profile:
  each corridor has one `OperationalLimitSet` linked to one `ACDCTerminal`,
  with upper and/or lower `InfeedLimit` (active power, `normalValueW`)
- Passive management logic per constraint `k`:
  ```
  P_max_eff = max(P_max_defined, P_before_RAO_k)
  P_min_eff = min(P_min_defined, P_before_RAO_k)
  ```
  where `P_before_RAO_k = Σ_{NE in corridor} P_NE(t)` from the initial LF
- Add hard constraint (default) or soft constraint (if `systemConstraint_Soft == True`):
  `P_min_eff ≤ Σ_{NE in corridor} P_NE_post_RAO(t) ≤ P_max_eff`
  Soft version adds `slack_SC[t, k] ≥ 0` penalised by `systemConstraint_penalty`
- N-0 only for this increment; N-X corridor constraints are added in R4.7
  (note: R4.7 references the parsing done here — implement R6.8 first, then R4.7 adds the N-X loop)
- Skip any `PowerTransferCorridors` with more than one `OperationalLimitSet` per side
  (log and skip per spec business rule)
- Apply TSO-specific `systemConstraint_penalty` if defined (CORNET-3650)

**Inputs:**
- CGM ER-Profile (`PowerTransferCorridors`, `OperationalLimitSet`, `InfeedLimit`)
- `lf_initial[t]` (for `P_before_RAO`)
- RAO control parameters: `systemConstraint_Soft`, `systemConstraint_penalty`,
  optional TSO-specific `systemConstraint_penalty`

**Outputs:**
- Updated `milp_model` with system constraint terms
- `results_system_constraints.csv`: columns `[corridor_mrid, corridor_name, tso, timestamp, p_before_rao_mw, p_after_rao_mw, p_min_eff_mw, p_max_eff_mw, slack_mw]`

**Acceptance criteria:**
- Given a corridor with `P_max = 500 MW` and initial flow of `P_before_RAO = 450 MW`,
- When the MILP is solved as a hard constraint,
- Then `Σ P_NE_post_RAO ≤ 500 MW` for that corridor AND if `P_before_RAO > P_max` the effective limit is set to `P_before_RAO` (passive management — flow not worsened).

---

## R6.9 — System constraints — current limits (CORNET-537)

**Spec ref:** CORNET-537 — System Constraints with current limits

**What it delivers:**
- Extend R6.8 to handle current-based system constraints:
  `InfeedLimit` with `normalValueA` instead of `normalValueW`
- Passive management logic (same structure as R6.8 but in amperes):
  ```
  I_max_eff = max(I_max_defined, I_before_RAO_k)
  I_min_eff = min(I_min_defined, I_before_RAO_k)
  ```
- Add constraint: `I_min_eff ≤ Σ_{NE in corridor} I_NE_post_RAO(t) ≤ I_max_eff`
- Distinguish between active power and current corridors by checking whether
  `OperationalLimitSet` links to `normalValueW` (MW) or `normalValueA` (A)
- If a corridor has mismatched limit types (one side MW, other side A), skip and log

**Inputs:**
- Same as R6.8 — same ER-Profile parsing, extended to detect current limits

**Outputs:**
- Extended `results_system_constraints.csv` with `limit_type` column (`MW` or `A`)

**Acceptance criteria:**
- Given a corridor with a current-based upper limit of `1000 A` and initial current of `900 A`,
- When the MILP is solved as a hard constraint,
- Then `Σ I_NE_post_RAO ≤ 1000 A` for that corridor.

---

## R6.10 — Final consolidated results export

**Spec ref:** BUC14#132 (extended), BUC14#137, BUC14#138 (prototype subset)

**What it delivers:**
- Produce the final consolidated results bundle after all R6 additions:

  **Summary (BUC14#132 prototype):**
  - `sumRDVolumePos/Neg`, `sumCTVolumePos/Neg` (MW)
  - `sumRDCost`, `sumCTCost`, `sumRDPenaltyCost`, `sumCTCost` (EUR)
  - `sumPSTPenaltyCost`, `sumHVDCPenaltyCost` (EUR)
  - `sumPATLPenaltyCost`, `sumTATLPenaltyCost` (EUR from N-X slack)
  - `sumSCPenaltyCost` (system constraint slack, EUR)
  - `objectiveValue`

  **Net positions and TSO exchange (BUC14#138 prototype subset):**
  - Per TSO per timestamp: `net_position_mw = Σ_g (ΔP_RD_g + ΔP_CT_g)` for generating
    units in that TSO's control area
  - Cross-border exchange change per TSO pair: derived from line flows delta

**Inputs:**
- All MILP results from R6.1–R6.9

**Outputs:**
- `results_summary_final.csv`: columns `[metric, value]` (extended from R3.11)
- `results_net_positions.csv`: columns `[tso, timestamp, net_position_mw_delta]`
- `results_tso_exchange.csv`: columns `[tso_from, tso_to, timestamp, exchange_delta_mw]`

**Acceptance criteria:**
- Given CT and RD activations in the final solution,
- When the consolidated summary is exported,
- Then `sumCTVolumePos + sumCTVolumeNeg > 0` if at least one CT RA was activated AND `|sumRDVolumePos − sumRDVolumeNeg + sumCTVolumePos − sumCTVolumeNeg| < 0.01 MW` (combined balancing in reported totals).
