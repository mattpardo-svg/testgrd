> Original plan. Current status per row: see `Spec_Coverage.md` (section 3). Where this file and that one differ, `Spec_Coverage.md` is right.

# R0 — Data Ingestion

**Goal:** Load the ReliCapGrid CGMES v3.0 network and parse the per-TSO NCP XML files into
internal Python data structures. No optimisation. No solver. Establishes the data layer
that every subsequent release depends on.

**Prototype time model (established here):**
```python
START_HOUR    = "1030Z"   # anchor timestamp for PATL time-series selection, configurable
N_TIMESTAMPS  = 4         # number of consecutive hourly timestamps, configurable
```
Timestamps selected: `[START_HOUR, START_HOUR+1h, ..., START_HOUR+(N-1)h]`

**Stack:** pypowsybl 1.15.0 (CGM load + AC LF + sensitivity), rdflib/ElementTree (NCP XML parse + TSO resolution + PST detection), Python dataclasses

**CGM package:** `data/CGM_package.zip` — 27 files built by the official ReliCapGrid build script
(`data/relicapgrid/buildScripts/create_cgm_zip.py`). Contains: EQ per TSO, Jotunheim merged
SSH_2 per TSO, single Jotunheim TP, single Jotunheim SV, boundary files, CommonData Grid files.
Committed to repo on branch `cgmes-3.0_ncp-2.5_tc-2.0`.

**NCP package:** `data/NCP_package.zip` — 39 files built manually from per-TSO
`NetworkCode/cimxml/` directories + `commonData/NetworkCode/`. Committed to repo.

**Known dataset facts (established during investigation):**
- pypowsybl load result: 275 buses, 311 lines, 85 2W transformers, 14 PSTs, 4 HVDC lines, LF CONVERGED
- Portheim is silently excluded by pypowsybl during merge (boundary substation with few nodes — acceptable, already out of scope)
- `CGMES.regionName` attribute is empty for all substations when loaded with `cgm-with-subnetworks=false` — TSO resolution must use rdflib on EQ files directly
- Required pypowsybl workaround: `iidm.import.cgmes.cgm-with-subnetworks=false` (bug: multiple boundary files share same `modelingAuthoritySet` URI; bug report filed on pypowsybl GitHub)

---

## Deferred items (R0 scope)

| Item | Reason deferred |
|------|----------------|
| CORNET-4841/4842/4844/4845/4846 — CoMo LF result profiles | CoMo format out of scope; LF results captured in CSV instead |
| BUC14#83 — Runtime progress estimation | Production infrastructure concern, not relevant to prototype |
| BUC14#130 — HPC Manager job submission | Production infrastructure concern |
| CORNET-4841 — Change to CoMo LF Result Profile | CoMo format out of scope |

---

## R0.1 — CGM load and base-case AC load flow (CORNET-97)

**Spec ref:** CORNET-97 (Load flow computations on a grid model)

**What it delivers:**
- Load `data/CGM_package.zip` via pypowsybl using the required workaround parameter:
  ```python
  import pypowsybl as pp
  network = pp.network.load(
      'data/CGM_package.zip',
      parameters={
          'iidm.import.cgmes.source-for-iidm-id': 'mRID',
          'iidm.import.cgmes.cgm-with-subnetworks': 'false'
      }
  )
  ```
- Run the base-case AC load flow (N-0) via pypowsybl:
  ```python
  results = pp.loadflow.run_ac(network)
  ```
- Confirm convergence of the main component (`results[0].status == 'CONVERGED'`)
- Capture network statistics: bus count, line count, 2W transformer count, PST count, HVDC count
- Export base-case branch loadings to `lf_basecase.csv`
- Note: Portheim is silently excluded during merge — log at INFO level, do not treat as error

**Inputs:**
- `data/CGM_package.zip` (27-file CGM package committed to repo)
- pypowsybl 1.15.0 (`pip install pypowsybl`)

**Outputs:**
- `network` object (pypowsybl `Network`, held in memory, used by all subsequent releases)
- `lf_results` (pypowsybl load flow result object, held in memory)
- `lf_basecase.csv`: columns `[branch_id, branch_name, i_ka, loading_pct, patl_ka, converged]`
- Console summary: bus count, line count, 2W transformer count, PST count, HVDC count, converged flag

**Acceptance criteria:**
- Given `data/CGM_package.zip` is loaded via pypowsybl with `cgm-with-subnetworks=false`,
- When the AC load flow is executed,
- Then `results[0].status == 'CONVERGED'` AND the network contains 275 buses, 311 lines,
  85 2W transformers, 14 PSTs, 4 HVDC lines (matching confirmed investigation results) AND
  `lf_basecase.csv` contains one row per monitored branch with `loading_pct >= 0`.

---

## R0.2 — TSO name resolution via EQ file SubGeographicalRegion (§3.2.1)

**Spec ref:** §3.2.1 — Definition of the TSO names / Consideration of the TSO names by the country code

**What it delivers:**
- Parse each TSO's EQ file from the CGM package via rdflib to resolve TSO identity:
  follow `Substation → SubGeographicalRegion → name` to extract the TSO name
  for each substation mRID
- Build `substation_mrid_to_tso: dict[str, str]` mapping each substation mRID to its TSO name
  (e.g. `{"_substation-BE-001": "Belgovia", ...}`)
- Also build `TSO_NAME_MAP: dict[str, str]` — the set of unique TSO names found
  (used for labelling results by TSO throughout all subsequent releases)
- Note: pypowsybl does not populate `CGMES.regionName`, `TSO`, or `country` attributes on
  substations when loaded with `cgm-with-subnetworks=false`. rdflib parsing of EQ files is
  the only reliable approach for this dataset.
- Note: the spec's EIC to country code table (§3.2.1) does not apply directly to ReliCapGrid —
  TSO identity is resolved from `SubGeographicalRegion.name` in the EQ files. The conceptual
  purpose (unambiguous TSO labelling in all results) is identical.
- Log any substation whose `SubGeographicalRegion` cannot be resolved (set TSO to empty string)

**Inputs:**
- EQ files from `data/CGM_package.zip` (one per TSO, extracted or read from zip)
- CIM namespaces: `https://cim.ucaiug.io/ns#` (equipment), `https://cim4.eu/ns/nc#` (NC extensions)

**Outputs:**
- `substation_mrid_to_tso: dict[str, str]` (in-memory, used for TSO labelling throughout)
- `TSO_NAME_MAP: dict[str, str]` (in-memory, set of unique TSO names)
- Console log: TSO names resolved, substation count per TSO, any unresolved substations

**Acceptance criteria:**
- Given the CGM EQ files are parsed via rdflib,
- When `substation_mrid_to_tso` is built,
- Then all substations in the 7-TSO network (excluding Portheim) resolve to a non-empty TSO name
  AND `TSO_NAME_MAP` contains exactly the TSO names present in the EQ files AND any substation
  with no `SubGeographicalRegion` entry produces an empty string (not an exception).

---

## R0.3 — NCP file discovery and TSO inventory (CORNET-85)

**Spec ref:** CORNET-85 — Considered time grid

**What it delivers:**
- Scan the NCP dataset directory for per-TSO NCP XML files following the naming convention:
  `{TSO}_RA.xml`, `{TSO}_AE.xml`, `{TSO}_CO.xml`, `{TSO}_SHS.xml`, `{TSO}_SIS.xml`
- Build a `NCP_FILES: dict[tso, dict[profile, Path]]` registry mapping each TSO name
  to the paths of its profile files, e.g.:
  ```python
  NCP_FILES = {
      "TSO-Belgovia": {
          "RA":  Path(".../TSO-Belgovia_RA.xml"),
          "AE":  Path(".../TSO-Belgovia_AE.xml"),
          "CO":  Path(".../TSO-Belgovia_CO.xml"),
          "SHS": Path(".../TSO-Belgovia_SHS.xml"),
          "SIS": Path(".../TSO-Belgovia_SIS.xml"),
      },
      ...
  }
  ```
- Validate that required profiles exist for each TSO:
  `AE`, `CO`, `RA` are required — raise a clear error if any are missing
  `SHS`, `SIS` are optional — log a warning if absent but continue
  TSOs with no `NetworkCode/cimxml/` directory are logged at INFO and excluded from `NCP_FILES` (they participate in the CGM only)
- Load `START_HOUR` and `N_TIMESTAMPS` as top-level config constants;
  these govern which `atTime` values are extracted from `SHS` files in R0.4 onwards
- Build `TIMESTAMP_LIST: list[str]` — the ordered list of `N_TIMESTAMPS` consecutive
  hourly `atTime` strings starting from `START_HOUR`
  (e.g. `["1030Z", "1130Z", "1230Z", "1330Z"]` for `START_HOUR="1030Z"`, `N_TIMESTAMPS=4`)

**Inputs:**
- NCP dataset root directory path (or `data/NCP_package.zip`)
- `START_HOUR: str` (e.g. `"1030Z"`)
- `N_TIMESTAMPS: int` (e.g. `4`)

**Outputs:**
- `NCP_FILES: dict[tso, dict[profile, Path]]` (in-memory, used by all R0.4-R0.9 increments)
- `TIMESTAMP_LIST: list[str]` (in-memory, used by all subsequent releases)
- Console log: TSOs found, profile files resolved, any missing optional profiles

**Acceptance criteria:**
- Given the NCP dataset directory is scanned and the CGM contains 7 TSOs of which 4 have a `NetworkCode/cimxml/` directory,
- When `NCP_FILES` is built,
- Then it contains exactly 4 TSO keys (Belgovia, Espheim, Galia, Svedala — TSOs with no `NetworkCode/cimxml/` directory are excluded and logged) AND each key maps to at least the 3 required profiles (`AE`, `CO`, `RA`) AND `TIMESTAMP_LIST` has exactly `N_TIMESTAMPS` entries starting from `START_HOUR`.

---

## R0.4 — Assessed element (XNE) parsing with exclusion logic (CORNET-336, SF927)

**Spec ref:** CORNET-336 — Data model: XNEs; SF927 — Excluded XNEs in RAO

**What it delivers:**
- Parse each `{TSO}_AE.xml` file from `NCP_FILES` via rdflib
- For each assessed element: extract `mRID`, `name`, `assessedSystemOperatorCode`,
  `securedForRegionCode`, `scannedForRegionCode`, `exclusionReason`
- Resolve PATL per branch per timestamp from each `{TSO}_SHS.xml` file:
  parse `CurrentLimitTimePoint.value` (A) at `atTime` for each branch `mRID` and
  build `patl: dict[branch_mrid, dict[timestamp, float]]` — one entry per (branch, timestamp)
  for all timestamps in `TIMESTAMP_LIST`
  - Fallback: if no `SHS` entry exists for a branch at a given timestamp, use the static
    current limit from the pypowsybl network object via `network.get_operational_limits()`
    filtered to the relevant branch mRID and `CURRENT` limit type
  - Log any branch where the SHS-derived PATL differs significantly (> 10%) from the pypowsybl static value
- Apply SF927 exclusion logic per spec business rules:
  - AE with `securedForRegionCode` set and no `exclusionReason` → **secured** (included in MILP as XNE)
  - AE with `exclusionReason` set and `scannedForRegionCode` set → **scanned only** (monitored but not secured; MILP constraint added in R3.12)
  - AE with `exclusionReason` set and no `scannedForRegionCode` → **fully excluded** (absent from all MILP constraints; present in SA only)
  - If `exclusionReason` has an invalid value → log fatal error and cancel
- Build `AEFlatList: list[AssessedElement]` dataclass with `ae_type` field
  (`secured` / `scanned` / `excluded`) and per-timestamp `patl_ka` from SHS
- Log and skip any AE whose linked branch `mRID` cannot be found in the pypowsybl network

**Inputs:**
- `{TSO}_AE.xml` files (from `NCP_FILES`)
- `{TSO}_SHS.xml` files (from `NCP_FILES` — `CurrentLimitTimePoint.value` + `atTime`)
- `network` (pypowsybl `Network` from R0.1 — `network.get_operational_limits()` as PATL fallback)
- `TSO_NAME_MAP` (from R0.2), `TIMESTAMP_LIST` (from R0.3)

**Outputs:**
- `AEFlatList: list[AssessedElement]` (in-memory)
- `patl: dict[branch_mrid, dict[timestamp, float]]` (in-memory, used by MILP construction)
- `ae_flat_list.csv`: columns `[mrid, name, tso, patl_ka, ae_type, secured_region, scanned_region, exclusion_reason, timestamp]`

**Acceptance criteria:**
- Given a `{TSO}_SHS.xml` file containing `CurrentLimitTimePoint` entries for a branch at timestamps `1030Z` and `1130Z`,
- When `patl` is built for `TIMESTAMP_LIST = ["1030Z", "1130Z", "1230Z", "1330Z"]`,
- Then `patl[branch_mrid]["1030Z"]` and `patl[branch_mrid]["1130Z"]` use SHS values AND
  `patl[branch_mrid]["1230Z"]` and `patl[branch_mrid]["1330Z"]` fall back to the pypowsybl
  operational limit value AND all three AE types (secured / scanned / excluded) are correctly
  classified in `ae_flat_list.csv`.

---

## R0.5 — Contingency parsing (CORNET-3693)

**Spec ref:** CORNET-3693 — Data model: Contingencies

**Scope correction — supported equipment types widened, confirmed against spec
text directly, superseding the original `line`/`transformer`-only scope.** The
spec's own Business Rules for the `ContingencyFlatList` data model state
explicitly: *"The RAO can only consider contingency types as defined in
Description. These contingencies must have a CoMo EquipmentType from the
following list: line, switch, transformer, gen, load, shuntCompensator,
staticVarCompensator, busbar, bus."* The original prototype scope
(`line`/`transformer` only) was narrower than the spec's actual scope, not a
deliberate boundary — confirmed via a live-data investigation that found a real
contingency (Belgovia CO3) tripping a generator (`cim:SynchronousMachine`
`BO-G2`), silently excluded and misleadingly logged as "not found in CGM" when
the equipment genuinely exists, just outside the prior validation scope. See
R3.1's own scope note below for the corresponding N-X application-side
extension this requires.

**⚠ Second, independent gap found during this investigation — `Contingency.contingencyType`
has three valid values in the spec, not two.** The spec's own
`ContingencyFlatList` data model defines `CO type` with three enumerated
values: *"ordinary, exceptional or out of range"* (`Contingency.contingencyType`:
`ordinary` / `exceptional` / `outofRange`). `parse_contingencies` originally
only scanned for `nc:OrdinaryContingency`/`nc:ExceptionalContingency` — a real
contingency of RDF type `nc:OutOfRangeContingency` was structurally invisible
to the parser, independent of anything to do with equipment types. Confirmed
via a real dataset instance: Svedala CO `e8e8300b`, `normalMustStudy=true`,
tripping two `BusbarSection` objects. **Fixed by extending `parse_contingencies`
to also scan for `nc:OutOfRangeContingency`, mapping to `contingency_type ==
'outofRange'`.**

**Dataset quirk, confirmed and recorded rather than silently resolved:** CO
`e8e8300b`'s own `IdentifiedObject.description` reads *"This is an example of
an OutOfRange contingency"*, yet `normalMustStudy=true`. Per this project's
established principle of trusting structured CIM fields over inferred intent
from free-text description (the same principle already applied to BO-TR2_1/
BO-TR2_2's non-grouping), this contingency is treated as genuine must-study
data — `normalMustStudy` is a machine-readable control field; the description
is documentation prose no parser in this codebase acts on.

**Confirmed equipment-type inventory across the real dataset (verified by
cross-referencing every contingency's tripped equipment against its actual CIM
type in the EQ files, not assumed):**

| Spec CoMo type | CIM class(es) found | Count | Real examples |
|---|---|---|---|
| `line` | `ACLineSegment` | many | most contingencies |
| `transformer` | `PowerTransformer` | 2 | Svedala CO `e05bbe20`, `5d587c7e` |
| `gen` | `SynchronousMachine` | 4 | Belgovia CO3/`BO-G2`, Espheim `ce19dd34`, Galia `bd7bb012`, Svedala `2c1fe55c` (2 machines) |
| `load` | `NonConformLoad`, `ConformLoad` | 4 | Belgovia `65582e87`, Svedala `92d4f3c9`/`f3a8c241` |
| `shuntCompensator` | `LinearShuntCompensator`, `NonlinearShuntCompensator` | 2 | Espheim `62eac668`, Svedala `ab92defa` |
| `switch` | — | 0 | none found anywhere in the dataset |
| `staticVarCompensator` | — | 0 | none found anywhere in the dataset |
| `busbar`/`bus` | `BusbarSection` | 1 (2 equipment refs) | Svedala `e8e8300b` — see R3.1's scope note for the pypowsybl mapping |
| *(not in spec's 9-type list)* | `CsConverter`, `DCLineSegment`, `VsConverter` | 3 | HVDC contingencies — confirmed genuinely out of the spec's own equipment-type enumeration, not a gap |

`switch` and `staticVarCompensator` get the same "correctly computes empty,
confirmed absent" treatment as GLSK/curative-RD/scanned-elements elsewhere in
this project — zero instances found by scanning every real `{TSO}_CO.xml`
file, not assumed. The three HVDC-typed contingencies are confirmed out of
scope per the spec's own equipment-type list, not an oversight.

**What it delivers:**
- Parse the Contingency profile from each `{TSO}_CO.xml` file via rdflib
- For each contingency: extract `mRID`, `name`, `contingencyType`
  (`OrdinaryContingency` / `ExceptionalContingency` / `OutOfRangeContingency`),
  `mustStudy` flag per timestamp, and list of `ContingencyEquipment` MRIDs with
  `equipmentType`
- Filter to the full spec-confirmed equipment type list: `line`, `switch`,
  `transformer`, `gen`, `load`, `shuntCompensator`, `staticVarCompensator`,
  `busbar`, `bus` — not `line`/`transformer` only
- Validate that each equipment MRID exists in the pypowsybl network, using the
  accessor appropriate to its `equipmentType`:
  - `line` → `network.get_lines().index`
  - `transformer` → `network.get_2_windings_transformers().index`
  - `gen` → `network.get_generators().index`
  - `load` → `network.get_loads().index`
  - `switch` → `network.get_switches().index`
  - `shuntCompensator` → `network.get_shunt_compensators().index`
  - `staticVarCompensator` → `network.get_static_var_compensators().index`
  - `busbar`/`bus` → **unconfirmed pypowsybl accessor** — CGMES `BusbarSection`
    may map to `network.get_busbar_sections()`, or the `bus`/`busbar` distinction
    in the spec's CoMo enumeration may correspond to different CIM concepts
    (`BusbarSection` vs. `ConnectivityNode`/`TopologicalNode`/`network.get_buses()`)
    that don't have a 1:1 pypowsybl mapping. **Verify against the live pypowsybl
    API and real contingency data before implementing** — do not assume the
    mapping the way an earlier implementation step had to correct the GLSK/price CIM class
    assumptions.
- Log and skip any contingency referencing equipment not found in the pypowsybl network
- Build `COFlatList: list[Contingency]` dataclass

**Inputs:**
- `{TSO}_CO.xml` files (from `NCP_FILES`)
- `network` (pypowsybl `Network` from R0.1 — used to validate equipment MRIDs,
  now across seven accessor methods instead of two)

**Outputs:**
- `COFlatList: list[Contingency]` (in-memory)
- `co_flat_list.csv`: columns `[mrid, name, contingency_type, must_study, equipment_mrids, equipment_type, timestamp]`
  — `equipment_type` column added so downstream consumers (R3.1) can dispatch to
  the correct apply/restore logic per contingency without re-deriving it

**Acceptance criteria:**
- Given the `{TSO}_CO.xml` files are parsed,
- When `COFlatList` is built,
- Then every entry with `must_study == True` references at least one equipment MRID that exists
  in the pypowsybl network AND unsupported contingency types are logged and excluded.
- Given a contingency referencing a `gen`-type equipment MRID that exists in
  `network.get_generators()`,
- When `COFlatList` is built,
- Then that contingency is included, not silently excluded with a misleading
  "not found in CGM" message — confirmed against the real Belgovia CO3/`BO-G2` case.

---

## R0.6 — PST remedial action parsing (CORNET-338, CORNET-21)

**Spec ref:** CORNET-338 — Data model: PSTs; CORNET-21 — Group constraints for PST

**What it delivers:**
- Identify PSTs via the NCP `TapPositionAction` CIM class in each `{TSO}_RA.xml` file:
  each `TapPositionAction` references a `TapChanger` mRID — this is the authoritative
  PST identification method for this prototype. Do not use tap angle inspection or
  pypowsybl heuristics (the tap-angle approach only finds 6 of the 14 PSTs when some
  are at zero-degree tap position).
- Cross-reference each `TapChanger` mRID to a pypowsybl transformer ID via
  `network.get_phase_tap_changers().index` (pypowsybl uses mRID as the index when loaded
  with `source-for-iidm-id=mRID`)
- For each PST RA: extract `mRID`, `name`, `systemOperatorCode`, `available` flag,
  `kind` (preventive/curative), `penaltyFactor`
- Extract operating limits per priority rule (§3.6.4 CORNET-2895) from `{TSO}_SIS.xml`:
  online SSI data > offline RA-Profile data > IGM data
  — both absolute (`highStepOperating`, `lowStepOperating`) and
  relative (`highStepRelative`, `lowStepRelative`) variants
- Read current tap position and step range from pypowsybl:
  `network.get_phase_tap_changers()` columns `tap`, `low_tap`, `high_tap`
- Resolve PST group membership via `GridStateAlterationRemedialAction` (CORNET-21):
  two or more `TapPositionAction` objects sharing the same parent `GridStateAlterationRemedialAction`
  in the NCP RA file form a PST group and must be assigned the same `group_id`
- Important dataset note: BO-TR2_1 and BO-TR2_2 (Belgovia) are NOT declared as a CORNET-21
  group in the NCP RA file — they appear as independent RAs. Their physical symmetry
  (opposite-sign equal-magnitude sensitivities on the same branch) is a topology coincidence
  from a shared secondary busbar, not a data-model group. Do not infer group membership
  from sensitivity patterns.
- Build `PSTList: list[PST]` dataclass

**Inputs:**
- `{TSO}_RA.xml` files and `{TSO}_SIS.xml` files (from `NCP_FILES`)
- `network` (pypowsybl `Network` from R0.1 — `network.get_phase_tap_changers()` for tap data)

**Outputs:**
- `PSTList: list[PST]` (in-memory)
- `pst_list.csv`: columns `[mrid, name, tso, available, kind, low_tap, high_tap, current_tap, operating_tap_min, operating_tap_max, group_id, penalty_factor, timestamp]`

**Acceptance criteria:**
- Given the `{TSO}_RA.xml` files are parsed and cross-referenced with pypowsybl,
- When `PSTList` is built,
- Then `PSTList` contains exactly 14 PSTs (matching the confirmed pypowsybl network count)
  AND every PST entry has `low_tap <= current_tap <= high_tap` AND PSTs sharing a
  `GridStateAlterationRemedialAction` in the NCP carry the same non-null `group_id` AND
  BO-TR2_1 and BO-TR2_2 appear as independent entries with no shared `group_id`.

---

## R0.7 — RD remedial action and power bid parsing (CORNET-335)

**Spec ref:** CORNET-335 — Data model: Generating Units

**What it delivers:**
- Parse the RemedialAction profile (`{TSO}_RA.xml`) and SecuritySchedule profile (`{TSO}_SIS.xml`) via rdflib
- For each RD RA: extract `mRID`, `name`, `systemOperatorCode`, `available` flag, `kind`
- For each linked `PowerBidSchedule`: extract per-timestamp `p` (available MW, up and down),
  `price` (EUR/MW), `penaltyFactor`, `leadTime`, `activationCost`,
  `minEnergyBid`, `maxEnergyBid`, `stepSizeCTRD`
- Resolve the linked `GeneratingUnit` from the pypowsybl network via `network.get_generators()`:
  match on generator mRID (index) to retrieve `target_p` (PROD), `max_p` (Pmax), `min_p` (Pmin)
- Read ramp rates from the NCP RA profile (`raiseRampRate`, `lowerRampRate`) — not available
  directly from pypowsybl network attributes for this dataset
- Skip any `PowerBidSchedule` whose linked unit is not found in `network.get_generators()` (log and exclude)
- Build `RDList: list[RDUnit]` and `PowerBidList: list[PowerBid]` dataclasses

**Inputs:**
- `{TSO}_RA.xml` files and `{TSO}_SIS.xml` files (from `NCP_FILES`)
- `network` (pypowsybl `Network` from R0.1 — `network.get_generators()` for unit attributes)

**Outputs:**
- `RDList: list[RDUnit]`, `PowerBidList: list[PowerBid]` (in-memory)
- `rd_list.csv`: columns `[ra_mrid, ra_name, tso, gu_mrid, gu_name, prod_mw, pmax_mw, pmin_mw, timestamp]`
- `power_bid_list.csv`: columns `[bid_mrid, ra_mrid, direction, available_mw, price_eur_mw, penalty_factor, lead_time_h, activation_cost_eur, min_energy_mwh, max_energy_mwh, step_size_mw, timestamp]`

**Acceptance criteria:**
- Given the `{TSO}_RA.xml` and `{TSO}_SIS.xml` files are parsed,
- When `PowerBidList` is built,
- Then every bid entry references a `GeneratingUnit` that exists in `network.get_generators()`
  AND bids whose linked unit is absent from the pypowsybl network are excluded and logged.

---

## R0.8 — Inventory summary and SAR cross-check

**Spec ref:** No direct CORNET item — prototype-specific validation increment

**What it delivers:**
- Print a structured inventory summary after all R0 increments complete:
  nodes, branches, XNEs (by type: secured / scanned / excluded), contingencies (`mustStudy` count),
  PST RAs, RD RAs, power bids — broken down per TSO and per timestamp
- Load `2D_SAR_1030Z_Jotunheim.xml` (Security Analysis Result file) via rdflib and attempt
  a cross-check against `lf_basecase.csv` from R0.1, with graceful degradation:
  - Parse all `BaseCasePowerFlowResult` entries: extract `valueA` (current) where present,
    `valueW` and `valueVAR` where present
  - Parse all `ContingencyPowerFlowResult` entries: extract `valueA`, log as a separate
    contingency results block (informational only — not compared to base case LF)
  - If no `BaseCasePowerFlowResult` entries contain `valueA`: log a clear WARNING that
    the SAR file contains no base case current readings, export an empty
    `sar_vs_lf_comparison.csv` with a header comment explaining the dataset limitation,
    and mark the cross-check as "not verifiable with this dataset"
  - If timestamps in the SAR file do not match `TIMESTAMP_LIST` (e.g. different date):
    log at WARNING level — do not treat as a fatal error
  - If `valueA` entries are present: compute per-branch absolute difference vs
    `lf_basecase.csv` and flag any branch where difference > 5% loading

**Inputs:**
- All outputs from R0.1-R0.7
- `2D_SAR_1030Z_Jotunheim.xml`

**Outputs:**
- Console inventory table (per TSO: XNE count by type, CO count, PST count, RD unit count)
- `sar_vs_lf_comparison.csv`: populated if base case `valueA` entries found; otherwise empty
  with dataset-limitation note in header
- `sar_contingency_results.csv`: all `ContingencyPowerFlowResult` entries parsed from SAR,
  columns `[contingency_mrid, branch_id, value_a_ka, timestamp]`

**Acceptance criteria:**
- Given all R0 increments have completed,
- When the SAR validator runs,
- Then `AEFlatList` contains at least one secured XNE with `patl_ka > 0` AND the SAR
  validator completes without error AND either produces a populated `sar_vs_lf_comparison.csv`
  (if base case `valueA` entries are present with matching timestamps) OR logs a clear WARNING
  and exports an empty `sar_vs_lf_comparison.csv` with a dataset-limitation note
  (if no base case currents are available or timestamps do not match).

---

## R0.9 — Scanned element parsing (CORNET-439)

**Spec ref:** CORNET-439 — Scanned Elements

**What it delivers:**
- From `AEFlatList` (R0.4), extract all entries with `ae_type == "scanned"`
- For each scanned element: extract `virtualPositiveLoadMargin` (0-100 integer, optional)
  from `AssessedElement.normalPositiveVirtualMargin` in the AssessedElement profile
- If `virtualPositiveLoadMargin` is not defined, default to 0
- Note: `normalPositiveVirtualMargin` was not found in any ReliCapGrid AE file —
  all scanned elements default to `virtualPositiveLoadMargin = 0` on this dataset.
  The parser is implemented to accept the field if present in future datasets.
- Compute the effective scanned element loading limit per branch and timestamp:
  ```
  PATL_scanned = PATL_CGM * (1 + virtualPositiveLoadMargin / 100)
  ```
- If the initial LF loading `I_b,0` exceeds `PATL_scanned`, use `I_b,0` as the limit instead
  (the RAO will not worsen the initial overload)
- Parse `ScannedElementConstraint_Soft` control parameter (bool, default False — hard constraint)
  and `ScannedElement_penalty` (EUR, used when soft)
- Build `ScannedElementList: list[ScannedElement]` dataclass with effective PATL per element per timestamp

**Inputs:**
- `AEFlatList` (from R0.4, scanned entries only)
- `lf_initial[t]` (initial branch currents, optional — populated after R1.1; defaults to `patl_scanned_ka` if not provided)
- RAO control parameters: `ScannedElementConstraint_Soft: bool`, `ScannedElement_penalty: float`

**Outputs:**
- `ScannedElementList: list[ScannedElement]` (in-memory)
- `scanned_element_list.csv`: columns `[mrid, name, tso, timestamp, patl_cgm_ka, virtual_load_margin_pct, patl_scanned_ka, initial_loading_ka, effective_limit_ka]`

**Acceptance criteria:**
- Given a scanned element with `virtualPositiveLoadMargin = 10` and `PATL_CGM = 1000 A` and initial loading of `900 A`,
- When `ScannedElementList` is built,
- Then `patl_scanned_ka = 1100 A` and `effective_limit_ka = 1100 A` (initial loading below scanned limit) AND for a case where initial loading is `1200 A`, `effective_limit_ka = 1200 A` (initial loading used as limit).
- Note: verified in unit tests with synthetic data; margin is 0 for all entries
  on the current ReliCapGrid dataset (field absent from NCP files).
