> Original plan. Current status per row: see `Spec_Coverage.md` (section 3). Where this file and that one differ, `Spec_Coverage.md` is right.

# R3 — N-X Security Constraints and Curative Remedial Actions

**Goal:** Add N-1/N-X security constraints to the MILP using conventional per-contingency
AC load flow (replacing FOA/FCC), introduce curative PST and RD actions, close
the completeness iteration loop, and wire all of it into `run_pipeline.py` as a
real, runnable entry point (R3.10).

**Prerequisite:** R2 complete — RD PRA MILP working, including the composable
PstMilpInputs/RdMilpInputs architecture. R3 operates on a single timestamp —
multi-timestamp generalisation is deferred to R4.

**Stack:** pypowsybl 1.15.0 (per-contingency AC LF + AC sensitivity), Pyomo + HiGHS
via `highspy` (`solver_name="appsi_highs"`, `solver_io=None`), rdflib/ElementTree.

**~~Original stack line said "VeraGridEngine (per-contingency AC LF + sensitivity)"
— superseded entirely. All LF and sensitivity calls use pypowsybl.~~**

**Solver note:** Use `solver_name="appsi_highs"` with `solver_io=None`. Do not use
`solver_io="python"` (raises `NotImplementedError` on the current Pyomo/highspy version).

**Key design decision (unchanged):** FOA and FCC are replaced by a direct AC LF call
per contingency per timestamp via pypowsybl. Sensitivities for each N-X case are
computed from the converged N-X operating point using the same confirmed pypowsybl
sensitivity API as R1.2/R2.1. This is slower but exact.

**Side-awareness note (critical — inherits from R1/R2):** All branch current lookups,
PATL and TATL comparisons, and sensitivity computations in R3 must be side-aware.
`current_limit_side_map` from `ncp_parser.build_current_limit_side_map()` must be
used for every current and sensitivity lookup. This applies to N-X currents and
N-X sensitivities exactly as it applies to N-0.

**PST mRID note (inherits from R0.6):** pypowsybl indexes `get_phase_tap_changers()`
by the parent `PowerTransformer` mRID, not the `TapChanger`'s own mRID. All PST
mRID lookups in R3 must use the transformer mRID (via
`ncp_parser.build_tap_changer_to_transformer_map()`). Using the TapChanger mRID
directly will produce silent lookup failures.

**Composability architecture note (inherited from R2 — load-bearing for R3):** R2
established `PstMilpInputs` / `RdMilpInputs` dataclasses, the `hasattr`-based gating
pattern for optional PST/RD components on the Pyomo model, and the
`secured_branch_ids` / `scanned_branch_ids` split within a unified `branch_ids` set
(see R2's "Cross-cutting requirement" and "Architecture note: unified branch
candidate set" sections). **R3 extends the same `milp_builder.py` module** — every
new N-X constraint, curative variable, and completeness-loop addition in R3 must
respect the existing `hasattr`-gating pattern: N-X PST terms only appear when
`pst_inputs is not None`, N-X RD terms only appear when `rd_inputs is not None`.
Before writing any R3 increment, check the current state of `milp_builder.py` and
`milp_solver.py` directly rather than assuming R2's structure from this document
alone — the R2 implementation's closing note flagged that pre-existing call sites
into `build_n0_milp_model` (e.g. `linearisation.py`'s flat-signature call) were
missed once already during R2.4's refactor. **Explicitly check for every call site
into `build_n0_milp_model` and any N-X equivalent before assuming R3's changes are
isolated to `milp_builder.py` alone.**

**Single-timestamp indexing note:** Although several formulas below are written with
a `[t]` index for structural consistency with R4's future multi-timestamp extension,
R3 as scoped operates over a single timestamp — `t` is fixed to the one active
timestamp throughout this release. `lf_initial` (from R1.1) and `must_study` (from
`COFlatList`, R0.5) are both single-timestamp objects in R3; do not introduce an
outer per-timestamp dict layer prematurely. R4 will generalise this indexing when
multi-timestamp support is added.

---

## Architecture note: unified N-X branch candidate set (secured + scanned)

**Established after initial R3.1–R3.9 implementation, extending the R2
"Architecture note: unified branch candidate set" to the N-X/per-contingency
case. This section is authoritative for R3.1–R3.3 below — where it conflicts
with earlier drafts of those increments, this note governs.**

**Correction to the original framing of this note (verified directly against
live code before implementation, not assumed):** an earlier draft of this note
stated that R3.2's PATL constraint and R3.3's TATL constraint applied `patl`
uniformly to `AEFlatList` without distinguishing AE type. This was checked and
found **not** to be true — `_add_nx_block`'s PATL constraint was already
restricted to `AEType.SECURED` only, and `compute_tatl_data` was already
`SECURED`-only by construction (its own candidate-branch comprehension excludes
scanned branches structurally, before any filtering step — a scanned branch's
mRID can never become a key in its output). Both were correct from the start.
Similarly, `_get_monitored_branch_sides_nx` (used by `compute_lf_nx` and both
N-X sensitivity functions) was **already** computing `lf_nx` and raw sensitivity
data for both `AEType.SECURED` and `AEType.SCANNED` branches — scanned branches
were never absent from N-X computation entirely, as an earlier draft implied.

**What was actually missing, confirmed by direct inspection:** Filter 1 (loading)
did not exist anywhere — `_get_monitored_branch_sides_nx`'s own docstring stated
it takes no `lf_initial`/`sensitivity_threshold_pct` pre-filter, meaning
sensitivity was computed unconditionally for every monitored branch × every
usable contingency. Filter 2 (sensitivity pruning) was confirmed absent — no
`_pruned` dicts existed anywhere. **R3.2a did not exist at all** — meaning the
already-correct scanned-branch sensitivity data computed by
`_get_monitored_branch_sides_nx` was never consumed by any constraint. The gap
was real, but narrower than originally drafted: not "scanned elements never
entered N-X," but "scanned elements' sensitivity was computed but never
filtered, never pruned, and never wired into a constraint."

This note now specifies the actual correction implemented: the two filters,
and R3.2a as the missing consumer of already-correct data.

### New control parameters (all default `0.0` for now)

```python
min_loading_threshold_pct_nx: float = 0.0          # Filter 1, N-X
sensitivity_threshold_pct_pst_nx: float = 0.0      # Filter 2, N-X, PST
sensitivity_threshold_pct_rd_nx: float = 0.0       # Filter 2, N-X, RD
```

These are independent from N-0's `min_loading_threshold_pct`,
`sensitivity_threshold_pct_pst`, and `sensitivity_threshold_pct_rd` — sharing a
threshold across N-0 and N-X would conflate two different loading
regimes (base case vs. post-contingency), and N-X naturally produces many more
(branch × contingency) combinations than N-0, so a shared threshold is not
appropriate even before considering the type distinction below.

### Filter 1 — loading (per contingency, per branch, both AE types)

For each contingency `c` and timestamp `t`, a branch `b` is a candidate for N-X
sensitivity computation only if:
```
lf_nx[t][c][b] / limit[b][t] ≥ min_loading_threshold_pct_nx
```
where `limit[b][t]` is `patl[b][t]` for `AEType.SECURED` branches and
`effective_limit[b][t]` (from `ScannedElementList`, R0.9 — `PATL × (1 +
virtual_load_margin/100)`, with the initial-loading fallback) for
`AEType.SCANNED` branches. `effective_limit` is unchanged from R0.9/R2.12 — this
note does not introduce a new limit calculation, only applies the existing one
to the N-X context. A branch failing this check under a given contingency has no
sensitivity computed for it under that contingency at all — it is absent from
the candidate set for that (branch, contingency) pair, not merely constrained
to zero.

### Filter 2 — sensitivity (per branch, per contingency, per RA)

Applied only to branches that passed Filter 1. For each such (branch, contingency)
pair, individual RA sensitivities are pruned independently:
- PST: drop `(branch, contingency, pst)` if
  `|sensitivity_pst_nx[t][c][b,τ]| < sensitivity_threshold_pct_pst_nx × limit[b][t] / 100`
- RD: drop `(branch, contingency, gu)` if
  `|sensitivity_rd_nx[t][c][b,g]| < sensitivity_threshold_pct_rd_nx × limit[b][t] / 100`

This never removes the branch itself. A branch that passed Filter 1 but has
every RA pruned by Filter 2 still gets a constraint in the MILP — one with no
adjustable terms, e.g. `lf_nx[t][c][b] ≤ limit[b][t] + slack`. The slack absorbs
the violation and is penalised in the objective; the result honestly reflects
an unresolvable overload rather than silently dropping the branch from the
model.

### Constraint-building split (after both filters)

- **`AEType.SECURED` branches** — R3.2's existing PATL constraint (preventive +
  curative terms) applies, and separately R3.3's TATL constraint where a TATL is
  defined for that branch.
- **`AEType.SCANNED` branches** — a new N-X scanned-element constraint, identical
  in structure to R3.2's secured-branch constraint (preventive + curative terms
  summed together, same as R3.2), but comparing against `effective_limit[b][t]`
  instead of `patl[b][t]`. **No TATL-equivalent applies to scanned elements** —
  TATL (CORNET-1792) is defined specifically for the branches the RAO is
  securing to PATL; scanned elements have only the one `effective_limit`
  ceiling, confirmed as a deliberate modelling decision, not an oversight.

Both AE types share the same underlying `sensitivity_pst_nx`/`sensitivity_rd_nx`
computation and the same two-filter pruning pass — only the final
constraint-building step differs by type, mirroring exactly how R2.5/R2.12 split
after a shared N-0 pass.

---

## R3 implementation notes (added post-completion — deviations from this MD, confirmed against live code)

**This section documents confirmed deviations between this MD's original text and
the actual, tested R3 implementation.** Some are approved corrections (the MD text
was wrong or incomplete); some are documented gaps (intentionally not implemented,
flagged rather than silently built); one is an **unresolved bug** that should be
fixed before R4 builds on top of it. Read this section before extending R3 further
or before starting R4.

### ✓ Completeness loop stale-baseline bug — confirmed fixed

*(History: `run_completeness_loop` is replaced by the outer loop of the nested orchestrator; see "Loop redesign and consistency pass". Baselines are now refreshed from the current state at every iteration.)*

In `completeness_loop.py`'s `run_completeness_loop`: when a completeness check finds
zero new congestions, the loop previously mutated `lf_nx` to the fresh post-RA values,
but then **broke before rebuilding the model against that refreshed baseline**. The
returned `milp_model` — and therefore R3.9's exported results — could reflect
the stale, pre-RA linear baseline from iteration 0, even in the common
"converged immediately" case, which is every real case observed on the current
dataset. The mutation happened; nothing re-solved against it before returning.

This did not surface in initial testing because the existing tests checked that the
loop *stops*, not what baseline the final model reflects, and the real smoke-test run
has no live PST/RD movement to make stale-vs-fresh visible (nothing moves, so the
two baselines are numerically identical in that case).

**Confirmed fixed, verified directly against the live code (not assumed):**
`model = build_and_solve_fn()` now runs unconditionally on every iteration, not
gated on `new_constraints_added == 0`, and this is covered by
`test_stops_after_one_rebuild_when_no_new_congestions_found`. This is no longer a
blocker for R4 or any future work building on the completeness loop. Retained here
for historical context — this was a real, consequential bug in the original
implementation.

### R3.1 — confirmed deviations

- **Native batch sensitivity API used instead of the manual disconnect/run_ac/restore
  loop described below.** pypowsybl's native security/sensitivity batch APIs (which
  compute N-X sensitivities for many contingencies in a single call, internally
  managing contingency application and restoration) were used instead of the
  manual per-contingency loop this document originally described. This was an
  explicit, approved change based on empirical research into pypowsybl's contingency
  API surface. The manual loop text below is retained for conceptual reference (it
  describes correctly *what* must happen — apply, run, restore — just not via which
  API surface) but the actual implementation uses the batch contingency API, not a
  manual per-contingency `update_lines`/`update_2_windings_transformers` loop.
- **`sensitivity_pst_nx` stores raw A/degree, not A/tap.** This MD's text says to
  convert to A/tap "same conversion as R1.2" — but R1.2's actual, live implementation
  does not perform that conversion at sensitivity-computation time either; the
  degrees-per-tap conversion happens later, inside `_add_pst_block` in
  `milp_builder.py`. R3.1 was implemented to match R1.2's real behaviour (defer
  conversion to the MILP-building stage) rather than this MD's stated description.
  **This MD's R1.2 text should also be checked for the same inaccuracy** — flagged
  here for visibility, not corrected in R1's file in this pass.
- **Sensitivity computation covers both preventive and curative PSTs/RD units.**
  R1.2/R2.1 (N-0 sensitivity) were preventive-only; R3.1 necessarily computes
  sensitivity for both preventive and curative RAs, since R3.5/R3.6 need curative
  sensitivity too. This MD's original text did not state this scope explicitly —
  now confirmed and documented.
- **`sensitivity_threshold_pct` pruning was NOT implemented for N-X sensitivity**
  at the time of R3's initial implementation, despite being listed as an R3.1
  input in earlier drafts of this document. R2.2 has a dedicated pruning
  increment for N-0; R3 initially had no equivalent, and this MD's own R3.1
  "what it delivers" text never actually described a pruning step at that time
  either. This was a confirmed, documented gap, not a bug. **Superseded by the
  "Architecture note: unified N-X branch candidate set" section above** — N-X
  now has its own two-filter pruning pass (`min_loading_threshold_pct_nx`,
  `sensitivity_threshold_pct_pst_nx`, `sensitivity_threshold_pct_rd_nx`),
  specified there and implemented in R3.1/R3.2. This also resolved the open
  question about scanned elements previously absent from N-X entirely — see the
  same architecture note for the unified secured+scanned candidate set.
- **`current_limit_side_map` is not taken as an explicit function parameter
  anywhere.** Each branch's side is instead read from its already-resolved
  `AssessedElement.branch_side` attribute (set once in R0.4), matching how R1.2/R2.1
  actually work — this MD's abstract "Inputs" list implies a separate map parameter
  threaded through every function, which does not match the real call pattern.
- **`lf_nx` is dual-sided per branch** (`{1: i1, 2: i2}`, matching `build_lf_initial`'s
  existing shape), not the single-value-per-branch shape this MD's output type
  annotation implies.
- **`sensitivity_rd_nx.csv` was added proactively** as an R3.1 output — not
  originally listed in this MD's R3.1 outputs.

### R3.4 / R3.5 — confirmed deviations

- **Four CIM predicates were found empirically and were not named anywhere in this
  MD before this note:** `RemedialAction.timeToImplement`,
  `GridStateAlteration.timePerStage`, `ContingencyWithRemedialAction`,
  `AssessedElementWithRemedialAction`. These are the real predicates backing
  `time_per_stage_minutes`, `reaction_time_minutes`, `linked_contingency_mrids`, and
  `linked_xne_mrids` respectively. Documented here for the first time; verified
  against live NCP data, not assumed.
- **`pst_tap_bounds_curative`'s fallback-to-preventive-bounds logic lives in the
  caller**, not inside `build_pst_tap_bounds_curative` or `milp_builder.py` — an
  architectural choice this MD did not specify either way. If a curative
  `RangeConstraint` is absent for a PST, the caller falls back to that PST's
  preventive tap bounds rather than the bounds-building function doing so internally.
- **The `RelativeDirectionKind` convention (which enum value means upper vs. lower
  bound for curative `RangeConstraint`) is an unverified assumption**, flagged
  directly in the code, since the current ReliCapGrid dataset has zero real examples
  of a curative PST `RangeConstraint` to confirm the direction convention against.
  Treat this as an open item — if a future dataset cut has real curative range
  constraints, verify the assumption before trusting the sign convention.

### R3.6 — confirmed deviations

- **Two real bugs were found and fixed in `_add_rd_block` and its objective term**:
  both previously mixed preventive and curative bids together (a carry-over defect
  from R2-era code, not something newly introduced by R3.6). `_add_rd_block` now
  correctly filters to preventive-kind bids only; curative bids are handled
  separately by R3.6's own curative variable construction. **This is relevant to
  anyone reading R2's documentation going forward** — R2.4's original description
  of `_add_rd_block` did not need to distinguish preventive/curative since R2 predates
  curative RD entirely, but the shared function now has this distinction and it
  should be understood by anyone extending R2's RD logic further.
- **`activate_cra_xne_linkage` for RD is checked at the generating-unit level**,
  coarser than PST's exact per-variable check in R3.5. This MD said "same logic as
  PST CRA in R3.5," which is not quite accurate — RD's GLSK-aggregation structure
  does not preserve per-bid identity the way PST's 1:1 tap-changer-to-PST mapping
  does, so the linkage check for RD is necessarily coarser (per generating unit,
  not per bid). Explicitly flagged as a simplification in the code.

### Curative RA spec-alignment pass (post-R3) — confirmed changes and deviations

A review of the MILP against the spec found gaps in the curative RAs. All items
below were verified against live code first, fixed test-first, and checked with
before/after pipeline runs (mock N-X compared at 1e-6 tolerance because of solver
noise of about 1e-9; other datasets byte-identical unless stated).

- **Preventive/curative PST separation (real bug).** The PST list passed to the
  MILP mixed both kinds, so a curative-only PST received *preventive* tap
  variables, and the penalty dict keyed by transformer let one RA overwrite the
  other's penalty factor. Fixed: `PstMilpInputs` keeps one list but exposes
  `preventive_pst_list` and `curative_pst_list` views; everything preventive reads
  the first, everything curative the second; penalties are computed per kind.
  Two RAs of the *same* kind on one transformer with different penalties: the
  larger value is used, with a warning (assumption — the spec does not say).
- **Duplicate transformer bug.** `_get_pst_ids` returned a transformer with two RAs
  twice, doubling its N-0 effect and counting it twice toward the per-TSO tap cap.
  This alone changed the mock N-X result (objective 97,692 to 83,654); the old
  numbers were wrong and the new ones are the baseline.
- **Curative PST cost term (new).** Curative taps previously had no cost. Now
  penalty factor of the curative RA x `penalty_reference_pst_pra`, summed over all
  (PST, contingency) pairs (spec eq. 3.47–3.48, CORNET-1982). **Sum, not max** —
  the max for PST is only an "Outlook" item in the spec. No new config parameter.
  `results_pst.csv` gained `curative_tap_change_total` and
  `curative_penalty_cost_eur`.
- **Curative tap-bounds fallback.** The fallback range (the PST's own operating tap
  range) is now built from curative PSTs only; a preventive RA on the same
  transformer can no longer override it. One log line reports how many curative
  PSTs used the fallback (all of them on current data).
- **Curative RD cost: deviation kept on purpose.** The code multiplies by the bid
  *energy price*; spec eq. 3.40 / BUC 14#43 uses the *reservation cost*
  (`reservePriceCRA`) and says the energy price is not considered. Decision: keep
  the energy price. No reservation cost is parsed and none exists in any dataset.
  The per-bid max over contingencies already split up and down (eq. 3.42–3.43);
  a six-mutation lock test now guards it.
- **Curative RD lead time (CORNET-576).** Previously ignored for curative bids.
  Now enforced as a variable upper bound of 0, reusing the preventive helpers.
  No effect on current data (all lead times are 0).
- **Curative RD without preventive RD.** The pipeline gate previously set
  `rd_inputs=None` when no preventive RD unit existed, so curative-only generators
  never got curative RD. New gate `rd_inputs_required` (`pre_milp/workflow_gates.py`):
  a curative-only unit opens the RD workflow when N-X analysis is on. Two
  preventive-only sensitivity calls (initial and AC-loop refresh) are guarded.
  On the mock curative-only variant the objective fell from 53.3M to 2.24M.
- **Curative PST group constraint (SF3074, new).** Equal curative delta tap for all
  group members, per contingency, over all unique pairs. Also new: **outage-element
  exclusion** — `compute_pst_cra_availability` previously kept a PST as curative
  RA in a contingency that tripped that same transformer. `PSTGroupKind` is a
  per-TSO RAO control parameter in the spec (default blocked; not in the CoMo
  model): config `curative_ra.pst_group_kind_default` plus optional
  `pst_group_kind_per_tso`. Verified on synthetic data only — no dataset has a
  curative PST group.
- **Ignored RA classes.** `RedispatchRemedialAction` and `CountertradeRemedialAction`
  (e.g. `fa73cfee` in NCP_generic) have no link to a generating unit; they would
  need a bidding-zone/GLSK redispatch model, a separate feature. The parser now
  logs a warning for each. The exact profile text could not be read beyond about
  p.41 of the NC profile specification.

**Open points (updated):** `extract_results_summary` is now called by the pipeline; curative RD volumes are exported in `results_curative_rd.csv` (`results_preventive_rd.csv`, formerly `results_rd.csv`, is preventive only); curative RD is
outside RA-count and group-limit logic; the up/down mapping of the curative range
parser is unverified (no dataset has one); the common-delta group check uses
headroom at the initial tap and ignores preventive movement; the two smoke tests
must be run locally on real data.

### Loop redesign and consistency pass (after the curative spec-alignment pass)

This section records a sequence of investigations and fixes, in the order they happened. It supersedes the descriptions of the loop in "R3.8 — detailed" and "Convergence correction" further down (kept as history). Technical references: `AC_Verification_Loop_Technical_Reference.md` (loop), `MILP_Mathematical_Formulation.md` §7 (cumulative formulation), `Results_Export_Technical_Reference.md` (files).

**Spec basis.** Functional spec pp. 68–72: a linearisation iteration builds the MILP at the current operating point, solves, applies the RAs temporarily to the grid model, runs a new load flow and, if it converged, runs the Convergence Check; after it the outage approximation runs again. The criteria are independent acceptance criteria (OR): `MaxCountLinIter` (hard), sum of RA change below `MaxChangeRASum` (eq. 3.35), each RA change below `MaxChangeRA`, change of element overloads, CT adaption (not applicable). A cyclic repetition exit compares the new result with earlier solutions (threshold definable). Completeness iterations (`MaxCountCompIter`) form the outer loop (CORNET-12, CORNET-16). A non-converged load-flow solution cannot be used to evaluate the grid state (CORNET-106). The spec is silent on contingency propagation.

#### 1. Why the loop was redesigned

An investigation of the exported files found a **hybrid state**: some model inputs came from the original network, some from the AC-applied state, and the completeness model's deltas did not sit on a single consistent baseline. (My first hypothesis — that the completeness model simply sat on top of the AC-applied state — was wrong.) The fix was a single state object (below).

#### 2. Design now in the code

- **`OperatingPointState`** (`milp/operating_point_state.py`): original frozen, current updated. All baselines are refreshed every iteration: PST taps, `target_p`, N-0 and N-X load flows, N-0 and N-X PST/RD sensitivities.
- **Nested loops:** completeness outside, linearisation inside; apply first, then check (spec order).
- **Cumulative MILP** against the original network: per-PST cumulative up/down variables with `cum_up − cum_down = (r_current − r_orig) + up − down`; per-TSO tap limit on `Σ(cum_up + cum_down) ≤ L`; RD bid headroom (same direction: availability − used; opposite direction: used); RA-count binary linked to the absolute cumulative net (big-M = original availability), not fixed to 1; cost priced against the original network; curative actions re-optimised every solve and never applied, curative costs per solve; curative "unit in operation" flag on the original `target_p`; scanned effective limit anchored on the original N-0 load flow; applied taps integer-rounded. (Formulas: `MILP_Mathematical_Formulation.md` §7.)
- **Export:** results are read from the AC-final model (`select_result_models`); the stale-file problem is handled by `output_file_registry.py`. RA-count activation is derived from `|net volume| > 1e-6 MW` (the binary has no lower link and no penalty when no count limit is configured — my earlier hypothesis that an RA-count penalty was active was wrong).

#### 3. Convergence check

Any of the following ends the loop as `CONVERGED` (OR, confirmed by spec pp. 69–70):

1. Σ|tap change| and Σ|ΔMW per generating unit| both below `max_change_ra_sum_threshold`;
3. max|tap change| and max|ΔMW per unit| both below `max_change_ra`;
4. Σ over elements |overload_e(k) − overload_e(k−1)| below `max_change_overload` (amperes), where `overload_e = max(0, AC current − model limit)` over N-0 secured and scanned branches and N-X PATL/TATL pairs; N-X uses the AC current plus the linearised curative effect; state 0 is the initial AC state; not evaluated if the N-X refresh failed.

The earlier criterion 4 compared the MILP's overload-slack totals and fired meaninglessly at iteration 2 (172 MW had moved); it is now a diagnostic only. Criterion 4 does not cover N-X scanned pairs. Thresholds are all 1.0 in the test config.

#### 4. Cycle exit and revert

After iteration k ≥ 2, if no criterion holds, the cumulative solution (tap per PST, net RD MW per unit) is compared with iterations 0…k−2; a maximum difference below `max_change_ra` is a cycle. Among the cycle members (matched j…k) the one with the lowest total AC overload is kept (ties: lowest cumulative cost), re-applied with a load flow, and `cycle_selected_iteration` is recorded; member 0 is not a candidate; a failed re-apply keeps the newest member with a warning (`CYCLIC_REPETITION`). A load-flow failure at iteration k > 1 reverts to the **last converged state**, at k = 1 to the original (k > 1: `REVERTED_TO_LAST_CONVERGED_STATE`, reason "load flow non-convergent - reverted to last converged state"; k = 1: `REVERTED_NON_CONVERGENT`; `data_model.py:88–99`). Statuses (seven): `CONVERGED`, `CYCLIC_REPETITION`, `MAX_ITERATIONS_REACHED`, `REVERTED_NON_CONVERGENT`, `REVERTED_TO_LAST_CONVERGED_STATE`, `SENSITIVITY_INVALID`, `NOT_APPLICABLE`. Cycle tie-break: lowest total AC overload, then lowest cumulative cost, then the latest member.

#### 5. The "flip" investigation (Galia ±40 MW)

A mock-case run ended on the cycle exit with an RD flip of about ±40 MW at Galia. Cause: a near-tie (3–95 EUR between the two dispatch options) amplified by inconsistent sensitivities (section 6). With consistent sensitivities there is no flip.

#### 6. Sensitivity load-flow-parameter defect (confirmed, older than the redesign)

The N-X (and other) sensitivity analyses ran with pypowsybl default load-flow parameters instead of `build_loadflow_parameters(use_reactive_limits, extra_lf_params)` (`pre_milp/lf_parameters.py`). With defaults the post-contingency reference was zero at some states, all sensitivities of that contingency were zero and the MILP was forced into slack (for example 88.9 A); initial sensitivities were also about 23 % smaller (Σ|PST| 265.9 against 344.5). This had distorted model-versus-AC agreement (about 3 pp) since R3. **Fixed at eight call sites** (initial N-0 PST/RD, initial N-X PST/RD, refresh N-0 PST/RD, refresh N-X PST/RD); the N-0 refresh in the loop warm-starts with `voltage_init_mode = PREVIOUS_VALUES`, the N-X sensitivity refresh does not (open point).

**Guard.** Sensitivities are checked against the load flow at the same state: N-0 reference versus `lf_initial` tolerance 1e-3 relative; N-X: reference missing or zero while the load-flow current is above 1 A, all sensitivities of a contingency exactly zero while the load-flow current is non-zero, or relative deviation above 1e-2 (tightened from 1.5 after the propagation fix; measured maximum 2e-9 mock, 1.7e-5 generic). A branch the contingency itself disconnects is valid. On failure the last **valid** PST/RD sets are reused (a reused set never becomes "last valid"; the initial sets count as valid; stored sets are used only if their keys still match). With no valid set the loop ends with `SENSITIVITY_INVALID` and the completeness loop stops. At the first computation `SensitivityGuardError` is raised, but the summary, contingency status and iteration history are still written. `results_iteration_history.csv` carries a `sensitivity_source` column.

#### 7. Contingency propagation

The security analysis behind `lf_nx` ran with OpenLoadFlow `contingencyPropagation = true` (default), which trips extra equipment through the node-breaker topology; the sensitivity analysis and a direct load flow trip exactly the listed equipment. **Decision: propagation off everywhere**, set in the shared builder; `compute_lf_nx` is the only place a security analysis is created (initial run, loop refresh and completeness check all go through it). Evidence (`docs/analysis/propagation_evidence.csv` + README): confirmed against a direct load flow (difference ≤ 4.3e-3) for ce19dd34 (generator), 62eac668 and ab92defa (shunts), 65582e87 (load). **Not reproduced:** busbar e8e8300b and generic 8cdec4c6, 96c96ad8, 264e9a19, 7e31c67d, e9eab3fe, 2c1fe55c ("propagated state not reproduced"). Five of 16 contingencies changed `lf_nx` on mock, 11 of 22 on generic (largest: mock ce19dd34 on 60-61, 509.0 → 692.5 A; generic 96c96ad8 on 68-81, 247.8 → 514.5 A). No code depends on the evidence.

**Effect (mock):** model-versus-AC final-state difference N-X 1.98 pp → 0.002 pp (max; mean 0.0001), N-0 max 0.0012 pp; loop 6 iterations ending in a cycle → 3 solves ending on criterion 4; final objective 89146.17 → 89146.12; cumulative state unchanged (same PST taps, RD about ±49.598 MW). Generic: 1 solve, criteria 1+3+4, differences 0.0000. Pipeline time unchanged (mock 3.4 → 3.5 s). Five N-X pairs on mock remain over PATL at the final state (CO2/CL5 121.38 %, CO1_CL7_and_CT72_T1_LAST on TieLine_SD_BO2 107.20 %, CO2/23-25 102.86 %, CO3 on TieLine_SD_BO2 100.00 %, CO_ConformLoad_1 on TieLine_SD_BO2 105.23 %); all are in the model sets with post-curative loading at 100.00 %. Generic: CO2/CL5 123.09 %, CO2/23-25 105.51 %.

**Busbar contingencies are an open point:** with propagation off the busbar contingency e8e8300b changes more branches against N-0 (86 against 45 above 1 A), so how busbar tripping should be modelled is not settled.

#### 8. Verification

Test-first with mutation checks (bytecode caching off). Propagation pass: 6 of 6 mutations killed (propagation true in the builder, no provider parameters, `compute_lf_nx` bypassing the builder, tolerance 1.5 / 1e-3 / 1e-1); the bypass mutation was killed through a fixture error rather than a clean assertion failure. Permanent regression test: sensitivity reference equals `lf_nx` within 1e-4 for every (contingency, branch) on the mock fixture. Suite: 779 passed, 41 skipped (implementation run); 33 tests in `tests/test_rao_convergence_check.py`. On mock the count of post-curative pairs at exactly 100.0 % went from 3 to 4, read as a floating-point boundary effect (not investigated).

#### 8a. Clean-up pass and measurements (after the verification pass)

- **Config:** see the struck-through items in section 9. **Dead code:** removed (section 9). **Old file names:** replaced in `docs/`; `tests/test_rao_output_renames.py` guards `docs/*.md` and the rename table.
- **Scanned N-X export aligned with the loadings export:** `loading_before_rao_ka` = original `lf_nx`; `loading_after_rao_ka` = `lf_nx_final` + curative-only linearised effect (fallback: build baseline + full linearised effect); new last column `loading_after_model_ka` = build baseline + full linearised effect. 12 tests, 6 of 6 mutations caught.
- **Dead N-0 scanned results file removed:** `write_results_scanned_elements_csv` / `extract_scanned_element_results` and the R2.12 smoke-test block; the N-0 scanned results file (`results_scanned_elements.csv`) is not produced.
- **N-X sensitivity refresh without warm start — measured, left as is.** On mock, a temporary variant with `PREVIOUS_VALUES` changed the sensitivities by at most 1e-6 (relative), gave the same taps, the same status and criterion, and the same refresh time (0.9 s against 0.8 s). Generic never reaches the refresh (one solve). Add the warm start only if a case with an extreme incremental-fallback state shows a benefit.
- **Suite:** 795 passed, 41 skipped.

#### 9. Open points from this pass

- `activation_cost_eur` (eq. 3.38) and generating-unit start-up cost (eq. 3.39, BUC14#102/#103) are not in the objective; eq. 3.35 is not built (taps and MW share one threshold).
- Real-data runtime of the N-X sensitivity refresh is unmeasured (worst case 10 iterations × 5 completeness solves).
- Fractional versus integer applied taps: unverified on real data; first-solve linearisation error can be large (up to 374 A in a preventive-only N-X case).
- Busbar contingency modelling (above); the unconfirmed generic propagation cases.
- ~~`rao_config.default.yaml` lacks `max_change_ra`, `max_change_overload` and `logging_options.debug_log_mode`.~~ **Fixed in the clean-up pass:** the default file now has all 32 keys; a missing key raises `ConfigKeyError` naming the key and the file; `tests/test_rao_config_keys.py` (5 tests) fails if the code reads a key the default file lacks, or if default and active config differ in keys.
- ~~`run_completeness_loop` / `run_completeness_check` are dead code.~~ **Removed in the clean-up pass** (with `CompletenessCheckStatus`, their tests, and the unused imports in `ac_convergence_loop.py` and `n0_results_export.py`). `scanned_element_list` no longer carries the assessed-element mrid.
- Criterion 4 does not cover N-X scanned pairs.
- Fix pass after the validation inventory: see `INDEX.md` open item 8 and `Data_Validation_Reference.md` section 13 (status paragraph).
- Real-data checks and kept deviations (TATL = PATL with 600 s, excluded-element rule, RD Pmax/Pmin default): see `Real_Data_Checks.md`.
- Smoke tests on real data must be run locally.
- R4.3 / R4.4 loop wiring and multi-timestamp N-X are deferred (R4 branch).
- Wording of the `pst_cra_availability` column in the User_Guide was not re-checked.
- Optional: report the propagation behaviour to the pypowsybl / OpenLoadFlow maintainers.


---

> **History from here on.** The R3.8 sections below (including "Convergence correction") describe the loop as it was before the redesign; where they differ from the section above, the section above is current.

### R3.8 — confirmed deviations / clarifications

- **Only preventive actions are applied to the network for the completeness
  re-check, not curative.** This matches the MD's own acceptance criteria wording
  (which only mentions PRAs), but the "what it delivers" bullet list did not scope
  this explicitly — now stated directly: the completeness check re-applies
  preventive tap positions and RD volumes only, not curative CRA activations.
- **"New congestion" is defined strictly as never-before-constrained (branch,
  contingency) pairs.** Given `min_loading_threshold_pct_nx` defaults to `0` in this
  codebase, most pairs are already constrained from iteration 0 — meaning the
  practical value of this loop on the current dataset is converging the linear
  baseline toward the true AC solution (which the "stale baseline" note anticipated
  in this MD already), not discovering brand-new congested pairs that were entirely
  absent before. This reading is now the documented interpretation; if a future
  dataset or configuration relies on the loop's brand-new-pair-discovery role more
  heavily, revisit this note.
- **See the bug note above** — the stale-baseline defect on the "zero new
  congestions" exit path was the most consequential finding from R3's initial
  implementation, since confirmed fixed.

---

| Item | Reason deferred |
|------|----------------|
| CORNET-3691 — Fast Outage Approximation | Replaced by conventional per-contingency AC LF |
| SF3072 — Fast Contingency Calculation | Replaced by conventional per-contingency AC LF |
| BUC14#113 — useFCCOnly control parameter | Not applicable; prototype always uses conventional LF |
| BUC14#111 — Non-coordinable SPS | SPS deferred entirely |
| BUC14#131 — Read input of SPS | SPS deferred entirely |
| CORNET-2586 — RTE-specific TATL handling | Deferred; standard single TATL per XNE (CORNET-1792) only |
| CORNET-4614 — PRAs and CRAs for same generating unit | Included in R3.6 |
| 3-winding-transformer-backed PSTs | Not supported by TRANSFORMER_PHASE sensitivity variable type (confirmed via live error); defer to future release |

---

## R3.1 — Custom N-X sensitivity computation via conventional AC LF

**Spec ref:** Custom increment (replaces CORNET-3691 FOA and SF3072 FCC with
conventional per-contingency AC LF via pypowsybl)

**~~Original text said "Apply the contingency in the VeraGridEngine network model"
and "using the same VeraGridEngine Jacobian sensitivity API as R1.2 / R3.1"
— superseded entirely. Use pypowsybl throughout.~~**

**Implementation note:** The manual per-contingency disconnect/run_ac/restore loop
described below is the conceptual model (this is *what* must logically happen), but
the actual, tested implementation uses pypowsybl's native security/sensitivity batch
APIs instead, which compute N-X sensitivities for many contingencies in a single
call and manage contingency application/restoration internally. This was an
approved change based on empirical research into pypowsybl's contingency API
surface — see "R3 implementation notes" above. The steps below remain accurate as a
description of the required behaviour; treat them as a specification of outcomes,
not a literal API call sequence to replicate.

**Scope note — equipment types widened, corresponding to R0.5's correction.**
This increment's disconnect/restore logic originally covered `line`/`transformer`
only, matching R0.5's original (too-narrow) validation scope. Per R0.5's
confirmed spec finding, `COFlatList` now includes `gen`, `load`, `switch`,
`shuntCompensator`, `staticVarCompensator`, `busbar`, and `bus` contingencies
too. See R0.5's confirmed equipment-type inventory table for exactly which
types have real instances in this dataset (`switch` and `staticVarCompensator`
confirmed absent; `busbar`/`bus` has exactly one real instance).

**`busbar`/`bus` resolution — confirmed against live pypowsybl API and one
real dataset instance (Svedala CO `e8e8300b`), not guessed:**

- **`busbar` → `BusbarSection`, individually disconnectable.** Confirmed via
  `network.get_busbar_sections()` (265 real rows in this network, columns
  `[name, v, angle, voltage_level_id, bus_id, connected]` — **singular**
  `connected`, genuinely different kwarg shape from lines/transformers'
  `connected1`/`connected2`). `network.update_busbar_sections(id=...,
  connected=False)` confirmed to exist and work via a standalone diagnostic
  script before wiring into the real N-X loop. CO `e8e8300b`'s two
  `ContingencyEquipment` entries ("Busbar 1"/"Busbar 2") each point to a
  distinct `BusbarSection` object — the semantics are "trip these two named
  busbar sections individually," not "disconnect every element attached to a
  bus," resolving the originally-flagged ambiguity for this concrete case.
- **`bus` → no confirmed pypowsybl equivalent.** `network.get_buses()` exists
  (274 rows) but has **no `connected` column at all** — buses are a
  derived/computed topological view in pypowsybl, not something directly
  toggled; there is no "disconnect this bus" operation. Zero real `bus`-type
  (as distinct from `busbar`) contingency instances exist in this dataset to
  verify semantics against even if a mechanism existed. **`bus` is documented
  as investigated with no direct pypowsybl equivalent found and zero real
  instances to test against** — the same honest-gap treatment as `switch`/
  `staticVarCompensator`'s confirmed-absent finding, not implemented.

**`gen`/`load`/`shuntCompensator` contingency support — confirmed real,
partial, root cause pending. `staticVarCompensator` — confirmed fully
working.** Investigated via `add_single_element_contingency` against real
dataset instances, not assumed from the busbar precedent. **Status: NOT a
clean per-type pass/fail the way `switch`/`staticVarCompensator` absence was**
— `staticVarCompensator` and `busbar` are both cleanly confirmed working
(100% of tested instances). `gen`, `load`, and `shuntCompensator` show a
genuine, reproducible **per-instance** split — some real instances register a
contingency correctly, others silently don't, for the same equipment type,
under apparently identical conditions.

*Switch-level topology — checked directly, ruled out as the mechanism.*
Initial hypothesis was an operable-disconnector difference, mirroring the
busbar investigation's own consideration. Checked via
`network.get_bus_breaker_topology(voltage_level_id)` for a working and a
non-working generator: **structurally identical** — one bus, zero switches,
exactly 2 generators + 2 lines at each. Not a missing switch to operate.

*The `_DC1`-suffixed failures — reclassified, not a defect.* Several
"failing" generators (e.g. `BP_SD-EH_DC1`, `BP_EH-SD_DC1`) are confirmed
synthetic AC-generator proxies for genuine HVDC converter stations — verified
against `network.get_hvdc_lines()`, which contains a real `DC-Line-EH_SD1`
matching this exact boundary. **This is pypowsybl correctly declining to do
something semantically wrong** — a synthetic AC proxy for an HVDC converter
shouldn't be contingency-tripped as a plain generator. Kept separate from the
genuinely unexplained pattern below.

*The genuine, unexplained correlation — confirmed real, not random.* Every
`BP_`-prefixed (boundary point) generator tested is a synthetic cross-TSO
power-exchange proxy (confirmed: `min_p`/`max_p` infinite, not real physical
limits; the co-located "other generator" at the same bus has the exact
mirrored `target_p`). Against 25 tested real generators:

| Boundary | Result |
|---|---|
| `BP_GA-BO*` (Galia↔Belgovia) | **Works — every instance tested** |
| `BP_GA-NH1` (Galia↔Nordheim) | Works |
| `BP_SD-*` (Svedala↔anything, non-DC) | **Fails — every instance tested** |
| `BP_GA-BH1` (Galia↔Britheim) | **Fails — the exception that rules out "Galia always works" as a clean rule** |
| Plain generator, non-boundary (`225.0`) | Works |
| Plain voltage level, non-boundary (`VL 220 kV`) | Fails |

`BP_GA-BH1` is kept explicitly visible, not smoothed into the cleaner-looking
rows — it's what stops "Galia's boundaries work, Svedala's don't" from
becoming a false rule relied on later. The last two rows confirm this isn't
purely a boundary-point phenomenon; plain, non-synthetic equipment shows the
same split.

*Root cause — confirmed not found via API-level investigation, deliberately
not pursued further.* The next diagnostic step would be comparing raw CIM XML
directly between a working TSO's EQ submission (e.g. Galia's `BP_GA-BO1`
definition) and a failing one (Svedala's `BP_SD-BO1` definition) to find the
actual data-authoring difference. **Deliberately not pursued** — this is
CGMES data auditing, a different kind of work than this project's scope, the
same judgment that stopped the `bus` investigation once "no pypowsybl
mechanism, zero real instances" was confirmed rather than chasing a
workaround with nothing real to test against.

**Recorded status, matching the busbar restore anomaly and the CGMES merge
workarounds already on file:** confirmed real, reproducible, correlates with
TSO/boundary identity, root cause pending deeper CIM-level comparison if ever
revisited. Legitimate candidate for a pypowsybl GitHub issue (same category as
the existing filed workarounds) if pursued later.

**⚠ Note on disconnect-call kwarg shapes — genuinely still unverified, not
confirmed by this investigation.** The `gen`/`load`/`shuntCompensator`
findings above are about whether a contingency **registers** correctly via
`add_single_element_contingency` — a separate question from which
`network.update_*()` kwarg shape each type's own disconnect/restore call
actually needs. That has not been directly confirmed for `gen`, `load`, or
`shuntCompensator` yet, the same open item flagged when this scope note was
first written. Do not assume `connected1`/`connected2` (the line/transformer
shape) applies uniformly — busbar sections already confirmed a genuinely
different shape (singular `connected`), so each remaining type still needs
its own direct check before implementation, exactly as originally scoped.

**A near-miss worth recording explicitly, not silently dropped:** an early,
single-instance test of `update_loads(connected=False)` and
`update_shunt_compensators(connected=False)` (one load, one shunt
compensator) appeared to succeed, before the instance-dependent registration
pattern above was discovered. Given that pattern — 3/5 loads and 1/5 shunt
compensators registering correctly via the native contingency API — that
early single-instance result cannot be treated as a general confirmation; it
may simply have landed on a working instance by chance (n=1 cannot
distinguish "reliably works" from "works ~60%/~20% of the time"). Recorded
here so a future reader who finds that early test result elsewhere doesn't
mistake it for real verification — the same discipline as the shared-threshold
near-miss recorded in R2.5.

**What it delivers:**
- Candidate (branch, contingency) pairs are determined by Filter 1 of the
  "Architecture note: unified N-X branch candidate set" above — covering both
  `AEType.SECURED` and `AEType.SCANNED` branches from `AEFlatList`, tested
  against `patl` or `effective_limit` respectively, using
  `min_loading_threshold_pct_nx`
- For each contingency `c` in `COFlatList` where `must_study[t][c_mrid] == True`:
  - Apply the contingency in the pypowsybl network, dispatching on
    `c.equipment_type`:
    ```python
    # For a line contingency:
    network.update_lines(id=equipment_mrid, connected1=False, connected2=False)
    # For a transformer contingency:
    network.update_2_windings_transformers(id=equipment_mrid,
                                           connected1=False, connected2=False)
    # For gen/load/switch/shuntCompensator/staticVarCompensator/busbar/bus
    # contingencies: verify the correct pypowsybl call and kwarg shape per
    # type before implementing — see "Scope note" above. Do not assume the
    # line/transformer connected1/connected2 pattern generalises.
    ```
  - Run a full AC LF on the post-contingency topology:
    ```python
    lf_result_nx = pp.loadflow.run_ac(network)
    ```
  - Check convergence: if `lf_result_nx[0].status.name != 'CONVERGED'`, log a
    WARNING and skip this contingency for this timestamp
  - Check for network split: compare connected component count before and after;
    if island count increases, log and skip
  - If convergent: extract side-aware N-X branch currents using the same
    `current_limit_side_map` as R1.1/R2.1:
    ```python
    lines_res_nx  = network.get_lines_results()
    trafos_res_nx = network.get_2_windings_transformers_results()
    # use i1 or i2 per branch per AE based on current_limit_side_map
    ```
  - Compute N-X PST sensitivities, for candidate (branch, contingency) pairs only,
    using the confirmed pypowsybl sensitivity API:
    ```python
    sa = pp.sensitivity.create_ac_analysis()
    sa.add_factor_matrix(
        functions_ids=branch_mrids_side1,
        variables_ids=pst_mrids,            # PowerTransformer mRIDs
        contingencies_ids=[],
        contingency_context_type=pp.sensitivity.ContingencyContextType.NONE,
        sensitivity_function_type=pp.sensitivity.SensitivityFunctionType.BRANCH_CURRENT_1,
        sensitivity_variable_type=pp.sensitivity.SensitivityVariableType.TRANSFORMER_PHASE,
        matrix_id=f'psdf_nx_{c_mrid}_side1_t{t}'
    )
    # Repeat with BRANCH_CURRENT_2 for side-2 branches
    result_nx = sa.run(network)
    matrix_nx = result_nx.get_sensitivity_matrix(f'psdf_nx_{c_mrid}_side1_t{t}')
    # matrix_nx.index = pst_mRIDs, matrix_nx.columns = branch_mRIDs
    ```
    Values are in A/degree — convert to A/tap using `degrees_per_tap` from
    `network.get_phase_tap_changer_steps()` column `alpha` (same conversion as R1.2)
  - Compute N-X RD sensitivities using `INJECTION_ACTIVE_POWER` variable type
    (same as R3.1, but evaluated at the post-contingency operating point)
  - Apply Filter 2 (sensitivity pruning) from the architecture note above,
    separately for PST (`sensitivity_threshold_pct_pst_nx`) and RD
    (`sensitivity_threshold_pct_rd_nx`) — per (branch, contingency, RA) triple,
    never dropping the branch itself
  - Restore the network to the N-0 state after each contingency:
    ```python
    network.update_lines(id=equipment_mrid, connected1=True, connected2=True)
    # or update_2_windings_transformers for transformer contingencies
    ```
    **Critical:** always restore — failure to restore propagates the contingency
    topology into the next contingency's LF, producing silently wrong results.

**Inputs:**
- `network` (pypowsybl `Network` from R0.1)
- `lf_initial` (from R1.1 — single-timestamp, not indexed by `t`)
- `must_study` (from `COFlatList`, R0.5 — the `mustStudy` flag per contingency for
  the single active timestamp; **not** from R2, which does not produce this field)
- `COFlatList` (from R0.5)
- `PSTList` (from R0.6, using PowerTransformer mRIDs — both preventive and curative)
- `RDList` (from R0.7 — both preventive and curative), `AEFlatList` (from R0.4)
- `ScannedElementList` (from R0.9 — `effective_limit` per scanned branch per timestamp)
- Branch side is read from each branch's already-resolved
  `AssessedElement.branch_side` attribute (set in R0.4) — **not** passed as a
  separate `current_limit_side_map` parameter, despite earlier drafts of this
  document implying that. See "R3 implementation notes" above.
- `min_loading_threshold_pct_nx`, `sensitivity_threshold_pct_pst_nx`,
  `sensitivity_threshold_pct_rd_nx` — see "Architecture note: unified N-X branch
  candidate set" above

**Confirmed real function signatures (as implemented, not the earlier
pseudocode draft):**
```python
compute_sensitivity_pst_nx(network, co_flat_list, pst_list, ae_flat_list, timestamp,
    lf_nx, lf_initial, min_loading_threshold_pct_nx=0.0, output_path=None)
compute_sensitivity_rd_nx(network, co_flat_list, rd_list, ae_flat_list, timestamp,
    lf_nx, lf_initial, min_loading_threshold_pct_nx=0.0, output_path=None)
prune_sensitivity_pst_nx(sensitivity_pst_nx, limit_by_branch,
    sensitivity_threshold_pct_pst_nx=0.0)
prune_sensitivity_rd_nx(sensitivity_rd_nx, limit_by_branch,
    sensitivity_threshold_pct_rd_nx=0.0)
_get_limit_by_branch_nx(ae_flat_list, timestamp, lf_initial)
    # -> dict[branch_mrid, limit_ampere]; lazy-imports
    # milp_builder._get_monitored_branch_limits_and_ae_types (R2.12's own helper)
    # rather than duplicating the effective_limit formula a second time
```
Filter 1 is implemented as **post-hoc filtering** — sensitivity is computed for
every monitored branch per contingency (unconditionally, via the existing
batched `add_factor_matrix` call per contingency/side — a confirmed workaround
for a live pypowsybl `ArrayIndexOutOfBoundsException` that made restricting the
API call itself too risky to touch), and branches failing Filter 1 are then
dropped from the *output* dict. The final result is identical to restricting
the API call itself; the computation cost of evaluating a few extra branches on
this dataset's scale (11 contingencies, 14 branches) is negligible against the
risk of destabilising a confirmed-working batching workaround.

**`NxMilpInputs.sensitivity_pst_nx`/`sensitivity_rd_nx` hold the *pruned*
values, not raw** — a deliberate choice to avoid touching
`milp_builder.py`'s existing `_nx_pst_and_rd_effect` closure at all. The caller
(`run_pipeline.py`, tests) passes the already-pruned dicts into these field
names; the raw, unpruned dicts remain available as intermediate values inside
`nx_sensitivity.py` for CSV export and debugging, never stored on the
dataclass itself. `sensitivity_threshold_pct_pst_nx`/`sensitivity_threshold_pct_rd_nx`
are consumed entirely upstream of `NxMilpInputs` and do not live on it.

**Outputs:**
- `sensitivity_pst_nx: dict[t, dict[c_mrid, dict[(branch_mrid, pst_mrid), float]]]`
  (in-memory, **raw A/degree** — the degrees-per-tap conversion to A/tap happens
  later, inside `_add_pst_block` in `milp_builder.py`, matching R1.2's actual
  behaviour, not at sensitivity-computation time as earlier drafts of this document
  implied — see "R3 implementation notes" above). Covers both `AEType.SECURED` and
  `AEType.SCANNED` branches passing Filter 1 (see architecture note above).
- `sensitivity_rd_nx: dict[t, dict[c_mrid, dict[(branch_mrid, gu_mrid), float]]]`
  (in-memory, A/MW). Same combined-type coverage as above.
- `sensitivity_pst_nx_pruned`, `sensitivity_rd_nx_pruned` — same shape as above,
  after Filter 2 pruning per (branch, contingency, RA) triple
- `lf_nx: dict[t, dict[c_mrid, dict[branch_mrid, dict[int, float]]]]` — **dual-sided
  per branch** (`{1: i1, 2: i2}`, matching `build_lf_initial`'s existing shape), not
  a single value per branch
- `sensitivity_pst_nx.csv` (was `sensitivity_nx.csv`): columns `[timestamp, contingency_mrid, branch_mrid, branch_name,
  ae_type, pst_mrid, side, di_ds_ampere_per_degree]` — `ae_type` column added to
  distinguish `secured`/`scanned` rows. **Confirmed real column name via
  `inspect`-level verification against live code**: originally shipped as
  `di_ds_ampere_per_tap`, which mislabeled the unit (values are raw A/degree,
  converted to A/tap later inside `_add_pst_block`) — corrected.
- `sensitivity_rd_nx.csv`: columns `[timestamp, contingency_mrid, branch_mrid,
  branch_name, ae_type, gu_mrid, tso, side, di_dp_ampere_per_mw]` (added proactively,
  not in earlier drafts of this document; `ae_type` column added alongside the
  unified candidate set). **Confirmed real column name**: originally shipped as
  `di_da_ampere_per_mw` with `branch_name`/`tso` absent entirely — corrected to
  match R2.1's N-0 RD sensitivity CSV convention.
- `lf_nx_initial.csv`: columns `[timestamp, contingency_mrid, branch_mrid, branch_name,
  tso, ae_type, side, i_ka, loading_pct, limit_ka, converged]` — `limit_ka` replaces
  `patl_ka`, since scanned rows report `effective_limit`, not `patl`.

  **⚠ Confirmed real gap found during CSV verification, more consequential than a
  naming mismatch — same bug category as R4.7's `results_rd_multits.csv` finding.**
  `write_lf_nx_csv`'s original body hardcoded `["", side, i_ka, "", "", "TRUE"]` for
  every row, unconditionally — `tso`, `loading_pct`, and `patl_ka` were never
  computed at all, for any row, ever. This was not a "wrong value" bug (no row
  was reporting an incorrect number) — it was an "always-blank placeholder" gap,
  undetected because nothing had ever asserted on the actual field values, only
  that the file existed with the expected column headers. **This is the second
  confirmed instance of this failure mode in this project** (the first being
  R4.7's `results_rd_multits.csv` shipping blank `price_eur_mw`/
  `rd_penalty_factor`/`penalty_cost_eur`/`rd_cost_eur` columns) — worth treating
  as its own named risk going forward: *a CSV schema can look complete and still
  ship hardcoded placeholder constants instead of real computation, invisible to
  any test that only checks the file exists or has the right headers.*

  **Fixed properly, not cosmetically**: `compute_lf_nx` gained a new optional
  `lf_initial` parameter (trailing, defaulting to preserve the prior blank
  behaviour for any caller that doesn't pass it — zero blast radius to existing
  callers), resolving real `ae_type`/`limit_ka`/`loading_pct`/`tso` via a new
  helper `_get_limit_and_ae_type_by_branch_nx` (built alongside
  `_get_limit_by_branch_nx`, whose own MD-confirmed signature was left
  untouched). **Proven with a deliberately unambiguous test**
  (`test_scanned_branch_loading_pct_computed_against_effective_limit_not_patl`):
  a scanned branch is given `effective_limit_ka=2000` and `patl_ka=1000` so that
  the two possible results (45% vs 90%) cannot be confused with each other —
  a much stronger proof than checking the field is merely non-null, mirroring
  the same design used for the `raart` wiring test (non-default value chosen
  specifically so "correct" and "wrong" outcomes are visibly distinct).
- Console log: contingencies skipped (non-convergent or network split) per timestamp;
  candidate/pruned pair counts per Filter 1/Filter 2, broken down by `ae_type`
  (all three `compute_*` functions log a `[N secured, M scanned]` breakdown)

**Acceptance criteria:**
- Given a contingency that removes a single line from the network,
- When the N-X LF is run via pypowsybl,
- Then `lf_nx[t][c_mrid]` contains non-zero currents for all remaining branches
  AND the removed line's current entry is absent (or zero)
  AND the network is restored to N-0 topology for the next contingency
  AND side-1 and side-2 branches use separate sensitivity matrix calls.
- Given the real Belgovia CO3 contingency (`equipment_type == 'gen'`, tripping
  `BO-G2`),
- When N-X analysis is run with `ENABLE_NX_ANALYSIS=True`,
- Then CO3 is applied (generator disconnected, AC LF re-run) rather than
  silently skipped with a "not found in CGM" message — confirming the R0.5/R3.1
  equipment-type scope widening is genuinely reachable on real data, not just
  theoretically supported.
- Given a scanned branch and a secured branch both pass Filter 1 under the same
  contingency,
- When `sensitivity_pst_nx`/`sensitivity_rd_nx` are inspected,
- Then both branches have sensitivity entries computed via the same code path,
  each compared against its own correct limit (`patl` vs `effective_limit`) —
  no branch is silently missing sensitivity data due to its AE type.
- Given a branch passes Filter 1 but every RA's sensitivity on it is pruned by
  Filter 2,
- When the MILP is built,
- Then that branch still receives a loading constraint (slack-only, no adjustable
  RA terms) — it is not dropped from the model.
- Given a scanned branch with `effective_limit_ka=2000` and `patl_ka=1000` for the
  same branch (deliberately different values so the two possible outcomes are
  unambiguous),
- When `lf_nx_initial.csv`'s `loading_pct` is computed for that branch,
- Then it is computed against `effective_limit_ka` (yielding the result
  consistent with 2000, not 1000) — confirming `lf_nx_initial.csv` reports real,
  correctly-sourced values, not the hardcoded placeholder blanks
  (`tso`, `loading_pct`, `patl_ka` as `""`/`""`/`""`) it previously shipped
  unconditionally for every row.

**Dataset note:** `must_study` flags come from `{TSO}_CO.xml` at the active
timestamp's `atTime` (parsed in R0.5). Only contingencies where `must_study == True`
are evaluated. On the current ReliCapGrid dataset, confirm which contingencies have
`mustStudy == True` before assuming coverage — do not assume all contingencies are
studied.

---

## R3.2 — N-X loading constraints in MILP (CORNET-1790 extended, CORNET-16)

**Spec ref:** CORNET-1790 — XNEs in MILP (N-X extension);
CORNET-16 — Consideration of Congestions

**Scope note (confirmed already correct in the implementation — only this
document's earlier text was imprecise):** this increment applies to
`AEType.SECURED` branches only — `patl[b][t]` is the correct limit for secured
XNEs, not for scanned elements. **Verified directly against live code:**
`_add_nx_block`'s PATL constraint was already restricted to `AEType.SECURED`
before any of the work described in the architecture note above — earlier
drafts of *this document* stated the constraint applied to `AEFlatList`
uniformly with no type distinction, but that was inaccurate about the code, not
a real defect that needed fixing. See "Architecture note: unified N-X branch
candidate set" above for what was actually missing (Filter 1, Filter 2, and
R3.2a as the consumer of scanned-branch data), and R3.2a below for the
equivalent scanned-element constraint using `effective_limit`.

**What it delivers:**
- For each (contingency `c`, branch `b`, timestamp `t`) where `b` is
  `AEType.SECURED` and passed Filter 1 (`lf_nx[t][c][b] / patl[b][t] ≥
  min_loading_threshold_pct_nx` — **note the `_nx` suffix**, this is the N-X-specific
  threshold, independent from N-0's `min_loading_threshold_pct`):
  add a soft N-X PATL loading constraint to the Pyomo model, using the
  Filter-2-pruned sensitivities:
  ```
  lf_nx[t][c][b] + Σ_τ sensitivity_pst_nx_pruned[t][c][b,τ] · tap_change_τ(t)
                 + Σ_g sensitivity_rd_nx_pruned[t][c][b,g] · rd_net_injection_g(t)
                 ≤ patl[b][t] + nx_patl_overload_slack[t,b,c]
  ```
  with `nx_patl_overload_slack[t,b,c] ≥ 0` penalised by
  `penalty_cost_overload_nx_patl` in the objective
- All currents and PATLs are side-aware
- Both filters (loading, sensitivity) are applied upstream in R3.1, per the
  architecture note above — this increment consumes the already-pruned result,
  it does not re-apply pruning itself

**Naming note:** Use `nx_patl_overload_slack`, `penalty_cost_overload_nx_patl`,
`min_loading_threshold_pct_nx` — not `slack_nx_PATL`, `c_slack_nx_PATL`,
`min_loading_threshold_pct` (that name is reserved for the N-0 threshold, a
distinct control parameter).

**Inputs:**
- `sensitivity_pst_nx_pruned[t][c]`, `sensitivity_rd_nx_pruned[t][c]`, `lf_nx[t][c]`
- `AEFlatList` (PATL values via `patl` dict), filtered to `AEType.SECURED`
- RAO control parameters: `penalty_cost_overload_nx_patl: float`,
  `min_loading_threshold_pct_nx: float`

**Outputs:**
- Updated `milp_model` with N-X PATL constraints (secured branches only)
- Console log: number of (branch, contingency, timestamp) constraints added

**Acceptance criteria:**
- Given a contingency that causes a secured branch to exceed PATL and a PRA
  exists that can relieve it,
- When the MILP is solved,
- Then the linearised N-X loading for that branch is ≤ PATL
  (i.e. `nx_patl_overload_slack == 0`) OR the PRA cost exceeds the slack penalty
  and the slack is positive.
- Given a scanned branch under the same conditions,
- When this increment's constraint-building runs,
- Then no `nx_patl_overload_slack` constraint is created for it — scanned
  branches are handled exclusively by R3.2a below.

---

## R3.2a — N-X scanned-element loading constraints (CORNET-439 extended to N-X)

**Spec ref:** CORNET-439 — Scanned Elements (N-0 version in R2.12); extended here
to the N-X/per-contingency case per the architecture note above.

**Implementation note:** built **inline inside the existing `_add_nx_block`**,
not as a separate top-level function — reuses the same `_nx_pst_and_rd_effect`
closure `_add_nx_block` already uses for the secured-branch constraint, rather
than duplicating roughly 80 lines of curative/linkage logic a second time. R3.2a
is a conceptually distinct increment for spec and documentation purposes (its
own constraint, its own CSV, its own acceptance criteria below) but not a
structurally separate function in the code — the same kind of implementation
choice as R3.1's native batch API replacing the originally-drafted manual loop.
Always builds, even producing an empty Pyomo `Set` when there are no scanned
branches — matching R3.2's PATL pattern (always present) rather than R3.3's
TATL pattern (only present when a TATL is actually defined for a branch), since
R3.2a's existence does not depend on any per-branch optional data the way TATL
does.

**What it delivers:**
- For each (contingency `c`, branch `b`, timestamp `t`) where `b` is
  `AEType.SCANNED` and passed Filter 1
  (`lf_nx[t][c][b] / effective_limit[b][t] ≥ min_loading_threshold_pct_nx`):
  add a soft N-X scanned-element constraint, structurally identical to R3.2's
  secured-branch constraint (preventive + curative terms summed together, same
  as R3.2) but comparing against `effective_limit` instead of `patl`:
  ```
  lf_nx[t][c][b] + Σ_τ sensitivity_pst_nx_pruned[t][c][b,τ] · tap_change_τ(t)
                 + Σ_g sensitivity_rd_nx_pruned[t][c][b,g] · rd_net_injection_g(t)
                 ≤ effective_limit[b][t] + nx_scanned_overload_slack[t,b,c]
  ```
  with `nx_scanned_overload_slack[t,b,c] ≥ 0` penalised by
  `penalty_cost_overload_nx_scanned` in the objective
- **No TATL-equivalent applies to scanned elements** — TATL (CORNET-1792, R3.3)
  is defined specifically for branches the RAO is securing to PATL; scanned
  elements have only the one `effective_limit` ceiling. This is a confirmed
  modelling decision, not an oversight.
- All currents and limits are side-aware, same as R3.2

**Naming note:** Use `nx_scanned_overload_slack`, `penalty_cost_overload_nx_scanned`
— following the same naming pattern as R3.2's `nx_patl_overload_slack`,
`penalty_cost_overload_nx_patl`. Confirmed real model attribute names:
`model.nx_scanned_branch_contingency_pairs` (the Pyomo `Set`),
`model.nx_scanned_overload_slack`, `model.nx_scanned_loading`.

**Inputs:**
- `sensitivity_pst_nx_pruned[t][c]`, `sensitivity_rd_nx_pruned[t][c]`, `lf_nx[t][c]`
- `ScannedElementList` (from R0.9 — `effective_limit` per branch per timestamp),
  filtered to `AEType.SCANNED`
- RAO control parameter: `penalty_cost_overload_nx_scanned: float`
  (`min_loading_threshold_pct_nx` is shared with R3.2 — same Filter 1 threshold
  applies to both AE types, only the limit compared against differs)
- `NxMilpInputs` gains exactly one new field to carry this parameter:
  `penalty_cost_overload_nx_scanned: float = 0.0`

**Outputs:**
- Updated `milp_model` with N-X scanned-element constraints
- `results_nx_scanned_elements.csv`: columns `[timestamp, contingency_mrid,
  branch_mrid, branch_name, tso, side, effective_limit_ka, loading_before_rao_ka,
  loading_after_rao_ka, slack_ka]`, written by
  `export_nx_scanned_elements_csv(model, ae_flat_list, co_flat_list,
  lf_nx_initial, sensitivity_pst_nx, sensitivity_rd_nx, pst_degrees_per_tap,
  branch_limits, timestamp, output_path, branch_mrid_to_name=None)` in
  `post_milp/nx_results_export.py`, reusing the same linearised-effect helper
  R3.9's export module already uses
- Console log: number of (scanned branch, contingency, timestamp) constraints added

**Acceptance criteria:**
- Given a scanned branch with `effective_limit_ka = 1.1` under a contingency
  causing `lf_nx = 1.2 A`, with a PRA available that can resolve it,
- When the MILP is solved,
- Then the post-optimisation linearised loading for that branch under that
  contingency does not exceed `1.1 ka` (i.e. `nx_scanned_overload_slack == 0`)
  OR the slack is positive with a corresponding penalty contribution.
- Given the same scanned branch,
- When the model is inspected for a TATL-equivalent constraint,
- Then none exists — scanned elements have exactly one N-X constraint, not two.
- Given the confirmed real dataset (0 scanned AEs — 14 `SECURED`, 0 `SCANNED`,
  0 `EXCLUDED`),
- When `ENABLE_NX_ANALYSIS=True` is run against real data,
- Then `results_nx_scanned_elements.csv` is written header-only, matching the
  established GLSK/power-bid/CRA precedent for correctly-computed-empty
  results on this dataset cut — not skipped, not erroring.

---

## R3.3 — TATL constraint for N-X (CORNET-1792)

**Spec ref:** CORNET-1792 — Consideration of one TATL

**Scope note (explicit, confirmed):** applies to `AEType.SECURED` branches only.
Scanned elements have no TATL-equivalent — see R3.2a's own note and the
"Architecture note: unified N-X branch candidate set" above for the confirmed
reasoning (TATL is defined for branches being secured to PATL; scanned elements
have only `effective_limit`).

**On defense-in-depth vs. an actual bug (verified, not assumed):**
`compute_tatl_data`'s own candidate-branch comprehension excludes scanned
branches structurally — a scanned branch's mRID can never become a key in its
returned dict, by construction, not by a downstream filter. A defensive
`AEType.SECURED` check was added inside `_add_nx_block`'s TATL loop during this
extension, in case a future caller ever constructs `tatl_data` by some other
path than `compute_tatl_data`. **This was checked and confirmed to never have
been a real bug**: every real call site (`run_pipeline.py`,
`smoke_test_r3_nx_cra.py`) passes `compute_tatl_data`'s output straight into
`NxMilpInputs` with no intermediate construction or mutation anywhere in the
codebase. The only way a scanned branch could ever have appeared in
`tatl_data` was a test hand-constructing `NxMilpInputs` directly with a
fabricated dict — never a path any real pipeline run has ever taken. Recorded
here as an added safeguard, not as a fixed defect that ever produced wrong
output.

**~~Original text said "Parse `tatlLimit` (A) and `tatlDuration` (seconds) from
the EquipmentProfile" — superseded. In pypowsybl, TATL data is retrieved from
`network.get_operational_limits()` filtered to `acceptable_duration > 0`
(i.e. not permanent = not PATL). The PATL fallback in R0.4 already uses
`acceptable_duration == -1` for the permanent limit; TATL uses
`acceptable_duration > 0`.~~**

**What it delivers:**
- For each `AEType.SECURED` branch that has a TATL defined, retrieve it from pypowsybl:
  ```python
  limits_df = network.get_operational_limits()
  tatl_df = limits_df[
      (limits_df['type'] == 'CURRENT') &
      (limits_df['acceptable_duration'] > 0) &   # not permanent
      (limits_df.index.get_level_values('element_id') == branch_mrid)
  ]
  ```
  Extract `tatl_limit_ampere` (value column) and `tatl_duration_seconds`
  (`acceptable_duration` column)
- Use the branch's own resolved `branch_side` (from `AEFlatList`, R0.4 — not a
  separate `current_limit_side_map` parameter, per the correction in R3.1's
  Inputs) for the TATL lookup — TATL is side-specific just as PATL is
- If more than one TATL is defined for an XNE (multiple `acceptable_duration` > 0
  entries for the same branch on the same side), skip TATL for that XNE and log
  a WARNING (CORNET-1792: exactly one TATL expected in V1)
- Add a separate N-X TATL constraint to the Pyomo model, using the
  Filter-2-pruned sensitivities (same as R3.2):
  ```
  lf_nx[t][c][b] + Σ_τ sensitivity_pst_nx_pruned[t][c][b,τ] · tap_change_τ(t)
                 + Σ_g sensitivity_rd_nx_pruned[t][c][b,g] · rd_net_injection_g(t)
                 ≤ tatl_limit_ampere[b] + nx_tatl_overload_slack[t,b,c]
  ```
  `nx_tatl_overload_slack` penalised with `penalty_cost_overload_nx_tatl`
  (typically higher than PATL slack penalty)

**Naming note:** Use `tatl_limit_ampere`, `tatl_duration_seconds`,
`nx_tatl_overload_slack`, `penalty_cost_overload_nx_tatl` — not `tatlLimit`,
`tatlDuration`, `slack_nx_TATL`, `c_slack_nx_TATL`.

**Inputs:**
- `network` (pypowsybl `Network` — `network.get_operational_limits()` for TATL data)
- `AEFlatList` (for each branch's own resolved `branch_side`)
- `sensitivity_pst_nx_pruned`, `sensitivity_rd_nx_pruned`, `lf_nx`
- RAO control parameter: `penalty_cost_overload_nx_tatl: float`

**Outputs:**
- Updated `milp_model` with N-X TATL constraints
- `tatl_data.csv`: columns `[branch_mrid, branch_name, side, tatl_limit_ka,
  tatl_duration_seconds]`

**Acceptance criteria:**
- Given an XNE with `tatl_limit_ampere = 1200 A` and `patl = 1000 A`, and a
  contingency that causes `lf_nx = 1100 A`,
- When the MILP is solved with no CRA available,
- Then `nx_tatl_overload_slack == 0` (PRA-only loading ≤ TATL) if a PRA can resolve
  it, OR `nx_tatl_overload_slack > 0` with a corresponding penalty contribution
  to the objective.

---

## R3.4 — Curative PST RA parsing and reaction time (BUC14#110, CORNET-1978)

**Spec ref:** BUC14#110 — Consideration of PST as curative remedial actions;
CORNET-1978 — Reaction time for PST in curative mode

**~~Original text said "IAM files (RA profile)" — superseded. Parse from
`{TSO}_RA.xml` (NCP RA profile) using `NCP_FILES` registry from R0.3.~~**

**What it delivers:**
- Extend `PSTList` parsing (established in R0.6) to include curative PST entries:
  `kind == 'curative'`, `linked_contingency_mrids`, `linked_xne_mrids`,
  `time_per_stage_minutes` (PST speed in min/tap)
- Parse `pst_speed_curative_minutes_per_tap` and `reaction_time_minutes` from
  `{TSO}_RA.xml`
- Compute maximum tap change available within `tatl_duration_seconds`:
  ```python
  max_curative_taps = floor(
      (tatl_duration_seconds / 60 - reaction_time_minutes) / time_per_stage_minutes
  )
  ```
  If result ≤ 0: CRA not available for that XNE
- Build `pst_cra_availability: dict[(pst_mrid, xne_mrid, co_mrid), {"max_curative_taps", "available"}]` (in-memory key order; `xne_mrid` = every secured branch with a TATL)
- **mRID note:** `pst_mrid` here is the `PowerTransformer` mRID (as used by pypowsybl),
  not the TapChanger mRID. Use `ncp_parser.build_tap_changer_to_transformer_map()`
  consistently.

**Naming note:** Use `time_per_stage_minutes`, `reaction_time_minutes`,
`max_curative_taps`, `pst_speed_curative_minutes_per_tap`, `pst_cra_availability`,
`linked_contingency_mrids`, `linked_xne_mrids` — not `timePerStage`,
`PSTSpeedCurative`, `PST_CRA_availability`, `linkedContingencies`, `linkedElements`.

**Inputs:**
- `{TSO}_RA.xml` files (from `NCP_FILES`) — curative PST entries, `time_per_stage_minutes`,
  `reaction_time_minutes`, linked contingencies/elements
- `tatl_data` (from R3.3)

**Outputs:**
- Extended `PSTList` with curative entries (in-memory)
- `pst_cra_availability.csv`: columns `[pst_mrid, branch_mrid, contingency_mrid,
  max_curative_taps, available]` (the in-memory key `xne_mrid` is written as `branch_mrid`, `co_mrid` as `contingency_mrid`; `cra_preprocessing.py:161–175`)

**Acceptance criteria:**
- Given a curative PST with `time_per_stage_minutes = 2` and an XNE with
  `tatl_duration_seconds = 300` (5 min) and `reaction_time_minutes = 3`,
- When availability is computed,
- Then `max_curative_taps = floor((5 - 3) / 2) = 1` AND `available == True`.

**Dataset note:** All PST RAs in the current ReliCapGrid NCP dataset are curative —
this increment should find real entries to work with (unlike R1/R2/R3 which had
zero preventive PST RAs without a diagnostic override).

---

## R3.5 — Curative PST variables and MILP constraints (CORNET-1985, SF3074)

**Spec ref:** CORNET-1985 — Limitations of PST in curative mode;
SF3074 — Group constraints for PST in curative mode

**Composability note:** Curative PST variables and constraints are only added when
`pst_inputs is not None` (i.e. `enable_pst_remedial_actions=True`) — same
`hasattr`-gating discipline as R2.4/R2.5. A workflow with PST disabled has no
curative PST variables either.

**What it delivers:**
- For each (curative PST `τ`, contingency `c`) pair where
  `pst_cra_availability[(pst_mrid, xne_mrid, co_mrid)] == True`:
  add per-contingency curative tap variables to the Pyomo model:
  - `curative_tap_change_upward[t, pst_mrid, c_mrid]` ≥ 0
  - `curative_tap_change_downward[t, pst_mrid, c_mrid]` ≥ 0
- Curative tap bounds (combined preventive + curative must stay within curative limits):
  ```
  curative_tap_min ≤ current_tap + tap_change_τ(t)
                   + curative_tap_change_upward[t,τ,c]
                   - curative_tap_change_downward[t,τ,c]
                   ≤ curative_tap_max
  ```
  Curative limits may differ from preventive limits — parsed from `{TSO}_RA.xml`
  curative `RangeConstraint`
- Curative tap magnitude limit per (PST, XNE):
  `curative_tap_change_upward + curative_tap_change_downward ≤ max_curative_taps[τ, xne]`
- CRA linkage (when `activate_cra_xne_linkage == True`, default False):
  only include curative PST `τ` in the N-X loading constraint for XNE `b` if
  `(pst_mrid, b)` is in `linked_xne_mrids` (BUC14#112)
- N-X PATL loading constraint updated to include curative PST terms:
  ```
  lf_nx[t][c][b]
    + Σ_τ sensitivity_pst_nx[t][c][b,τ]
      · (tap_change_τ(t) + curative_tap_change_upward[t,τ,c]
         - curative_tap_change_downward[t,τ,c])
    + Σ_g sensitivity_rd_nx[t][c][b,g] · rd_net_injection_g(t)
    ≤ patl[b][t] + nx_patl_overload_slack[t,b,c]
  ```

**Naming note:** Use `curative_tap_change_upward`, `curative_tap_change_downward`,
`curative_tap_min`, `curative_tap_max`, `activate_cra_xne_linkage` — not
`dr_cur_pos`, `dr_cur_neg`, `r_cur_min`, `r_cur_max`, `activateLinkCRA_XNE`.
Also use `pst_tap_bounds_curative` for the curative bounds dict, not `pst_bounds`.

**Inputs:**
- `pst_cra_availability` (from R3.4)
- `sensitivity_pst_nx` (from R3.1)
- `pst_tap_bounds_curative: dict[pst_mrid, (curative_tap_min, curative_tap_max)]`
  — parsed from `{TSO}_RA.xml` curative `RangeConstraint`
- RAO control parameter: `activate_cra_xne_linkage: bool` (default False)

**Outputs:**
- Updated `milp_model` with curative PST variables and constraints
- `results_pst_cra.csv`: columns `[pst_mrid, pst_name, tso, timestamp,
  contingency_mrid, curative_tap_change, current_tap_position,
  result_tap_position_preventive, result_tap_position_curative, penalty_cost_eur]`

**Acceptance criteria:**
- Given a curative PST linked to contingency CO1 only,
- When the MILP is solved and CO1 causes an overload,
- Then the curative tap change appears only in the CO1 N-X loading constraint
  AND `|curative_tap_change_upward - curative_tap_change_downward| ≤ max_curative_taps`.

---

## R3.6 — Curative RD RA variables and MILP constraints (BUC14#106, CORNET-4614)

**Spec ref:** BUC14#106 — Consideration of redispatch RA in curative mode;
CORNET-4614 — PRAs and CRAs for same generating unit

**Composability note:** Curative RD variables and constraints are only added when
`rd_inputs is not None` (i.e. `enable_rd_remedial_actions=True`) — same
`hasattr`-gating discipline as R2.4/R2.5. This applies regardless of whether R5's
`enable_rd_generator_physics` flag is set — CRA is available in both Simple RD and
Full RD workflows (R5's physics constraints apply only to the preventive component,
per CORNET-4614's own "Outlook" note deferring gradient-type limits on combined
PRA+CRA dispatch to a later release — see R5's cross-cutting section for the
full explanation once R5 is implemented).

**What it delivers:**
- For each curative RD RA in `RDList` (`kind == 'curative'`):
  add per-contingency curative RD variables to the Pyomo model:
  - `curative_rd_volume_upward[t, bid_mrid, c_mrid]` ≥ 0
  - `curative_rd_volume_downward[t, bid_mrid, c_mrid]` ≥ 0
  bounded by `max_curative_rd_volume_upward` and `max_curative_rd_volume_downward`
  from `PowerBidList`
- CRA availability: generating unit must be in operation at timestamp `t`
  (`initial_production[g] > 0` from `network.get_generators()` `target_p` column);
  if not, fix `curative_rd_volume_upward = curative_rd_volume_downward = 0`
- CRA linkage: same logic as PST CRA in R3.5 (`linked_contingency_mrids`,
  optional `linked_xne_mrids`)
- Combined Pmax/Pmin constraint for units appearing in both a PRA and a CRA
  (CORNET-4614):
  ```
  pmin[g] ≤ initial_production[g] + rd_adjustment_upward[g,t]
            + curative_rd_adjustment_upward[g,t,c]
            - rd_adjustment_downward[g,t]
            - curative_rd_adjustment_downward[g,t,c]
            ≤ pmax[g]
  ```
- N-X PATL loading constraint updated to include curative RD terms:
  ```
  lf_nx[t][c][b]
    + Σ_τ sensitivity_pst_nx · (tap_change_τ + curative_tap_change_τ^c)
    + Σ_g sensitivity_rd_nx · (rd_net_injection_g + curative_rd_net_injection_g^c)
    ≤ patl[b][t] + nx_patl_overload_slack[t,b,c]
  ```
- Curative objective cost: maximum over contingencies approach (SF3077 eq. 3.40–3.44):
  implemented via auxiliary variable `max_curative_rd_volume_upward[t,bid]` with
  `max_curative_rd_volume_upward ≥ curative_rd_volume_upward[t,bid,c]` for all `c`
  — this is a Pyomo constraint, not a HiGHS-specific construct

**Naming note:** Use `curative_rd_volume_upward`, `curative_rd_volume_downward`,
`curative_rd_adjustment_upward`, `curative_rd_net_injection_g`,
`max_curative_rd_volume_upward` — not `dP_cur_pos`, `dP_cur_neg`, `max_cur_pos`.
Use `max_curative_rd_volume_upward` and `max_curative_rd_volume_downward` from
`PowerBidList` — not `posAvailableCurRDVolume`, `negAvailableCurRDVolume`.

**Inputs:**
- `RDList` (curative entries from R0.7)
- `PowerBidList` (curative volumes from R0.7, parsed from `{TSO}_SIS.xml`)
- `glsk` (from R2.3 — the same participation factor mapping used for preventive RD;
  curative RD reuses the same generating-unit linkage, not a separate GLSK)
- `sensitivity_rd_nx` (from R3.1)
- `lf_nx` (from R3.1)
- `network` (pypowsybl `Network` — `network.get_generators()` for `target_p`,
  `max_p`, `min_p`)

**Outputs:**
- Updated `milp_model` with curative RD variables and constraints
- `results_rd_cra.csv`: columns `[ra_mrid, bid_mrid, tso, timestamp, contingency_mrid,
  curative_rd_volume_net_mw, reservation_cost_eur, penalty_cost_eur]`

**Acceptance criteria:**
- Given a curative RD unit with `initial_production = 0` at timestamp `t`,
- When the MILP is solved,
- Then `curative_rd_volume_upward[t, bid, c] == 0` for all contingencies `c`
  AND a unit with `initial_production > 0` can be activated curatively up to
  its `max_curative_rd_volume_upward`.

---

## R3.7 — N-X system constraints per contingency (CORNET-498, CORNET-537 N-X extension)

**Spec ref:** CORNET-498 — System Constraints with active power limits;
CORNET-537 — System Constraints with current limits (N-X extension)

**Note:** Parsing of `PowerTransferCorridors` is done in R6.8. This increment adds
the N-X MILP constraint loop using the already-parsed corridor data. Implement R6.8
parsing first, then return here to add the N-X constraint formulation.

**What it delivers:**
- For each system constraint corridor `k` and each contingency `c` per timestamp `t`:
  extract corridor flow from `lf_nx[t][c]`:
  `corridor_flow_nx[k,c,t] = Σ_{b ∈ corridor} lf_nx[t][c][b]` (A or MW per corridor type)
- Apply passive management per contingency:
  `effective_corridor_max_nx = max(corridor_max, corridor_flow_nx[k,c,t])`
  `effective_corridor_min_nx = min(corridor_min, corridor_flow_nx[k,c,t])`
- Add soft or hard Pyomo constraint per (corridor, contingency, timestamp):
  `effective_corridor_min_nx ≤ Σ_{b} post_RA_flow[b,t] ≤ effective_corridor_max_nx`
  with optional `system_constraint_nx_slack[t,k,c]` penalised by
  `system_constraint_penalty`

**Naming note:** Use `corridor_flow_nx`, `effective_corridor_max_nx`,
`effective_corridor_min_nx`, `system_constraint_nx_slack`, `system_constraint_penalty`
— not `F_k^c`, `F_max_eff^c`, `slack_SC_NX`.

**Inputs:**
- `PowerTransferCorridors` data (parsed in R6.8 — forward reference)
- `lf_nx[t][c]` (from R3.1)
- RAO control parameters: `system_constraint_soft: bool`, `system_constraint_penalty: float`

**Outputs:**
- Updated `milp_model` with per-contingency corridor constraints
- Extended `results_system_constraints.csv` with columns `[contingency_mrid,
  corridor_flow_nx_before_rao, corridor_flow_nx_after_rao, slack_nx]`

**Acceptance criteria:**
- Given a corridor with `corridor_max = 500 MW` and a contingency that raises
  corridor flow to `480 MW`,
- When the MILP is solved as a hard N-X system constraint,
- Then the post-RA corridor flow for that contingency does not exceed `500 MW`
  AND if the pre-contingency flow already exceeds `500 MW`, the effective limit is
  set to the pre-contingency flow (passive management).

---

## R3.8 — Completeness iteration loop (CORNET-16)

**Spec ref:** CORNET-16 — Consideration of Congestions (completeness iterations)

**✓ Completeness loop stale-baseline bug — confirmed fixed** (see "R3
implementation notes" above for full detail, including the exact verification
against live code). Previously, when the loop found zero new congestions, it
mutated `lf_nx` to the fresh post-RA baseline but returned **without rebuilding
the model against it** — the returned model could reflect the stale iteration-0
baseline. Confirmed fixed: the model now rebuilds unconditionally on every
iteration, covered by `test_stops_after_one_rebuild_when_no_new_congestions_found`.

**⚠ Correction to an earlier claim in this MD:** an earlier draft attributed
the `AEType.SECURED`-only restriction to `compute_lf_nx` itself. That was
wrong — `compute_lf_nx` genuinely covers both `AEType.SECURED` and
`AEType.SCANNED` (via `_get_monitored_branch_sides_nx`). The `SECURED`-only
restriction belongs to a different function, `compute_tatl_data`. This
conflation was caught and corrected during the investigation described below.

**⚠ SNEC (scanned N-X elements) never re-evaluated by the completeness loop —
confirmed real, spec-traceable, and now fixed. Three findings and fixes,
recorded in the order they were actually discovered, including two real
process near-misses worth preserving as their own lessons, not smoothed into
a clean narrative.**

**Spec basis, confirmed directly:** CORNET-439 (Scanned Elements) states
scanned elements follow *"the same approach as used for the modelling of XNEs
within the RAO"* — cross-referenced in the spec document as "CORNET-92," which
is itself a numbering artifact for what this document actually titles
**CORNET-1790: Consideration of XNEs in MILP** (the same kind of
cross-reference inconsistency already found once for "CORNET-13" →
CORNET-4850). CORNET-1790's own N-X section requires: *"These criteria are
evaluated in every outer iteration. In case optimised remedial actions will
lead to new relevant XNEC combinations, up to maxNumXNEC new combinations per
XNE are added to the optimisation problem per outer iteration. Already
considered constraints stay in the optimisation problem."* Confirmed the
completeness loop implements this for secured XNEC pairs, but had **zero
references to scanned elements anywhere** — SNEC was computed once from
`lf_nx_initial` and never re-evaluated, meaning `results_nx_scanned_elements.csv`
could report a picture stale relative to the pipeline's final converged state.

**Finding #1 (near-miss, proposed then reverted) — the stale-`lf_nx`-in-export
hypothesis was wrong.** Initial investigation found `run_pipeline.py`'s local
`lf_nx` variable assigned once, pre-RA, and never reassigned, feeding all
three N-X export functions (`export_nx_loadings_csv`,
`export_contingency_status_csv`, `export_nx_scanned_elements_csv`) as
`lf_nx_initial`. The variable name and single-assignment pattern looked like
exactly the staleness signature this project has caught twice before (the
`results_rd_multits.csv` and `lf_nx_initial.csv` blank-field bugs). **This was
wrong.** A fix was written and shipped — passing its own tests and a 447-test
full regression suite — before being caught. What actually caught it: a
request to prove the fix's *numeric* consequence, not just its mechanism,
forced a complete read of `export_nx_loadings_csv`'s own docstring, which
states explicitly: *"lf_nx_initial (R3.1's ORIGINAL pre-RA per-contingency
currents — NOT the completeness loop's mutated `nx_inputs.lf_nx`... the
caller must pass R3.1's own untouched result here)"* — because the export's
own math is a **linear extrapolation from a fixed pre-RA baseline**
(`i_ampere_post_pra = i_ampere_nx_initial + post_pra_effect`), not a value
meant to be swapped for an already-post-RA number. The proposed fix would have
made the `post_pra`/`post_pra_cra` columns double-count the RA's own effect.
**Reverted in full**, confirmed byte-identical to pre-change state, verified
against a 446-test regression suite, both smoke tests, and a direct
`run_pipeline.py` run. The test file was kept, not deleted — rewritten as a
permanent regression guard documenting exactly what was proposed, why it
looked plausible, and what a complete read of the consuming function's
contract actually revealed.

**The general lesson, worth stating precisely because it's narrower than "read
more code":** a genuinely correct heuristic (assigned-once-never-reassigned as
a staleness signal) was applied to a case that was an explicitly documented
exception to that heuristic. The heuristic itself isn't wrong — it caught real
bugs every other time it was used in this project. The gap was applying it
without first reading the consuming function's own stated contract in full.
A test written specifically to prove a fix works can only ever confirm the fix
matches the author's own mental model at the time of writing — it cannot
independently check whether that mental model was correct, because the
premise was never separately tested. A 447-test regression suite passing
confirmed only that nothing *else* in the codebase broke, not that the
fix's underlying premise was right.

**Finding #2 (confirmed active bug, not just theoretical) — `branch_limits` in
`run_completeness_check` used raw `patl_ka` for every AE type indiscriminately.**
Unrelated to Finding #1, and unaffected by its revert. This meant a scanned
branch could be silently, incorrectly flagged as new PATL-type congestion even
while genuinely under its real `effective_limit` — **confirmed as an active
defect in the current code path**, not a dormant risk waiting for scanned
bookkeeping to be added later. Fixed by restricting `branch_limits` to
`AEType.SECURED` only. A paired test confirms the intended `SECURED` case is
untouched by the filter, not just that the scanned false-positive is suppressed.

**Finding #3 (the actual fix, built on the corrected foundation) — SNEC
completeness bookkeeping added, mirroring the PATL/TATL pattern exactly.**
Before writing any new code, `export_nx_scanned_elements_csv` and
`export_contingency_status_csv` were read completely (the specific lesson from
Finding #1, applied) — confirming `export_nx_scanned_elements_csv` was
**already correct**: it reads scanned pairs directly from the final solved
model (`model.nx_scanned_branch_contingency_pairs`) and uses the pre-RA
baseline only for its own legitimate before/after linear-extrapolation
columns, mirroring `export_nx_loadings_csv`'s confirmed-correct design. **No
export-layer changes were needed for this fix.** `run_completeness_check` and
`run_completeness_loop` now track `current_scanned_pairs`/`new_scanned_pairs`
alongside the existing PATL/TATL tracking, using `effective_limit` — reused
directly from `milp_builder._get_monitored_branch_limits_and_ae_types` (the
same function the MILP's own scanned constraint already sources it from)
rather than reimplementing the formula a fourth time. Scanned counts folded
into `total_nx_constraints`/`results_completeness_iterations.csv`.

**A smaller, related process near-miss worth recording separately from
Finding #1's revert, not merged into it — a different failure shape, not the
same one at lighter severity.** The reuse of
`_get_monitored_branch_limits_and_ae_types` was initially justified by
signature-matching and "it's the same function the MILP already uses
successfully" — not by a complete read of that function against what
`run_completeness_check` specifically needed, the same discipline Finding #1
was supposed to have already established. When asked directly whether this
reuse had actually been verified the way the export function was, the honest
answer was no — it had been read once earlier in the work, for a
different purpose (explaining SNE/SNEC generally), and trusted by association
at the point of reuse. A complete line-by-line read, done under the question
rather than before shipping, confirmed the reuse was correct on every
dimension (units — returns Amperes, consistent with `post_ra_current`; AEType
classification — matches exactly; the `max(patl, initial_loading)` formula;
the `lf_initial` shape). The test's own asserted values were run back through
the real formula and matched exactly. **This is a distinct, smaller failure
shape from Finding #1: not "wrong conclusion, shipped, caught by proving the
consequence" but "correct conclusion, shipped, verification of *why* it was
correct happened only after being asked, not before."** Recorded as its own
entry because the two shapes call for different levels of scrutiny in future
reuse decisions — a future reader should be able to tell "was this checked
before or after it mattered" apart from "was the answer right or wrong."

**What it delivers:**
- After each MILP solve and post-solve LF (within the linearisation loop from R2.5),
  run a completeness check:
  - For each contingency `c` and timestamp `t`: apply the current RA solution to the
    pypowsybl network and re-run the per-contingency AC LF (same pattern as R3.1)
  - Check if any new (branch, contingency, timestamp) combinations are now congested
    that were not in the current MILP — for `AEType.SECURED` branches:
    `post_RA_lf_nx[t][c][b] > patl[b][t]`; for `AEType.SCANNED` branches:
    `post_RA_lf_nx[t][c][b] > effective_limit[b][t]` (Finding #3 above)
  - If new congestions found (either type): add their N-X constraints to the
    Pyomo model and re-solve (increment completeness iteration counter)
  - Stop when no new congestions are found OR `max_completeness_iterations` reached
- **Tap application note:** when applying the RA solution to the network for the
  completeness check, use `network.update_phase_tap_changers(id=pst_mrid, tap=int(round(...)))`
  with the `tap` kwarg — not `tap_position`. Restore after each contingency LF.
- **Stale baseline note:** refresh `lf_nx[t][c]` from the post-RA LF result at
  each completeness iteration — do not reuse stale values from a previous iteration.
  **This applies to the constraint-rebuild path only — the CSV export layer
  deliberately keeps a separate, fixed pre-RA baseline for its own linear
  extrapolation math (see Finding #1 above); do not conflate the two.**

**Naming note:** Use `max_completeness_iterations`, `current_scanned_pairs`,
`new_scanned_pairs` — not `MAX_COUNT_COMP_ITER`.

**Inputs:**
- `network` (pypowsybl `Network`)
- Current RA solution (tap positions and RD volumes from the MILP)
- `COFlatList` (from R0.5), `AEFlatList` (from R0.4)
- `must_study` (from `COFlatList`, R0.5)
- `lf_initial` (from R1.1 — needed for `effective_limit` computation via
  `_get_monitored_branch_limits_and_ae_types`, threaded through from
  `run_pipeline.py` where it was already in scope)
- RAO control parameter: `max_completeness_iterations: int` (default 5)

**Outputs:**
- Final `milp_model` after all completeness iterations
- Console log: per-iteration new constraint count (PATL, TATL, and scanned),
  final termination reason
- `results_completeness_iterations.csv`: columns `[completeness_iteration,
  new_constraints_added, total_nx_constraints]` — `total_nx_constraints` now
  includes scanned-pair counts, not PATL/TATL only

**Acceptance criteria:**
- Given a RAO run where applying PRAs creates a new N-X congestion not in the
  initial MILP,
- When the completeness loop runs,
- Then the new congestion is detected, its constraint is added, and the MILP
  re-solves to address it AND the loop terminates within `max_completeness_iterations`
  iterations.
- Given a scanned branch under its real `effective_limit` but over its raw
  `patl_ka`,
- When the completeness check runs,
- Then it is **not** flagged as new congestion — confirming Finding #2's fix
  discriminates correctly, not just suppresses a false positive by accident.
- Given a scanned branch genuinely over its `effective_limit`,
- When the completeness check runs,
- Then it **is** correctly flagged and its constraint added — proving the
  fix works in both directions, not just the negative case.
- Given `results_nx_loadings.csv`'s and `results_nx_scanned_elements.csv`'s
  `post_pra`/`post_pra_cra` columns,
- When inspected after a run with real RA activation,
- Then they reflect a linear extrapolation from the fixed R3.1 pre-RA
  baseline, matching each export function's own documented contract — this is
  correct behaviour, not staleness (see Finding #1 above; do not re-attempt
  the reverted fix without re-reading this note first).

**Finding #4 (a real symptom, one confirmed-wrong hypothesis, one real bug,
and one downstream gap the same root cause reproduces in a different
function) — `run_completeness_check` could evaluate zero contingencies even
though N-X sensitivity was confirmed correct and non-empty.** Recorded in the
order actually discovered, matching Findings #1–#3's own style, since the
path here is as instructive as the destination.

**Starting symptom:** `run_completeness_check` reported `0/16` must-study
contingencies usable, on a run where R3.1's own sensitivity computation had
already confirmed a real, non-trivial candidate set. The MILP's own preventive
solution — determined separately, via the AC verification loop documented in
this MD's R2.5 and R1.7 entries — proposed a real correction involving
multiple PSTs and RD units. Applying that correction and running
`compute_lf_nx` immediately afterward failed to converge, for every
contingency, every time.

**Hypothesis 1 (wrong, confirmed wrong by checking, not assumed) — a "tap
mismatch" between the AC verification loop's own final state and
`run_completeness_check`'s independently-solved result.** `run_completeness_loop`'s
own body begins with `model = build_and_solve_fn()` — a genuinely fresh MILP
build and solve, not a reuse of the AC verification loop's already-applied,
already-validated model. Comparing the two for agreement was comparing two
independently-solved problems that were never guaranteed to produce the same
optimum — a fresh solve landing on a different, equally valid solution (HiGHS's
own solve-path non-determinism, multiple optima) is not corruption. This was a
real red herring: real effort was spent chasing it, and it revealed nothing
about the actual `0/16` symptom, which was still present after "fixing" it.
**The lesson, stated precisely because it is not simply "read more code first"
the way Finding #1's lesson was:** a mismatch between two values is only
evidence of a bug if the two values were ever supposed to agree in the first
place — check that assumption before debugging toward eliminating the
mismatch.

**The real mechanism, found once the red herring was set aside and the
original `0/16` symptom was investigated directly:** `run_completeness_check`
applies its own freshly-solved PST/RD proposal to the network via a single,
direct `apply_preventive_solution_to_network` call, then immediately attempts
`compute_lf_nx` — no incremental fallback of any kind. This is structurally
the same large-single-step problem this release's own earlier investigation
(recorded in R2.5) found and fixed inside the AC verification loop itself — a
direct jump the flat-start AC solver cannot converge to — except
`run_completeness_check` never received the equivalent treatment. Confirmed,
not inferred: after implementing an explicit voltage-state snapshot and
incremental-ramp fallback for this function too (reusing the shared mechanism
originally built for the AC verification loop, not a second independent
implementation — see the *Post-RA Congestion Check Technical Reference* for
the full shared mechanism), the fallback itself succeeded, confirmed in its
own log output ("reached a converging base case in 5 steps").

**A second, distinct gap surfaced immediately after the first fix, in the
same investigation, not a separate one:** even with the fallback
succeeding and the base case confirmed converged, `compute_lf_nx` still
failed, still reporting `0/16`. Root cause: `compute_lf_nx`'s own internal
security-analysis solve is a separate computation from the direct AC load
flow the fallback uses to confirm convergence — it does not automatically
inherit the fallback's reached, warm-started voltage state, because nothing
told it to. Fixed by having `run_completeness_check` conditionally inject
`voltage_init_mode=PREVIOUS_VALUES` into the parameters passed to that one
`compute_lf_nx` call, specifically when the fallback was the reason the base
case converged (when the direct jump converges on its own, the parameters
are passed through unchanged). **The general principle this illustrates, worth
carrying into any future extension of this code:** a component's own local
convergence does not automatically propagate to a separately-invoked solve
downstream — each solve call needs its own explicit warm-start wiring; assuming
"the network is now in a good state, so the next solve will naturally benefit"
is not a safe assumption in this codebase, confirmed twice in one investigation
(once for the AC verification loop's own iteration handoff, once here).

**Confirmed resolved, with the real number, not an intermediate signal:**
`compute_lf_nx: 16/16 must-study contingencies usable (0 skipped)`. The
fallback's own log line reporting success was correctly treated as
insufficient evidence on its own — the investigation continued past it
specifically because the real, downstream number still said `0/16` at that
point, and stopping at "the fallback logged success" would have been the same
category of premature conclusion Findings #1–#3 already warned against, in a
new shape.

**A new typed status, matching the `AcVerificationStatus` precedent
deliberately, not reusing it:** `CompletenessCheckStatus`
(`EVALUATED`/`REVERTED_UNEVALUATED`) — a parallel enum, not a shared one, since
`run_completeness_check` is a single-shot check with no iteration-count
concept; forcing it into `AcVerificationStatus`'s four states (built around an
iterative loop) would have needed a state — an iteration-limit equivalent —
that genuinely does not apply here, repeating the exact category of dishonesty
`NOT_APPLICABLE` was introduced to avoid in the first place. **Currently
internal to `run_completeness_loop` only** — consumed for exactly two things
(gating the `nx_inputs.lf_nx` overwrite, described next, and a log line) and
does not currently reach `results_completeness_iterations.csv` or
`run_pipeline.py`. Flagged as a possible future visibility gap, not fixed as
part of this investigation — the same kind of explicitly-named, deliberately
deferred scope boundary as R4.3/R4.4's loop-integration deferral.

**A near-miss caught while wiring the new status in, not found independently
afterward:** `nx_inputs.lf_nx = post_ra_lf_nx` was unconditional prior to this
fix — meaning a `REVERTED_UNEVALUATED` outcome would have silently overwritten
a good, already-established `lf_nx` baseline with an empty result. Now guarded
on `CompletenessCheckStatus == EVALUATED`. Caught during implementation of the
status check itself, not discovered on a later pass — worth noting since it
demonstrates the new typed status earning its keep immediately, not just as
documentation.

**Shared-utilities consolidation, done as its own isolated step before any new
logic was added on top:** `_snapshot_bus_voltage_state`, `_restore_bus_voltage_state`,
`_run_ac_loadflow`, and the generalised `_apply_changes_incrementally`
(renamed from an AC-loop-specific name, domain-generalised) all moved to
`post_ra_congestion_check.py`, alongside the already-shared
`apply_preventive_solution_to_network`/`restore_network_state`/
`extract_pst_tap_solution`/`extract_rd_target_p_solution`. `ac_convergence_loop.py`
now imports all four rather than holding its own copies. The move's own
regression suite was run in isolation, immediately after the move and before
any completeness-check-specific logic was added — this caught two real
mistakes (an accidentally-deleted function from an overly broad find-replace,
and a pre-existing test needing its own mock updated for a call it didn't
know about) attributable unambiguously to the move itself, not conflated with
whatever came next.

**Regression:** 474 tests passing throughout every step of this investigation,
full pipeline confirmed clean end-to-end on the final state. See the *AC
Verification Loop Technical Reference* and the new *Post-RA Congestion Check
Technical Reference* for the current-state mechanics this investigation
produced.

---

## R3.9 — N-X results export (BUC14#142, BUC14#141 subset)

**Spec ref:** BUC14#142 — Results of contingency calculation;
BUC14#141 — Results of system constraints (N-X subset); prototype subset

**What it delivers:**
- Export per-contingency N-X results after final optimisation:
  - Per (contingency, branch, timestamp): initial loading (`lf_nx`), post-PRA
    linearised loading, post-PRA+CRA linearised loading, PATL, TATL (if defined),
    remaining overload slack values
  - Per contingency: pypowsybl convergence status, skipped flag and reason
  - Per (corridor, contingency, timestamp): N-X corridor flow before and after RA
- All current values in kA, all PATL/TATL values from the `patl` dict and
  `tatl_data` CSV (side-aware)

**Inputs:**
- Final Pyomo MILP solution
- `lf_nx` (from R3.1), `patl` (from R0.4), `tatl_data` (from R3.3)
- `AEFlatList` (from R0.4), `COFlatList` (from R0.5)

**Outputs:**
- `results_nx_loadings.csv`: columns `[timestamp, contingency_mrid, contingency_name,
  branch_mrid, branch_name, tso, side, i_ka_n0, i_ka_nx_initial,
  loading_pct_nx_initial, loading_pct_nx_post_pra, loading_pct_nx_post_pra_cra,
  patl_ka, tatl_ka, slack_patl, slack_tatl]` — **`AEType.SECURED` branches only**;
  scanned branches are reported separately in `results_nx_scanned_elements.csv`
  (R3.2a), which follows the same before/after/slack pattern but compares against
  `effective_limit` and has no TATL-related columns
- `results_contingency_status.csv`: columns `[timestamp, contingency_mrid,
  converged, skipped_reason, included_in_milp]`

**Acceptance criteria:**
- Given a contingency that causes a branch overload resolved by a PRA,
- When results are exported,
- Then `loading_pct_nx_post_pra ≤ 100%` (or TATL%) for that branch in that
  contingency AND `slack_patl == 0.0`.

---

## R3.10 — Pipeline integration (`ENABLE_NX_ANALYSIS`)

**Spec ref:** No direct CORNET item — prototype integration increment, added after
the fact, mirroring R4.10's role for the multi-timestamp path. Without it, this MD
did not describe what R3 actually delivers as a usable pipeline entry point, only
as correctly implemented and unit-tested modules.

**Context:** R3.1–R3.9's N-X and curative PST/RD logic were fully implemented and
correctly tested at the module level, but `run_pipeline.py` never constructed an
`NxMilpInputs` object and never passed `nx_inputs=` into `build_n0_milp_model`
anywhere — confirmed by direct grep before any code was written. This increment
wires R3's logic into `run_pipeline.py` as a real, runnable path.

**⚠ Four confirmed pre-existing bugs in `run_pipeline.py`, unrelated to N-X,
found only because this was the first time anyone ran `main()` end-to-end
against real data.** These were wrong regardless of N-X — they would have
blocked the existing preventive-only PST/RD path on any branch, at any time, for
anyone who actually tried to run the script. Recording them here because this is
where they were found, not because they are N-X-specific:

1. `REPO_ROOT = Path(__file__).resolve().parent` resolved to `src/`, not the repo
   root — `data/` does not exist under `src/`. One-line fix.
2. `cgmes_loader.write_lf_basecase_csv` was missing entirely — flagged as a known
   gap at the end of R3's original implementation, never fixed until now.
3. `sar_validator.run_sar_crosscheck()` was called with a `patl=` kwarg its real
   signature does not accept.
4. `scanned_elements.write_scanned_element_csv()` was called with an
   `lf_initial=` kwarg its real signature does not accept.

**Confirmed regression-free, proven by byte-for-byte checksum, not just by tests
passing:** every output CSV from a real `run_pipeline.main()` run with
`ENABLE_NX_ANALYSIS=False` was checksummed before and after all changes in this
increment. Identical. "Tests pass" and "output is provably unchanged" were
treated as two separate claims requiring separate proof, consistent with every
other verification in this project.

**What it delivers:**

- New control parameters, following the existing `ENABLE_*` convention:
  ```python
  ENABLE_NX_ANALYSIS: bool = False
  ACTIVATE_CRA_XNE_LINKAGE: bool = False   # see deferred-activation note below
  PENALTY_COST_OVERLOAD_NX_PATL: float = ...
  PENALTY_COST_OVERLOAD_NX_TATL: float = ...   # higher than PATL's, per R3.3
  MIN_LOADING_THRESHOLD_PCT_NX: float = 0.0
  MAX_COMPLETENESS_ITERATIONS: int = 5
  ```
  Extended by the "Architecture note: unified N-X branch candidate set" work
  (Filter 1/Filter 2/R3.2a) with three more:
  ```python
  SENSITIVITY_THRESHOLD_PCT_PST_NX: float = 0.0
  SENSITIVITY_THRESHOLD_PCT_RD_NX: float = 0.0
  PENALTY_COST_OVERLOAD_NX_SCANNED: float = 10_000.0
  ```

- **`NxMilpInputs` construction** — a new, gated preprocessing block positioned
  after RD preprocessing completes and before the "nothing to optimise" check.
  Runs regardless of whether `pst_inputs`/`rd_inputs` are `None` — N-X with zero
  dispatchable capacity is a valid, meaningful degenerate case (confirmed via
  R3.2's own smoke test: solves to optimal, slack absorbs what nothing can
  resolve). Calls, in order: `compute_lf_nx`, `compute_tatl_data`,
  `compute_sensitivity_pst_nx` (guarded on `pst_list` non-empty),
  `compute_sensitivity_rd_nx` (guarded on `rd_list` non-empty),
  `compute_pst_cra_availability`, `build_pst_tap_bounds_curative` (per TSO, merged).

- **Curative tap bounds fallback:** `pst_tap_bounds_curative` falls back to each
  PST's own `operating_tap_min`/`operating_tap_max` when no real curative
  `RangeConstraint` exists for that PST — deliberately **not** falling back to
  `pst_inputs.pst_tap_bounds`, since `pst_inputs` can legitimately be `None` on
  this dataset (zero preventive PSTs) while the PST object's own operating bounds
  always exist regardless of which workflow is active. This makes the fallback
  robust to workflows where no preventive PST path exists at all.

- **`tap_changer_to_transformer_all` accumulation fix.** Previously a local
  variable rebuilt fresh inside the per-TSO loop and discarded after each
  iteration — never accumulated globally, and unusable for curative bounds
  construction (which needs the full cross-TSO mapping). Fixed by accumulating
  into a persistent dict across the TSO loop. Confirmed safe to merge globally:
  `build_pst_tap_bounds_curative` only matches TapChanger mRIDs it finds inside
  the one `ra_path` graph it is given per call, so entries from other TSOs are
  irrelevant, not conflicting (CIM mRIDs are globally unique UUIDs).

- **`linearisation.py` extended, not bypassed.**
  `run_post_rao_linearisation_loop` gains `nx_inputs: Optional[NxMilpInputs] = None`,
  threaded through to `build_n0_milp_model` on **every** iteration, unchanged —
  the exact same precedent already established in this function for R2.12's
  `scanned_element_constraint_hard`/`scanned_element_penalty_eur_per_ka`. This
  ensures N-X constraints are present in every MILP build regardless of which
  RA-type branch a given workflow takes (PST-only via this loop, or
  RD-only/PST+RD via the direct `build_n0_milp_model` call in `run_pipeline.py`)
  — not silently absent under PST-only, which was the original, real gap this
  increment exists to close. Proven directly with a spy-based test confirming
  every iteration's actual call kwargs include `nx_inputs` (real data cannot
  reach this branch — zero available preventive PSTs on the current dataset —
  so this could only be proven via the spy, not via a real end-to-end run).

- **Sequential, not joint, linearisation + completeness — a dated decision, not
  a silent omission.** `nx_inputs.lf_nx` is **not** refreshed by the
  linearisation loop's own per-iteration N-0 AC revalidation
  (`lf_after`/`build_lf_initial`) — N-X's per-contingency load flow is a
  separate computation the linearisation loop does not touch. Refreshing
  `nx_inputs.lf_nx` to reflect the loop's own final converged solution is
  (historical: this is now done by the outer loop of the nested orchestrator) `completeness_loop.run_completeness_loop`'s job, called **separately by the
  caller after the linearisation loop returns** — in both branches uniformly.
  **Joint convergence** (reconciling the linearisation loop's N-0 tap-change
  convergence criterion with the completeness loop's N-X congestion-coverage
  criterion inside a single combined loop) **is explicitly deferred**, parallel
  to how R4.3/R4.4's combined-loop integration was deferred. **Acceptance
  criterion for this scope decision:** each piece — N-0 tap-change convergence
  via the linearisation loop, N-X congestion-coverage via the completeness loop
  — is independently correct and independently tested; they are not required to
  jointly converge in this increment.

- **Branch-selection bug fixed.** The pre-existing condition
  `if rd_inputs is None:` incorrectly routed to the PST-only branch whenever
  `rd_inputs` was `None` — including the `pst_inputs=None, rd_inputs=None,
  nx_inputs=<real>` scenario (N-X analysis with no dispatchable preventive
  capacity at all), which would have crashed on `pst_inputs.pst_list` since
  `pst_inputs` was also `None`. Corrected to
  `if pst_inputs is not None and rd_inputs is None:`. Discovered directly by the
  test scenario this increment was required to prove, not found separately.
  Consequently, R2.7–R2.10's RD-specific result extraction (previously assumed
  reachable only when `rd_inputs` was real) now also needed an explicit
  `rd_inputs is not None` guard, since the corrected branch condition makes that
  code path reachable with `rd_inputs=None` too.

- **`build_n0_milp_model`'s own internal "nothing to optimise" guard updated —
  a necessary consequence of this release's contract change, not a
  pre-existing bug.** Confirmed via a pre-existing, still-passing test
  (`test_both_inputs_none_raises_before_model_creation`, predating this
  increment) that `pst_inputs is None and rd_inputs is None` was a deliberately
  written and correctly tested definition of "nothing to optimise" back when
  only two RA-type sources existed. It only became too strict the moment
  `nx_inputs` was introduced in this release as a legitimate third source — updated
  to `pst_inputs is None and rd_inputs is None and nx_inputs is None`. Unlike
  the four `run_pipeline.py` bugs above (wrong regardless of N-X, on any branch,
  at any time), this was correct until this release's own change to the
  function's contract made it too strict — a direct, mechanical consequence,
  not an independent latent defect.

- **`ae_path=`/`ACTIVATE_CRA_XNE_LINKAGE` deferred exactly as scoped.**
  `ACTIVATE_CRA_XNE_LINKAGE` defaults `False`. `ae_path=` was **not** added to
  the existing `parse_psts`/`parse_rd_units` calls in this increment — a comment
  at the flag's definition states explicitly that turning it on requires
  `ae_path=` added to both calls first, or `linked_xne_mrids` will silently stay
  `[]` and the flag will do nothing. `linked_contingency_mrids` (needed for
  curative CRA regardless of the linkage flag) does not depend on this — it
  resolves from `ra_path` alone.

**Dataset findings — corrected after a later investigation (see "Convergence
correction" note immediately below); original figures retained here struck
through for the historical record, not deleted.**

**~~11 must-study contingencies at `1030Z`; 3 give usable N-X results (7
non-convergent `MAX_ITERATION_REACHED`, 1 likely network split) — matches R3.1's
original finding exactly.~~**

**~~Conclusion: the core N-X layer (sensitivity, PATL, TATL) is real and
non-trivial on this dataset — 3 genuinely usable contingencies...~~**

- 11 must-study contingencies at `1030Z` (confirmed identical in both the
  sandbox and the real environment — the must-study *count* was never in
  question; only the convergence outcome changed with the corrections below)
- **11/11 usable, 0 skipped** — confirmed end-to-end, in both environments, both
  at the initial N-X pass and again after the completeness loop's own refresh
  (R3.8 shows the same `11/11 (0 skipped)` a second time, confirming the fix
  holds after the RAO solve, not just at the first pass)
- 10 branches have a real TATL.
- `pst_cra_availability`: 0 entries (the one real curative PST is missing
  `reaction_time_minutes`/`time_per_stage_minutes`). Zero curative RD RAs anywhere.
- **Conclusion: the core N-X layer (sensitivity, PATL, TATL) is real and
  non-trivial on this dataset — all 11 must-study contingencies now genuinely
  usable, 10 real TATL-bearing branches, producing a real, non-degenerate solve
  across the full contingency set, not a partial one. The curative (CRA) layer
  specifically still degrades to empty**, exactly like GLSK and power bids
  did for RD in R2/R3 — not skipped, not erroring, correctly computing empty
  with a clear log message.

### ⚠ Convergence correction (superseding the original "3/11" / "7/11" finding above)

The original R3.10 implementation reported **3/11 usable contingencies** in the
sandbox (7 "non-convergent," 1 "likely network split"), and a real-environment
run separately reported **7/11**. Both were investigated further and found to
be substantially undercounting, for two independent, unrelated reasons — both
now fixed:

1. **`use_reactive_limits` was left at pypowsybl's own default** at all three
   real AC-solve call sites (`run_initial_loadflow` in `cgmes_loader.py`,
   `compute_lf_nx` in `nx_sensitivity.py`, `_run_ac_loadflow` in
   `linearisation.py`). A dedicated standalone investigation confirmed reactive
   limit enforcement was causing widespread, genuine (if dataset-specific)
   non-convergence — not solver noise, not a data quality issue. This is a
   deliberate, documented departure from pypowsybl's
   `PowerFlowCalculationSettings.adoc` default. **Fixed by setting
   `use_reactive_limits=False`** at all three sites, now exposed as a real
   control parameter (see below), not left as an unexplained hardcoded choice.
2. **A genuine, independent bug in `_contingency_result_is_usable`**: the
   "likely network split" detection produced a false positive whenever a
   contingency's own tripped equipment was also a monitored branch — entirely
   expected behaviour (a branch that trips as part of the contingency itself is
   supposed to be missing from the post-contingency result), misdiagnosed as a
   topology split. **Fixed by excluding a contingency's own equipment from its
   own missing-branch check.**

Together, these two fixes took this dataset from 3/11 (sandbox) / 7/11 (real
environment) to **11/11 in both environments**, confirmed independently via a
fresh `run_pipeline.py` run in each (not assumed from the sandbox figure
carrying over).

**On the earlier "13" figure, which never belonged here:** a "13/26" number
surfaced briefly during this investigation via `standalone_security_analysis.py`,
a broader diagnostic script that parses *every* contingency across *every* TSO
in `NCP_package.zip` with no must-study filtering at all. That is a different,
wider scope than R0.5's must-study count and was never a corrected version of
the 11-contingency figure — the must-study total was always 11, in both
environments, throughout this entire investigation. Recorded here only to
close out the confusion, not because it is a real dataset figure for this
increment.

**`USE_REACTIVE_LIMITS` control parameter, new:**
```python
USE_REACTIVE_LIMITS: bool = False
```
Following the existing `ENABLE_*`/`PENALTY_COST_*` convention, threaded through
to all three AC-solve call sites above as an explicit trailing parameter
(backward-compatible — defaults preserve today's behaviour). Previously
hardcoded identically in three separate function bodies with no way to
override without editing source; now a single, visible, documented setting.

**TATL constraint count — a secondary, mechanical effect of the convergence
fix, not a change to TATL itself.** TATL's own *data* is unaffected by either
fix (`compute_tatl_data` has no `run_ac`/security-analysis dependency — a
static CGM property lookup only). But `_add_nx_block`'s TATL constraint pairs
are built by iterating `nx_inputs.lf_nx`'s own contingency keys — with more
contingencies now genuinely usable (11 vs. the original 3), the number of real
(branch, contingency) TATL pairs actually constrained in the MILP grew
correspondingly: **132 pairs, up from 96.** Worth stating explicitly so a
reader doesn't assume TATL-related MILP size is untouched by a fix that, on
paper, only touched contingency convergence.

**Inputs:**
- All R3.1–R3.9 preprocessing and MILP-building functions
- `ae_flat_list`, `co_flat_list`, `pst_list`, `rd_list` (from R0)
- RAO control parameters listed above

**Outputs:**
- `run_pipeline.py` gains a real, selectable N-X/CRA entry point
- All R3.1–R3.9 result CSVs, produced via the real pipeline path — including
  confirmed non-trivial `sensitivity_nx.csv` (now `sensitivity_pst_nx.csv`), `results_nx_loadings.csv` (real
  loading percentages and slack values, including honest large `slack_tatl`
  values reflecting genuinely unresolved overloads where nothing dispatchable
  exists to fix them), and confirmed-empty `pst_cra_availability.csv`
  (header-only) and `results_contingency_status.csv` (11/11 converged, matching
  the confirmed dataset figure after the convergence correction above — see
  "⚠ Convergence correction" for what this figure originally was and why)

**Acceptance criteria:**
- Given `ENABLE_NX_ANALYSIS=True`,
- When `run_pipeline.py` is run against the real dataset,
- Then the pipeline completes to "Pipeline complete" with no exception, N-X PATL/TATL
  constraints are present and non-trivial (11 usable contingencies, 10 TATL-bearing
  branches, 132 TATL constraint pairs), and `pst_cra_availability`/curative RD
  correctly compute empty without error.
- Given `pst_inputs=None`, `rd_inputs=None`, and `nx_inputs=<real>` (N-X analysis
  with no dispatchable preventive capacity at all — a scenario that did not exist
  as a reachable branch before this increment),
- When the pipeline runs,
- Then it reaches the solve rather than incorrectly hitting the "nothing to
  optimise" early exit, and does not crash on the previously-mis-routed
  PST-only branch.
- Given `ENABLE_NX_ANALYSIS=False` (the default),
- When `run_pipeline.py` is run,
- Then output is byte-for-byte identical to the pre-increment baseline — checked
  via checksum comparison, not test-pass alone.
- Given the linearisation loop runs N-X-guarded iterations (PST-only branch,
  hypothetical — not reachable on the current dataset),
- When each iteration's `build_n0_milp_model` call is inspected via a spy,
- Then `nx_inputs` is present in every iteration's kwargs, unchanged.
- Given `USE_REACTIVE_LIMITS=False` (the default),
- When each of the three AC-solve call sites is inspected via a spy/mock,
- Then `pp.loadflow.Parameters(use_reactive_limits=False)` is confirmed
  constructed at all three, not just accepted as a parameter without being
  threaded through.
- Given a contingency whose own tripped equipment is also a monitored branch,
- When `_contingency_result_is_usable` evaluates that contingency,
- Then it is not misclassified as a network split — the contingency's own
  equipment is excluded from its own missing-branch check.
- Given `run_pipeline.py` is run in a real environment after both convergence
  fixes,
- When the must-study convergence figure is inspected,
- Then it reports `11/11 usable, 0 skipped` — confirmed independently in both
  the sandbox and the real environment, not assumed to carry over from one to
  the other.
