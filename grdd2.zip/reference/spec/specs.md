
<!-- page 1 -->

> **Figure (page 1) — described in text.**
>
> Publisher logo: the letters **FGH** in dark blue capitals, set between two diagonal banner shapes.

RAO Calculation Module

Functional Specification (R25_1)

Document Date: 14 .11.2025

<!-- page 2 -->

##### TABLE OF CONTENTS

- 1. Document Information … 7
- 1.1 Scope … 7
- 1.2 Executive Summary … 7
- 1.3 Audience … 8
- 2. Process Description … 9
- 2.1 BPMN/Process Diagram … 9
- 3. Specifications … 10
- 3.1 RAO Job Component … 10
- CORNET-344: RAO Job Component … 10
- BUC 14#130 Submit RAO Job Using HPC Manager … 10
- BUC 14#83 The RAO estimates the remaining runtime in percent … 11
- 3.2 Data model … 14
- CORNET-334: Data model – Introduction … 14
- CORNET-335: Data model – Generating Units … 14
- CORNET-336: Data model - XNEs … 15
- CORNET-3693: Data model - Contingencies … 15
- CORNET-338: Data model - PSTs … 16
- CORNET-339: Data model - Preventive topological RA … 17
- CORNET-340: Data model - Results … 17
- CORNET-4841: RAO - Change to CoMo LF Result Profile … 18
- CORNET-4842: RAO – General LF Results … 18
- CORNET-4844: RAO - Terminal LF Results … 20
- CORNET-4845: RAO - Bus LF Results … 21
- CORNET-4846: RAO - Tap Changer LF Results … 22
- 3.2.1 Definition of the TSO names … 23
- Consideration of the TSO names by the country code … 23
- 3.3 LF Computation … 26
- CORNET-97: Load flow computations on a grid model … 26
- CORNET-103: Consideration of PSTs in LF computation … 28
- CORNET-104: Handling of PV/PQ-Conversions … 29
- CORNET-105: Active power control … 29
- CORNET-111: Initial LF calculation with non-convergence … 30
- CORNET-106: Behaviour with non-convergence LF-solutions … 30
- CORNET-98: LF Result output … 31

<!-- page 3 -->

- CORNET-107: Results per topological node … 32
- CORNET-3221: Results per AC line segment and 2W transformer … 33
- CORNET-109: Results per 3W transformer … 34
- 3.4 CA Computation … 36
- CORNET-3691: Fast Outage Approximation … 36
- SF3072: Fast Contingency Calculation … 39
- BUC 14#113 Using FCC for all contingency situations in RAO … 45
- SF3073: RAO Input Data - Contingencies … 48
- 3.5 Sensitivity Computation … 54
- CORNET-4836: Calculation of Sensitivities … 54
- CORNET-102: Sensitivity results … 63
- 3.6 RAO Computation … 65
- 3.6.1 Introduction … 65
- 3.6.2 Optimisation Model … 66
- Process … 66
- CORNET-12: RAO Procedure … 66
- CORNET-15: Considering Degrees of Freedom … 67
- CORNET-4850: Accuracy Requirement … 68
- CORNET-16: Consideration of Congestions … 71
- SF3077 Objective Function … 73
- CORNET-85: Considered time grid … 77
- BUC 14#115: Consideration of the RA status from RAC in following RAO iteration … 77
- 3.6.3 Consideration of Remedial Actions … 81
- CORNET-17: Participation of Controllable Units in Optimization … 81
- CORNET-3447: RA Deciding Point … 82
- CORNET-4848: Definition of GLSK in RAO … 85
- BUC 14#112 Configuration of XNE linkage in CRAs … 91
- 3.6.4 Consideration of PST in RAO … 93
- CORNET-18: Consideration of PST … 93
- CORNET-2895: Limitation of PST in preventive mode … 93
- CORNET-21: Group constraints for PST (RRQ 866) … 98
- CORNET-3653: Limitation of the PST tap changes per time stamp … 100
- CORNET-3654: Limitation of the PST tap changes per optimisation timeframe … 102
- CORNET-2998: Considered costs for PST in preventive mode … 105
- BUC 14#110 Consideration of PST as curative remedial actions … 106
- CORNET-1978: Consideration of reaction time for PST in curative mode … 110

<!-- page 4 -->

- CORNET-1985: Limitations of PST in curative mode … 111
- SF3074: Group constraints for PST in curative mode … 116
- CORNET-1982: Considered costs for PST in curative mode … 120
- 3.6.5 Consideration of Generation Units in RAO … 122
- CORNET-35: Consideration of generation units … 122
- CORNET-41: Consideration of available RD volume … 122
- CORNET-36: Upper active power limits for generation units … 125
- CORNET-37: Lower active power limits for generation units … 127
- CORNET-4593: Limits of minimum up and down times of the Generating Unit … 130
- CORNET-43: Last change of state of a generation unit (in operation / out of operation) … 132
- CORNET-4595: Minimum up and down times of Generating Units … 132
- CORNET-45: Consideration of Power Gradient Constraint of Generating Units … 136

CORNET-46: Consideration of Power Gradients at the Beginning and End of the Optimisation

- Period … 139
- CORNET-47: Input data and definition on start-up of generating units … 139
- CORNET-48: Input data and definition of shut-down … 140
- CORNET-49: Consideration of a start-up process without start-up before optimisation … 142

CORNET-50: Consideration of shut-down process without shut-down before optimisation 143

- CORNET-69: Consideration of start-up process with start-up before optimisation … 144
- CORNET-70: Consideration of shut-down process with shut-down before optimisation … 145
- CORNET-4596: Input data on lead and lag times … 145
- CORNET-91: Consideration of lead times in RAO … 148
- CORNET-51: Penalty and marginal costs … 149
- BUC 14#103 Consideration of generating unit start-up costs … 149
- CORNET-71: Consideration of shut-down costs … 154
- 3.6.6 Redispatch Remedial Actions … 155
- BUC 14#106: Consideration of redispatch RA in curative mode … 155

CORNET-4614: Consideration of PRAs and CRAs of redispatch RAs for the same Generating

- Unit … 161
- CORNET-612: Consideration of technical limits from redispatch RA in curative mode … 163
- CORNET-613: Consideration of reaction time for redispatch RA in curative mode … 164
- CORNET-576: Consideration of lead time for redispatch RA in curative mode … 166
- CORNET-574: Balancing of redispatch RA in curative mode … 168
- BUC 14#43 Consideration of costs for redispatch CRA … 169
- 3.6.7 Countertrade … 173
- CORNET- 4847: Consideration of Countertrade … 173

<!-- page 5 -->

- 3.6.8 Consideration of Power Bids … 177
- CORNET-2006: Consideration of multiple Power Bids per Generating Unit … 177
- CORNET-2007: Consideration of minimum up and down times for Power Bids … 182
- CORNET-2008: Consideration of minimum redispatch for Power Bids … 184
- CORNET-3616: Consideration of lead time for Power Bids in preventive mode … 186

CORNET-3626: Consideration of a minimum Energy Limit for Power Bids in preventive mode CORNET-3711: Consideration of a maximum Energy Limit for Power Bids in preventive mode

- CORNET-4606: Considered costs of redispatch RA in preventive mode … 190
- BUC 14#102 Consideration of Power Bid activation costs … 193
- 3.6.9 Balancing of Redispatch Remedial Actions … 197
- CORNET-73: Balancing of Redispatch Remedial Actions … 197
- 3.6.10 Limiting Redispatch Remedial Actions … 198
- BUC 14#119 Limiting the number of activated RD PRA per timestamp in RAO … 198

CORNET-3649: Limitation of the activated RD Remedial Actions per optimisation timeframe CORNET-4838: Limitation of Redispatch and Countertrade for Remedial Action Groups for

- PRAs … 202
- 3.6.11 HVDC Remedial Actions … 205
- BUC 14#55 RAO considers HVDC PRAs modelled as Equivalent Injections … 205
- BUC 14#109 Costs of HVDC Setpoint changes … 212
- 3.7 Special Protection Schemes … 215
- BUC 14#131 Read input of SPS … 215
- BUC 14#111: Non-Coordinable SPS related to a contingency … 217
- 3.8 Network Elements … 221
- 3.8.1 Consideration of Congestions … 221
- CORNET-32: Consideration of XNEs … 221
- CORNET-1790: Consideration of XNEs in MILP … 222
- CORNET-1792: Consideration of one TATL … 227
- CORNET-2586: Consideration of one TATL (RTE-specific) … 228
- CORNET-439: Scanned Elements … 230
- SF927: RAO-ExclusionsInclusions: Excluded XNEs in RAO (Offline) … 234
- 3.8.2 System Constraints … 238
- CORNET-498: System Constraints with active power limits … 238
- CORNET-537: System Constraints with current limits … 242

<!-- page 6 -->

- 3.9 Topological Remedial Actions … 247
- Disclaimer … 247
- BUC 14#85: Read input of proposed or agreed topological XRAs … 247
- BUC 14#84 Application of already agreed topological PRAs before RAO … 249
- BUC 14#105: Application of proposed topological CRAs … 252
- 3.10 Configuration of RAO optimisation settings … 256
- CORNET-3624: Sensitivity Threshold … 256
- CORNET-3650: TSO specific parametrisation of penalty terms in soft constraints … 261

CORNET-4339: TSO specific parametrisation of penalty reference values for remedial actions CORNET-4340: TSO specific parametrisation for consideration of technical limits from

- redispatch RA in curative mode … 269
- 3.11 Optimisation results … 272
- CORNET-3632: Consideration of RD step size … 272
- BUC 14#132 General Optimisation results … 274
- SF3078: PowerScheduleAction Optimisation results … 279
- SF3079: GridStateIntensitySchedule Optimisation results … 281
- BUC 14#153 Results for SPS … 285
- BUC 14#137 Generating Unit Optimisation results … 287
- BUC 14#138 Net positions and TSO exchange results … 289
- BUC 14#141 Results of system constraints … 293
- BUC 14#142 Results of contingency calculation … 295
- 3.12 Output of additional RAO information … 300
- CORNET-3697: Storing additional RAO information in output files … 300
- CORNET-4344: Exporting the additional RAO information … 303
- 3.13 Update of CoMo … 304
- SF2927: Update CoMo to baseline R25_1 … 304
- 4. Appendix A: Glossary … 307

<!-- page 7 -->

## 1. Document Information

### 1.1 Scope

This document is the Functional Specification of the RAO Calculation module and represents the status for R25_1.

The Requirements are stored and managed in the ReqSuite tool, so there is a constant reference to the Business Needs, System Features and Use Cases in the system.

### 1.2 Executive Summary

This document specifies the Remedial Action Optimisation (RAO) job component of the RAO Service. The RAO is part of the day-ahead (DA) CROSA process and is executed between Regional Security Assessments in the first regional run as well as after a Remedial Action Coordination in the second regional run. The goal of the RAO computation is to assess operational limit violations on Core XNEs and solve these overloads with the available Remedial Actions (RA).

The document is divided into several chapters. The first chapter is a short overview of the data model. The following chapter specifies the computational modules for the load flow computation, the contingency analysis and the sensitivity computation. The load flow calculation is solved iteratively using the Newton-Raphson method . The module can consider all transformer types, handles PV/PQ- conversions and has an active power control.

To reduce the calculation time of conducting a full AC load flow calculation for each contingency situation , Fast Outage Approximation ( FOA) and Fast Contingency Calculation (FCC ) are utilized. The FOA offers significant benefits in calculation time but cannot be applied to all contingency situations. The remaining congestions are solved using FCC, which uses a modified Newton-Raphson approach. The next chapter describes the sensitivity computation. These sensitivities are used to build the mixed integer linear program (MILP) optimisation problem. They allow a separation of the optimisation process from the load flow calculations and represent the load flow properties of the different RAs. The following chapter describes the optimisation modules within the RAO process. At first the RAO is placed within the CROSA process, and an overview of the iterative RAO process and the calculation modules is given. Afterwards, the considered remedial actions are specified . After a section about preventive remedial actions, definitions of network elements are given. The consideration of

<!-- page 8 -->

congestions and system constraints are specified. In the following sections, topological remedial actions and configuration and results of the optimisation are described .

### 1.3 Audience

The document is created by FGH (Vendor of Lot 3). The document shall be reviewed and evaluated by the appropriate CorNet experts (e.g. SME, BA, Architects, Operators etc.) and, at CorNet’s discretion, TSO experts as appropriate. CorNet Project Management will give the final approval of the document to FGH.

<!-- page 9 -->

## 2. Process Description

### 2.1 BPMN/Process Diagram

> **Figure (page 9) — described in text.**
>
> Full BPMN process diagram of the RAO, drawn across two swim-lanes.
>
> **Lane 1 — RAO System.** Start event *EVT 1.4#1_01-01 Need to start RAO* → task *PRC 1.4#1_02 Submit RAO to HPC*, which carries four attached error events: *HPC Unavailable/in Error Mode* (02-05), *No Parameter Set in MongoDB* (02-02), *Parameter Set Cannot be Stored in CDS* (02-03) and *Data Transfer from CDS to S3 Failed* (02-04). All four converge on a gateway leading to end event *EVT 1.4#1_01-02 Terminate RAO Process*. On the right, *PRC 1.4#1_03 Write Output Data* leads to end event *EVT 1.4#1_01-07 End RAO Process*, triggered by the message *RAO Job Finished Successfully*.
>
> **Lane 2 — HPC / RAO Processing.** Sequence: *Initialise Internal Data Model* → *Calculate AC Load Flow* → gateway *Initial LF Result Convergent?* (No → *Publish RAO Log Message*; Yes → continue) → *Expand Contingencies by SPS* → *Contingency Calculation (FOA and FCC)* → into the optimisation loop: *AC Sensitivity Calculation (N-0 & N-1)* → *Build MILP* → *Solve MILP* → gateway *MILP Calculation Successful?* → *Calculate AC Load Flow* → gateway *New LF Result Convergent?* → *Check Linearization Quality* → *Check New Operating Point For Cycling* → *Check Nr. of Iterations* → *Contingency Calculation (FOA and FCC)* → *Check New Outages* → gateway *Are New Outages Relevant?* (Yes loops back to the start of the optimisation; No → *Calculate and Save Result to S3* → *RAO Job Finished Successfully*).
>
> Attached intermediate events: *EVT 1.4#1_01-05 Linearization Quality Insufficient*, *EVT 1.4#1_01-04 Cycling of operating point is the same as previous*, *EVT 1.4#1_01-03 Nr. of inner iterations not Reached*, and *EVT 1.4#1_01-06 Maximum Nr. of outer iterations reached*.
>
> Annotations: a boxed note gives the performance timings — *Normal Scenario: 90% of cases ≈ 5 minutes; Exception Scenario: 100% of cases ≈ 10 minutes* — with the caveat that timings depend on the number of jobs currently queued for the HPC engine. A second note explains that the new operating point is compared with prior iterations, and the iteration is aborted for cycling if the same point is visited again.

Figure 1: RAO BPMN

<!-- page 10 -->

## 3. Specifications

### 3.1 RAO Job Component

#### CORNET-344: RAO Job Component

The RAO Job Component is part of the RAO System as described in the RAO Service – Main Module specifications and will interact with several other components of the RAO Service (chapter 1.3 and 1.4 in RAO Service – Main Module).

The use-cases (chapter 2.2 and 2.4 in RAO Service – Main Module) and the integration within the HPC cluster (chapter 3 in RAO Service – Main Module) are also described in the RAO Service – Main Module specifications.

The logging of the optimisation within the RAO Job Component is done via Kafka. The optimisation log message format is specified in chapter 4.18 of the RAO Service – Main Module specifications. All assumptions, on which the specifications are based, are described in chapter 6 of the RAO Service – Main Module specifications.

#### BUC 14#130 Submit RAO Job Using HPC Manager

##### Scenario

#### BUC 14#130 Submit RAO Job Using HPC Manager

The RAO Job is submitted via the HPC Manager API instead of the Slurm HTTP API. Different submission argument syntax is used for the job submission.

##### Description

In prior releases, the RAO HPC jobs were submitted through the Slurm HTTP API directly. Instead, a HPC Manager API is used. Additionally, the cancellation of jobs, monitoring of jobs and changes of authorisation are handled by the HPC Manager API.

Because the job instances of RAO, LF and SA are submitted in uniform syntax using the HPC Manager API, the following submission arguments are to be used:

• The computation ID replaces the Slurm-internal job ID and is submitted via the argument --computation-id (previously: --raoId)

• The computation arguments are submitted via an S3 URL using the argument --computation- args

(previously: --calcArgs)

<!-- page 11 -->

For detailed information, see the functional specification for SYS 4#07 HPC Manager.

##### Configuration

No input data required.

##### Business Rules

RAO HPC jobs are submitted via the HPC Manager as described in the corresponding functional specification (see SYS 4#07 HPC Manager – SF2366 Computation Submission).

##### Triggers

A RAO calculation is requested through the CorNet platform.

##### Pre-Condition

All relevant input data is available, see chapter 3.2 Data model.

##### Acceptance Criteria

Given

A RAO job is prepared using the submission arguments specified in the functional specification for SYS 4#07 HPC Manager.

When

The HTTP API endpoint is called,

Then

The RAO job is submitted successfully.

##### Basic Flow

The RAO calculation is started.

##### Alternative Flow

No alternative flow foreseen.

#### BUC 14#83 The RAO estimates the remaining runtime in percent

##### Scenario

#### BUC 14#83 The RAO estimates the remaining runtime in percent

During the operational process operators need to have feedback on the status of the RAO to plan the next steps. This includes an estimate of the expected run-time necessary to complete a full RAO run.

<!-- page 12 -->

##### Description

RAO is based on an iterative approach combined with an initialisation routine and an output routine (see CORNET-12 : RAO Procedure). Estimating the Run-Time of the RAO is a computationally complex task. The necessary number of iterations to resolve all congestions optimally is not easily determined beforehand.

Instead of estimating the Run-Time, the RAO reports the current progress of the RAO in % to full completeness based on estimate to complete all iterations. Based on historical computations we determined empirically the required time for the different steps during the optimisation, such as: - Initialisation of the data model

- Loadflow calculation

- Contingency calculation

- Sensitivity calculation

- Application of the remedial actions

- Convergence check

- Stop criteria check

- Export of the results

In combination with additional information which determines the computation time such as

- Number of contingencies

- MaxCountLinIter

- MaxCountCompIter

We develop a heuristic approach that combines the relative time for the different optimization steps in combination with the additional information to calculate the current progress of the RAO. This current progress will be sent via a Kafka Event (see SYS 14#01 RAO UI Main Module).

##### Outlook

We plan to further improve upon the report of the progress based on the first operational runs in the future. This includes defining parameters (e.g. number of outages, sum of congestions, number of binary decision variables, ...) that have a large impact on calculation time and use this information to have a better approximation. Additionally, a remaining Run-Time estimation in minutes can be part of further developments.

##### Configuration

| Name |  | Description | Unit | Object |
| --- | --- | --- | --- | --- |

<!-- page 13 -->

| MaxCountLinIter | Max. count of linearisation iterations | - | RAOControlParameterProfile: RAOControlParameterSet. maxCountLinIter |
| --- | --- | --- | --- |
| MaxCountCompIter | Max. count of completeness iterations | - | RAOControlParameterProfile: RAOControlParameterSet. maxCountCompIter |

##### Triggers

No trigger needed, default behaviour.

##### Pre-Condition

The RAO has started successfully.

##### Acceptance Criteria

Given

The RAO has been started

When

The RAO has not yet terminated successfully,

Then

RAO logs its current progress

##### Basic Flow

The current progress is sent via a Kafka Event (see SYS 14#01 RAO UI Main Module).

##### Alternative Flow

No alternative flow is foreseen.

<!-- page 14 -->

### 3.2 Data model

#### CORNET-334: Data model – Introduction

This chapter describes the general assumptions for the CoMo input data in Release 1.1 (R1.1). These general assumptions are necessary to handle the input data which cannot be fully processed in this first release as well as handling the uncertainty in which the input data is being delivered. According to the HLBP the RAO will only process the CGM created by the ROSC process step 3.2.2. This CGM is based on the CGMES 2.4.15 data format.

#### CORNET-335: Data model – Generating Units

The generation schedule of the Generating Units (PROD) is taken from the CGMES input data in R1.1 for each time stamp (see CORNET-41 ). The same applies for the technical upper active power and lower active power limits of the generation units. This information must be available within the GeneratingUnit class in the EquipmentProfile (see CORNET-36 and CORNET-37 ).

The available redispatch volume is delivered via PowerBidSchedules in the SecurityScheduleProfile . Several of these PowerBidSchedules can be available for each RD unit per time stamp and redispatch direction. In R1.1 the RAO utilises only two PowerBidSchedule per Generating Unit. One PowerBidSchedule for the downwards and upwards available RD volume each. If several PowerBidSchedule are available per Generating Unit, the schedules with the lowest RD energy costs are selected.

The price for activation of preventive energy and the start-up costs are taken from the same profile, whereas the penalty costs are derived from the RemedialAction profile (see CORNET-51 ).

The linked RD unit within the PowerBidSchedule must be a Generating Unit within the CGMES input data. If the linked RD unit of the PowerBidSchedule is not available within the CGMES data (e.g., it is a GLSK), the schedule is not considered for the RAO.

Each Generating Unit has one defined minimum down time and one minimum up time. These values are taken from the selected PowerBidSchedules (see CORNET-39 ). If the schedules have different values for the attributes, the higher value of each attribute is used. The same rule applies to the selection of the redispatch lead time. This information is also taken from a PowerBidSchedule within the SecurityScheduleProfile ( CORNET-72 ).

The cold status of a generation unit, as well as the cold and warm lead and lag time are taken from the GeneratingUnit class within the EquipmentReliability (ER) profile ( CORNET-72 ).

The negative and positive powergradients are taken from the GeneratingUnit class in the EquipmentProfile (see CORNET-45 ). The start-up and shut-down gradients of the Generating Units

<!-- page 15 -->

are derived from the positive and negative powergradients, respectively (see CORNET-47 and CORNET-48 ).

Because GLSK cannot be considered in R1.1, only Generating Units from the GLSKSchedule with a GLSK of 1 are processed.

If the input data for the available RD volume has an incomplete timeseries with missing values, a default setting is available to correct the missing entries. If the timeseries for the available RD volume or the RD price has a missing value, the value for this time stamp will be set to zero.

Used CSA profiles of version 2.2 in R1.1:

• EquipmentProfile

• EquipmentReliabilityProfile

• RemedialActionProfile

• SecurityScheduleProfile

• SteadyStateInstructionProfile

#### CORNET-336: Data model - XNEs

The XNEs are taken from the AssessedElement profile in the CoMo input data. Each profile must be linked to the CurrentLimit in the EquipmentProfile class (see CORNET-32 ). Because there is no PenaltyFactor attribute available for the XNEs, the penaltyPATL value for exceeding the PATL must be defined within RAO as a controlparameter. The same applies for the control parameters of the minimum loading for consideration of a XNEC combination in the optimisation problem as well as the maximum number of contingencies per network element. These parameters are defined as a RAO Control Parameter (see CORNET-92 ).

In Release 1.1 only AssessedElements will be considered. No AssessedElementWithContingency , AssessedElementWithRemedialAction or other additional configurations are considered.

Used profiles in R1.1:

• AssessedElement

• EquipmentProfile

#### CORNET-3693: Data model - Contingencies

##### Description

In R24Q2 only certain ordinary and exceptional contingencies are considered within the RAO (see CORNET-3692: RAO Input Data - Contingencies). Each contingency from the AssessedElements and Contingency profiles must be linked to the class ACLine or Transformer , other definitions are not yet considered.

<!-- page 16 -->

Used profiles in R24Q2:

• AssessedElement

• Contingency

If the contingency is an ordinary contingency, the contingency must be linked in the NC-profile to an OrdinaryContingency . Exceptional contingencies on the other hand must be linked as ExceptionalContingency in the NC-profiles.

Business Needs :

BN814: RAO-Contingencies_Advanced

Use Cases :

BUC 14#32 Consideration of multiple line/PST outages (exceptional contingencies) in RAO

#### CORNET-338: Data model - PSTs

Transformers for consideration as remedial actions in the RAO must be part of the TapPositionAction and GridStateAlteration classes. The corresponding TapChanger class in the CGMES Equipment profile must contain the technical limits of the PST (highStep / lowStep) and must be either a 60° or 90° variant.

In R1.1 only one TapPositionAction attribute will be used.

The attribute RangeConstraints is used for the operational limits of the PST. Of the available StaticPropertyRange.direction definitions per PST only one is used for the upwards ( up ) and downwards ( down ) limit each or only a single upanddown definition is used. If several StaticPropertyRange definitions per switching direction and PST exist, the lowest value is chosen for consideration in the RAO.

The StaticPropertyRange.ValueKind attribute defines the operating limit as either relative ( incremental ) or absolute ( absolute ).

The penalty costs for a tap position change are two-part. The penalty costs for a tap change within the operational limits Is taken from the PenaltyFactor attribute within the RemedialAction class. Because it is not possible to define an additional penalty cost factor for a tap change outside of the operational limits but within the technical limits in the CoMo data, this penaltyTechnical value has to be defined within the RAO Control Parameters as a default value.

A PST group is not defined via a list with the mRIDs of the PST in that specific group but instead with definitions of the class GridStateAlterationRemedialAction . For each PST in the group one definition of this class is available.

<!-- page 17 -->

Used profiles in R1.1:

• EquipmentProfile

• RemedialActionProfile

• SecurityScheduleProfile

• SteadyStateInstructionProfile

#### CORNET-339: Data model - Preventive topological RA

Preventive topological remedial actions are already integrated into the CGM created by the ROSC process step 3.2.2. An additional consideration of topological remedial actions does not take place within the RAO for R1.1.

#### CORNET-340: Data model - Results

The results of the RAO for Generating Unit remedial actions are saved within the PowerTimePoint class. For each Generating Unit activated as a remedial action in the RAO the result per time stamp ( atTime ) is saved in the attribute activatedP . This is the proposed change in active power per time stamp and can therefore be either positive or negative. The activatedPrice attribute contains the sum of redispatch costs for the unit in this time stamp (see CORNET-76 ).

The results of the RAO for the PST remedial actions are saved within the GenericValueTimePoint class. For each PST activated as remedial action in the RAO the result per time stamp ( atTime ) is saved in the attribute value. This is the proposed change of the tap position per time stamp and can therefore be either positive or negative (see CORNET-76 ).

The results of the LF calculation are saved in the PowerFlowResult profile, which is derived from SecurityAnalysisResultProfile (see CORNET-107 ).

The results of the Fast Outage Approximation are stored in the SecurityAnalysisResult profile (see CORNET-83 ).

Used profiles in R1.1:

• RemedialActionScheduleProfile

• SecurityAnalysisResultProfile

<!-- page 18 -->

#### CORNET-4841: RAO - Change to CoMo LF Result Profile

##### Description

Use case: The RAO outputs the results of the initial load-flow calculation before the optimisation and of the last load-flow calculation within the optimisation procedure (see CORNET-12 - RAO procedure). The results are given

- per calculation ( CORNET-4842 )

- per bus of calculation ( CORNET-4845 )

- per terminal of calculation ( CORNET-4844 )

- per tap changer ( CORNET-4846 )

##### Business Needs:

##### Use-Cases:

UC857: BUC 14#92 Change of RAO LF result profile to the LF Result Profil defined by Unicorn

##### Acceptance Criteria:

##### -

#### CORNET-4842: RAO – General LF Results

##### Description

Use case: The results per calculation are:

| Name | Description | Unit | Data type | CoMo- Object |
| --- | --- | --- | --- | --- |
| awId |  | - | string | LfResult |
| busCount | number of busses in NeMo | - | int | LfResult |
| calculatedIslandCount | number of islands calculated in LF | - | int | LfResult |
| convergedIslandCount | number of islands that converged in LF calculation | - | int | LfResult |
| id | unique id | - | string | LfResult |
| islandCount | number of identified topological islands | - | int | LfResult |
| majorIslandBusCount | number of busses in the major island | - | Int | LfResult |
| majorIslandConverged | true or false - identifies whether LF converged for the major island | - | boolean | LfResult |

<!-- page 19 -->

| majorIslandId | int id of the major island withig given calc. | - | int | LfResult |
| --- | --- | --- | --- | --- |
| nemoId | id of input Network Model | - | string | LfResult |
| powerBalance |  | - | PowerBalance LfResult |  |
| timestamp | time in UTC identificates time, when LF was carried out | - | Timestamp | LfResult |

| Name | Description |  | Data type | CoMo-Object |
| --- | --- | --- | --- | --- |
|  |  | Unit |  |  |
| activePowerExchange | sum of active gen - active load in island's x-busses | MW | float | PowerBalance |
| activePowerGeneration | sum of active generation in the island | MW | float | PowerBalance |
| activePowerLoad | sum of active load in the island | MW | float | PowerBalance |
| activePowerLosses | sum of active losses in the island | MW | float | PowerBalance |
| reactivePowerExchange | sum of reactive gen - reactive load in island's x-busses | MVAr | float | PowerBalance |
| reactivePowerGeneration | sum of reactive generation in the island | MVAr float |  | PowerBalance |
| reactivePowerLoad | sum of reactive load in the island | MVAr float |  | PowerBalance |
| reactivePowerLosses | sum of reactive losses in the island | MVAr float |  | PowerBalance |

| Name | Description | Unit | Data |  | CoMo-Object |
| --- | --- | --- | --- | --- | --- |
|  |  |  | type |  |  |
| busCount |  | - | int |  | LfIslandStatistic |
| id | int number 1, 2 depends on island count in the within given calculation | - | int |  | LfIslandStatistic |
| referenceBusId | reference bus for voltage angles (in UCTE is the same as slack, for CGMES can be different) | - | string |  | LfIslandStatistic |
| slackBusImbalance | P_before_calc - P_after_calc | MW float |  |  | LfIslandStatistic |
| slackBusList | internal ids of slack bus | - | string [0..*] |  | LfIslandStatistic |

<!-- page 20 -->

##### Business Needs:

##### Use-Cases:

UC8173: BUC 14#93 RAO – General LF Results

##### Acceptance Criteria:

Given

A RAO calculation has been started,

When

The RAO successfully terminates,

Then

RAO has to write the CoMo-Objects LfResult, PowerBalance and LfIslandStatistic

#### CORNET-4844: RAO - Terminal LF Results

##### Description

Use case: The results per terminal are:

| Name |  |  | Description |  |  | Unit | Data type | CoMo-Object |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| activePower |  | active power flows through terminal |  |  | MW |  | float | TerminalResult |
| connected |  | Connectivity result of topological processing. |  |  | - |  | boolean | TerminalResult |
| current |  | current flows through terminal |  |  | A |  | float | TerminalResult |
| equipmentId |  | ID of equipment |  |  | - |  | string | TerminalResult |
|  |  | equipmentMrid MRID of equipment |  |  | - |  | string | TerminalResult |
| island |  | island number within given calculation - zero means that element doesn't belong to any calc. island |  |  | - |  | int | TerminalResult |
| reactivePower |  | Reactive power flows through terminal |  |  | MVAr float |  |  | TerminalResult |
| terminalId |  | terminal ID |  |  | - |  | string | TerminalResult |
| terminalMrid |  | terminal MRID |  |  | - |  | string | TerminalResult |
| loading |  | calculated loading = current / limit.value |  |  | - |  | TerminalLoading TerminalResult |  |

##### Business Needs:

<!-- page 21 -->

##### Use-Cases:

UC8174: BUC 14#94 RAO - Terminal LF Results

##### Acceptance Criteria:

Given

A RAO calculation has been started,

When

The RAO successfully terminates,

Then

RAO has to write the CoMo-Object TerminalResult

#### CORNET-4845: RAO - Bus LF Results

##### Description

Use case: The results per bus are:

| Name |  | Description |  |  |  | Unit Data type CoMo-Object |  |
| --- | --- | --- | --- | --- | --- | --- | --- |
| busId | ID of Bus |  | - |  | string |  | BusResult |
| busMrid | MRID of Bus |  | - |  | string |  | BusResult |
| island | island number within given calculation |  | - |  | int |  | BusResult |
| nodeList | List of Nodes |  | - |  |  |  | string[0..*] BusResult |
| voltageAngle | Voltage Angle |  | ° |  | float |  | BusResult |
|  | voltageMagnitude nodal voltage magnitude |  | kV |  | float |  | BusResult |

##### Business Needs:

##### Use-Cases:

UC8175: BUC 14#95 RAO - Bus LF Results

##### Acceptance Criteria:

Given

A RAO calculation has been started,

When

<!-- page 22 -->

The RAO successfully terminates,

Then

RAO has to write the CoMo-Object BusResult

#### CORNET-4846: RAO - Tap Changer LF Results

##### Description

Use case: The results per tap changer are:

| Name | Description |  |  |  | Unit Data type | CoMo-Object |  |
| --- | --- | --- | --- | --- | --- | --- | --- |
| step |  | - |  | int |  | TapChangerResult |  |
| tapChangerId | transformer tap/phase changer ID | - |  | string |  | TapChangerResult |  |
| tapChangerMrid | transformer tap/phase changer mrid | - |  | string |  | TapChangerResult |  |
| transformerId | transfomer ID | - |  | string |  | TapChangerResult |  |
| transformerMrid |  | - |  | string |  | TapChangerResult |  |
| type | Enum for Result type of a TapChanger: - RATIO - PHASE | - |  | enum |  | TapChangerResult |  |

##### Business Needs:

##### Use-Cases:

UC8176: BUC 14#96: RAO - Tap Changer LF Results

##### Acceptance Criteria:

Given

A RAO calculation has been started,

When

The RAO successfully terminates,

Then

RAO has to write the CoMo-Object TapChangerResult

<!-- page 23 -->

#### 3.2.1 Definition of the TSO names

##### Consideration of the TSO names by the country code

###### Scenario

The RAO exposes the country code of TSOs in the results. This country code is determined based on the given energy ident code (EIC) from NC-Profiles and the CGM in CGMES format.

###### Description

Since the country code of TSOs is always two digits and well known in the operational planning processes. The RAO exposes the country code of a TSO determined based on the EIC in the given data.

The TSO specific control parameters are defined by the country code. The mapping from the country code to the NC-Profiles is done by the EIC as well.

###### Configuration

| Name | Description | Uni t | Data Type |  | Time |  | CoMo-Object/CGMES- Object |
| --- | --- | --- | --- | --- | --- | --- | --- |
|  |  |  |  |  | Series / |  |  |
|  |  |  |  |  | Constan |  |  |
|  |  |  |  |  | t |  |  |
| RA- SystemOperatorCo de | SystemOperatorCo de based on the RA- Profile | - | Strin g |  |  |  | Constant RA-Profile: RemedialAction. systemOperatorCode |
| ControlArea-EIC | EnergyIdentCode based on the Control Area |  | Strin g |  |  |  | Constant EQ-Profile: ControlArea. energyIdentCodeEic |
| ControlArea-Name | Name based on the Control Area |  | Strin g |  |  |  | Constant EQ-Profile: ControlArea.name |
| AE- SystemOperatorCo de | SystemOperatorCo de based on the AE- Profile |  | Strin g |  |  |  | Constant AE-Profile: AssessedElement. assessedSystemOperatorCo de |

Mapping of EICs to country code:

| EIC Code | Country Code |
| --- | --- |
| 10XAT-APG------Z | AT |
| 10YAT-APG------L | AT |
| 10X1001A1001A094 | BE |
| 10YBE----------2 | BE |
| 10XCH-SWISSGRIDC | CH |
| 10YCH-SWISSGRIDZ | CH |
| 10XCB-CZ-COMP--D | CZ |
| 10YCZ-CEPS-----N | CZ |
| 10XCZ-CEPS-GRIDE | CZ |

<!-- page 24 -->

| 10XDE-EON-NETZ-C | D2 |
| --- | --- |
| 10YDE-EON------1 | D2 |
| 10XDE-ENBW--TNGX | D4 |
| 10YDE-ENBW-----N | D4 |
| 10XDE-RWENET---W | D7 |
| 10YDE-RWENET---I | D7 |
| 10XDE-VE-TRANSMK | D8 |
| 10YDE-VE-------2 | D8 |
| 10XFR-RTE------Q | FR |
| 10YFR-RTE------C | FR |
| 10XHR-HEP-OPS--A | HR |
| 10YHR-HEP------M | HR |
| 10X1001A1001A329 | HU |
| 10YHU-MAVIR----U | HU |
| 21X000000001333E | LU |
| 10YLU-CEGEDEL-NQ | LU |
| 10X1001A1001A361 | NL |
| 10YNL----------L | NL |
| 10XPL-TSO------P | PL |
| 10YPL-AREA-----S | PL |
| 10XRO-TEL------2 | RO |
| 10YRO-TEL------P | RO |
| 10XSI-ELES-----1 | SI |
| 10YSI-ELES-----O | SI |
| 10XSK-SEPS-GRIDB | SK |
| 10YSK-SEPS-----K | SK |

###### Business Rules

For the different results the TSO name is determined as specified below:

RemedialActions

- Based on the given system operator code

Loadflow Results

- Based on the given EIC from the control area

TSO-Exchanges

- Based on the given EIC from the control area

- Fallback: Based on the name from the given control area

Countertrade Results

- Based on the given EIC from the control area

- Fallback: Based on the name from the given control area

Net Position Results

<!-- page 25 -->

- Based on the given EIC from the control area

- Fallback: Based on the name from the given control area

Assess Elements

- Based on the given assessed system operator code

System Constraints

- Based on the given assessed system operator code

The TSO specific parameters are mapped to the input data from the NC-Profiles as specified below: RemedialActions

- Based on the given system operator code

Assess Elements

- Based on the given assessed system operator code

EIC is not recognized

- Result-Files:

o If the EIC is not recognized, the TSO attribute of the result files is empty.

o If the EIC is empty, the TSO attribute of the result files is set to “TSO empty”

- TSO specific control parameters

o If the EIC is not recognized the default control parameters are used

- There are no log messages if the EIC is not recognized

###### Triggers

The RAO started successfully and all pre-conditions are met.

###### Pre-Condition

All relevant input data is delivered, see: CORNET-4847: Consideration of Countertrade.

At least one correctly defined assessed element is part of the AE-FlatList.

The RAO must finish the optimization successfully.

###### Acceptance Criteria

###### Basic Flow

The RAO results are exported to CDS.

###### Alternative Flow

If the RAO fails, no result data is exported.

<!-- page 26 -->

### 3.3 LF Computation

#### CORNET-97: Load flow computations on a grid model

##### Description

During the RAO process, several load-flow calculations are carried out on the basis of the CorNet data model (see CORNET-12 - RAO procedure). The load-flow calculation module is based on the Newton- Raphson method, in which a solution to the non-linear and non-convex power equations is sought iteratively. The load-flow iteration according to Newton-Raphson is terminated when the power deviation at all nodes is below a parameterizable iteration limit. The iteration limit applies to both active power (MW) and reactive power (MVar).

> **Figure (page 26) — described in text.**
>
> Screenshot of the solver's *Iteration* log for a converging load flow. Header line: *Iteration-Barrier: 0.049999 MW or Mvar*. Columns are Step-No., Convergence nodes, Average deviation, Step size:
>
> | Step-No. | Convergence nodes | Average deviation | Step size |
> | --- | --- | --- | --- |
> | 0 | 2 | 82.672966003418 | – |
> | 1 | 2 | 0.257225245237 | 1.00000 |
> | 2 | 6 | 0.000006671186 | 1.00000 |
>
> The deviation falls below the barrier within three steps at full step size.

Figure: Exemplary table for an iteration-information example

In the example above, a good-natured iteration is shown. The solution is reached in only two steps. It is also a very small grid, as can be seen from the reported "convergence nodes". Grids of continental Europe also converge within about seven steps with a smooth iteration process. A deterioration of the average power deviation (i.e. a divergence) is prevented by the programme by shortening the step size. In the case of the good-natured iteration process, the "step size" is 1.0 throughout. The step size is to be understood here as a factor for the change of the voltages and other system variables. The "1.0" corresponds to an adjustment up to the zero crossing of the tangent (see figure below).

<!-- page 27 -->

> **Figure (page 27) — described in text.**
>
> Same *Iteration* log, but for a **non-convergent** case, shown above an explanatory sketch.
>
> | Step-No. | Convergence nodes | Average deviation | Step size |
> | --- | --- | --- | --- |
> | 0 | 6 | 3917.500000000000 | – |
> | 1 | 6 | 986.600097656250 | 1.00000 |
> | 2 | 6 | 958.789062500000 | 0.272486 |
> | 3 | 6 | 945.820495605469 | 0.119108 |
> | 4 | 6 | 940.769042968750 | 0.0516255 |
> | 5 | 6 | 938.457824707031 | 0.0243238 |
> | 6 | 6 | 935.449951171875 | 0.00664450 |
> | 7 | 6 | 935.447998046875 | 4.04857E-006 |
>
> Below, a blue U-shaped curve labelled *Average deviation* is plotted against the system variable, with red tangent lines drawn at successive iteration points 0, 1, 2, 3. Step 0 sits high on the right branch; its tangent crosses the axis a full step away (*step size = 1.0*). Later tangents intersect the axis closer and closer to the minimum, so the step size is repeatedly shortened (*shortened step size*, annotated −0.272). A red marker at the far left of the curve is labelled *no convergence*, with the note *(as no intersection)* — the tangent there never crosses the axis, so no step can be derived and the deviation stagnates around 935 instead of falling to zero.

Figure: Exemplary figure for the iteration-information - example for non-convergence

In this figure, from the second step onwards, a further improvement of the "average power deviation" can only be achieved by an increasingly drastic step size reduction. Finally, the step size is so small that the changes in the system variables are insignificant. The load-flow solution is not convergent. An approximated solution is provided (see also CORNET-106 - Behaviour with non-convergent LF- solutions).

The step size is shortened as soon as the average power deviation does not decrease in one iteration. The step size is calculated from:

$$
C_{k} = \frac{G_{k}}{(G_{k+1} + G_{k})} \tag{3.1}
$$

$G_{k}$: Sum of least squares at position $X= X_{k}$

<!-- page 28 -->

$G_{k+1}$: Sum of least squares at position $X= X_{k+1} = X_{k} + \mathit{dX}$

$X_{k}$: State vector in iteration k of Newton-Raphson-method

$\mathit{dX}$: Difference of state vector between two iterations

The objective of the load-flow calculation is to determine missing values for each grid node in order to subsequently calculate the active and reactive power flows, currents and finally the loadings for each net element.

Based on the given and searched values, different node types result in the grid. The node type is defined by the connected bus element. Bus elements are generation and load units. For nodes to which only bus elements with constant power are connected, P and Q are input data for the calculation (PQ $\mathit{nodes}). \mathit{The} \mathit{voltage} \mathit{amount} V \mathit{and} \mathit{the} \mathit{voltage} \mathit{phase} \mathit{angle} \theta \mathit{are} \mathit{unknown}. \mathit{The} \mathit{same} \mathit{applies} \mathit{to} \mathit{all}$ nodes in the grid without connected bus elements, whereby the active and reactive power at the node is selected to be zero. For nodes with voltage-regulated feed-ins, the active power feed-in P and the voltage amount V are specified (PV nodes), the reactive power feed-in and the voltage phase angle are unknown here and must be determined by the load flow calculation. Since the voltage angle at a node must be specified, a slack node is required. The slack node is selected according to the parameterization of the grid model. At this node, the voltage angle is set to 0 as a reference point and the voltage amount is also specified.

A power imbalance is not compensated by the slack but instead compensated by several load units (see CORNET-105 - Active power control).

|  | Node type Given value Sought value |  |
| --- | --- | --- |
| PQ-Node | P, Q | $V, \theta$ |
| PV-Node | P, V | $Q, \theta$ |
| $\mathit{Slack}-\mathit{Node} V, \theta$ |  | P, Q |

The input data for the load-flow calculation are derived from the CorNet data model.

System Requirement: SRQ843

#### CORNET-103: Consideration of PSTs in LF computation

##### Description

The RAO LF module is able to consider all transformer types within the load-flow calculation. An automatic tap changing is not considered in the load flow calculation. Instead, the current tap position of the PST is input data for the calculation.

<!-- page 29 -->

System Requirement:

#### CORNET-104: Handling of PV/PQ-Conversions

##### Description

The calculation of the reactive power feed-in of PV nodes within the load flow calculation can lead to inadmissibly high inductive or capacitive reactive power values of the generation units connected to the node. If the reactive power limits of a generation unit at the PV node are not complied with, the corresponding PV node is converted into a PQ node. The voltage control of the connected generation units is thus switched off. This releases the voltage of the node and changes the node type. The reactive power of the affected generation units is set to the violated limit and the load flow is calculated in further iterations.

With the help of a RAO Control Parameter (PV->PQ conversion permitted), it can be parameterized whether a PV-to-PQ conversion is to be carried out by the load flow calculation in the event that reactive power limits are exceeded at PV nodes. If PV to PQ conversion is not taken into account, the reactive power limits of generation units are ignored.

| Name | Description | Unit | Data object |
| --- | --- | --- | --- |
| Qmax | Upper limit of reactive power |  | MVar Generation unit |
| Qmin | Lower limit of reactive power |  | MVar Generation unit |
| PVtoPQ | Conversion of node property PV to PQ in case of violation of the reactive power limit | - | RAO Control Parameter |

System Requirement:

#### CORNET-105: Active power control

##### Description

Since the active power losses are not known a priori in a complex load flow calculation, an active power control is required within the framework of the load flow calculation. An active power balancing via loads is implemented. All loads in the grid model participate proportionally to their active power in the base case.

<!-- page 30 -->

$$
\Delta P_{0l,i} = P_{\mathit{deficit}} \frac{|P_{0l,i} |}{\sum |P_{0l} |} \tag{3.2}
$$

$P_{0l,i}$: Active power of load

$P_{\mathit{deficit}}$: Active power deficit of active power balance

$\Delta P_{0l,i}$: Delta active power of load

The load flow calculation does not consider active power limits of loads.

The load flow calculation considers the active power balance of the whole grid in the active power control.

In the load flow calculation, the Jacobian matrix derived from the node admittance matrix is generated for the Newton-Raphson method. In the Jacobian matrix, the proportional participation of the loads in the active power balancing is mapped.

The active power control is carried out according to the amount of the active power values of the loads in the N-0 base case. The higher the amount of the active power value of the load in the base case, the higher the control share.

System Requirement:

#### CORNET-111: Initial LF calculation with non-convergence

##### Description

If the initial load-flow calculation of the RAO procedure (see CORNET-12 - RAO procedure) has a non- convergence result, the RAO procedure stops and a log entry is created.

System Requirement:

#### CORNET-106: Behaviour with non-convergence LF-solutions

##### Description

In case of non-convergence of the load flow calculation, an approximated solution is determined (see also CORNET-98 - LF result output). This is a non-physical result in which the sum of the node balance deviations is minimal. In this approximated solution, Kirchhoff's rules are violated, so it cannot be used to evaluate the grid state.

<!-- page 31 -->

For each grid node, however, the errors of the node balances are output separately for active and reactive power (MismatchP and MismatchQ). Usually, the causes for non-convergence are to be found in the vicinity of those nodes where the errors of the node balance have the highest amount. In addition, an examination of the voltage amounts of the approximated solution can provide information about the location of the cause for the non-convergence.

Questionable voltage amounts refer to grid nodes in whose vicinity the cause for the non-convergence of the load flow calculation could also be located. Questionable voltage amounts are values that deviate very strongly from the nominal voltage of the node.

In the first load flow iteration, the reactive power of PV feed-ins is initially assumed to be unlimited. Subsequently, those feed-ins that were regulated beyond their limits are then limited. Afterwards, the load flow may no longer converge because too few voltage-regulating generation units are active locally. In most cases, only a few of the reactive power feed-ins with limit violations are responsible for the non- convergence. To narrow down the cause of non-convergence, the user can, for example, widen the limits for the voltage regulating generation units. Afterwards, the original limits can be reinstated step by step until the non-convergence occurs again after a limitation. In this way, the cause of the non-convergence can be localized. Alternatively, a PV/PQ conversion can be automated. In the event of non-convergence, a log entry can be viewed in which errors and warnings are written with an indication of the causes. In the event of non-convergence, grid-related results are available, including the nodes at which the specified iteration limits cannot be met (see CORNET-98 - LF result output).

System Requirement:

#### CORNET-98: LF Result output

##### Description

The RAO outputs the results of the initial load-flow calculation before the optimisation and of the last load-flow calculation within the optimisation procedure (see CORNET-12 - RAO procedure). The results are given

• per topological node ( CORNET-107 )

• per AC line segment and 2W transformer ( CORNET-108 )

• per 3W transformer ( CORNET-109 ).

<!-- page 32 -->

System Requirement: SRQ835

#### CORNET-107: Results per topological node

##### Description

The results per topological node are:

| Name | Description | Unit | Data type | CoMo-Object |
| --- | --- | --- | --- | --- |
| Voltage | Voltage magnitude | kV | float | RAOResult load- flow node |
| Angle | Voltage angle | ° | float | RAOResult load- flow node |
| SumP | Sum of active power from generation and load units | MW | float | RAOResult load- flow node |
| SumQ | Sum of reactive power from generation and load units | MVar float |  | RAOResult load- flow node |
| MismatchP | Node mismatch of active power, relevant when load flow calculation non-convergent | MW | float | RAOResult load- flow node |
| MismatchQ | Node mismatch of reactive power, relevant when load flow calculation non-convergent | MVar float |  | RAOResult load- flow node |
|  | PsharedGen Active power per node | MW | float | RAOResult load- flow node |
|  | QsharedGen Reactive power per node | MVar float |  | RAOResult load- flow node |
| mIRD | mIRD of the element | - | string | RAOResult load- flow node |
| Name | CGMES-Name of the element | - | string | RAOResult load- flow node |

System Requirement:

<!-- page 33 -->

#### CORNET-3221: Results per AC line segment and 2W transformer

This is an update for CORNET-108 and replaces the specification.

##### Description

The results per AC line segment or 2W transformer are given for the beginning and end each:

| Name | Description Unit |  | Data type | CoMo-Object |
| --- | --- | --- | --- | --- |
| P | Active power for connection side of element | MW | float | SAR: PowerFlowResult.valueW |
| Q | Reactive power for connection side of element | MVa r | float | SAR: PowerFlowResult.valueVA |
| I | Absolute current for connection side of element | A | float | SAR: PowerFlowResult.valueA |
| S | Apparent power for connection side of element | MVA float |  | SAR: PowerFlowResult.valueVAR |
| Load | Maximum loading (start and end) of PATL | % | float | SAR: PowerFlowResult.value |
| Limit | Maximum loading of | % | float | SAR: PowerFlowResult.limit |

<!-- page 34 -->

|  | element in optimisation |  |  |  |
| --- | --- | --- | --- | --- |
| Type_Elemen t | Type of the assessed element (e.g. scanned element, XNE) |  | enum | SAR: PowerFlowResult.aeType |
| ResultType | Definiton of the Result Type ( BaseCase , Contingency ) | - | PowerFlowResultKin d | SAR: PowerFlowResult.powerFlowResultTyp e |
| Side | Side of the branch (begin, end) | - | enum branchSide (begin, end) | SAR: PowerFlowResult.side |
| mIRD | mIRD of the element | - | string | SAR: PowerFlowResult.mRID |
| Name | CGMES- Name of the element | - | string | SAR: PowerFlowResult.name |

Business Needs : BN788: RAO-Scanned_Elements_MVP (RAO)

#### CORNET-109: Results per 3W transformer

##### Description

The results per 3W tranformer are:

| Name | Description | Unit | Data type | CoMo-Object |
| --- | --- | --- | --- | --- |

<!-- page 35 -->

| Pw1 | Active power for winding 1 of transformer | MW | float | Security Analysis Result Profile |
| --- | --- | --- | --- | --- |
| Pw2 | Active power for winding 2 of transformer | MW | float | Security Analysis Result Profile |
| Pw3 | Active power for winding 3 of transformer | MW | float | Security Analysis Result Profile |
| Qw1 | Reactive power for winding 1 of transformer | MVar float |  | Security Analysis Result Profile |
| Qw2 | Reactive power for winding 2 of transformer | MVar float |  | Security Analysis Result Profile |
| Qw3 | Reactive power for winding 3 of transformer | MVar float |  | Security Analysis Result Profile |
| Iw1 | Absolute current for winding 1 of transformer | A | float | Security Analysis Result Profile |
| Iw2 | Absolute current for winding 2 of transformer | A | float | Security Analysis Result Profile |
| Iw3 | Absolute current for winding 3 of transformer | A | float | Security Analysis Result Profile |
| Sw1 | Apparent power for winding 1 of transformer | MVA float |  | Security Analysis Result Profile |
| Sw2 | Apparent power for winding 2 of transformer | MVA float |  | Security Analysis Result Profile |
| Sw3 | Apparent power for winding 3 of transformer | MVA float |  | Security Analysis Result Profile |
| LoadMax | Maximum loading (start and end) of PATL | % | float | Security Analysis Result Profile |
| mIRD | mIRD of the element | - | string | Security Analysis Result Profile |
| Name | CGMES-Name of the element | - | string | Security Analysis Result Profile |

<!-- page 36 -->

System Requirement:

### 3.4 CA Computation

#### CORNET-3691: Fast Outage Approximation

##### Simplified Explanation

A simplified explanation of the fast outage approximation is given in the following:

1. The contingency element is deleted from the admittance matrix so that the line is no longer considered for calculation of load flow.

2. Modelling of two new virtual injections at end nodes of the line in contingency equal to the negative value of the active/reactive power flow of the line before the contingency.

3. Calculation of flows on all grid elements with the new set of virtual injections (this flow is an approximated N-1 flow)

The effect of the contingency on load flows is approximated with the effect of two new virtual injections at the nodes of the line in contingency and removal of the line in contingency from the admittance matrix.

The time benefit of the calculation comes from avoiding the creation of new matrices and solving non- linear equations in several iterations. The flows of the contingency case are just recalculated on existing matrices from the base case load flow calculation, with modifications made to reflect the two virtual injections at the nodes of the branch in contingency.

##### Description

Since a complete contingency simulation in a large grid model via an AC load-flow calculation with a Newton-Raphson approach for each contingency situation requires high computing times, a module called Fast Outage Approximation (FOA) for an approximation of the load-flow in each contingency situation is provided. In this case, a complete load-flow calculation is only carried out for the base case (N-0), which saves about 95-99% of the required calculation time. The methodology of the FOA was developed for fast power flow approximations of large amounts of topological modifications in detailed transmission grid models .

Note : The contingency situations must be part of the largest connected AC-subgrid to be considered within the FOA.

J. Eickmann, J. Kellermann, and A. Moser: Efficient Power Flow Approximation Methodology for Topology Optimization Algorithms in Transmission System Operation; RWTH Aachen University, Germany; 2015

<!-- page 37 -->

In summary, the FOA can be broken down into seven steps (see Figure below). At first, an AC load- flow for the base case (N-0) is calculated. Next, the disconnection of the contingency element has to be considered in the admittance matrix of this load-flow calculation. The element is therefore removed from the admittance matrix to reflect this disconnection.

This modified admittance matrix is used to determine in step three the Jacobian matrix. Modifications on this Jacobian matrix are made to reflect PV and slack nodes in the grid. This modified Jacobian matrix is used together with an injection vector, which represents the injected active and reactive power of the start and end nodes, to calculate the change in voltage in the whole grid after the contingency. These resulting changes in voltage are used to calculate the resulting voltages in the grid in the contingency case. The resulting currents and therefor loadings of elements in the contingency case are determined from these new voltages.

> **Figure (page 37) — described in text.**
>
> Vertical flowchart of the Fast Outage Approximation, drawn as a stack of six boxes inside a multi-sheet frame (indicating the loop runs once per contingency), fed from a single box on top:
>
> *Initial power flow calculation* → *Modifying admittance matrix* → *Determining power injections* $\vec{S}_{c,inj}$ → *Adjusting Jacobian matrix* $\underline{\tilde{J}}^{c}$ → *Solving* $\underline{\tilde{J}}^{c}\cdot\Delta\vec{\underline{U}} = \vec{S}_{c,inj}$ → *New state* $\vec{\underline{U}} = \vec{\underline{U}}_{0} + \Delta\vec{\underline{U}}$ → *Calculating branch currents*.

Figure: Calculation of a branch contingency with the FOA

Explaining the AC load-flow during the outage of an element can be approximated by the superposition of the initial load-flow situation and the change of nodal voltages caused by the contingency. This change of nodal voltages can be calculated by the injection of the complex power flow (active and reactive power) on the element before the contingency (derived from the load-flow calculation) and considering the topology including the contingency as illustrated in the figure below.

<!-- page 38 -->

> **Figure (page 38) — described in text.**
>
> Superposition sketch for the fast (N-1) approximation, showing three identical cross-hatched two-port network blocks combined as **left + middle ≈ right**.
>
> *Left:* the intact system — the outage element carries current $\underline{I}_a$ along its upper branch, with terminal voltages $\underline{U}_i$ and $\underline{U}_j$ at the bottom nodes.
> *Middle:* the correction case — the upper branch is replaced by a dashed double-headed arrow labelled *Power Injection*, and the bottom terminals carry the voltage deviations $\Delta\underline{U}_i^{a}$ and $\Delta\underline{U}_j^{a}$.
> *Right:* the result — the upper branch is disconnected at both ends (open circles, no connection), annotated $\underline{I}_a \approx 0$, with resulting terminal voltages $\underline{U}_i^{a}$ and $\underline{U}_j^{a}$.
>
> The message: injecting the pre-outage power at both ends of the element cancels its current, which is equivalent to removing the element.

Figure: Power injection for fast (N-1) approximation

To calculate an element outage, the admittance matrix of the full common grid model (CGM) is modified by removing the corresponding matrix elements $\underline{Y}_{c,11} ,\underline{Y}_{c,12} ,\underline{Y}_{c,13} , \underline{Y}_{c,14}$ of the outage element. The modified admittance matrix $\underline{\boldsymbol{Y}}^{\boldsymbol{c}}$ serves as the basis for the calculation of the modified Jacobian matrix $\underline{\boldsymbol{\tilde{J}}}^{\boldsymbol{c}}$ in contingency case c. Special attention has to be paid to the handling of slack and PV nodes within the calculation. The impact of the contingency on the nodal voltages can then be calculated by solving the system of equations in (3.3). This procedure is equivalent to one iteration of the Newton-Raphson algorithm starting from the normal operation load-flow result. Here $\Delta \vec{x}^{c}$ is the systems state vector with the deviation of voltages and voltage angles at each node and $\vec{S}_{c,\mathit{inj}}$ is the vector including the injected powers at both ends of the outage element.

$$
\boldsymbol{\tilde{J}}^{c} \cdot \Delta \vec{x}^{c} = \vec{S}_{c,\mathit{inj}} \tag{3.3}
$$

The injected powers result from the element currents at the beginning and end of the element multiplied with the complex node voltages.

$$
\underline{S}_{c,1,\mathit{inj}} = \underline{U}_{c,1} \cdot \underline{I}_{c,1}^{*} = \underline{U}_{c,1} \cdot (\underline{Y}_{c,11} \underline{U}_{c,1} + \underline{Y}_{c,12} \underline{U}_{c,2} )^{*} \\
\underline{S}_{c,2,\mathit{inj}} = \underline{U}_{c,2} \cdot \underline{I}_{c,1}^{*} = \underline{U}_{c,2} \cdot (\underline{Y}_{c,21} \underline{U}_{c,1} + \underline{Y}_{c,22} \underline{U}_{c,2} )^{*} \tag{3.4}
$$

Solving equation (3.3) using the injected powers in equation (3.4) leads to the change of voltages and voltage angles at each network node. These changes describe the influence of the contingency on the rest of the system and can be used to determine the influence on line flows and to monitor possible N- 1 violations. Since the computational effort for a matrix inversion is very high, it is important to solve equation (3.3) without matrix inversion. Since the sparsity of the matrix is very large, sparse linear solvers are used.

<!-- page 39 -->

With R24Q2 ordinary (single) contingencies of lines and transformers as well as exceptional (multi-) contingencies containing a combination of contingencies of lines and transformers are considered within the Fast Outage Approximation.

Note : If a contingency results in a split of the largest AC-subgrid into smaller AC-subgrids, the contingency is not considered by the RAO.

#### SF3072: Fast Contingency Calculation

##### Scenario

UC8766: BUC 14#116 Calculation of power generation unit contingencies

UC8767: BUC 14#117 Calculation of demand facility contingencies

UC8768: BUC 14#118 Calculation of voltage compensation device contingencies

UC793: BUC 14#57 Calculation of busbar and busbar coupler contingencies

UC8866: BUC 14#129 Calculation of exceptional contingencies

The RAO must be able to calculate load flows in contingency situations. In cases where the FOA could not sufficiently calculate the contingency situation, the FCC is used.

##### Description

The Fast Outage Approximation (FOA) of the RAO (see CORNET-3691: Fast Outage Approximation) is used to determine the currents and voltages on all grid elements for a contingency situation. The methodology used in the FOA has an advantage regarding the calculation time, especially for a very high number of contingency situations compared to a contingency calculation based on a full load-flow calculation. The accuracy of the approximation methodology is very good for certain contingency situations, such as line and transformer outages. Other contingency situations, such as the failure of a busbar, resulting in the outage of several branches, could lead to a lower accuracy of the FOA result. Therefore, the RAO calculates these contingency situations with an alternative approach, called Fast Contingency Calculation (FCC).

<!-- page 40 -->

> **Figure (page 40) — described in text.**
>
> The same two-lane BPMN diagram as Figure 1 on page 9, repeated here as *Figure 2: Overview of RAO Calculation process* — RAO System lane (submit to HPC, four error paths, terminate or write output) above the HPC lane (initialise → AC load flow → expand contingencies by SPS → contingency calculation → the AC-sensitivity / build MILP / solve MILP / AC load flow / linearisation / cycling / iteration-count / new outages loop → calculate and save result to S3).

Figure 2: Overview of RAO Calculation process

<!-- page 41 -->

The FCC is based on a contingency calculation with a full iterative Newton-Raphson load-flow calculation (see CORNET-97: Load flow computations on a grid model).

Any active power imbalances resulting from a contingency are handled according to CORNET-105. To speed up the calculation times, the load-flow calculation to determine the new voltages and currents during the contingency utilizes an initial state as a starting point for the initial guess of the state variables (see Figure 3). This initial state is derived from the base case (N-0) load-flow calculation and applied on the modified bus-branch model of the grid for the contingency situation. The modification refers to the removal of the outage elements, e.g. by opening breakers.

By the assumption that not all state variables ($V^{\mathit{initial}}$ and $\theta^{\mathit{initial}}$) and branch variables of the grid change a lot because of the contingency, the Newton-Raphson load-flow calculation needs fewer iterations to achieve a convergence solution with the new state variables ($V^{\mathit{new}}$ and $\theta^{\mathit{new}}$) and calculated branch variables as a result. Eventually, this results in a lower calculation time of the FCC compared to a contingency calculation with a full load-flow calculation (e.g. with a Newton-Raphson approach) while retaining the same benefits, such as being able to calculate all possible contingency situations.

Initial guess( and )

##### Base case load-flow calculation

- Determining state variables (N-0)

- Calculating branch variable (N-0)

Initial state ( and )

##### Fast state determination

Applying switching action Initial state as initial guess

Modified bus-branch model

Load-flow calculation

(Determining state variables (N-1))

New state ( and )

Calculating branch variables (N-1)

for each

contingency

Figure 3: Overview of Fast Contingency Calculation process

<!-- page 42 -->

The calculation time of the FCC is higher than with the FOA for the same contingency situation, e.g. for a branch failure. Therefore, only contingency situations which cannot be calculated by the FOA are instead calculated via the FCC. These are primarily situations which result in a change of the number of nodes with the contingency. This results in the lowest total calculation time for all contingency situations.

The RAO utilizes the FCC for the following contingency situations:

• Loss of a single voltage compensation device (only StaticVarCompensator and ShuntCompensator ) (ordinary contingency)

• Loss of a single power generation unit (ordinary contingency)

• Loss of a single demand facility (ordinary contingency)

• loss of a single busbar coupler, in case it is protected by an overcurrent protection device (ordinary contingency)

• loss of a single busbar coupler, in case it is protected by an over-/under-voltage protection device (ordinary contingency)

• loss of network elements having common fault mode, meaning that a single fault will lead to the loss of more than one network element (exceptional contingency)

• loss of grid users having common process mode, meaning that the total or partial sudden loss of one grid user will lead to the total or partial loss of the others (exceptional contingency) • loss of network elements/ users simultaneously disconnected as a result of the operation of a Special Protection Scheme (exceptional contingency)

• loss of multiple generation units disconnected because of a voltage drop on the network (exceptional contingency)

In case of losses of elements with common process mode and disconnections of multiple generation units due to voltage drops, all affected generation units have to be modelled as multiple single generation units being outaged at the same time.

In general, the Fast Outage Approximation would also be able to calculate the loss of generating and demand units. Previous research has shown that in certain situations these contingencies could result in an insufficient accuracy of the resulting power flows. This behaviour was seen when units are highly involved in the voltage regulation of the grid.

Consideration of HVDC in the FCC

The loss of HVDC connections is modelled by the loss of the equivalentInjections , which represent the HVDC converters between the DC and AC-system. In order to model the total loss of an HVDC system in a synchronous area, the equivalentInjections from both sides of the HVDC connection must be

<!-- page 43 -->

defined as the contingency equipment in the contingency situation. If the contingency situation is insufficiently modelled, i.e. containing only side, the RAO cannot detect this error and the calculation will lead to wrong results.

For HVDC connecting asynchronous systems usually only one converter side is modelled with equivalentInjections . In this case the contingency can be modelled with only the one converter side (and therefore equivalentInjection ) be defined as the contingency equipment in the contingency situation.

When each HVDC converter side is modelled by two equivalent injections, one for active power P and one for reactive power Q, all equivalentInjections should be part of the contingency situation. In certain contingencies a failure of only the equivalentInjection representing the active power part is also possible.

Calculation of topological CRAs

As specified in BUC 14#105 topological CRAs can only be calculated with the FCC. This is due to the detailed consideration of switch gear in that calculation module.

##### Outlook

In future releases a better distribution of contingency situations on the FOA and FCC could be implemented to increase the performance of the contingency calculation. Certain types of contingencies, e.g. loss of a single power generation unit, could be either calculated with the FOA or FCC, depending on certain properties of the contingency equipment.

##### Configuration

For input data, see SF3073: RAO Input Data - Contingencies.

For output data, see BUC 14#142 Results of contingency calculation.

##### Business Rules

The RAO must be able to calculate all contingency situations with the FCC. By default, the control parameter specified in BUC 14#113 is deactivated, limiting the usage of the FCC to the following contingency situations:

• Loss of a single voltage compensation device (only StaticVarCompensator and ShuntCompensator ) (ordinary contingency)

• Loss of a single power generation unit (ordinary contingency)

• Loss of a single demand facility (ordinary contingency)

• loss of a single busbar coupler, in case it is protected by an overcurrent protection device (ordinary contingency)

<!-- page 44 -->

• loss of a single busbar coupler, in case it is protected by an over-/under-voltage protection device (ordinary contingency)

• loss of network elements having common fault mode, meaning that a single fault will lead to the loss of more than one network element (exceptional contingency)

• loss of grid users having common process mode, meaning that the total or partial sudden loss of one grid user will lead to the total or partial loss of the others (exceptional contingency) • loss of network elements/ users simultaneously disconnected as a result of the operation of a Special Protection Scheme (exceptional contingency)

• loss of multiple generation units disconnected because of a voltage drop on the network (exceptional contingency)

##### UC8766: BUC 14#116 Calculation of power generation unit contingencies

Contingency situations with the EquipmentType gen are calculated with the FCC.

##### UC8767: BUC 14#117 Calculation of demand facility contingencies

Contingency situations with the EquipmentType load are calculated with the FCC.

##### UC8768: BUC 14#118 Calculation of voltage compensation device contingencies

Contingency situations with the EquipmentType shuntCompensator or staticVarCompensator are calculated with the FCC.

##### UC793: BUC 14#57 Calculation of busbar and busbar coupler contingencies

Contingency situations with the EquipmentType bus or busbar are calculated with the FCC.

##### UC8866: BUC 14#129 Calculation of exceptional contingencies

Network elements having a common fault mode or common process mode, network elements simultaneously disconnect as a result of SPS and losses of multiple generation units due to voltage drops are calculated with the FCC.

##### Triggers

The RAO started successfully and all pre-conditions are met.

##### Pre-Condition

At least one correctly defined assessed element is part of the AE-FlatList.

<!-- page 45 -->

At least one correctly defined contingency situation must be part of the CO-FlatList and this contingency situation must be of the correct kind to be calculated with the FCC or the control parameter useFCConly is set to True.

The initial load-flow converged.

##### Acceptance Criteria

See SF3073 RAO Input Data - Contingencies

##### Basic Flow

The following log-messages are exposed during the initialization of the internal data model:

• Name of CO calculated with FCC

• MRID calculated with FCC

• The following log-messages are exposed during the FCC: In case a contingency case cannot be calculated successfully a warning is logged.

• In case a contingency case cannot be calculated due to an technical error an error is logged. The results are exported via the SecurityAnalysisResultProfile (see BUC 14#142 Results of contingency calculation).

##### Alternative Flow

No alternative flow is foreseen.

#### BUC 14#113 Using FCC for all contingency situations in RAO

##### Scenario

#### BUC 14#113 Using FCC for all contingency situations in RAO

By default, the RAO allocates the FOA and FCC calculation modules to contingency situations. By activating a control parameter, all contingency situations are calculated using the FCC module.

##### Description

The RAO uses different modules to calculate various contingency situations. Due to advantages in calculation time, Fast Outage Approximation (FOA, see: CORNET-3691) is used for most contingency situations. For exceptional contingency situations, in which the FOA could lead to results of insufficient accuracy, the more accurate Fast Contingency Calculation (FCC, see: CORNET-4634) is used. For certain RAO runs, e.g. for the comparison and analysis of contingency calculations, the user must be able to calculate all contingency situations using FCC.

<!-- page 46 -->

When the control parameter (useFCCOnly) is activated, all contingency situations are calculated using FCC.

##### Configuration

The following input data is needed for the RAO:

| Name | Description | Unit | Data Type |  | Time | CoMo-Profile |
| --- | --- | --- | --- | --- | --- | --- |
|  |  |  |  |  | Series/ |  |
|  |  |  |  |  | Constant |  |
| useFCCOnly | Control parameter for the module used for contingency calculation. If activated, all contingency situations are calculated using FCC. | - | Boolean | constant |  | RAOControlPa rameterProfile: RAOControlPa rameterSet.use FCCOnly |

##### Business Rules

If the control parameter is not set, the RAO chooses either FOA or FCC as the calculation module depending on the type of contingency situation. The default allocation of FOA and FCC to the types of contingency situations is done according to their respective FS (FOA, see CORNET-3691; FCC, see SF3072). Contingencies with topological CRAs are always calculated using FCC (see BUC14#105: Application of proposed topological CRAs). Activating the control parameter forces FCC for all contingencies.

##### Triggers

The RAO is started successfully and all pre-conditions are met.

##### Pre-Condition

The control parameter useFCCOnly is activated.

At least one correctly defined assessed element is part of the AE-FlatList.

At least one correctly defined contingency situation must be part of the CO-FlatList.

The initial load-flow converged.

##### Acceptance Criteria

Given

The user activates the useFCCOnly setting before starting the RAO run.

When

The RAO run starts,

Then

<!-- page 47 -->

All contingency situations are calculated with the Fast Contingency Calculation module.

Given

The parameter useFCConly is not activated before starting the RAO run.

When

The RAO run starts,

Then

The allocation of Fast Outage Approximation and Fast Contingency Calculation to the contingency situations is conducted according to the FOA and FCC functional specifications.

##### Basic Flow

The following log messages are exposed:

• Number of contingencies calculated with FCC, which would have been calculated using FOA if the control parameter useFCCOnly was not activated

• Number of contingencies calculated with FCC, which would have been calculated using FCC

##### Alternative Flow

No alternative flow is foreseen.

<!-- page 48 -->

#### SF3073: RAO Input Data - Contingencies

##### Scenario

UC304: BUC 14#32 Consideration of multiple line/PST outages (exceptional contingencies) in RAO UC792: BUC 14#56 Consideration of busbar and busbar coupler contingencies

UC8766: BUC 14#116 Calculation of power generation unit contingencies

UC8767: BUC 14#117 Calculation of demand facility contingencies

UC8768: BUC 14#118 Calculation of voltage compensation device contingency

UC8866: BUC 14#129 Calculation of exceptional contingencies

##### Description

The relevant contingencies of each TSO for consideration in the Fast Outage Approximation as well as the Fast Contingency Calculation are provided via the common contingency list in the input data. The classification of these contingencies is based on the CSAm . The considered contingencies are: • ordinary (single contingency):

o loss of a single line / cable

o loss of a single transformer

o loss of a single phase-shifting transformer

o loss of a single busbar coupler, in case it is protected by an overcurrent protection device o loss of a single busbar coupler, in case it is protected by an over-/under-voltage protection device

o Loss of a single voltage compensation device (only Static Var Compensator and Shunt Compensator) (ordinary contingency)

o Loss of a single power generation unit (ordinary contingency)

o Loss of a single demand facility (ordinary contingency)

• exceptional (multi-contingency):

o loss of network elements having common fault mode, meaning that a single fault will lead to the loss of more than one network element (only fault on a busbar)

o loss of overhead lines built on the same tower

o loss of underground cables built in the same trench

o loss of grid users having common process mode, meaning that the total or partial sudden loss of one grid user will lead to the total or partial loss of the others (exceptional contingency)

Methodology for coordinated operational security analysis – Annex I (13 May 2024)

<!-- page 49 -->

o loss of network elements/ users simultaneously disconnected as a result of the operation of a Special Protection Scheme

o loss of multiple generation units disconnected because of a voltage drop on the network Note : Some contingency situations are only relevant for the TSO when modelling the contingency input data. For example, the RAO does not consider the protection device of the busbar coupler. This information is only relevant for the TSO when modelling the contingency situation.

The parameter mustStudy for each time stamp specifies if the contingency case must be taken into account by the RAO. The contingencyType contains the information whether a OrdinaryContingency or ExceptionalContingency (permanent and temporary) has to be calculated. The unique ID(s) of the outage element(s) is/are contained in the parameter ID for Contingency Equipment.

##### Configuration

Data requirements (input data) for assessment of contingencies in Fast Outage Approximation and Fast Contingency Calculation:

| Name | Description | Data type | Time | CoMo-Profile |  |
| --- | --- | --- | --- | --- | --- |
|  |  |  | series / |  |  |
|  |  |  | Constant |  |  |
| CO type | The class of the contingency (ordinary, exceptional or out of range) | Enumeration constant |  | ContingencyFlatList: Contingency.contingencyType: - ordinary - exceptional - outofRange |  |
| mustStudy | Set true if must study this contingency in time stamp. | Boolean | constant | ContingencyFlatList: Contingency.mustStudy |  |
| Equipment mRID | The identifier of the element used in the contingency | String | constant | ContingencyFlatList: ContingencyGroup -> Equipment.equipmentMrid |  |
| equipmentType | The type of the equipment used | Enumeration constant |  | ContingencyFlatList: |  |

<!-- page 50 -->

|  | in the contingency |  |  | ContingencyGroup -> Equipment.equipmentType |
| --- | --- | --- | --- | --- |

##### Business Rules

The RAO can only consider contingency types as defined in Description.

These contingencies must have a CoMo EquipmentType from the following list:

- line

- switch

- transformer

- gen

- load

- shuntCompensator

- staticVarCompensator

- busbar

##### Business Rules

UC304: BUC 14#32 Consideration of multiple line/PST outages (exceptional contingencies) in

##### RAO

The RAO considers contingency situations with more than one element from the EquipmentType line and transformer .

##### UC792: BUC 14#56 Consideration of busbar and busbar coupler contingencies

The RAO considers contingency situations with the EquipmentType bus or busbar .

##### UC8766: BUC 14#116 Calculation of power generation unit contingencies

The RAO considers contingency situations with the EquipmentType gen .

##### UC8767: BUC 14#117 Calculation of demand facility contingencies

The RAO considers contingency situations with the EquipmentType load .

##### UC8768: BUC 14#118 Calculation of voltage compensation device contingencies

The RAO considers contingency situations with the EquipmentType shuntCompensator or staticVarCompensator .

##### UC8866: BUC 14#129 Calculation of exceptional contingencies

The RAO considers contingency situations with more than one element from the EquipmentType gen or load .

<!-- page 51 -->

##### Triggers

The RAO started successfully and all pre-conditions are met.

##### Pre-Condition

All relevant input data is delivered, see Configuration.

At least one correctly defined assessed element is part of the AE-FlatList.

At least one correctly defined contingency situation must be part of the COFlatList.

The initial loadflow converged.

##### Acceptance Criteria

Given

No contingencies are available

When

The input data for the contingency calculation is processed,

Then

The RAO will not read any contingency data into the data model.

Given

The input data has a contingency situation which is defined as an ExceptionalContingency and represents the outage of multiple lines. Additionally, the control parameter useFCConly is not activated. When

The FOA successfully terminates in each iteration,

Then

That contingency situation must have been considered by the FOA and the approximated flows and loading of the grid calculated for the outage situation.

Given

The input data has a contingency situation which is defined as an ExceptionalContingency and represents the outage of multiple PST. Additionally, the control parameter useFCConly is not activated. When

The FOA successfully terminates in each iteration,

Then

That contingency situation must have been considered by the FOA and the approximated flows and loading of the grid calculated for the outage situation.

Given

<!-- page 52 -->

The input data has a contingency situation which is defined as an OrdinaryContingency and represents the outage of a single busbar coupler.

When

The FCC successfully terminates in each iteration,

Then

That contingency situation must have been considered by the FCC and the flows and loading of the grid calculated for the outage situation.

Given

The input data has a contingency situation which is defined as an ExceptionalContingency and represents the fault on a busbar resulting in the loss of multiple network elements (lines or cables). When

The FCC successfully terminates in each iteration,

Then

That contingency situation must have been considered by the FCC and the flows and loading of the grid calculated for the outage situation.

Given

The input data has a contingency situation which is defined as an OrdinaryContingency and represents the outage of a single voltage compensation device.

When

The FCC successfully terminates in each iteration,

Then

That contingency situation must have been considered by the FCC and the flows and loading of the grid calculated for the outage situation.

Given

The input data has a contingency situation which is defined as an OrdinaryContingency and represents the outage of a single power generating unit.

When

The FCC successfully terminates in each iteration,

Then

That contingency situation must have been considered by the FCC and the flows and loading of the grid calculated for the outage situation.

Given

<!-- page 53 -->

The input data has a contingency situation which is defined as an OrdinaryContingency and represents the outage of a single demand facility.

When

The FCC successfully terminates in each iteration,

Then

That contingency situation must have been considered by the FCC and the flows and loading of the grid calculated for the outage situation.

Given

The input data has a contingency situation which is defined as an ExceptionalContingency and represents the outage of multiple generating units.

When

The FCC successfully terminates in each iteration,

Then

That contingency situation must have been considered by the FCC and the flows and loading of the grid calculated for the outage situation.

Given

The input data has a contingency situation which is defined as an ExceptionalContingency and represents the outage of multiple grid users due to having common process.

When

The FCC successfully terminates in each iteration,

Then

That contingency situation must have been considered by the FCC and the flows and loading of the grid calculated for the outage situation.

Given

The input data has a contingency situation which is defined as an ExceptionalContingency and represents the outage of multiple grid elements as a result of the operation of a Special Protection Scheme.

When

The FCC successfully terminates in each iteration,

Then

That contingency situation must have been considered by the FCC and the flows and loading of the grid calculated for the outage situation.

<!-- page 54 -->

##### Basic Flow

The RAO reads the contingency situations of the ContingencyFlatList into the internal data model. The following log-messages are exposed

• CO Name

• CO MRID

• Used calculation method per CO (FOA or FCC)

##### Alternative Flow

In case the input data for a contingency situation is not in the correct format, the contingency is logged and the RAO is canceled.

### 3.5 Sensitivity Computation

#### CORNET-4836: Calculation of Sensitivities

##### Description

The load flow calculation of large transmission grid models considering control schemes like primary or voltage control is a straightforward but computationally expensive task. To enable the consideration of all control schemes within the load flow calculations and at the same time provide the opportunity to perform optimisation procedures, it is beneficial to separate the optimisation process itself from the load flow calculations.

This splitting requires a representation of the load flow properties within the optimisation problem. This representation is given by the derivatives of all constraints with respect to the remedial actions (i.e. variables). Special care has to be taken in the calculation of these derivatives, because they are one of the computationally most expensive parts of the overall problem.

In the following, the calculation of these derivatives along the physical effects in the transmission grid is presented. The derivatives are denominated sensitivities.

The dependency between power injections and nodal voltages is taken as a base calculation for the calculation of sensitivities. All other dependencies (the node-branch sensitivities (3.15) and the node- branch-outage sensitivities (3.24) ) are formulated based upon these so-called node-node sensitivities. These sensitivities are calculated within the AC Sensitivity Calculation (N-0 & N-X) module of the iterative optimisation (see CORNET-12 - RAO procedure).

The elements for which sensitivities are calculated are called branches in this specification.

##### Note:

The sensitivity calculation is only used within the optimisation in order to build the MILP. Therefore, the sensitivity calculation module cannot be called up individually. The results of the sensitivity calculation

<!-- page 55 -->

are saved in the central data storage and can be used for other processes as described in CORNET- 102 - Sensitivity results.

For the N-X sensitivities only the contingencies described in CORNET-4635: RAO Input Data - Contingencies are considered.

##### Node-node sensitivities

Node-node sensitivities describe the impact of changing active or reactive power feed-in at one node on the voltage magnitudes and voltage angles of any other node. These sensitivities are taken directly from the inverted Jacobian matrix $\boldsymbol{J}^{-1}$, which is already calculated within the Newton-Raphson algorithm. The active power flow control (see CORNET-105 – Active power control), which is done by all loads of the grid, is considered within the Jacobian matrix and has an influence on the node-node sensitivities.

Accordingly, the sensitivities have the following form:

$$
\begin{pmatrix} \Delta U \\ \Delta \theta \end{pmatrix}
=
\begin{pmatrix}
\dfrac{\partial U}{\partial P} & \dfrac{\partial U}{\partial Q} \\[10pt]
\dfrac{\partial \theta}{\partial P} & \dfrac{\partial \theta}{\partial Q}
\end{pmatrix}
\cdot
\begin{pmatrix} \Delta P \\ \Delta Q \end{pmatrix}
= \boldsymbol{J}^{-1} \cdot \vec{S}^{\,\mathit{inj}} \tag{3.5}
$$

Thus, for a power injection at node j

$$
T \\
S_{j}^{\mathit{inj}} = (0 \cdots 0, P_{j}^{\mathit{inj}} , Q_{j}^{\mathit{inj}} , 0 \cdots 0) \tag{3.6}
$$

The change in complex power at this node is

$$
\Delta \underline{S}_{j} = P_{j}^{\mathit{inj}} + j\,Q_{j}^{\mathit{inj}} = \Delta P_{j} + j\,\Delta Q_{j} \tag{3.7}
$$

Therefore, the deviation of voltage magnitude and voltage angle at node m is defined as:

$$
\Delta U = \frac{\partial U_{m}}{\partial P_{j}} \Delta P \frac{\partial U_{m}}{\partial Q_{j}} \Delta Q \tag{3.8}
$$

$$
m j +_{j} \\
\Delta \theta = \frac{\partial \theta_{m}}{\partial P_{j}} \Delta P \frac{\partial \theta_{m}}{\partial Q_{j}} \Delta Q \tag{3.9}
$$

$$
m j +^{j}
$$

##### Node-branch sensitivities

To determine the impact on line currents, if a complex nodal voltage changes, node-branch sensitivities are used. Therefore, the current injected at the beginning of a line $\underline{I}_{b}$ is considered. The change of current magnitudes is given by their derivate with respect to the voltage magnitudes and voltage angles of the nodes at the beginning and end of each line.

<!-- page 56 -->

$$
|\underline{I}_{\underline{b}} | = |\underline{Y}_{11} \cdot \underline{U}_{1} + \underline{Y}_{12} \cdot \underline{U}_{2} | = |\underline{Y}_{11} \cdot U_{1} e^{j\theta_{1}} + \underline{Y}_{12} \cdot U_{2} e^{j\theta_{2}} | = |\underline{I}_{11} + \underline{I}_{12} | \tag{3.10}
$$

$$
\frac{\partial I_{b}}{\partial \theta_{1}} = \frac{\Re \{\underline{I}_{\underline{11}} \} \cdot \Im \{\underline{I}_{\underline{b}} \} - \Re \{\underline{I}_{\underline{b}} \} \cdot \Im \{\underline{I}_{\underline{11}} \}}{|\underline{I}_{\underline{b}} |} \tag{3.11}
$$

$$
\frac{\partial I_{b}}{\partial \theta_{2}} = \frac{\Re \{\underline{I}_{\underline{12}} \} \cdot \Im \{\underline{I}_{\underline{b}} \} - \Re \{\underline{I}_{\underline{b}} \} \cdot \Im \{\underline{I}_{\underline{12}} \}}{|\underline{I}_{\underline{b}} |} \tag{3.12}
$$

$$
\frac{\partial I_{b}}{\partial U_{1}} = \frac{\Im \{\underline{I}_{\underline{11}} \} \cdot \Im \{I_{b} \} + \Re \{\underline{I}_{\underline{b}} \} \cdot \Re \{\underline{I}_{\underline{11}} \}}{|\underline{I}_{\underline{b}} | \cdot |\underline{U}_{\underline{1}} |} \frac{\} \cdot \Im \{I_{b}}{|\underline{I}} \tag{3.13}
$$

$$
\frac{\partial I_{b}}{\partial U_{2}} = \frac{\Im \{\underline{I}_{\underline{12}} \} \cdot \Im \{I_{b} \} + \Re \{\underline{I}_{\underline{b}} \} \cdot \Re \{\underline{I}_{\underline{12}} \}}{|\underline{I}_{\underline{b}} | \cdot |\underline{U}_{\underline{2}} |} \frac{\} \cdot \Im \{I_{b}}{|\underline{I}} \tag{3.14}
$$

To determine the effect of power injections directly on branch currents, node-node and node-branch sensitivities are linked to a more generalized form:

$\partial I_{\underline{b}} \frac{\partial I_{b}}{\partial \theta_{b,1}} \frac{\partial \theta_{b,1}}{\partial X_{f}} \frac{\partial I_{b}}{\partial \theta_{b,2}} \frac{\partial \theta_{b,2}}{\partial X_{f}} \frac{\partial I_{b}}{\partial U_{b,1}} \frac{\partial U_{b,1}}{\partial X_{f}} \frac{\partial I_{b}}{\partial U_{b,2}} \frac{\partial U_{b,2}}{\partial X_{f}}$

$$
\partial X = \cdot + \cdot + \cdot + \cdot \tag{3.15}
$$

$f$

In this formulation $X_{f}$ represents the adjustment of an arbitrary degree of freedom f (remedial action). The determination of $X_{f}$ for each degree is presented in the following sections.

To determine the impact on the active power transferred via a branch, if a complex nodal voltage changes, node-branch sensitivities for active power flow have to be used. Therefore, the active power injected at the beginning of a line $P_{b,\mathit{flow}}$ is considered. The change of active power transferred over each branch is given by its derivative with respect to the voltage magnitudes and voltage angles of the nodes at the beginning and end of each line.

$P_{b,\mathit{flow}} = \Re \{\underline{S}_{b,\mathit{flow}} \} = \Re \{\underline{S}_{11} + \underline{S}_{12} \} = \Re \{\underline{Y}_{11}^{*} \cdot \underline{U}_{1} \cdot \underline{U}_{1}^{*} + \underline{Y}_{12}^{*} \cdot \underline{U}_{1} \cdot \underline{U}_{2}^{*} \}$

$$
+ \underline{Y} \tag{3.16}
$$

$= \Re \{\underline{Y}_{11}^{*} \cdot U_{1 12}^{2 *} \cdot U_{1} e^{j\theta_{1}} \cdot U_{2} e^{-j\theta_{2}} \}$

By using the formula above, the derivatives required can be build:

$$
\frac{\partial P_{b,\mathit{flow}}}{\partial \theta_{1}} = \Re \{j\cdot \underline{S}_{12} \} \tag{3.17}
$$

$$
\frac{\partial P_{b,\mathit{flow}}}{\partial \theta_{2}} = \Re \{-j\cdot \underline{S}_{12} \} \tag{3.18}
$$

<!-- page 57 -->

$$
\frac{\partial P_{b,\mathit{flow}}}{\partial U_{1}} = \frac{\Re \{2 \cdot \underline{S}_{11} + \underline{S}_{12} \}}{|\underline{U}_{1} |} \tag{3.19}
$$

$$
\frac{\partial P_{b,\mathit{flow}}}{\partial U_{2}} = \frac{\Re \{\underline{S}_{12} \}}{|\underline{U}_{2} |} \tag{3.20}
$$

To determine the effect of power injections directly on the active power transferred over a branch, node-node and node-branch sensitivities are linked to a more generalized form:

$\partial P_{\underline{b,\mathit{flow}}}$

$\partial X = \frac{\partial P_{b,\mathit{flow}}}{\partial \theta_{b,1}} \cdot \frac{\partial \theta_{b,1}}{\partial X_{f}} + \frac{\partial P_{b,\mathit{flow}}}{\partial \theta_{b,2}} \cdot \frac{\partial \theta_{b,2}}{\partial X_{f}} + \frac{\partial P_{b,\mathit{flow}}}{\partial U_{b,1}} \cdot \frac{\partial U_{b,1}}{\partial X_{f}}$

$f$

$$
+ \frac{\partial P_{b,\mathit{flow}}}{\partial U_{b,2}} \cdot \frac{\partial U_{b,2}}{\partial X_{f}} \tag{3.21}
$$

Note : The following description for the determination of the outage sensitivities is only applicable for contingency situations that are calculated via the FOA (see CORNET-3691: Fast Outage Approximation). Sensitivities for contingency situations calculated via the FCC (see CORNET-4634: Fast Contingency Calcualtion) are determined the same way as described above. The distinction is made because the FOA uses an approximation method for the determination of voltages and flows in N-X, whereas the FCC uses a modified load-flow calculation. Therefore, the sensitivities can be calculated the same way as for the N-0 situation.

##### Node-branch-outage sensitivities

The consideration of the N-1-criterion introduces new constraints based on the outage network topology in the N-X-case. The calculation of separate sensitivities for all N-X-cases based on an inversion of the Jacobian matrix for the specific contingency dramatically increases the computational effort, especially for large system. Hence, an approximation is applied for the sensitivities in contingency cases (see CORNET-3691: Fast Outage Approximation). Because the calculation of the node-branch-outage sensitivities uses the same superposition principle as the Fast Outage Approximation, the same limits as in the FAO apply also to the sensitivity calculation for contingency cases.

Example: In the figure below a simple example is given for the superposition principle. In the base case (N-0) the flow on three parallel branches with the same impedance between two remedial actions is the same. In a contingency case one of the branches is the contingency element. The change in flow $(\Delta \mathit{Flow}_{C}$) on each of the remaining two branches is the initial flow of the third branch evenly distributed. In the end the final flow on each remaining branch in the contingency case is the sum of the initial flow $(N-0) \mathit{and} \mathit{the} \Delta \mathit{Flow}_{C}$. The same statement can be made about the node-branch-outage sensitivity

<!-- page 58 -->

calculation. The final sensitivity for each branch is the sum of the initial node-branch sensitivity and the $\Delta \mathit{Sensitivity} \mathit{for} \mathit{the} \mathit{contingency} \mathit{case}.$

> **Figure (page 58) — described in text.**
>
> Superposition principle for outage sensitivities, drawn as three small grid diagrams joined by **+** and **=**.
>
> *Base case (N-0), left:* two busbars connected by three parallel branches carrying $Flow_{1,0}$, $Flow_{2,0}$, $Flow_{3,0}$; a generator RA1 feeds the top bus and RA2 the bottom. Below: $Flow_{1,0} = Flow_{2,0} = Flow_{3,0}$ and $Sensitivity_{1,0} = Sensitivity_{2,0} = Sensitivity_{3,0}$.
> *Contingency case (N-1), middle:* the third branch is struck out with a large red **✗**; the two surviving branches carry $\Delta Flow_{1,c} = Flow_{3,0}/2$ and $\Delta Flow_{2,c} = Flow_{3,0}/2$. Below: $\Delta Flow_{1,c} = \Delta Flow_{2,c}$, $\Delta Sensitivity_{1,c} = \Delta Sensitivity_{2,c}$ and $\Delta Sensitivity_{1,c} = Sensitivity_{3,0}/2$.
> *Result, right:* again the third branch is crossed out; the remaining branches carry $Flow_{1,c} = Flow_{1,0} + \Delta Flow_{1,c}$ and $Flow_{2,c} = Flow_{2,0} + \Delta Flow_{2,c}$. Below: $Flow_{1,c} = Flow_{2,c}$, $Sensitivity_{1,c} = Sensitivity_{2,c}$ and $Sensitivity_{1,c} = Sensitivity_{1,0} + \Delta Sensitivity_{1,c}$.

Figure: Superposition principle for calculation of outage sensitivities

Node-Branch-Outage sensitivities describe the influence of an outaged branch on the flow on branch b, if a degree of freedom $X_{f}$ (remedial action) changes. To calculate this relationship, the combination of multiple sensitivities is necessary.

This is illustrated exemplary for transformer tap changes in the following figure.

> **Figure (page 58) — described in text.**
>
> Chain of six stacked boxes, each linked to the next by an arrow whose label names the sensitivity type that performs the step:
>
> *Transformer* —(Transformer-Node Sensitivities)→ *Power injection* —(Node-Node Sensitivities)→ *Voltages at nodes of outaged lines* —(Branch Sensitivities)→ *Flow on outaged branch* —(Power injection Sensitivities)→ *Voltage at nodes of monitored branch b* —(Branch Sensitivities)→ *Flow on monitored branch b*.

Figure: Exemplary calculation of Node-Branch-Outage Sensitivities for transformers

<!-- page 59 -->

Sensitivities from the Jacobian matrix are used to approximate the change of the power flow on the outaged line prior to tripping, if a certain degree of freedom is adjusted. These changes of power flow are then injected into the outaged topology to estimate the impact on the system state during the contingency. Since the power flow changes are a function of the optimisation variable, the power injections have to be performed for each deviation $\Delta I_{c,1} , \Delta I_{c,2} , \Delta I_{\varphi ,1} , \Delta I_{\varphi ,2}$.Thereby $\Delta I_{c,1} , \Delta I_{c,2}$ refers to the deviation in magnitude and $\Delta I_{\varphi ,1} , \Delta I_{\varphi ,2}$ to the deviation in phase of current. Therefore, 16 power- injection-sensitivities are calculated to describe the relationship between system voltage change and the line current on an outaged line, see the figure below.

> **Figure (page 59) — described in text.**
>
> A single cross-hatched network block with a generator (⌁ symbol) connected on the right. Across the top terminals a dashed double-headed arrow labelled *Power Injection* connects the two complex power deviations $\Delta\underline{S}_{c,1}$ and $\Delta\underline{S}_{c,2}$. The bottom terminals are the monitored branch. Beneath it the four resulting partial derivatives are listed:
>
> $\dfrac{\partial \underline{U}_{b,1}^{c}}{\partial \underline{I}_{c,1}},\ \dfrac{\partial \underline{U}_{b,1}^{c}}{\partial \underline{I}_{c,2}},\ \dfrac{\partial \underline{U}_{b,2}^{c}}{\partial \underline{I}_{c,1}},\ \dfrac{\partial \underline{U}_{b,2}^{c}}{\partial \underline{I}_{c,2}}$

Figure: Power-Injection-Sensitivities

The individual sensitivities are given within the matrix in the following equation.

$$
\begin{pmatrix}
\dfrac{\partial U_{b,1}^{\delta c}}{\partial X_{f}} \\[10pt] \dfrac{\partial U_{b,2}^{\delta c}}{\partial X_{f}} \\[10pt] \dfrac{\partial \theta_{b,1}^{\delta c}}{\partial X_{f}} \\[10pt] \dfrac{\partial \theta_{b,2}^{\delta c}}{\partial X_{f}}
\end{pmatrix}
=
\begin{pmatrix}
\dfrac{\partial U_{b,1}^{\delta c}}{\partial I_{c,1}} & \dfrac{\partial U_{b,1}^{\delta c}}{\partial I_{c,2}} & \dfrac{\partial U_{b,1}^{\delta c}}{\partial \varphi_{c,1}} & \dfrac{\partial U_{b,1}^{\delta c}}{\partial \varphi_{c,2}} \\[10pt] \dfrac{\partial U_{b,2}^{\delta c}}{\partial I_{c,1}} & \dfrac{\partial U_{b,2}^{\delta c}}{\partial I_{c,2}} & \dfrac{\partial U_{b,2}^{\delta c}}{\partial \varphi_{c,1}} & \dfrac{\partial U_{b,2}^{\delta c}}{\partial \varphi_{c,2}} \\[10pt] \dfrac{\partial \theta_{b,1}^{\delta c}}{\partial I_{c,1}} & \dfrac{\partial \theta_{b,1}^{\delta c}}{\partial I_{c,2}} & \dfrac{\partial \theta_{b,1}^{\delta c}}{\partial \varphi_{c,1}} & \dfrac{\partial \theta_{b,1}^{\delta c}}{\partial \varphi_{c,2}} \\[10pt] \dfrac{\partial \theta_{b,2}^{\delta c}}{\partial I_{c,1}} & \dfrac{\partial \theta_{b,2}^{\delta c}}{\partial I_{c,2}} & \dfrac{\partial \theta_{b,2}^{\delta c}}{\partial \varphi_{c,1}} & \dfrac{\partial \theta_{b,2}^{\delta c}}{\partial \varphi_{c,2}}
\end{pmatrix}
\cdot
\begin{pmatrix}
\dfrac{\partial I_{c,1}}{\partial X_{f}} \\[10pt] \dfrac{\partial I_{c,2}}{\partial X_{f}} \\[10pt] \dfrac{\partial \varphi_{c,1}}{\partial X_{f}} \\[10pt] \dfrac{\partial \varphi_{c,2}}{\partial X_{f}}
\end{pmatrix} \tag{3.22}
$$

$$
\frac{\partial \theta_{b,1}^{\delta c}}{\partial X_{f}} \frac{\partial \theta_{b,1}^{\delta c}}{\partial I_{c,1}} \frac{\partial \theta_{b,1}^{\delta c}}{\partial I_{c,2}} \frac{\partial \theta_{b,1}^{\delta c}}{\partial \varphi_{c,1}} \frac{\partial \theta_{b,1}^{\delta c}}{\partial \varphi_{c,2}} \frac{\partial \varphi_{c,1}^{f}}{\partial X_{f}} \\
\frac{\partial \theta_{b,2}^{\delta c}}{\partial X_{f}} \frac{\partial \theta_{b,2}^{\delta c}}{\partial I_{c,1}} \frac{\partial \theta_{b,2}^{\delta c}}{\partial I_{c,2}} \frac{\partial \theta_{b,2}^{\delta c}}{\partial \varphi_{c,1}} \frac{\partial \theta_{b,2}^{\delta c}}{\partial \varphi_{c,2}} \frac{\partial \varphi_{c,2}^{f}}{\partial X_{f}} \\
( ) ( ) ( )
$$

To determine Node-Branch-Outage-Sensitivities for branch b , the sensitivities in the equation above are multiplied with the Node-Branch-Sensitivities.

$$
\frac{\partial I_{b}^{\delta c}}{\partial X_{f}} = \frac{\partial I_{b}^{\delta c}}{\partial U_{b,1}^{\delta c}} \frac{b,1 \delta c}{\cdot \partial U \partial X_{f}} + \frac{\partial I_{b}^{\delta c}}{\partial U_{b,2}^{\delta c}} \frac{b,2 \delta c}{\cdot \partial U \partial X_{f}} + \frac{\partial I_{b}^{\delta c}}{\partial \theta_{b,1}^{\delta c}} \frac{b,1 \delta c}{\cdot \partial \theta \partial X_{f}} + \frac{\partial I_{b}^{\delta c}}{\partial \theta_{b,2}^{\delta c}} \frac{b,2 \delta c}{\cdot \partial \theta \partial X_{f}} \tag{3.23}
$$

Which can be reformulated to:

<!-- page 60 -->

$$
\frac{\partial \underline{I}_{b}^{\delta c}}{\partial X_{f}}
= \frac{\partial \underline{I}_{b}^{\delta c}}{\partial \underline{U}_{b}^{\delta c}}
\cdot \frac{\partial \underline{U}_{b}^{\delta c}}{\partial \underline{I}_{c}}
\cdot \frac{\partial \underline{I}_{c}}{\partial \underline{U}_{c}}
\cdot \frac{\partial \underline{U}_{c}}{\partial X_{f}} \tag{3.24}
$$

These sensitivities describe the current change on branch b due to contingency c . To obtain the total current deviation, (3.15 ) and (3.24 ) are summed up to:

$$
\frac{\partial I_{b}^{c}}{\partial X_{f}} = \frac{\partial I_{b}}{\partial X_{f}} + \frac{\partial I_{b}^{\delta c}}{\partial X_{f}} \tag{3.25}
$$

##### Sensitivities of generating units

The power injection approximation for a generation unit g is easily done. The power injection at this node is equal to the change in power feed-in at the generating unit:

$$
\partial X_{f} = \partial P_{g} \tag{3.26}
$$

Note: The sensitivities are related to a reference point. This reference point and the active power control is defined as the active power control and considered in the Jacobian matrix. This Jacobian matrix is used for calculating the node-node sensitivities (see CORNET-105 – Active power control).

##### Sensitivities of PSTs

To describe transformer tap adjustment as power injections, tap changing is approximated as a current injection in a first step, which is then reformulated as injection of complex power. The figure below shows the equivalent circuit of a transformer with injected currents $\underline{I}_{\mathit{inj},1}$ and $\underline{I}_{\mathit{inj},2}$.

> **Figure (page 60) — described in text.**
>
> Single-line equivalent circuit of a transformer with injected currents. From left to right: terminal pair with voltage $\underline{U}_1$ and inflowing current $\underline{I}_1$; a shunt admittance $\underline{Y}_q$ to the return rail; an injected current source $\underline{I}_{inj,1}$ at that node; the series (longitudinal) admittance $\underline{Y}_l$; a second node carrying injected current $\underline{I}'_{inj,2}$, a second shunt $\underline{Y}_q$, current $\underline{I}'_2$ and voltage $\underline{U}'_2$; then an ideal transformer with ratio $\underline{\ddot{u}}_0 : 1$; and finally the right-hand terminal pair with current $\underline{I}_2$ and voltage $\underline{U}_2$.

Figure: Transformer current injection

Therefore, the actual transformer $\underline{r}(s)$, depending on the tap position s, is separated into a fixed term $\underline{r}_{0}$ and a variable term $\Delta \underline{r}(s)$. The fixed ratio is set to the transformer ratio at the standard tap position, which is the current tap position of the transformer. The variable term represents the deviation from this standard position caused by tap switching.

<!-- page 61 -->

$$
\underline{r}(s) = \underline{r}_{0} + \Delta \underline{r}(s) \tag{3.27}
$$

To calculate the currents as a function of the transformer ratio and the voltages at both sides of the transformer, equation (3.27) is combined with the transformers quadrupole equations.

$$
\begin{pmatrix} \underline{I}_{1} + \underline{I}_{\mathit{inj},1} \\
\underline{I}_{2} + \underline{I}_{\mathit{inj},2} \end{pmatrix}
=
\begin{pmatrix}
\underline{Y}_{11} &
\left(\underline{r}_{0} + \Delta \underline{r}(s)\right)\underline{Y}_{12} \\[6pt]
\left(\underline{r}_{0}^{*} + \Delta \underline{r}(s)^{*}\right)\underline{Y}_{21} &
\left(\underline{r}_{0} + \Delta \underline{r}(s)\right)
\left(\underline{r}_{0}^{*} + \Delta \underline{r}(s)^{*}\right)\underline{Y}_{22}
\end{pmatrix}
\cdot
\begin{pmatrix} \underline{U}_{1} \\ \underline{U}_{2} \end{pmatrix} \\[10pt]
=
\left(
\begin{pmatrix}
\underline{Y}_{11} & \underline{r}_{0}\underline{Y}_{12} \\[6pt]
\underline{r}_{0}^{*}\underline{Y}_{21} & \underline{r}_{0}\underline{r}_{0}^{*}\underline{Y}_{22}
\end{pmatrix}
+
\begin{pmatrix}
0 & \Delta \underline{r}\,\underline{Y}_{12} \\[6pt]
\Delta \underline{r}^{*}\underline{Y}_{21} &
\left(\underline{r}_{0}\Delta \underline{r}^{*} + \underline{r}_{0}^{*}\Delta \underline{r}
+ \Delta \underline{r}\Delta \underline{r}^{*}\right)\underline{Y}_{22}
\end{pmatrix}
\right)
\cdot
\begin{pmatrix} \underline{U}_{1} \\ \underline{U}_{2} \end{pmatrix} \tag{3.28}
$$


$2 + \underline{I}^{\mathit{inj},2} (\underline{r}_{0}^{*} + \Delta \underline{r}(s)^{*} )\underline{Y}_{21} (\underline{r}_{0} + \Delta \underline{r}(s)) (\underline{r}_{0}^{*} + \Delta \underline{r}(s)^{*} )\underline{Y}_{22}^{2}$



Equation (3.28) shows that the currents $(\underline{I}_{1} + \underline{I}_{\mathit{inj},1} )$ and $(\underline{I}_{2} + \underline{I}_{\mathit{inj},2} )$ are dependent on the fixed and the variable part of the transformer ratio. Thus, the transformer currents can be interpreted as the superposition of the fixed currents, caused by standard tap position, and additional currents as a result of tap adjustment.

So, the injected currents are given by:

$$
\begin{pmatrix} \underline{I}_{\mathit{inj},1} \\ \underline{I}_{\mathit{inj},2} \end{pmatrix}
=
\begin{pmatrix}
0 & \Delta \underline{r}\,\underline{Y}_{12} \\[6pt]
\Delta \underline{r}^{*}\underline{Y}_{21} &
\left(\underline{r}_{0}\Delta \underline{r}^{*} + \underline{r}_{0}^{*}\Delta \underline{r}
+ \Delta \underline{r}\Delta \underline{r}^{*}\right)\underline{Y}_{22}
\end{pmatrix}
\cdot
\begin{pmatrix} \underline{U}_{1} \\ \underline{U}_{2} \end{pmatrix} \tag{3.29}
$$

The linear sensitivities of the injected currents are their partial derivatives with respect to the tap position.

$$
\frac{\partial \underline{I}_{\mathit{inj},1}}{\partial s} = \underline{Y}_{12} \underline{U}_{2} \frac{\partial \Delta \underline{r}}{\partial s} \tag{3.30}
$$

$$
\frac{\partial \underline{I}_{\mathit{inj},2}}{\partial s} = \underline{Y}_{21} \underline{U}_{1} \left(\frac{\partial \Delta \underline{r}}{\partial s}\right)^{*} + 2\underline{Y}_{22} \underline{U}_{2} \mathit{Re}\left\{\underline{r}^{*} \frac{\partial \Delta \underline{r}}{\partial s}\right\} \tag{3.31}
$$

The multiplication of the injected currents with the voltages $\underline{U}_{1}$ and $\underline{U}_{2}$ leads to complex power values, which can be interpreted as complex power injection $\vec{S}^{\mathit{inj}}$ at this node. Thereby $\vec{S}^{\mathit{inj}}$ is a real vector with separated entries for the active and reactive power, as shown in (3.32) .

$$
\vec{S}^{\,\mathit{inj}} =
\begin{pmatrix}
0 \\ \vdots \\ P_{\mathit{inj},1} \\ Q_{\mathit{inj},1} \\ 0 \\ \vdots \\
P_{\mathit{inj},2} \\ Q_{\mathit{inj},2} \\ 0 \\ \vdots
\end{pmatrix}
=
\begin{pmatrix}
0 \\ \vdots \\
\mathit{Re}\{\underline{U}_{1}\underline{I}_{\mathit{inj},1}^{*}\} \\
\mathit{Im}\{\underline{U}_{1}\underline{I}_{\mathit{inj},1}^{*}\} \\ 0 \\ \vdots \\
\mathit{Re}\{\underline{U}_{2}\underline{I}_{\mathit{inj},2}^{*}\} \\
\mathit{Im}\{\underline{U}_{2}\underline{I}_{\mathit{inj},2}^{*}\} \\ 0 \\ \vdots
\end{pmatrix} \tag{3.32}
$$


By means of this complex power injection, Node-Node- as well as Node-Branch Sensitivities can be calculated. The degree of freedom of transformers is the change of the tap position.

<!-- page 62 -->

$$
\partial X_{f} = \partial s \tag{3.33}
$$

Business Needs :

##### Use-Cases:

UC853: BUC 14#58 Calculation of sensitivities for contingency situations from FCC

<!-- page 63 -->

#### CORNET-102: Sensitivity results

##### Description

In R1.1 the sensitivity calculation is carried out for building the MILP within the RAO process. Therefore. only the sensitivities relevant for the optimisation are calculated.

The sensitivities of considered

• generating units ( CORNET-35 - Consideration of generation units) and

• PSTs ( CORNET-18 - Consideration of PST)

on XNEs and relevant XNECs ( CORNET-92 - Consideration of XNEs in MILP) are calculated in the form of sensitivity matrices.

These sensitivity matrices contain for generating units the effect per change in power directly on element currents ($\frac{\partial I_{b}}{\partial P_{g}}$) and for PSTs the effect per change of tap position directly on element currents $(_{\partial s}^{\underline{\partial I}_{\underline{b}}}$).

##### Sensitivity results in N-0 case

| Name | Description | Units | Data type | Time series / |
| --- | --- | --- | --- | --- |
|  |  |  |  | Constant |
| element_N0 | Element to which the sensitivities apply in N-0 case | - | string | Constant |
| dIb_dPg_N0 | Effect per change in power directly on element currents in N-0 case | A/MW float |  | Time series |
| dIb_ds_N0 | Effect per change of tap position directly on element currents in N-0 case | A/Tap float |  | Time series |

##### Sensitivity results in N-X case

| Name | Description | Units | Data type |  | Time series / |
| --- | --- | --- | --- | --- | --- |
|  |  |  |  |  | Constant |
| element_NX | Element to which the sensitivities apply in N- X case | - | string | Constant |  |
|  | NX_contingency Relevant contingency case | - | string | Time series |  |
| dIb_dPg_NX | Effect per change in power directly on element currents in N-X case | A/MW float |  | Time series |  |

<!-- page 64 -->

| dIb_ds_NX | Effect per change of tap position directly on element currents in N-X case | A/Tap float |  | Time series |
| --- | --- | --- | --- | --- |

##### Note for Release 1.1:

In R1.1 the first (initial) and last calculated sensitivities matrices of the iterative optimisation process are exported.

System Requirement: SRQ835

<!-- page 65 -->

### 3.6 RAO Computation

#### 3.6.1 Introduction

In this chapter the general concept of Remedial Actions Optimization (RAO) and its computation is described. The RAO (Steps 4.2 and 7.1) is part of the CROSA and is executed between Regional Security Assessments (Steps 4.1 and 5.1) in the first regional run as well as after a Remedial Action Coordination (Step 6.1) in the second regional run (see Figure below).

At first, an overview of the RAO procedure is given with an introduction of the individual calculation modules (see Figure 2). Later, each module is described in more detail in a separate chapter. 1st regional run

T0 T1 T2 (tentative) T3 (tentative) 18:00 18:30 18:35 19:20 0.2 2.1 3.1 3.2.1 3.2.2

0.1 1.1 Identification and Implementation of

CSA Input Data Regional RSA performed

Input Consistency CGM Building Security X by the TSO on + proposal of the proposed X

preventive XRAs in preventive XRAs in Preparation Process

Check Assessment the same CGM the CGM by all TSOs the CGM by all TSOs

3.3.1 3.3.2

Identification of Update of the list of

curative TOPO XRAs curative XRAs and list

by the TSO of contingencies

T3 (tentative) T4 (tentative) T5 (tentative) T6 (tentative)

19:20 19:35 19:40 20:30

4.1 5.1 6.1

4.2

Regional Regional Remedial

RAO (PST, RD &

Security Security Action

CT and HVDC)

Assessment Assessment Coordination

T6 (tentative) T7 (tentative) T8 (tentative) T9 (tentative) T10 (tentative)

20:30 20:40 20:45 21:40 22:00

8.1 9.1

7.1 10.1

Regional Remedial Final Remedial

RAO (PST, RD & Action Validation

Security Action

CT and HVDC) Session

Assessment Coordination

2nd regional run

Figure 1: Temporal process overview for DA CROSA in ROSC V1

<!-- page 66 -->

#### 3.6.2 Optimisation Model

##### Process

##### CORNET-12: RAO Procedure

###### Description

The term remedial action optimization computation (RAO computation) describes the entire process that determines the remedial actions in the remedial action optimization (RAO) as part of the operational planning processes of the transmission system operators (see Figure 2). The RAO computation consists of an initialisation routine, an optimal power flow algorithm (OPF) module and an output routine. The OPF is the mathematical procedure for identifying optimal remedial actions and is described as the iterative Optimization in Figure 2. Because the OPF module also considers contingency situations (N-X) within the optimization, it is technically a security-constrained optimal power flow algorithm (SCOPF).

> **Figure (page 66) — described in text.**
>
> Three-band flowchart of the RAO procedure (two pink bands, one grey), each drawn as a dashed container.
>
> *Initialisation Routine* (from **Start**): *Initialisation of Internal Data Model* → *AC Load Flow Calculation* → *Expanding of contingencies by SPS* → *Fast Outage Approximation*.
> *Iterative Optimization*: *AC Sensitivity Calculation (N-0 & N-1)* → *Build MILP* → *Solve MILP* → *AC Load Flow Calculation* → **✗** gateway *Convergence Check* → *Fast Outage Approximation* → **✗** gateway *Stop Criteria Check*, which loops back to the start of this band.
> *Output Routine* (grey): *Write Output Data* → **Exit**.

Figure 2 RAO-Procedure

Within the scope of this chapter, it will be shown how the OPF is designed and which parameters are available to the user to support the RAO calculation. Therefore, within the detailed specifications all parameters are defined in detail (Name, Description, Unit, Data Type, Time Series/Constant, Data Object, CSA-Object, Profile). The OPF determines the remedial actions by successively building and solving a mixed integer linear program (MILP). The MILP is also referred to as the optimization problem in the following. The MILP is constructed as a function of the current operating point of the common

<!-- page 67 -->

grid model. The current operating point, which is a result of the AC load-flow calculation, is defined by the initial state before optimisation or after implementation of remedial actions as a result of the previous solution of a MILP as an intermediate step of the OPF. The solution of the MILP set up within the OPF is determined using the solver GUROBI. In each MILP, the remedial actions and constraints of the network operation are modelled. The modelling of the remedial actions is described in the chapter Optimized Remedial Actions. This chapter describes in more detail the technical and operational constraints relevant when defining remedial actions, for example, control range limits or maximum permissible gradients for adjusting the generation output of power plants. The modelling of the constraints of network operation, in other words the permissible branch loadings, is addressed in chapter Considered Congestions ( CORNET-32 et seqq.). The coefficients of the objective function, the driving force of the optimization problem, consist of operating and penalty costs. The objective function value must be minimized within the mathematical optimization in order to minimize the sum of operating and penalty costs to be spent (see CORNET-80 – Objective function).

Penalty costs are not real costs. They are used to model transmission system operation constraints. Firstly, penalty costs for remedial actions are modelled. Secondly, penalty costs are included in the objective function for non-compliance with allowable branch loadings. This ensures that the solver can determine an OPF and this OPF can be implemented, even if the available remedial actions are not sufficient to eliminate all congestions. In the chapter CORNET-80 – Objective Function the objective function including all considered cost factors (operating and penalty costs) is specified in detail. The considered constraints will be specified in detail in the following specifications for the considered remedial actions. In addition, chapter CORNET-XX – Overview of considered constraints ( TBD in R1.2 ) contains an overview of all constraints, including information on whether the constraint is considered as a soft or hard constraint in the optimization.

System Requirement: SRQ836

##### CORNET-15: Considering Degrees of Freedom

###### Description

From the point of view of the OPF, there are relaxed (soft) and non-relaxed (hard) constraints. For relaxed constraints additional variables are required, which are included with penalty costs in the objective function. In the further course of this document, it is always marked whether a described constraint is relaxed or not. The parameterisation of the operating and penalty costs is of great significance for the success of the optimisation. The neglection of cost parameters could lead to an unwanted behaviour of certain remedial actions within the OPF, for example too low penalty costs

<!-- page 68 -->

could result in a re-optimisation of the market results and the solution would be therefore not completely congestion-driven.

System Requirement:

##### CORNET-4850: Accuracy Requirement

###### Description

In the process of RAO, congestions must be considered both in the base case (N-0) and in defined contingency situations (N-X) (see CORNET-16 – Consideration of Congestions). The resulting grid states must be evaluated accordingly.

The reference of the accuracy requirements for the grid base case N-0 is the modelling of the power flows, which are based on the nodal admittance matrix derived from the complex node equations. The nodal admittance matrix Y describes the transmission characteristics between the buses for the transmission lines or transformers. The diagonal elements $Y_{11} , Y_{22} ,\dots , Y_{\mathit{nn}}$ are called the self- admittances of the nodes. Each of their values equals the sum of all admittances terminating on the node identified by the repeated subscripts. The other admittances are called the mutual admittances of the nodes. Their values equal the negative of the sum of all admittances connected directly between the nodes identified by the two subscripts.

$$
Y =
\begin{bmatrix}
Y_{11} & Y_{12} & \cdots & Y_{1n} \\
Y_{21} & Y_{22} &        & Y_{2n} \\
\vdots &        & \ddots & \vdots \\
Y_{n1} & Y_{n2} & \cdots & Y_{nn}
\end{bmatrix} \tag{3.34}
$$

$$
Y= [ Y_{21} Y_{22} Y_{2n} ] \\
\vdots \ddots \vdots \\
Y_{n1} Y_{n2} \cdots Y_{\mathit{nn}}
$$

Similar to the Newton-Raphson approach, which is used to solve the nonlinear power flow equations, the optimization problem is solved iteratively until a stop criterion is reached. For the evaluation of outage situations to be considered, the grid calculation method of the Fast Outage Approximation is used (for a detailed description see CORNET-26 - Approximation of Contingencies). With this module the influence of a contingency on the grid utilisation can be estimated linearly and separate calculation loops for all contingency situations each with a load flow calculation are therefore not necessary. This method leads to an insignificantly lower accuracy regarding the estimated flows within the grid in a contingency situation but a significant increase in calculation speed.

The impact of remedial actions on the branch flows is modelled linearly and referred to as sensitivity (see CORNET-23 - Sensitivity Computation). The iterative procedure to meet the accuracy requirements is shown in the following figure:

<!-- page 69 -->

> **Figure (page 69) — described in text.**
>
> The *Iterative Optimization* band from the previous figure shown on its own, with an explanatory callout attached to each step:
>
> - *AC Sensitivity Calculation (N-0 & N-1)* — “Calculation of the linearised influence of RAs on elements based on the AC load flow”
> - *Build MILP* — “Formulation of the MILP with variables, constraints and the objective function”
> - *Solve MILP* — “MILP is solved via an external solver”
> - *AC Load Flow Calculation* — “The results are used in an AC load flow calculation to obtain the new operating point”
> - *Convergence Check* — “Check of convergence criteria for new result”
> - *Fast Outage Approximation* — “Checking for new contingencies and elements above a defined utilisation threshold because of new operating point”
> - *Stop Criteria Check* — “Checking the stop criteria after each completeness iteration”

Figure 3 Iterative Optimisation Procedure (Loops of linearisation iterations)

An iteration to replicate the nonlinear power flow equations is called linearisation iteration. First, the power flows in the defined contingency situations are approximated and existing N-X-congestions are determined on this basis (see Figure 2). These congestions are considered as constraints in addition to the power flows in the N-0 base case when setting up the optimization task. The basis for calculating the sensitivities are the power flows at the current operating point. The sensitivities consider the influence of remedial actions, both on power flows in the N-0 base case and on the approximated power flows in the contingency situations determined to be relevant (see CORNET-23 - Sensitivity Computation and CORNET-16 – Consideration of Congestions). Sensitivities are therefore calculated for the N-0 base case and each contingency situation which will be considered in the following steps. In order for an element to be considered within the MILP as a constraint, the calculated loading in the base case or the approximated loading in the contingency situation has to be above a defined limit (e.g. 80 % loading). Following the calculation of the sensitivities, the MILP can be built and solved. The remedial actions determined from this are then temporarily implemented in the common grid model for the next iteration. A new load flow is calculated with this updated common grid model to determine the new operating point. If this new load flow calculation converges, the Convergence Check tests several criteria for a termination of the linearised optimisation iteration. As criteria for the termination • the number of linearisation iterations:

o The compliance with a maximum permissible number of linearisation iterations (MaxCountLinIter) is checked as a hard termination criterion.

• the sum of the change in redispatch (in MW) and the approximated flow shift by PSTs

|  | $\sum_{\Delta P_{\mathit{remedial} \mathit{action}} < P_{\mathit{MaxC}h\mathit{angeRASum}}}$ |  | ( 3 . 35 ) |
| --- | --- | --- | --- |

• the change in each remedial action

<!-- page 70 -->

| $P_{\mathit{remedial} \mathit{action}} < P_{\mathit{MaxC}h\mathit{angeRA}}$ |  |  | ( 3 .3) |
| --- | --- | --- | --- |

• the change of the element overloads (congestions)

• the adapted active power of a countertrade remedial action (CT RA) due to exceeding technical limits of generating units (see CORNET-4849: Consideration of technical limits of generating units of CT RAs)

| $\sum_{\substack{g \in \mathit{GLSK} \\ \Delta P_{\mathit{adaption},g} < P_{\mathit{MaxAdaptionCT}}}}$ |  | ( 3 .4) |
| --- | --- | --- |

are checked after each iteration.

For PSTs a weighting factor based on the used sensitivities is calculated during the optimisation. With this weighting factor the influence in MW for the tap changes during the optimisation can be calculated. When cyclic repetitions of the MILP results occur, there is otherwise also an exit from the iteration loop by comparing the new result with already determined solutions in an earlier iteration. For this check a threshold can be defined.

After the Convergence Check, the Outage Approximation runs again to check for new additional contingencies. In a last Stop Criteria Check the outcome of this Fast Outage Approximation is checked as well as the current number of completeness iterations is checked against the maximum number of allowed completeness iterations (see CORNET-16 ).

###### Configuration

| Name | Description | Unit |  |  | Object |
| --- | --- | --- | --- | --- | --- |
| MaxCountLinIter | Max. count of linearisation iterations | - |  | RAO Control Parameter |  |
|  | MaxChangeRASum Max. sum of changes in redispatch of RAs MW RAO Control Parameter |  |  |  |  |
| MaxChangeRA | Max. change in redispatch of each RA |  |  | MW RAO Control Parameter |  |
| MaxAdaptionCT | Max. adaption of a CT RA |  |  | MW RAO Control Parameter |  |

Business Needs :

BN785: RAO-GLSK_Advanced: The RAO must support use and adaptation of GLSK

Use-Cases :

UC861: BUC 14#91 Accuracy Requirement - New Criteria for CT Adaption

Acceptance Criteria :

Given

<!-- page 71 -->

The RAO has a defined value for the maximum number of linearisation iterations (MaxCountLinIter). When

The optimisation is successful and the load flow calculation converges,

Then

The maximum number of linearisation iteration cannot be exceeded.

Given

The RAO has a defined value for the maximum sum of changes in redispatch of RAs (MaxChangeRASum).

When

The optimisation is successful and the load flow calculation converges,

Then

The next completeness iteration must start if the sum of changes in redispatch of RA is below MaxChangeRASum.

Given

The RAO has a defined value for the maximum change in redispatch of each RAs (MaxChangeRA). When

The optimisation is successful and the load flow calculation converges,

Then

The next completeness iteration must start if the change in redispatch of each RA is below MaxChangeRA.

Given

The RAO has a defined value for the maximum adaption of a CT RA (MaxAdaptionCT).

When

The optimisation is successful and the load flow calculation converges,

Then

The next completeness iteration must start if the adapted active power of a CT RA due to exceeding the technical limits of generating unit is below MaxAdaptionCT.

##### CORNET-16: Consideration of Congestions

###### Description

The RAO essentially takes all defined contingency situations into consideration. To reduce the computing time required, the contingency situations relevant for the RAO are selected before the

<!-- page 72 -->

optimisation problem is set up by a fast outage approximation. In order for an element to be considered within the MILP as a constraint, the approximated loading in the contingency situation has to be above a defined limit (e.g. 80 % loading). If that is the case, they are added to the optimisation problem. Relevant contingency situations are characterized by congestions and must be eliminated by available remedial actions (see CORNET-13 – Accuracy requirement). Since power flows in the common grid model are influenced due to the implementation of remedial actions in the linearization iterations, additional contingency situations may be relevant after the implementation. Therefore, relevant contingency situations are determined in an iterative sequence and added to the optimisation problem. The iterations of this loop are called completeness iterations. Provided that no new branch overloads (congestions) occur as a result of contingency situations that were not previously considered in the optimisation problem, the stop criterion is met and the iteration loop is completed. The maximum number of completeness iterations can be defined by the user as a hard cancellation criterion. The sequence of the RAO is shown in the following figure:

> **Figure (page 72) — described in text.**
>
> Repeat of the three-band RAO procedure flowchart (Initialisation Routine → Iterative Optimization → Output Routine) from page 66, shown here as the completed sequence including the loop back from the *Stop Criteria Check* gateway.

The above figure is also a completion of the figure from CORNET-13 – Accuracy requirement. This always ensures that all relevant congestions are considered in the RAO.

###### Configuration

| Name | Description | Unit |  |  | Object |
| --- | --- | --- | --- | --- | --- |
|  | MaxCountCompIter Max. count of completeness iterations - |  |  | RAO Control Parameter |  |

System Requirement:

<!-- page 73 -->

##### SF3077 Objective Function

###### Scenario

UC489: BUC 14#43 Consideration of reservation costs for CRA

UC490: BUC 14#44 The RAO considers only the maximum CRA costs per time stamp in the objective function

###### Description

The objective function is part of the optimisation problem and is defined in the RAO as the minimisation of the sum over all cost terms.

These cost terms contain several operational and penalty costs, such as for the preventive and curative activated and used power bids from redispatch and countertrade or the tap changes of transformers. A full description can be found under Business Rules.

###### Outlook

For a future release, the same approach as for reservation costs from power bids is being discussed for the curative use of PSTs. Only the maximum curative tap change per time stamp is considered within the objective function value.

###### Business Rules

The optimisation objective is composed of several parts: a preventive redispatch/countertrade penalty term $C_{\mathit{rd}/\mathit{ct}}$, a curative redispatch/countertrade penalty term $C_{\mathit{rd}/\mathit{ct},\mathit{cur}}$, a penalty term for minimizing transformer tap adjustments in preventive mode $C_{\mathit{vol},T}$ and curative mode $C_{\mathit{vol},T,\mathit{cur}}$, and penalties for the utilisation of slack variables $C_{\mathit{vol},\mathit{slack}}$. The following terms apply each for one time stamp of the optimisation timeframe.

Thereby, the costs and imputed costs related to the adjustment of the power of a preventive remedial action bid b can be calculated by using the following equations, in case of a deterministic day-ahead approach:

$$
c_{b,\mathit{Day}-Ah\mathit{ead}} = c_{b,\mathit{Penalty}} \cdot \Delta P_{b}^{+} + c_{b,\mathit{Price} \mathit{for} \mathit{RD}+} \cdot \Delta P_{b}^{+} + c_{b,\mathit{Penalty}} \cdot \Delta P_{b}^{-} \\
+ c_{b,\mathit{Price} \mathit{for} \mathit{RD}-} \cdot \Delta P_{b}^{-} \tag{3.36}
$$

$$
c_{b,\mathit{Penalty}} = \mathit{cf}_{b,\mathit{penalty}} \cdot c_{\mathit{redisp},\mathit{reference}} \tag{3.37}
$$

$$
c_{b,\mathit{bid} \mathit{activation}} = c_{b,\mathit{activation} \mathit{cost}} *B_{\mathit{bid} \mathit{activation},b} \tag{3.38}
$$

and

$$
C_{\mathit{rd}/\mathit{ct}} = \sum_{b\in \mathit{PB}} c_{b,\mathit{Day}-Ah\mathit{ead}} + \sum_{b\in \mathit{PB}} c_{b,\mathit{bid} \mathit{activation}} + \sum_{g\in G} c_{g,\mathit{Startup}} \cdot B_{g,\mathit{ON}} \tag{3.39}
$$

<!-- page 74 -->

The costs for adjusting the power output of a preventive remedial action are defined in (3.36 ) and linked to the amount of the preventive adjustment $(\Delta P_{b}^{+}$ and $\Delta P_{b}^{-}$) from each power bid PB. The costs of the penalty term $c_{b,\mathit{penalty}}$ are preventing unnecessary adjustments and consists of a remedial action specific penalty cost factor $\mathit{cf}_{b,\mathit{penalty}}$ and a constant penalty reference value for preventive redispatch $c_{\mathit{redisp},\mathit{reference}}$ (3.37) (see CORNET-4606: Considered costs of redispatch RA in preventive mode). Additional costs are represented with the variable $c_{b,\mathit{Price} \mathit{for} \mathit{RD}}$ for reflecting the compensation payments for increasing ( RD+ ) or decreasing ( RD- ) the power output available from a power bid and is linked to the fuel consumption (e.g. the marginal costs) (additional information in CORNET-4606: Considered costs of redispatch RA in preventive mode). The activation costs of a power bid are defined in (3.38). These activation costs could be incurred at any time stamp (see BUC 14#102 Consideration of Power Bid activation costs). The binary variable $B_{\mathit{bid} \mathit{activation},b}$ represents the activation status of the power bid and is multiplied with the activation costs of the power bid ($c_{b,\mathit{activation} \mathit{cost}}$).

Start-up costs are linked to the generation unit and are reflected with the term $c_{g,\mathit{Startup}}$. These are multiplied with the binary variable $B_{g,\mathit{ON}}$, which represents the start-up status of a generation unit. The penalty term for curative redispatch remedial actions is calculated analogously:

$$
C_{b,\mathit{curative}} = c_{b,\mathit{Penalty}}^{\mathit{cur}} \cdot \Delta P_{b}^{\mathit{cur},+} + c_{b,\mathit{Reservation}}^{\mathit{cur},+} \cdot \Delta P_{b}^{\mathit{cur},+} + c_{b,\mathit{Penalty}}^{\mathit{cur}} \cdot \Delta P_{b}^{\mathit{cur},-} \\
+ c_{b,\mathit{Reservation}}^{\mathit{cur},-} \cdot \Delta P_{b}^{\mathit{cur},-} \tag{3.40}
$$

with

$$
c_{b,\mathit{Penalty}}^{\mathit{cur}} = \mathit{cf}_{b,\mathit{penalty}}^{\mathit{cur}} \cdot c_{\mathit{redisp},\mathit{reference}}^{\mathit{cur}} \tag{3.41}
$$

$$
\Delta P_{b}^{\mathit{cur},+} = \max_{c\in \mathit{Contingencies}} \{\Delta P_{b}^{\mathit{cur},c+} \} \forall b\in \mathit{PowerBids} \tag{3.42}
$$

$$
\Delta P_{b}^{\mathit{cur},-} = \max_{c\in \mathit{Contingencies}} \{\Delta P_{b}^{\mathit{cur},c-} \} \forall b\in \mathit{PowerBids} \tag{3.43}
$$

$$
C_{\mathit{rd}/\mathit{ct},\mathit{cur}} = \sum_{b\in \{\mathit{PB}|B_{G,\mathit{curative}} =1\}} C_{b,\mathit{curative}} \tag{3.44}
$$

The costs for curative remedial actions of a power plant are defined in (3.40) and linked to the amount of the curative adjustment $(\Delta P_{b}^{\mathit{cur},c+}$ and $\Delta P_{b}^{\mathit{cur},c-}$) per power bid. These costs consist of the penalty term $c_{b,\mathit{Penalty}}^{\mathit{cur}}$ preventing unnecessary adjustments and consists of a remedial action specific penalty cost factor $\mathit{cf}_{b,\mathit{penalty}}^{\mathit{cur}}$ and a constant penalty reference value for curative redispatch $c_{\mathit{redisp},\mathit{reference}}^{\mathit{cur}}$

(3.41) as well as the reservation costs $c_{b,\mathit{Reservation}}^{\mathit{cur}}$ for the curative redispatch volume (additional information in BUC 14#43: Considered costs of redispatch RA in curative mode). To avoid double counting the curative penalty and reservation costs within the objective function in all contingency situations, only the maximum activated curative adjustments are considered ( (3.42) and (3.43) ). This is directly implemented via a maximum constraint function from the solver.

<!-- page 75 -->

The penalty term added with the aim to minimize the preventive transformer tap adjustments is calculated using equation (3.45) for all transformers T .

$$
C_{\mathit{vol},T} = \sum_{\tau \in T} (c_{\tau} \cdot \Delta r_{\tau}^{+} + c_{\tau} \cdot \Delta r_{\tau}^{-} ) \tag{3.45}
$$

$$
c_{\tau} = \mathit{cf}_{\tau ,\mathit{penalty}} \cdot c_{T,\mathit{reference}} \tag{3.46}
$$

Each preventive transformer tap change is priced with a bid-specific penalty cost term $c_{\tau}$.

Analogously the penalty term for the curative transformer tap adjustments are formulated:

$$
C_{\mathit{vol},T,\mathit{cur}} = \sum_{c\in \mathit{Outages} d\in S \tau \in T} \sum (c_{\tau}^{\mathit{cur}} \cdot \Delta r_{\tau}^{\mathit{cur},c,d+} + c_{\tau \mathit{cur}} \cdot \Delta r_{\tau}^{\mathit{cur},c,d-} ) \tag{3.47}
$$

with

$$
c_{\tau}^{\mathit{cur}} = \mathit{cf}_{\tau ,\mathit{penalty}}^{\mathit{cur}} \cdot c_{T,\mathit{reference}}^{\mathit{cur}} \tag{3.48}
$$

For each TATL duration (d), which are part of the last TATL steps S, a variable $\Delta r_{\tau}^{\mathit{cur},c,d}$ per transformer exists and is the curative transformer tap adjustment made for the corresponding TATL duration d . Each curative tap adjustment is priced with a penalty term $c_{\tau}^{\mathit{cur}}$, which consists of a transformer-specific penalty factor $\mathit{cf}_{\tau ,\mathit{penalty}}^{\mathit{cur}}$ and a constant penalty reference value $c_{T,\mathit{reference}}^{\mathit{cur}}$ for curative tap adjustments (3.48) (additional information in CORNET-1982: Considered costs for PST in curative mode). Penalties for the utilisation of slack variables will be calculated as follows:

$$
C_{\mathit{vol},\mathit{slack},I} = c_{\mathit{vol},\mathit{slack},I} \cdot \sum_{b\in B} \Delta I_{b,\mathit{slack}} \tag{3.49}
$$

$$
C_{\mathit{vol},\mathit{slack},I,c,\mathit{PATL}} = c_{\mathit{vol},\mathit{slack},I,c,\mathit{PATL}} \cdot \sum_{b\in B} \Delta I_{b,\mathit{slack},\mathit{PATL}}^{c} \tag{3.50}
$$

$$
C_{\mathit{vol},\mathit{slack},I,c,\mathit{TATL}} = c_{\mathit{vol},\mathit{slack},I,c,\mathit{TATL}} \cdot \sum_{b\in B} \Delta I_{b,\mathit{slack},\mathit{TATL},s}^{c} \tag{3.51}
$$

The use of slack variables for the XNE constraints (3.49) - (3.51) are described in CORNET-1790: Consideration of XNE in MILP. It is possible in the RAO to define individual penalty costs for the overloading of branches (b) in N-0 ($c_{\mathit{vol},\mathit{slack},I}$) and N-X ($c_{\mathit{vol},\mathit{slack},I,c,\mathit{PATL}}$ and $c_{\mathit{vol},\mathit{slack},I,c,\mathit{TATL}}$). The number of RD PRA can be limited per timestamp or over the optimisation timeframe. When the constraint per timestamp is defined as soft, additional slack variables are considered by the RAO in each timestamp.

$$
C_{\mathit{RA},\mathit{slack},\mathit{TS}} = c_{\mathit{RA},\mathit{slack}} \cdot \sum_{\mathit{tso}\in \mathit{TSO}} A_{\mathit{RA},\mathit{tso},\mathit{slack},\mathit{TS}} \tag{3.52}
$$

The main objective function is the minimisation of the sum over all cost terms.

<!-- page 76 -->

$f_{\mathit{obj}} = \min ( \sum_{\mathit{time} \mathit{steps}} ( C_{\mathit{redisp}} + C_{\mathit{redisp},\mathit{cur}} + C_{\mathit{vol},T} + C_{\mathit{vol},T,\mathit{cur}} + C_{\mathit{vol},\mathit{slack},I}$

$$
+ C_{\mathit{vol},\mathit{slack},I,c,\mathit{PATL}} + C_{\mathit{vol},\mathit{slack},I,c,\mathit{TATL}} + C_{\mathit{RA},\mathit{slack},\mathit{TS}} ))
$$

As the final objective function value consists also of imputed costs, the sum of all redispatch costs will be given as an output, as well as the sum of different cost terms.

###### Triggers

The RAO started successfully and all pre-conditions are met.

###### Pre-Condition

All relevant input data is delivered.

At least one correctly defined assessed element is part of the AE-FlatList.

The initial loadflow converged.

###### Acceptance Criteria

Given

Penalty costs for preventive and curative RD, preventive and curative transformer taps and utilisation of slack variables are specified before a RAO run.

When

The RAO run is started,

Then

The objective function is constructed.

Given

A RAO optimisation problem has been built.

When

The RAO optimisation problem has been solved by the solver,

Then

The objective value is written to the RAO log.

###### Basic Flow

The following log-messages are exposed:

• The objective value of each MILP optimisation is written to the RAO log.

<!-- page 77 -->

###### Alternative Flow

No alternative flow foreseen.

##### CORNET-85: Considered time grid

###### Description

The RAO optimises a timeframe over a maximum of 25 hours. The size of each time stamp within the optimisation is one hour.

Additionally, the RAO uses in Release 1.1 the following:

• The intermediate time stamps are used in the 15 min time grid.

The input data is available in different time formats e.g., hourly, 15 min time stamps or just minutes. Therefore, the input data is processed accordingly for use in the hourly time steps of the optimisation. The technical constraints of the RAO must take the possible differences of time grids in the input data into account. Time-coupling constraints are therefore modelled in such a way that the technical constraints are always fulfilled.

System Requirement: SRQ831

##### BUC 14#115: Consideration of the RA status from RAC in following RAO iteration

###### Scenario

The RAO must consider the RA status given by the TSOs during RAC in the RAO run. The RA status is either agreed , rejected , notUsed or proposed .

###### Assumptions

A PRA can only be linked to one RemedialActionSchedule .

A CRA can be linked to multiple RemedialActionSchedule , one for each contingency.

The XRA must be present in the RemedialActionFlatList.

###### Description

At the end of the RAC, the determined RAs of the first RAO iteration have a defined statusKind in the RemedialActionSchedule for the Acceptance ( agreed ) or Refusal ( rejected ). The RAO must consider this status from the RAC process to determine the availability of the RAs.

<!-- page 78 -->

If a RemedialActionSchedule has the statusKind set as agreed , a PRA will be available in the RAO run. The RA can be fully used for the optimisation, depending on the available CT or RD volume, or available tap position changes.

A CRA will also be fully available in the RAO, but only for the linked contingency.

If a RemedialActionSchedule has the statusKind set as rejected , the RA will not be considered in the RAO in the optimisation. If the RemedialActionSchedule is linked to a PRA, this PRA is considered unavailable for the RAO run. If the RemedialActionSchedule is linked to a CRA, this CRA is not considered for the contingency linked in the RemedialActionSchedule for the RAO run.

If a RemedialActionSchedule has the statusKind set as notUsed , a PRA will be available in the RAO run. The RA can be fully used for the optimisation, depending on the available CT or RD volume, or available tap position changes.

A CRA will also be fully available in the RAO, but only for the linked contingency.

If a RemedialActionSchedule is for a topological XRA (see BUC 14#85), the statusKind can also be proposed. The RAO will apply the topological XRA when the statusKind is either agreed or proposed .

###### Configuration

The following input data is needed for the RAO:

| Name | Description | Unit | Data Type |  | Time | CoMo-Profile |
| --- | --- | --- | --- | --- | --- | --- |
|  |  |  |  |  | Series/ |  |
|  |  |  |  |  | Constant |  |
| statusKind | Status of the RAS - agreed - rejected - proposed - notUsed | - | enumeration constant |  |  | RemedialActio nScheduleProfi le: RemedialActio nSchedule: statusKind |

###### System Interactions

The RAO considers the statusKind if a RemedialActionSchedule is available in the input data for the RAO iteration.

###### Business Rules

The RA of the RemedialActionSchedule is considered by RAO as available if the statusKind is agreed .

<!-- page 79 -->

The RA of the RemedialActionSchedule is considered by RAO as available if the statusKind is proposed and the corresponding RA is a topological XRA.

The RA of the RemedialActionSchedule is not considered by RAO if the statusKind is rejected . If the RemedialActionSchedule is linked to a contingency, the CRA is not available for this specific contingency situation.

The RA of the RemedialActionSchedule is considered by RAO if the statusKind is notUsed .

The RA of the RemedialActionSchedule is not considered by RAO if the statusKind is anything else.

###### Triggers

The RAO started successfully and all pre-conditions are met.

###### Pre-Condition

At least one correctly defined assessed element is part of the AE-FlatList.

The initial loadflow converged.

A RemedialActionSchedule must be available in the input data for RAO.

The statusKind must be set accordingly in the RemedialActionSchedule .

###### Acceptance criteria (post condition)

Given

The RAO has a RAS with the statusKind agreed for the RAO iteration.

When

The RAO optimisation is carried out

Then

The RA must be available for congestion management in the RAO optimisation.

Given

The RAO has a RAS with the statusKind rejected for the RAO iteration.

When

The RAO optimisation is carried out

Then

The RA must not be available for congestion management in the RAO optimisation.

<!-- page 80 -->

###### Basic flow

The following log-messages are exposed:

• Rejected RAs (including the MRID)

###### Alternative flow

If a RemedialActionSchedule has a different statusKind than agreed , rejected, proposed or notUsed , the RemedialActionSchedule is logged and the RAO is canceled.

<!-- page 81 -->

#### 3.6.3 Consideration of Remedial Actions

##### CORNET-17: Participation of Controllable Units in Optimization

###### Description

All input data relevant for the optimization are mapped in the internal CorNet data model. Based on this the optimization problem is modelled.

The RAO considers the controllable entities listed below:

• PST (see CORNET-18 / CorNet Release 1.1 (partial))

• HVDC (see CORNET-XX / CorNet Release 1.2 ( TBD ))

• Generation units (see CORNET-29 / CorNet Release 1.1 (partial))

• Load units (see CORNET-XX / CorNet Release 1.2 ( TBD ))

• Countertrade (see CORNET-XX / CorNet Release 1.2 ( TBD ))

• TCSC and mSSSC (see CORNET-XX / CorNet Release 1.2 ( TBD ))

• Topology changes (see CORNET-XX / CorNet Version 2 ( TBD )).

Influence of controllable units on network congestions are modelled by means of sensitivities (see CORNET-27 Sensitivities of Generating / Load Units, CORNET-30 Sensitivities of PST, CORNET-31 Sensitivities of HVDC, CORNET-XX Sensitivities of TCSC and mSSSC ( TBD in R1.2 ) and CORNET- XX Sensitivities of Topology changes ( TBD in R1.2 )). Each potentially controllable unit has a flag "optimize" in the common grid model, which can be used to configure a controllable unit whether it participates active or not in a RAO calculation. If a controllable unit is marked as not optimizable, it will not be changed within the scope of the RAO calculation.

Note : The "optimise" flag is set as part of the common grid model adaptation on the basis of CGMES and CSA profiles. The attribute “Availability” for generation units is a time series for each hour of the day. In Release 1.1 the first time stamp of this time series is evaluated and the value is used for the whole optimisation timeframe. Later versions will evaluate the whole time series and consider each value in the corresponding time stamp.

Note: The RAO system automatically determines the shutdown capability of generation units from the modelled redispatch potential (see CORNET-41 - Consideration of RD Potentials) as described in CORNET-37 - Lower active power limits of generation units.

Note: The RAO considers only controllable entities which are connected to the largest subgrid.

###### Configuration

Data requirements OPF-Flag for Redispatch Unit:

<!-- page 82 -->

| Name | Description | Unit | Data Type | Time Series/ Constant | Data Object | CoMo-Object | Profile |
| --- | --- | --- | --- | --- | --- | --- | --- |
| Availability | Indicates whether the unit is to be used as degree of freedom in RAO calculation | - |  | Boolean constant | Network object | RemedialAction.available SSI-P |  |

System Requirement: SRQ836

##### CORNET-3447: RA Deciding Point

###### Description

The RAO considers the RA Deciding Point (RADP). RADP is the earliest point in time from which the technical lead time of a RA can be started (see CORNET-91: Consideration of lead times in RAO, CORNET-576: Consideration of lead time for redispatch RA in curative mode, CORNET-3616: Consideration of lead time for Power Bids in preventive mode).

The RADP is calculated during the runtime of the RAO and is the resulting time of adding the ordering time (duration) and the procedural/operational constraint time (duration) to the RA agreement reference time (RAART) (point in time).

<!-- page 83 -->

RAART POCT Optimisation Timeframe

OT RADP Lead time

22:00 00:30

RAART: RA Agreement Reference Time

OT: Ordering Time

POCT: Procedural/Operational Constraint Time

RADP: Remedial Action Deciding Point

Figure 4: Example for the determination of RADP based on RAART and additional durations for the DA CROSA The ordering time and the procedural time cannot be defined at the time of R24Q2 due to missing input data. Therefore, the RADP is equal to the RAART.

If no RAART is defined before the RAO starts, the default RADP is used. The default RADP is the time stamp right before the first time stamp of the optimisation period.

###### Configuration

Data requirements for the RA Deciding Point:

| Name | Description | Unit | Data type | Time series/ constant | Profile |
| --- | --- | --- | --- | --- | --- |
| RAART | RA agreement reference time | - | Time | constant | RAO Setting |

The RAART is defined as a point in time before the optimisation timeframe of the RAO. Therefore, the RAART is the first of day matching the defined reference time before the optimisation timeframe. If the ordering time and procedural time have to be indirectly considered, as a workaround the RAART must be set accordingly.

###### Details / Background

Example : A Day ahead CROSA starts at 18:00. It is expected that the Final Remedial Action Validation Session ends at 22:00. In this example the RAART is set at 22:00 and without an ordering time and procedural time, the RADP results in 22:00.

Example : Because an additional ordering time and procedural time cannot be defined in the input data, the RAART is set to 23:30 to indirectly consider these durations. Therefore, the RADP results in 23:30.

<!-- page 84 -->

The redispatch lead time of a RA is 3h and therefore could be used from 02:30. To ensure the complete consideration of this redispatch lead time within the hourly time stamps of the RAO, the RA can be used at the earliest in time stamp 03:30 within the optimisation. The resulting time of RADP + LeadTime is therefore rounded to the next available time stamp.

###### Outlook

This chapter is only for informational purposes and is not part of the delivered specification.

In the future, an ordering time and procedural time could be delivered to the RAO either via input data or configuration parameter. The exact approach is still in discussion. With the consideration of these two durations the RADP will be calculated during the RAO runtime and can be later than the RAART. Business Needs :

BN621: RAO-RA_Deciding_Point

Use Cases :

UC78: BUC 14#5 RAO-Deciding_Point_as_Parameter

Acceptance Criteria :

Given

The RAO has RD RA with Power Bids having a BidLeadTime. The RAART and therefore the RADP is set to 22:00.

When

The optimisation terminates successfully,

Then

No RD volume must be used from Power Bids for time stamps before or equal to RADP + BidLeadTime. If a BidLeadTime, counted from the RADP, ends within in a time stamp, the use of RD volume is only possible from the beginning of the following time stamp.

<!-- page 85 -->

##### CORNET-4848: Definition of GLSK in RAO

###### Description

Countertrade (CT) with the gLSKStrategy explicitInstruction and redispatch (RD) remedial actions (RAs) are linked to a GLSK ( GLSKSchedule ), which connects the available CT or RD volume defined in the Power Bids to the corresponding generating units ( cim:GeneratingUnit ). Other objects than generating units, which are linked to a GLSKSchedule are not considered by the RAO. Generating units can be part of different power remedial actions (RD or CT RAs).

For RD RAs the RAO only considers GLSK with fixed participation factors (similar to the strategy

###### explicitInstruction

participation factor ( participationFactor ) for each generating unit per time stamp, which describes the proportion of the generating unit on the RD volume.)

participationFactor

| GeneratingUnit ~ GeneratingUnit ~ GeneratingUnit ~ GeneratingUnit ~ | 0.2 0.3 0.3 0.2 | GLSKSchedule |
| --- | --- | --- |

For CT RAs the RAO considers the following GLSK strategies ( gLSKStrategy ):

###### explicitInstruction

###### proportionalForGenerator

###### proportionalForRemainingCapacity

###### General Assumptions

- Generating units cannot be started only by a CT RA

- Generating units cannot be shut down only by a CT RA

- For proportionalForGenerator and proportionalForRemainingCapacity GLSK strategies all generating units which are in operation of the bidding zone of a CT RA are considered - Actual production of a generating unit is defined as the follows:

$$
\mathit{actPROD}_{g} = \mathit{PROD}_{g} + \Delta P_{g}^{+} - \Delta P_{g}^{-}
$$

<!-- page 86 -->

o $\mathit{PROD}_{g}$: Production of the generating unit based on the CGM (see CORNET-41: Consideration of available RD volume)

o $\Delta P_{g}^{+}$: Amount of preventive upward adjustment of the generating unit due to RD and CT RAs

o $\Delta P_{g}^{-}$: Amount of preventive downward adjustment of the generating unit due to RD and CT RAs

o Only the adjustment due to preventive RAs is considered to determine $\mathit{actPROD}_{g}$

###### explicitInstruction

The GLSK must contain one or more generating units and has a participation factor ( participationFactor ) for each generating unit per time stamp, which describes the proportion of the generating unit on the CT volume.

###### proportionalForGenerator

All generating units of the bidding zone which are in operation are considered. The participation factors are calculated based on the actual production (actPROD of the generating unit.

$$
\mathit{PF}_{g} = \frac{\mathit{actPROD}_{g}}{\sum_{g \in G_{\mathit{BZ}}} \mathit{actPROD}_{g}}
$$

- $\mathit{PF}_{g}$: Participation factor of generating unit $g$

- $\mathit{PROD}_{g}$: Production of generating unit $g$

- $G_{\mathit{BZ}}$: All generating units of the bidding zone of the CT RA

###### proportionalForRemainingCapacity

All generating units of the bidding zone which are in operation are considered. The participation factors are calculated based on the remaining capacity (P max - actPROD) (see CORNET-36: Upper active power limits for generation units) of the generating unit.

$$
\mathit{PF}_{g} = \frac{P_{\max ,g} -\mathit{actPROD}_{g}}{\sum_{g \in G_{\mathit{BZ}}} P_{\max ,g} -\mathit{actPROD}_{g}}
$$

- $\mathit{PF}_{g}$: Participation factor of generating unit $g$

- $P_{\max ,g}$: Upper active power limit of generating unit $g$

- $\mathit{PROD}_{g}$: Production of generating unit $g$

- $G_{\mathit{BZ}}$: All generating units of the bidding zone of the CT RA

<!-- page 87 -->

If a GLSK with fixed participation factors (RD RA or CT RA with explicitInstruction ) contains generating units which cannot take part in the optimisation or the data is not sufficient, participationFactor is missing.

- RD RA: they are not connected to the largest subgrid)

- CT RA:

o Generating unit is not in operation (actPROD = 0)

o Generating unit is in start-up (actPROD > 0 & PROD < P min)

o For a PowerBid in upward direction: actPROD = P max

o For a PowerBid in downward direction: actPROD = P min

These generating units are not considered within the optimisation and thus, the participation factors of the remaining generating units in the GLSK do not add up to a total of one. The RAO normalizes the remaining participation factors by dividing the missing participation factors across the remaining generating units according to their initial participation factors (see example in “Details / Background”). The changed participation factors are part of the RAO output data for consideration in the following Core ROSC processes. If a generating unit is out of operation, it will remain in the GLSK because it could be started within the RAO for RD. If the sum of the initial participation factors is not equal to 1 the GLSK is normalized as described above:

$$
\mathit{PF}_{g} = \mathit{PF}_{g} + \frac{\sum_{h \in G_{\mathit{NO}}} \mathit{PF}_{h}}{\sum_{g \in G_{\mathit{GLSK}}} \mathit{PF}_{g}}
$$

- $\mathit{PF}_{g}$: Participation factor of generating unit $g$

- $\mathit{PF}_{h}$: Participation factor of generating unit $h$

- $G_{\mathit{GLSK}}$: All generating units of the GLSK which take part in the optimisation

- $G_{\mathit{NO}}$: All generating units of the GLSK which cannot take part in the optimisation

The RAO considers GLSK with generating units only. If a GLSK contains anything else then a generating unit load unit, the GLSK is not considered by the RAO. The linked Power Bids with this GLSK are therefore also not considered within the RAO.

Note : Future versions of the RAO will consider GLSK with load units and therefore also the linked Power Bids.

The RAO considers only generating units which are linked by one single GLSK. If a generating unit is linked to different GLSKs, all RAs with these GLSKs are not considered by the RAO.

The RAO considers the constraints of generating units when linked to a GLSK which is part of a RD RA ( RedispatchRemedialAction ). If the GLSK is part of a CT RA ( CountertradeRemedialAction ), the

<!-- page 88 -->

constraints of generating units are not indirectly considered within the optimisation (see CORNET- 4849: Consideration of technical limits of generating units of CT RAs).

###### Configuration

| Name | Description |  | Units Data type | Time | Profile |
| --- | --- | --- | --- | --- | --- |
|  |  |  |  | series/ |  |
|  |  |  |  | constant |  |
| participationFactor | The participation factor for each generating unit per time stamp | - | double | Time series | SIS-Profile: GLSKSchedule-> ParticipationFactorTimePoint .participationFactor |

<!-- page 89 -->

###### Details / Background

participationFactor a)

| GeneratingUnit ~ GeneratingUnit ~ GeneratingUnit ~ GeneratingUnit ~ | 0.2 0.3 0.3 0.2 | GLSKSchedule |
| --- | --- | --- |

participationFactor b)

| GeneratingUnit ~ GeneratingUnit ~ GeneratingUnit ~ GeneratingUnit ~ | 0.25 0.375 0.375 0.2 | GLSKSchedule |
| --- | --- | --- |

Figure 5: Handling of missing generation units to normalize the GLSK

Example : A GLSK is linked to four generating units (upper part (a) in Figure 1). One of the generating units connection node is not connected to the largest AC-subgrid. The generating unit is therefore not considered by the RAO for the optimisation. Because the remaining participation factors do not add up to a total of one, the RAO normalizes the remaining participation factors by dividing the missing participation factors across the remaining generating units according to their initial participation factors (lower part (b) in Figure 1).

###### Outlook

This chapter is only for informational purposes and is not part of the delivered specification.

Future versions of the RAO will consider GLSK with loads and therefore also the linked Power Bids.

<!-- page 90 -->

Business Needs :

BN606: RAO-GLSK_MPV

BN785: RAO-GLSK_Advanced: The RAO must support use and adaptation of GLSK

Use-Cases :

UC305: BUC 14#33 Consideration of GLSK in RAO (MVP)

UC859: BUC 14#89 Definition of GLSK in RAO - Additional GLSK Strategies

Acceptance Criteria :

Given

The RAO has a RD RA with Power Bids and a GLSK with at least two generating units.

When

The optimisation terminates successfully,

Then

If the RAO has determined available RD volume from one of these Power Bids for RD activation, the RD volume must be divided across the generating units of the GLSK according to their fixed participation factors at the corresponding time stamp.

Given

The RAO has a CT RA with Power Bids, a GLSK with at least two generating units and the GLSK strategy is either explicitInstruction, proportionalForGenerator or proportionalForRemainingCapacity. When

The optimisation terminates successfully,

Then

If the RAO has determined available CT volume from one of these Power Bids for CT activation, the CT volume must be divided across the generating units of the GLSK according to their current participation factors at the corresponding time stamp.

<!-- page 91 -->

##### BUC 14#112 Configuration of XNE linkage in CRAs

###### Scenario

##### BUC 14#112 Configuration of XNE linkage in CRAs

The User must have the ability to activate the consideration of the optional linkage between CRAs and a XNE. When activated, all existing links between CRA and XNE are considered in the RAO run and the CRA are restricted to relieve congestion on these XNE. By default, all existing links between CRA and XNE are not considered in the RAO run, making the CRA available to relieve congestion on all XNE.

###### Description

The RAO has a control parameter which activates the optional link between CRA and a subset of XNE (described in BUC 14#106 and BUC 14#110).

When the control parameter is activated, all existing links between CRA and XNE are considered by the RAO run.

The optional linkage between CRA and CO will continue to be considered as before.

###### Configuration

The following input data is needed for the RAO:

| Name | Description | Unit | Data Type | Time | CoMo-Profile |
| --- | --- | --- | --- | --- | --- |
|  |  |  |  | Series/ |  |
|  |  |  |  | Constan |  |
|  |  |  |  | t |  |
| activateLinkCRA _XNE | Activates the link between XNE and a subset of CRA | - | bool | constant | RAOControlParameterProfile: RAOControlParameterSet.activateLi nkCRA_XNE |

###### Business Rules

If the RAO control parameter is activated, all links between CRA and XNE are considered by the RAO. Without activation of the RAO control parameter, the RAO will not consider the link between CRA and a subset of XNE when available.

###### Triggers

The RAO started successfully and all pre-conditions are met.

<!-- page 92 -->

###### Pre-Condition

The RAO control parameter must be activated.

All relevant input data is delivered.

At least one correctly defined assessed element is part of the AE-FlatList.

The initial loadflow converged.

###### Acceptance Criteria

Given

The RAO control parameter activateLinkCRA_XNE is activated before a RAO run.

When

the optimisation terminates successfully,

then

The RAO should have considered the optional linkage between CRA and XNE in all available CRA. Given

The RAO control parameter activateLinkCRA_XNE is not activated before a RAO run.

When

The optimisation terminates successfully,

Then

Existing links between CRA and XNE are not considered in the RAO run.

###### Basic Flow

The following log messages are exposed:

• The RAO control parameter is activated, but no links between CRA and XNE have been defined • Defined links between CRA and XNE have not been considered, because the RAO control parameter is not activated

###### Alternative Flow

No alternative flow foreseen.

<!-- page 93 -->

#### 3.6.4 Consideration of PST in RAO

##### CORNET-18: Consideration of PST

###### Description

The RAO will include a consideration of phase shifting transformers (PST) as a degree of freedom / available remedial action in the optimisation problem. Each PST modelled in the CorNet data model and defined as a remedial action can participate in the optimisation.

The participation of a PST in the RAO is parameterised via the optimise flag (see CORNET-17 - Participation of Controllable Units in Optimisation).

In the context of the RAO calculation, PSTs are considered as controllable units, if they fulfil the requirements described in CORNET-103 – Consideration of PSTs in the LF computation and CORNET-30 - Sensitivities of PSTs. These requirements state that the PST has to be connected to the grid and is flagged as available as a remedial action.

###### Configuration

| Name | Descriptio n | Uni t | Data type |  | Time | Data object | CoMo-Object | Profil e |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
|  |  |  |  |  | series / |  |  |  |
|  |  |  |  |  | Consta |  |  |  |
|  |  |  |  |  | nt |  |  |  |
| availabl e | Availability for optimisatio n (optimise flag) | - | Boolea n | Constan t |  | Transform er | GridStateAlterationRemedialAct ion: RemedialAction.available | SSI-P |

###### Details / Background

For Release 1.1 only symmetrical PSTs are considered in accordance with CGMES format. In later releases 60° and 90° transformers will also be considered.

System Requirement: SRQ825

##### CORNET-2895: Limitation of PST in preventive mode

This specification replaces the following specifications:

- CORNET-19: Technical limits of a PST

- CORNET-20: Limitations of operating control range PST

<!-- page 94 -->

- CORNET-33: Consideration of relative PST limits

###### Description

The possible tap range of a PST is limited to the technical minimum and maximum values of the tap changer. Additionally, operational minimum and maximum values for tap changes can be defined. These limits can be specified in the CorNet data model.

Assumption : the absolute preventive maximum operational limit is less or equal to the absolute curative maximum operational limit. The absolute preventive minimum operational limit is greater or equal to the absolute curative minimum operational limit. If this assumption is not met, only the PRA is considered in the optimisation.

When the RA of the PST is defined as preventive, the technical limits are the absolute limits which will be taken first within the optimisation. These limits can be further limited by the operational limits of the PSTs ( highStepOperating / lowStepOperating ). A comparison of the operational limits with the technical limits ( highStep / lowStep ) is done during the build of the MILP to ensure the technical feasibility.

$$
\mathit{PSTtapMaxOperatingAbsolute}= \min (h\mathit{ig}h\mathit{Step}, h\mathit{ig}h\mathit{StepOperating}) \\
\mathit{PSTtapMinOperatingAbsolute}= \max (\mathit{lowStep}, \mathit{lowStepOperating})
$$

If the PRA also provides relative operational limits for the PST ( highStepRelative / lowStepRelative ), these limits will be compared to the absolute limits ($\mathit{PSTtapMaxOperatingAbsolute}$ / $\mathit{PSTtapMinOperatingAbsolute}$) to determine the restrictive limits.

$$
r_{\tau ,\max} = \min (\mathit{PSTtapMaxOperatingAbsolute}, r_{\tau ,0} (t) + h\mathit{ig}h\mathit{StepRelative}(t)) \\
r_{\tau ,\min} = \max (\mathit{PSTtapMinOperatingAbsolute}, r_{\tau ,0} (t) + \mathit{lowStepRelative}(t))
$$

The constraints for the compliance with these minimum and maximum values of the tap position are not relaxed in the optimisation problem of the RAO. Thus, the optimisation result of a tap position of a transformer $\tau$ cannot be outside the operational limits ($r_{\tau ,\min}$ / $r_{\tau ,\max}$).

$$
r_{\tau ,\min} \leq r_{\tau ,0} (t) + \Delta r_{\tau} (t) \leq r_{\tau ,\max}
$$

The variable $r_{\tau ,0}$ is the initial operating point before RAO from CGM in the current SUC t before application of the remedial measures and $\Delta r_{\tau} (t) = \Delta r_{\tau}^{+} (t) -\Delta r_{\tau}^{-} (t)$ is the deviation from this operating point in the optimisation. The optimisation formulation allows via a configuration parameter letting the tapping $\Delta r^{\tau}$ to be either a continuous or discrete value (control parameter: PSTTapingDiscrete). This is a global control parameter for all PSTs which are defined as RA (preventive and curative). The use of continuous tapping variables allows faster solving of the MILP compared to the use of discrete values for tapping.

<!-- page 95 -->

###### Configuration

The technical and operational limits of a PST can be supplied in the input data in various ways. The following business rules are being applied:

• The priority for determining the limits from the input data is as follows: Daily data NC-profile → Offline data NC-profile → IGM data

• If absolute tap limits are given in the daily online data of the NC-profile, these are defined as the operational limits (highStepOperatingOnline / lowStepOperatingOnline).

• If no tap limits are given in the daily data of the NC-profile, the tap limits given in the offline data of the NC-profile are the operational limits (highStepOperatingOffline / lowStepOperatingOffline).

• If minimum and maximum relative tap changes are supplied in the daily data of the NC-profile (highStepRelativeOnline / lowStepRelativeOnline), these cannot exceed the absolute minimum and maximum technical tap limits given in the input data. The reference value for the relative tap changes is the initial tap position before RAO.

• If no minimum and maximum relative tap changes are supplied in the online daily data of the NC-profile, the minimum and maximum relative tap changes of the offline data in the NC-profile (highStepRelativeOffline / lowStepRelativeOffline) if available is used. These cannot exceed the absolute minimum and maximum technical tap limits given in the input data.

• If both, relative and absolute tap changing limits are supplied e.g., in the daily NC-profile, they are both evaluated, and the stricter limit is applied.

Validation Rule : If more than one relative or absolute limit range is given in the input data for one PST, the strictest limit range is used in the RAO.

Data requirements for the limits of PST in preventive mode:

| Name | Descriptio n | Uni t | Data Type |  | Time | Profile |
| --- | --- | --- | --- | --- | --- | --- |
|  |  |  |  |  | Series/ |  |
|  |  |  |  |  | Constan |  |
|  |  |  |  |  | t |  |
| highStep | Technical maximum value of the tap changer | - | intege r |  |  | constant Equipment-Profile |

<!-- page 96 -->

| lowStep | Technical minimum value of the tap changer | - | intege r |  | constant Equipment-Profile |
| --- | --- | --- | --- | --- | --- |
| highStepOperatingOffli ne | Operationa l maximum value of the tap changer (offline data) | - | intege r | constant | RemedialAction-Profile RangeConstraint::normalValue RangeConstraint::direction.up RangeConstraint::valueKind.absolute |
| lowStepOperatingOfflin e | Operationa l minimum value of the tap changer (offline data) | - | intege r | constant | RemedialAction-Profile RangeConstraint::normalValue RangeConstraint::direction.down RangeConstraint::valueKind.absolute |
| highStepOperatingOnli ne | Operationa l maximum value of the tap changer (online data) | - | intege r | time series | SteadyStateInstruction-Profile RangeConstraint::Value (RangeConstraint - > mRID of the original StaticPropertyRange) |
| lowStepOperatingOnlin e | Operationa l minimum value of the tap changer (online data) | - | intege r | time series | SteadyStateInstruction-Profile RangeConstraint::Value (RangeConstraint - > mRID of the original StaticPropertyRange) |

<!-- page 97 -->

| highStepRelativeOffline | Operationa l maximum value of the tap changer (offline data) | - | intege r | constant | RemedialAction-Profile RangeConstraint::normalValue RangeConstraint::direction.up RangeConstraint::valueKind.increme ntal |
| --- | --- | --- | --- | --- | --- |
| lowStepRelativeOffline | Operationa l minimum value of the tap changer (offline data) | - | intege r | constant | RemedialAction-Profile RangeConstraint::normalValue RangeConstraint::direction.down RangeConstraint::valueKind.increme ntal |
| highStepRelativeOnline | Operationa l maximum value of the tap changer (online data) | - | intege r | time series | SteadyStateInstruction-Profile RangeConstraint::Value (RangeConstraint - > mRID of the original StaticPropertyRange) |
| lowStepRelativeOnline | Operationa l minimum value of the tap changer (online data) | - | intege r | time series | SteadyStateInstruction-Profile RangeConstraint::Value (RangeConstraint - > mRID of the original StaticPropertyRange) |
| PSTTapingDiscrete | Control parameter to define if the PST tapping is discrete |  | bool |  | constant RAO Control Parameter |

<!-- page 98 -->

|  | (true) or continuous (false) |  |  |  |  |
| --- | --- | --- | --- | --- | --- |

Business Needs : BN872: RAO-RA_OperationalLimit_PRA_PST_MVP

Acceptance Criteria :

Given

The RAO could reduce the loading on an overloaded XNE with a preventive PST remedial action and the maximum technical tap limits is at least one tap above the operational tap limit and the minimum technical tap limit is at least one tap below the operational tap limit.

When

the optimisation terminates successfully,

then

the determined curative PST tap changes in the contingency situation are a maximum of 2 tap changes per PST. Other constraints can have an influence on the result of the RAO.

##### CORNET-21: Group constraints for PST (RRQ 866)

###### Description

Use Case : The RAO user expects that PST groups are taken into account by the RAO.

The RAO system offers the possibility to define groups of PSTs that must be equally tapped within the OPF. Equally tapped means that the tap position of all PSTs in a PST group must be the same after optimization.

It is possible to define any number of such PST groups. A PST group can contain any number of PSTs present in the network model.

A PST can be assigned to several groups.

Within the RAO, a constraint in the optimization problem (PST group constraints) ensures that the tap positions of all PSTs in a PST group are the same after optimization. So the delta tap within the optimisation might be different if initial tap positions are not the same.

The orientation of the tap positions in the transformers and existing PST group constraints should be modelled correctly by the TSO and will not be changed by the RAO.

The minimum and maximum tap positions of all PSTs within a PST group are evaluated. If the tapping range of one or more transformers is not within the overlapping tapping range of its PST group (see

<!-- page 99 -->

figure below), the constraint of the minimum and maximum tap position is restrictive and excludes the whole PST group from the optimisation (see example below).

If the optimize flag (see CORNET-17 - Participation of controllable units in optimisation) of at least one PST in a PST group is set to No, then no PST in this PST group will participate in the optimization. In this case, a warning and logging will occur.

No relaxation of PST group constraints exists in the optimization problem.

Before the RAO, it is checked whether technical limitations (see CORNET-19 - Technical limits of a PST) of the minimum and maximum tap positions allow an equal tap position of all PST in a PST group. If this is not given, all PST of this PST group are excluded from the optimization for all time stamps, since no solution exists that can fulfil this constraint. In this case, a warning and logging will occur. The following example illustrates this.

###### Configuration

Data requirement: PST groups

|  | Name Description Unit |  | Data Type | Time |  | Data Object | CoMo Object | Profile |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
|  |  |  |  | Series/ |  |  |  |  |
|  |  |  |  | Constant |  |  |  |  |
| psts | PSTs that belong to a group | - | - | constant |  | PST- Group | GridStateAlterationRemedialAction: TapPositionAction | RA-P |

Two or more objects of the TapPositionAction definition in the GridStateAlterationRemedialAction class form a PST group.

###### Details / Background

Example: The following figure shows a qualitative example of the range of technically possible tap positions of three PSTs. Technical limits of the PSTs:

|  | PST lowStep highStep |  |
| --- | --- | --- |
| PST 1 -13 |  | -4 |
| PST 2 -9 |  | -1 |
| PST 3 2 |  | 15 |

PST 1 and PST 2 could be optimized in one group. This will result in the possible range of resulting tap positions from -9 to -4. If the tap positions before optimisation are not equal (PST 1: -9 and PST 2: -4). The RAO will ensure, that the tap positions after optimisation are the same. In this example the tap position after optimisation is -6 for both PSTs. Thus, the delta tap changes are + 3 for PST 1 and -2 for PST 2.

<!-- page 100 -->

If PST 3 were also in added to this PST group, all three PSTs would be excluded from the optimization, because the three PSTs have no intersection of their technical limits.

> **Figure (page 100) — described in text.**
>
> Number line of PST tap positions from −14 to +15, with three coloured bars showing each PST's technical range:
>
> - **PST 1** (dark blue): roughly −13 to −4
> - **PST 2** (orange): roughly −9 to −1
> - **PST 3** (yellow): roughly +2 to +15
>
> A shaded blue band from about −9 to −4 is bracketed *range of PST group (PST 1 and PST 2)* — the intersection of the first two ranges. Arrows below the axis mark *Tap before opt. (PST 1)* ≈ −9, *Tap before opt (PST 2)* ≈ −4, and *Tap after opt (PST 1 & 2)* ≈ −6. PST 3 has no overlap with the others, which is why it cannot join the group.

Figure: Tap position bands of PSTs

##### Note:

• Curative use of PSTs is foreseen for Release 1.2

• PST flows are foreseen for Release 1.2

System Requirement: SRQ825

##### CORNET-3653: Limitation of the PST tap changes per time stamp

###### Description

In order to achieve a feasible solution for the operator, the tap changes to be implemented per time stamp must be limited. One tap change is defined as the change of one PST step in either direction. Example : The change from the PST tap position 5 to the PST tap position 8 equals three tap changes. Example : The change from the PST tap position 5 to the PST tap position 3 equals two tap changes. The limitation applies on scheduled tap changes and determined preventive tap changes by the RAO.

<!-- page 101 -->

The limit maxTapsTS_TSO is defined for each TSO and limits the number of the initial scheduled tap changes $\Delta r_{\tau ,\mathit{sc}h\mathit{edule}}$ before RAO and the number of preventive tap changes $\Delta r_{\tau}$ determined by the RAO for all transformer $\tau$ of that TSO that can be performed in each time stamp t. The limit constraint is modelled soft with a slack variable. Therefore, any additional tap change ($A_{T,\mathit{TSO},\mathit{slack}}$) above maxTapsTS_TSO is penalised with PSTlimitTS_penalty within the objective function of the RAO. The penalty cost term could be parameterised in such a way that additional tap changes above the limit occur only in a certain percentage of all time stamps, e.g. in only 20 % of all calculated time stamps.

$$
\sum_{\tau \in T} |\Delta r_{\tau ,\mathit{sc}h\mathit{edule}} (t) + \Delta r_{\tau ,\mathit{TSO}} (t)| - A_{T,\mathit{TSO},\mathit{slack}} (t) \leq \mathit{maxTapsTS}\_\mathit{TSO}
$$

The constraint exists for each time stamp t and for each TSO.

Note : Additionally, each PST has a maximum number of tap changes it can perform each optimisation timeframe (see CORNET-3654: Limitation of the PST tap changes per optimisation timeframe).

###### Configuration

| Name | Description | Units | Data type | Time series/ constant | Profile |
| --- | --- | --- | --- | --- | --- |
| PSTlimitTS_penal ty | Penalty cost for additional tap changes of PST above maxTapsTS_TSO | €/tap |  | integer constant | RAO Control Parameter |
| maxTapsTS_TSO | Maximum number of tap changes allowed per timestamp and per TSO without additional penalty costs |  |  | integer constant | RAO Control Parameter |

###### Outlook

This chapter is only for informational purposes and is not part of the delivered specification.

A future release of the RAO will consider the limitation of tap changes for contingency cases and/or CRAs.

##### Business Needs:

<!-- page 102 -->

BN870: RAO-RA_Limit_PST_Advanced

Use-Cases :

UC278: BUC 14#28 Limiting the number of PST tap changes for a time stamp in RAO

Acceptance Criteria :

Given

The RAO has preventive PST RA and a defined maxTapsTS_TSO limit with a very high (maximum value) PSTlimitTS_penalty .

When

The optimisation terminates successfully,

Then

The preventive tap changes of each PST (scheduled + determined by RAO) per time stamp should not exceed maxTapsTS_TSO .

Given

The RAO has preventive PST RA and a defined maxTapsTS_TSO limit with a PSTlimitTS_penalty . When

The optimisation terminates successfully,

Then

The preventive tap changes of each PST (scheduled + determined by RAO) per time stamp could exceed maxTapsTS_TSO .

##### CORNET-3654: Limitation of the PST tap changes per optimisation timeframe

###### Description

Additionally, to limit the accepted tap changes per time stamp for PSTs (see CORNET-3653: Limitation of the PST tap changes per time stamp), a limitation of the tap changes per optimisation timeframe ( OT ) can be defined. This constraint is defined for each PST. One tap change is defined as the change of one PST step in either direction.

Example : The change from the PST tap position 5 to the PST tap position 8 equals three tap changes. Example : The change from the PST tap position 5 to the PST tap position 3 equals two tap changes. The limitation applies on scheduled tap changes and determined preventive tap changes by the RAO. The maximum number of tap changes per optimisation timeframe ( maxTapsOT ) is specific for each transformer $\tau$. By modelling the constraint soft, additional tap changes above the limit are possible and

<!-- page 103 -->

priced with the penalty cost term PSTlimitOT_penalty within the objective function of the RAO. The penalty cost term could be parameterised in such a way that additional tap changes above the limit occur only in a certain percentage of all timeframes, e.g. in only 20 % of all calculated timeframes of the year.

$$
\sum_{t\in \mathit{OT}} |\Delta r_{\tau ,\mathit{sc}h\mathit{edule}} (t) + \Delta r_{\tau} (t)| - A_{\tau ,\mathit{slack}} \leq \mathit{maxTapsOT}_{\tau}
$$

The constraint exists for each PST. The sum of the absolute values from the scheduled tap changes $\Delta r_{\tau ,\mathit{sc}h\mathit{edule}}$ plus the preventive tap changes $\Delta r_{\tau}$ determined by the RAO in each time stamp t of the optimisation timeframe should be less than maxTapsOT . By subtracting the PST-specific slack variable $A_{\tau ,\mathit{slack}}$ from the sum of the tap changes, additional tap changes with additional penalty costs for each tap change above maxTapsOT are possible.

Note : If maxTapsOT of a PST is defined lower than the sum of the absolute values from the initial scheduled tap changes over the optimisation timeframe before RAO, the RAO might determine tap changes which result in a schedule with less absolute tap changes over the optimisation timeframe. The input data is not validated in that regard.

###### Configuration

| Name | Description | Units | Data type | Time series/ constant | Profile |
| --- | --- | --- | --- | --- | --- |
| PSTlimitOT_penal ty | Penalty cost for additional tapping of PST above maxTapsOT | €/tap |  | integer constant | RAO Control Parameter |
| maxTapsOT | Maximum number of tapping actions allowed per optimisation timeframe and per PST without additional penalty costs |  |  | integer constant | RA-P GridStateAlteratio n.maximumPerDa y |

<!-- page 104 -->

###### Details / Background

Schedule by CGM Schedule after RAO 1 1 2 3 4 5 6 7 Time stamps

Example : The figure above shows the scheduled PST tap positions (yellow line). The RAO determines a change of the schedule for the time stamps 2 to 4 (green line). The sum of the absolute value of the resulting tap changes for the timeframe is four:

• two tap changes in time stamp 2

• one tap change in time stamp 4

• one tap change in time stamp 6

##### Business Needs:

BN870: RAO-RA_Limit_PST_Advanced

Use-Cases :

UC279: BUC 14#29 Limiting the number of PST tap changes for the optimisation timeframe in RAO Acceptance Criteria :

Given

The RAO has preventive PST RA and a defined maxTapsOT limit with a very high (maximum value) PSTlimitOT_penalty .

When

The optimisation terminates successfully,

Then

The preventive tap changes of each PST (scheduled + determined by RAO) per optimisation timeframe should not exceed maxTapsOT .

Given

The RAO has preventive PST RA and a defined maxTapsOT limit with a PSTlimitOT_penalty . When

The optimisation terminates successfully,

<!-- page 105 -->

Then

The preventive tap changes of each PST (scheduled + determined by RAO) per optimisation timeframe could exceed maxTapsOT .

##### CORNET-2998: Considered costs for PST in preventive mode

This specification replaces the following specifications:

- CORNET-20: Limitations of operating control range PST

###### Description

Use Case : The RAO user expects that operational limits of a PST are taken into account by the RAO as a hard constraint.

The RAO System offers the possibility to specify an operational maximum and minimum value for the tap position for each PST. These parameters can be specified in the network model.

The range between operational and technical limits of the control range is not considered in the optimisation. Therefore, only one penalty cost factor is necessary.

The preventive PST tap changes are considered via penalty costs from the input data within the objective function of the RAO (see CORNET-1765: Objective function). These RA specific penalty costs $c_{\tau}$ are calculated from the penalty cost factor of the input data $\mathit{cf}_{\tau ,\mathit{penalty}}^{\mathit{prev}}$ (RAPenaltyFactor) and the preventive penalty reference value for PST of the RAO $c_{T,\mathit{reference}}^{\mathit{prev}}$. The RA specific penalty costs must be multiplied with the number of determined tap changes of the RA in the objective function.

$$
c_{\tau} = \mathit{cf}_{\tau ,\mathit{penalty}}^{\mathit{prev}} \cdot c_{T,\mathit{reference}}^{\mathit{prev}} \tag{3.54}
$$

Additional costs for PST in preventive mode are not considered in this release.

###### Configuration

| Name |  | Unit | Data Typ e | Time Series/ Constan t | Profile |
| --- | --- | --- | --- | --- | --- |
|  | Descriptio |  |  |  |  |
|  | n |  |  |  |  |
| RAPenaltyFactor | Penalty cost factor of the PRA |  |  | float constant | RemedialAaction-Profile RemedialAction::penaltyFact or |

<!-- page 106 -->

|  | for each tap change of a PST. Must be multiplied with the preventive penalty reference value of the RAO. |  |  |  |  |
| --- | --- | --- | --- | --- | --- |
| PenaltyReferencePSTpreventi ve | Preventive penalty reference value for PST for each tap change | €/Ta p |  | float constant RAO-Setting |  |

Business Needs : BN872: RAO-RA_OperationalLimit_PRA_PST_MVP

##### BUC 14#110 Consideration of PST as curative remedial actions

###### Scenario

##### BUC 14#110 Consideration of PST as curative remedial actions

PSTs can also be used in curative mode as a remedial action. The tap positions are changed when the contingency occurs. For each contingency situation different curative tap changes must be determined.

The use of PSTs as a CRA is only possible in tap mode, not targetflow mode.

###### Assumptions

The link from a CRA to one or multiple contingencies is optional.

The link from one or multiple CRA to a XNE is optional.

<!-- page 107 -->

###### Description

PSTs can be used as curative remedial actions (CRAs) in the RAO. For that, the PST must be linked to a CRA and be defined as available in the RA-Profile. If a RA is defined as curative ( RemedialAction::kind ), it can be linked to one or multiple contingencies (COs). Optionally, a subset of CRAs can be linked to a XNE. Therefore, the consideration of a CRA is possible for the following cases: - CRA linked to COs: CRA can be used independently for the linked CO cases and for all XNEs - CRA linked to COs and to one or multiple XNEs: CRA can be used only for all combinations of the linked COs and XNEs

- CRA without links to COs and any XNE: CRA can be used for all COs and for all XNEs - CRA without link to COs and linked to one or multiple XNEs: CRA can be used for all COs, but only for the subset of XNEs linked to

Additionally, CRA will be considered in the optimisation according to CORNET-92 - Consideration of XNEs in MILP.

In RAO V1 only one TATL per assessed element is considered for the determination of CRAs (see CORNET-1792 and CORNET-2586). In addition to the reaction time (see CORNET-1978: Consideration of reaction time for PST in curative mode), the change of the tap position needs time ( PSTSpeedCurative ) as well and must be considered when determining the limits of the PST tap change (see CORNET-1985: Limitations of PST in curative mode).

Note : for PST in curative mode an operation only in tap mode is foreseen. A targetflow mode is not considered within the RAO for PST as CRA.

Note : CRA are only considered linearised within the FOA of the RAO.

###### Outlook

In a future release the CRA can be linked additionally to a region and not only to a XNE.

###### Configuration

The following input data is needed for the RAO:

| Name | Description | Unit | Data Type | Time | CoMo-Profile |
| --- | --- | --- | --- | --- | --- |
|  |  |  |  | Series/ |  |
|  |  |  |  | Constan |  |
|  |  |  |  | t |  |
| available | Availability for optimisation given | - | bool | time series | RemedialActionFlatList: RemedialAction::available |

<!-- page 108 -->

|  | for each time stamp |  |  |  |  |
| --- | --- | --- | --- | --- | --- |
| RAactivationKin d | Definition if PST is preventive or curative RA | - |  | string constant | RemedialActionFlatList: RemedialAction::kind |
| linkedContingen cies | List of contingencies for the curative use (optional) | - |  | string constant | RemedialActionFlatList: ContingencyWithRemedialAction |
| linkedAssessed Elements | List of assessed elements for the curative use (optional) | - |  | string constant | AssessedElementFlatList: AssessedElement -> RemedialAction.enabled = true RemedialAction.ruleType = included |
| PSTSpeedCurati ve | Time needed to change one tap in curative mode | min | float | constant | RemedialActionFlatList: GridStateAlteration:: timePerStage |

###### Business Rules

CRA linked to COs: CRA can be used independently for the linked CO cases and for all XNEs CRA linked to COs and to one or multiple XNEs: CRA can be used only for all combinations of the linked COs and XNEs

CRA without links to COs and any XNEs: CRA can be used for all COs and for all XNEs

CRA without link to COs and with link to one or multiple XNEs: CRA can be used for all COs, but only for the subset of linked XNEs

###### Triggers

The RAO started successfully and all pre-conditions are met.

###### Pre-Condition

• All relevant input data is delivered, see Configuration.

• At least one correctly defined assessed element is part of the AE-FlatList.

• At least one correctly defined contingency situation is part of the CO-FlatList.

• The initial loadflow converged.

<!-- page 109 -->

###### Acceptance Criteria:

Given

The RAO could reduce the loading on an overloaded XNE in a contingency situation with two curative PST remedial actions with one of them being linked to this contingency situation and the other is not. Both PST can be tapped in such a way that the loading on the overloaded XNE is reduced.

When

the optimisation terminates successfully,

then

only the curative PST remedial action linked to the contingency situation is used for reducing the loading of the XNE. The penalty costs are parameterized in such a way that eliminating the

congestion by PST remedial actions leads to a lower objective function value. Other constraints can have an influence on the result of the RAO.

Given

The RAO could reduce the loading on an overloaded XNE in a contingency situation with two curative PST remedial actions with one of them being linked to this contingency situation and linked to this XNE and the other is linked to this contingency situation and a different XNE. The penalty costs are parameterized in such a way that eliminating the congestion by PST remedial actions leads to a lower objective function value.

When

the optimisation terminates successfully,

then

only the curative PST remedial actions which is linked to this contingency situation and the

overloaded XNE is determined as a curative remedial action for activation in the contingency situation. Other constraints can have an influence on the result of the RAO.

Given

The RAO could reduce the loading on an overloaded XNE in a contingency situation with a curative PST remedial action not linked to any contingency situation. The PST can be tapped in such a way that the loading on the overloaded XNE is reduced.

When

the optimisation terminates successfully,

then

the curative PST remedial action is used for reducing the loading of the XNE. The penalty costs are parameterized in such a way that eliminating the congestion by PST remedial actions leads to a lower objective function value. Other constraints can have an influence on the result of the RAO.

<!-- page 110 -->

###### Basic Flow

The results of the CRA are exported via the RemedialActionScheduleProfile (see SF3079: GridStateIntensitySchedule Optimisation results).

###### Alternative Flow

The following log-messages are exposed:

• If a CRA is linked to the AE and the CRA is not in the RA-FlatList a fatal error is logged and the RAO is cancelled

• If a CO is linked to a CRA and the CO is not found in the CO-FlatList a fatal error is logged and the RAO is cancelled

##### CORNET-1978: Consideration of reaction time for PST in curative mode

###### Description

In RAO V1 only one TATL per assessed element is considered for the determination of CRAs (see CORNET-1792 and CORNET-2586). The reaction time of the CRA ( RemedialAction::timeToImplement ) must be compared to the temporary overloading time associated to this one TATL of the assessed element (TATL duration). The timeToImplement is the time needed for the TSO to start the activation of the tapping. If timeToImplement of the CRA is lower than the TATL duration of the assessed element, the CRA is considered as a viable CRA option for the linked contingency cases and this assessed element. Otherwise, if timeToImplement of the CRA is equal to or higher than the TATL duration, the CRA is not considered in the optimisation for this assessed element. If timeToImplement is empty in the input data, it is set to 0.

###### Configuration

| Name | Description | Unit | Data Type | Time Series/ Constant | Profile |
| --- | --- | --- | --- | --- | --- |
| timeToImplement | This will at least provide the reaction time that will need to be compared to the temporary overloading time associated to the | min float |  | constant | RemedialAction-Profile RemedialAction::timeToImplement |

<!-- page 111 -->

|  | TATL of the grid elements |  |  |  |  |
| --- | --- | --- | --- | --- | --- |

Business Needs : BN781: RAO-RA_CRA_PST (RAO)

Acceptance Criteria :

Given

The RAO could reduce the loading on an overloaded XNE with a TATL duration of 10 minutes in a contingency situation with curative PST remedial actions which are linked to this contingency situation and have a reaction time of 1 minute and a tap change time of 2 min/tap.

When

the optimisation terminates successfully,

then

the determined curative PST tap changes in the contingency situation are a maximum of 4 tap changes per PST. Other constraints can have an influence on the result of the RAO.

##### CORNET-1985: Limitations of PST in curative mode

###### Description

The possible tap range of a PST is limited to the technical minimum and maximum values of the tap changer. Additionally, operational minimum and maximum values for tap changes can be defined. These limits can be specified in the CorNet data model.

Assumption : the absolute preventive maximum operational limit is less or equal to the absolute curative maximum operational limit. The absolute preventive minimum operational limit is greater or equal to the absolute curative minimum operational limit. If this assumption is not met, the CRA is not considered in the optimisation.

When the RA of the PST is defined as curative, a comparison of the operational limits with the technical limits ( highStep / lowStep ) is done during the build of the MILP to ensure the technical feasibility of the operational limits of the PSTs ( highStepOperating / lowStepOperating ).

$$
\mathit{PSTtapMaxOperatingAbsolute}= \min (h\mathit{ig}h\mathit{Step}, h\mathit{ig}h\mathit{StepOperating}) \\
\mathit{PSTtapMinOperatingAbsolute}= \max (\mathit{lowStep}, \mathit{lowStepOperating})
$$

<!-- page 112 -->

If the CRA also provides relative operational limits for the PST ( highStepRelative / lowStepRelative ), these limits will be compared to the absolute limits ($\mathit{PSTtapMaxOperatingAbsolute}$ / $\mathit{PSTtapMinOperatingAbsolute}$) to determine the restrictive limits. $\Delta r_{\tau} (t)$ is the deviation from the initial operating point as preventive remedial action.

$\mathit{PSTtapMaxOperating}= \min (\mathit{PSTtapMaxOperatingAbsolute}, r_{\tau ,0} (t) + \Delta r_{\tau} (t) + h\mathit{ig}h\mathit{StepRelative}(t))$ $\mathit{PSTtapMinOperating}= \max (\mathit{PSTtapMinOperatingAbsolute}, r_{\tau ,0} (t) + \Delta r_{\tau} (t) + \mathit{lowStepRelative}(t))$ The maximum usable tap changes within the optimisation are not only limited by the RA input data ( PSTtapMaxOperating / PSTtapMinOperating ), but also regarding the possible tap changes within the TATL duration available (see CORNET-571: Consideration of PST as curative remedial actions). As specified in CORNET-1790 (Consideration of XNEs in MILP) each TATL duration within a considered CO case is considered as one step $s$ in the MILP. For each step the maximum possible tap changes are calculated for the considered TATL duration ($\mathit{maxTap}_{\mathit{TATL},s}$) during the MILP building process. $\mathit{maxTap}_{\mathit{TATL},s} = \mathit{round}\_\mathit{down}(\max (0, \mathit{TATLduration}_{\mathit{XNE}} -\mathit{timeToImplement})/\mathit{PSTspeed})$ The maximum possible tap position in upwards and downwards direction as a CRA for each step are determined via the minimum or maximum tap because of $\mathit{maxTap}_{\mathit{TATL},s}$ and PSTtapMaxOperating or PSTtapMinOperating, respectively. Because $\mathit{maxTap}_{\mathit{TATL},s}$ is a relative value, the initial tap position ($r_{\tau ,0} (t))$ is used to determine absolute tap positions for each step.

$$
r_{\tau ,\max}^{\mathit{cur},s} (t) = \min ((r_{\tau ,0} (t) + \Delta r_{\tau} + \mathit{maxTap}_{\mathit{TATL},s} ), \mathit{PSTtapMaxOperating}) \\
r_{\tau ,\min}^{\mathit{cur},s} (t) = \max ((r_{\tau ,0} (t) + \Delta r_{\tau} -\mathit{maxTap}_{\mathit{TATL},s} ), \mathit{PSTtapMinOperating})
$$

These values are determined during the build of the MILP. The limitations on the possible tap changes are ensured via a constraint in the optimisation for each TATL duration d to consider from the critical elements.

$$
r_{\tau ,\min}^{\mathit{cur},s} (t) \leq r_{\tau ,0} (t) + \Delta r_{\tau} (t) + \sum_{d\in s} \Delta r_{\tau}^{\mathit{cur},d} (t) \leq r_{\tau ,\max}^{\mathit{cur},s} (t)
$$

The variable $r_{\tau ,0}$ is the initial operating point in the current timestamp t before application of the remedial actions and $\Delta r_{\tau}^{\mathit{cur},d} (t) = \Delta r_{\tau}^{\mathit{cur},d+} (t) -\Delta r_{\tau}^{\mathit{cur},d-} (t)$ is the deviation from this operating point in the optimisation for a given TATL duration. Each constraint must also contain the $\Delta r_{\tau}^{\mathit{cur},d} (t)$ of all TATL durations less than the TATL duration of the current step.

The constraint of the technical limits introduced in CORNET-2895 (Limitations of PST in preventive mode) must be updated to reflect the tap adjustments in curative mode:

<!-- page 113 -->

$$
r_{\tau ,\min} < r_{\tau ,0} (t) + \Delta r_{\tau} (t) + \sum_{d\in s} \Delta r_{\tau}^{\mathit{cur},d} (t) \leq r_{\tau ,\max}
$$

The optimisation formulation allows via a configuration parameter letting the tapping $\Delta r_{\tau}$ and $\Delta r_{\tau}^{\mathit{cur}}$ to be either a continuous or discrete value (control parameter: PSTTapingDiscrete)

###### Configuration

The technical and operational limits of a PST can be supplied in the input data in various ways. The following business rules are being applied:

• The priority for determining the limits from the input data is as follows:

Daily data NC-profile → Offline data NC-profile → IGM data

• If absolute tap limits are given in the daily online data of the NC-profile, these are defined as the operational limits ( highStepOperatingOnline / lowStepOperatingOnline ).

• If no tap limits are given in the daily data of the NC-profile, the tap limits given in the offline data of the NC-profile are the operational limits ( highStepOperatingOffline /

lowStepOperatingOffline ).

• If minimum and maximum relative tap changes are supplied in the daily data of the NC-profile (highStepRelativeOnline / lowStepRelativeOnline), these cannot exceed the absolute minimum and maximum technical tap limits given in the input data. The reference value for the relative tap changes is the initial tap position before RAO.

• If no minimum and maximum relative tap changes are supplied in the online daily data of the NC-profile, the minimum and maximum relative tap changes of the offline data in the NC- profile (highStepRelativeOffline / lowStepRelativeOffline) if available is used. These cannot exceed the absolute minimum and maximum technical tap limits given in the input data. • If both, relative and absolute tap changing limits are supplied e.g., in the daily NC-profile, they are both evaluated, and the stricter limit is applied.

Validation Rule : If more than one relative or absolute limit range is given in the input data for one PST, the strictest limit range is used in the RAO.

| Name | Descriptio n | Uni t | Data Type |  | Time | Profile |
| --- | --- | --- | --- | --- | --- | --- |
|  |  |  |  |  | Series/ |  |
|  |  |  |  |  | Constan |  |
|  |  |  |  |  | t |  |
| highStep | Technical maximum value of | - | intege r |  |  | constant Equipment-Profile |

<!-- page 114 -->

|  | the tap changer |  |  |  |  |
| --- | --- | --- | --- | --- | --- |
| lowStep | Technical minimum value of the tap changer | - | intege r |  | constant Equipment-Profile |
| highStepOperatingOffli ne | Operationa l maximum value of the tap changer (offline data) | - | intege r | constant | RemedialAction-Profile RangeConstraint::normalValue RangeConstraint::direction.up RangeConstraint::valueKind.absolute |
| lowStepOperatingOfflin e | Operationa l minimum value of the tap changer (offline data) | - | intege r | constant | RemedialAction-Profile RangeConstraint::normalValue RangeConstraint::direction.down RangeConstraint::valueKind.absolute |
| highStepOperatingOnli ne | Operationa l maximum value of the tap changer (online data) | - | intege r | time series | SteadyStateInstruction-Profile RangeConstraint::Value (RangeConstraint - > mRID of the original StaticPropertyRange) |
| lowStepOperatingOnlin e | Operationa l minimum value of the tap changer | - | intege r | time series | SteadyStateInstruction-Profile RangeConstraint::Value (RangeConstraint - > mRID of the original StaticPropertyRange) |

<!-- page 115 -->

|  | (online data) |  |  |  |  |
| --- | --- | --- | --- | --- | --- |
| highStepRelativeOffline | Operationa l maximum value of the tap changer (offline data) | - | intege r | constant | RemedialAction-Profile RangeConstraint::normalValue RangeConstraint::direction.up RangeConstraint::valueKind.increme ntal |
| lowStepRelativeOffline | Operationa l minimum value of the tap changer (offline data) | - | intege r | constant | RemedialAction-Profile RangeConstraint::normalValue RangeConstraint::direction.down RangeConstraint::valueKind.increme ntal |
| highStepRelativeOnline | Operationa l maximum value of the tap changer (online data) | - | intege r | time series | SteadyStateInstruction-Profile RangeConstraint::Value (RangeConstraint - > mRID of the original StaticPropertyRange) |
| lowStepRelativeOnline | Operationa l minimum value of the tap changer (online data) | - | intege r | time series | SteadyStateInstruction-Profile RangeConstraint::Value (RangeConstraint - > mRID of the original StaticPropertyRange) |
| PSTTapingDiscrete | Control parameter to define if the PST |  | bool |  | constant RAO Control Parameter |

<!-- page 116 -->

|  | tapping is discrete (true) or continuous (false) |  |  |  |  |
| --- | --- | --- | --- | --- | --- |

Business Needs : BN781: RAO-RA_CRA_PST (RAO)

Acceptance Criteria :

Given

The RAO could reduce the loading on an overloaded XNE with a TATL duration of 10 minutes in a contingency situation with curative PST remedial actions which are linked to this contingency situation and have a reaction time of 1 minute, a tap change time of 2 min/tap and technical tap limits two taps above/below the initial tap positions.

When

the optimisation terminates successfully,

then

the determined curative PST tap changes in the contingency situation are a maximum of 2 tap changes per PST. Other constraints can have an influence on the result of the RAO.

##### SF3074: Group constraints for PST in curative mode

###### Scenario

BUC 14#147 PST in groups as CRA change the same delta tap position

A contingency situation triggers the activation of a curative remedial action. If this action is the tapping of PSTs in a PST group, the delta tap of all PSTs in the group must be the same.

BUC 14#50 Advanced handling of curative PST Groups during contingencies

The RAO must model PST groups for PST CRAs as decision variables to find the most efficient RAs including the consideration of advanced contingency cases with influence on the PST group Consideration of two attributes for handling of PST groups if one unit is not available:

• Reduced: the remaining PSTs of the group are used together as the PST group

• Blocked: the whole PST group is not used by the RAO as RA

###### Assumptions

Any group of CRA PSTs should also be available as a PRA PST group. This is not mandatory.

<!-- page 117 -->

As the final tap position of any PRA PST group is the same, as well as the delta tap of a CRA PST group, the overall final tap position of the PSTs within the group will be the same.

###### Description

CRAs can also be defined for PST groups within the input data. The definition of PST groups in curative mode is the same as described in CORNET-4619 : PRA - Group constraints for PST.

For CRAs there is no constraint ensuring that the tap position of each PST is the same after optimisation. Instead, other constraints are defined which ensure that the delta tap of all PSTs within the group will be the same after RAO. To achieve this, an additional constraint is added to the optimisation problem (MILP) for each step (each TATL duration ($d$) within a considered CO case, see CORNET-1985) to ensure the same curative tap change $\Delta r_{\tau}^{\mathit{cur},d} (t)$ of each curative PST ($\tau$) in the group at timestep t .

$\Delta r_{\tau}^{\mathit{cur},d} (t) = \cdots = \Delta r_{\tau_{n}}^{\mathit{cur},d} (t)$ for all PSTs of the PST group (n = number of PST in group) and where $\Delta r_{\tau}^{\mathit{cur},d} (t) = \Delta r_{\tau}^{\mathit{cur},d,+} (t) -\Delta r_{\tau}^{\mathit{cur},d,-} (t)$

As described in CORNET-1985: Limitations of PST in curative mode, for each PST in curative mode the maximum possible taps in upwards and downwards direction for each step depending on the TATL duration are calculated. Since an equal delta tap can only be achieved, if all PSTs can be tapped in the same direction, the whole group is excluded from the optimisation when no common rectified delta tap is available for all PSTs belonging to that group.

If one or more PSTs of a PST group are part of a contingency situation as the outage element, these PSTs cannot be considered as a curative remedial action in that contingency. The RAO detects the PST which is part of the contingency. For the remaining PSTs of the group, the following two options are possible for operation ( PSTGroupKind ):

- reducedGroup: the first option is that all remaining PSTs of that group are operated in group mode, as described above. The remaining PSTs of that group must have the same curative delta tap at the end of the optimisation. PSTs of that group which are part of the outage elements will not be considered in the optimisation.

- blockedGroup: the second option is that the whole PST group is unavailable as a remedial action if one or more PSTs of that group are not available as curative remedial action. The remaining PSTs are also not available as individual remedial actions within the RAO.

###### Configuration

The following input data is needed for the RAO:

<!-- page 118 -->

| Name | Description | Unit | Data Type |  | Time | Profile |
| --- | --- | --- | --- | --- | --- | --- |
|  |  |  |  |  | Series/ |  |
|  |  |  |  |  | Constant |  |
| PSTGroupKind | Definition of the PST group when one or more PSTs of the group are not available Default: blocked | - | enum: - reduced - blocked | constant |  | RAOControlPa rameterProfile: RAOControlPa rameterSet -> RAOControlPa rameterSetFor TSO.PSTGrou pKind |

• PSTs needs to be defined as specified in CORNET-18 : Consideration of PST

• PST-Group: Two or more objects of a GridStateAlteration needs to be linked to the same GridStateAlterationRemedialAction to form a PST group.

The attribute PSTGroupKind and the corresponding enumeration is currently not available in CoMo data model. Therefore, the PSTGroupKind is defined per TSO as a RAO control parameter and applied to all PST groups for that TSO.

###### Business Rules

It is assumed that PST are members of only one group and cannot be part of more PST groups with different PSTGroupKind

In curative mode PSTs can only be tapped within a limited timeframe. As it cannot be ensured that all PSTs reach the same tap position during this limited timeframe, the following rules apply:

• The delta tap of CRA PSTs in the same group has to be the same after RAO

• If it is not possible for all PSTs in a group to be tapped in the same direction, the whole group is excluded from the optimization

The following example illustrates this:

|  |  | PST lowStep highStep |  |
| --- | --- | --- | --- |
| PST 1 -11 |  |  | -9 |
| PST 2 -6 |  |  | -1 |
| PST 3 3 |  |  | 7 |

<!-- page 119 -->

PST 1 and PST 2 could be optimized in one group, as both can be tapped in negative direction. This will result in a common delta tap change of either -1 or -2.

PST 2 and PST 3 could also be optimized as a group with a delta tap change of either 1 or 2. However, PST 1 can only be tapped in negative direction, whereas PST 3 can only be tapped in positive direction. Therefore, the optimization cannot find a common rectified delta tap. The whole group must be excluded from the optimization.

Tap

Position -10 -8 -6 -4 -2 0 2 4 6 8

Tap before Tap before Tap before

opt. (PST 1) opt. (PST 2) opt. (PST 3)

PST 1 PST 2 PST 3

Figure: Possible delta taps in CRA-PST groups

###### Triggers

The RAO started successfully and all pre-conditions are met.

###### Pre-Condition

All relevant input data is delivered, see Configuration and BUC 14#110 Consideration of PST as curative remedial actions.

At least one correctly defined assessed element is part of the AE-FlatList.

The initial loadflow converged.

###### Acceptance Criteria

Given

<!-- page 120 -->

A PST of a CRA PST group is not available because the equipment is the contingency element. The PST group is defined as a reducedGroup.

When

The RAO successfully terminates,

Then

The remaining PST of that PST group could be used as a group to handle congestion. The remaining available PST of the group must have the same delta tap at the end of the RAO if used.

Given

A PST of a CRA PST group is not available because the equipment is the contingency element. The PST group is defined as a blockedGroup.

When

The RAO successfully terminates,

Then

The remaining PST of that PST group are not available as a remedial action and are not used to handle congestion.

###### Basic Flow

The following log-messages are exposed:

• The tap change of the PST group must be added to the RAO result log files.

###### Alternative Flow

No alternative flow foreseen.

##### CORNET-1982: Considered costs for PST in curative mode

###### Description

In R24Q1 the curative PST tap changes are considered via penalty costs from the input data within the objective function of the RAO (see CORNET-1765: Objective function). These RA transformer specific penalty costs $c_{\tau}^{\mathit{cur}}$ are calculated from the penalty cost factor of the input data $\mathit{cf}_{\tau ,\mathit{penalty}}^{\mathit{cur}}$

(RAPenaltyFactor) and the curative penalty reference value for PST of the RAO $c_{T,\mathit{reference}}^{\mathit{cur}}$. The RA specific penalty costs must be multiplied with the number of determined tap changes of the RA in the objective function.

$$
c_{\tau}^{\mathit{cur}} = \mathit{cf}_{\tau ,\mathit{penalty}}^{\mathit{cur}} \cdot c_{T,\mathit{reference}}^{\mathit{cur}} \tag{3.55}
$$

The RA specific penalty costs are also used to define a ranking of the different CRA options within the objective function, e.g. if the sensitivities of two RA are the same, the cheaper RA is being activated first (depending on other active constraints).

<!-- page 121 -->

Additional costs for PST in curative mode are not considered in this release.

###### Configuration

| Name | Description | Unit | Data Type |  | Time |  | Profile |
| --- | --- | --- | --- | --- | --- | --- | --- |
|  |  |  |  |  | Series/ |  |  |
|  |  |  |  |  | Constant |  |  |
| RAPenaltyFacto r | Penalty cost factor of the CRA for each tap change of a PST. Must be multiplied with the curative penalty reference value of the RAO. |  | float | constant |  |  | RemedialAaction-Profile RemedialAction::penalty Factor |
| PenaltyReferen cePSTcur | Curative penalty reference value for PST for each tap change | €/Ta p | float | constant |  |  | RAO-Setting |

Business Needs : BN781: RAO-RA_CRA_PST (RAO)

<!-- page 122 -->

#### 3.6.5 Consideration of Generation Units in RAO

##### CORNET-35: Consideration of generation units

###### Description

Generation units are used to model generating plants (technical resource generating electrical energy) in the CGM. Their active power infeed is modelled in the CGMES grid model.

Adjustments to the active power operating points of generation units are considered by the RAO within the limits of their technical availabilities. Generation units represent units that can feed active power into the grid. This includes conventional power plants as well as units for the generation of electricity from renewable energy sources. The active power feed-in can be positive (power feed-in by the generation unit) or negative (power drawn by the generation unit).

• Consideration of available RD volumes (see CORNET-41 )

• Consideration of technical power limits (see CORNET-36 and CORNET-37 )

• Consideration of unit commitment constraints (see CORNET-39 , CORNET-43 and CORNET- 44 )

• Consideration of power gradient constraints (see CORNET-45 and CORNET-46 )

• Consideration of lead and lag time (see CORNET-72 , CORNET-47 , CORNET-48 , CORNET- 49 , CORNET-50 , CORNET-69 and CORNET-70 )

System Requirement: SRQ840

##### CORNET-41: Consideration of available RD volume

###### Description

Note: In R1.1 only one CSA entry (available RD volume of XRAs) mapped to a generation unit can be considered in the RAO process. In future releases bids and more than one available RD volume per generation unit will be considered in the optimisation process.

Use case: The user wants the RAO to comply with the available RD volume of a power plant. The RAO considers available RD volume for the active power feed-in of generation units. The modelling of the available RD volume of a generating unit is done with the help of adjustable active power ranges (PRange). An available RD volume is the power by which a generating unit may change its power feed- in.

For each generating unit

• a positive PRange RD+ is considered. This means that an increase of active power feed-in by max. RD+ is possible.

<!-- page 123 -->

• a negative PRange RD- is considered. This means that a decrease of active power feed-in by max. RD- is possible.

The change in active power feed-in is possible, unless further technical limitations of the generating units (see CORNET-36 - Upper active power limits for generation units) oppose the change in active power feed- in. PRanges therefore do not define the absolute limit of the active power feed-in, but always the permissible change starting from the current value of the power feed-in PROD (value before RAO).

###### Configuration

Data requirement: modelling the available RD volume of a generation unit

| Name | Description | Unit | Data Type | Time Series/ Constant | Data Object | CoMo-Object | Profile |
| --- | --- | --- | --- | --- | --- | --- | --- |
| max RD+ | Maximal size of the upward (increase generation, decrease load) offer in MW which can be activated | MW float |  | time series | generating unit | "PowerBidSchedule. direction = ""up"" PowerBidSchedule TimePoint.atTime = ""DD.MM.YYYY HH:30"" PowerBidSchedule TimePoint.p = XX [MW]" | SecuritySchedule Profile (SS-P) |
| max RD- | Maximal size of the downward (decrease generation, increase load) offer in MW which can be activated | MW float |  | time series | generating unit | "PowerBidSchedule. direction = ""down"" PowerBidSchedule TimePoint.atTime = ""DD.MM.YYYY HH:30"" PowerBidSchedule TimePoint.p = XX [MW]" | SecuritySchedule Profile (SS-P) |
| PROD | Scheduled value (production) of the active | MW float |  | time series | generating unit | GeneratingUnit. initialP | EQ-Profile |

<!-- page 124 -->

|  | power feed-in of a generation unit |  |  |  |  |  |  |
| --- | --- | --- | --- | --- | --- | --- | --- |

There is no relaxation of the constraint to meet max. RD+/-, so that in the optimization result a generating unit can feed-in only within the given PRange.

Note : Two conditions must be fulfilled for a generating unit to participate in the RAO: Firstly, the optimise flag (see CORNET-17 - Participation of Controllable Units in Optimization) must be set to Yes. Secondly, at least one available RD volume with max. RD not equal to zero must be defined and a RD volume needs to be available. The "optimise" flag is set as part of the common grid model adaptation on the basis of CGMES and CSA profiles. The attribute “Availability” for generation units is a time series for each hour of the day. In Release 1.1 the first time stamp of this time series is evaluated and the value is used for the whole optimisation timeframe. Later versions will evaluate the whole time series and consider each value in the corresponding time stamp.

###### Details / Background

Example : A qualitative example is used to explain PRange and the resulting available RD volume for a generating unit. The following figure shows (part a) the definition of PRange max. RD+ and max. RD- as timeseries. This results in the absolute power limits shown in the figure part b. The orange line indicates the scheduled value of the active power feed-in (PROD) before optimisation. A complete utilisation of the

max. RD+ results in the violet line of the active power feed-in. A reduction of the active power feed-in can be achieved by utilising max. RD-. At maximum the active power feed-in shown as the yellow line can be provided by the generating unit.

<!-- page 125 -->

> **Figure (page 125) — described in text.**
>
> Two stacked time-series charts.
>
> **a) Adjustable Active Power Ranges (PRange)** — *Change in Active Power* against *Time*. A purple band above the zero axis is bounded by *max. RD+* and a yellow band below by *−max. RD−*; both bands vary from timestamp to timestamp, with a purple peak and a deeper yellow trough in the middle of the period.
> **b) RD Potential of a Generating Unit** — *Active Power* against *Time*, with three curves: orange *PROD before Optimisation* (with round markers at the RAO timestamps), purple *PROD before Optimisation + max. RD−* above it, and yellow *PROD before Optimisation − max. RD−* below it. The yellow line marks the lowest feed-in the unit can be driven to.

System Requirement:

##### CORNET-36: Upper active power limits for generation units

###### Description

Use Case : The RAO user expects that limits for the maximum active power feed-in of a generating unit are taken into account by the RAO.

Upper active power limit P describes the technically maximum possible power feed-in for a Max generating unit. The active power feed-in of a generating unit can be increased maximum up to P Max within the RAO, independent of the available RD volume of XRAs which is defined by PRanges (see CORNET-41 - Consideration of available RD volumes). This is achieved by a constraint in the optimisation problem.

There is no relaxation of the constraint to meet P Max , so that in the optimisation result a generating unit can feed-in active power with maximum up to P . Max

###### Configuration

Data requirement: available RD volume of a generation unit

<!-- page 126 -->

| Name | Description | Unit | Data Type | Time Series/ Constant | Data Object | CGMES- Object | Profile |
| --- | --- | --- | --- | --- | --- | --- | --- |
| ratedGrossMaxP (P Max ) | Available power (production) as the technical limit of the generating unit | MW float |  | time series | generating unit | Cim: GeneratingUnit | Equipment Profile |

###### Details / Background

Example : In the following figure, PRanges are shown defining the maximum admissible positive and negative change in active power feed-in. However, the available RD volume of XRAs is limited additionally by the technical active power limits of the generation unit. Areas in which the PRanges cannot be used completely because the technical active power limits are exceeded are shaded in red. For the sake of completeness, areas that cannot be approached due to the parameterisation of the PRanges are shaded grey. The technical upper active power limit is shown in blue dashed lines in this example.

> **Figure (page 126) — described in text.**
>
> Two stacked charts illustrating RRanges against the upper technical limit.
>
> **a) RRanges** — green band above the axis up to *max. RD+*, yellow band below down to *−max. RD−*, the yellow band dipping deeper in the middle of the period.
> **b) RD-Potential of a Generating Unit** — orange *PROD before Optimisation* flat with markers; green *PROD before Optimisation + max. RD+* above it; yellow *PROD before Optimisation − max. RD−* below it; a dashed light-blue *Pmax* line that steps down partway through the period. Where Pmax lies above the green line the gap is hatched grey (*Unused area of change in active power*); after Pmax steps below the green line the gap is hatched red (*Prohibited Area for change in active power*).

<!-- page 127 -->

Use Case : The technical limit P max of a power plant is modelled as a hard constraint. In order to avoid an unsolvable optimisation problem if this limit is violated before optimisation, this limit is expanded in this case.

If the scheduled value of the power feed-in (PROD) before optimisation is greater than P Max when using the RAO computation component, a warning and logging will take place.

In this case, if PROD before optimisation is greater than P Max , P Max is increased to PROD. This adjustment of P Max is made exclusively within the RAO computation and the data model is not updated. P Max is only adjusted for the time stamps in which the limit violation exists before optimisation. System Requirement: SRQ840

##### CORNET-37: Lower active power limits for generation units

###### Description

Use Case : The RAO user expects that limits for the minimum active power feed-in of a generating unit are taken into account by the RAO.

Lower active power limit P Min describes the technically minimum possible active power feed-in in stable operation of a generating unit. The active power feed-in of a generation unit can be reduced to a minimum of P Min within the scope of the RAO, if enough available RD volume of XRAs is defined (see CORNET-41 - Consideration of available RD volumes). This is achieved by a constraint in the optimisation problem.

There is no relaxation of the constraint to meet P , so that in the optimisation result a generating unit Min feeds-in active power greater than or equal to P Min . Exceptions arise with regard to the shutdown capability of generation units (see below) and the startup and shutdown process of generation units (see CORNET-47 – Definition of start-up and CORNET-48 – Definition of shut-down).

Note : The value of P Min can be less than 0.

Note : According to CORNET-38 Consideration of Unit-Commitment Constraints, P min influences the consideration of unit-commitment constraints of a generation unit in the optimisation (see CORNET-47 – Definition of start-up and CORNET-48 – Definition of shut-down).

###### Configuration

Data requirement: available RD volume of a generation unit

| Name | Description | Unit | Data Type | Time Series/ Constant |  | Data Object | CGMES- Objekt | Profile |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |

<!-- page 128 -->

| ratedGrossMinP (P Min ) | Minimum power (production) as technical limit of the generating unit |  | MW float | time series | generating unit | cim: GeneratingUnit | Equipment Profile |
| --- | --- | --- | --- | --- | --- | --- | --- |

###### Details / Background

Example : In the following figure, PRanges are shown defining the maximum admissible positive and negative change in active power feed-in of a generating unit. However, the available RD volume is limited by the minimum technical active power limits of the generating unit. Areas in which the technical active power limits the available RD volume are shown shaded in red. The lower active power limit is shown dashed in purple in this example.

> **Figure (page 128) — described in text.**
>
> Same two-panel layout as page 126 but for the **lower** limit.
>
> **a) PRanges** — green band to *max. RD+* above the axis, yellow band to *−max. RD−* below, dipping in the middle.
> **b) RD-Potential of a generation unit** — orange *PROD before Optimisation*, green *PROD before Optimisation + max. RD+*, yellow *PROD before Optimisation − max. RD−*, and a dashed purple *Pmin* line. Where the yellow line dips below Pmin the enclosed area is hatched red — the *Prohibited Area for change in active power*.

Use Case : The user expects that a generating unit can be switched off by the RAO. This applies to generating units that have a P > 0 or P < 0. The range between P and 0 MW does not represent Min Min Min a stable operating state of a generating unit.

In the event that P Min of a generation unit is greater or smaller than 0 and a value for the shut-down costs is available, the shutdown capability of these generation units is taken into account as described below:

<!-- page 129 -->

The shutdown capability of a generation unit is modelled with the help of binary state variables. In order for a generation unit to actually be shut down within the framework of the RAO, PROD minus max. RD- before optimisation must contain the value 0 MW. This means that max. RD- has to be sized in a way to reach "0" from PROD. A generation unit that can be switched-off can feed in active power with |PROD| >= |P | or PROD = 0 MW in the optimisation result, with the exception of start-up and shut- Min down processes (see CORNET-47 – Definition of start-up and CORNET-48 – Definition of shut-down). This is achieved by constraints in the optimisation problem.

Note : In contrast, a generating unit that cannot be shut-down is characterised by the fact that either an active power feed-in of 0 MW is not part of the available RD volume described by PROD and max. RD- , no shut-down cost value is given or P Min = 0 MW for all considered timestamps. The latter means that the generation unit can feed in any value between P and P including 0 MW. Min Max

Example : In the following figure, the available RD volume max. RD- allows a change in active power down to the value of 0 MW from PROD before optimisation. P Min is always greater than 0 MW in the figure. The generation unit may therefore be switched off by the RAO in the time range with a grey background.

> **Figure (page 129) — described in text.**
>
> Two panels showing when a unit may be switched off.
>
> **a)** *Change in Active Power* with the green *max. RD+* band above and the yellow *−max. RD−* band below; the yellow band widens sharply over the middle timestamps. A grey vertical column spanning those timestamps is bracketed *shutdown possible* and labelled *PRange*.
> **b) RD-Potential of a generation unit** — orange *PROD before Optimisation*, green *PROD + max. RD+*, dashed purple *PMin*, and yellow *PROD − max. RD−* which drops to zero inside the grey column. The two sloping transitions where the yellow line runs between PMin and zero are stippled grey and labelled *Area for startup and shutdown process*. Because the yellow line reaches 0 MW while PMin stays above 0, the unit may be switched off in the grey time range.

Conversely, in order to switch on a generation unit that is out of operation (PROD = 0 MW before optimisation), P Min must be in the range defined by the available RD volume.

<!-- page 130 -->

Note : The prerequisite for a possible switching on or off of a generation unit is that the startup and shutdown process can take place within the PRange described by the available RD volume. The relevant constraints for startup and shutdown operations are described in (see CORNET-47 – Definition of start-up and CORNET-48 – Definition of shut-down).

Use Case: The user wants the optimisation problem to be formulated as robustly as possible in the RAO. If unit commitment constraints (e.g. consideration of minimum up and downtimes, see CORNET- 39 – Limits of minimum up and down times of the generation unit) are desired, P Min of a generating unit must be greater or smaller than 0 MW for all timestamps. If this is not given in the input data before optimisation, this input data is suitably corrected for the optimisation in order to guarantee a stable optimisation calculation.

The minimum permissible active power feed-in P of a generation unit must either be greater or Min smaller than 0 MW for all considered timestamps or equal to 0 MW for all considered timestamps. If P Min of a generation unit is greater than zero for at least one but not for all considered timestamps, a warning is issued and logged. Furthermore, in this case P Min is set to 0 MW for all considered timestamps in which P Min is greater than 0 MW. The same applies for P Min smaller than 0 MW. This adjustment of P Min is made exclusively within the RAO computation and the data model is not updated. Use Case : The technical limit P of a power plant is modelled as a hard constraint. In order to avoid Min an unsolvable optimisation problem if this limit is violated before optimisation, this limit is expanded in this case.

If |PROD| is smaller than |P Min | for a generation unit for a considered timestamp before optimisation, it is first checked whether this considered timestamp is part of a startup and shutdown phase (see CORNET-47 – Definition of start-up and CORNET-48 – Definition of shut-down).

Note : Startups and shutdowns are only taken into account if P > 0 MW or P < 0 MW. Min Min

If this is not the case, P Min is set to PROD. This adjustment of P Min is made exclusively within the RAO computation and the data model is not updated. P Min is only adjusted for the timestamps in which the limit violation exists before optimisation. There is a warning and logging.

System Requirement: SRQ840

##### CORNET-4593: Limits of minimum up and down times of the Generating Unit

###### Description

The RAO considers minimum up and down times for each generating unit. The minimum up and down times are constant over all time stamps of the entire optimisation period.

<!-- page 131 -->

The consideration of minimum up and down times within the RAO is described in CORNET-4595 - Minimum down times of Generating Units.

###### Configuration

Data requirements of minimum up and down times for generating units:

| Name | Description | Unit | Data Type | Time Series/ Constant | Profile |
| --- | --- | --- | --- | --- | --- |
| min down time [h] | The minimum down time of a generation unit | Duration [h] |  | integer Constant | ER-Profile: GeneratingUnit.minimumOffTime |
| min up time [h] | The minimum running time of a generation unit | Duration [h] |  | integer Constant | ER-Profile: GeneratingUnit.minimumUpTime |

Both attributes are not mandatory in the NC-profiles and the minimumUpTime attribute is introduced with the NC-profiles 2.3. Because the attribute can only be used with an update of the CoMo, a default value of zero for the min up time is used within the RAO data model. The same applies for the min down time, if no value is available a default value of zero is used.

Business Needs :

BNXXX: RAO-XX:

Use-Cases :

UC495: BUC 14#45 Consideration of minimum up times from Generating Units

UC496: BUC 14#46 Consideration of minimum down times from Generating Units

Acceptance Criteria :

Given

A generating unit has a min down time greater than zero.

When

The RAO successfully terminates,

Then

An available down time of this generating unit must be equal to or greater than the min down time.

<!-- page 132 -->

Given

A generating unit has a min up time greater than zero.

When

The RAO successfully terminates,

Then

An available up time of this generating unit must be equal to or greater than the min up time.

##### CORNET-43: Last change of state of a generation unit (in operation / out of operation)

###### Description

In Release 1.1 the last change of state of a generation unit before the current RAO optimisation timeframe is not considered.

###### Details / Background

Example : A RAO run starts with the time stamp 00:30. If a generation unit was shut down at 23:35 of the previous day and has a minimum downtime of 8 hours, it could only be switched on again by the RAO at 08:30. The information of this last state change hast to be taken from the previous day. System Requirement: TBD

##### CORNET-4595: Minimum up and down times of Generating Units

###### Description

Use case: The user wants the RAO to comply with minimum up and down times of generating units. In the RAO, the minimum up and minimum down times are considered as constraints in the optimisation. This ensures that they are always met.

The constraints for taking minimum up and minimum down times into account are formulated in the optimisation problem as hard (non-relaxed) constraints.

Constraints for compliance with the minimum up and down times of a generating unit are only applied if P Min of this generating unit is greater than zero (see CORNET-38 - Consideration of unit-commitment constraints).

Use Case: Power plant schedules are usually available in 15-minute intervals. The RAO optimises a time grid of 60 minutes on the basis of the available CGMs. The consideration of minimum up and down times must therefore be carried out in the 60-minute time grid of the RAO.

<!-- page 133 -->

Constraints for compliance with the minimum up and down times of generating units are modelled in the RAO in the 60 min time grid for considered time stamps. For this purpose, constraints in the optimisation problem ensure,

• that the number of consecutive time stamps in which a generation unit is in the down state (see definition below) is greater than or equal to the minimum down time and

• that the number of consecutive time stamps in which a generation unit is in the operating state (see definition below) is greater than or equal to the minimum up time

###### Details / Background

Example : If a minimum up time of 59 min is specified for a generation unit, the RAO shall ensure via constraints that this generation unit is in operation for at least two consecutive optimisation time stamps As seen in the figure below, the up time starts in hour “12:30”. Because of the hourly time grid, it is not known when exactly the generation unit is going into operation within the 60 minutes. It is sometime between 12:00 and 13:00. To always ensure the fulfilment of the minimum up time technical constraint, two consecutive time stamps are needed.

> **Figure (page 133) — described in text.**
>
> Time axis marked with RAO time stamps at 11:30, 12:30, 13:30 and 14:30 (vertical blue bars, with ellipses either side indicating the series continues). A blue block labelled **59 min** is drawn between 12:30 and 13:30, showing that a 59-minute minimum up time fits inside a single one-hour interval — whereas a 60-minute requirement would need two consecutive time stamps.

Example : If a minimum up time of 60 min is specified for a generation unit, the RAO shall ensure via constraints that this generation unit is in operation for at least two consecutive optimisation time stamps Example : If a minimum up time of 61 min is specified for a generation unit, the RAO shall ensure via constraints that this generation unit is in operation for at least three consecutive optimisation time stamps. At least three consecutive optimisation time stamps are needed because the unit could go into operation in a “worst case” scenario at 12:59 and therefore has to be in operation until 14:00. The unit is a minimum in operation at the optimisation time stamps “12:30”, “13:30” and “14:30”. Because of the hourly time grid, it is not known when exactly the generation unit is going into operation within the 60 minutes. To always ensure the fulfilment of the minimum up time technical constraint, three consecutive time stamps are needed.

Example : If a minimum up time of a generation unit of 0 min is specified, no constraints for compliance with the minimum up time of this generation unit shall be taken into account.

An analogous procedure applies to the consideration of minimum down times.

<!-- page 134 -->

Example : If a minimum down time of a generation unit of 59 min is specified, the RAO shall ensure via constraints that this generation unit is in the down state for at least two consecutive optimisation time stamps.

Use Case: The user wants redispatch to be calculated only to resolve congestion. If there are violations of the minimum down time of a generating unit before the RAO, the RAO should not calculate redispatch only to resolve these violations.

If the limit for the minimum down times of a generating unit is violated by the schedule before optimisation, a warning and a logging are issued. Furthermore, the minimum down time is adjusted so that the schedule before optimisation is valid. The procedure for this is as follows:

• Adjustment of minimum down time: In the event that the minimum number x of consecutive optimisation time stamps in which a generation unit is down before optimisation is less than the minimum down time (rounded up to a full 60 min), the minimum down time is reduced to x. The minimum down time is a constant, so this effects the entire optimisation period.

• Adjustment of minimum up time: In the event that the minimum number x of consecutive optimisation time stamps in which a generation unit is in operation before optimisation is less than the minimum up time (rounded up to a full 60 min), the minimum up time is reduced to x. The minimum up time is a constant, so this effects the entire optimisation period.

This adjustment of the minimum up and down time is only made within the optimisation.

As shown in the following figures, the status of a generation unit is considered in operation as soon as PROD > 0 for an optimisation time stamp. Otherwise, it is in down state.

> **Figure (page 134) — described in text.**
>
> *Active power* against *Time* over five RAO time stamps. An orange *PROD* line rises linearly from zero at the first stamp, crossing the blue *P_Min* line (which wobbles slightly around a constant level) at the fourth stamp and continuing above it. A bracket over stamps 1–4 is labelled *Generation unit start-up*. A row of status boxes beneath the axis reads **Down** (yellow) for the first stamp, then **Operation** (green) for the remaining four.

Figure: Change of state of a generation unit (down -> operation)

<!-- page 135 -->

> **Figure (page 135) — described in text.**
>
> Mirror image of the previous figure. The orange *PROD* line falls linearly from an initial level, crossing the blue *P_Min* line at the second stamp and reaching zero at the fifth. A bracket over stamps 2–5 is labelled *Generation unit shut-down*. The status boxes read **Operation** (green) for the first four stamps and **Down** (yellow) for the last.

Figure: Change of state of a generation unit (operation -> down)

Note : In the RAO, state changes of generating units (operation → down or down → operation) take place within the 60 min time grid of the optimisation time stamps. The unit could reach for example the down status within any minute of the time stamp. The state is always valid for the whole time stamp. In the $\mathit{first} \mathit{figure} \mathit{the} \mathit{down} \mathit{state} \mathit{changes} \mathit{to} \mathit{the} \mathit{operation} \mathit{state} \mathit{with} \mathit{the} \mathit{first} \mathit{time} \mathit{stamp} \mathit{where} \mathit{PROD} \neq 0. \mathit{In}$ the second figure the operation state changes to the down state for the first time stamp in which PROD reaches zero.

###### Outlook

The consideration of time-coupling constraints at the end of the optimisation timeframe is not yet defined. In order to fulfil the minimum down time of a generation unit it could be defined that units cannot be shut down at the end of the optimisation timeframe to ensure availability at the beginning of the next day. It could also be defined that a start-up at the end of the optimisation timeframe is not allowed.

Use-Cases :

UC495: BUC 14#45 Consideration of minimum up times from Generating Units

UC496: BUC 14#46 Consideration of minimum down times from Generating Units

Acceptance Criteria :

Given

<!-- page 136 -->

A generating unit has a min down time greater than zero.

When

The RAO successfully terminates,

Then

An available down time of this generating unit must be equal to or greater than the min down time. Given

A generating unit has a min up time greater than zero.

When

The RAO successfully terminates,

Then

An available up time of this generating unit must be equal to or greater than the min up time.

##### CORNET-45: Consideration of Power Gradient Constraint of Generating Units

###### Description

Use Case: When redispatch is done with generating units, the user wants the restrictions on maximum and minimum power gradients by the RAO to be taken into account.

When adjusting the active power feed-in of generating units, maximum rates of active power change must be taken into account in order to correctly represent the potential of the generating unit. Therefore, two maximum power gradient for power ramp-up and ramp-down are defined for each generating unit. The maximum power gradient (pos. or neg.) is parameterised as a time-invariant value for the entire optimisation period.

The RAO takes into account constraints that ensure that the maximum increase in the active power feed-in of a generating unit between two consecutive timestamps is less or equal than the maximum allowed pos. power gradient of this generating unit.

The RAO takes into account constraints that ensure that the maximum decrease in the active power feed- in of a generating unit between two consecutive timestamps is less or equal than the maximum allowed neg. power gradient of this generating unit.

The constraints on the technical limits on pos. power gradient and neg. power gradients of a generating unit are modelled as hard constraints (no relaxation).

###### Configuration

Data requirements on power gradients of generating units:

<!-- page 137 -->

| Name | Descriptio n | Unit | Data Type | Time | Data Object | CoMo Object | Profile |
| --- | --- | --- | --- | --- | --- | --- | --- |
|  |  |  |  | Series/ |  |  |  |
|  |  |  |  | Consta |  |  |  |
|  |  |  |  | nt |  |  |  |
| pos. powergradi ent [MW/h] | Maximum positive delta for power output of redispatchi ng unit that can be changed between two consecutiv e timestamp s | [MW/ h] | intege r; >= 0 | constan t | Generati ng Unit | GeneratingUnit.raiseRamp Rate | EQprofi le referrin g from the ER Profile |
| neg. powergradi ent [MW/h] | Maximum negative delta for power output of redispatchi ng unit that can be changed between two consecutiv e timestamp s | [MW/ h] | intege r; >= 0 | constan t | Generati ng Unit | GeneratingUnit.lowerRamp Rate | EQprofi le referrin g from the ER Profile |

<!-- page 138 -->

###### Details / Background

The model is explained using the following figure. The solid orange line describes the schedule (PROD) of a generating unit before optimisation. The active power feed-in of the generation unit is adjusted at time t 1 and t 3 . Although the active power feed-in does not coincide with the range limits of the permissible power adjustment (dashed light blue line), no positive redispatch can be performed from time t 1 to t 2 . Within this time range, the power adjustment before optimisation already corresponds to the maximum permissible value (dotted black line).

Negative power changes are taken into account in the same way, whereby the limit value for maximum positive and negative power changes can be specified separately.

> **Figure (page 138) — described in text.**
>
> *Example on max. pos. powergradient limitation of a generating unit* — *Active Power Feed in* against *time*, with marks at $t_1$, $t_2$ and $t_3$. The orange *PROD before RAO* curve is flat, steps up steeply between $t_1$ and $t_2$, is flat again, then ramps up more gently after $t_3$. A dashed light-blue *P_max* line jumps up at $t_1$ and stays high; a dashed purple *P_min* line runs flat along the bottom. Two black dotted lines show the *Max pos. powergradient*, each steeper than the orange curve it sits beside, with small red arrows indicating that the actual ramp is held back to this slope.

Note: Consideration on start-up and shut-down of generating units are considered in CORNET-47 and CORNET-48 .

Use Case : The technical limits on pos. power gradient and neg. power gradients of a generating unit is modelled as a hard constraint. In order to avoid an unsolvable optimisation problem if this limit is violated before optimisation, this limit is expanded in this case.

If the gradient of the active power feed-in of a generating unit before optimisation violates the defined limit value for the maximum permissible pos./neg. power gradient, the limit value is adjusted to the power gradient of the active power feed-in before optimisation of the respective time stamp. This is done for each affected time stamp. In the event of such a limit value adjustment, a warning and logging is issued. The limit value adjustment is only carried out for the optimisation.

The maximum power gradient (pos. or neg.) is parameterised as a time-invariant value for the entire optimisation period. However, the previously described adjustment of the maximum power gradient only takes place for the time stamps in which a limit value violation occurs. Thus, such an adjustment can result in a time-variant maximum power gradient.

System Requirement: SRQ840

<!-- page 139 -->

##### CORNET-46: Consideration of Power Gradients at the Beginning and End of the Optimisation Period

##### Optimisation Period

###### Description

The following applies with regard to the consideration of power gradients at the beginning and end of the optimisation period: No constraints shall be considered to account for power gradients (see CORNET-44 - Minimum up and down times of generation units) between the first time stamp of the optimisation period and the time before. Similarly, no constraints are considered to account for power gradients between the last timestamp of the optimisation period and the time after.

###### Details / Background

For release 1.2 data of the previous day will be supplied for analysis and corresponding conclusions for the power gradients at the beginning of the optimisation period will be derived.

System Requirement: SRQ352

##### CORNET-47: Input data and definition on start-up of generating units

###### Description

Assumption: In release 1.1 the start-up power gradient is equivalent to the positive power gradient. The input data on power a plant start-up is given by the start-up power gradient. Basically, the RAO considers this start-up power gradient during the start-up phase of a generating unit. The start-up phase is the time period between the last time stamp with an active power injection of 0 and the first time stamp with an power injection >= P (see CORNET-44 – Minimum up and down times of generation Min units). In this start-up phase the power injection increases with the constant power gradient (exceptions see CORNET-69 – Consideration of start-up process with start-up before optimisation).

The RAO operates with a time grid of one hour (see CORNET-85 – Considered time grid). To ensure consistency between this time grid and the start-up power gradient of generating units, the RAO considers internally the Start-up-Time. This the Start-up-Time of a generating units is calculated based on the start-up power gradient as described below:

$$
\mathit{Start}-\mathit{up}-\mathit{Time} = \mathit{roundup}( P_{\mathit{Min}} ⁄ ) \tag{3.56}
$$

$$
\mathit{Power} \mathit{gradient}_{\mathit{start} \mathit{up}}
$$

The rounding up takes place to full hours, so that there is a linear increase of the active power injection during the start-up phase.

<!-- page 140 -->

###### Configuration

Data requirement: start-up process of generating units

| Name | Descriptio n | Units | Data type | Time series/ constan t | Data object | CoMo-Object | Profile |
| --- | --- | --- | --- | --- | --- | --- | --- |
| start-up power gradien t [MW/h] | Gradient when going from PROD=0 to P Min | [MW/h ] | Integer ; >=0 | constan t | generatin g unit | GeneratingUnit.raiseRampRa te | EQprofil e referring from the ER profile |

The fixed start-up power gradient is derived from the pos. powergradient [MW/h] in R1.1.

###### Details / Background

Example : A generation unit has a P Min of 100 MW and a start-up power gradient of 75 MW/h. Dividing these two values results in a Start-up-Time of 1.5 h. In order to achieve a linear increase of the active power injection during the start-up phase, the result is round up and results in a final Start-up-Time of 2 h.

System Requirement:

##### CORNET-48: Input data and definition of shut-down

###### Description

The input data on power a plant shut-down is given by the shut-down power gradient. Basically, the RAO considers this shut-down power gradient during the shut-down phase of a generating unit. The shut-down phase is the time period between the last time stamp with an active power injection >= P min and the first time stamp with an power injection of 0 (see CORNET-44 – Minimum up and down times of generation units). In this shut-down phase the power injection decreases with the constant gradient (exceptions see CORNET-69 – Consideration of start-up process with start-up before optimisation). The RAO operates with a time grid of one hour (see CORNET-85 – Considered time grid). To ensure consistency between this time grid and the shut-down power gradient of generating units, the RAO

<!-- page 141 -->

considers internally the shut-down-Time. This Shut-down-Time of a generating unit is calculated based on the shut-down power gradient as described below:

$$
\mathit{Shut}-\mathit{down}-\mathit{Time} = \mathit{roundup}( P_{\mathit{Min}} ⁄ ) \tag{3.57}
$$

$$
\mathit{Power} \mathit{gradient}_{sh\mathit{ut} \mathit{down}}
$$

The rounding up takes place to full hours, so that there is a linear decrease of the active power injection during the shut-down phase.

###### Configuration

Input data on shut-down process of generating units:

| Name | Descriptio n | Units | Data type | Time series/ constan t | Data object | CoMo-Object | Profile |
| --- | --- | --- | --- | --- | --- | --- | --- |
| shut- down power gradien t [MW/h] | Gradient when going from P Min to 0 infeed | [MW/h ] | Integer ; >=0 | constan t | generatin g unit | GeneratingUnit.lowerRampRa te | EQprofil e referring from the ER profile |

The fixed shut-down power gradient is derived from the neg. powergradient [MW/h] in R1.1.

###### Details / Background

Example : A generation unit has a P Min of 100 MW and a shut-down power gradient of 75 MW/h. Dividing these two values results in a Shut-down-Time of 1.5 h. In order to achieve a linear decrease of the active power injection during the shut-down phase, the result is round up and results in a final Shut-down-Time of 2 h.

The following figure shows a schematic diagram for defining the Shut-down-Time.

<!-- page 142 -->

> **Figure (page 142) — described in text.**
>
> *Active power* against *Time* over five numbered time stamps. The orange *PROD* line falls steadily from the left, meeting the blue *P_Min* line at stamp 1 and reaching zero at stamp 4, then staying at zero. A grey band covers stamps 1 to 4 and is bracketed *Shut-down-Time*. Annotations: stamp 1 is *Last optimisation timestamp with PROD >= 0*; stamp 4 is *First optimisation timestamp with PROD = 0*.

Figure: Schematic figure for defining the shut-down process of a generation unit

System Requirement:

##### CORNET-49: Consideration of a start-up process without start-up before optimisation

###### Description

The RAO considers the start-up process of generation units in the optimisation as described below. These specifications apply to generation units that do not experience any start-up or shut-down within the optimisation timeframe process prior to optimisation (i.e. a generation unit is completely out of service for the entire optimisation timeframe or completely in service, the latter also being relevant as a generation unit can be shut-down and restarted by the optimisation).

Note : For generation units with a start-up before optimisation within the optimisation timeframe: CORNET-69 - Consideration of a start-up process with start-up before optimisation.

For the power feed-in of a generation unit constraints in the optimisation problem ensure that the generation unit starts with a start-up ramp during the start-up time (see CORNET-47 ).

This start-up ramp of a generating unit is defined below:

• The start-up ramp has the length Start-up-Time (see CORNET-47 ).

• The start-up ramp begins with an optimisation time

• The start-up ramp ends with an optimisation time

<!-- page 143 -->

• The power feed-in of the generation unit at the first optimisation time stamp of the start-up ramp is zero

• The power feed-in of the generation unit at the last optimisation time stamp of the start-up ramp is P Min (see CORNET-41 - Consideration of RD potentials) at this optimisation

• If the start-up process is less than or equal to 60 min, the start and end of the start-up time is given by two directly consecutive optimisation time stamps.

• If the start-up process is longer than one hour, there are optimisation time stamps within the start-up ramp (and not only at the beginning and end). For these optimisation timestamps, the power feed-in of the affected generating unit is supposed to increase linearly (see figure below). The following figure shows the principle of a start-up ramp.

> **Figure (page 143) — described in text.**
>
> The start-up counterpart. An orange *Active power change* line rises linearly from zero at stamp 1, meeting the blue *P_Min* line at stamp 4 and continuing above it to stamp 5. A grey band covers stamps 1 to 4, bracketed *Start-up-Time*. Annotations: stamp 1 is *Last optimisation timestamp with PROD = 0*; stamp 4 is *First optimisation timestamp with PROD >= P_Min*.

Figure: Schematic diagram of a start-up ramp for generation units without warm-up

Note : A generation unit start-up is only possible if the start-up power gradient allows a start-up process within the lead time (see CORNET-49 - Definition of start-up).

System Requirement:

##### CORNET-50: Consideration of shut-down process without shut-down before optimisation

##### optimisation

###### Description

The consideration of the shut-down process of a generation unit in the optimisation for generation units without shutdown before optimisation is analogous to CORNET-49 - Consideration of start-up process

<!-- page 144 -->

without start-up before optimisation. Analogous to the parameterizable start-up power gradient, the parameterizable shut-down power gradient is used here.

System Requirement:

##### CORNET-69: Consideration of start-up process with start-up before optimisation

###### Description

CORNET-49 - Consideration of a start-up process without start-up before optimisation applies to the starting of generation units with start-up within the optimisation timeframe before the optimisation, with the exception of the following changes.

The RAO hast to be parameterised in such a way that any change in control variables is driven exclusively by grid congestion. In other words, it should be avoided that the output of a generation unit is changed when there is no congestion. To ensure this, special treatment of ramp rates before optimisation is required. Explanation: According to CORNET-49 - Consideration of start-up process without start-up before optimisation, it would be ensured that a generation unit always starts with a linear ramp rate. If these constraints were to be applied in general, the optimisation would force non- linear ramp rates into a linear ramp rate before optimisation by redispatch. The following figure illustrates this undesired behaviour.

> **Figure (page 144) — described in text.**
>
> Two stacked panels over the same five time stamps, with a grey *Start-up-Time* band covering stamps 1–4.
>
> **Top — Active power:** the orange *PROD before optimisation* curve climbs in irregular steps and plateaus, while a straight green *Linear start-up ramp* runs from zero at stamp 1 to the same end point at stamp 5. The blue *P_Min* line runs across the middle.
> **Bottom — Redispatch:** a black line oscillating about zero, showing the redispatch that would be needed at each moment to force the real non-linear ramp onto the linear one — positive where the ramp lags, then sharply negative at stamp 4. This is the undesired behaviour the text warns about.

Figure: Redispatch demand to convert non-linear ramp rate into linear ramp rate

<!-- page 145 -->

To avoid this undesired behaviour, the P Min value of generation units is set to PROD for all optimisation time stamps within the start-up phase of the power plant.

System Requirement:

##### CORNET-70: Consideration of shut-down process with shut-down before optimisation

###### Description

The consideration of the shut-down process of a generation unit in the optimisation for generation units with shut-down before optimisation is analogous to CORNET-69 - Consideration of start-up process with start-up before optimisation.

System Requirement:

##### CORNET-4596: Input data on lead and lag times

###### Description

Use case: The user wants the RAO to comply with lead and lag times of generating units.

Lead and lag times are input data for each generation unit. These input data represent both technical and operational constraints of the power plants:

• The running lead time [h] specifies the lead time for changing the active power of a generating unit when in operation. The lead time describes the minimum duration between activation and power change of a generation unit in operation (minimum duration between RADP (see CORNET-89 ) and power change of a generation unit in operation).

• The cold/warm lead time (PowerPlant start up) [h] specifies the lead time for the start-up of a generation unit (minimum duration between RADP and reaching the operational state and P Min ), whereby this lead time can be defined differently for the states "warm" and "cold". A generation unit is in the state "cold" if it has operated for the duration cold status with PROD=0 according to the schedule. The state of a generation unit before optimisation is calculated once for the optimisation

• The lag time (shut down) [h] specifies the time for the shut-down of a generation unit (minimum duration between the RADP and the change of state from P Min to standstill (PROD=0)). Note :

<!-- page 146 -->

According to CORNET-4595 - Minimum up and down times of generation units, the shutdown starts earlier than the change of state from operation to shut-down by the shutdown time. If the running lead time of a generation unit is greater than the cold/warm lead time or the lag time , a warning is issued and logged. Furthermore, the running lead time is set to the minimum of the cold/warm lead time and lag time .

###### Configuration

Input data on lead and lag times of generating units:

| Name | Description | Units | Data type | Time series / Constant | Profile |
| --- | --- | --- | --- | --- | --- |
| running lead time [h] | Lead time for changing the active power of a generation plant in operation | Duration [h] | Integer; >= 0 | Constant | ER-Profile: GeneratingUnit.runningLeadTime |
| cold status [h] | Duration from the state with PROD=0, from which a power plant adopts the state "cold" | Duration [h] | Integer; >= 0 | Constant | ER-Profile: GeneratingUnit.coolDownTime |
| cold lead time (PowerPlant start up) [h] | Duration of the start-up of a generation unit until P Min with time to "warm up" | Duration [h] | Integer; >= 0 | Constant | EQ-Profile: GeneratingUnit.startupTime |
| warm lead time (PowerPlant start up) [h] | Duration of the start-up of a generation unit until P with Min | Duration [h] | Integer; >= 0 | Constant | ER-Profile: GeneratingUnit.warmStartupTime |

<!-- page 147 -->

|  | time to "warm up" |  |  |  |  |
| --- | --- | --- | --- | --- | --- |
| lag time (shut down) [h] | Duration until a generation unit reaches 0 infeed starting from P Min | Duration [h] | Integer; >= 0 | Constant | ER-Profile: GeneratingUnit.shutdownTime |

The runningLeadTime attribute is introduced with the NC-profiles 2.3 and is not mandatory. Because the attribute can only be used with an update of the CoMo, a default value of zero is used until then within the internal RAO model.

The startupTime attribute is only available with CGMES 3.0 and cannot be considered until the use of CGMES 3.0 within the CoMo.

###### Details / Background

Note : The consideration of the start-up time in the RAO is described in CORNET-49 - Consideration of a start-up process without start-up before optimisation and CORNET-69 - Consideration of a start- up process with start-up before optimisation.

The start-up process of a generation unit is only evaluated by the RAO if P Min >0.

The following figures illustrate the definition of the lead and start-up time of a generation unit.

> **Figure (page 147) — described in text.**
>
> *Active power* against *Time* over five time stamps, with a grey band covering stamps 1–5 bracketed *Lead time*. Two sub-brackets divide it: *Warm-up* from stamp 1 to 2, and *Start-up* from stamp 2 to 5. The orange *PROD before optimisation* line stays at zero through the warm-up phase, then rises linearly from stamp 2 to meet the blue *P_Min* line at stamp 5. Annotations: stamp 2 is *Last optimisation timestamp with PROD = 0*; stamp 5 is *First optimisation timestamp with PROD >= P_Min*. This is the 4 h lead time / 3 h start-up time example.

Figure: Schematic diagram for the definition of a 4 h lead time and a resulting 3 h start-up time for a linear start-up ramp

Use-Cases :

<!-- page 148 -->

UC497: BUC 14#47 Consideration of lead times for Generating Units

UC498: BUC 14#48 Consideration of lag time for Generating Units

Acceptance Criteria :

Given

A generating unit has a running lead time greater than zero. The RAART and therefore the RADP is set to 22:00.

When

The RAO successfully terminates,

Then

No RD volume must be used from this generating unit for time stamps before or equal to RADP + running lead time. If a running lead time, counted from the RADP, ends within in a time stamp, the use of RD volume is only possible from the beginning of the following time stamp.

##### CORNET-91: Consideration of lead times in RAO

###### Description

The lead times (see CORNET-72 ) of generating units are considered in the RAO as described below: • A change in the power feed-in of a generation unit in operating state or for which P Min <=0 (If P Min <=0 no unit commitment constraints are considered, see CORNET-37 ) applies, can only take place at a given optimisation time stamp if this optimisation time stamp minus the redispatch lead time is higher or equal than RADP. If the power change for a generation unit is not possible due to the lead times in the entire or parts (starting at the front) of the optimisation timeframe, the generation unit is excluded from the optimisation for the relevant optimisation time. For this purpose, corresponding non-relaxed constraints are considered in the optimisation problem.

• A change in the operating state of a generation unit from down state to operation state can only take place at a given optimisation time state if this optimisation time stamp minus the lead time (taking into account the "warm" or "cold" state) is smaller or equal than the optimisation For this purpose, corresponding hard constraints are added to the optimisation problem. If a start-up for a generation unit is not possible due to the lead time in the entire or parts (starting at the front) of the optimisation timeframe, the generation unit is excluded from the optimisation for the relevant optimisation time stamps, provided it is in down state.

• A change in the operating state of a generation unit from the state operation to down state can only take place at a given optimisation time stamp if this optimisation time stamp minus the lag time is smaller or equal than the optimisation time. If a shut-down is not possible for a generation

<!-- page 149 -->

unit due to the lag time of the entire optimisation timeframe or parts of it (starting at the front), the generation unit remains in operation for the relevant optimisation time stamps, provided it is in operation before. For this purpose, corresponding non-relaxed constraints are taken into account in the optimisation problem.

Note : Status changes operation/down of generation units are considered in the RAO in 60 min time frame for optimisation time stamps.

System Requirement:

##### CORNET-51: Penalty and marginal costs

This specification is no longer valid. The penalty and marginal costs are bid specific, see “CORNET- 4606: Considered costs of redispatch RA in preventive mode” and “CORNET-575: Considered costs of redispatch RA in curative mode”.

##### BUC 14#103 Consideration of generating unit start-up costs

###### Scenario

##### BUC 14#103 Consideration of generating unit start-up costs

The RAO must consider available start-up costs of a generating unit during the optimisation. Correction of the description from where the information is taken in the input data.

###### Description

The start-up costs of generation units ( startupCost ) are taken into account by including the costs in the objective function (see SF3077: Objective function) of the optimisation for each state transition from down state to operation (see CORNET-44 - Minimum up and down times of generation units). Start-up costs of generation units are only taken into account if the generation unit has a P Min >0. Note : Start-up costs are always applied to the exact optimisation time stamp at which the status transition from down state to operation takes place because of the design of the optimisation model. A binary variable ($B_{g,\mathit{ON}}$) for each time stamp ensures the correct consideration of the start-up costs by retaining the information of a transition per time stamp.

###### Configuration

The following input data is needed for the RAO:

| Name | Description Units |  | Data type | Time series/ constant | CoMo-Profile |
| --- | --- | --- | --- | --- | --- |

<!-- page 150 -->

| generatingUnitMrid | MRID of the generating unit | - | string | constant | ErExtensionDocument: GenExtensionErList.generatingUnitMrid |
| --- | --- | --- | --- | --- | --- |
| startupCost | Costs for the start of a generation unit | € | floating point; >=0 | constant | ErExtensionDocument: GenExtensionErList.warmStartupCost |

The start-up costs of a generating unit are defined in the GenExtensionErList as part of the ErExtensionDocument. The generatingUnitMrid is the MRID of the generating unit. The value from the attribute warmStartupCost is used by RAO for the start-up costs.

If no start-up cost is given within the attribute (explicit: no value is given), the RAO cannot determine a start-up of the generation unit. Additionally, if the generation unit is already in operation before RAO and there are no start-up costs given, the optimisation cannot determine a shut-down of the generation unit. Otherwise, the generating unit can’t be started again after the shut-down within the given optimisation timeframe.

Note : there is no difference made for start-up costs between a warm or cold status of the generation unit.

###### Business rules

Example : A generation unit is not in operation before optimisation. If this generation unit is put into operation by redispatch, then start-up costs are applied for each change of state. The following figure illustrates this:

<!-- page 151 -->

> **Figure (page 151) — described in text.**
>
> *Active power* against *Time* across a series of time stamps. The orange *PROD before optimisation* line is flat at zero for the whole period (the unit is down). The green *PROD after optimisation* line rises to a plateau, returns to zero, then rises to a second plateau and returns to zero again. Two black downward arrows, one above each rising edge, mark *Start-up costs* — costs are charged for each of the two start-ups.

Figure: Example of start-up costs for a generation unit that is in down state before optimisation Example : A generation unit is in operation before optimisation. If this generation unit is shut-down by redispatch, then start-up costs are applied for each new start-up within the optimisation. The following figure illustrates this:

> **Figure (page 151) — described in text.**
>
> Same axes. Here the orange *PROD before optimisation* line runs flat at an operating level for the whole period, while the green *PROD after optimisation* line drops to zero, stays there, and then ramps back up to the original level. A single black downward arrow marks *Start-up costs* at the point where it comes back up. The legend also lists a light-blue arrow for *avoided start-up costs*, unused here.

Figure: Example of start-up costs for a generation unit in operation before optimisation

Example : Given a generation unit that changes its state from operation to down and back to operation before optimisation within the optimisation timeframe. If in the meantime this generation plant remains fully in operation due to redispatch, start-up costs for the avoided restart are saved due to the redispatch. This results in a negative objective function contribution due to an avoided start-up. The following figure illustrates this:

<!-- page 152 -->

> **Figure (page 152) — described in text.**
>
> Same axes, the reverse situation. The orange *PROD before optimisation* line dips to zero and later ramps back up — a start-up that would have happened anyway — while the green *PROD after optimisation* line stays flat at the operating level throughout. A light-blue downward arrow marks *Avoided start-up costs*: because the optimisation keeps the unit running, the start-up never occurs and the objective function receives a negative contribution.

Figure: Example of redispatch avoided start-up costs

Note : The above example makes it clear that a cost saving is possible through redispatch in connection with start-up costs. This could lead to redispatch being calculated purely out of cost optimisation without justification by grid congestion. To prevent this, it is necessary to select the penalty costs for redispatch of generation plants (see CORNET-51 - Penalty and marginal costs for generation units) appropriately. Example : Given a generation unit that changes state from down state to operation before optimisation within the optimisation timeframe. If the start-up of this generation unit is brought forward by redispatch, no start-up costs are effective in the objective function, since start-up costs and avoided start-up costs balance each other out exactly. The following figure illustrates this:

> **Figure (page 152) — described in text.**
>
> Same axes, showing an early start-up. The green *PROD after optimisation* line ramps up from zero at the very beginning of the period and stays at the plateau; the orange *PROD before optimisation* line stays at zero until much later, then ramps up to the same plateau. A black arrow marks *Start-up costs* at the early (green) ramp and a light-blue arrow marks *Avoided start-up costs* at the later (orange) one — the two cancel exactly, so bringing the start-up forward is cost-neutral in the objective function.

Figure: Example of effective start-up costs for an early start-up of a generation unit due to redispatch

<!-- page 153 -->

###### Triggers

The RAO started successfully and all pre-conditions are met.

###### Pre-Condition

• All relevant input data is delivered, see Configuration.

• At least one correctly defined assessed element is part of the AE-FlatList.

• The initial loadflow converged.

###### Acceptance Criteria

Given

A generating unit has a value given for start-up costs and is shut down before RAO for the whole optimisation timeframe. The RAO determines the activation of a preventive redispatch Power Bid from this generating unit to be the most cost efficient solution considering also the startup costs.

When

The RAO successfully terminates,

Then

$\mathit{The} \mathit{generating} \mathit{unit} \mathit{must} \mathit{be} \mathit{running} \mathit{in} \mathit{the} \mathit{results} (\mathit{PROD} \geq P_{min}$) and the start-up costs available in the results for the time stamp of the start-up.

Given

A generating unit has no value given for start-up costs and is shut down before RAO for the whole optimisation timeframe.

When

The RAO successfully terminates,

Then

The generating unit must be still shut down in the results and no start-up costs available in the results.

###### Basic Flow

The following log-messages are exposed:

• The start-up of a generating unit are written to the RAO log

The start-up costs of a generating unit is exposed in the results, see BUC 14#137 Generating Unit Optimisation results.

###### Alternative Flow

The RAO logs negative startupCost of a generating unit and cancels itself.

<!-- page 154 -->

##### CORNET-71: Consideration of shut-down costs

###### Description

Shut-down costs for generation units are considered in the RAO in a later release version and not release 1.1

System Requirement:

<!-- page 155 -->

#### 3.6.6 Redispatch Remedial Actions

##### BUC 14#106: Consideration of redispatch RA in curative mode

###### Scenario

##### BUC 14#106: Consideration of redispatch RA in curative mode

Some redispatch RAs are defined as being available in curative mode. These curative RAs only need to be activated when the contingency occurs. The RAO must consider these redispatch CRA during the optimisation.

Optionally, links to contingency situations and a subset of XNEs can be considered. These restrict the use of the redispatch CRA further.

###### Assumptions

The link from a CRA to one or multiple contingencies is optional.

The link from one or multiple CRA to a XNE is optional.

###### Description

Generating units can also be used as curative remedial actions in the RAO. If a RA is defined as curative (RAactivationKind), it can be optionally linked to one or multiple contingencies in the input data. Additionally, a link from a XNE to one or more CRA is optionally possible in the input data. Therefore, the consideration of a CRA is possible for the following cases:

- CRA linked to COs: CRA can be used independently for the linked CO cases and for all XNEs - CRA linked to COs and to one or multiple XNEs: CRA can be used only for all combinations of the linked COs and XNEs

- CRA without links to COs and any XNE: CRA can be used for all COs and for all XNEs - CRA without link to COs and linked to one or multiple XNEs: CRA can be used for all COs, but only for the subset of XNEs linked to

Additionally, CRA will be considered in the optimisation according to CORNET-92 - Consideration of XNEs in MILP.

In RAO v1 only one TATL per assessed element is considered for the determination of curative RAs ( see CORNET-1792: Consideration of one TATL and CORNET-2586: Consideration of one TATL (RTE-specific)). For consideration of the curative RA for the assessed element, the curative RA must be linked to the current contingency and optionally to the XNE. Secondly, the reaction time of the curative RA must be compared to the temporary overloading time ( duration ) associated to the TATL of

<!-- page 156 -->

the assessed element (see CORNET-613 - Consideration of reaction time for redispatch RA in curative mode). The outcome of this comparison is the availability of the curative RA for the assessed element. When considered in the optimisation, the redispatch volume for the curative RA is limited by the given available redispatch volume in the PowerBidSchedule. The consideration of technical limits depends on the RA and TSO specific configuration (see CORNET-612 – Consideration of technical limits from redispatch RA in curative mode) and can further limit the available RD volume of the bid.

CRA Potential could be max

P limited by

Maximum technical ~ active power limit P max Minimum technical active power limit P P min min

Available curative RD volume

Prod CRA for different XNEC

Whereas in preventive mode the generating unit can be out of operation and the RAO can determine the start-up for redispatch use, this is not yet possible for curative RA. A start-up of a generating unit just for curative use is not possible. If the generating unit for the CRA is out of operation, the CRA cannot be applied in the optimisation.

If a generating unit is started because of a PRA, the CRA can also be applied.

To reduce the complexity of the optimisation problem, the RAO does not consider a minimum RD size for the curative offers as well as no RD step size in which the offer can be ordered.

The RAO does not consider linked offers (parent-child definition) of curative RA. If PowerBidSchedule of a curative RA are linked to each other via a PowerBidDependency , these offers are not considered. Only RD offers of a curative RA which are independent of each other are considered within the RAO. Note : CRA are only considered linearised within the Fast Outage Approximation of the RAO.

###### Outlook

A future release will also have the option to link the curative RA to a region, e.g. a TSO region or bidding zone. The RA can then only be applied to the elements within this region.

CRA will also be able to start-up a generating unit for curative use only.

###### Configuration

The following input data is needed for the RAO:

<!-- page 157 -->

| Name | Description | Unit | Data Type |  | Time | CoMo-Profile |
| --- | --- | --- | --- | --- | --- | --- |
|  |  |  |  |  | Series/ |  |
|  |  |  |  |  | Constant |  |
| RAactivationKind | Indication of RA if preventive or curative | - | string | constant |  | RemedialActio nFlatList: RemedialActio n.kind |
| linkedContingencie s | Contingency cases for which the RA can be activated (optional) | - | List of string constant |  |  | RemedialActio nFlatList: ContingencyWi thRemedialActi on.Contingenc yMrid |
| linkedElement | Assessed element for which the RA can be activated (optional) | - | List of string constant |  |  | RA-P: AssessedElem entFlatList: AssessedElem ent -> RemedialActio n.enabled = true RemedialActio n.ruleType = included |
| posAvailableCurRD Volume | Available curative RD volume of the upward (increase generation, decrease load) offer in MW which can be activated | MW | float | time series |  | RemedialActio nFlatlist: PowerBidSche dule.p |
| negAvailableCurRD Volume | Available curative RD volume of the downward (decrease generation, increase load) offer in MW which can be activated | MW | float | time series |  | RemedialActio nFlatlist: PowerBidSche dule.p |

<!-- page 158 -->

###### Business Rules

CRA linked to COs: CRA can be used independently for the linked CO cases and for all XNEs CRA linked to COs and to one or multiple XNEs: CRA can be used only for all combinations of the linked COs and XNEs

CRA without links to COs and any XNEs: CRA can be used for all COs and for all XNEs

CRA without link to COs and with link to one or multiple XNEs: CRA can be used for all COs, but only for the subset of linked XNEs

Example : Two curative RA are linked to XNE1. The curative RA can only be applied on this XNE1 in a contingency and are therefore only used in that XNE1's loading constraints. An additional use for an XNE2 which is also overloaded in the contingency but not linked with the curative RA is not possible. The curative RA are not considered within the XNE2 loading constraints and the congestion must be solved some other way, e.g. with preventive RA.

It should be noted that even without considering the curative RA in the loading constraints of XNE2, they can have an impact when being applied for the linked XNE1. This impact is determined with the iterative approach of the RAO via the following LF-calculation and FOA after the MILP has been solved. The loadings of all XNEs are considered linearised via the FOA with the curative RA applied in the contingency.

This modelling requires reasonable parameterisation of the input data to avoid unwanted behaviour of the RAO and unwanted results.

Special case : In general, even generating units with very fast start-up times (like hydro generation) will not be considered as CRA if they are switched off at the respective time stamp. To enable the RAO to consider such CRAs is only possible in special cases. For example, a generating unit with neither P min nor minimum up/down time constraints can be operated at P=0 while still be considered on and the RAO would use the respective CRA.

###### Triggers

The RAO started successfully and all pre-conditions are met.

###### Pre-Condition

• All relevant input data is delivered, see Configuration.

• At least one correctly defined assessed element is part of the AE-FlatList.

• The initial loadflow converged.

###### Acceptance Criteria

Given

<!-- page 159 -->

The RAO could reduce the loading on an overloaded XNE (loading is under the TATL limit) in a contingency situation with curative redispatch remedial actions with some being linked to this contingency situation and others linked to other contingency situations. There are no PRA available. When

the optimisation terminates successfully,

then

no curative redispatch remedial actions not linked to the contingency situation responsible for the overloading are used for reducing the loading of the XNE in this contingency situation. Other constraints can have an influence on the result of the RAO.

Given

The RAO could reduce the loading on an overloaded XNE (loading is under the TATL limit) in a contingency situation with curative redispatch remedial actions which are linked to this contingency situation and some of them linked to this overloaded XNE and the rest of the curative redispatch remedial actions linked to a different XNE. There are no PRA available.

When

the optimisation terminates successfully,

then

only the curative redispatch remedial actions which are linked to this contingency situation and linked to the overloaded XNE are used for reducing the loading of the XNE. Other constraints can have an influence on the result of the RAO.

reservation costs must be shown for this redispatch CRA depending on the reserved capacity. Given

The RAO could reduce the loading on an overloaded XNE (loading is under the TATL limit) in a contingency situation with curative redispatch remedial actions not linked to any contingency situation. There are no PRA available.

When

the optimisation terminates successfully,

then

the curative redispatch remedial actions not linked to any contingency situation are used for reducing the loading of the XNE in this contingency situation. Other constraints can have an influence on the result of the RAO.

<!-- page 160 -->

###### Basic Flow

The results of the activated CRA are exported via the RemedialActionScheduleProfile (see SF3078: PowerScheduleAction Optimisation results).

###### Alternative Flow

The following log-messages are exposed:

• If a CRA is linked to the AE and the CRA is not in the RA-FlatList a fatal error is logged and the RAO is cancelled

• If a CO is linked to a CRA and the CO is not found in the CO-FlatList a fatal error is logged and the RAO is cancelled

<!-- page 161 -->

##### CORNET-4614: Consideration of PRAs and CRAs of redispatch RAs for the same Generating Unit

##### Generating Unit

###### Description

Use case: When defining redispatch RAs one generating unit can be used in a PRA as well as a CRA for one or multiple contingencies. TSOs shall be able to model both options in RAO. However, constraints of a generating unit shall be met regardless. Meaning, that the combination of PRA and CRA for each generating unit shall not lead to violations of the technical restrictions of the generation unit.

When considered in the optimisation, the redispatch volume for the CRA and PRA is limited by the given available redispatch volume in the PowerBidSchedules. The consideration of technical limits depends on the RA and TSO specific configuration (see CORNET-612 – Consideration of technical limits from redispatch RA in curative mode) and can further limit the available RD volume of the bid. For any given generation unit the active power output after the RAO must meet the technical limits P min and P max for the base case (Prod and PRA) and in any contingency case (Prod, PRA and CRA) in each time stamp.

$$
P_{\min} \leq P_{\mathit{prod},g} + \Delta P_{\mathit{PRA},g}^{+} -\Delta P_{\mathit{PRA},g}^{-} \leq P_{\max} \\
P_{\min} \leq P_{\mathit{prod},g} + \Delta P_{\mathit{PRA},g}^{+} -\Delta P_{\mathit{PRA},g}^{-} + \Delta P_{\mathit{CRA},g}^{+} -\Delta P_{\mathit{CRA},g}^{-} \leq P_{\max} \\
\Delta P_{\mathit{PRA},g}^{+} = \sum_{b\in \mathit{PB}} \Delta P_{b,g}^{+} \\
\Delta P_{\mathit{PRA},g}^{-} = \sum_{b\in \mathit{PB}} \Delta P_{b,g}^{-} \\
\Delta P_{\mathit{CRA},g}^{+} = \sum_{b\in \mathit{PB}} \max \{\Delta P_{b,g}^{\mathit{cur},c+} \} \forall c\in \mathit{Outages} \\
\Delta P_{\mathit{CRA},g}^{-} = \sum_{b\in \mathit{PB}} \max \{\Delta P_{b,g}^{\mathit{cur},c-} \} \forall c\in \mathit{Outages}
$$

The preventive RD of a generating unit ($\Delta P_{\mathit{PRA},g}^{+}$ / $\Delta P_{\mathit{PRA},g}^{-}$) is the sum of the activated RD specific to this generating unit ($\Delta P_{b,g /}^{+} \Delta P_{b,g}^{-}$). These values are derived from multiplying the activated RD volume of the PowerBids with the participation factor of the generating unit.

To avoid double counting the reserved curative RD volume ($\Delta P_{\mathit{CRA},g}^{+}$ / $\Delta P_{\mathit{CRA},g}^{-}$), only the maximum reserved curative RD volume of the generating unit ($\Delta P_{b,g}^{\mathit{cur},c+}$ / $\Delta P_{b,g}^{\mathit{cur},c-}$) over all contingencies is considered.

<!-- page 162 -->

> **Figure (page 162) — described in text.**
>
> Bar chart of a generating unit's dispatch, with a generator symbol (⌁) at the left. The vertical axis is bounded by two red dashed lines, $P_{max}$ at the top and $P_{min}$ at the bottom. A dark blue bar labelled *Prod* sits at $P_{min}$; an orange bar labelled *PRA* sits just above it; then four brown floating bars grouped under the bracket *CRA for different XNEC*, each starting from the post-PRA level (grey dotted reference line) and reaching different heights — one dipping below the reference, the last reaching up to $P_{max}$. A brace on the right reads *CRA Potential limited by: Technical limit $P_{min}$ · Technical limit $P_{max}$*.

###### Outlook

Further technical limits (e.g. restrictions due to max. power gradients) will be tackled in a later release.

##### Business Needs:

BN806: RAO-RA_CRA_PRA

##### Use-Cases:

UC487: BUC 14#41 Consideration of Pmax for generating Units with PRA and CRA

UC488: BUC 14#42 Consideration of Pmin for generating Units with PRA and CRA

##### Acceptance Criteria:

Given

A Generating unit has both, a PRA and one or multiple CRA

When

The RAO successfully terminates,

Then

The resulting active power output after RAO of the generating unit shall stay within bounds (Pmin and Pmax) in base case and all contingency cases for all timestamps

<!-- page 163 -->

##### CORNET-612: Consideration of technical limits from redispatch RA in curative mode

###### Description

The consideration of technical limits for generation units depends on the linked GLSK within the PowerBidSchedule of the RA and configurable TSO specific RAO control parameters in release Q1/2024.

The control parameter (curPMax) enables/disables the consideration of the maximum upper active power limit (P ) from a generation unit. This parameter is only considered if the curative RA is linked Max via the GLSK to a single generation unit. If the curative RA is linked via the GLSK with more than one generation unit, the P Max of these generation units is not considered within the RAO and the offers of the bids are taken as they are defined without an additional consideration of the technical limits of the generation units. Furthermore, this GLSK can only contain generation units as participating, GLSKs with loads are not considered.

The control parameter (curPMin) enables/disables the consideration of the minimum active power limit (P Min ) from a generation unit. This parameter is only considered if the curative RA is linked via the GLSK to a single generation unit. If the curative RA is linked via the GLSK with more than one generation unit, the P Min of these generation units is not considered within the RAO and the offers of the bids are taken as they are defined without an additional consideration of the technical limits of the generation units. Furthermore, this GLSK can only contain generation units as participating, GLSKs with loads are not considered.

###### Configuration

| Name | Description | Unit | Data Type | Time Series/ Constant | Profile |
| --- | --- | --- | --- | --- | --- |
| curPMax | Enables/disables consideration of P Max from generation units Default: Enabled |  | bool | constant | RAO Setting |
| curPMin | Enables/disables consideration of P Min from generation units Default: Enabled |  | bool | constant | RAO Setting |

<!-- page 164 -->

###### Outlook

In a future release the consideration of minimum and maximum active power limits for generating units which are linked to a GLSK with more than one unit could be possible. Additionally, the control parameters will be available on TSO specific level.

Business Need :

BN813: RAO-RA_CRA_Redispatch_MVP (RAO)

Acceptance Criteria :

Given

The RAO reduces the loading on an overloaded XNE in a contingency situation with curative redispatch remedial actions which are linked to this contingency situation and are part of a TSO region for which the consideration of the maximum active power limit for curative remedial actions is enabled.

When

the optimisation terminates successfully,

then

the active power output of a generation unit cannot exceed its maximum active power limit with activated curative redispatch remedial actions. Other constraints can have an influence on the result of the RAO.

##### CORNET-613: Consideration of reaction time for redispatch RA in curative mode

###### Description

In RAO v1 only one TATL per assessed element is considered for the determination of curative RAs. Therefore, the reaction time of the curative RA ( timeToImplement ) must be compared to the duration of the TATL of the assessed element. If the reaction time of the curative RA is lower than or equal to the TATL duration, the curative RA is considered as a viable curative RA option for the linked contingency cases. Otherwise, if the reaction time of the curative RA is higher than the duration, the curative RA is not considered in the optimisation for this assessed element. The determination of which CRAs can be used for a given TATL is done when the optimisation problem (MILP) is being build and is therefore not part of the MILP itself.

<!-- page 165 -->

No Modelling of the timeline of the CRA activation

| TATL duration TATL duration TATL N-1 N-1 PATL XNEC Loading N-0 N-0 CRA timeToImplement timeToImplement |  |  |
| --- | --- | --- |

TATL

PATL XNEC Loading

CRA

Contingency CRA- Time Contingency CRA- Time Case Activation Case Activation

Figure 6: Modelling of reaction time (timeToImplement) and activation of curative RA

The timeline of the CRA activation (therefore modelling of a ramp-up) is not considered for curative redispatch RA in the reaction time. The maximum available RD volume of the offer is fully usable from the beginning after the timeToImplement , a start-up gradient is not considered.

###### Configuration

| Name | Description | Unit | Data Type | Time Series/ Constant | Profile |
| --- | --- | --- | --- | --- | --- |
| timeToImplemen t | Reaction time that will be compared to the temporary overloading time (duration) associated to the TATL of the grid elements. The reaction time is the time needed | Minute float |  | constant | RA-P: RedispatchRemedialAction -> RemedialAction.timeToImplem ent |

<!-- page 166 -->

|  | to activate the RA and until it takes effect. |  |  |  |  |
| --- | --- | --- | --- | --- | --- |

###### Outlook

A future release could consider a gradient for the change in power of the curative RA. This could further limit the available RD volume, depending on the powergradient of the RA and temporary overloading time associated to the TATL of a grid element. This could also lead to a change of the consideration of curative RA in the XNE loading constraints.

Business Need :

BN813: RAO-RA_CRA_Redispatch_MVP (RAO)

Acceptance Criteria :

Given

The RAO reduces the loading on an overloaded XNE in a contingency situation with curative redispatch remedial actions which are linked to this contingency situation.

When

the optimisation terminates successfully,

then

the applied curative remedial actions for activation in the contingency situation have a reaction time which is less than or equal to the TATL duration of the overloaded XNE. Other constraints can have an influence on the result of the RAO.

##### CORNET-576: Consideration of lead time for redispatch RA in curative mode

###### Description

For organising and ordering the RA a redispatch lead time is considered. This RDleadTime is for reserving the redispatch potential of the curative RA. Therefore, the curative RA is only available in time stamps where:

$\mathit{RDleadTime} + \mathit{RA} \mathit{Deciding} \mathit{Point} (\mathit{RADP}) \leq \mathit{Time} \mathit{Stamp}$

The RADP is defined in CORNET-89 – RA Deciding Point.

Additional lead times of the RA (e.g. start-up lead times) are ignored.

<!-- page 167 -->

###### Configuration

| Name | Description | Unit | Data Type | Time Series/ Constant | Profile |
| --- | --- | --- | --- | --- | --- |
| RDleadTime | Time needed until the offered RD offer is available |  | hour float | constant | RA-P: PowerBidSchedule.LeadTime |

###### Details / Background

CRA with RDleadTime = 3h

Active power

Redispatch Leadtime

00:30 01:30 02:30 03:30 04:30 Time RADP: CRA activation CRA activation now Reservation of not possible in possible from this CRA possible this timestamp timestamp onwards Figure 7: Example for consideration of the RDleadTime of a CRA

Example : the RA Deciding Point is the first timestamp of the optimisation timeframe (00:30). A curative RA has a RDleadTime of 3h. The earliest activation of the curative RA is possible in time stamp “04:30”. An activation and therefore use of the curative RA on earlier time stamps is not possible.

###### Outlook

In the next release the RADP will be configurable to consider lead times already starting the day before. Business Needs : BN846: RAO-RA_CRA_GeneratingUnit_Leadtime

<!-- page 168 -->

Acceptance Criteria :

Given

The RAO could reduce the loading on an overloaded XNE in a contingency situation in the first timestamp with curative redispatch remedial actions which are linked to this contingency situation and have a redispatch lead time of 5 hours. The RA Decision Point is defined as the first time stamp. When

the optimisation terminates successfully,

then

no curative remedial actions for activation in the contingency situation are determined. Other constraints can have an influence on the result of the RAO.

Given

The RAO could reduce the loading on an overloaded XNE in a contingency situation in the fifth timestamp with curative redispatch remedial actions which are linked to this contingency situation and have a redispatch lead time of 5 hours. The RA Decision Point is defined as the first time stamp. When

the optimisation terminates successfully,

then

curative remedial actions for activation in the contingency situation have been determined. Other constraints can have an influence on the result of the RAO.

##### CORNET-574: Balancing of redispatch RA in curative mode

###### Description

In order to balance the active power injections of curative RA, a balancing constraint is considered for each contingency in the RAO.

$$
\sum \Delta P_{\mathit{CRA},C} = 0
$$

Part of this balancing constraint are all curative RAs with a link to the contingency C . Therefore, the RAO determines the necessary curative redispatch RA and corresponding counterparts for solving imbalances itself by evaluating all curative redispatch RA linked to the contingency.

###### Details / Background

The MILP of the RAO is built in such a way that the curative RA must find the counterparts themselves. For the balancing approach to work, at least two curative RA must be linked to a contingency and must be considered within the MILP (see CORNET-572: Consideration of redispatch RA in curative mode).

<!-- page 169 -->

These curative RAs must also provide sufficient positive and negative available RD volume for balancing.

The curative RA are considered with their sensitivities and the costs in the RAO (see CORNET-575 - Considered costs of redispatch RA in curative mode).

###### Outlook

Depending on the current discussion, a balancing constraint per contingency and assessed element could be considered in a future release of the RAO.

With the introduction of GLSK linked to more than one generation unit, the RAO can also consider slack node types. The slack node type must be modelled as a curative RA linked to a contingency situation and XNEC. The linked GLSK of the RA must be mapped to the generation units at the slack nodes with associated participation factors.

Business Needs: BN813: RAO-RA_CRA_Redispatch_MVP (RAO)

Acceptance Criteria :

Given

The RAO could reduce the loading on an overloaded XNE in a contingency situation with curative redispatch remedial actions which are linked to this contingency situation and have positive and negative available RD volume respectively.

When

the optimisation terminates successfully,

then

the sum of redispatch from the determined curative remedial actions for activation in the contingency situation must be zero. Other constraints can have an influence on the result of the RAO.

##### BUC 14#43 Consideration of costs for redispatch CRA

###### Scenario

UC489: BUC 14#43 Consideration of reservation costs for CRA

For RD CRA, both reservation and penalty costs are considered in the RAO per Power Bid and time stamp.

<!-- page 170 -->

###### Assumptions

The curative redispatch RA are considered via reservation and penalty costs from the input data within the objective function of the RAO (see SF3077 Objective function). The reservation costs ( reservePriceCRA ) are given per Power Bid and for each time stamp. They are multiplied with the reserved curative active power volume within the objective function. To avoid double counting the curative penalty and reservation costs within the objective function in all contingency situations, only the maximum activated curative adjustments are considered per time stamp (see SF3077: Objective Function).

The RA specific penalty costs are calculated from the penalty cost factor of the input data ($\mathit{cf}_{b,\mathit{penalty}}^{\mathit{cur}}$ - penaltyFactorRA) and the curative penalty reference value of the RAO ($c_{\mathit{redisp},\mathit{reference}}^{\mathit{cur}}$).

$$
c_{b,\mathit{Penalty}}^{\mathit{cur}} = \mathit{cf}_{b,\mathit{penalty}}^{\mathit{cur}} \cdot c_{\mathit{redisp},\mathit{reference}}^{\mathit{cur}} \tag{3.58}
$$

It is assumed that the probability of activating a curative RA is quite low and these probabilities are currently unavailable. Therefore, a consideration of the price of the curative redispatch offer via an expected value is not possible.

Because costs for these RAs must be considered in the objective function, penalty costs are used in this release. The RA specific penalty costs are also used to define a ranking of the different curative RA options.

Additional costs for curative redispatch RAs are not considered in this release.

###### Outlook

The energy costs/price could be given in the offer but are not considered, because an expected value would need to be calculated with the probability of the contingency. This is not foreseen for RAO.

###### Configuration

The following input data is needed for the RAO:

| Name | Description | Unit | Data Type |  | Time | CoMo-Profile |
| --- | --- | --- | --- | --- | --- | --- |
|  |  |  |  |  | Series/ |  |
|  |  |  |  |  | Constant |  |
| reservePriceCRA | Price for reserving the curative redispatch RA | EUR/ MW | float | Time series |  | RemedialActio nFlatList: PowerBidSche dule.reservePri ce |

<!-- page 171 -->

| penaltyFactorRA | Penalty cost factor of the RA for multiplication with curative penalty reference value of the RAO |  | float | constant | RemedialActio nFlatList: RemedialActio n.penaltyFactor |
| --- | --- | --- | --- | --- | --- |

The penalty reference value is described in CORNET-4339: TSO specific parametrization of penalty reference values for remedial actions.

###### Business Rules

If no value is given for the reservePriceCRA in the input data, the value is set to zero in the RAO. If no value is given for the penaltyFactorRA in the input data, the value is set to zero in the RAO.

###### Triggers

The RAO is started successfully and all pre-conditions are met.

###### Pre-Condition

All relevant input data for redispatch CRAs is delivered (see Configuration and BUC 14#106: Consideration of redispatch RA in curative mode).

At least one correctly defined assessed element is part of the AE-FlatList.

At least one correctly defined contingency is part of the CO-FlatList.

The initial load-flow converged.

###### Acceptance Criteria

Given

The RAO determines the activation of a redispatch CRA for a contingency situation.

When

The RAO successfully terminates,

Then

The correct total reservation costs must be applied for this redispatch CRA depending on the reserved capacity.

Given

The RAO determines the activation of a redispatch CRA for a contingency situation.

When

The RAO successfully terminates,

Then

<!-- page 172 -->

The correct total penalty costs must be applied for this redispatch CRA depending on the reserved capacity.

###### Basic Flow

The penalty and reservation costs per bid are stored in the RemedialActionSchedule (see SF3078: PowerScheduleAction Optimisation results).

###### Alternative Flow

No alternative flow is foreseen.

<!-- page 173 -->

#### 3.6.7 Countertrade

##### CORNET- 4847: Consideration of Countertrade

###### Description

The RAO shall consider countertrading (CT) as a form of remedial action (RA). CT RAs can be used together with redispatch (RD) RAs. The difference between a CT RA and a RD RA is that for a CT RA the generating units related constraints are not considered in the optimisation, whereas for RD RAs generating unit related constraints are considered in the optimisation (see 5.3.3 Consideration of Generation Units in RAO).

A CT RA must be defined as a CountertradeRemedialAction and can be either preventive or curative ( RAactivationKind ). Each CT RA must have at least one Power Bid ( PowerBidSchedule ), which contains the available volume and price for the countertrade. This approach is the same as for RD RA (see CORNET-2006: Consideration of multiple Power Bids per Generating Unit). If more than one PowerBid is linked to the same CT RA, all PowerBids must have the same GLSK. The distribution of the volume of the CT RA is done according to the gLSKStrategy ( gLSKStrategy: explicitInstruction, proportionalForGenerator, proportionalForRemainingCapacity ). Other gLSKStrategy kinds are not considered by the RAO, therefore CT RAs which are using other kinds are not considered within the optimisation.

##### Note:

Each TSO can deliver multiple CT RAs where each CT RA can have a different gLSKStrategy applied. (For example, CT RA1 for hours 01-06 can have proportionalForGenerator while CT RA2 for hours 07- 24 can have proportionalForRemainingCapacity.)

Because CT RA use the same Power Bids class like RD RA, CT RAs respect the already defined attributes of these Power Bids (see chapter 5.3.6 Consideration of Power Bids) .

It is not possible to start-up or shut-down a generating unit due to a CT RA, but generating units can be part of a RD RA and CT RA and can be started due to the RD RA. Therefore, the constraints of generating units regarding minimum up and down times are only indirectly considered (see CORNET- 4849: Consideration of technical limits of generating units of CT RAs). All other technical constraints of generating units (see 5.3.3 Consideration of Generation Units in RAO) are not considered in the optimisation problem (MILP) for CT RAs.

<!-- page 174 -->

###### Configuration

Data requirement: modelling countertrade remedial actions

| Name | Description | Unit | Data type | Time series/ constant | Profile |
| --- | --- | --- | --- | --- | --- |
| gLSKStrategy | Definition of the GLSK CT strategy. | - | string | constant | CountertradeRemedialAct ion → GLSKStrategyKind: - explicitInstruction - proportionalForGe nerator - proportionalForRe mainingCapacity |

###### Details / Background

##### Example:

A TSO has a CT RA with three Power Bids (CT Bd_1, CT Bd_2 and CT Bd_3 ). The RAO determines to activate from the second Power Bid CT Bd_2 a volume of 100 MW. The linked GLSK contains the three GeneratingUnits GenA, GenB and GenC, which provide the volume to the grid. The amount of power that each of the generation units must provide from the second Power Bid is given via the corresponding gLSKStrategy (explicitInstruction) . Thus, the participation factors are as follows (see table and figure below).

| Generation Unit | Participation Factor | Power to provide |
| --- | --- | --- |
| GenA | 0.2 | 20 MW |
| GenB | 0.5 | 50 MW |
| GenC | 0.3 | 30 MW |

<!-- page 175 -->

##### GenA ~ CT Bid_1 +

##### 0.2 * 100 MW = 20 MW

##### 0.2

GenB ~ $0.5_{GLSK CT Bid_2 +} =$ 100 MW

##### 0.5 * 100 MW = 50 MW

##### 0.3

##### participation factor GenC ~ CT Bid_3 +

##### 0.3 * 100 MW = 30 MW

Figure 8: Example countertrade via a GLSK

###### Outlook

This chapter is only for informational purposes and is not part of the delivered specification.

In future releases of the RAO the technical limits of generating units (P min and P max ) of CT RAs will be considered. Also, CT RAs with a dynamic GLSK strategy and subset of generating units will be possible (at the moment there are no examples of the modelling of such CT RAs in the NC profiles available). The remaining GLSK strategies will be considered.

##### Business Needs:

BN611: RAO-RA_Countertrade_MVP

BN785: RAO-GLSK_Advanced: The RAO must support use and adaptation of GLSK

Use-Cases :

UC306: BUC 14#34 Consideration of Countertrade in RAO (MVP)

UC858: BUC 14#88 Consideration of Countertrade - Additional GLSK Strategies

Acceptance Criteria :

Given

The RAO has a CT RA with the attribute gLSKStrategy being defined as explicitInstruction . The CT RA has at least one Power Bid with an available volume for countertrade. The available volume of the countertrade is the cheapest way to relieve an available congestion.

When

<!-- page 176 -->

The optimisation terminates successfully,

Then

The RAO should have used the CT RA for relieving the congestion.

Given

The RAO has a CT RA with the attribute gLSKStrategy being defined as proportionalForGenerator . The CT RA has at least one Power Bid with an available volume for countertrade. The available volume of the countertrade is the cheapest way to relieve an available congestion.

When

The optimisation terminates successfully,

Then

The RAO should have used the CT RA for relieving the congestion.

Given

The RAO has a CT RA with the attribute gLSKStrategy being defined as proportionalForRemainingCapacity . The CT RA has at least one Power Bid with an available volume for countertrade. The available volume of the countertrade is the cheapest way to relieve an available congestion.

When

The optimisation terminates successfully,

Then

The RAO should have used the CT RA for relieving the congestion.

<!-- page 177 -->

#### 3.6.8 Consideration of Power Bids

##### CORNET-2006: Consideration of multiple Power Bids per Generating Unit

###### Description

Note : According to CORNET-41: Consideration of available RD volume, only a total of two power bids – one bid per direction, positive and negative RD volume – is considered per generation unit. This functionality is extended by this specification to consider multiple bids.

Note : According to CORNET-335: Data model – Generating Units, the RAO considers only power bids which are linked to a GLSK, as required by the NC-profiles, representing a single generation unit. This applies for R24Q1 as well.

Use Case: The user wants the RAO to comply with the available power bids of a remedial action for a power plant. The RAO considers available RD volume for the active power feed-in of generation units. An available RD volume is the power by which a generating unit may change its power feed-in. The modelling of the overall available RD volume of a generating unit is defined as sum of available RD volume per power bid.

For each generating unit

• multiple independent power bids for the upward offer (increase generation) can be

considered.

• multiple independent power bids for the downward offer (decrease generation) can be considered.

Each power bid contains the available RD volume per timestamp. To consider the RD volume within the RAO, the availability must be set to “True” per timestamp for the given available RD volume. Otherwise, the available RD volume of the timestamp is treated as zero. For each timestamp of the power bid with a preventive available RD volume, the price of the RD energy must also be supplied. For curative available RD volume, a penalty cost factor must be given for the remedial action. The available positive and negative RD volume of a generation unit is defined as the sum of the available positive resp. negative RD volume of all associated power bids. If no power bids are defined in the input data, the available RD volume is set to zero. The available RD volume per power bid may be restricted by further power bid constraints such as minimal up and down time (see CORNET-2007: Consideration of minimum up and down times for power bids).

Additionally, the available RD volume of the power bid can only be used while respecting the technical limits of the generating unit. Exceeding the technical limits ($P_{\mathit{Min}}$, $P_{\mathit{Max}}$) by activating high RD volume is not possible.

<!-- page 178 -->

Note : bid dependencies, e.g. parent-child links, are not considered in R24Q1. The available RD volume of bids that are linked to each other is not considered for redispatch in the RAO.

###### Details / Background

Example : Part a of the following figure shows exemplary the available RD volume for three power bids of a generation unit (two bids with direction up and one bid with direction down) over time. The maximum positive RD volume equals an addition of both two bids with direction up. The maximum negative RD volume equals the available RD volume of the single bid with direction down. Resulting absolute power limits are shown in part b of the figure. A complete utilisation of both bids with direction up results in the maximum achievable active power given by the green line. Accordingly, the minimum achievable active power by fully utilisation of the bid with direction down is given by the yellow line. a)

| Power Bids (stacked) Bid Bid Bid |  |  |  |  |  |  |  |  |  |  |  |  |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |

up,2 Max. RD+ = Bid + Bid

up,1 up,2

up,1

Max. RD- = Bid

down,1 down,1

Change in Active Power

t Time

b)

| Time |  |  |  |  |  |  |  |  |  |  |  |  |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |

PROD before Optimisation

Active Power PROD before Optimisation + Bid + Bid up,1 up,2 PROD before Optimisation + Bid

up,1

PROD before Optimisation - Bid

down,1

t

Each bid may have different costs. With the assumption for the prices (for RD energy) bid = 0.5 * up,1 price bid = 0.5 * price bid . This results in the following cost contribution to the objective function down,1 up,2 as a function of RD volume for the timestamp t 0 :

<!-- page 179 -->

RD volume 0

Cost

###### Configuration

Data requirement: modelling the available power bids of a generation unit

| Name |  | Unit | Data Type | Time Series/ Constan t | Profile |
| --- | --- | --- | --- | --- | --- |
|  | Descriptio |  |  |  |  |
|  | n |  |  |  |  |
| RAID | The | - | string | Constant | RemedialAction-Profile RemedialAction::mrid |
|  | identifier of |  |  |  |  |
|  | the RA is a |  |  |  |  |
|  | fixed ID |  |  |  |  |
|  | allowing |  |  |  |  |
|  | the unicity |  |  |  |  |
|  | of the |  |  |  |  |
|  | identificatio |  |  |  |  |
|  | n of the RA |  |  |  |  |
| PowerBidScheduleI D |  | - | string | Constant | StateInstructionSchedule-Profile PowerBidSchedule::mrid |
|  | mRID |  |  |  |  |
| linkedGLSK | The | - | string | Constant | StateInstructionSchedule-Profile GLSKSchedule->GeneratingUnit GLSKSchedule-> ParticipationFactorTimePoint:: participationFactor = 1 |
|  | reference |  |  |  |  |
|  | to the |  |  |  |  |
|  | CGMs’ grid |  |  |  |  |
|  | element(s) |  |  |  |  |
|  | associated |  |  |  |  |
|  | to the RA |  |  |  |  |
|  | that will |  |  |  |  |
|  | allow |  |  |  |  |
|  | application |  |  |  |  |
|  | of the RA in |  |  |  |  |

<!-- page 180 -->

|  | RSA or RA |  |  |  |  |
| --- | --- | --- | --- | --- | --- |
|  | optimisatio |  |  |  |  |
|  | n |  |  |  |  |
| directionRD | Direction of | - | enum(up , down) | Constant |  |
|  | the |  |  |  |  |
|  | available |  |  |  | StateInstructionSchedule-Profile |
|  | RD volume |  |  |  | PowerBidSchedule::direction |
|  | in bid: up or |  |  |  |  |
|  | down |  |  |  |  |
| Availability |  |  | boolean | Time series | RemdialAction-Profile |
|  | Indicating |  |  |  |  |
|  |  |  |  |  | RemedialAction::normalAvailable |
|  | the |  |  |  |  |
|  |  |  |  |  | or |
|  | availability |  |  |  |  |
|  |  |  |  |  | SteadyStateInstruction-Profile |
|  | status for |  |  |  |  |
|  |  |  |  |  | RemedialAction::available |
|  | each hour |  |  |  |  |
| priceRDBid |  | €/MW h | float | Time series | StateInstructionSchedule-Profile |
|  | Price of |  |  |  |  |
|  |  |  |  |  | PowerBidScheduleTimePoint::atTi |
|  | redispatch |  |  |  |  |
|  |  |  |  |  | me |
|  | energy in |  |  |  |  |
|  |  |  |  |  | PowerBidScheduleTimePoint::pric |
|  | EUR/MWh. |  |  |  |  |
|  |  |  |  |  | e |
| available RD Volume | Maximal | MW | float | Time series |  |
|  | size of the |  |  |  |  |
|  | offer in MW |  |  |  |  |
|  |  |  |  |  | StateInstructionSchedule-Profile |
|  | which can |  |  |  |  |
|  |  |  |  |  | PowerBidScheduleTimePoint::atTi |
|  | be |  |  |  |  |
|  |  |  |  |  | me |
|  | activated |  |  |  |  |
|  |  |  |  |  | PowerBidScheduleTimePoint::p |
|  | (minimal |  |  |  |  |
|  | resolution |  |  |  |  |
|  | is 1MW) |  |  |  |  |

##### Notes:

• The data requirement defined in CORNET-41 is changed in the following manner: Parameters “max RD+” and “max RD-“ are no longer directly set but are defined as sum of available RD volume of power bids within the respective RD direction (direction = up for RD+ and direction = down for RD-). This is incorporated in the RAO via additional constraints. However, all

<!-- page 181 -->

additional constraints regarding the generating unit and are containing “max RD+” and “max RD-“ such as upper and lower active power limits (CORNET-36, CORNET-37), minimum up and down times of the generating unit (CORNET-39), etc., are still valid and considered in the RAO.

• Power bids are defined as a relative/ delta to PROD (same as “max RD+” and “max RD-“ in CORNET-41).

• It is mandatory to link the power bid to a GLSK with only one generating unit with participation factor 1. Otherwise, the bid cannot be considered.

• Each generating unit must have at least one bid, otherwise the generating unit will not participate in the RAO.

###### Outlook

A future release will consider bid dependencies. The feature will be implemented when the corresponding input data format is fixed.

With the specification of GLSK in a future release, additional power bids linked to a GLSK which represents more than one generation unit are going to be implemented.

Business Needs : BN811: RAO-RA_Redispatch_Offer_MVP

Acceptance Criteria :

Given

the RAO has an overloaded XNE in one time stamp on which the loading can be reduced with two available PRA. The first PRA has two power bids with positive available RD volume, the other PRA has two power bids with negative available RD volume. In each PRA one of the power bids is cheaper than the other one. The penalty costs are parameterized in such a way that eliminating the congestion of the overloaded XNE by remedial actions leads to a lower objective function value. Activation of the PRA is not restricted by other constraints (power ramps , min RD, etc.).

When

the optimisation terminates successfully,

then

at least the two cheaper power bids of the PRAs must be activated and reduce the loading of the XNE to or below the PATL. Other constraints can have an influence on the result of the RAO.

<!-- page 182 -->

##### CORNET-2007: Consideration of minimum up and down times for Power Bids

###### Description

Use case: In CORNET-44 minimum up and down times of generating units are specified. Additionally, minimum up and down times for each power bid are considered for preventive RA.

The minimum up time of a power bid refers to the shortest duration for which a power bid, with a RD volume above zero, must remain continuously active once it has been activated. Similarly, the minimum down time of a power bid indicates the shortest period that a power bid must remain continuously inactive after it has been deactivated.

By changing the scope to power bids instead of generating units, all specifications made in CORNET- 44 can be adopted.

###### Configuration

| Name |  | Unit | Data Type | Time Series/ Constant | Profile |
| --- | --- | --- | --- | --- | --- |
|  | Description |  |  |  |  |
| minUpBid be activated | minimal duration for which an offer must |  | hour integer Constant |  |  |
|  |  |  |  |  | SecurityScheduleProfile |
|  |  |  |  |  | PowerBidSchedule.minimumUptime |
| minDownBid be active between two activated timestamps | minimal duration for which an offer can’t |  | hour integer Constant |  |  |
|  |  |  |  |  | SecurityScheduleProfile |
|  |  |  |  |  | PowerBidSchedule.minimumOffTime |

Business Needs : BN811: RAO-RA_Redispatch_Offer_MVP

Acceptance Criteria :

Given

the RAO has an overloaded XNE in one time stamp on which the loading can be reduced with two available PRA. The first PRA has a power bid with positive available RD volume, the other PRA has a power bid with negative available RD volume. The power bid of the first PRA has a minimum up time of two hours. The penalty costs are parameterized in such a way that eliminating the congestion of the

<!-- page 183 -->

overloaded XNE by remedial actions leads to a lower objective function value. Activation of the PRA is not restricted by other constraints (power ramps, min RD, etc.).

When

the optimisation terminates successfully,

then

both power bids of the PRAs must be activated for two hours and reduce the loading of the XNE. Other constraints can have an influence on the result of the RAO.

Given

the RAO has an overloaded XNE in the first and the third time stamp on which the loading can be reduced with two available PRA. The first PRA has a power bid with positive available RD volume, the other PRA has a power bid with negative available RD volume. The power bid of the first PRA has a minimum down time of two hours. The penalty costs are parameterized in such a way that eliminating the congestion of the overloaded XNE by remedial actions leads to a lower objective function value. Activation of the PRA is not restricted by other constraints (power ramps, min RD, etc.).

When

the optimisation terminates successfully,

then

both power bids of the PRAs must be activated for the first three consecutive hours and reduce the loading of the XNE. Other constraints can have an influence on the result of the RAO.

Given

the RAO has an overloaded XNE in the first and the fifth time stamp on which the loading can be reduced with two available PRA. The first PRA has a power bid with positive available RD volume, the other PRA has a power bid with negative available RD volume. The power bid of the first PRA has a minimum down time of two hours. The penalty costs are parameterized in such a way that eliminating the congestion of the overloaded XNE by remedial actions leads to a lower objective function value. Activation of the PRA is not restricted by other constraints (power ramps, min RD, etc.).

When

the optimisation terminates successfully,

then

both power bids of the PRAs must be activated only for the first and the fifth time stamp and reduce the loading of the XNE. Other constraints can have an influence on the result of the RAO.

<!-- page 184 -->

##### CORNET-2008: Consideration of minimum redispatch for Power Bids

###### Description

Use Case: The user wants the RAO to comply with a minimum amount of redispatch for an activated power bid. In the RAO, the minimum redispatch of a power bid is considered as an additional (hard, non-relaxed) constraint.

###### Configuration

| Name |  | Unit | Data Type | Time Series/ Constant | Profile |
| --- | --- | --- | --- | --- | --- |
|  | Description |  |  |  |  |
| minRD | Minimal size of the offer |  | MW integer | Time Series | StateInstructionSchedule-Profile PowerBidScheduleTimePoint::atTime PowerBidScheduleTimePoint:: minimumActivationP |
|  | in MW which can be |  |  |  |  |
|  | activated (default |  |  |  |  |
|  | minimal size of the offer |  |  |  |  |
|  | is 1MW). |  |  |  |  |

Note: The min size RD is an optional user defined time series parameter. In case no min. size RD is defined, the default value is 1 MW.

###### Details / Background

##### Example:

##### A generating unit g has two power bids as follows:

| Power bid |  | price for RD |  |  | available RD |  | min. size RD [MW] |
| --- | --- | --- | --- | --- | --- | --- | --- |
|  |  | energy [€/MWh] |  |  | Volume [MW] |  |  |
| Bid up,1 | 5 |  |  | 50 |  |  | 10 |
| Bid up,2 | 2 |  |  | 50 |  |  | 20 |

##### Case 1:

In order to resolve a congestion, redispatch of 5 MW is needed as remedial action from generating unit g for one hour. Power balancing (the determined counterpart(s) of the RD activation) is assumed with additional costs of 0.5 € / MWh. A higher amount of redispatch does not lead to any following congestions. Due to the given min. size RD a higher amount of redispatch than necessary to solve the congestion needs to be selected.

• Bid : 10 MW * 5 €/MWh * 1h + 10 MW * 0.5 €/MWh * 1h = 55 € up,1

• Bid up,2 : 20 MW * 2 €/MWh * 1h + 20 MW * 0.5 €/MWh * 1h = 50 €

<!-- page 185 -->

➔ The optimisation will select bid up,2 with 20 MW redispatch for one hour for a total of 50 €.

##### Case 2:

In order to resolve a congestion, redispatch of 5 MW is needed as remedial action from generating unit g for one hour. Power balancing (the determined counterpart(s) of the RD activation) is assumed with additional costs of 1.5 € / MWh. A higher amount of redispatch does not lead to any following congestions.

• Bid up,1 : 10 MW * 5 €/MWh * 1h + 10 MW * 1.5 €/MWh * 1h = 65 €

• Bid up,2 : 20 MW * 2 €/MWh * 1h + 20 MW * 1.5 €/MWh * 1h = 70 €

➔ The optimisation will select bid up,1 with 10 MW leading to a total cost of 65 €.

##### Case 3:

In order to resolve a congestion, redispatch of 5 MW is needed as remedial action from generating unit g for one hour. Power balancing (the determined counterpart(s) of the RD activation) is assumed with no additional costs. Redispatch of above 10 MW leads to following congestions that cannot be removed with further remedial actions.

➔ The optimisation will select bid up,1 with 10 MW leading to a total cost of 50 €.

➔ Using bid is not an option since remaining congestions are generally more expensive up,2 parameterised than the costs of remedial actions.

Business Needs : BN811: RAO-RA_Redispatch_Offer_MVP

Acceptance Criteria :

Given

the RAO has an overloaded XNE in one time stamp on which the loading can be reduced with two available PRA. The first PRA has a power bid with positive available RD volume, the other PRA has a power bid with negative available RD volume. The power bid of the first PRA has a minimum redispatch volume. The penalty costs are parameterized in such a way that eliminating the

congestion of the overloaded XNE by remedial actions leads to a lower objective function value. Activation of the PRA is not restricted by other constraints (power ramps, etc.).

When

the optimisation terminates successfully,

then

both power bids of the PRAs must be activated for at least the minimum redispatch volume and reduce the loading of the XNE. Other constraints can have an influence on the result of the RAO.

<!-- page 186 -->

##### CORNET-3616: Consideration of lead time for Power Bids in preventive mode

The Redispatch Lead time described in CORNET-72: Input data on lead and lag times was specified for one generation unit. The following specification describes the use of this lead time for the available RD volume of each Power Bid and replaces the definition of Redispatch Lead time in CORNET-72.

###### Description

The RAO considers the technical lead time BidLeadTime of a Power Bid from a RD PRA as the duration that operators of one or more generation units need to provide the requested RD volume.

The RA Deciding Point is the first point in time from which the BidLeadTime can be counted. Therefore, the Power Bid is only available in time stamps where:

$$
\mathit{BidLeadTime} + \mathit{RA} \mathit{Deciding} \mathit{Point} (\mathit{RADP}) \leq \mathit{Time} \mathit{Stamp}
$$

The RADP is defined in CORNET-3447 – RA Deciding Point.

###### Configuration

| Name | Description | Unit | Data Type | Time Series/ Constant | Profile |
| --- | --- | --- | --- | --- | --- |
| BidLeadTime | Time needed until the offered RD-bid is available | hour float |  | constant | RA-P: PowerBidSchedule.LeadTime |

<!-- page 187 -->

###### Details / Background

Offer with BidLeadTime = 3h

Active power Available RD Volume

|  |  |  |  |  | BidLeadTime |  |  |  |  |  |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |

Time 22:30 23:30 00:30 01:30 02:30 RADP: Use of PRA RD volume Use of PRA RD Earliest point in not possible in the first volume now time when the two timestamps possible from this PRAs are ordered timestamp onwards Example : The RA Deciding Point is at 22:30 the day before the optimisation timeframe. A Power Bid of a preventive RA has a BidLeadTime of 3h. The earliest use of RD volume from this Power Bid is possible with time stamp “02:30”, which starts at 2:00. An activation and therefore use of the preventive RA on earlier time stamps is not possible because the lead time is still active (“00:30”) or ends within the middle of the time stamp ("01:30”). The RD volume must be fully available within the hour of the time stamp in order to be activated.

Business Needs :

BN861: RAO-RA_Leadtime_Offer: The RAO must consider the lead time of redispatch offers. Use-Cases :

UC119: BUC 14#15 RAO considers the lead time of Power Bids

Acceptance Criteria :

Given

The RAO has RD RA with Power Bids having a BidLeadTime. The RAART and therefore the RADP is set to 22:00.

When

<!-- page 188 -->

The optimisation terminates successfully,

Then

No RD volume must be used from Power Bids for time stamps before or equal to RADP + BidLeadTime. If a BidLeadTime, counted from the RADP, ends within in a time stamp, the use of RD volume is only possible from the beginning of the following time stamp.

##### CORNET-3626: Consideration of a minimum Energy Limit for Power Bids in preventive mode

##### mode

###### Description

The RAO can consider a minimum limitation of the activated CT or RD volume of a Power Bid over the optimisation timeframe considered. This represents an energy limit and could be defined by an owner of a generation unit to offer redispatch with a minimum volume in a certain timeframe. The minEnergyBid defines the minimum total energy that must be ordered from a Power Bid if the Power Bid is activated at least for one timestamp. The definition of a maximum energy limit is also possible (see CORNET-3711: Consideration of a maximum Energy Limit for Power Bids in preventive mode). The energy limitations of the Power Bid are only considered if CT or RD volume is activated from the offer. Otherwise, the given limits are neglected so the RAO does not try fulfil the constraint if not necessary. This is realized by using a binary variable for the activation status of the Power Bid. Only if the Power Bid is used, the minimum energy limit constraint is actively considered within the optimisation.

If no minimum energy limit is given for the Power Bid, the RAO does not consider a minimum energy constraint in the optimisation.

The energy limits are modelled as hard constraints and cannot be exceeded.

###### Configuration

| Name | Description | Unit | Data Type | Time Series/ | Profile |
| --- | --- | --- | --- | --- | --- |
|  |  |  |  | Constant |  |
| minEnergyBid | Minimum total energy that can be activated from the bid | MWh | Float, >=0 | constant | RA-P: PowerBidSchedule. TotalMinimumEnergy |

Business Needs :

<!-- page 189 -->

BN807: RAO-RA_Limit_Energy_offer: The RAO considers the energy limit of redispatch offers Use-Cases :

UC246: BUC 14#18 Considering of Power Bid energy limits in RAO (min)

Acceptance Criteria :

Given

The RAO has RD RA with a minEnergyBid defined in the Power Bids greater than zero.

When

The optimisation terminates successfully,

Then

The sum of the activated RD volume in all time stamps from a single Power Bid must be at least the minEnergyBid value defined in that Power Bid.

##### CORNET-3711: Consideration of a maximum Energy Limit for Power Bids in preventive mode

##### mode

###### Description

The RAO can consider a maximum limitation of the activated CT or RD volume of a Power Bid over the optimisation timeframe considered. This represents an energy limit and could be defined by an owner of a generation unit to offer redispatch with a maximum volume in a certain timeframe, e.g. a hydro power plant with a water reservoir. The maxEnergyBid defines the maximum total energy that can be activated from the Power Bid over all time stamps.

If no maximum energy limit is given for the Power Bid, the RAO does not consider a maximum energy constraint in the optimisation.

The energy limits are modelled as hard constraints and cannot be exceeded.

###### Configuration

| Name | Description | Unit | Data Type | Time Series/ Constant | Profile |
| --- | --- | --- | --- | --- | --- |
| maxEnergyBid | Maximum total energy that can be activated from the bid | MWh | Float, >=0 | constant | RA-P: PowerBidSchedule. TotalMaximumEnergy |

<!-- page 190 -->

Business Needs :

BN807: RAO-RA_Limit_Energy_offer: The RAO considers the energy limit of redispatch offers Use-Cases :

UC325: BUC 14#40 Considering of Power Bid energy limits in RAO (max)

Acceptance Criteria :

Given

The RAO has RD RA with a maxEnergyBid defined in the Power Bids greater than zero.

When

The optimisation terminates successfully,

Then

The sum of the activated RD volume in all time stamps from a single Power Bid must be at maximum the maxEnergyBid value defined in that Power Bid.

##### CORNET-4606: Considered costs of redispatch RA in preventive mode

###### Description

The costs of preventive redispatch are considered via the price for the available active power in each power bid. In the objective function this variable price ($c_{b,\mathit{Price} \mathit{for} \mathit{RD}+}$ and $c_{b,\mathit{Pr} \mathit{ice} \mathit{for} \mathit{RD}-}$) is multiplied with the activated positive or negative redispatch from the power bid and is linked to the marginal costs , e.g. the fuel costs.

This price is defined in the power bid for each given time stamp.

Additionally, the preventive RA can be considered with penalty costs from the input data within the objective function of the RAO (see CORNET-1765: Objective function). These RA specific penalty costs are calculated from the penalty cost factor of the input data ($\mathit{cf}_{b,\mathit{penalty}}$) and the preventive penalty reference value of the RAO ($c_{\mathit{redisp},\mathit{reference}}$).

$$
c_{b,\mathit{Penalty}} = \mathit{cf}_{b,\mathit{penalty}} \cdot c_{\mathit{redisp},\mathit{reference}} \tag{3.59}
$$

###### Configuration

| Name |  | Unit | Data Typ e | Time Series/ Constan t | Profile |
| --- | --- | --- | --- | --- | --- |
|  | Descriptio |  |  |  |  |
|  | n |  |  |  |  |

<!-- page 191 -->

| priceRD | Price of the available preventive redispatch volume | EUR/M W | float | Time series | RA-P: PowerBidScheduleTimePoint.pri ce |
| --- | --- | --- | --- | --- | --- |
| penaltyFactorRA | Penalty cost factor of the redispatch RA for multiplicatio n with preventive penalty reference value of the RAO |  |  | float constant | RA-P |
| penaltyReferenceRD_P RA | Preventive penalty reference value for redispatch per MW | EUR/M W | float > 0 | constant | RAOControlParameterProfile. RAOControlParameterSetForTS O |

###### Details / Background

The RAO takes into account the possible different generation costs of generation units within the OPF. Each active power change of a generation unit in the optimisation enters the objective function as the sum of marginal and penalty costs, whereby the marginal costs (MC) act proportionally to the power change and the penalty costs (PC) act proportionally to the absolute value of the power change. By appropriately parameterising the penalty costs, the user can ensure that there is no pure post- optimisation of the market- based power plant deployment.

Example: The resulting objective function contribution of the power change of a generation unit is shown in the figure below. In this example, it is assumed that the penalty costs for the positive and negative redispatch potential are identical.

<!-- page 192 -->

> **Figure (page 192) — described in text.**
>
> Cost curves plotted against *Change in active power $P_{RD}$ for a generation unit compared to PROD before optimisation* (horizontal axis, positive and negative), with *Objective function contribution* on the vertical axis. Two lines pass through the origin: an orange V-shaped curve labelled $PC \sim |P_{RD}|$ (penalty costs, symmetric — positive for redispatch in either direction) and a blue straight line labelled $MC \sim P_{RD}$ (marginal costs, proportional and signed, so negative for downward redispatch).

Figure: Explanatory illustration for marginal and penalty costs of a generation unit

In a time-coupled optimisation, the sum of all penalty and marginal costs over all generation units and all timestamps to be optimised is included in the objective function. The marginal costs are specified in the internal CorNet data model specifically for each generating unit and each optimisation time stamp (corresponds to time series).

Example : Due to heat extraction, a power plant unit A with marginal costs of 30 €/MW is feeding in active power before optimisation, whereas a power plant B with marginal costs of 20 €/MW does not feed in before optimisation. In an optimisation aimed purely at marginal costs, the active power output of power plant A would be decreased and power plant B would be started, even if this did not avoid a congestion. With penalty costs PC > 5 €/ MW, this behaviour, which is undesirable for a congestion based optimisation approach, can be suppressed.

Example : By parameterizing the penalty costs, different types of generation units can be prioritised with regard to their use for redispatch. For instance, by increasing the penalty costs for renewable generation compared to conventional power plants, a subordination for the use of renewable generation in redispatch can be modelled.

##### Business Needs:

BNXXX

##### Use-Cases:

UC499: BUC 14#49 Consideration of different costs for redispatch PRA

<!-- page 193 -->

Acceptance Criteria :

Given

A PowerBid with an available preventive RD volume is available for a congestion as a PRA.

When

The RAO successfully terminates,

Then

The priceRD multiplied by the activated RD volume must be disclosed, if RD volume of the PowerBid is activated.

Given

A PowerBid with an available preventive RD volume is available for a congestion as a PRA.

When

The RAO successfully terminates,

Then

The final penalty value, which is derived by multiplying by the activated RD volume with the penaltyFactorRA and the penaltyReferenceRD_PRA, must be disclosed, if RD volume of the PowerBid is activated.

##### BUC 14#102 Consideration of Power Bid activation costs

###### Scenario

##### BUC 14#102 Consideration of Power Bid activation costs

The RAO must consider costs for the activation of a Power Bid. These activation costs should be incurred every time for each activated contiguous time stamp range.

###### Description

For each CT and RD Power Bid ( PowerBidSchedule ) an optional price for the activation of that Power Bid can be defined. If any available CT or RD volume of this Power Bid is activated within the RAO, these activation costs are incurring. For activated CT or RD volume in contiguous time stamps the activation costs are considered once for the first time stamp of the time stamp range. Additional activated CT and RD volume in later non-contiguous time stamps results in the additional consideration of activation costs for each continuous time stamp range.

If a bid is activated in the first time stamp of the optimization timeframe, no previous time stamp is available. The activation costs are counted towards this time stamp.

If no CT or RD volume is activated from the Power Bid, no activation costs are applied.

<!-- page 194 -->

For the mathematical mapping of these activation costs a binary state variable for the activation status of the Power Bid is used in each time stamp. These binary variables are different than the binary variable for the activation of Power Bids described in CORNET-3626: Consideration of a minimum Energy Limit for Power Bids in preventive mode . This state variable is together with the corresponding activation costs of the Power Bid part of the objective function (see SF3077: Objective Function).

$$
B_{\mathit{bid} \mathit{activation},b} \in \{0,1\} \tag{1}
$$

###### Assumptions

The activation costs are only incurred for preventive remedial actions. For curative remedial actions the activation costs are not considered in the objective function.

###### Configuration

The following input data is needed for the RAO:

| Name | Description | Unit | Data Type |  | Time | Profile |
| --- | --- | --- | --- | --- | --- | --- |
|  |  |  |  |  | Series/ |  |
|  |  |  |  |  | Constant |  |
| activationCostPB | Activation cost of a Power Bid (optional) | € | double | constant |  | RemedialActio nFlatList: PowerBidSche dule.startupCo st |

The attribute PowerBidSchedule.startupCost is an optional parameter. If no value is provided, a default value of “0” is assumed.

###### Business rules

The activation costs of Power Bids are strictly related to costs incurring from activating a Power Bid. They have no relation to possible start-up costs of generating units (see BUC 14#103 Consideration of start-up costs).

If the activation of a Power Bid with activation costs leads to a start-up of a generating unit, both the start-up costs of the generating unit and the activation costs of the Power Bid must be considered in the objective function of the RAO.

The activation costs of a Power Bid give no indication of the start-up availability for a generating unit connected to the Power Bid via a GLSK.

<!-- page 195 -->

###### Triggers

The activation costs must be available in the data set to be considered. If no activation costs are given for a PowerBidSchedule, the RAO sets the activation costs internally to zero.

The activation costs are only considered for PRA. If Power Bids of CRA have activations costs provided, the RAO will ignore them.

###### Pre-Condition

A RAO run is started successfully via the ROSC umbrella or the RAO UI and the available remedial actions provided to RAO contain at least one available RD or CT remedial action with at least one linked PowerBidSchedule and available RD or CT volume for at least one hour of the day and activationCostPB provided in the PowerBidSchedule(s) is a valid cost greater zero. In addition, a second power bid in the same or a different remedial action that can provide the volume required for the balancing of this remedial action is required as part of the input. The available RD or CT remedial action with the activation cost is selected by RAO to solve a congestion in preventive mode. A successful start of RAO implies that all required data was provided to the RAO run and no technical error occurred.

###### Acceptance Criteria

Given a RAO run is started successfully via the ROSC umbrella or the RAO UI

When the RAO activates a bid from a RD or CT remedial action once for an arbitrary number of sequential hours of the day and the RAO terminates successfully

Then the activation costs are reported in the RemedialActionScheduleProfile ( PowerTimePoint.startUpCosts ) for the first hour in which the bid is active and none of the other hours. The sum of the activation costs for the XRA are reported in RemedialActionCost.otherCost .

Given a RAO run is started successfully via the ROSC umbrella or the RAO UI

When the RAO activates a bid from a RD or CT remedial action more than once for an arbitrary number of sequential hours of the day with an hour between the sequences during which the bid is not active and the RAO terminates successfully

Then the activation costs are reported in the RemedialActionScheduleProfile ( PowerTimePoint.startUpCosts ) for the first hour of each sequence of sequential hours in which the bid is active and none of the other hours. The sum of the activation costs for the XRA are reported in RemedialActionCost.otherCost .

###### Basic Flow

The following log-messages are exposed:

• The activation costs are written to the RAO result log.

<!-- page 196 -->

The activation costs are stored in the RemedialActionScheduleProfile.

###### Alternative Flow

No alternative flow foreseen.

<!-- page 197 -->

#### 3.6.9 Balancing of Redispatch Remedial Actions

##### CORNET-73: Balancing of Redispatch Remedial Actions

###### Description

Due to the possibility of redispatching of generation units, the cumulated fed-in active power into the electrical grid could change. To avoid this kind of behaviour and guarantee a balance between active power generation before and after optimisation, a conformity constraint is added to the optimisation problem (MILP) for each time stamp:

$$
\sum \Delta P_{i} = 0 \tag{3.60}
$$

$\Delta P_{i}$ being the activated amount of the generation unit i

Remedial actions from countertrading will be included in the balancing at a later release.

System Requirement: SRQ841

<!-- page 198 -->

#### 3.6.10 Limiting Redispatch Remedial Actions

##### BUC 14#119 Limiting the number of activated RD PRA per timestamp in RAO

###### Scenario

UC8789: BUC 14#119 Limiting the number of activated RD PRA in each timestamp of the RAO. The maximum number of activated redispatch PRA in each timestamp is limited both individually for each TSO and in total. The limitation is implemented either as a soft constraint or a hard constraint by setting a control parameter. A hard constraint disallows PRAs exceeding the maximum number, a soft constraint penalizes additional redispatch PRAs in the objective function.

###### Description

The number of activated preventive redispatch RAs is limited in each timestamp of the RAO. A constraint for this limitation exists both individually for each TSO ( maxNumRA_TS_TSO ).

The constraints have an upper limit of maxNumRA_TS_TSO for the number of activated preventive redispatch RA ($B_{\mathit{ra},\mathit{TSO}}^{\mathit{RD}}$) assigned to a TSO. A redispatch RA is activated ($B_{\mathit{ra},\mathit{TSO}}^{\mathit{RD}} = 1$), if the available RD volume of at least one of the associated Power Bids is used for redispatch. This constraint exists per TSO and time stamp.

The maximum number of RAs maxNumRA_TS_TSO is a RAO Control Parameter. Because the activation of additional RAs above the limit shall be possible to reduce remaining congestions, the control parameter RAlimitConstraintTS_Soft can be activated to allow exceeding these limits. If it is activated, each additional RA ($A_{\mathit{RA},\mathit{TSO},\mathit{slack}}$) activated is penalised with RAlimit_penalty within the objective function of the RAO.

$$
\sum_{\mathit{ra}\in \mathit{RA}} B_{\mathit{ra},\mathit{TSO}}^{\mathit{RD}} (t) -A_{\mathit{RA},\mathit{TSO},\mathit{slack}} (t) \leq \mathit{maxNumRA}_{\mathit{TS}\_\mathit{TSO}} \forall t\in [1, T]
$$

If the constraint is considered as a hard constraint in the RAO, $A_{\mathit{RA},\mathit{TSO},\mathit{slack}}$ is not needed.

$$
\sum_{\mathit{ra}\in \mathit{RA}} B_{\mathit{ra},\mathit{TSO}}^{\mathit{RD}} (t) \leq \mathit{maxNumRA}_{\mathit{TS}\_\mathit{TSO}} \forall t\in [1, T]
$$

With

$$
T: \mathit{Number} \mathit{of} \mathit{considered} \mathit{time} \mathit{stamps}
$$

###### Configuration

The following input data is needed for the RAO:

<!-- page 199 -->

| Name | Description | Unit | Data Type |  | Time | CoMo-Profile |
| --- | --- | --- | --- | --- | --- | --- |
|  |  |  |  |  | Series/ |  |
|  |  |  |  |  | Constant |  |
| RAlimitConstraintT S_Soft | Control parameter that allows exceeding the maximum number of redispatch RAs with additional penalty costs. | - | boolean | constant |  | RAOControlPa rameterProfile: RAOControlPa rameterSet.RAl imitConstraintT SSoft |
| RAlimit_penalty | Penalty cost for activation of additional redispatch RAs above maxNumRA_TS or maxNumRA_TS_TSO. | €/RA float |  | constant |  | RAOControlPa rameterProfile: RAOControlPa rameterSet.pen altyRAlimit_TS |
| maxNumRA_TS_T SO | Maximum number of redispatch RAs defined per TSO that can be activated without additional penalty costs per timestamp and TSO. Default: empty |  | integer | constant |  | RAOControlPa rameterProfile: RAOControlPa rameterSetFor TSO.maxNum RA_TS |

###### Business Rules

If no penalty cost RAlimit_penalty is given while the control parameter RAlimitConstraintTS_Soft is activated, the penalty cost is set to zero in the RAO run.

If no maxNumRA_TS_TSO is given, an unlimited amount of RD RA can be activated for the TSO in the timestamp.

###### Triggers

The RAO is started successfully and all pre-conditions are met.

###### Pre-Condition

The RAO Control Parameters must be set to trigger the limit constraints.

The setting RAlimitConstraintTS_Soft must be activated to trigger the constraints as soft. If the setting is not activated, maxNumRA_TS_TSO is a hard limit by default. If limits are to be considered (either soft or hard), maxNumRA_TS_TSO must be defined.

<!-- page 200 -->

At least one correctly defined assessed element is part of the AE-FlatList.

The initial load-flow converged.

###### Acceptance Criteria

Given

The RAO has several RD PRA, a defined maxNumRA_TS_TSO limit and the control parameter RAlimitConstraintTS_Soft is set to false.

When

The optimisation terminates successfully,

Then

The number of activated RD PRA by the RAO per timestamp does not exceed maxNumRA_TS_TSO for any TSO.

Given

The RAO has several RD PRA and a defined maxNumRA_TS_TSO limit with a set RAlimit_penalty . Additionally, the control parameter RAlimitConstraintTS_Soft is activated.

When

The optimisation terminates successfully,

Then

The number of activated RD PRA by the RAO in each timestamp could exceed maxNumRA_TS_TSO for any TSO , but RD PRA exceeding maxNumRA_TS_TSO are penalized in the objective function.

###### Basic Flow

No log messages are exposed.

###### Alternative Flow

No alternative flow is foreseen.

##### CORNET-3649: Limitation of the activated RD Remedial Actions per optimisation timeframe

##### timeframe

###### Description

To achieve an implementable solution for the operator, the number of activated preventive redispatch RAs is limited over the optimisation timeframe of the RAO. A constraint for this limitation exists individually for each TSO.

<!-- page 201 -->

The constraints have an upper limit of maxNumRA_TSO for the number of activated preventive redispatch RA ($B_{\mathit{ra},\mathit{TSO}}$) assigned to a TSO. A redispatch RA is activated ($B_{\mathit{ra},\mathit{TSO}} = 1$), if at least from one of the associated Power Bids available RD volume is used for redispatch.

The maximum number of RAs maxNumRA_TSO is a RAO Control Parameter and can be defined per TSO. Because the activation of additional RAs above the limit shall be possible in order to reduce remaining congestions, the constraint is modelled as a soft constraint.

$$
\sum_{\mathit{ra}\in \mathit{RA} t\in \mathit{OT}} B_{\mathit{ra},\mathit{TSO}} (t) -A_{\mathit{RA},\mathit{TSO},\mathit{slack}} \leq \mathit{maxNumRA}\_\mathit{TSO}
$$

This constraint exists per TSO and optimisation timeframe. Each additional RA ($A_{\mathit{RA},\mathit{TSO},\mathit{slack}}$) activated above maxNumRA is penalised with RAlimit_penalty within the objective function of the RAO.

###### Configuration

| Name | Description | Units | Data type | Time series/ constant | Profile |
| --- | --- | --- | --- | --- | --- |
| RAlimit_penalty | Penalty cost for activation of additional redispatch RAs above maxNumRA. | €/RA | integer | constant | RAO Control Parameter |
| maxNumRA_TSO | Maximum number of redispatch RAs that can be activated without additional penalty costs per optimisation timeframe. Can be defined for each TSO. |  | integer | constant | RAO Control Parameter |

##### Business Needs:

BN871: RAO-RA_Limit_RD_Advanced

Use-Cases :

UC277: BUC 14#27 Limiting the number of activated RD RA during the optimisation timeframe in RAO

<!-- page 202 -->

Acceptance Criteria :

Given

The RAO has several RD RA and a defined maxNumRA_TSO limit with a very high (maximum value) RAlimit_penalty (like a hard constraint).

When

The optimisation terminates successfully,

Then

The number of activated RD RA over the optimisation timeframe by the RAO should not exceed maxNumRA_TSO .

Given

The RAO has several RD RA and a defined maxNumRA_TSO limit with a normal RAlimit_penalty . When

The optimisation terminates successfully,

Then

The number of activated RD RA over the optimisation timeframe by the RAO could exceed maxNumRA_TSO .

##### CORNET-4838: Limitation of Redispatch and Countertrade for Remedial Action Groups for PRAs

##### for PRAs

###### Description

Use Case : The RAO shall consider available limits for the sum of positive RD and/or CT volume and the sum of negative RD and/or CT volume independently when the RA are part of the same Remedial Action Group.

The RAO considers limitations of the activated upwards and downwards RD and CT volume. These limitations of PowerRemedialActions are defined with a RemedialActionGroup and its attributes maxRegulatingDown and maxRegulatingUp . These attributes define for each time stamp the maximum net amount of active power that can either be regulated down or up over all PowerRemedialActions of the RemedialActionGroup . These attributes are only considered for the RA of the group whose kind of the RemedialActionDependency ( RemedialActionDependencyKind ) is set to restrictive .

$$
\sum_{b\in \mathit{PB}} \Delta P_{b,t_{i}}^{+} \leq \mathit{maxRegulatingUp}_{t_{i}} \forall t_{i} \in \mathit{OT} \tag{1}
$$

<!-- page 203 -->

$$
\sum_{b\in \mathit{PB}} \Delta P_{b,t_{i}}^{-} \leq \mathit{maxRegulatingDown}_{t_{i}} \forall t_{i} \in \mathit{OT} \tag{2}
$$

The sum of the activated upwards preventive adjustment ($\Delta P_{b}^{+}$) for all PowerBids linked via RA to a RemedialActionGroup must be less or equal to maxRegulatingUp in each time stamp.

The sum of the activated downwards preventive adjustment ($\Delta P_{b}^{-}$) for all PowerBids linked via RA to a RemedialActionGroup must be less or equal to maxRegulatingDown in each time stamp.

Example : A TSO wants to limit the activated active power amount for a bidding zone. To achieve this limitation, all PowerRemedialAction of this bidding zone must be part of the same single RemedialActionGroup . The RADependencyKind must be set to restrictive for all these RA. This

###### Configuration

maxRegulatingDown and maxRegulatingUp limits.

###### Configuration

| Name | Description Unit |  | Data type | Time series / Constant | Profile |
| --- | --- | --- | --- | --- | --- |
| RemedialAction DependencyKind | Type of dependency between remedial actions |  |  | string Constant | RA-Profile: RemedialActionDependency.kind |
| maxRegulatingDown | Maximum net amount of active power that the group of remedial actions can regulate down. |  | MW Float | Time series | SSI-Profile: RemedialActionGroup.maxRegulatingDown |
| maxRegulatingUp | Maximum net amount of active power that |  | MW Float | Time series | SSI-Profile: RemedialActionGroup.maxRegulatingUp |

<!-- page 204 -->

|  | the group of remedial actions can regulate up. |  |  |  |  |
| --- | --- | --- | --- | --- | --- |

Note : The RemedialActionDependencyKind is currently not considered in RAO, except for HVDC connections (see CORNET-4621: Consideration of HVDC Setpoint changes in preventive mode).

##### Business Needs:

BN 862: RAO-RA_Limit_BiddingZone: The RAO must consider the given limits for the up and downward volume per bidding zones

##### Use-Cases:

UC 862: BUC 14#97 Limitation of Redispatch and Countertrade for Remedial Action Groups for PRAs

##### Acceptance Criteria:

Given

The RAO has CT and RD PRA with Power Bids grouped as a RA group with the RemedialActionDependencyKind restrictive and values for maxRegulatingDown.

When

The optimisation terminates successfully,

Then

The net amount of downwards active power that the group of PRA has activated is equal or below maxRegulatingDown.

Given

The RAO has CT and RD PRA with Power Bids grouped as a RA group with the RemedialActionDependencyKind restrictive and values for maxRegulatingUp.

When

The optimisation terminates successfully,

Then

The net amount of downwards active power that the group of PRA has activated is equal or below maxRegulatingUp.

<!-- page 205 -->

#### 3.6.11 HVDC Remedial Actions

##### BUC 14#55 RAO considers HVDC PRAs modelled as Equivalent Injections

###### Scenario

##### BUC 14#55 RAO considers HVDC PRAs modelled as Equivalent Injections

The RAO shall consider point-to-point HVDC connections and determine new active power setpoints of the HVDC converters. The HVDC connections are modelled as redispatch units and part of a RA group.

###### Assumptions

HVDC connections are modelled via equivalentInjection in the CGM input data. Each converter consists either of one equivalentInjection for jointly operating active and reactive power, or two separate equivalentInjection . One unit represents the flexible setpoint change of the active power, whereas the other unit represents the flexible range of the reactive power.

An equivalentInjection representing HVDC must be identifiable by being connected to a cim:ConnectivityNode in EQ-BD-Profile and the description attribute of these objects must have “HVDC” in the beginning.

The CGMES input data is using load sign convention. The RAO changes this to generation sign convention when importing the data.

The modelling of a HVDC line via an AC-line or a DC-line must not be done.

The possible active power setpoint range for the HVDC converters is delivered via a GridStateAlterationRemedialAction . The actionType of the GridStateAlteration must be set as equivalenInjectionAction .

The reactive power cannot be set during the optimisation and is therefore determined by the LF calculation because of the voltage regulation target.

The balanced RA group for the two equivalent injections representing the HVDC converters must not contain other RA which are linked to other generating units. This could result in an unbalanced DC- system if other generating units are part of the balancing. This must be carefully modelled by the TSO because such linkage errors will not be detected by the RAO validation.

<!-- page 206 -->

###### Description

The RAO can consider point-to-point HVDC connections as a RA. Because CGMES v2.4.15 used for the input data is not fully compatible with the necessary HVDC equipment (Figure 9a), the input data is providing the information of the HVDC converter via equivalentInjection instead (Figure 1b). These equivalentInjections are converted to generating units within the RAO (see Figure 9c).

a) AC/DC AC/DC

Converter 1 Converter 2

##### =

##### ~ ~

##### =

EI 1 for EI 2 for

b) active power active power

c) GU 1 GU 2

##### ~ ~

RA Group

Figure 9: a) standard modelling of point-to-point HVDC connection b) modelling of the active power of HVDC connection via equivalent injections (EI) c) simplified modelling for the active power of HVDC connection via two generating units (GU) in RAO

Each HVDC converter of the connection is modelled via a generating unit. The P max and P min values of these generating units are the maximum and minimum setpoint values of the converters. Due to possible power flow reversals on the HVDC connection, the P min value can be negative. The active power injection (P 0 ) of the generating unit is defined as follows in the RAO (generation sign convention): • Positive value: the absolute value is the active power injection from the DC-system into the AC- system.

• Negative value: the absolute value is the active power injection from the AC-system into the DC-system.

With the assumption that the transmission capacity of a HVDC branch is at least equal to the transmission capacity of the connected converters, the HVDC branch does not have to be modelled explicitly.

<!-- page 207 -->

The available setpoint changes for each converter are defined in a RangeConstraint of a GridStateAlteration . In valueKind the setpoint change can be defined as either an absolute setpoint limit ( absolute ) or a relative limit ( incremental ) from the current operating point before RAO with the value . The direction of the setpoint change is defined in the attribute direction .

In the GridStateAlteration the powerSystemResourceMrid contains the MRID of the equivalentInjection .

In order to remain the power balance within the DC-system when changing setpoints, each equivalentInjection must be linked to separate GridStateAlterations , which are linked to a GridStateAlterationRemedialAction . These RAs must be part of the same RA group ( RemedialActionGroup ) and the RemedialActionDependency.kind of the RA group must be set to “ balanced ”. This ensures that the active power change at one generating unit (representing converter one (g 1 )) is balanced at the other generating unit (representing converter two (g 2 )) with the same absolute value and the opposite direction in each time stamp. $\Delta P_{\mathit{HVDC},g_{1}}^{+}$ is representing the positive $active power setpoint change of g_{1}$ and $\Delta P_{\mathit{HVDC},g_{1}}^{-}$ is representing the negative active power setpoint $change of g_{1}$. The same applies for $\Delta P_{\mathit{HVDC},g_{2}}^{+}$ and $\Delta P_{\mathit{HVDC},g_{2}^{2}}^{-}$, which represent g. This balancing constraint must be met in each time stamp, for preventive as well as curative mode.

$$
(\Delta P_{\mathit{HVDC},g_{1}}^{+} + \Delta P_{\mathit{HVDC},g_{1}}^{-} ) -(\Delta P_{\mathit{HVDC},g_{2}}^{+} + \Delta P_{\mathit{HVDC},g_{2}}^{-} ) = 0 \tag{3.61}
$$

Note : The balanced RA group for the two generating units representing the HVDC converters must not contain other RA which are linked to other generating units. This could result in an unbalanced DC- system if other generating units are part of the balancing. This must be carefully modelled by the TSO because such linkage errors will not be detected by the RAO validation.

###### Outlook

With the change in modelling the HVDC connection as originally intended in CGMES 3.0 or newer, the loadflow calculation will be able to calculate the losses of the DC-system. Contingencies of either a converter or HVDC branch can also be considered within the FOA with this changed modelling. This will also open the possibility to model Multi-Terminal HVDC systems.

As a workaround, HVDC contingencies can be modelled via the outage of both equivalent injections representing the HVDC converter. In a future release the detailed modelling of the contingencies will be implemented (see SF3072).

HVDC connections can also be used as CRA in a future release.

<!-- page 208 -->

Modelling of internal HVDC lines will be part of future release.

###### Configuration

The following input data is needed for the RAO:

| Name | Description | Unit | Data Type | Time Series/ Constant |
| --- | --- | --- | --- | --- |
| actionType | Only the type equivalentInjectionAction is considered for HVDC | - |  | enum Constant |
| description | Only when the description of the Terminal or ConnectivityNode connected with the EquivalentInjection starts with “HVDC”, the unit is considered | - |  | string Constant |
| maximumSetpoint | Technical maximum setpoint of the unit | - |  |  |
| minimumSetpoint | Technical minimum setpoint of the unit | - |  |  |
| highSetpointAbsolute | Absolute maximum operating setpoint of the unit | - | Float | Time series |
| lowSetpointAbsolute | Absolute minimum operating setpoint of the unit | - | Float | Time series |

##### CoMo-Profile

RemedialActionFlatList: GridStateAlteration::actionType cim:Terminal.description cim:ConnectivityNode.description Float Constant cim:EquivalentInjection.maxP Float Constant cim:EquivalentInjection.minP RemedialActionFlatList: GridStateAlteration → RangeConstraint::direction.up RangeConstraint::valueKind.absolute RangeConstraint::value RemedialActionFlatList: GridStateAlteration → RangeConstraint::direction.down RangeConstraint::valueKind.absolute RangeConstraint::value

<!-- page 209 -->

| highSetpointRelative | Relative positive setpoint change of the unit based on initial setpoint | - | Float | Time series |
| --- | --- | --- | --- | --- |
| lowSetpointRelative | Relative negative setpoint change of the unit based on initial setpoint | - | Float | Time series |
| RAGroupID | Remedial Action group. Must be the same for balancing two RA. | - |  | String constant |
| RemedialAction DependencyKind | Type of dependency between two RA. Must be “balanced” for HVDC connections. | - |  | enum constant |

RemedialActionFlatList: GridStateAlteration → RangeConstraint::direction.up RangeConstraint::valueKind.incremen RangeConstraint::value RemedialActionFlatList: GridStateAlteration → RangeConstraint::direction.down RangeConstraint::valueKind.incremen RangeConstraint::value RemedialActionFlatList: RemedialActionGroup.mrid RemedialActionFlatList: RemedialActionDependency.kind The direction “upAndDown” could also be used alternatively.

###### Business Rules

The equivalentInjection (see Assumptions) representing each converter, are converted into generating units within the internal RAO grid model. If one HVDC side is modelled via two separate equivalentInjection , two generating units are created, each connected to the same busbar as the equivalentInjection .

The one modelling the active power has a minimum/maximum reactive power limit of zero and voltage control is deactivated.

Regulation is not enabled: the reactive power is kept constant.

Regulation is enabled: The EI modelling the reactive power has a minimum/maximum reactive power ( minQ / maxQ ) set from the information in the equivalentInjection and the regulationCapability activated. The regulationTarget is used for the target voltage. The ReactiveCapabilityCurve must also be respected. The active power is set to zero.

In order to change not all equivalentInjection into generating units, only equivalentInjection defined as HVDC as described under Assumptions are converted.

<!-- page 210 -->

Because a curative use of HVDC RA is currently not foreseen, the GridStateAlterationRemedialAction must have the kind::preventive .

The RAO considers per HVDC converter side in each time stamp only one RangeConstraint per direction . The setpoint range for a time stamp can either be defined by one single RangeConstraint with the direction “upAndDown” or two separate RangeConstraint with one being defined as “up” and the other as “down”. If more than one RangeConstraint with the same direction exists for a time stamp, RAO uses the RangeConstraint with the lowest setpoint range.

Only RangeConstraint with propertyRangeType::static are considered by the RAO.

The technical setpoint limits of the equivalentInjection cannot be exceeded during the RAO. The RAO validates therefore the possible operational setpoint limits via a RangeConstraint with the technical setpoint limits.

$$
\mathit{HVDCMaxOperating}= \min (\mathit{maximumSetpoint}, h\mathit{ig}h\mathit{SetpointAbsolute}) \\
\mathit{HVDCMinOperating}= \max (\mathit{minimumSetpoint}, \mathit{lowSetpointAbsolute})
$$

Or with relative setpoint changes:

$\mathit{HVDCMaxOperating}= \min (\mathit{maximumSetpoint}, P_{\mathit{HVDC},0} (t) + h\mathit{ig}h\mathit{SetpointRelative})$ $\mathit{HVDCMinOperating}= \max (\mathit{minimumSetpoint}, P_{\mathit{HVDC},0} (t) -\mathit{lowSetpointRelative})$

Because of the simplified modelling of a HVDC connection with two generating units, the RAO cannot calculate the losses incurring during operation.

Because of the simplified modelling of a HVDC connection with two generating units the RAO can only consider a contingency of the complete HVDC connection.

No gradient is considered for the setpoint change of the units.

###### Triggers

A certain contingency situation requires the usage of HVDC PRA to counteract overloads

###### Pre-Condition

Two equivalentInjection in the CGM must be linked to a GridStateAlteration each with a GridStateAlterationRemedialAction .

###### Acceptance Criteria

Given

<!-- page 211 -->

The RAO has a RA group for two preventive GridStateAlterationRA with linked equivalenInjection via GLSK and the RemedialActionDependency.kind set to balanced.

When

The optimisation terminates successfully,

Then

The amount of the positive setpoint change of one generating unit must be equal to the negative setpoint change of the other generating unit and must be within the operational and technical setpoint limits.

Given

The RAO has a RA group for two curative GridStateAlterationRA with linked equivalenInjection via GLSK and the RemedialActionDependency.kind set to balanced.

When

The optimisation terminates successfully,

Then

The amount of the positive setpoint change of one generating unit must be equal to the negative setpoint change of the other generating unit for the contingency and must be within the operational and technical setpoint limits.

###### Basic Flow

The following log-messages are exposed during the initialization of the internal data model:

• Considered equivalent injections to model HVDC converter

The HVDC setpoint changes must be added to the RAO result log file and the RemedialActionSchedule (see SF3079: GridStateIntensitySchedule Optimisation results).

###### Alternative Flow

No alternative flow foreseen.

<!-- page 212 -->

##### BUC 14#109 Costs of HVDC Setpoint changes

###### Scenario

##### BUC 14#109 Costs of HVDC Setpoint changes

The RAO must consider costs for the preventive or curative setpoint changes of a HVDC converter. This will be done via the RA penaltyFactor and a penalty reference value, which is specific for preventive and curative.

###### Assumptions

The setpoint change of a HVDC converter is considered as a non-costly XRA.

###### Description

The costs for the preventive and curative HVDC setpoint changes are considered via penalty costs from the input data within the objective function of the RAO (see SF3077: Objective function). For the preventive case, these RA specific penalty costs $c_{h\mathit{vdc}}$ are calculated from the penalty cost factor of the input data $\mathit{cf}_{h\mathit{vdc},\mathit{penalty}}^{\mathit{prev}}$ (RAPenaltyFactor) and the preventive penalty reference value for HVDC of the RAO $c_{\mathit{HVDC},\mathit{reference}}^{\mathit{prev}}$. The RA specific penalty costs must be multiplied with the determined setpoint change of the RA in the objective function.

$$
c_{h\mathit{vdc}} = \mathit{cf}_{h\mathit{vdc},\mathit{penalty}}^{\mathit{prev}} \cdot c_{\mathit{HVDC},\mathit{reference}}^{\mathit{prev}} \tag{3.62}
$$

For the curative case, these RA specific penalty costs $c_{h\mathit{vdc}}$ are calculated from the penalty cost factor of the input data $\mathit{cf}_{h\mathit{vdc},\mathit{penalty}}^{\mathit{cur}}$ (RAPenaltyFactor) and the curative penalty reference value for HVDC of the RAO $c_{\mathit{HVDC},\mathit{reference}}^{\mathit{cur}}$. The RA specific penalty costs must be multiplied with the

determined setpoint change of the RA in the objective function.

$$
c_{h\mathit{vdc}} = \mathit{cf}_{h\mathit{vdc},\mathit{penalty}}^{\mathit{cur}} \cdot c_{\mathit{HVDC},\mathit{reference}}^{\mathit{cur}} \tag{3.63}
$$

Because each side of the HVDC connection has its own GridStateAlterationRemedialAction for the available setpoint changes (see BUC 14#55) with independent penaltyFactor , the penalty costs are calculated and applied for each converter side of the connection.

###### Outlook

With the change in modelling the HVDC connection as originally intended in CGMES 3.0 or newer, the associated costs to a HVDC converter setpoint could change.

###### Configuration

The following input data is needed for the RAO:

<!-- page 213 -->

| Name | Description | Unit | Data Type |  | Time |  | CoMo-Profile |
| --- | --- | --- | --- | --- | --- | --- | --- |
|  |  |  |  |  | Series/ |  |  |
|  |  |  |  |  | Constant |  |  |
| RAPenaltyFacto r | Penalty cost factor of the RA for the setpoint change of a HVDC converter. Must be multiplied with either the preventive or curative penalty reference value of the RAO. |  | float | constant |  |  | RemedialActionFlatList: RemedialAction::penalty Factor |
| PenaltyReferen ceHVDC_PRA | Preventive penalty reference value for HVDC for each setpoint change | €/M W | float | constant |  |  | RAOControlParameterPr ofile: RAOControlParameterS et.penaltyReferenceHVD C_PRA |
| PenaltyReferen ceHVDC_CRA | Curative penalty reference value for HVDC for each setpoint change | €/M W | float | constant |  |  | RAOControlParameterPr ofile: RAOControlParameterS et.penaltyReferenceHVD C_CRA |

###### Business Rules

If no penaltyFactor is given in the RemedialAction , the RAPenaltyFactor is set to zero.

Additional costs for HVDC in preventive or curative mode are not considered.

###### Triggers

The RAO started successfully and all pre-conditions are met.

###### Pre-Condition

• All relevant input data is delivered, see BUC 14#55 RAO considers HVDC PRAs modelled as Equivalent Injections.

• At least one correctly defined assessed element is part of the AE-FlatList.

• The initial loadflow converged.

<!-- page 214 -->

###### Acceptance Criteria

Given

The RAO uses a RA group for HVDC units to change the setpoints in preventive mode.

When

The optimisation terminates successfully,

Then

The sum of the HVDC penalty must be equal to the corresponding setpoint change multiplied with the RAPenaltyFactor and the PenaltyReferenceHVDCprev.

Given

The RAO uses a RA group for HVDC units to change the setpoints in curative mode.

When

The optimisation terminates successfully,

Then

The sum of the HVDC penalty must be equal to the corresponding setpoint change multiplied with the RAPenaltyFactor and the PenaltyReferenceHVDCcur.

###### Basic Flow

The following results are exposed:

• The HVDC penalty costs are written to the RAO results, see SF3079: GridStateIntensitySchedule Optimisation results.

###### Alternative Flow

There is no alternative flow foreseen.

<!-- page 215 -->

### 3.7 Special Protection Schemes

#### BUC 14#131 Read input of SPS

##### Scenario

#### BUC 14#131 Read input of SPS

The RAO must be able to read the SPS-FlatList.

##### Assumptions

The RAO will get a SPS-FlatList for each time stamp.

##### Description

The available SPS must be delivered to RAO via the SPS-FlatList. This file contains the information on the available SPS in the corresponding time stamp.

Coordinable SPS are linked to a SchemeRemedialAction , whereas non-coordinable SPS are not linked to a RA. This characteristic is used by the RAO to differentiate the two SPS types.

##### Configuration

The configuration is described in the following UC:

• BUC 14#111 Non-Coordinable SPS related to a contingency

##### Business Rules

The information of the SpsFlatList is saved within the internal RAO data model.

##### Triggers

The RAO started successfully and all pre-conditions are met.

##### Pre-Condition

All relevant input data is delivered in the correct format, see Configuration.

• Coordinable SPS are linked to a SchemeRemedialAction .

• Non-coordinable SPS are not linked to a RA.

##### Acceptance Criteria

Given

The RAO is started and a SPS-FlatList containing SPS is available for the time stamp to be calculated. When

The RAO successfully initialised the input data,

Then

<!-- page 216 -->

The SPS must be known by the RAO and applied if the trigger conditions are met.

##### Basic Flow

The following log-messages are exposed:

• SPS which are not considered yet as information.

##### Alternative Flow

The SPS with incomplete input data is logged with the MRID and information on missing input data and the RAO is cancelled.

<!-- page 217 -->

#### BUC 14#111: Non-Coordinable SPS related to a contingency

##### Scenario

#### BUC 14#111: Non-Coordinable SPS related to a contingency

The RAO must consider a basic SPS scenario. The basic SPS scenario is a non-coordinable SPS with one trigger (Contingency) and one action (opening of a switch).

The non-coordinable SPS related to a contingency are applied in RAO after the initial AC load-flow calculation (see BPMN at the beginning of the document). The action (opening of a switch) is applied to the corresponding contingency (the trigger), so the following contingency calculation already considers the changed grid topology.

##### Assumptions

Coordinable SPS are linked to a SchemeRemedialAction .

Non-coordinable SPS are not linked to a RA.

The non-coordinable SPS has only one trigger (PinContingency) and one action ( topologyAction ).

##### Description

Special Protection Schemes (SPS) are automatic actions which are activated when certain situations are triggered. A SPS is defined as a RemedialActionScheme . They consist of one or more Stages that can trigger and execute each a protection action.

Each Stage is connected via a StageTrigger and a Gate to a trigger ( PinContingency ). The trigger is activated when the contingency situation occurs.

The difference between coordinable and non-coordinable SPS is made with the relation to a RA class. Coordinable SPS have a relation to SchemeRemedialAction . Non-Coordinable SPS have no relation to a RA class.

The Stage is linked with the action, which is a GridStateAlterationCollection , via the MRID. The connected GridStateAlteration contains the actionType and the MRID to the powerSystemResource . When the contingency occurs, the topologyAction (switch opening) is activated.

The RAO applies the SPS before the calculation of the contingency situation. Therefore, the results of the contingency calculation for that specific contingency are with the SPS taken into account. The RAO uses the FCC when calculating contingency situations with non-coordinable SPS.

<!-- page 218 -->

##### Outlook

Future releases will consider advanced non-coordinable SPS. Several Stages and therefore different triggers and conditions will be possible, as well as several actions. These actions could be coming from generating units, transformers or other equipment.

Additionally, coordinable SPS will be possible.

##### Configuration

The following input data is needed for the RAO:

| Name | Description | Unit | Data Type | Time Series/ Constant | CoMo-Profile |
| --- | --- | --- | --- | --- | --- |
| gridStateAlterati onCollectionMrid | MRID of the action (switch opening) | - | String | Time Series | SPSFlatList: ProtectionScheme -> Stage.gridStateAlterationC ollectionMrid |
| contingencyMrid | MRID of the trigger (contingency) | - | String | Time Series | SPSFlatList: Gate -> PinContingency: contingencyMrid |
| changeType | Type of the action (e.g. switch.open) | - | ChangeType Time Series |  | SPSFlatList: GridStateAlterationCollecti on -> GridStateAlteration.actionT ype |
| equipmentMrid | MRID of the equipment for the action | - | string | Time Series | SPSFlatList: GridStateAlterationCollecti on -> GridStateAlteration.powerS ystemResourceMrid |

<!-- page 219 -->

> **Figure (page 219) — described in text.**
>
> UML class diagram, titled *CorNET_CSA_UC_RA_SPS_002*, of the CGMES data model for a non-coordinable SPS related to a contingency. A description box at the top left reads: *Non-Coordinable SPS related to a Contingency — Simple Non-coordinable SPS with 1 trigger (contingency) and 1 action (opening of a switch).*
>
> Classes and associations: **RemedialActionScheme** «NC» (a PowerSystemResource) with attributes *kind: RemedialActionSchemeKind* and *normalArmed: Boolean*, referenced from **Stage** «NC» (an IdentifiedObject) with attribute *priority: Integer*. Stage points left to **GridStateAlterationCollection** «NC», which is realised by **TopologyAction** «NC», which is realised by **StaticPropertyRange** «NC». Below Stage: **StageTrigger** «NC» (attributes *normalArmed: Boolean*, *priority: Integer*) → **Gate** «NC» (attribute *kind: GateLogicKind*) → **PinContingency** «NC».
>
> Green annotation boxes: *Used as a connection point to Stage* (on GridStateAlterationCollection); *Action (switch opening) which shall happen in case the Contingency appears* (on TopologyAction/StaticPropertyRange); *Each Stage can cause different actions* (on Stage); *Tripping of a line* (on StageTrigger); *"AND", but only one real trigger, so nothing to connect* (on Gate); *SPS is triggered when Contingency appears* (on PinContingency).

Figure 10 Data-model of non-coordinable SPS related to a contingency (NC-Profile)

##### Business Rules

The RAO considers only SPS with no relation to a RA class ( SchemeRemedialAction ), because these are defined as non-coordinable SPS. RAO does not optimise non-coordinable SPS during the process. The SPS must have only one Stage and the Gate.kind attribute must be set to and . For non-coordinable SPS the RemedialActionScheme.kind attribute must be set as sips . The trigger for that one stage must be a contingency situation ( PinContingency ). The linked GridStateAlteration.actionType must be a topologyAction . If the RAO receives such a SPS, the topology action of the SPS will be applied to all COs which include the contingency linked under the PinContingency .

Other SPS are not considered by the RAO. They are logged and discarded.

The RAO applies the SPS before the calculation of the contingency situation. Therefore, the results of the contingency calculation for that specific contingency are with the SPS taken into account.

<!-- page 220 -->

The RAO uses the FCC when calculating contingency situations with non-coordinable SPS.

##### Triggers

The RAO started successfully and all pre-conditions are met.

##### Pre-Condition

All relevant input data is delivered, see Configuration.

At least one correctly defined assessed element is part of the AE-FlatList.

The initial loadflow converged.

##### Acceptance Criteria

Given

The RAO calculates a contingency situation and a SPS is available and has that contingency linked as a trigger.

When

The RAO contingency calculation is finished.

Then

The resulting flows of the contingency situation must be the ones with the SPS (opening of a switch) applied.

##### Basic Flow

The results of SPS are exported via the RAOResultsProfile (see BUC 14#153 Results for SPS).

##### Alternative Flow

The SPS with incorrect input data is logged with the MRID and information on missing input data and the RAO is cancelled. E.g.: The SPS cannot be applied because the switch is not available in the data model.

<!-- page 221 -->

### 3.8 Network Elements

Within the RAO, especially in the FOA and the building / solving of the MILP different kinds of branches as network elements can be considered.

• Excluded elements : The loading of a branch is not relevant, regardless if the branch is overloaded or not. This branch is therefore defined as excluded

• Scanned elements : The loading of a branch is relevant, but a possible overload shall not be relieved with available RAs or worsened within the RAO. The branch is therefore observed and via constrains also considered within the MILP. These branches are defined as scanned elements.

• Cross-border relevant Network Elements (XNEs) : The loading of a branch is relevant. If the branch is overloaded, the RAO shall determine RAs to reduce the loading to or below the permissible loading. This branch is therefore observed and via constrains also considered within the MILP.

#### 3.8.1 Consideration of Congestions

##### CORNET-32: Consideration of XNEs

###### Description

The compliance with the permissible currents for all assessed elements in all relevant contingencies (N-X cases) and in the base case (N-0) case must be considered as a constraint for the optimisation problem (in Release 1.1 only secured elements (XNE) will be considered).

In the input data, assessed elements are defined for the optimisation in accordance with CORNET- XX - RAO Input Data - Assessed Elements.

The optimisation checks with the help of a load flow calculation (according to CORNET-97 - Load Flow Computations on a grid model) and an outage calculation (according to CORNET-26 - Fast outage approximation) the loading of the assessed elements in the base case (N-0) and considered contingencies (N-X cases) (see CORNET-84 - RAO Input Data - Contingencies).

A thermal limit can be defined in the input data for each assessed element for the N-0 and N-X case. This admissible transmission loading value is the PATL (considered in R1.1) value. Within the RAO a loading limit can be calculated. This loading limit equals 100% in R1.1 and the maximum loading is therefore equal to the PATL value. In later releases a deviation from this approach could be possible by considering additional security margins in the maximum loading limit.

The loading on an element is calculated with dividing the current on the element by the PATL. Due to the usage of an AC load flow calculation, the loading of an assessed element can be different at the

<!-- page 222 -->

front and the end of the element. Therefore, the higher utilised side of an element is always used as the loading within the optimisation.

###### Configuration

Data requirements for calculation of loading limits of assessed elements in N-0 and N-X case:

|  | Name Description | Units | Data type | Time series/ constant | Data object | CGMES-Object | Profile |
| --- | --- | --- | --- | --- | --- | --- | --- |
| PATL | permanent admissible transmission loading (N-0/N-X) | % or A | floating point | time series | current limit | Cim:CurrentLimit | Equipment Profile |

System Requirement: SRQ842

##### CORNET-1790: Consideration of XNEs in MILP

###### Description

Constraints for the loading of XNEs are added to the optimisation problem (MILP) (see CORNET-12 – RAO procedure, Figure 2, Module “Build MILP”) as described below.

One of the main objectives of the optimisation of remedial actions is to relieve congestions on XNE in (N-0) operation and in all relevant outage situations (N-X).

Note : According to CORNET-1792 and CORNET-2586 only one TATL (value, duration) per XNE is considered in the RAO in V1.

##### N-0 case:

• A hard constraint (non-relaxed) is added to the optimisation problem (MILP) for the loading of all XNEs, with a loading lower than or equal to the maximum loading limit in the N-0 case ($I_{b,\mathit{PATL}}$) before the optimisation

$$
|\underline{I}_{b} | = |\underline{I}_{b,0} | + \sum_{b\in \mathit{PB}} \frac{\partial I_{b}}{\partial P_{b}} \Delta P_{b} + \sum_{\tau \in T} \frac{\partial I_{b}}{\partial r_{\tau}} \Delta r_{\tau} \leq I_{b,\mathit{PATL}}
$$

where the current $\underline{I}_{b}$ is based on the initial current of the power flow ($\underline{I}_{b,0}$) and the projection of

<!-- page 223 -->

the RA power bids b redispatch $\Delta P_{b}$ and transformers $\tau$ tap changing $\Delta r_{\tau}$ based on the sensitivities (generating unit: $\frac{\partial I_{b}}{\partial P_{b}}$, transformer: $\frac{\partial I_{b}}{\partial r_{\tau}}$) described in CORNET-99.

• A soft constraint (relaxed) is added to the optimisation problem (MILP) for the loading of all XNEs with a loading higher than the maximum loading limit in the N-0 case ($I_{b,\mathit{PATL}}$) before the optimisation

$$
|\underline{I}_{b} | -\Delta I_{b,\mathit{slack}}^{+} \leq I_{b,\mathit{PATL}}
$$

with $\underline{I}_{b}$ as defined as above and

$$
0 \leq \Delta I_{b,\mathit{slack}}^{+} \leq \infty
$$

where $\Delta I_{b,\mathit{slack}}^{+}$ is the slack variable for the branch current limits to ensure a feasible

optimisation problem (MILP)

##### N-X cases:

• A soft constraint (relaxed) is added to the optimisation problem (MILP) for the loading of a XNEC combination of an assessed element in case the following selection criteria are matched:

o The loading of the XNE for a given contingency (XNEC) is higher than the predefined utilization limit for the N-X case(minUtilNX).

o If the loading of a XNE for a given contingency is higher than minUtilNX a maximum number of maxNumXNEC XNEC combinations per XNE (with the highest utilisation) are added to the optimisation problem.

o These criteria are evaluated in every outer iteration. In case optimised remedial actions will lead to new relevant XNEC combinations, up to maxNumXNEC new combinations per XNE are added to the optimisation problem per outer iteration. o Already considered constraints stay in the optimisation problem.

The added constraint is defined by

$|\underline{I}_{b}^{c} | = |\underline{I}_{b,0}^{c} | + \sum_{b\in \mathit{PB}} \frac{\partial I_{b}^{c}}{\partial P_{b}} ( \Delta P_{b} + \Delta P_{b}^{\mathit{cur}} ) + \sum_{\tau \in T} \frac{\partial I_{b}^{c}}{\partial r_{\tau}} (\Delta r_{\tau} + \sum_{d\in s} \Delta r_{\tau}^{\mathit{cur},c,d} ) -\Delta I_{b,\mathit{slack},\mathit{PATL}}^{c,+} \leq I_{b,\mathit{PATL}}$

$$
0 \leq \Delta I_{b,\mathit{slack},\mathit{PATL}}^{c,+} \leq \infty
$$

The current $\underline{I}_{b}^{c}$ in an outage situation c is estimated by the sum of the current $\underline{I}_{b,0}^{c}$ which is calculated by the outage approximation and described in $\frac{CORNET-26}{\mathit{cur},c,d}$, and the influence of the preventive ($\Delta P_{b} , \Delta r_{\tau} )$ and curative ($\Delta P_{b}^{\mathit{cur}} , \sum_{d\in s} \Delta r_{\tau} )$ remedial actions for all considered steps, which is calculated using the outage sensitivities ($\frac{\partial I_{b}^{c}}{\partial P_{b}} , \frac{\partial I_{b}^{c}}{\partial r_{\tau}} ,$ see CORNET-99).

• In case of allowed curative remedial actions as described in CORNET-572 and CORNET-571, additional soft constraints ($I_{b,\mathit{TATL}} > I_{b,\mathit{PATL}}$) to consider the TATL current in the period

<!-- page 224 -->

between the beginning of an outage at $t_{\mathit{trip}}$ and the end of the curative action period $t_{\mathit{trip}} +$ $t_{\mathit{TATL}}$ (with the TATL duration $t_{\mathit{TATL}}$) has to be included in the optimisation problem.

o In case XNEC combinations of different XNEs and the same contingency are

considered in the optimisation problem, the TATL durations of these XNEs must be taken into account.

o Each different TATL duration ($t_{\mathit{TATL},d}$) per contingency is considered as one step $s$ (post-fault situation) in the optimisation problem. Therefore, one additional soft constraint (relaxed) per XNE and step is added to the optimization problem for the contingency:

$|\underline{I}_{b}^{c,s} | = |\underline{I}_{b,0}^{c} | + \sum_{b\in \mathit{PB}} \frac{\partial I_{b}^{c}}{\partial P_{b}} (\Delta P_{b} + \sum_{d\in s} \Delta P_{b}^{\mathit{cur},c,d} ) + \sum_{\tau \in T} \frac{\partial I_{b}^{c}}{\partial r_{\tau}} (\Delta r_{\tau} + \sum_{d\in s} \Delta r_{\tau}^{\mathit{cur},c,d} ) -\Delta I_{b,\mathit{slack},\mathit{TATL},s}^{c,+} \leq I_{b,s}$

$$
0 \leq \Delta I_{b,\mathit{slack},\mathit{TATL},s}^{c,+} \leq \infty
$$

where:

o The variable $\underline{I}_{b}^{c,s}$ describes the current of a congested XNE in step $s$

o with preventive remedial actions ($\Delta P_{b}$ and $\Delta r_{\tau}$) applied and

$$
o with all curative remedial actions ( \sum_{d\in s} \Delta P_{b}^{\mathit{cur},c,d} and \sum_{d\in s} \Delta r_{\tau}^{\mathit{cur},c,d} ) applied, which were
$$

already applied until step $s$.

o $I_{b,s}$ is equal to

▪ $I_{b,\mathit{PATL}}$ if the duration $t_{s}$ of step $s$ is higher or equal than the TATL duration

$$
t_{\mathit{TATL},d} of the XNE
$$

▪ $I_{b,\mathit{TATL}}$ if the duration $t_{s}$ of step $s$ is lower than the TATL duration $t_{\mathit{TATL},d}$ of the XNE

o $\Delta I_{b,\mathit{slack},\mathit{TATL},s}^{c,+}$ is the slack variable for the branch current limits in step $s$ to ensure a feasible optimisation problem (MILP)

Example : There are two assessed XNEs, one with a 5-minute TATL duration (XNE 1 ), the other one with a 10-minute TATL duration (XNE ). This results in two steps and therefore two constraints per 2 XNE and relevant contingency situation. In the constraints for the first step the $\Delta r_{\tau}^{\mathit{cur},c,d}$ for the 5- minute TATL duration is considered and in the constraint for the second step the $\Delta r_{\tau}^{\mathit{cur},c,d}$ for the 5- minute and 10-minute TATL duration are considered. The $I_{b,s}$ for the two XNEs is as described below:

|  | - Step 1: | : |  | - Step 2: | : |
| --- | --- | --- | --- | --- | --- |
|  | o XNE 1 |  |  | o XNE 1 |  |
|  | $I_{b,\mathit{PATL}}$ |  |  | $I_{b,\mathit{PATL}}$ |  |

<!-- page 225 -->

| o XNE : 2 $I_{b,\mathit{TATL}}$ |  |  | o XNE : 2 |  |
| --- | --- | --- | --- | --- |
|  |  |  | $I_{b,\mathit{PATL}}$ |  |

With this formulation, the timeframe for temporarily admissible overloadings can be used to relieve congestions.

If the optimisation is not able to relieve the congestion of an XNE, the remaining congestion results in a contribution to the objective function in the amount of the remaining congestion multiplied by a penalty cost factor (see CORNET-1765 Objective Function).

The penalty cost factor is constant, applies to all XNE per timestamp and can be defined for the base case (N-0) and the (N-X) case.

##### Configuration:

Data requirements for penalty costs of XNE in (N-0) and (N-X) case:

| Name | Description | Units | Data type | Time series/ constant | RAO Object |
| --- | --- | --- | --- | --- | --- |
| penaltyPATL | Penalty cost factor effective for exceeding the PATL | [EUR/A] | floating point | constant | RAO Control Parameter |
| penaltyTATL | Penalty cost factor effective for exceeding the TATL | [EUR/A] | floating point | constant | RAO Control Parameter |

Control parameters for consideration of XNECs in the optimisation problem:

| Name | Description |  |  |  | Units Data type Object |  |
| --- | --- | --- | --- | --- | --- | --- |
| minUtilNX | Minimum loading to consider a XNEC combination in the optimisation problem | [%] |  | floating point |  | RAO Control Parameter |
| maxNumXNECs | Maximum number of contingencies per network element |  |  | integer |  | RAO Control Parameter |

Note : Loading factors shown in the result of the RAO process (see CORNET-83 - Results of outage approximation) refer to the rated current Ir (cim:CurrentLimit, see CORNET-32: Consideration of XNEs) and are therefore independent of the PATL.

##### Outlook:

<!-- page 226 -->

There is an additional TSO Requirement, that it should be possible to define all constraints either as hard or soft constraint. This requirement will be implemented in a future release for ROSC V1. With the actual specified version all soft constraints can implicitly made as hard constraints by applying very high penalty costs via the RAO control parameters.

Business Needs :

BN557: RAO-PATL

BN616: RAO-TATL_One

Acceptance Criteria :

Given

the RAO is used to optimise a grid including an overloaded XNE in N-0 and sufficient PRAs with available RD volume and sensitivities capable of reducing the loading on the XNE.

When

the optimisation terminates successfully,

then

the loading of the XNE is equal or below the PATL if the PRA activation is cheaper than leaving a remaining overload. Other constraints can have an influence on the result of the RAO.

Given

the RAO is used to optimise a grid including an overloaded XNE in N-X and sufficient PRAs with available RD volume and sensitivities capable of reducing the loading on the XNE. No CRAs are available.

When

the optimisation terminates successfully,

then

the loading of the XNE is equal or below the PATL if the PRA activation is cheaper than leaving a remaining overload. Other constraints can have an influence on the result of the RAO.

Given

the RAO is used to optimise a grid including an overloaded XNE in N-X and sufficient PRAs and CRAs with available RD volume and sensitivities capable of reducing the loading on the XNE. When

the optimisation terminates successfully,

then

<!-- page 227 -->

the loading of the XNE is equal or below the TATL after the PRA and equal or below PATL after PRA and CRA if the PRA and CRA activation is cheaper than leaving a remaining overload. Other constraints can have an influence on the result of the RAO.

##### CORNET-1792: Consideration of one TATL

###### Description

The Temporary Admissible Transmission Loading (TATL) is the loading which a XNE can accept for a certain limited duration. The definition of a TATL for a XNE is optional.

The RAO can consider in V1 only one tatlLimit for each XNE. The tatlLimit must be linked to a tatlDuration . This tatlDuration can be different for each XNE.

###### Configuration

Data requirements for the TATL of XNEs:

| Name | Description | Units | Data type | Time series/ constant | Profile |
| --- | --- | --- | --- | --- | --- |
| limitType | The type of the limit. Must be “tatl”. | - | LimitType Kind | constant | EquipmentProfile entsoe:OperationalLimitType:: limitType.tatl |
| tatlLimit | Temporarily Admissible Transmission Loading (TATL) is the loading in Amps that can be accepted by a branch for a certain limited duration. | A | floating point | constant | EquipmentProfile cim:CurrentLimit: cim:CurrentLimit.value with a linked OperationalLimitType as follows: - limitType as specified above - tatlDuration as specified below - cim:OperationalLimitType:: direction.absoluteValue |
| tatlDuration | Limited duration for which the corresponding TATL value can | secon ds | integer | constant | EquipmentProfile cim: OperationalLimitType.acceptab leDuration |

<!-- page 228 -->

|  | be accepted by a branch |  |  |  |  |
| --- | --- | --- | --- | --- | --- |

For RAO V1, it is expected that only one TATL, as specified above, per XNE is provided in the input data. If more than one TATL is provided for an XNE no TATL will be considered in the optimisation for this XNE. If one or more of the required input data attributes is not provided for an XNE the TATL will not be considered in the optimisation.

For the RTE region a different approach applies (see CORNET-2586).

Business Needs : BN616: RAO-TATL_One

##### CORNET-2586: Consideration of one TATL (RTE-specific)

This is an additional specification for RTE and extends CORNET-1792: Consideration of one TATL.

###### Description

RTE will provide more than one TATL per XNE in the input data for RAO V1. Which TATL limit to choose must be specified via RAO-Control Parameters (RTE_TATLDuration_CGM_Transformer / RTE_TATLDuration_CGM_Line). Both parameters specify the TATL duration to use for the linked TATL limits.

As these values are derived from the tripping current, a transformer ( RTE_TATLDuration_RAO_Transformer ) and line / PST ( RTE_TATLDuration_RAO_Line ) specific time must replace the tatlDuration given in the CGM from elements within the RTE region.

###### Configuration

Data requirements for the TATL of XNEs (RTE-specific):

| Name | Description | Units | Data type | Time series/ constant | Profile |
| --- | --- | --- | --- | --- | --- |
| RTE_TATLDuration_CGM_Transformer | The TATL duration for transformers from which the linked TATL limit in the |  | seconds integer constant |  | RAO- Control Parameter |

<!-- page 229 -->

|  | CGM must be used. |  |  |  |  |
| --- | --- | --- | --- | --- | --- |
| RTE_TATLDuration_CGM_Line | The TATL duration for lines/PST from which the linked TATL limit in the CGM must be used. |  | seconds integer constant |  | RAO- Control Parameter |
| RTE_TATLDuration_RAO_Transformer | The time for the TATL duration for transformers within the RTE region. |  | seconds integer constant |  | RAO- Control Parameter |
| RTE_TATLDuration_RAO_Line | The time for the TATL duration for lines / PST within the RTE region. |  | seconds integer constant |  | RAO- Control Parameter |

###### Details / Background

Example : in the CGM input data a XNE (line) has two TATL limits, one linked to the TATL duration 600s and the other one to the TATL duration of 1200s. RTE_TATLDuration_CGM_Line is set to 600 and RTE_TATLDuration_RAO_Line is set to 1200. The RAO uses from the CGM data the TATL limit linked to the 600s TATL duration as the only tatlLimit for the XNE. The tatlDuration for this XNE is set to RTE_TATLDuration_RAO_Line and is therefore 1200 seconds.

Business Needs : BN616: RAO-TATL_One

<!-- page 230 -->

##### CORNET-439: Scanned Elements

###### Description

Scanned elements are considered within FOA and the MILP. The initial load-flow calculation determines the initial loading of these elements in the base case (N-0) before the RAO. The following initial FOA determines the initial loadings for the contingency case (N-X).

Scanned elements are considered with their element specific thermal limits (PATL) within the MILP. Additionally, for each scanned element an individual virtual positive load margin can be defined. If available, this additional virtual loading margin is considered on top of the PATL ($\mathit{PATL}_{\mathit{Scanned} \mathit{Element}}$).

$$
\mathit{PATL}_{\mathit{Scanned} \mathit{Element}} = \mathit{PATL}_{\mathit{CGM}} *(1 + \frac{\mathit{virtual} \mathit{positive} \mathit{load} \mathit{margin}}{100} )
$$

If the calculated initial loadings in base or contingency case are above the individual allowed limit of a scanned element ($\mathit{PATL}_{\mathit{Scanned} \mathit{Element}}$), these determined element specific loadings are used as limits per time stamp and element for the maximum loading within the MILP. These adjustments are carried out within the RAO and not transferred to the CorNet data model. The adjusted limits are only used within the MILP.

If the calculated initial loadings in base or contingency case are below $\mathit{PATL}_{\mathit{Scanned} \mathit{Element}}$, this element specific loading limit is used as the limit per time stamp and element for the maximum loading within the MILP.

The constraints of scanned elements can be either modelled as hard or soft via a RAO control parameter ( ScannedElementConstraint_Soft ). The default is the modelling of the constraints as hard. By activating the control parameter, the constraints of the scanned elements are modelled as soft by implementing an additional slack variable when the loading of the scanned element is higher than $\mathit{PATL}_{\mathit{Scanned} \mathit{Element}}$. This is the same approach as used for the modelling of XNEs within the RAO (see CORNET-92: Consideration of XNEs in MILP).

The results of the scanned elements are described in CORNET-108: Results per AC line segment and 2W transformer.

###### Configuration

Data requirements for scanned elements in assessed elements:

| Name | Description | Units | Data type | Time | Profile |
| --- | --- | --- | --- | --- | --- |
|  |  |  |  | series / |  |
|  |  |  |  | constant |  |

<!-- page 231 -->

| ScannedStatus | A status to indicate whether the element has to be considered as a scanned element | - | bool | constant | AssessedElement-Profile: AssessedElement linked to a Region as ScannedAssessedElement |
| --- | --- | --- | --- | --- | --- |
| Virtualpositive loadmargin | A positive margin (0-100) that defines the overload allowed in a solution for the assessed element for a normal situation. The margin represents influences that can be solved by the System Operators using available remedial action which is not cross-border relevant remedial action. | - |  | integer constant | AssessedElement-Profile: AssessedElement::normalpo sitiveVirtualMargin |
| ScannedElementC onstraint_Soft | Control parameter for constraint type of scanned elements. If activated, the constraints are modelled as soft. | - | bool | constant | RAO setting |
| ScannedElement_p enalty | Penalty costs for overloads of scanned element constraints when modelled soft | € |  | double constant | RAO setting |

If no virtual positive load margin is defined for the scanned element in the CoMo data, the virtual positive load margin is set to zero.

Business Needs : BN788: RAO-Scanned_Elements_MVP (RAO)

Acceptance Criteria :

Given

the RAO is used to optimise a grid including a scanned element to relieve a congestion on another element. The scanned element has a virtual positive load margin and a calculated initial load below the

<!-- page 232 -->

thermal limit (PATL_scannedelement, calculated using the given virtual positive load margin). Scanned elements are configured as hard constraints.

When

the optimisation terminates successfully,

then

the load on the scanned element in the optimisation result is not above the thermal limit (PATL_scannedelement, calculated using the given virtual positive load margin). Other constraints can have an influence on the result of the RAO.

Given

the RAO is used to optimise a grid including a scanned element to relieve a congestion on another element. The scanned element does not have a virtual positive load margin and the calculated initial load is below the thermal limit (PATL_scannedelement = PATL_CGM). Scanned elements are configured as hard constraints.

When

the optimisation terminates successfully,

then

the load on the scanned element in the optimisation result is not above the thermal limit (PATL_scannedelement = PATL_CGM). Other constraints can have an influence on the result of the RAO.

Given

the RAO is used to optimise a grid including a scanned element to relieve a congestion on another element. The scanned element has a calculated initial load above the thermal limit. Scanned elements are configured as hard constraints.

When

the optimisation terminates successfully,

then

the load on the scanned element in the optimisation result is not above the calculated initial load. Other constraints can have an influence on the result of the RAO.

Given

the RAO is used to optimise a grid including a scanned element to relieve a congestion on another element. The scanned element has a virtual positive load margin outside of the intended parameter range and a calculated initial loading below the thermal limit (PATL_scannedelement = PATL_CGM). Scanned elements are configured as hard constraints.

<!-- page 233 -->

When

the optimisation terminates successfully,

then

the load on the scanned element in the optimisation result is not above the thermal limit (PATL_scannedelement = PATL_CGM). Other constraints can have an influence on the result of the RAO.

Given

the RAO is used to optimise a grid including a scanned element to relieve a congestion on another element. The scanned element has a virtual positive load margin and a calculated initial load below the thermal limit (PATL_scannedelement, calculated using the given virtual positive load margin). Scanned elements are configured as soft constraints.

When

the optimisation terminates successfully,

then

the load on the scanned element in the optimisation result can be above the thermal limit (PATL_scannedelement, calculated using the given virtual positive load margin). Other constraints can have an influence on the result of the RAO.

Given

the RAO is used to optimise a grid including a scanned element to relieve a congestion on another element. The scanned element does not have a virtual positive load margin and the calculated initial load is below the thermal limit (PATL_scannedelement = PATL_CGM). Scanned elements are configured as soft constraints.

When

the optimisation terminates successfully,

then

the load on the scanned element in the optimisation result can be above the thermal limit (PATL_scannedelement = PATL_CGM). Other constraints can have an influence on the result of the RAO.

Given

the RAO is used to optimise a grid including a scanned element to relieve a congestion on another element. The scanned element has a calculated initial load above the thermal limit. Scanned elements are configured as soft constraints.

When

<!-- page 234 -->

the optimisation terminates successfully,

then

the load on the scanned element in the optimisation result can be above the calculated initial load. Other constraints can have an influence on the result of the RAO.

Given

the RAO is used to optimise a grid including a scanned element to relieve a congestion on another element. The scanned element has a virtual positive load margin outside of the intended parameter range and a calculated initial loading below the thermal limit (PATL_scannedelement = PATL_CGM). Scanned elements are configured as soft constraints.

When

the optimisation terminates successfully,

then

the load on the scanned element in the optimisation result can be above the thermal limit (PATL_scannedelement = PATL_CGM). Other constraints can have an influence on the result of the RAO.

##### SF927: RAO-ExclusionsInclusions: Excluded XNEs in RAO (Offline)

###### Scenario

BUC 14#143 Element Excluded as Secured and not being Scanned

Exclusion of Secured element from RAO.

• An Element which was supposed to be Secured, but it has been excluded by the TSO. • An element is NOT to be kept as Scanned.

• The element is disabled (not to be used for the Process).

BUC 14#144 Element Excluded as Secured and kept as Scanned

Downgrade of Secured element to Scanned only.

• An Element which was supposed to be Secured, but it has been excluded by the TSO. • An element is kept as Scanned.

• The element is enabled (to be used for the Process).

Assessed elements (AE) can be excluded from being secured.

<!-- page 235 -->

###### Assumptions

The AE (XNE) is originally marked as secured. To mark an AE as secured, the mRID of the Capacity Calculation Region (CCR) it is located in, must be stored in securedForRegionCode .

###### Description

It must be possible to exclude AEs that were initially marked as secured from the RAO.

The exclusion is achieved by giving an exclusion reason in the parameter exclusionReason.

If an AE is excluded and not kept as scanned, it is not part of the optimization but will still be considered as part of the SA.

###### Configuration

The following input data is needed for the RAO:

| Name | Description | Unit | Data Type |  | Time | CoMo-Profile |
| --- | --- | --- | --- | --- | --- | --- |
|  |  |  |  |  | Series/ |  |
|  |  |  |  |  | Constant |  |
| securedForRegion Code | mRID of the Region this Contingency is secured for | - | String | Time Series |  | AssessedElem entFlatList: AssessedElem ent.securedFor RegionCode |
| exclusionReason | Reason for not associating this assessed element with a secured region | - | Enumeration | Time Series |  | AssessedElem entFlatList: AssessedElem ent.exclusionR eason |
| scannedForRegion Code | mRID of the Region this Contingency is scanned for | - | String | Time Series |  | AssessedElem entFlatList: AssessedElem ent.scannedFo rRegionCode |

###### Business Rules

Element Excluded as Secured and kept as Scanned

<!-- page 236 -->

An Element that was supposed to be secured is downgraded to only being scanned. Overloads are monitored but not solved by the RAO.

To indicate that an AE should be kept as scanned, the parameter scannedForRegionCode must be set.

Element Excluded as Secured and not being Scanned

An element that was supposed to be secured is completely excluded from the RAO. It is not kept as a scanned object.

The parameter scannedForRegionCode is not set and stays empty.

###### Triggers

The RAO started successfully and all pre-conditions are met.

###### Pre-Condition

All relevant input data is delivered, see Configuration.

At least one correctly defined assessed element is part of the AE-FlatList.

The status of an AE is manually adjusted.

The initial loadflow converged.

###### Acceptance Criteria

Given

An AE is excluded from the secured elements and kept as scanned

When

the optimisation terminates successfully,

then

the overload on the element is not worsened and the results are given according to CORNET-3221. Given

An AE is excluded from the secured elements and not being Scanned

When

the optimisation terminates successfully,

then

there are no results for this element.

<!-- page 237 -->

###### Basic Flow

If an AE has both securedForRegionCode and scannedForRegionCode, but no exclusionReason set, the RAO considers the AE as secured. This consideration of the AE as secured and the AE mRID are logged.

If an AE has only a scannedForRegionCode and exclusionReason set, the RAO considers the AE asscanned. This consideration of the AE as scanned and the AE mRID are logged.

###### Alternative Flow

If an AE has an invalid exclusionReason, the RAO is cancelled. The invalid exclusionReason and the AE mRID are logged.

If an AE in the AE-FlatList is not found in the CGM, the RAO is cancelled. An according log-message including the AE mRID is exposed.

<!-- page 238 -->

#### 3.8.2 System Constraints

##### CORNET-498: System Constraints with active power limits

###### Description

In the optimisation, constraints for the sum of the active power flow over a parameterisable set of net elements, e.g. to restrict the physical exchange flow into a grid area that is not modelled in full detail, must be taken into account. This can be, for example, a maximum physical exchange flow into a neighbouring control zone or a subgrid.

Each system constraint has a list of elements involved in the given constraint and is managed passively.

When managed passively, the sum of the flow on these elements is not worsened if it is above the provided limit (system constraint flow value) before the RAO. This is achieved by modelling the system constraint for these elements as a hard constraint with the resulting sum of flow as the upper limit. In case the sum of flow on these elements is below the provided limit before the RAO, the system constraint for these elements is modelled as a hard constraint with the provided limit as the upper limit.

$$
P_{\max}^{*} = \max (P_{\max} , P_{\mathit{before} \mathit{RAO}} ) \\
P_{\min}^{*} = \min (P_{\min} , P_{\mathit{before} \mathit{RAO}} )
$$

The passive system constraint is therefore modelled as the following constraint in the RAO:

$$
P_{\min}^{*} \leq \sum P_{\mathit{NE}} \leq P_{\max}^{*}
$$

The orientation for the system constraint must be given clearly via the input data by linking the NC profile to an ACDC-Terminal.

Figure 11: Schematic view of system constraint

Optionally, system constraints can be modelled as soft constraints via a RAO control parameter ( systemConstraint_Soft ). The default is the modelling of the constraints as hard. By activating the control parameter, the constraints of the system constraints are modelled as soft by implementing an

<!-- page 239 -->

additional slack variable when the sum of active power is higher than the defined limit of the system constraint. This is the same approach as used for the modelling of XNEs within the RAO (see CORNET- 92: Consideration of XNEs in MILP).

System constraints are only considered for the base case (N-0) in the release for Q01/2024. An implementation for specific contingency cases will follow in a later release.

###### Configuration

System constraints are modelled via PowerTransferCorridors in the EquipmentReliability-Profile. Each PowerTransferCorridors represents one system constraint and must be modelled as described below. - Each PowerTransferCorridors is linked to only one OperationalLimitSet

- The OperationalLimitSet is linked to one ACDCTerminal

- The OperationalLimitSet can be linked to either a lower, an upper or both limits via an OperationalLimit

- For the lower limit, the OperationalLimit is linked to one OperationalLimitType with the following attributes:

o Direction: absoluteValue

o isMinimum: true

- The OperationalLimit is linked to one InfeedLimit, which must be an active power limit: o normalValueW

- For the upper limit, the OperationalLimit is linked to one OperationalLimitType with the following attributes:

o Direction: absoluteValue

o isMinimum: false

- The OperationalLimit is linked to one InfeedLimit, which must be an active power limit: o normalValueW

- If lower and upper limit are both given for one PowerTransferCorridors both must have the same limit (current or active power)

- If only a lower limit is given for one PowerTransferCorridors the upper limit is unlimited. - If only an upper limit is given for one PowerTransferCorridors the lower limit is unlimited. - If more than two OperationalLimitSets are given for one PowerTransferCorridors the PowerTransferCorridors is not considered by the RAO.

- If two OperationalLimitSets are given for the same limit side, the PowerTransferCorridors are not be considered by the RAO.

- Only the ACDCTerminal linked to the OperationalLimitSet is considered in the system constraints

<!-- page 240 -->

- All ACDCTerminals linked to the given InfeedLimits are not considered in the RAO.

| Name | Description | Units |  | Data type | Time series / constant |  | Profile |
| --- | --- | --- | --- | --- | --- | --- | --- |
| systemConstraint_Soft | Control parameter for constraint type of system constraints. If activated, the constraints are modelled as soft. | - | bool |  | constant |  | RAO setting |
| systemConstraint_penalty | Penalty costs for overloads of system constraints | € | double |  |  |  | RAO setting |

Business Needs :

BN613: RAO-SystemConstraints_MVP (RAO)

BN836: RAO-InputData_System_Constraints

Acceptance Criteria :

Given

the RAO is used to optimise a grid including a system constraint on at least one element. The sum of the initial active power flow on the element(s) is not above the active power limit of the system constraint.

When

the optimisation terminates successfully,

then

the sum of the active power flow on the element(s) in the optimisation result is not above the active power limit of the system constraint. Other constraints can have an influence on the result of the RAO.

Given

the RAO is used to optimise a grid including a system constraint on at least one element. The sum of the initial active power flow on the element(s) is above the active power limit of the system constraint. When

the optimisation terminates successfully,

then

<!-- page 241 -->

the sum of the active power flow on the element(s) in the optimisation result is not above the sum of the initial active power flow on the element(s). Other constraints can have an influence on the result of the RAO.

Given

the RAO is used to optimise a grid including multiple system constraints including the same

element(s). The system constraints are modelled as hard constraints.

When

the optimisation terminates successfully,

then

none of the system constraints are violated in the results. Other constraints can have an influence on the result of the RAO.

Given

the RAO is used to optimise a grid including a system constraint on excluded elements.

When

the optimisation terminates successfully,

then

the active power flows on these elements could be outside the system constraint limits. Other constraints can have an influence on the result of the RAO.

Given

the RAO is used to optimise a grid including a system constraint on an element which is disabled by a manual topological RA. The system constraints are modelled as hard constraints.

When

the optimisation terminates successfully,

then

the active power flows on the remaining elements of the system constraint does not exceed the active power limit of the system constraint. Other constraints can have an influence on the result of the RAO.

Given

the RAO is used to optimise a grid including a system constraint on elements which are all disabled by manual topological RAs.

When

the optimisation terminates successfully,

<!-- page 242 -->

then

the RAO does not consider the system constraint. Other constraints can have an influence on the result of the RAO.

##### CORNET-537: System Constraints with current limits

###### Description

In the optimisation, constraints for the sum of the current flow over a parameterisable set of net elements, e.g. to restrict the physical exchange flow into a grid area that is not modelled in full detail, must be taken into account. This can be, for example, a maximum physical exchange flow into a neighbouring control zone or a subgrid.

Each system constraint has a list of elements involved in the given constraint and is managed passively.

When managed passively, the sum of the flow on these elements is not worsened if it is above the provided limit (system constraint flow value) before the RAO. This is achieved by modelling the system constraint for these elements as a hard constraint with the resulting sum of currents as the upper limit. In case the sum of currents on these elements is below the provided limit before the RAO, the system constraint for these elements is modelled as a hard constraint with the provided limit as the upper limit.

$$
I_{\max}^{*} = \max (I_{\max} ,I_{\mathit{before} \mathit{RAO}} ) \\
I_{\min}^{*} = \min (I_{\min} , I_{\mathit{before} \mathit{RAO}} )
$$

The passive system constraint is therefore modelled as the following constraint in the RAO:

$$
I_{\min}^{*} \leq \sum I_{\mathit{NE}} \leq I_{\max}^{*}
$$

The orientation for the system constraint must be given clearly via the input data by linking the NC profile to an ACDC-Terminal.

Figure 12: Schematic view of system constraint

<!-- page 243 -->

Optionally, system constraints can be modelled as soft constraints via a RAO control parameter ( systemConstraint_Soft ). The default is the modelling of the constraints as hard. By activating the control parameter, the constraints of the system constraints are modelled as soft by implementing an additional slack variable when the sum of the currents is higher than the defined limit of the system constraint. This is the same approach as used for the modelling of XNEs within the RAO (see CORNET- 92: Consideration of XNEs in MILP).

System constraints are only considered for the base case (N-0) in the release for Q01/2024. An implementation for specific contingency cases will follow in a later release.

###### Configuration

System constraints are modelled via PowerTransferCorridors in the EquipmentReliability-Profile. Each PowerTransferCorridors represents one system constraint and must be modelled as described below. - Each PowerTransferCorridors is linked to only one OperationalLimitSet

- The OperationalLimitSet is linked to one ACDCTerminal

- The OperationalLimitSet can be linked to either a lower, an upper or both limits via an OperationalLimit

- For the lower limit, the OperationalLimit is linked to one OperationalLimitType with the following attributes:

o Direction: absoluteValue

o isMinimum: true

- The OperationalLimit is linked to one InfeedLimit, which must be a current limit:

o normalValueA

- For the upper limit, the OperationalLimit is linked to one OperationalLimitType with the following attributes:

o Direction: absoluteValue

o isMinimum: false

- The OperationalLimit is linked to one InfeedLimit, which must be a current limit:

o normalValueA

- If lower and upper limit are both given for one PowerTransferCorridors both must have the same limit (current or active power)

- If only a lower limit is given for one PowerTransferCorridors the upper limit is unlimited. - If only an upper limit is given for one PowerTransferCorridors the lower limit is unlimited. - If more than two OperationalLimitSets are given for one PowerTransferCorridors, the PowerTransferCorridors are not considered by the RAO.

<!-- page 244 -->

- If two OperationalLimitSets are given for the same limit side, the PowerTransferCorridors are not considered by the RAO.

- Only the ACDCTerminal linked to the OperationalLimitSet is considered in the system constraints

- All ACDCTerminals linked to the given InfeedLimits are not considered in the RAO.

| Name | Description | Units |  | Data type | Time series / constant |  | Profile |
| --- | --- | --- | --- | --- | --- | --- | --- |
| systemConstraint_Soft | Control parameter for constraint type of system constraints. If activated, the constraints are modelled as soft. | - | bool |  | constant |  | RAO setting |
| systemConstraint_penalty | Penalty costs for overloads of system constraints | € | double |  |  |  | RAO setting |

Business Needs :

BN613: RAO-SystemConstraints_MVP (RAO)

BN836: RAO-InputData_System_Constraints

Acceptance Criteria :

Given

the RAO is used to optimise a grid including a system constraint on at least one element. The sum of the initial current flow on the element(s) is not above the current limit of the system constraint. When

the optimisation terminates successfully,

then

the sum of the current flow on the element(s) in the optimisation result is not above the current limit of the system constraint. Other constraints can have an influence on the result of the RAO.

Given

the RAO is used to optimise a grid including a system constraint on at least one element. The sum of the initial current flow on the element(s) is above the current limit of the system constraint.

When

the optimisation terminates successfully,

then

<!-- page 245 -->

the sum of the current flow on the element(s) in the optimisation result is not above the sum of the initial current flow on the element(s). Other constraints can have an influence on the result of the RAO.

Given

the RAO is used to optimise a grid including multiple system constraints including the same

element(s). The system constraints are modelled as hard constraints.

When

the optimisation terminates successfully,

then

none of the system constraints are violated in the results (the sum of current flow on all elements of each system constraint is below the limit of the system constraint). Other constraints can have an influence on the result of the RAO.

Given

the RAO is used to optimise a grid including a system constraint on excluded elements.

When

the optimisation terminates successfully,

then

the current flows on these elements could be outside the system constraint limits. Other constraints can have an influence on the result of the RAO.

Given

the RAO is used to optimise a grid including a system constraint on an element which is disabled by a manual topological RA. The system constraint is modelled as a hard constraint.

When

the optimisation terminates successfully,

then

the current flows on the remaining elements of the system constraint does not exceed the current limit of the system constraint. Other constraints can have an influence on the result of the RAO. Given

the RAO is used to optimise a grid including a system constraint on elements which are all disabled by manual topological RAs.

When

the optimisation terminates successfully,

<!-- page 246 -->

then

the RAO does not consider the system constraint. Other constraints can have an influence on the result of the RAO.

<!-- page 247 -->

### 3.9 Topological Remedial Actions

#### Disclaimer

In RAO V1 there is no optimisation of topological remedial actions. The RAO only considers the manual proposed topological PRAs and CRAs from the TSOs before RAO.

The optimisation of topological RAs will be part of RAO V2.

#### BUC 14#85: Read input of proposed or agreed topological XRAs

##### Scenario

BUC 14#85 RAO reads the RAS-Profile as input data for topological RAs

##### Assumptions

Topological RAs are optional input data. If no topological RAs are given via the RAS flatlist, no topological RA can be applied.

##### Description

Use case: Topological Remedial Actions can be a cost-effective solution to prevent congestions in the transmission grid. TSOs shall be able to provide proposed or already agreed topological XRAs to the RAO. To achieve this, the input data format is to be defined.

The RAO Calculation Module uses the RemedialActionSchedule-Profile as an input to determine the status of a Remedial Action (RA). The RAO only considers topological RAs with the statusKind proposed or agreed . Additionally, the RemedialActionSchedule must be linked to the corresponding GridStateAlteration via a GridIntensitySchedule .

##### Configuration

The following input data is needed for the RAO:

| Name | Description | Unit | Data Type | Time Series/ Constant |  | Profile |
| --- | --- | --- | --- | --- | --- | --- |
| RA status | Status of the topological RA | - | enum | Time series |  | RemedialActionSchedule: RemedialActionSchedule.Stat usKind: - Proposed - Agreed |

<!-- page 248 -->

| Linked topological RA | The linked topological RA which is defined in the RA-Profile | - |  | constant | RemedialActionSchedule: RemedialActionSchedule ->GenericValueSchedule ->GridIntensitySchedule ->GridStateAlteration |
| --- | --- | --- | --- | --- | --- |
| Linked contingency | The contingency, for which the curative topological RA must be used. |  |  |  | RemedialActionFlatList: ContingencyWithRemedialAct ion |

##### Business Rules

The information of the RemedialActionSchedule and the RA-FlatList is saved within the internal RAO data model.

##### Triggers

The RAO started successfully and all pre-conditions are met.

##### Pre-Condition

• All relevant input data is delivered, see Configuration.

• At least one correctly defined assessed element is part of the AE-FlatList.

• The initial loadflow converged.

##### Acceptance Criteria

Given

The RemedialActionSchedule-Profile contains topological XRA

When

The RAO successfully starts,

Then

The topological XRA are imported into the RAO internal data model.

##### Basic Flow

No log-messages are foreseen.

##### Alternative Flow

If errors occur while reading the input data, the issues are logged and the RAO is cancelled.

<!-- page 249 -->

#### BUC 14#84 Application of already agreed topological PRAs before RAO

##### Scenario

UC8742 BUC 14#84 Application of already agreed topological PRAs before RAO V2

The RAO processes preventive topological RA with the status proposed or agreed and applies them.

##### Description

Use case: Topological Remedial Actions (RAs) can be a cost-effective solution to prevent congestions in the transmission grid. The RAO shall be able to apply proposed or agreed preventive topological RAs from TSOs which were determined by their local assessment.

The format of the input data for the RemedialActionSchedule-Profile for proposed or agreed topological RAs is specified in BUC 14#85.

Preventive topological RA only with the status proposed or agreed are processed by the RAO. Besides, only TopologyActions which are part of a GridStateAlteration are considered.

Cross-checking of multiple topological PRAs will not be performed. If a Switch is defined in multiple topological PRAs with different RangeConstraints assigned to it, only the last change (in the order of the input data list) will be active in the grid model.

Each topological RA is checked for plausibility individually. Every equipment, identified by TopologyAction.Switch , that is part of the topological RA, must be found in the CGM. Besides the value assigned to the equipment ( GridStateAlteration.PropertyReference ) must be within the range of the equipment ( StaticPropertyRange.PropertyReference ). If any change by one topological RA cannot be validated by the RAO, the GridStateAlterationRemedialAction will not be considered at all and a log entry will be written.

##### Outlook

The optimisation of topological PRAs within the RAO will be subject of CorNet V2. Furthermore, cross checking of multiple topological RAs for plausibility will be specified in a later stage in CorNet V1. All validation rules specified in this ticket will be part of the input data validation module. Currently this module is not specified.

##### Configuration

The following input data is needed for the RAO:

<!-- page 250 -->

| Name | Description | Unit | Data Type | Time Series/ Constant | CoMo-Profile |
| --- | --- | --- | --- | --- | --- |
| RemedialActionKind | RA mode for the topological action | - | enum: preventiv e curative | constant | RemedialActionFlatList: RemedialAction.kind = preventive |
| TopologyActionName | Name of the Topological Action | - | string | constant | RemedialActionFlatList: RemedialAction.name |
| TopologyAction | Topological RA associated to a GridStateAlteratio n | - |  | constant | RemedialActionFlatList: RemedialAction -> GridStateAlterationRemedialA ction -> GridStateAlteration.actionTyp e = TopologyAction |
| TopologyActionSwitch | Switch associated with Topological RA | - |  | constant | RemedialActionFlatList: RemedialAction -> GridStateAlterationRemedialA ction -> GridStateAlteration -> powerSystemResourceMrid |
| GridStateAlterationPro pertyReference | Switching action associated with Topological RA | - |  | constant | RemedialActionFlatList: RemedialAction -> GridStateAlterationRemedialA ction -> GridStateAlteration -> RangeConstraint.propertyRef erence |
| RangeConstraint | Possible Range of Switching action associated with Topological RA | - |  | constant | RemedialActionFlatList: - RemedialAction -> GridStateAlterationRe medialAction -> GridStateAlteration -> RangeConstraint - direction = none |

<!-- page 251 -->

|  |  |  |  |  | - valueKind = absolute - normalValue = 1 |
| --- | --- | --- | --- | --- | --- |
| StaticPropertyRange | Possible Range of Switching action associated with Topological RA |  |  | Constant | RemedialActionFlatList: RemedialAction -> GridStateAlterationRemedialA ction -> GridStateAlteration -> RangeConstraint - Switch.open - Switch.close |

##### Business Rules

Topological RA are available via the GridStateIntensitySchedule and the EventSchedule to RAO. The RAO uses the GridStateIntensitySchedule for topological RA.

##### Triggers

The RAO started successfully and all pre-conditions are met.

##### Pre-Condition

All relevant input data is delivered (see: BUC 14#85: Read input of proposed or agreed topological XRAs).

At least one correctly defined assessed element is part of the AE-FlatList.

The initial loadflow converged.

##### Acceptance Criteria

Given

The RemedialActionSchedule contains a topological PRA

When

The RAO successfully terminates,

Then

RAO will either implement the topological PRA or log the reason of denial.

##### Basic Flow

The following log-messages regarding topological PRA are exposed:

• Name

• MRID

• Equipment MRID

<!-- page 252 -->

##### Alternative Flow

No alternative flow foreseen.

#### BUC 14#105: Application of proposed topological CRAs

##### Scenario

#### BUC 14#105: Application of proposed topological CRAs

Topological Remedial Actions (RAs) can be a cost-effective solution to reduce congestion in the transmission grid. The RAO shall be able to apply proposed curative topological RAs from TSOs which were determined by their local assessment.

##### Assumptions

The RAO does not carry out any wide-ranging validation checks for topological CRAs. It is only tested whether the corresponding element is present in the grid model. If the equipment of the topological CRA is part of the contingency equipment, the topological CRA cannot be applied and is therefore ignored.

The topological CRAs are implemented as they are proposed by the TSO.

The format of the input data for the RemedialActionSchedule -Profile for proposed or agreed topological RAs is specified in BUC 14#85 Read Input of agreed or proposed topological XRAs

##### Description

The RAO must apply topological CRAs for certain contingency situations. The topological RA are a GridStateAlterationRemedialAction and defined as a TopologyAction. The GridStateAlteration is linked to a Switch , which is located between two ACDCTerminal .

The RA and the contingencies are directly linked to each other via the ContingencyWithRemedialAction .

The application of a topological CRA for a contingency situation is automatic and therefore the same as for preventive topological RA (see BUC 14#84 Application of already agreed topological PRAs before RAO).

Contingency situations with topological CRA can only be calculated with the FCC (see SF3072: Fast Contingency Calculation) because of the detailed consideration of switch gear in that calculation module. The topological CRA is applied on the internal grid model before the contingency situation is calculated. The resulting loading on the elements after the FCC is therefore with the topological CRA already considered.

<!-- page 253 -->

##### Configuration

The following input data is needed for the RAO:

| Name | Description | Unit | Data Type | Time Series/ Constant | CoMo-Profile |
| --- | --- | --- | --- | --- | --- |
| RemedialAction Kind | RA mode for the topological action | - | enum: preventive curative | constant | RemedialActionFlatList: RemedialAction.kind = curative |
| linkedContingen cies | Contingency cases for which the RA can be activated | - | string | constant | RemedialActionFlatList: RemedialAction -> ContingencyWithRemed ialAction.contingencyMri d |
| TopologyAction | Topological RA associated to a GridStateAlteration | - |  | constant | RemedialActionFlatList: RemedialAction -> GridStateAlterationRem edialAction -> GridStateAlteration.acti onType = TopologyAction |
| TopologyActionS witch | Switch associated with Topological RA | - |  | constant | RemedialActionFlatList: RemedialAction -> GridStateAlterationRem edialAction -> GridStateAlteration -> powerSystemResource Mrid |
| GridStateAlterati onPropertyRefer ence | Switching action associated with Topological RA | - |  | constant | RemedialActionFlatList: RemedialAction -> GridStateAlterationRem edialAction -> GridStateAlteration -> RangeConstraint.proper tyReference |

<!-- page 254 -->

| RangeConstraint | Possible Range of Switching action associated with Topological RA | - |  | constant | RemedialActionFlatList: RemedialAction -> GridStateAlterationRem edialAction -> GridStateAlteration -> RangeConstraint - direction = none - valueKind = absolute normalValue = 1 |
| --- | --- | --- | --- | --- | --- |
| StaticPropertyRa nge | Possible Range of Switching action associated with Topological RA | - |  | constant | RemedialActionFlatList: RemedialAction -> GridStateAlterationRem edialAction -> GridStateAlteration -> RangeConstraint - Switch.open - Switch.close |

##### Business Rules

Cross-checking of multiple topological CRAs will not be performed. If a Switch is defined in multiple topological CRAs with different RangeConstraints assigned to it, only the last change (in the order of the input data list) will be active in the grid model.

Only curative topological RAs with the status proposed or agreed are processed by the RAO. Besides, only TopologyActions which are part of a GridStateAlteration are considered.

If a topological RA is applied, the maximum limit for applicable RA is adjusted accordingly. The topological RA is not part of the constraint as a variable.

##### Triggers

The RAO started successfully and all pre-conditions are met.

##### Pre-Condition

All relevant input data is delivered (see: BUC 14#85: Read input of proposed or agreed topological XRAs). At least one correctly defined assessed element is part of the AE-FlatList.

<!-- page 255 -->

The topological RA must be defined as curative and linked to a contingency.

The initial loadflow converged.

##### Acceptance Criteria

Given

The RemedialActionSchedule-Profile contains topological CRA

When

The FCC calculated the linked contingency

Then

The result must be based on the new grid topology.

Given

The RemedialActionSchedule-Profile contains topological CRA

When

The RAO successfully terminates

Then

The CRAs are merged to the output RAS of the RAO.

##### Basic Flow

The topological CRA is applied to the internal grid model before the FCC is used to calculate the contingency situation.

The following log-messages regarding topological CRA are exposed:

• Name

• MRID

• Equipment MRID

##### Alternative Flow

No alternative flow foreseen.

<!-- page 256 -->

### 3.10 Configuration of RAO optimisation settings

#### CORNET-3624: Sensitivity Threshold

##### Description

Use Case: The optimisation shall only consider RAs, which have a significant impact on the loading of the overloaded XNEs.

In some cases, the optimisation might excessively use RAs with a small sensitivity, even though its impact on the congestion is minimal. This behaviour can occur due to the modelling of the optimisation problem (MILP) with very high penalty costs for overloads (see CORNET-1790: Consideration of XNEs in MILP) compared to the costs for RAs. Even though the impact of the RAs is small, this small reduction in the XNE’s loading might lead to a minimisation of the objective value compared to the initial overload. However, this behaviour is not desired.

Within the RAO it is possible to consider sensitivity thresholds for RAs. This threshold can be defined as a global value (per RA type: PST or RD).

There are two different control parameters for each RA type – one limit for sensitivities with a positive impact on a XNE and one for sensitivities with a negative impact. The reason for the distinction is explained below with an example in “Details / Background”.

In case the sensitivity of a RA on a certain XNE is below the threshold, it is set to zero and therefore no longer has an impact within the optimisation. As a result, the RA will not be used to relieve congestions on that XNE.

sensitivity < threshold → sensitivity set to zero

sensitivity >= threshold → sensitivity keeps value

##### Configuration

| Name | Description | Units | Data type | Time series/ constant | Profile |
| --- | --- | --- | --- | --- | --- |
| SensitivityThreshol dRD_posImpact | Minimum sensitivity threshold of RD for RAO. Smaller sensitivities with positive impact are set to zero. | A/MW float |  | constant | RAO Control Parameter |

<!-- page 257 -->

| SensitivityThreshol dRD_negImpact | Minimum sensitivity threshold of RD for RAO. Smaller sensitivities with negative impact are set to zero. | A/MW float |  | constant | RAO Control Parameter |
| --- | --- | --- | --- | --- | --- |
| SensitivityThreshol dPST_posImpact | Minimum sensitivity threshold of PST for RAO. Smaller sensitivities with positive impact are set to zero. | A/Tap float |  | constant | RAO Control Parameter |
| SensitivityThreshol dPST_negImpact | Minimum sensitivity threshold of PST for RAO. Smaller sensitivities with negative impact are set to zero. | A/Tap float |  | constant | RAO Control Parameter |

##### Details / Background

##### Example: Neglecting negative impact sensitivities can lead to overloads

The neglection of sensitivities with a negative impact might lead to line loadings > 100%.

Figure 19 and Figure 14 show the optimisation result of a simple example with both sensitivity thresholds set to 0.2 A/Tap.

Figure 15 on the other hand shows what the actual power flow would look like. There, the upper line becomes overloaded, since the previously neglected sensitivity of 0.15 is taken into account. As the corresponding sensitivity was not included in the optimisation, the overload was not detected and relieved. To consider this, only the sensitivities of RAs with a decreasing effect on the loading should be neglected within the optimisation.

> **Figure (page 257) — described in text.**
>
> Small example grid showing sensitivities from a PST. A transformer symbol (two overlapping circles on a busbar) at the left has two curved arrows leaving it: one labelled **0.15** pointing to a green line at **99 %** loading, and one labelled **− 0.3** pointing to a red line at **102 %** loading (overloaded). A second transformer at the right sends a curved arrow labelled **− 0.02** to the same overloaded line.

Figure 13: Example grid with overload - PST

<!-- page 258 -->

> **Figure (page 258) — described in text.**
>
> The same grid after the PST is moved by **Δ7** taps (annotated at the left transformer). The sensitivities that would *increase* loading are struck through in red (0.15 and −0.02 are crossed out); only the −0.3 path is evaluated. The formerly overloaded line is recalculated as **102 % − 0.3·7 = 99.9 %** and is now drawn green at 99.9 %, while the other line stays green at 99 %.

Figure 14: Example grid and power in flow optimisation - PST

> **Figure (page 258) — described in text.**
>
> Same Δ7 tap change, but now the neglected sensitivity is taken into account. The upper line, previously green at 99 %, becomes **99 % + 0.15·7 = 100.05 %** and is drawn red at 100.05 % — a new overload created by the very action that relieved the other one. The lower line is still **102 % − 0.3·7 = 99.9 %**, drawn green.

Figure 15: Example grid and power in flow optimisation -PST

Figures 4 to 6 show a similar example, but for a change in redispatch. It should be noted that the sensitivity calculation for generation units depends on the considered reference nodes. This should be kept in mind when setting the sensitivity threshold for RD.

> **Figure (page 258) — described in text.**
>
> The equivalent example for a generation unit. A generator symbol (⌁) at the left sends two curved arrows: **0.1** to a green line at **99 %**, and **− 0.2** to a red line at **103 %** (overloaded). A second generator at the right contributes **− 0.01** to the overloaded line.

<!-- page 259 -->

Figure 16: Example grid with overload – Generation unit

> **Figure (page 259) — described in text.**
>
> The generation-unit example after a **15 MW** injection (blue arrow at the left generator). The 0.1 and −0.01 sensitivities are struck through in red; only the −0.2 path is evaluated, giving **103 % − 0.2·15 = 100 %**, so the previously overloaded line is drawn green at 100 % and the other stays green at 99 %.

Figure 17: Example grid and power in flow optimisation - Generation unit

> **Figure (page 259) — described in text.**
>
> The same 15 MW injection with all sensitivities considered. The upper line becomes **99 % + 0.1·15 = 100.5 %** and is drawn red at 100.5 %; the lower line is **103 % − 0.2·15 = 100 %**, drawn green — again showing that neglecting the loading-increasing sensitivity hides a newly created overload.

Figure 18: Example grid and power in flow optimisation - Generation unit

##### Outlook

This chapter is only for informational purposes and is not part of the delivered specification.

A future release will consider additional configuration parameters of the sensitivity threshold, such as a TSO-specific configuration.

Business Need :

BN881: RAO-Sensitivity_Threshold_MVP

<!-- page 260 -->

Use-Cases :

BUC 14#14 RAO considers sensitivity thresholds

Acceptance Criteria :

Given

The RAO determines an overloading on a branch.

When

The optimisation terminates successfully,

Then

No RD RA must be used for reducing this overload with a positive impact and a sensitivity smaller than SensitivityThresholdRD_posImpact.

Given

The RAO determines an overloading on a branch.

When

The optimisation terminates successfully,

Then

No RD RA must be used for reducing this overload with a negative impact and a sensitivity smaller than SensitivityThresholdRD_negImpact.

Given

The RAO determines an overloading on a branch.

When

The optimisation terminates successfully,

Then

No PST RA must be used for reducing this overload with a positive impact and a sensitivity smaller than SensitivityThresholdPST_posImpact.

Given

The RAO determines an overloading on a branch.

When

The optimisation terminates successfully,

Then

No PST RA must be used for reducing this overload with a negative impact and a sensitivity smaller than SensitivityThresholdRD_negImpact.

<!-- page 261 -->

#### CORNET-3650: TSO specific parametrisation of penalty terms in soft constraints

##### Description

The RAO can model certain constraints as soft by integrating an additional slack variable. This expands the solution space of the optimisation problem, e.g. the RAO can determine an optimal solution with a remaining overload on a XNE because of insufficient available RD volume from RAs.

These slack variables are defined in:

• CORNET-1790: Consideration of XNEs in MILP

• CORNET-439: Scanned Elements

• CORNET-498: System Constraints with active power limits

• CORNET-537: System Constraints with current limits

These slack variables are priced with associated penalty costs. The penalty cost parameters defined in the aforementioned specifications are mandatory global control parameters which define the penalty costs for all TSOs. This specification addresses only the extension of the parametrisation of the slack penalty costs.

This extension is the definition of penalty costs for the slack variables on a TSO-specific level. If used, these TSO-specific penalty costs overwrite the corresponding global parameter. When the TSO- specific penalty cost is not set, the corresponding mandatory global penalty cost parameter is used instead.

##### Configuration

Data requirements for TSO-specific penalty costs:

| Name | Description | Units | Data type |  | Mandatory | Profile |
| --- | --- | --- | --- | --- | --- | --- |
|  |  |  |  |  | (Default |  |
|  |  |  |  |  | value) |  |
| penaltyPAT L | Penalty costs effective for exceeding the PATL | EUR/ A | float > 0 | no |  | RAOControlParameterProfile. RAOControlParameterSetForT SO |
| penaltyTAT L | Penalty costs effective for exceeding the TATL | EUR/ A | float > 0 | no |  | RAOControlParameterProfile. RAOControlParameterSetForT SO |

<!-- page 262 -->

| scannedEle mentPenalty | Penalty costs for overloads of scanned element constraints when modelled soft | EUR/ A | float > 0 | no | RAOControlParameterProfile. RAOControlParameterSetForT SO |
| --- | --- | --- | --- | --- | --- |
| systemCons traintPenalty | Penalty costs for overloads of system constraints | EUR/ A | float > 0 | no | RAOControlParameterProfile. RAOControlParameterSetForT SO |

##### Outlook

This chapter is only for informational purposes and is not part of the delivered specification.

With the introduction of additional soft constraints within the RAO, the TSO-specific penalty cost parameters will be extended as well.

Business Needs :

BN826: RAO-CostParametrisation_Advanced

Use-Cases :

UC307: BUC 14#36 Consideration of TSO-specific slack costs in RAO

Acceptance Criteria :

Given

A TSO uses the TSO-specific penaltyPATL parameter for a RAO run and defines a different value than the global penaltyPATL parameter.

When

The optimisation terminates successfully,

Then

The TSO-specific penaltyPATL parameter must have been used by the RAO as penalty costs for overloads exceeding the PATL in the TSO region.

Given

A TSO does not use the TSO-specific penaltyPATL parameter for a RAO run and only a value for the global penaltyPATL parameter is defined.

<!-- page 263 -->

When

The optimisation terminates successfully,

Then

The global penaltyPATL parameter must have been used by the RAO as penalty costs for overloads exceeding the PATL in the TSO region.

Given

A TSO uses the TSO-specific penaltyTATL parameter for a RAO run and defines a different value than the global penaltyTATL parameter.

When

The optimisation terminates successfully,

Then

The TSO-specific penaltyTATL parameter must have been used by the RAO as penalty costs for overloads exceeding the TATL in the TSO region.

Given

A TSO does not use the TSO-specific penaltyTATL parameter for a RAO run and only a value for the global penaltyTATL parameter is defined.

When

The optimisation terminates successfully,

Then

The global penaltyTATL parameter must have been used by the RAO as penalty costs for overloads exceeding the TATL in the TSO region.

Given

A TSO uses the TSO-specific scannedElementPenalty parameter for a RAO run and defines a different value than the global scannedElementPenalty parameter. Scanned elements are defined as modelled soft in the settings.

When

The optimisation terminates successfully,

Then

The TSO-specific scannedElementPenalty parameter must have been used by the RAO as penalty costs for overloads on scanned elements in the TSO region.

Given

<!-- page 264 -->

A TSO does not use the TSO-specific scannedElementPenalty parameter for a RAO run and only a value for the global scannedElementPenalty parameter is defined. Scanned elements are defined as modelled soft in the settings.

When

The optimisation terminates successfully,

Then

The global scannedElementPenalty parameter must have been used by the RAO as penalty costs for overloads on scanned elements in the TSO region.

Given

A TSO uses the TSO-specific systemConstraintPenalty parameter for a RAO run and defines a different value than the global systemConstraintPenalty parameter. System constraints are defined as modelled soft in the settings.

When

The optimisation terminates successfully,

Then

The TSO-specific systemConstraintPenalty parameter must have been used by the RAO as penalty costs for overloads on system constraints in the TSO region.

Given

A TSO does not use the TSO-specific systemConstraintPenalty parameter for a RAO run and only a value for the global systemConstraintPenalty parameter is defined. System cosntraints are defined as modelled soft in the settings.

When

The optimisation terminates successfully,

Then

The global systemConstraintPenalty parameter must have been used by the RAO as penalty costs for overloads on system constraints in the TSO region.

<!-- page 265 -->

#### CORNET-4339: TSO specific parametrisation of penalty reference values for remedial actions

##### actions

##### Description

Remedial actions can have a penalty factor defined. This RA specific penalty factor is multiplied with the corresponding mandatory global penalty reference value for calculating the penalty costs to consider within the optimisation.

These penalty reference values can optionally be parameterised for each TSO individually. If used, these TSO-specific penalty reference values overwrite the corresponding global parameter. When the TSO-specific penalty reference value is not set, the corresponding mandatory global penalty reference value is used instead.

The penalty reference values are for each preventive and curative:

• For each PST tap change ( penaltyReferencePST_PRA / penaltyReferencePST_CRA ) • For each MW of redispatch ( penaltyReferenceRD_PRA / penaltyReferenceRD_CRA ) • For each MW of countertrade ( penaltyReferenceCT_PRA / penaltyReferenceCT_CRA )

##### Configuration

| Name | Description | Unit | Data Type |  | Mandatory |  | Profile |
| --- | --- | --- | --- | --- | --- | --- | --- |
|  |  |  |  |  | (Default |  |  |
|  |  |  |  |  | value) |  |  |
| penaltyReferenc ePST_PRA | Preventive penalty reference value for PST for each tap change | €/Ta p | float > 0 | no |  |  | RAOControlParameterPr ofile. RAOControlParameterS etForTSO |
| penaltyReferenc ePST_CRA | Curative penalty reference value for PST for each tap change | €/Ta p | float > 0 | no |  |  | RAOControlParameterPr ofile. RAOControlParameterS etForTSO |
| penaltyReferenc eRD_PRA | Preventive penalty reference value for redispatch per MW | €/M W | float > 0 | no |  |  | RAOControlParameterPr ofile. RAOControlParameterS etForTSO |

<!-- page 266 -->

| penaltyReferenc eRD_CRA | Curative penalty reference value for redispatch per MW | €/M W | float > 0 | no | RAOControlParameterPr ofile. RAOControlParameterS etForTSO |
| --- | --- | --- | --- | --- | --- |
| penaltyReferenc eCT_PRA | Preventive penalty reference value for countertrade per MW | €/M W | float > 0 | no | RAOControlParameterPr ofile. RAOControlParameterS etForTSO |
| penaltyReferenc eCT_CRA | Curative penalty reference value for countertrade per MW | €/M W | float > 0 | no | RAOControlParameterPr ofile. RAOControlParameterS etForTSO |

Business Needs :

BN826: RAO-CostParametrisation_Advanced

Use-Cases :

UC321: BUC 14#35 Consideration of TSO-specific penalty reference values in RAO

Acceptance Criteria :

Given

A TSO uses the TSO-specific penaltyReferencePST_PRA parameter for a RAO run and defines a different value than the global penaltyReferencePST_PRA parameter.

When

The optimisation terminates successfully,

Then

The TSO-specific penaltyReferencePST_PRA parameter must have been used by the RAO for calculating the penalty costs for a preventive PST tap change in the TSO region.

Given

A TSO does not use the TSO-specific penaltyReferencePST_PRA parameter for a RAO run and only a value for the global penaltyReferencePST_PRA parameter is defined.

When

The optimisation terminates successfully,

Then

<!-- page 267 -->

The global penaltyReferencePST_PRA parameter must have been used by the RAO for calculating the penalty costs for a preventive PST tap change in the TSO region.

Given

A TSO uses the TSO-specific penaltyReferencePST_CRA parameter for a RAO run and defines a different value than the global penaltyReferencePST_CRA parameter.

When

The optimisation terminates successfully,

Then

The TSO-specific penaltyReferencePST_CRA parameter must have been used by the RAO for calculating the penalty costs for a curative PST tap change in the TSO region.

Given

A TSO does not use the TSO-specific penaltyReferencePST_CRA parameter for a RAO run and only a value for the global penaltyReferencePST_CRA parameter is defined.

When

The optimisation terminates successfully,

Then

The global penaltyReferencePST_CRA parameter must have been used by the RAO for calculating the penalty costs for a curative PST tap change in the TSO region.

Given

A TSO uses the TSO-specific penaltyReferenceRD_PRA parameter for a RAO run and defines a different value than the global penaltyReferenceRD_PRA parameter.

When

The optimisation terminates successfully,

Then

The TSO-specific penaltyReferenceRD_PRA parameter must have been used by the RAO for calculating the penalty costs for a preventive RD RA in the TSO region.

Given

A TSO does not use the TSO-specific penaltyReferenceRD_PRA parameter for a RAO run and only a value for the global penaltyReferenceRD_PRA parameter is defined.

When

The optimisation terminates successfully,

Then

<!-- page 268 -->

The global penaltyReferenceRD_PRA parameter must have been used by the RAO for calculating the penalty costs for a preventive RD RA in the TSO region.

Given

A TSO uses the TSO-specific penaltyReferenceRD_CRA parameter for a RAO run and defines a different value than the global penaltyReferenceRD_CRA parameter.

When

The optimisation terminates successfully,

Then

The TSO-specific penaltyReferenceRD_CRA parameter must have been used by the RAO for calculating the penalty costs for a curative RD RA in the TSO region.

Given

A TSO does not use the TSO-specific penaltyReferenceRD_CRA parameter for a RAO run and only a value for the global penaltyReferenceRD_CRA parameter is defined.

When

The optimisation terminates successfully,

Then

The global penaltyReferenceRD_CRA parameter must have been used by the RAO for calculating the penalty costs for a curative RD RA in the TSO region.

Given

A TSO uses the TSO-specific penaltyReferenceCT_PRA parameter for a RAO run and defines a different value than the global penaltyReferenceCT_PRA parameter.

When

The optimisation terminates successfully,

Then

The TSO-specific penaltyReferenceCT_PRA parameter must have been used by the RAO for calculating the penalty costs for a preventive CT RA in the TSO region.

Given

A TSO does not use the TSO-specific penaltyReferenceCT_PRA parameter for a RAO run and only a value for the global penaltyReferenceCT_PRA parameter is defined.

When

The optimisation terminates successfully,

Then

<!-- page 269 -->

The global penaltyReferenceCT_PRA parameter must have been used by the RAO for calculating the penalty costs for a preventive CT RA in the TSO region.

Given

A TSO uses the TSO-specific penaltyReferenceCT_CRA parameter for a RAO run and defines a different value than the global penaltyReferenceCT_CRA parameter.

When

The optimisation terminates successfully,

Then

The TSO-specific penaltyReferenceCT_CRA parameter must have been used by the RAO for calculating the penalty costs for a curative CT RA in the TSO region.

Given

A TSO does not use the TSO-specific penaltyReferenceCT_CRA parameter for a RAO run and only a value for the global penaltyReferenceCT_CRA parameter is defined.

When

The optimisation terminates successfully,

Then

The global penaltyReferenceCT_CRA parameter must have been used by the RAO for calculating the penalty costs for a curative CT RA in the TSO region.

#### CORNET-4340: TSO specific parametrisation for consideration of technical limits from redispatch RA in curative mode

##### redispatch RA in curative mode

##### Description

The control parameters specified in CORNET-612: Consideration of technical limits from redispatch RA in curative mode were specified as global control parameters. These parameters are now available as TSO specific control parameters.

##### Configuration

| Name | Description | Unit | Data Type |  | Mandatory |  | Profile |
| --- | --- | --- | --- | --- | --- | --- | --- |
|  |  |  |  |  | (Default |  |  |
|  |  |  |  |  | value) |  |  |

<!-- page 270 -->

| curPMax | Enables/disables consideration of P from Max generation units Default: Enabled |  | bool | no | RAOControlParameterProfile. RAOControlParameterSetForTSO |
| --- | --- | --- | --- | --- | --- |
| curPMin | Enables/disables consideration of P Min from generation units Default: Enabled |  | bool | no | RAOControlParameterProfile. RAOControlParameterSetForTSO |

Business Needs :

BN826: RAO-CostParametrisation_Advanced

Use-Cases :

UC322: BUC 14#37 TSO-specific consideration of technical limits from RD RA when CRA

Acceptance Criteria :

Given

A TSO enables the TSO-specific curPMax parameter for a RAO run. The global curPMax parameter is disabled.

When

The optimisation terminates successfully,

Then

The Pmax limit of generating units within that TSO region must have been respected by the

optimisation when determining RD RA.

Given

A TSO disables the TSO-specific curPMax parameter for a RAO run. The global curPMax parameter is enabled.

When

The optimisation terminates successfully,

Then

The Pmax limit of generating units within that TSO region must not have been respected by the optimisation when determining RD RA.

Given

<!-- page 271 -->

A TSO enables the TSO-specific curPMin parameter for a RAO run. The global curPMin parameter is disabled.

When

The optimisation terminates successfully,

Then

The Pmin limit of generating units within that TSO region must have been respected by the

optimisation when determining RD RA.

Given

A TSO disables the TSO-specific curPMin parameter for a RAO run. The global curPMin parameter is enabled.

When

The optimisation terminates successfully,

Then

The Pmin limit of generating units within that TSO region must not have been respected by the optimisation when determining RD RA.

<!-- page 272 -->

### 3.11 Optimisation results

#### CORNET-3632: Consideration of RD step size

##### Description

Use Case: The optimisation shall consider that each Power Bid has an available countertrade (CT) / redispatch (RD) volume and corresponding CT/RD step size (stepSizeCTRD) defined for each optimisation time stamp. An increase or decrease of the CT/RD volume is therefore only possible in discrete increments of size stepSizeCTRD. The minimum size and default value of stepSizeCTRD is 1 MW.

The number of possible steps for each Bid, each of size stepSizeCTRD, in both positive (Bid up ) and $negative (Bid_{down}$) direction are modelled using two discrete decision variables $\Delta r_{\mathit{CT}/\mathit{RD},b}^{+} (t)$ and $\Delta r_{\mathit{CT}/\mathit{RD},b}^{-} (t)$ per Power Bid. The activated CT or RD volume ($\Delta P_{b}^{+}$ / $\Delta P_{b}^{-}$) cannot exceed the available CT/RD volume of the Power Bid ($P_{b,\max}$) for each time stamp.

$$
\Delta P_{b}^{+} (t) = \mathit{stepSizeCTRD}_{b} (t) \cdot \Delta r_{\mathit{CT}/\mathit{RD},b}^{+} (t) \\
\Delta P_{b}^{-} (t) = \mathit{stepSizeCTRD}_{b} (t) \cdot \Delta r_{\mathit{CT}/\mathit{RD},b}^{-} (t) \\
\Delta P_{b}^{+} (t) + \Delta P_{b}^{-} (t) \leq P_{b,\max} (t)
$$

If no value for stepSizeCTRD is given within the Power Bid Schedule, the default value of 1 MW is used in the RAO for stepSizeCTRD.

##### Configuration

| Name | Description | Unit s | Data type | Time series/ constant | Profile |
| --- | --- | --- | --- | --- | --- |
| stepSizeCTRD | Step size in which the RAO can choose the CT or RD. If nothing is defined 1 MW will be assumed. |  | MW double | time series | SecuritySchedule Profile PowerBidSchedul eTimePoint.stepin cmentP |
| stepSizeCTRDAct ive | Control Parameter to activate (“true”) or deactivate ("false”) CT/RD step sizes in RAO. Default value is “true”. | - | Bool | constant | RAO-Control- Parameter |

<!-- page 273 -->

##### Details / Background

> **Figure (page 273) — described in text.**
>
> Two stacked charts of *Active Power* against *Time*, with RAO time stamps at 02:30, 06:30 and 10:30.
>
> **a) RD Potential including discrete step sizes of a Generating Unit** — an orange *PROD before Optimisation* curve steps up after 02:30 and back down before 10:30. Parallel to it run several evenly spaced light-green lines above (*PROD before Optimisation + n_up · stepSize*) and dark-green lines below (*PROD before Optimisation − n_down · stepSize*). A brace on the vertical axis marks one *stepSizeRD* increment.
> **b) RD Potential including discrete step sizes and P_Min and/or P_Max of a Generating Unit** — the same ladder of discrete levels, now with a purple *P_Max* line above and a yellow *P_Min* line below. Where P_Min rises above the lower green steps (around 06:30–10:30) the enclosed region is hatched red — the *Prohibited Area for change in active power* — so those discrete steps are unavailable.

Figure 19: example of discrete RD step sizes

Example: A generating unit with a given PROD for the timeframe between 00:30 am and 01:30 pm offers two bids – one in positive and one in negative direction – that both can be retrieved in two discrete denominations of stepSize as depicted in Figure 19. In case PROD before Optimisation + n up * stepSize or PROD before Optimisation – n down * stepSize exceeds a considered P Min and/or P Max (example b)), these increments in RD are not possible. In the given example, this is the case for n in the timeframe down between 06:30 and 10:30.

##### Outlook

This chapter is only for informational purposes and is not part of the delivered specification.

The consideration of discrete CT/RD step sizes can lead to a significant increase of computing time. Future approaches will deal with performance improvements.

Business Needs :

BN620: RAO-RA_RDStepSize

Use Cases :

BUC 14#30 Consideration of RD step sizes from Power Bids

<!-- page 274 -->

##### Acceptance Criteria:

Given

The RAO considers RD RA with Power Bids which have a stepSizeCTRD defined. The parameter stepSizeCTRDActive is set to true.

When

The optimisation terminates successfully,

Then

The activated RD volume of these Power Bids must be a multiple of the corresponding stepSizeCTRD. Given

The RAO considers CT RA with Power Bids which have a stepSizeCTRD defined. The parameter stepSizeCTRDActive is set to true.

When

The optimisation terminates successfully,

Then

The activated CT volume of these Power Bids must be a multiple of the corresponding stepSizeCTRD.

#### BUC 14#132 General Optimisation results

##### Scenario

#### BUC 14#132 General Optimisation results

The RAO returns general optimisation results for the GUI, such as RD and CT volumes, as well as costs for the use of RD/CT/PST PRAs and CRAs.

##### Description

A summary overview of the most important results is shown in the GUI after the RAO calculation is finished. The RAO calculates the necessary results in a final step and provides the information to the GUI via the RAOResultsProfile.

The summary contains information on the overall RD / CT volume and cost, as well as penalty costs for PST, HVDC setpoint changes and remaining overloads.

##### Outlook

In upcoming releases with the consideration of additional remedial actions the result output will be extended.

<!-- page 275 -->

##### Configuration

The following table represents output data of the RAO:

| Name |  |  | Descripti |  | Unit |  |  | Data |  |  | Time Series |  |  | CoMo-Object |  |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
|  |  |  | on |  |  |  |  | Type |  |  | / Constant |  |  |  |  |
| sumRDVolumePo s |  | Sum of positive RD volume of all determin ed remedial action |  |  | MW |  | Integer |  |  | Constant |  |  |  | RAOResultsProfile: RAOResultsOverview.sumRDVo lumePos |  |
| sumRDVolumeNe g |  | Sum of negative RD volume of all determin ed remedial action |  |  | MW |  | Integer |  |  | Constant |  |  |  | RAOResultsProfile: RAOResultsOverview.sumRDVo lumeNeg |  |
| sumCTVolumePo s |  | Sum of positive CT volume of all determin ed remedial action |  |  | MW |  | Integer |  |  | Constant |  |  |  | RAOResultsProfile: RAOResultsOverview.sumCTVo lumePos |  |
| sumCTVolumeN eg | Sum of negative CT volume of all determined remedial action |  |  |  |  | MW |  | Integer |  |  |  | Constan t | RAOResultsProfile: RAOResultsOverview.sumCTV olumeNeg |  |  |
| sumRDCost |  | Sum of costs for all determin ed remedial actions because of redispatc h |  |  | € |  | Float |  |  | Constant |  |  |  | RAOResultsProfile: RAOResultsOverview.sumRDC ost |  |
| sumCTCost |  | Sum of costs for all |  |  | € |  | Float |  |  | Constant |  |  |  | RAOResultsProfile: RAOResultsOverview.sumCTCo st |  |

<!-- page 276 -->

|  | determin ed remedial actions because of countertr ade |  |  |  |  |  |  |  |  |  |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| sumRDPenaltyCo st | Sum of penalty costs for all determin ed remedial actions because of redispatc h | € |  | Float |  | Constant |  |  | RAOResultsProfile: RAOResultsOverview.sumRDPe naltyCost |  |
| sumPSTPenaltyC ost | Sum of penalty costs from PST tap changes | € |  | Float |  | Constant |  |  | RAOResultsProfile: RAOResultsOverview.sumPSTP enaltyCost |  |
| sumHVDCPenalt yCost | Sum of penalty costs from HVDC setpoint changes |  | € |  | Float |  | Constan t | RAOResultsProfile: RAOResultsOverview.sumHVDC PenaltyCost |  |  |
| objectiveValue | The last objective function value given by the optimisatio n. |  | - |  | Float |  | Constan t | RAOResultsProfile: RAOResultsOverview.objectiveV alue |  |  |
| sumPRAPenaltyC ostRD | Sum of penalty costs for all determined RD PRA |  | € |  | Float |  | Constan t | RAOResultsProfile: RAOResultsOverview.sumPRAP enaltyCostRD |  |  |
| sumPRAPenaltyC ostCT | Sum of penalty costs for all determined CT PRA |  | € |  | Float |  | Constan t | RAOResultsProfile: RAOResultsOverview.sumPRAP enaltyCostCT |  |  |
| sumPRAPenaltyC ostPST | Sum of penalty costs for all | € |  | Float |  | Constant |  |  | RAOResultsProfile: RAOResultsOverview.sumPRA PenaltyCostPST |  |

<!-- page 277 -->

|  | determin ed PST PRA |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| sumPRAPenaltyCo stHVDC |  |  | Sum of penalty costs for all determine d HVDC PRA |  | € |  |  | Float |  |  | Constan t |  | RAOResultsProfile: RAOResultsOverview.sumPRAP enaltyCostHVDC |  |  |  |
| sumCRAPenaltyCo stRD |  |  | Sum of penalty costs for all determine d RD CRA |  | € |  |  | Float |  |  | Constan t |  | RAOResultsProfile: RAOResultsOverview.sumCRAP enaltyCostRD |  |  |  |
| sumCRAPenaltyCo stCT |  |  | Sum of penalty costs for all determine d CT CRA |  | € |  |  | Float |  |  | Constan t |  | RAOResultsProfile: RAOResultsOverview.sumCRAP enaltyCostCT |  |  |  |
| sumCRAReservatio nCostRD |  |  | Sum of reservatio n costs for all determine d RD CRA |  | € |  |  | Float |  |  | Constan t |  | RAOResultsProfile: RAOResultsOverview.sumCRAR eservationCostRD |  |  |  |
| sumCRAReservatio nCostCT |  |  | Sum of reservatio n costs for all determine d CT CRA |  | € |  |  | Float |  |  | Constan t |  | RAOResultsProfile: RAOResultsOverview.sumCRAR eservationCostCT |  |  |  |
| sumCRAPenalty CostPST | Sum of penalty costs for all determin ed PST CRA |  |  | € |  |  | Float |  |  | Constant |  |  |  |  | RAOResultsProfile: RAOResultsOverview.sumCRA PenaltyCostPST |  |
| sumCRAPenaltyC ostHVDC |  | Sum of penalty costs for all determined HVDC CRA |  |  |  | € |  |  | Float |  |  | Constan t |  | RAOResultsProfile: RAOResultsOverview.sumCRA PenaltyCostHVDC |  |  |
| sumPATLPenalty Cost |  | Sum of penalty costs for the remaining overloads on XNE |  |  |  | € |  |  | Float |  |  | Constan t |  | RAOResultsProfile: RAOResultsOverview.sumPAT LPenaltyCost |  |  |

<!-- page 278 -->

| sumTATLPenaltyC ost | Sum of penalty costs for the remaining overloads in contingencie s on XNE | € | Float | Constan t | RAOResultsProfile: RAOResultsOverview.sumTATL PenaltyCost |
| --- | --- | --- | --- | --- | --- |
| sumSEPenaltyCos t | Sum of penalty costs for the remaining overloads on scanned elements | € | Float | Constan t | RAOResultsProfile: RAOResultsOverview.sumSEP enaltyCost |
| sumSCPenaltyCos t | Sum of penalty costs for the remaining overloads on system constraints | € | Float | Constan t | RAOResultsProfile: RAOResultsOverview.sumSCP enaltyCost |

##### Business Rules

When available, general results are written to the RAOResultsProfile.

##### Triggers

The RAO started successfully and all pre-conditions are met.

##### Pre-Condition

All relevant input data is delivered.

At least one correctly defined assessed element is part of the AE-FlatList.

The RAO must successfully finish the optimization.

##### Acceptance Criteria

Given

The optimisation process has terminated successfully.

When

The results are reported,

Then

General optimisation results are written into the results profile RAOResultsOverview.

##### Basic Flow

The RAOResultsProfile is exported to CDS.

<!-- page 279 -->

##### Alternative Flow

If the RAO fails, no result data is exported.

#### SF3078: PowerScheduleAction Optimisation results

##### Scenario

BUC 14#133 Return the results of redispatch RA

The RAO returns the results of the load-flow calculation, the outage calculation and sensitivity calculation of redispatch RA for each timestamp and the entire optimization time frame. The results consist of data on active power set points and changes, as well as penalty costs.

BUC 14#134 Return the results of countertrade RA

The RAO returns the results of the load-flow calculation, the outage calculation and sensitivity calculation of countertrade RA for each timestamp and the entire optimization time frame. The results consist of data on active power set points and changes, as well as penalty costs.

##### Description

The RAO exports the results of RD and CT RA via the RemedialActionScheduleProfile as PowerScheduleAction . Each activated PowerBid is exported as a PowerSchedule with information on the activated power and costs.

The information is shown in the GUI of the RAO and used in the RAC.

##### Outlook

The results are given in a time series with an hourly resolution. In future releases the option of an output with a resolution of 15 minutes will be given.

##### Configuration

The following table represents output data of the RAO:

| Name |  | Description |  |  | Unit | Data Type |  |  | Time |  | CoMo-Object |  |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
|  |  |  |  |  |  |  |  |  | Series / |  |  |  |
|  |  |  |  |  |  |  |  |  | Constant |  |  |  |
| name |  | Name of the PowerScheduleAc tion (bid) |  |  | - | String |  | Constant |  |  | RAS: PowerScheduleAction.n ame |  |
| actionKind | Redispatch or Countertrad e |  | - | Enumeration |  |  | Consta nt | RAS: PowerScheduleAction.powerSche duleActionKind |  |  |  |  |
| tso | TSO of power bid |  | - | String |  |  | Time Series | RAS: PowerScheduleAction -> PowerSchedule.tso |  |  |  |  |

<!-- page 280 -->

| powerShiftK ey | PSK of the power bid |  |  |  |  | - | String |  |  |  |  |  |  |  |  |  |  |  |  | RAS: PowerScheduleAction -> PowerSchedule.powerShiftKey |  |  |  |  |  |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| deltaP | Change in neg. or pos. active power by power bid |  |  |  |  | M W | Integer |  |  |  |  |  |  |  |  | Time Series |  |  |  | RAS: PowerScheduleAction -> PowerSchedule -> PowerTimePoint.activatedP |  |  |  |  |  |
| initialPsetpoin t |  |  | Initial active power setpoint of power bid |  |  |  |  |  |  | MW |  |  |  |  | Integer |  |  |  |  | Time Series |  |  |  | RAS: PowerScheduleAction - > PowerSchedule -> PowerTimePoint.initialP |  |
| resultPsetpoi nt |  | Resulting active power setpoint of power bid |  |  |  |  |  |  | MW |  |  |  | Integer |  |  |  |  |  | Time Series |  |  |  | RAS: PowerScheduleAction -> PowerSchedule -> PowerTimePoint.p |  |  |
| marginP |  | Remaining available active power for power bid |  |  |  |  |  |  | MW |  |  |  | Integer |  |  |  |  |  | Time Series |  |  |  | RAS: PowerScheduleAction -> PowerSchedule -> PowerTimePoint.margi nP |  |  |
| CostBid |  |  | Costs of power bid because of redispatch or countertrade |  |  |  |  |  |  | € |  |  |  |  | Float |  |  |  |  | Time Series |  |  |  | RAS: PowerScheduleAction - > PowerSchedule -> PowerTimePoint.activat edPrice |  |
| PenaltyCosts Bid |  |  | Penalty costs of determined redispatch or countertrade from power bid |  |  |  |  |  |  | € |  |  |  |  | Float |  |  |  |  | Time Series |  |  |  | RAS: PowerScheduleAction - > PowerSchedule -> PowerTimePoint.penalt yCosts |  |
| activationCost sBid |  |  |  | Activation costs of Power Bid |  |  |  | € |  |  | Float |  |  |  |  |  | Time Series |  |  |  | RAS: PowerScheduleAction -> PowerSchedule -> PowerTimePoint.startUpCosts |  |  |  |  |
| reservationCos tsBid |  |  |  | Reservation Costs of Power Bid |  |  |  | € |  |  | Float |  |  |  |  |  | Time Series |  |  |  | RAS: PowerScheduleAction -> PowerSchedule -> PowerTimePoint.reservationC osts |  |  |  |  |
| CostRA |  |  |  | Sum of the operational costs for the RA |  |  |  | € |  |  | Float |  |  |  |  |  | Time Series |  |  |  | RAS: RemedialActionSchedule -> RemedialActionCost.operation alCost |  |  |  |  |
| activationCosts RA |  |  |  |  | Sum of the activation costs for the RA |  |  |  |  |  |  | € |  | Float |  |  |  | Time Series |  |  |  | RAS: RemedialActionSchedul e -> RemedialActionCost.ot herCost |  |  |  |

<!-- page 281 -->

##### Business Rules

If PowerScheduleAction optimization results are available, they are written to RAS profile .

##### Triggers

The RAO started successfully and all pre-conditions are met.

##### Pre-Condition

All relevant input data is delivered, see:

• CORNET-335: Data model – Generating Units

• CORNET-4847: Consideration of Countertrade

At least one correctly defined assessed element is part of the AE-FlatList.

The RAO must finish the optimization sucessfully.

##### Acceptance Criteria

Given

The optimisation process has terminated successfully.

When

The results are reported,

Then

The results of RD and CT RA are exported as PowerScheduleAction via the RemedialActionScheduleProfile.

##### Basic Flow

The RemedialActionSchedule profile is exported to CDS.

##### Alternative Flow

If the RAO fails, no result data is exported.

#### SF3079: GridStateIntensitySchedule Optimisation results

##### Scenario

BUC 14#135 Return the results of phase shift transformer RA

The tap position information of transformers (initial, resulting) and penalty costs are exported via the GridStateIntensitySchedule.

BUC 14#145 Results of HVDC

The RAO must export the results of HVDC systems, which are modelled via Equivalent Injections.

<!-- page 282 -->

The results contain the change of the setpoints, the initial and resulting setpoints, as well as the resulting penalty costs.

UC8931: BUC 14#146 Results of topology RA

The RAO must export the results of the topological RA as an GridStateIntensityschedule after the optimisation.

##### Description

The result of a GridStateAlteration is exported via the GridStateIntensitySchedule in the RemedialActionScheduleProfile . This includes the results of transformers, HVDC connections and topological XRA.

For transformers the initial, resulting and change in tap positions are exported, as well as the penalty costs and additional information on the location and TSO of the transformer.

For HVDC connections the initial, resulting and change in active power setpoints are exported, as well as the penalty costs and additional information on the location and TSO of the HVDC connection. For topological XRA the initial, resulting and change in status of the switching equipment are exported, as well as additional information on the location and TSO of the equipment.

##### Outlook

The results are given in a time series with an hourly resolution. In future releases the option of an output with a resolution of 15 minutes will be given.

##### Configuration

The result output of transformers is as followed:

| Name | Description | Un it | Data Type |  | Time |  | CoMo-Object |
| --- | --- | --- | --- | --- | --- | --- | --- |
|  |  |  |  |  | Serie |  |  |
|  |  |  |  |  | s / |  |  |
|  |  |  |  |  | Const |  |  |
|  |  |  |  |  | ant |  |  |
| deltaTap | Change of PST taps | - | Integer | Time Series |  |  | RAS: GridStateIntensitySchedule -> GenericValueTimePoint.deltaValue |
| initialTap | Initial tap position of PST | - | Integer | Time Series |  |  | RAS: GridStateIntensitySchedule -> GenericValueTimePoint.initialValue |
| resultTap | Resulting tap position of PST | - | Integer | Time Series |  |  | RAS: GridStateIntensitySchedule -> GenericValueTimePoint.value |

<!-- page 283 -->

| PSTPenaltyCos t | Resulting penalty costs from PST tap changes | € | Float | Time Series | RAS: GridStateIntensitySchedule -> GenericValueTimePoint.penaltyCosts |
| --- | --- | --- | --- | --- | --- |
| tso | TSO of the PST | - | String | Const ant | RAS: GridStateIntensitySchedule.tso |
| terminal | Terminal of the PST | - | String | Const ant | RAS: GridStateIntensitySchedule.terminal |
| gridStateAlterati onType | The type of the GridStateAlte ration. Here: PST | - | Enumer ation | Const ant | RAS: GridStateIntensitySchedule.gridStateAl terationType::PST |

The result output of HVDC is as followed:

| Name | Description | U nit | Data Type | Time Serie s / Const ant | CoMo-Object |
| --- | --- | --- | --- | --- | --- |
| deltaSetpoint | Change of HVDC setpoint | - | Integer | Time Series | RAS: GridStateIntensitySchedule -> GenericValueTimePoint.deltaValue |
| initialSetpoint | Initial setpoint of HVDC | - | Integer | Time Series | RAS: GridStateIntensitySchedule -> GenericValueTimePoint.initialValue |
| resultSetpoint | Resulting setpoint of HVDC | - | Integer | Time Series | RAS: GridStateIntensitySchedule -> GenericValueTimePoint.value |
| HVDCPenaltyC ost | Resulting penalty costs from HVDC setpoint changes | € | Float | Time Series | RAS: GridStateIntensitySchedule -> GenericValueTimePoint.penaltyCosts |
| tso | TSO of the HVDC | - | String | Const ant | RAS: GridStateIntensitySchedule.tso |
| terminal | Terminal of the HVDC | - | String | Const ant | RAS: GridStateIntensitySchedule.terminal |
| gridStateAlterat ionType | The type of the GridStateAlt eration. Here: HVDC | - | Enumer ation | Const ant | RAS: GridStateIntensitySchedule.gridStateAlt erationType::HVDC |

The result output of topological XRA is as followed:

| Name | Description | U nit | Data | Time Serie s / Const ant | CoMo-Object |
| --- | --- | --- | --- | --- | --- |
|  |  |  | Type |  |  |
| switchAction | Change of switch status (1 = closed, 0 = open) | - | Integer | Time Series | RAS: GridStateIntensitySchedule -> GenericValueTimePoint.deltaValue |

<!-- page 284 -->

| initialSwitchPos ition | Initial switch position (1 = closed, 0 = open) | - | Integer | Time Series | RAS: GridStateIntensitySchedule -> GenericValueTimePoint.initialValue |
| --- | --- | --- | --- | --- | --- |
| resultSwitchPo sition | Resulting switch position (1 = closed, 0 = open) | - | Integer | Time Series | RAS: GridStateIntensitySchedule -> GenericValueTimePoint.value |
| tso | TSO of the switch | - | String | Const ant | RAS: GridStateIntensitySchedule.tso |
| terminal | Terminal of the switch | - | String | Const ant | RAS: GridStateIntensitySchedule.terminal |
| gridStateAlterat ionType | The type of the GridStateAlt eration. Here: topoRA | - | Enumer ation | Const ant | RAS: GridStateIntensitySchedule.gridStateAlt erationType::topoRA |

##### Business Rules

If GridStateIntensitySchedule optimisation results are available, they are written to the RAS profile.

##### Triggers

The RAO started successfully and all pre-conditions are met.

##### Pre-Condition

All relevant input data is delivered, see:

• CORNET-18: Consideration of PST

• BUC 14#55 RAO considers HVDC PRAs modelled as Equivalent Injections

• BUC 14#85: Read input of proposed or agreed topological XRAs

At least one correctly defined assessed element is part of the AE-FlatList.

The RAO must finish the optimization sucessfully.

##### Acceptance Criteria

Given

The RemedialActionSchedule contains PST tapping via a GridStateIntensitySchedule

When

The RAO successfully terminates,

Then

RAO will export the results of the PST tapping as a GridStateIntensitySchedule .

Given

<!-- page 285 -->

The RemedialActionSchedule contains HVDC connections via a GridStateIntensitySchedule

When

The RAO successfully terminates,

Then

RAO will export the results of the HVDC connections as a GridStateIntensitySchedule .

Given

The RemedialActionSchedule contains topological RA via a GridStateIntensitySchedule

When

The RAO successfully terminates,

Then

RAO will export the results of the topological XRA as a GridStateIntensitySchedule .

##### Basic Flow

The RemedialActionSchedule profile is exported to CDS.

##### Alternative Flow

If the RAO fails, no result data is exported.

#### BUC 14#153 Results for SPS

##### Scenario

#### BUC 14#153 Results for SPS

RAO returns the results of the basic non-coordinable SPS scheme.

##### Description

The RAO results for non-coordinable SPS are exported via the RAOResultsProfile to the RAO UI. The information for each SPS is stored in the RAOResultsNonCoordinableSPS class. If a non-coordinable SPS is activated for a certain timestamp is transmitted via the SPSTimePoint class.

##### Outlook

If necessary, the class is extended further for additional trigger and actions of non-coordinable SPS.

##### Configuration

The result output of non-coordinable SPS is as followed:

| Name |  | Descriptio |  |  | Uni |  | Data Type |  | Time |  | CoMo-Object |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
|  |  | n |  |  | t |  |  |  | Series / |  |  |

<!-- page 286 -->

|  |  |  |  |  | Consta |  |  |
| --- | --- | --- | --- | --- | --- | --- | --- |
|  |  |  |  |  | nt |  |  |
| name | Name of the SPS | - | String | Constan t |  |  | RAOResultsProfile: RAOResultsNonCoordinableSPS.name |
| tso | TSO for the SPS | - | String | Constan t |  |  | RAOResultsProfile: RAOResultsNonCoordinableSPS.tso |
| trigger | Trigger type of the SPS | - | Enumeratio n | Constan t |  |  | RAOResultsProfile: RAOResultsNonCoordinableSPS.trigger |
| spsKind | Action class of the SPS | - | Enumeratio n | Constan t |  |  | RAOResultsProfile: RAOResultsNonCoordinableSPS.spsKi nd |
| outage | Contingenc y which is the trigger | - | String | Constan t |  |  | RAOResultsProfile: RAOResultsNonCoordinableSPS.outag e |
| equipment | Name of the equipment | - | String | Constan t |  |  | RAOResultsProfile: RAOResultsNonCoordinableSPS.equip ment |
| action | Concrete action of the SPS (e.g. switch.ope n) | - | String | Constan t |  |  | RAOResultsProfile: RAOResultsNonCoordinableSPS.action |
| originalStat e | Original state of the equipment | - | String | Time Series |  |  | RAOResultsProfile: RAOResultsNonCoordinableSPS -> SPSTimePoint.originalState |
| activated | Info if SPS is activated for the time stamp | - | bool | Time Series |  |  | RAOResultsProfile: RAOResultsNonCoordinableSPS -> SPSTimePoint.activated |

##### Business Rules

If SPS results are available, they are written to RAOResultsProfile.

##### Triggers

The RAO started successfully and all pre-conditions are met.

##### Pre-Condition

All relevant input data is delivered, see: BUC 14#11: Non-Coordinable SPS related to a contingency. At least one correctly defined assessed element is part of the AE-FlatList.

The RAO must finish the optimization sucessfully.

Non-coordinable SPS must be available for the RAO.

##### Acceptance Criteria

Given

<!-- page 287 -->

The optimisation process has terminated successfully.

When

The results are reported,

Then

The result output of non coordinable SPS is written into the results profile RAOResultsNonCoordinableSPS.

##### Basic Flow

The RAOResultsProfile is exported to CDS.

##### Alternative Flow

If the RAO fails, no result data is exported.

#### BUC 14#137 Generating Unit Optimisation results

##### Scenario

#### BUC 14#137 Generating Unit Optimisation results

The RAO delivers optimisation results not just for the RA but also for each generating unit.

##### Description

The RAO processes after the optimisation all power RA to show the change of the generating unit schedules. Information on the initial and resulting active power setpoints, remaining setpoint margins and the operational / penalty costs are given per generating unit.

##### Outlook

The results are given in a time series with an hourly resolution. In future releases the option of an output with a resolution of 15 minutes will be given.

##### Configuration

The result output of generating units is as followed:

| Name | Description Unit |  | Data Type |  | Time |  | CoMo-Object |
| --- | --- | --- | --- | --- | --- | --- | --- |
|  |  |  |  |  | Series / |  |  |
|  |  |  |  |  | Constant |  |  |
| GUmrid | MRID of the generating unit | - | String | Constant |  |  | RAOResultsProfile: RAOResultsGeneratingUnit.GUmrid |
| name | Name of the generating unit | - | String | Constant |  |  | RAOResultsProfile: RAOResultsGeneratingUnit.name |

<!-- page 288 -->

| tso | TSO responsible for generating unit | - | String | Constant | RAOResultsProfile: RAOResultsGeneratingUnit.tso |
| --- | --- | --- | --- | --- | --- |
| deltaP | Change in neg. or pos. active power by generating unit | MW | Double | Time Series | RAOResultsProfile: RAOResultsGeneratingUnit.deltaP |
| initialPsetpoint | Initial active power setpoint of generating unit | MW | Double | Time Series | RAOResultsProfile: RAOResultsGeneratingUnit. initialPsetpoint |
| resultPsetpoint | Resulting active power setpoint of generating unit | MW | Double | Time Series | RAOResultsProfile: RAOResultsGeneratingUnit. resultPsetpoint |
| marginPPos | Remaining available active power for generating unit | MW | Double | Time Series | RAOResultsProfile: RAOResultsGeneratingUnit. marginPPos |
| marginPNeg | Remaining available active power for generating unit | MW | Double | Time Series | RAOResultsProfile: RAOResultsGeneratingUnit. marginPNeg |
| rdCost | Costs of generating unit because of redispatch | € | Float | Time Series | RAOResultsProfile: RAOResultsGeneratingUnit.rdCost |
| ctCost | Costs of generating unit because of countertrade | € | Float | Time Series | RAOResultsProfile: RAOResultsGeneratingUnit.ctCost |
| rdPenaltyCosts Penalty | costs of determined redispatch from generating unit | € | Float | Time Series | RAOResultsProfile: RAOResultsGeneratingUnit. rdPenaltyCost |
| startupCosts | Start-up costs of | € | Float | Time Series | RAOResultsProfile: RAOResultsGeneratingUnit. startupCost |

<!-- page 289 -->

|  | generating unit |  |  |  |  |
| --- | --- | --- | --- | --- | --- |
| shutdownCosts Shut-down | costs of generating unit | € | Float | Time Series | RAOResultsProfile: RAOResultsGeneratingUnit. shutdownCost |

##### Business Rules

If generating unit optimization results are available, they are written to RAOResultsProfile.

##### Triggers

The RAO started successfully and all pre-conditions are met.

##### Pre-Condition

All relevant input data is delivered, see CORNET-335: Data model – Generating Units.

At least one correctly defined assessed element is part of the AE-FlatList.

The RAO must finish the optimisation successfully.

##### Acceptance Criteria

Given

The optimisation process has terminated successfully.

When

The results are reported,

Then

The result output of each generating unit is written into the results profile RAOResultsGeneratingUnit .

##### Basic Flow

The RAOResultsProfile is exported to CDS.

##### Alternative Flow

If the RAO fails, no result data is exported.

#### BUC 14#138 Net positions and TSO exchange results

##### Scenario

#### BUC 14#138 Net positions and TSO exchange results

The RAO delivers optimisation result overview of:

• available counter trade potential of all TSOs before and after optimisation

• net positions

<!-- page 290 -->

• exchange between TSOs

##### Description

As a last step after the optimisation, before the RAO Job finishes, the RAO processes the countertrade RAs and summarizes the information on a per TSO basis. This includes the initial available countertrade volume before RAO and the remaining countertrade volume after RAO. The information is exported via the RAOResultsProfile .

Additionally, the resulting net position of a TSO after RAO is calculated and exported for the RAO GUI. The resulting active power exchange between two TSOs after RAO is also calculated and exported via the RAOResultsProfile .

##### Outlook

The results are given in a time series with an hourly resolution. In future releases the option of an output with a resolution of 15 minutes will be given.

When the modelling of HVDC connections changes to CGMES specific HVDC components and avoids the use of equivalentInjection , the correct resultPexchange between the two TSOs of the connection can be calculated.

##### Configuration

The result output of CT and the net positions is as followed:

| Name | Description Unit |  | Data Type |  | Time |  | CoMo-Object |
| --- | --- | --- | --- | --- | --- | --- | --- |
|  |  |  |  |  | Series / |  |  |
|  |  |  |  |  | Constant |  |  |
| tso | Name of the TSO | - | String | Constant |  |  | RAOResultsProfile: RAOResultsCountertrade.tso |
| posCTinitial | Available positive countertrade volume before RAO of TSO | MW | Integer | Time Series |  |  | RAOResultsProfile: RAOResultsCountertrade.ctInitialPos |
| negCTinitial | Available negative countertrade volume before RAO of TSO | MW | Integer | Time Series |  |  | RAOResultsProfile: RAOResultsCountertrade.ctInitialNeg |
| posCTmargin | Available positive countertrade | MW | Integer | Time Series |  |  | RAOResultsProfile: RAOResultsCountertrade.ctMarginPos |

<!-- page 291 -->

|  | volume after RAO of TSO |  |  |  |  |
| --- | --- | --- | --- | --- | --- |
| negCTmargin | Available negative countertrade volume after RAO of TSO | MW | Integer | Time Series | RAOResultsProfile: RAOResultsCountertrade.ctMarginNeg |
| netPosition | Net position of TSO after RAO | MW | Integer | Time Series | RAOResultsProfile: RAOResultsCountertrade.netPosition |

The result output of exchanges between TSOs is as followed:

| Name | Descriptio n | Uni t | Data Type |  | Time Series / Constan t | CoMo-Object |
| --- | --- | --- | --- | --- | --- | --- |
| tsoA | Identifier of the first TSO | - | String | Constant |  | RAOResultsProfile: RAOResultsExchange.tsoA |
| tsoB | Identifier of the second TSO | - | String | Constant |  | RAOResultsProfile: RAOResultsExchange.tsoB |
| resultPexchang e | Active power exchange between TSO A and TSO B | MW | Intege r | Time Series |  | RAOResultsProfile: RAOResultsExchange.resultPexchang e |

##### Business Rules

The initial CT volume before the RAO ( posCTinitial / negCTinitial ) is calculated by using all PowerRemedialAction of the PowerRemedialActionKind :: countertrade for each TSO. The positive CT volume is the sum of all p from PowerBidSchedule with direction::up , whereas the negative CT volume is the sum of all p from PowerBidSchedule with direction::down .

The remaining CT volume after the RAO ( posCTmargin / negCTmargin ) is calculated by using all PowerRemedialAction of the PowerRemedialActionKind :: countertrade for each TSO. The positive CT volume is the sum of all remaining (meaning not yet (fully) activated) p from PowerBidSchedule with direction::up , whereas the negative CT volume is the sum of all remaining (meaning not yet (fully) activated) p from PowerBidSchedule with direction::down .

The netPosition is calculated after the last LF-calculation of the RAO for each TSO from all types of production and load units.

<!-- page 292 -->

The resultPexchange is calculated after the last LF-calculation of the RAO for the neighbouring TSOs and represents the sum of the active power exchange between tsoA and tsoB on all cross-border elements.

HVDC connections are modelled via equivalentInjection (see BUC 14#55 RAO considers HVDC PRAs modelled as Equivalent Injections). Because of this alternative modelling approach for HVDC these elements are not considered for the calculation of the specific resultPexchange between the two TSOs of the HVDC connection. Instead, the active power exchange of a HVDC connection is always aggregated towards the boundary node (a so-called X node). The results show therefore the TSO- identifier for the grid the equivalentInjection is connected to and a second TSO as “X”.

##### Triggers

The RAO started successfully and all pre-conditions are met.

##### Pre-Condition

All relevant input data is delivered, see: CORNET-4847: Consideration of Countertrade.

At least one correctly defined assessed element is part of the AE-FlatList.

The RAO must finish the optimization successfully.

##### Acceptance Criteria

Given

The optimisation process has terminated successfully.

When

The results are reported,

Then

The result output of countertrade RA is written into the results profile RAOResultsCountertrade. Given

The optimisation process has terminated successfully.

When

The results are reported,

Then

The result output of exchanges between TSOs is written into the results profile RAOResultsExchange.

##### Basic Flow

The RAOResultsProfile profile is exported to CDS.

<!-- page 293 -->

##### Alternative Flow

If the RAO fails, no result data is exported.

#### BUC 14#141 Results of system constraints

This specification replaces CORNET-501.

##### Scenario

#### BUC 14#141 Results of system constraints

The RAO delivers results for system constraints.

##### Description

The results of system constraints, such as the initialValue and resultingValue are exported after the RAO for an overview in the RAO UI. The limitType is used to differentiate between either active power or current limit. The lowerLimit and upperLimit of the system constraint, as well as the remaining penalty costs after RAO are delivered.

##### Configuration

The result output of system constraints is as followed:

| Name | Description | Unit | Data type | CoMo-Object |
| --- | --- | --- | --- | --- |
| mRID | mRID of the PowerTransferCorridor - |  | string | RAOResultsLoadFlowProfi le: RAOResultsSystemConstr aint.ptcMrid |
| name | NC profile-Name of the PowerTransferCorridor | - | string | RAOResultsLoadFlowProfi le: RAOResultsSystemConstr aint.name |
| tso | TSO of the system constraint | - | string | RAOResultsLoadFlowProfi le: RAOResultsSystemConstr aint.tso |
| limitType | Limit type of the system constraint: - Current - Active Power | - | Enum: -current | RAOResultsLoadFlowProfi le: |

<!-- page 294 -->

|  |  |  | - activePo wer | RAOResultsSystemConstr aint.scKind |
| --- | --- | --- | --- | --- |
| initialValue | Sum of active power or current of all elements of the system constraint before RAO | MW/A | float | RAOResultsLoadFlowProfi le: RAOResultsSystemConstr aint.initialValue |
| resultValue | Sum of active power or current of all elements of the system constraint after RAO | MW/A | float | RAOResultsLoadFlowProfi le: RAOResultsSystemConstr aint.resultValue |
| upperLimit | Upper limit of all elements of the system constraint in optimisation | MW/A | float | RAOResultsLoadFlowProfi le: RAOResultsSystemConstr aint.upperLimit |
| lowerLimit | Lower limit of all elements of the system constraint in optimisation | MW/A | float | RAOResultsLoadFlowProfi le: RAOResultsSystemConstr aint.lowerLimit |
| mRID_termi nal | mRID of the linked terminal in system constraint |  | string | RAOResultsLoadFlowProfi le: RAOResultsSystemConstr aint.terminalMrid |
| penaltyCost s | Remaining penalty costs after RAO | € | float | RAOResultsLoadFlowProfi le: RAOResultsSystemConstr aint.penaltyCosts |

##### Business Rules

If system constraint results are available, they are written to RAOResultsLoadFlowProfile.

##### Triggers

The RAO started successfully and all pre-conditions are met.

<!-- page 295 -->

##### Pre-Condition

All relevant input data is delivered, see: CORNET-498: System Constraints with active power limits, CORNET-537: System Constraints with current limits.

At least one correctly defined assessed element is part of the AE-FlatList.

The RAO must finish the optimization successfully.

System Constraints must be available in the input data and considered by the RAO.

##### Acceptance Criteria

Given

The optimisation process has terminated successfully.

When

The results are reported,

Then

The result output of system constraints is written into the results profile RAOResultsSystemConstraint.

##### Basic Flow

The RAOResultsLoadFlowProfile profile is exported to CDS.

##### Alternative Flow

If the RAO fails, no result data is exported.

#### BUC 14#142 Results of contingency calculation

This specification replaces CORNET-83.

##### Scenario

#### BUC 14#142 Results of contingency calculation

The RAO delivers results for net elements in contingency situations after the FOA and FCC.

##### Description

Depending on the defined monitoring limits (in the N-0 or N-1 case), the Fast Outage Approximation and Fast Contingency Calculation provide lists of contingency elements with the following result data: • N-0 case: loading absolute, percentage (see CORNET-32 – Consideration of XNEs)

• N-1 case: loading absolute, percentage with N-1 variant (with display of all contingencies, displayed number of contingency cases can be parameterised via the RAO Control Parameter contingencyOutput )

The loading is given for only one side of the element and always the higher value in terms of amount.

<!-- page 296 -->

##### Configuration

| Name | Description |  | Units | Da |  | CoMo-Object |
| --- | --- | --- | --- | --- | --- | --- |
|  |  |  |  | ta |  |  |
|  |  |  |  | ty |  |  |
|  |  |  |  | pe |  |  |
| IN0 | Current in N-0 case (one value) |  | kA | flo at |  | SAR: PowerFlowResult.valueA |
| ItoIrN0 | Loading in N-0 case (one value) |  | % | flo at |  | SAR: PowerFlowResult.value |
| PN0 | Active power in N-0 case (one value) |  | MW | flo at |  | SAR: PowerFlowResult.valueW |
| QN0 | Reactive power in N-0 case (one value) |  | MVar | flo at |  | SAR: PowerFlowResult.valueVA |
| operationalLimitKind | Limit kind for the operational limit (e.g. PATL) |  | enumera tion - p at l - ta tl |  | SAR: PowerFlowResult -> operationalLimit.kind |  |
| operationalLimit | Value for the operational limit |  | kA float |  | SAR: PowerFlowResult -> operationalLimit.operationalLimitV alue |  |
| operationalLimitDuration | Duration for the operational limit (TATL) | s | integer |  | SAR: PowerFlowResult -> operationalLimit.duration |  |
| penalty | Remaining penalty costs for the element | € | float |  | SAR: PowerFlowResult.penalty |  |
| ResultType | Definiton of the Result Type ( BaseCase , Contingency) | - | PowerFl owResult Kind |  | SAR: PowerFlowResult.powerFlowRes ultType |  |

<!-- page 297 -->

| mRID | mIRD of the element | - | string | SAR: PowerFlowResult.mRID |
| --- | --- | --- | --- | --- |
| Name | CGMES-Name of the element | - | string | SAR: PowerFlowResult.name |

| Name | Description |  | Units |  | D |  | CoMo-Object |
| --- | --- | --- | --- | --- | --- | --- | --- |
|  |  |  |  |  | at |  |  |
|  |  |  |  |  | a |  |  |
|  |  |  |  |  | ty |  |  |
|  |  |  |  |  | pe |  |  |
| INX | Current in N-X case (one value per contingency case) |  | kA | flo at |  |  | SAR: PowerFlowResult.valueA |
| ItoIrNX | Loading in N-X case (one value per contingency case) |  | % | flo at |  |  | SAR: PowerFlowResult.value |
| PNX | Active power in N-X case (one value per contingency case) |  | MW | flo at |  |  | SAR: PowerFlowResult.valueW |
| QNX | Reactive power in N-X case (one value per contingency case) |  | MVar | flo at |  |  | SAR: PowerFlowResult.valueVA |
| operationalLimitKind | Limit kind for the operational limit (e.g. PATL) |  | enumera tion - p a tl - t a tl |  |  | SAR: PowerFlowResult -> operationalLimit.kind |  |
| operationalLimit | Value for the operational limit |  | kA float |  |  | SAR: PowerFlowResult -> operationalLimit.operationalLimit Value |  |

<!-- page 298 -->

| operationalLimitDuration | Duration for the operational limit (TATL) | s | integer | SAR: PowerFlowResult -> operationalLimit.duration |
| --- | --- | --- | --- | --- |
| penalty | Remaining penalty costs for the element | € | float | SAR: PowerFlowResult.penalty |
| NXContingency | Relevant contingency case | - | string | SAR: PowerFlowResult.Contingency |
| ResultType | Definiton of the Result Type (BaseCase, Contingency ) | - | PowerFl owResul tKind | SAR: PowerFlowResult.powerFlowRes ultType |
| mRID | mIRD of the element | - | string | SAR: PowerFlowResult.mRID |
| Name | CGMES-Name of the element | - | string | SAR: PowerFlowResult.name |

The following global RAO Control Parameter has to be set at the beginning of the process:

| Name | Descri |  | Units | Data type | CoMo-Object |  |  |  |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
|  | ption |  |  |  |  |  |  |  |
| contingenc yOutput |  | Number of contingency cases in result output, sorted by impact on loading of XNE |  |  |  |  | - integer | RAOControlParameterProfile: RAOControlParameterSet. contingencyOutput |

##### Business Rules

If contingency calculation (FOA or FCC) results are available, they are written to SAR profile . The number of contingency cases per assess element which are exposed in the SAR profile is defined by the control parameter contingencyOutput.

##### Triggers

The RAO started successfully and all pre-conditions are met.

##### Pre-Condition

All relevant input data is delivered.

At least one correctly defined assessed element is part of the AE-FlatList.

The RAO must finish the optimization successfully.

<!-- page 299 -->

##### Acceptance Criteria

Given

The contingency calculation has been started and the number of output contingency cases

contingencyOutput is defined.

When

The optimisation process terminates successfully,

Then

The result output of the contingency calculation is written into the PowerFlowResult CoMo-Object.

##### Basic Flow

The SecurityAnalysisResult profile is exported to CDS.

##### Alternative Flow

If the RAO fails, no result data is exported.

<!-- page 300 -->

### 3.12 Output of additional RAO information

#### CORNET-3697: Storing additional RAO information in output files

##### Description

The RAO can provide additional log information of the optimisation procedure for each run. The content of this additional information can be configured via RAO control parameters. The files (described below) are stored on the local S3 storage and can be downloaded by the user (see CORNET-4344: Exporting the additional RAO information).

The following information can be part of this additional export and is described further below: • The results of the RAO

• The active branch constraints of the optimisation problem

• The information of the considered RAs and Power Bids

• The calculated sensitivities within the RAO

If the parameter logResults is activated, the RAO results defined in

• CORNET-107: Results per topological node

• CORNET-3221: Results per AC line segment and 2W transformer

• CORNET-109: Results per 3W transformer

• CORNET-83: Results of outage approximation

• CORNET-76: Optimisation results

• CORNET-501: Results of System Constraints

are exported in result files for the corresponding run. The data format of the result files is CSV. The files will provide the information per time stamp. Each file name contains the business day and RAO ID.

If the parameter logConstraints is activated, the RAO exports the identifiers of the considered branch (lines and transformers) constraints in the optimisation problem. The data format of the constraint file is TXT. The file name contains the business day and RAO ID.

Note: System constraints are always considered in the optimisation problem. Therefore, they are not part of the logConstraints .

If the parameter logRA is activated, the RAO exports the information on all the considered CT & RD RA within the optimisation. This allows the user to get an overview which RAs and Power Bids are considered within the RAO from the input data. The files contain information on the mRIDs of the RAs

<!-- page 301 -->

and Power Bids, as well as the available CT or RD volume and price from the Power Bids for each time stamp (see example table header below).

The data format of the CT and RD RA files is CSV. The file name contains the business day and RAO ID.

| RA mRID |  | Power Bid |  | CT/RD volume & price |  |  | CT/RD volume & price |  |  | CT/RD volume & price (... time stamp) |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
|  |  | mRID |  | (first time stamp) |  |  | (second time stamp) |  |  |  |

Additionally, the RAO exports the information on all considered transformer RA within the optimisation. The files contain information on the mRIDs of the RA, as well as the available minimum and maximum tap changes and penalty costs for each tap change. The information is given per time stamp. The data format of the transformer RA files is CSV. The file name contains the business day and RAO ID.

| RA mRID |  | Transformer |  | MinTap/MaxTap & |  |  | MinTap/MaxTap & penalty |  | MinTap/MaxTap & penalty (... time stamp) |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
|  |  | mRID |  | penalty (first time stamp) |  |  | (second time stamp) |  |  |

If the parameter logSensitivities is activated, the RAO exports the calculated sensitivities for the PSTs and RD units considered within the RAO run. The sensitivity output is described in CORNET-102: Sensitivity results. Exported are the initial (from the first iteration) and the final (from the last iteration) sensitivities of the RAO run. The data format of the sensitivity output is CSV. The file name contains the business day and RAO ID.

##### Configuration

Data requirements for the RA Deciding Point:

| Name | Description | Units | Data type | Mandatory Profile |  |
| --- | --- | --- | --- | --- | --- |
| logResults | Enable/Disable the output of RAO results in log | - | Bool no |  | RAO Setting |
| logConstraints | Enable/Disable the output of the branch constraint names considered in the optimisation problem | - | Bool no |  | RAO Setting |
| logRA | Enable/Disable the output of the considered RAs and Power Bids | - | Bool no |  | RAO Setting |
| logSensitivities | Enable/Disable the output of the initial and final sensitivities | - | Bool no |  | RAO Setting |

<!-- page 302 -->

##### Outlook

This chapter is only for informational purposes and is not part of the delivered specification.

If necessary, the output of additional logs could be defined for future releases.

This could be, for example, the output of additional information for each iteration step such as the determined RAs or Power Bids. Additionally, to the mRIDs also the names of the units/ GLSK will be included.

Business Needs :

BN841: RAO-#135_basic

Use-Cases :

UC323: BUC 14#38 Storing additional RAO information in output files

Acceptance Criteria :

Given

The user activates the logResult setting before starting the RAO run.

When

The optimisation terminates successfully,

Then

The RAO results defined in the specifications are available in CSV file format.

Given

The user activates the logConstraints setting before starting the RAO run.

When

The optimisation terminates successfully,

Then

The identifiers of the branch constraints (name of the line/transformer | corresponding outage (if available)) considered in the optimisation problem of the RAO are available in TXT file format. Given

The user activates the logRA setting before starting the RAO run.

When

The optimisation terminates successfully,

Then

The considered RA in the RAO are available in CSV file format.

<!-- page 303 -->

Given

The user activates the logSensitivities setting before starting the RAO run.

When

The optimisation terminates successfully,

Then

The initial and final sensitivities of the RAO run are available in CSV file format.

#### CORNET-4344: Exporting the additional RAO information

##### Description

If additional information from the RAO run is saved in the S3 storage (see CORNET-3697: Storing additional RAO information in output files), these files can be accessed via a download for further inspection. When the user downloads the files via the GUI, they are bundled together in a single compressed ZIP file. The file name of this ZIP file has the format “RAO- Protocol_BusinessDay[date]_RAOID.zip”.

Business Needs :

BN841: RAO-Protocol_basic

Use-Cases :

UC324: BUC 14#39 Export of additional RAO information

Acceptance Criteria :

Given

The user has enabled at least one of the additional RAO information before the start of the RAO. When

The optimisation terminates successfully and the information is stored on the S3,

Then

The user can download the information and gets a compressed ZIP file with all the requested files.

<!-- page 304 -->

### 3.13 Update of CoMo

#### SF2927: Update CoMo to baseline R25_1

##### Scenario

BUC 14#122 RAO-CoMo: Update CoMo to Baseline for R25_1 (RAOCCRControlParameter-Profile) BUC 14#124 RAO-CoMo: Update CoMo to Baseline for R25_1 (RemedialActionSchedule-Profile) BUC 14#123 RAO-CoMo: Update CoMo to Baseline for R25_1 (SecurityAnalysisResult-Profile) BUC 14#125 RAO-CoMo: Update CoMo to Baseline for R25_1 (Matrix-Profile)

BUC 14#126 RAO-CoMo: Update CoMo to Baseline for R25_1 (RA-FlatList)

BUC 14#127 RAO-CoMo: Update CoMo to Baseline for R25_1 (CO-Flatlist)

BUC 14#128 RAO-CoMo: Update CoMo to Baseline for R25_1 (AE-Flatlist)

The RAO must consider any changes in the CoMo Baseline for R25_1.

##### Description

The RAO must consider and be able to process any changes in the CoMo Baseline for R25_1. Input and output data, as well as the CoMo schema-validator need to be updated accordingly.

##### Business Rules

The RAO considers changes to the CoMo Baseline for the following:

- RAOControlParameter-Profile

- RAOResultsProfile

- RAOResultsLoadFlowProfile

- RemedialActionScheduleProfile

- SecurityAnalysisResultProfile

- FullMatrixProfile

- RemedialActionFlatList

- ContingencyFlatList

- AssessedElementFlatList

- SPSFlatList

##### Triggers

No trigger needed

<!-- page 305 -->

##### Pre-Condition

Default behaviour. At least one of the files listed under Business Rules must be available in the format defined for R25_1.

##### Acceptance Criteria

Given

The RAO is started and has the RAOControlParameterProfile as input data.

When

The RAO has read the input data

Then

The RAO must have mapped the available information of the RAOControlParameterProfile to the internal RAO settings and parameters.

Given

The RAO is started with all necessary data.

When

The RAO has successfully finished the optimisation

Then

The RAO must have written the overview results for the GUI in the RAOResultsOverviewProfile. Given

The RAO is started with all necessary data.

When

The RAO has successfully finished the optimisation

Then

The RAO must have written the additional results for the GUI in the RAOResultsOptimisationProfile. Given

The RAO is started with all necessary data.

When

The RAO has successfully finished the optimisation

Then

The RAO must have written the results for the Remedial Actions in the RemedialActionScheduleProfile. Given

The RAO is started with all necessary data.

<!-- page 306 -->

When

The RAO has successfully finished the optimisation

Then

The RAO must have written the results for the Contingency Analysis in the SecurityAnalysisResultProfile.

Given

The RAO is started with all necessary data.

When

The RAO has successfully finished the optimisation

Then

The RAO must have written the results for the sensitivities via the FullMatrixProfile.

Given

The RAO is started and reads the input data.

When

The RAO has read the input data

Then

The RAO must have mapped the available information of the RemedialActionFlatList, the ContingencyFlatList, the AssessedElementFlatList and the SPSFlatList to the internal RAO data model.

##### Basic Flow

The following log-messages are exposed:

• Each CoMo-file read by RAO

##### Alternative Flow

If the RAO cannot read a CoMo-file, the RAO is cancelled. The associated CoMo-file is logged.

<!-- page 307 -->

## 4. Appendix A: Glossary

| Abbreviation | Description |
| --- | --- |
| ANORA | Agreed but Not Ordered Remedial Action |
| CDS | Central Data Storage |
| CGM | Common Grid Model |
| Constraints | Constraints are given as relaxed (soft) and non-relaxed (hard) constraints. |
| FOA | Fast Outage Approximation |
| GUROBI | Software for solving mathematical optimization problems. It is used for solving the MILP. |
| HVDC | High-Voltage Direct-Current Transmission |
| MILP | Mixed Integer Linear Problem The MILP is also referred to as the optimization problem. |
| OPF | Optimal Power Flow Algorithm |
| ORA | Ordered Remedial Action |
| PRange | Adjustable Active Power Range |
| PROD | In consideration of RD Potentials for the active power feed-in of generation units, PROD is the scheduled value (production) of the generation unit. |
| PST | Phase Shifting Transformer |
| RA | Remedial Action |
| RAO | Remedial Action Optimization |

<!-- page 308 -->

| RAO Computation | Remedial action optimization computation describes the entire process that determines the remedial actions in the remedial action optimization (RAO) as part of the operational planning processes of the transmission system operators. |
| --- | --- |
| RD | Redispatch |
| SCOPF | Security-Constrained Optimal Power Flow Algorithm Because the OPF module also considers contingency situations (N-1) within the optimization, it is technically a security-constrained optimal power flow algorithm. |
| TCSC | Thyristor Controlled Series Capacitor |
