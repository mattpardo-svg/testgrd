# Curative RD, TATL, generator on/off and objective: Feature Specs (R2, R4, R7, R9, R11, R15, F2, O1)

Status: R2, R4, R7, R9, R11, R15, F2 and O1 agreed and implemented (steps 1-6, 16 Oct 2026). Updated after the independent code review (16 Oct 2026): rules marked [review] were added or changed by the review round. This file is the full, current requirement. Source: investigation reports of 15 Oct 2026 plus reference/spec/specs.md quotes. Location in the repo: reference/spec/curative_rd_tatl_specs.md (deviation table: docs/Spec_Coverage.md).
Code is the source of truth for "today". The spec (reference/spec/specs.md) is the source of truth for "target".

## 0. Scope

In scope: R2, R4, R7, R9, R11, R15, F2, O1.

Out of scope or parked:
- Time coupling (ramping between timestamps, min up/down times, start-up processes).
- Links to XNEs (R3), multiple TATLs per branch, TATL duration bands or steps, R19.
- R6: nothing to do. R8: closed, limits stay always on. R14: nothing to change.
- R12: the TATL constraint follows the spec (see R11 rule 4). The 600 s fallback duration becomes a config value (see R9 rule 4).
- R17 and R18 (curative cost): resolved in O1.
- Generator on/off (feature 2) is now part of this spec set as section F2.

Assumptions:
- One TATL value and one TATL duration per branch.
- "TATL duration out of scope" means R9 compares the reaction time to that single duration.
- Spec references below come from the investigation reports; line numbers must be re-checked in the implementation.

---

## R2. Curative RA without contingency link applies to all contingencies

Spec: BUC 14#106 (reference/spec/specs.md ~4891-4893, 4949).

Today: `_add_curative_rd_block` (milp_builder.py ~838-845) creates variables only for contingencies in `linked_contingency_mrids`. An RA with no link gets no variables.

Required:
1. A curative RD RA with an empty `linked_contingency_mrids` is available for every contingency that has a usable N-X result.
2. An RA with a non-empty link list keeps today's behaviour (only those contingencies).
3. Same rule applied consistently to curative RD only (PST behaviour is not changed by this item).

Acceptance:
- Test: RA with no link, 3 contingencies in the N-X results gives 3 (bid, contingency) variable pairs.
- Test: RA linked to 1 of 3 contingencies still gives 1 pair.

---

## R4. "Unit in operation" test for curative RD (rewritten, depends on F2)

Status: CLOSED (agreed together with F2).

Spec: BUC 14#106 (reference/spec/specs.md ~4913-4915, 4959, 4925 outlook).
- "If the generating unit for the CRA is out of operation, the CRA cannot be applied in the optimisation." (4913)
- A start-up just for curative use is not possible (4913).
- "If a generating unit is started because of a PRA, the CRA can also be applied." (4915)
- A unit with neither Pmin nor min up/down constraints can run at P = 0 and still count as on (4959).

Required:
1. Unit status is defined as in F2 (connected, PROD as defined in F2 rule 2, Pmin <= 0 special case).
2. A curative RD volume on a unit is allowed only if the unit is on after the preventive actions:
   - initially on and not shut down by a preventive action, or
   - initially off and started by a preventive action (F2 start-up binary).
3. A unit that is initially off and not started preventively has both curative volumes fixed to 0.
4. A curative action can neither start up nor shut down a unit (Q4, Q5 accepted).
5. Multi-unit GLSK (decision 16 Oct 2026, replaces "no binaries"): the on/off logic of F2 applies per unit, also for units inside multi-unit bids (F2 rule 9). The curative gate is a pre-filter: volume <= available MW x (sum of the on/off binaries of its units; constant 1 for continuous units that are on), so a bid can act as soon as one unit is on. The per-unit R7 rows (net row plus the one-sided rows of F2 rule 7) then keep every off unit at 0, so a one-directional curative bid with a positive participation factor on an off unit is blocked (volume 0). In practice a multi-unit curative bid is usable only when all its units are on after the preventive actions. This is intended and consistent with F2 rule 9 (an off unit that cannot be started blocks the whole bid).

Acceptance:
- Test: initially off unit, no preventive start-up: curative volumes are 0.
- Test: initially off unit started by a preventive action: curative volumes are allowed.
- Test: initially on unit shut down by a preventive action: curative volumes are 0.
- Test: connected unit with P = 0 and Pmin = 0 counts as on.
- Existing test `test_generator_not_in_operation_fixes_curative_volume_to_zero` is adapted to the new status source.

---

## R7. Pmin/Pmax with curative maxima (CORNET-4614)

Spec: reference/spec/specs.md 5035-5048. Status: CLOSED. The spec formula (net form, as in the spec picture) is implemented as written.

For each generating unit g:
```
Pmin <= Pprod,g + dP+PRA,g - dP-PRA,g + dP+CRA,g - dP-CRA,g <= Pmax
dP+CRA,g = sum over bids b of max over contingencies c of dP^{cur,c+}_{b,g}
dP-CRA,g = sum over bids b of max over contingencies c of dP^{cur,c-}_{b,g}
```
where dP_{b,g} = participation factor of g in bid b times the bid volume.

Today: `combined_pmax_pmin_rule` (milp_builder.py ~940-954) is indexed by (unit, contingency) and uses that contingency's own volumes. It accepts plans the spec forbids when several bids on one unit peak under different contingencies.

Required:
1. One constraint pair (lower and upper bound) per unit, not per contingency.
2. The curative terms are the sums of per-bid maxima over contingencies, up and down separately, then combined as above.
3. The preventive-only constraint (`pmax_pmin_rule`) stays.
4. The formula above is the requirement and is not changed. Implementation note only: the existing `max_curative_rd_volume_*` variables are bounded only from below, so the MILP must make sure they represent the maximum as the formula says. The implementation proposes how and reports it.
5. Participation factors must be >= 0 (the maximum formulation relies on it). [review] A negative participation factor stops the run with a clear error naming the RA and the unit (deviation from the spec word "report": a wrong sign would silently give wrong bounds).
6. Effect on real data: each of the 8 curative units has both an up and a down bid. In the net form the up and down maxima can cancel, so R7 can be looser than today's per-contingency check (example: up 40 under c1 and down 60 under c2 gives 120 + 40 - 60 = 100, accepted; today's check rejects c1 at 160 against Pmax 150). R7 therefore changes real results.
7. Cost of an exact maximum: one binary per (bid, contingency), about 16 bids times up to 8 contingencies on the real data. The implementation states the exact count and the solve-time impact.

Worked example (Pmin 50, Pmax 150, Prod 100, preventive +20, factor 1):
- Bid X up: c1 = 25, c2 = 5. Bid Y up: c1 = 0, c2 = 20.
- Spec: 120 + 25 + 20 = 165 > 150, rejected. Per-contingency code: 145 and 140, accepted.

Acceptance:
- Test: the example above is infeasible under the new constraint.
- Test: a single bid on a unit gives the same result as before (no real unit has a single bid, so this needs a fixture).
- Test: the max variables cannot be inflated (solver result with cost 0 on the max).

---

## R9. Curative RD availability per branch by reaction time (CORNET-613)

Status: CLOSED (agreed).

Spec: reference/spec/specs.md ~5131. If the reaction time of the curative RA is lower than or equal to the TATL duration, it is a viable option for the assessed element. Otherwise it is not considered for that element.

Today: `timeToImplement` is not parsed for RD. Every curative RD variable enters every branch's N-X constraint. The PST side already does this through `compute_pst_cra_availability`.

Required:
1. Parse `RemedialAction.timeToImplement` for RD RAs into the RD data model (`RDUnit`).
2. Compute availability: available if reaction time <= TATL duration of the branch. The rule has no contingency term, so availability is per (RA, branch), valid for every contingency (deviation from the spec wording "per assessed element" only in that the key has no contingency).
3. In the constraint effect term, include a curative RD variable for a branch only where it is available (same mechanism as the PST triples).
4. Branches without a real TATL use a fallback duration from a new config value (for example `tatl_fallback_duration_s`, default 600). The same value is used for the PST cap. Test: a different value changes which RD RAs are available on such a branch.
5. An RD RA without `timeToImplement` is treated as reaction time 0 (always available). Agreed.
6. No volume cap is derived from the TATL duration and ramp rates stay unused (CORNET-613 5150: no ramp within the reaction time).
7. Export an availability file for RD like `pst_cra_availability.csv` (`rd_cra_availability.csv`).
8. The curative RD effect is aggregated per (unit, contingency) today (milp_builder.py ~923-936). Two curative actions on one unit with different reaction times cannot be filtered per branch that way. The effect must be available per (bid, contingency), or per (unit, contingency, availability group). Real data has 2 actions per unit.

9. [review] `timeToImplement` parsing: an ISO-8601 duration including a day part (P1D, P1DT2H). A value that cannot be parsed counts as 0 (always available) and writes a warning. A missing value counts as 0 without warning (rule 5).
10. [review] One shared helper decides, for every branch the MILP evaluates, the TATL duration (the fallback duration where there is no real TATL) and the availability of each curative RD RA. This includes branches of the TATL data, scanned branches and branches skipped because they have several TATLs. The MILP and `rd_cra_availability.csv` both use this helper, so the rule exists once and the file lists every branch the MILP uses.

Data note: the real input has no RD `timeToImplement`, and every TATL duration is 600 s. The change has no effect on that data. A test fixture with reaction times is required.

Acceptance:
- Test: RA with reaction time 15 min, branch TATL duration 10 min is excluded for that branch and included for a branch with 20 min.
- Test: RA with reaction time equal to the duration is available.
- Test: RA with no `timeToImplement` is available everywhere.
- [review] Test: unreadable `timeToImplement` gives 0 and a warning; `P1D` is read as 1440 min.
- [review] Test: a scanned branch with the fallback duration and an RA with a reaction time above it: not available, both in the CSV and in the MILP.
- [review] Test: the pipeline passes the monitored branches (limit_by_branch_nx) to compute_rd_cra_availability (record the call argument, or use a fixture with a scanned branch).
- [review] Note: day support in the duration parser also applies to bid lead times and the PST time per stage (P1D = 24 h, correct ISO reading; a lead time of P1D used to be read as 0 h). Record in docs/Spec_Coverage.md and add one lead-time test with P1D; check the SIS files for `leadTime` values with a day part.

---

## R11. TATL and PATL constraints (CORNET-1790), simplified

Status: CLOSED (agreed, based on the spec acceptance criterion).

Spec: reference/spec/specs.md ~7000-7061, acceptance criterion ~7135, CORNET-1792 ~7143 and 7160.

Spec text (CORNET-1790, from the spec pages):
- Intro: additional soft constraints (I_TATL > I_PATL) consider the TATL current in the period between the start of the outage and the end of the curative action period (t_trip to t_trip + t_TATL).
- Acceptance criterion: "the loading of the XNE is equal or below the TATL after the PRA and equal or below PATL after PRA and CRA if the PRA and CRA activation is cheaper than leaving a remaining overload."

Interpretation: with one TATL duration per branch and no steps, the acceptance criterion gives a two-state check. TATL after preventive actions only, PATL after preventive and curative actions. The multi-step formula (several durations, index d) is out of scope.

Required (per secured branch and contingency, no steps, no index d):
1. TATL constraint: N-X current + preventive PST and RD effect <= TATL + slack. No curative terms.
2. PATL constraint: N-X current + preventive effect + curative effect <= PATL + slack.
3. Curative filter: only curative RAs available per R9 (reaction time <= TATL duration of that branch) appear in the PATL constraint. The PST cap per (PST, branch, contingency) stays.
4. The TATL constraint is created only for a branch with a real TATL strictly above the PATL. If the TATL is missing, or is at most the PATL (corrected or synthetic), no TATL constraint is created for that branch (spec 7008: TATL > PATL; spec 7160: no TATL, no constraint). The fallback duration (config value, R9 rule 4) stays for the R9 availability and the PST cap. Accepted (B1, option b). [review] The test "TATL strictly above PATL" uses a tolerance (TATL > PATL + 1e-6 A) everywhere it is applied (MILP builder, post-RA congestion check, convergence check), because PATL is computed as kA x 1000 and TATL comes from the CGM in ampere (example: PATL 1.005 kA = 1004.9999999999999 A, TATL 1005.0 A must give no TATL constraint).
5. Slack variables, penalties and reporting stay unchanged for now.

Today: both constraints call `_nx_pst_and_rd_effect` and include all curative terms (milp_builder.py ~1216-1278). The TATL constraint must drop the curative terms.

Effect on current data: all 29 secured branches have TATL <= PATL after the correction, so no TATL constraint and no TATL slack is created on the mock data. Curative actions still relieve the PATL constraint. With real TATLs above the PATL, the TATL constraint is created and holds the preventive state only.

Acceptance:
- Test: branch with TATL > PATL and a curative action that relieves the overload: the TATL constraint ignores the curative action, the PATL constraint uses it.
- Test: with a missing TATL, or a TATL at most the PATL, no TATL constraint and no TATL slack exist for that branch; the PATL constraint is unchanged.
- Update the test `test_tatl_and_patl_constraints_coexist_independently` to the new semantics.
- [review] Test: PATL 1.005 kA with TATL 1005.0 A gives no TATL row.

---

## R15. Curative balancing per contingency (CORNET-574)

Spec: CORNET-574, "Balancing of redispatch RA in curative mode". Status: CLOSED.

Spec text (from the spec pages):
- "In order to balance the active power injections of curative RA, a balancing constraint is considered for each contingency in the RAO." Formula: sum of dP_CRA,C = 0.
- Part of the constraint are all curative RAs with a link to the contingency C. The RAO determines the necessary curative RD RAs and their counterparts itself.
- At least two curative RAs must be linked to a contingency and considered in the MILP. They must provide sufficient positive and negative available RD volume.
- Acceptance: the sum of redispatch from the curative RAs activated in the contingency situation must be zero.
- Outlook only (not required now): a balancing constraint per contingency and assessed element, and slack node types with multi-unit GLSK.

Today: only the N-0 balance exists (`rd_balancing_n0`, milp_builder.py ~1582-1586). Curative RD can act as a pure injection.

Required:
1. For each contingency, the sum over all curative RD injections (participation factor times (up - down), over all bids active in that contingency) equals 0.
2. The constraint is a hard equality (same as the N-0 balance). The spec text states no slack.
3. Only bids that are available for that contingency (R2 and R4 gating) contribute. If R15 is built before R4 and F2, its tests cover today's gating, and R4 extends it later.
4. The constraint is independent of the R9 branch filter, which only decides what enters the branch constraints.

Acceptance:
- Test: one curative up bid and no down bid gives 0 volume.
- Test: an up bid and a down bid on different units are forced to equal volumes in each contingency.
- Real data check: 16 curative RD RAs on 8 units have up/down pairs, so balancing is feasible.

---

## F2. Generator on/off for redispatch RAs (feature 2)

Status: CLOSED (all decisions accepted on 15 Oct 2026). Remaining items at the end are information only.

Scope: one timestamp. Out of scope (time coupling or later release): start-up and shut-down ramps, min up/down times, cold/warm lead and lag times (CORNET-47 to 50, 69, 70, 91, 4593, 4595, 4596), activation cost contiguity over timestamps (6081), curative start-up (outlook 4925, 4863 for release scope is overridden for shut-down costs, see below).

Spec: CORNET-37 (reference/spec/specs.md ~4171-4235), BUC 14#103 (~4748-4765), SF3077 (2537-2547), CORNET-41 (4098), 2839, 3012-3026.

Rules:
1. Unit status (accepted): a unit is on if it is connected (SSH `ACDCTerminal.connected`, exposed as `connected`) and PROD != 0 ([review] with a small tolerance: |PROD| > 1e-6 MW, so a CGM value of 1e-9 counts as 0). No CGMES flag says "running". `inService` and `connected` are true on all 13 units, so PROD != 0 is the deciding test. A connected unit with PROD = 0 and Pmin <= 0 is also on (4959 extended to Pmin < 0, since 0 lies inside the on-range). An unconnected unit is excluded from the redispatch model (2839).
2. PROD source (accepted, deviation from the spec): the spec says `GeneratingUnit.initialP` (EQ, line 4098). The implementation found that `initialP` does not exist in the CGMES 3.0 profile and not in the data. The only production value is SSH `RotatingMachine.p`, which pypowsybl exposes as `target_p` (= -p, checked on all 13 units). So PROD = `target_p`. Record this as a deviation caused by the CGMES version. If CGMES 2.4.15 data is used, `initialP` would exist (not verified).
3. Semi-continuous operation (accepted): one binary on/off variable per single-unit bid unit.
   - On: Pmin <= P <= Pmax.
   - Off: P = 0.
   - Applies only where Pmin > 0 (spec 4748 charges start-up cost only for Pmin > 0; 4233 also names Pmin < 0, which is not applied). Units with Pmin <= 0 stay continuous, with no binary and no start-up or shut-down. Example: unit `3a3b27be` (Pmin = -100, Pmax = 200) stays continuous. [review] A unit with Pmin > Pmax gets a warning naming the unit at build time (such a unit can never be on).
4. Start-up (initially off): allowed only for preventive upward bids, only if Pmin lies within the available RD volume (Pmin <= PROD + max RD+, 4221), and only if a start-up cost is given (4765). The start-up cost is charged times the start-up binary (2537-2544, 4748). Source (accepted): `UnitCostTimePoint.warmStartupCost` (spec 4761 means the warm start-up cost), fallback `UnitCostTimePoint.startupCost`, fallback `GeneratingUnit.normalWarmStartupCost`. Currency from `UnitCostSchedule.currency`.
5. Shut-down (initially on): allowed only for preventive downward bids, only if PROD - (sum of the unit's available preventive down volumes) reaches 0 (4208; "sum" as in rule 12), and only if a shut-down cost is given. The spec defers shut-down costs to a later release (4863); this feature deviates on purpose (accepted). Source (accepted): unit level only: `UnitCostTimePoint.shutdownCost`, then `GeneratingUnit.normalShutdownCost`. The bid-level `PowerBidSchedule.shutdownCost` is not used (decision C5: a unit can sit in several bids with different values, and the spec is silent).
6. Curative actions (accepted): cannot start up or shut down a unit. They may act on a unit that is on after the preventive actions (R4).
7. Pmin/Pmax constraints (accepted, Q11): the Pmin bound applies only when the unit is on after the preventive actions. If the unit is off after the preventive actions, the curative terms are 0 and the Pmin bound is not enforced. R7 (curative maxima) keeps its formula for units that are on. [review] For a unit with an on/off binary u, the net R7 row alone is not enough: when u = 0 it only forces (sum of up) - (sum of down) = 0, so up and down injections from different bids and contingencies can cancel and an off unit would still be moved (example: up bid X {A 0.5, B 0.5} and down bid Y {B 0.5, C 0.5}, B off: B gets +20 MW under c1 and -20 MW under c2). Therefore, in addition to the net row, two one-sided rows per unit with a binary: sum over bids of pf x M_up <= Pmax x u and sum over bids of pf x M_down <= Pmax x u (M = curative maximum over contingencies). With u = 0 both maxima are 0, so an off unit receives no curative injection at all. With u = 1 the rows are looser than the net row and change nothing.
8. Costs: the start-up and shut-down terms enter the objective. Curative actions carry no start-up cost (2547). Penalty weights of other terms are unchanged.
9. Multi-unit GLSK (decision 16 Oct 2026; the NC functional spec is silent, the approach follows Open RAO's generator constraints: one on/off binary per generator, injection of the generator = participation factor x bid set-point). The spec keeps offline units in a redispatch GLSK (3026) and drops only units not connected to the largest subgrid (3012-3014). Binaries are per unit, not per bid: every unit with Pmin > 0 in any bid (single- or multi-unit) is classified as in rule 3 and gets the on/off logic of rules 3-7, written on the unit's total injection PROD0 + sum over all bids of (participation factor x volume). Example: GLSK {A 0.5, B 0.5}, B off with Pmin 20: B is on only if 0.5 x volume >= 20 and pays its start-up cost, otherwise the bid volume is 0 (the whole bid is blocked if B cannot be started). Record as a deviation (source: Open RAO) in Spec_Coverage.md. This replaces the earlier limit "multi-unit bids have no binaries".
   [review] Static check at build time, before the solver: if Pmin of an off unit is not reachable (Pmin > sum over its bids of participation factor x available upward volume), or no start-up cost is given, the unit is fixed off: the volume upper bounds of every bid containing that unit (participation factor > 0) are set to 0 and one log line per blocked bid names the unit and the reason ("Pmin unreachable within the bid volume" or "no start-up cost"). Example: GLSK {A 0.5, B 0.5}, B off, Pmin 20, bid volume 30 MW: B can get at most 15 MW, so the bid is blocked and the model stays feasible. For units that can be started or stopped, the dynamic part stays in the MILP: Pmin x u <= injection <= Pmax x u with the binary u. The static check only shortcuts what the binary would decide anyway and adds the log line.
10. Today's code (verified by test before the fix): an offline unit with Pmin > 0 is forced up to at least Pmin by a 100 MW up bid, and the model is infeasible with a 30 MW up bid. Now fixed (unit stays at 0, or is started with its cost).
11. Pmin adjustment (accepted, CORNET-37 4231-4235): a unit with Pmin > 0 and 0 < PROD < Pmin gets Pmin := PROD, with one log line, computed once per run on the original PROD. Units with Pmin <= 0 are not affected (they stay continuous, rule 3; example `3a3b27be`, PROD 52.8, Pmin -100, keeps Pmin -100). The start-up/shut-down phase check (CORNET-47/48) is time coupling, so it is never true here. An off unit (PROD = 0, Pmin > 0) is not affected; it follows rules 4 and 5.
12. Start-up via several preventive up bids on one unit (accepted): Pmin <= PROD + sum of the unit's available preventive upward volumes.
13. Unit with no preventive bid and Pmin > 0 while off: no binary, counts as off, curative volumes 0 (consistent with rule 6). Unconnected units are removed from the GLSK and the remaining factors renormalised, with a warning (implementation choice, spec 3012-3014 only says they are dropped). [review] A preventive bid whose GLSK is empty (for example all units unconnected) has both volume upper bounds fixed to 0 (a curative bid in that case is already fixed to 0).
14. [review] Original-network reporting: when the AC loop ends without convergence and the original network is reported, every unit that is initially on counts as on (on/off binary = 1), so no shut-down cost and no start-up cost is reported for it.
15. [review] Log lines required by this spec (reserve-price fallback, Pmin := PROD, blocked bids, default penalty factor) are written once per pipeline run, not once per Python process (a second run in the same process, e.g. in tests or notebooks, writes them again; the GUI starts each run as a separate process).
16. Parser: no code loads `UnitCostSchedule` or `UnitCostTimePoint` (SIS) or the EquipmentReliability profile today, and `input/` has no ER file. The parser needs the SIS unit cost classes and a new optional ER input for `GeneratingUnit.normal*`.

Acceptance:
- Test: offline unit, Pmin > 0, upward bid covering Pmin, start-up cost given: the MILP can start the unit and the objective contains the start-up cost.
- Test: same unit without a start-up cost: no start-up, unit stays at 0, no infeasibility.
- Test: online unit, downward bid reaching 0, shut-down cost given: the MILP can shut the unit down and pays the cost. The result is 0 or at least Pmin, never in between.
- Test: online unit, downward bid that does not reach 0: no shut-down.
- Test: on unit with Pmin > 0 and 0 < PROD < Pmin: Pmin := PROD, no forced upward move, log line.
- Regression test: unit `3a3b27be` keeps Pmin = -100.
- Test: connected unit with PROD = 0 and Pmin < 0 counts as on (curative allowed).
- Test: curative bid on a unit shut down preventively: volumes 0.
- Test: unconnected unit is excluded.
- Test: units with Pmin = 0 and with Pmin < 0 stay continuous (no binary).
- Test (multi-unit): GLSK {A 0.5, B 0.5}, B off, Pmin 20, start-up cost given: the bid volume is 0 or at least 40 MW; with volume >= 40 B is started and pays its start-up cost once; without a start-up cost the bid volume is 0 and the model is feasible (solve it, do not only build it).
- Test (multi-unit): unit in two bids (one single-unit, one multi-unit): the on/off binary uses the sum of both injections, and the start-up cost is charged once.
- Test (multi-unit curative): allowed if at least one unit is on after the preventive actions; 0 if none is.
- Test (multi-unit, blocked bid) [review]: GLSK {A 0.5, B 0.5}, B off, Pmin 20, bid volume 30 MW: the bid volume is 0, the model is feasible and one log line names unit B and the reason.
- [review] Test: PROD = 1e-9 MW counts as 0 (unit off if Pmin > 0; no Pmin := PROD adjustment).
- [review] Test: unit with Pmin > Pmax gives a warning naming the unit.
- [review] Test: preventive bid with an empty GLSK has volume 0.
- [review] Test: non-convergent path with a unit that has a shut-down cost: sum_shutdown_cost_eur is 0 in the reported original network.
- [review] Test: log lines are written again in a second run in the same process.
- [review] Test (cancellation): up bid X {A 0.5, B 0.5} and down bid Y {B 0.5, C 0.5}, A and C on, B off (startable, not started): the curative volumes of X and Y are 0 (B receives no curative injection); the one-sided rows exist and bind. The model must be solved.
- [review] Test: the curative gate row exists and binds for a multi-unit bid whose units are all off.
- Data: the real input has 13 running, connected units and no start-up or shut-down costs. A fixture with an offline unit and with costs is required.

Open items:
1. PROD source and cost attribute priorities (rules 2, 4, 5): accepted.
2. Missing cost value: treated as "not allowed" (as in 4765). Accepted.
3. Bid activation cost: the spec names `PowerBidSchedule.startupCost` (6107), which does not exist in NC 2.4 or 2.5. The NC attribute is `PowerBidSchedule.activationCost` (what the code reads, all 0 in the mock data). Parked with the objective function.
4. Spec errors found in the implementation (for the spec authors, not for the code): 6107 (`startupCost`), 4761 (`GenExtensionErList.warmStartupCost` is not an NC class), 5301-5317 (`reservePrice` exists only per time point).
5. Missing Pmin: spec silent. Today's default is 0.0 with a warning.
6. The mock data has none of these cost attributes. The fixture must add them.

---

## O1. Objective function changes (SF3077 3.36-3.52, BUC 14#43, 14#102, 14#103)

Status: CLOSED (all decisions agreed on 16 Oct 2026).

Scope: one timestamp. Time coupling is out of scope (sum over timestamps, avoided start-up credit, activation cost over contiguous timestamps).

New terms (preventive only):
1. Start-up: sum over units g of c_startup,g * B_ON,g. B_ON exists only for units that are initially off, have Pmin > 0 and a start-up cost (F2). Source: `UnitCostTimePoint.warmStartupCost`, then `startupCost`, then `GeneratingUnit.normalWarmStartupCost` (F2 rule 4). Spec: 3.39, 4748.
2. Shut-down (deviation: the spec defers it to a later release, 4863): sum over units g of c_shutdown,g * B_OFF,g. B_OFF exists only for units that are initially on, have Pmin > 0 and a shut-down cost. Source: unit level only, `UnitCostTimePoint.shutdownCost`, then `GeneratingUnit.normalShutdownCost` (F2 rule 5). The bid-level shut-down cost is not used.
3. Bid activation (spec 3.38, 6081-6115): sum over preventive bids b of c_act,b * B_act,b. Source: `PowerBidSchedule.activationCost`; the value on `PowerBidScheduleTimePoint` overrides it if present; default 0. The binary is created only for bids whose cost is above 0. Not charged for curative bids (6097). If a bid activation starts a unit, both the activation cost and the start-up cost are charged (6115).

Changed terms:
4. Curative redispatch (3.40-3.44, BUC 14#43): cost per bid = (penaltyFactor * penalty reference + second component) * (max up + max down), the max taken over contingencies per bid (3.42, 3.43).
   - Penalty reference: the same reference as preventive (deviation from 3.41, which has a separate curative reference). The factor comes from `RemedialAction.penaltyFactor` in the NCP. Same for curative PSTs (unchanged).
   - Second component: `reservePrice` (per time point, NC) if present. If missing, the energy price is used and the fallback is logged. This deviates from spec 5317 and 5338. [review] A negative `reservePrice` is handled like a negative energy price: warning, value set to 0 (otherwise the solver would reserve curative volume just to earn a negative cost).
   - B_G,curative in 3.44 (undefined in the spec) is read as "every bid with a curative variable". Unused bids have max = 0 and cost 0.
5. Missing penalty factor: 1.0, logged as a default. This deviates from spec 5338 (0 for curative) and follows the NC default.
6. Currency: all costs are assumed to be EUR. A bid or unit currency other than EUR gives a warning (no conversion).

Unchanged (decided):
- Downward redispatch price: cost >= 0 per MW as in 3.36 (Q1).
- Scanned-element penalties: the two existing parameters (N-0 in EUR/kA, N-X in EUR/A) stay (Q11). Deviation from spec 8252, which has one EUR/A parameter.
- Penalty scale: the overload penalties (1e4 to 1e5 EUR/A) are far above redispatch and start-up costs. On the real data this is not a problem. No code change. Note: the penalty values in the config are placeholders and must be tuned for real data.
- Per-TSO penalty reference overrides (CORNET-4339) stay hard-coded to None (not part of this round).

Reporting: the results summary adds the sums of start-up cost, shut-down cost and bid activation cost (spec 2629: the sums of the different cost terms are an output).

Acceptance:
- Test: a start-up of an offline unit adds exactly c_startup to the objective; no cost given: no start-up possible.
- Test: a shut-down of an online unit adds exactly c_shutdown; no cost given: no shut-down possible.
- Test: a bid with activation cost > 0 pays it once when used (up or down) and nothing when unused; a bid with cost 0 has no binary.
- Test: a curative bid with `reservePrice` uses it; without it, the energy price is used and a log line is written.
- Test: a missing penalty factor gives 1.0 and a log line.
- Test: a non-EUR currency gives a warning.
- [review] Test: a negative `reservePrice` gives a warning and is used as 0.
- Test: the summary reports the new cost sums, and the objective equals the sum of all reported terms.
- Existing cost tests keep passing on the mock data (true for O1 alone; R7 and R11 change results on the mock data).

Q3 (same reference as preventive, factor from the NCP) and Q4 (`reservePrice` with energy-price fallback, logged): accepted.

---

## Cross-cutting

- Order of implementation: R2, R15, R9, R11, F2 with R4 and O1 (start-up/shut-down/activation terms), R7 last (R7 depends on the on/off status and on the exact-max formulation).
- New tests must run on a fixture with RD reaction times, because the real input has none.
- Every item gets a spec-coverage entry (docs/Spec_Coverage.md) with the CORNET reference.
- Test stability: the model fingerprint test hashes the structure (row names, variables, bounds) of the fixture-run models, and the coefficients only for the synthetic model, because pypowsybl returns last-bit differences in the N-X sensitivities. Tests that compare pypowsybl sensitivities use a relative tolerance 1e-9 and an absolute tolerance 1e-12.

### Deviations from the NC functional spec
The full list is kept in `docs/Spec_Coverage.md` (section 4).

## Open points

Decided and closed: R2, R4, R7 (formula), R9, R11, R15, F2, O1, and the review findings (negative reservePrice, unparseable timeToImplement, float tolerances, log caches per run, original-network reporting, empty GLSK, shared availability helper, multi-unit binaries).

Implementation notes (all done in the implementation):
1. R7: exact formulation of the per-bid maximum (done: argmax binaries, 52 on the real input).
2. R7: participation factors >= 0 (done: error, see R7 rule 5).
3. F2: done (the defect was reproduced by a test before the fix).
4. Test fixtures are required, because the mock data has none of these: RD reaction times, TATL above PATL, an offline unit, start-up/shut-down costs, `reservePrice`, activation cost > 0.

Parked (later):
0. Known limitation (existing, not part of this spec set): if there is no preventive RA at all and the N-0 scanned constraint is hard, that constraint has no variables and Pyomo stops with an error. To be handled with the N-0 scanned constraint (skip a constraint with a constant body).
5. R12: the TATL constraint follows the spec (no TATL, no constraint, see R11 rule 4). The 600 s fallback duration is a config value (R9 rule 4).
6. Parked: per-TSO penalty reference overrides (CORNET-4339). Needs the TSO of each RA, the `RAOControlParameterSetForTSO` input, and a separate curative reference (`penaltyReferenceRD_CRA`); to be investigated with the real data.

Not in this spec (other features): XNE links (R3), multiple TATLs and TATL duration bands, single-pass AC and DC workflows, HVDC set point, countertrading with RemainingCapacity GLSK.

For the spec authors (not code): spec lines 6107 (`startupCost` is not an NC attribute), 4761 (`GenExtensionErList.warmStartupCost` is not an NC class), 5301-5317 (`reservePrice` exists only per time point), and `initialP` (4098) is absent in CGMES 3.0.
