"""paths.py - where the data files are and what they are called: the one place to rename a zip.
Imports nothing but pathlib."""
from pathlib import Path

REPO_ROOT = Path(__file__).resolve().parents[1]
FIXTURES = REPO_ROOT / "tests" / "fixtures"
INPUT_DIR = REPO_ROOT / "input"

CGM_ZIP = FIXTURES / "CGM_package.zip"                       # official ReliCapGrid CGM sample
STANDARD_ZIP = FIXTURES / "NCP_mock_standard.zip"            # standard-form mock NCP (made by `python -m mock_data standard`)
LEGACY_ZIP = FIXTURES / "NCP_mock_legacy.zip"                # the old-form mock NCP, source of the converter
SAMPLE_GENERIC_ZIP = FIXTURES / "NCP_sample_generic_2_4.zip" # official ReliCapGrid NCP sample (profile 2.4)
FINGERPRINTS_JSON = FIXTURES / "milp_model_fingerprints.json"