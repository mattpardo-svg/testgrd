"""zipio.py - zip helpers shared by the generators."""
import zipfile


def fixed_entry(name):
    """A zip entry with a fixed time stamp and attributes, so two builds of the same mock are byte-identical
    (writestr with a plain name stamps the current time)."""
    entry = zipfile.ZipInfo(name, date_time=(1980, 1, 1, 0, 0, 0))
    entry.external_attr = 0o644 << 16
    return entry


def write_zip(files, dest):
    """Write {name: bytes} to dest (a path or a binary file object): names sorted, deflated, fixed time stamps, the
    same layout as the converter, so equal content gives equal bytes."""
    with zipfile.ZipFile(dest, "w", zipfile.ZIP_DEFLATED) as out:
        for name in sorted(files):
            info = fixed_entry(name)
            info.compress_type = zipfile.ZIP_DEFLATED
            out.writestr(info, files[name])
