"""multiday.py - NCP data that covers several days, to test that the run time of the CGM selects the right data.

- `write_series_files(folder)`: small hand-made AE, SHS, SIS and RA files of one TSO ("X") in which every
  time-dependent value (PATL, bid volume, participation factor, unit start-up cost, group limit) depends on the day:
  the value of day i (0 = 2022-06-15, 1 = 2022-06-16, 2 = 2022-06-17) is `value(i, ...)`; the points are at 23:30 and
  at 00:30 of every day, so a run at 23:30 on the 16th reads the 16th at 23:30 and the 17th at 00:30.
- `shift_time_points(source_zip, out_zip, hours)`: a copy of an NCP zip with every atTime moved by `hours`, so that the
  time points lie on the date and hour of the CGM (the mock CGM is 2022-06-16T23:30Z, the mock NCP 2022-06-15T10:30Z:
  37 hours).
"""

from __future__ import annotations

import datetime
import re
import zipfile
from pathlib import Path

from .zipio import fixed_entry

DAYS = ("2022-06-15", "2022-06-16", "2022-06-17")
HEADER = ('<?xml version="1.0" encoding="UTF-8"?>\n<rdf:RDF xmlns:rdf="http://www.w3.org/1999/02/22-rdf-syntax-ns#" '
          'xmlns:nc="https://cim4.eu/ns/nc#" xmlns:cim="https://cim.ucaiug.io/ns#">\n')
FOOTER = "</rdf:RDF>\n"


def points(clock: str = "T23:30:00Z", late_clock: str = "T00:30:00Z"):
    """[(day index, ISO time, is the 00:30 point)] for every day."""
    return [(i, f"{day}{clock}", False) for i, day in enumerate(DAYS)] + \
           [(i, f"{day}{late_clock}", True) for i, day in enumerate(DAYS)]


def patl_ampere(day_index: int, late: bool) -> float:
    return 1000.0 * (day_index + 1) + (500.0 if late else 0.0)


def bid_mw(day_index: int, late: bool) -> float:
    return 10.0 * (day_index + 1) + (5.0 if late else 0.0)


def key_factor(day_index: int) -> float:
    """Raw factor of key K1; key K2 is 1.0 on every day, so the share of K1 is f / (f + 1)."""
    return float(day_index + 1)


def startup_cost(day_index: int) -> float:
    return 1000.0 * (day_index + 1)


def group_limit(day_index: int) -> float:
    return 100.0 * (day_index + 1)


def write_series_files(folder: Path) -> dict[str, Path]:
    files = {}

    def write(name: str, body: str) -> None:
        path = Path(folder) / f"X_{name}.xml"
        path.write_text(HEADER + body + FOOTER, encoding="utf-8")
        files[name] = path

    write("AE", """
<nc:AssessedElement rdf:ID="_AE1"><cim:IdentifiedObject.mRID>AE1</cim:IdentifiedObject.mRID>
  <nc:AssessedElement.ConductingEquipment rdf:resource="#_BR1"/>
  <nc:AssessedElement.OperationalLimit rdf:resource="#_OL1"/>
  <nc:AssessedElement.SecuredForRegion rdf:resource="#_REGION"/></nc:AssessedElement>""")
    write("SHS", '<nc:CurrentLimitSchedule rdf:ID="_CLS1"><nc:CurrentLimitSchedule.CurrentLimit rdf:resource="#_OL1"/></nc:CurrentLimitSchedule>' +
          "".join(f'<nc:CurrentLimitTimePoint rdf:ID="_CP{n}"><nc:CurrentLimitTimePoint.atTime>{when}</nc:CurrentLimitTimePoint.atTime>'
                  f'<nc:CurrentLimitTimePoint.value>{patl_ampere(i, late)}</nc:CurrentLimitTimePoint.value>'
                  '<nc:CurrentLimitTimePoint.CurrentLimitSchedule rdf:resource="#_CLS1"/></nc:CurrentLimitTimePoint>'
                  for n, (i, when, late) in enumerate(points())))
    sis = ['<nc:PowerBidSchedule rdf:ID="_S1"><cim:IdentifiedObject.mRID>S1</cim:IdentifiedObject.mRID>'
           '<nc:PowerBidSchedule.PowerRemedialAction rdf:resource="#_RA1"/>'
           '<nc:PowerBidSchedule.direction rdf:resource="https://cim4.eu/ns/nc#MarketRegulationDirectionKind.up"/>'
           '<nc:BaseTimeSeries.interpolationKind rdf:resource="https://cim4.eu/ns/nc#TimeSeriesInterpolationKind.none"/></nc:PowerBidSchedule>']
    for n, (i, when, late) in enumerate(points()):
        sis.append(f'<nc:PowerBidScheduleTimePoint rdf:ID="_BP{n}"><nc:PowerBidScheduleTimePoint.atTime>{when}</nc:PowerBidScheduleTimePoint.atTime>'
                   '<nc:PowerBidScheduleTimePoint.PowerBidSchedule rdf:resource="#_S1"/>'
                   f'<nc:PowerBidScheduleTimePoint.p>{bid_mw(i, late)}</nc:PowerBidScheduleTimePoint.p>'
                   '<nc:PowerBidScheduleTimePoint.price>7</nc:PowerBidScheduleTimePoint.price></nc:PowerBidScheduleTimePoint>')
    sis.append('<nc:PowerBidSchedule rdf:ID="_PB-RA1"><cim:IdentifiedObject.mRID>PB-RA1</cim:IdentifiedObject.mRID>'
               '<nc:PowerBidSchedule.PowerRemedialAction rdf:resource="#_RA1"/></nc:PowerBidSchedule>')
    for key, unit in (("K1", "GU-A"), ("K2", "GU-B")):
        sis.append(f'<nc:PowerShiftKeyDistribution rdf:ID="_D{key}"><nc:PowerShiftKeyDistribution.PowerBidSchedule rdf:resource="#_PB-RA1"/>'
                   f'<nc:PowerShiftKeyDistribution.PowerShiftKeySchedule rdf:resource="#_{key}"/></nc:PowerShiftKeyDistribution>'
                   f'<nc:PowerShiftKeySchedule rdf:ID="_{key}"><cim:IdentifiedObject.mRID>{key}</cim:IdentifiedObject.mRID>'
                   f'<nc:PowerShiftKeySchedule.GeneratingUnit rdf:resource="#_{unit}"/></nc:PowerShiftKeySchedule>')
        for n, (i, when, late) in enumerate(points()):
            factor = key_factor(i) if key == "K1" else 1.0
            sis.append(f'<nc:ParticipationFactorTimePoint rdf:ID="_PF{key}{n}"><nc:ParticipationFactorTimePoint.atTime>{when}</nc:ParticipationFactorTimePoint.atTime>'
                       f'<nc:ParticipationFactorTimePoint.participationFactor>{factor}</nc:ParticipationFactorTimePoint.participationFactor>'
                       f'<nc:ParticipationFactorTimePoint.PowerShiftKeySchedule rdf:resource="#_{key}"/></nc:ParticipationFactorTimePoint>')
    sis.append('<nc:UnitCostSchedule rdf:ID="_US1"><nc:UnitCostSchedule.GeneratingUnit rdf:resource="#_GU-A"/></nc:UnitCostSchedule>')
    for n, (i, when, late) in enumerate(points()):
        sis.append(f'<nc:UnitCostTimePoint rdf:ID="_UC{n}"><nc:UnitCostTimePoint.atTime>{when}</nc:UnitCostTimePoint.atTime>'
                   '<nc:UnitCostTimePoint.UnitCostSchedule rdf:resource="#_US1"/>'
                   f'<nc:UnitCostTimePoint.startupCost>{startup_cost(i)}</nc:UnitCostTimePoint.startupCost></nc:UnitCostTimePoint>')
    sis.append('<nc:RemedialActionGroupSchedule rdf:ID="_GS1"><nc:RemedialActionGroupSchedule.RemedialActionGroup rdf:resource="#_G1"/></nc:RemedialActionGroupSchedule>')
    for n, (i, when, late) in enumerate(points()):
        sis.append(f'<nc:RemedialActionGroupTimePoint rdf:ID="_GP{n}"><nc:RemedialActionGroupTimePoint.atTime>{when}</nc:RemedialActionGroupTimePoint.atTime>'
                   '<nc:RemedialActionGroupTimePoint.RemedialActionGroupSchedule rdf:resource="#_GS1"/>'
                   f'<nc:RemedialActionGroupTimePoint.maxRegulatingUp>{group_limit(i)}</nc:RemedialActionGroupTimePoint.maxRegulatingUp>'
                   f'<nc:RemedialActionGroupTimePoint.maxRegulatingDown>{group_limit(i)}</nc:RemedialActionGroupTimePoint.maxRegulatingDown></nc:RemedialActionGroupTimePoint>')
    write("SIS", "".join(sis))
    write("RA", '<nc:RemedialActionGroup rdf:ID="_G1"><cim:IdentifiedObject.mRID>G1</cim:IdentifiedObject.mRID></nc:RemedialActionGroup>'
                '<nc:RemedialActionDependency rdf:ID="_DEP1"><nc:RemedialActionDependency.kind rdf:resource="https://cim4.eu/ns/nc#RemedialActionDependencyKind.restrictive"/>'
                '<nc:RemedialActionDependency.DependingRemedialActionGroup rdf:resource="#_G1"/>'
                '<nc:RemedialActionDependency.RemedialAction rdf:resource="#_RA1"/></nc:RemedialActionDependency>')
    return files


def shift_time_points(source_zip: Path, out_zip: Path, hours: float) -> int:
    """Copy source_zip to out_zip with every atTime literal moved by `hours`; returns the number of literals moved."""
    delta = datetime.timedelta(hours=hours)
    moved = 0

    def shift(match):
        shifted = datetime.datetime.strptime(match.group(1), "%Y-%m-%dT%H:%M:%SZ") + delta
        return "atTime>" + shifted.strftime("%Y-%m-%dT%H:%M:%SZ") + "<"

    with zipfile.ZipFile(source_zip) as source, zipfile.ZipFile(out_zip, "w", zipfile.ZIP_DEFLATED) as out:
        for info in source.infolist():
            data = source.read(info.filename)
            if info.filename.endswith(".xml"):
                text, count = re.subn(r"atTime>(\d{4}-\d\d-\d\dT\d\d:\d\d:\d\dZ)<", shift, data.decode("utf-8"))
                moved += count
                data = text.encode("utf-8")
            out.writestr(fixed_entry(info.filename), data)
    return moved
