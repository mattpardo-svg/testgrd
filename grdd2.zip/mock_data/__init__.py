"""mock_data - generators of the mock and test data of the RAO prototype (see README.md). Not imported by src/."""
