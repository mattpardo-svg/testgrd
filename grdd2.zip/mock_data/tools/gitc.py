"""Commit helper (dulwich, kept outside the repo). Usage: gitc.py SCRATCH baseline|package|status "message" """
import sys, pathlib, hashlib, time
sys.path.insert(0, sys.argv[1] + r"\pylib")
from dulwich.repo import Repo
from dulwich.ignore import IgnoreFilterManager
from dulwich.objects import Blob
from dulwich.index import index_entry_from_stat
mode_cmd, message = sys.argv[2], (sys.argv[3] if len(sys.argv) > 3 else "")
BRANCH = b"refs/heads/ncp-standard-alignment"
AUTHOR = b"Mahir Sarfati <77175776+MahirSarfati@users.noreply.github.com>"
repo = Repo(".")
ig = IgnoreFilterManager.from_repo(repo)
SKIP_PREFIX = () if __import__("os").environ.get("GITC_INPUT") == "1" else ("input/",)           # input data is never added; tracked input files keep their index state

def wanted_files():
    keep, skipped = [], []
    for p in pathlib.Path(".").rglob("*"):
        if not p.is_file(): continue
        rel = p.as_posix()
        if rel.startswith((".git/", ".venv/")) or ".git" == rel.split("/")[0]: continue
        if ig.is_ignored(rel): continue
        if rel.startswith(SKIP_PREFIX): skipped.append((rel, "input data")); continue
        if p.stat().st_size > 50 * 1024 * 1024: skipped.append((rel, "over 50 MB")); continue
        keep.append(rel)
    return sorted(keep), skipped

def head_tree_paths():
    out = {}
    try: head = repo[repo.head()]
    except KeyError: return out
    def walk(t, prefix=""):
        for e in repo[t].items():
            p = prefix + e.path.decode()
            if e.mode & 0o170000 == 0o040000: walk(e.sha, p + "/")
            else: out[p] = (e.mode, e.sha)
    walk(head.tree)
    return out

def stage():
    keep, skipped = wanted_files()
    index = repo.open_index()
    tracked = {k.decode() for k in index}
    added = modified = removed = 0
    for rel in keep:
        data = pathlib.Path(rel).read_bytes()
        blob = Blob.from_string(data)
        key = rel.encode()
        if key in index and index[key].sha == blob.id and True:
            continue
        repo.object_store.add_object(blob)
        st = pathlib.Path(rel).stat()
        entry = index_entry_from_stat(st, blob.id)
        was = key in index
        index[key] = entry
        if was: modified += 1
        else: added += 1
    keepset = set(keep)
    for rel in sorted(tracked):
        if rel.startswith(SKIP_PREFIX): continue
        if rel not in keepset:
            if pathlib.Path(rel).exists() and not ig.is_ignored(rel):      # skipped for size: leave
                continue
            del index[rel.encode()]; removed += 1
    index.write()
    return added, modified, removed, skipped, len(keep)

def status_report():
    keep, skipped = wanted_files()
    index = repo.open_index()
    problems = []
    for rel in keep:
        key = rel.encode()
        blob = Blob.from_string(pathlib.Path(rel).read_bytes())
        if key not in index: problems.append(("untracked", rel))
        elif index[key].sha != blob.id: problems.append(("modified", rel))
    for k in index:
        rel = k.decode()
        if rel.startswith(SKIP_PREFIX): continue
        if not pathlib.Path(rel).exists(): problems.append(("deleted", rel))
    return problems, keep, skipped

def tree_files(commit_id):
    out = {}
    def walk(t, prefix=""):
        for e in repo[t].items():
            p = prefix + e.path.decode()
            if e.mode & 0o170000 == 0o040000: walk(e.sha, p + "/")
            else: out[p] = e.sha
    walk(repo[commit_id].tree)
    return out

if mode_cmd in ("baseline", "package"):
    if mode_cmd == "baseline":
        main = repo.refs[b"refs/heads/main"]
        repo.refs[BRANCH] = main
        repo.refs.set_symbolic_ref(b"HEAD", BRANCH)
    added, modified, removed, skipped, n = stage()
    # build the commit from the index
    from dulwich.index import commit_index
    tree_id = commit_index(repo.object_store, repo.open_index())
    from dulwich.objects import Commit
    c = Commit(); c.tree = tree_id; c.parents = [repo.refs[BRANCH]]
    c.author = c.committer = AUTHOR; c.author_time = c.commit_time = int(time.time()); c.author_timezone = c.commit_timezone = 0
    c.encoding = b"UTF-8"; c.message = message.encode()
    repo.object_store.add_object(c)
    repo.refs[BRANCH] = c.id
    print("commit", c.id.decode(), "added", added, "modified", modified, "removed", removed, "files in tree", n)
    print("skipped:", skipped)
problems, keep, skipped = status_report()
files_in_commit = tree_files(repo.refs[BRANCH] if BRANCH in repo.refs else repo.head())
extra = [f for f in files_in_commit if f not in set(keep) and not f.startswith(SKIP_PREFIX)]
print("branch", repo.refs.read_ref(b"HEAD"), "HEAD ->", repo.refs.get_symrefs().get(b"HEAD"))
print("status problems:", problems[:20], "count", len(problems))
print("committed files", len(files_in_commit), "working non-ignored (without input/)", len(keep), "extra in commit (not in tree)", extra[:10])
print("skipped:", skipped)

