"""Inventory of the standard-form mock P: python mock_data/tools/inventory_p.py [OUT_DIR]  (default docs/).
Reads P and the CGM; writes ncp_p_ra_inventory.md and the CSVs ncp_p_inventory_pst/rd/bids.csv into OUT_DIR.
Also available as: python -m mock_data inventory-p --out-dir OUT_DIR"""
import sys, pathlib, zipfile, csv, re, collections, logging, io, tempfile
REPO = pathlib.Path(__file__).resolve().parents[2]
sys.path[:0] = [str(REPO / 'src' / 'rao'), str(REPO)]
from mock_data import paths
logging.disable(logging.CRITICAL)
from rdflib import Graph, RDF
from pre_milp import cgmes_loader, ncp_parser

P_ZIP = paths.STANDARD_ZIP
CGM_ZIP = paths.CGM_ZIP
OUT_DIR = pathlib.Path(sys.argv[1]) if len(sys.argv) > 1 else REPO / 'docs'
TSOS = ['Belgovia', 'Espheim', 'Galia', 'Svedala']

sh = lambda x: str(x).split('#')[-1]
def last(x): return None if x is None else re.split(r'[#.]', str(x))[-1]
def frag(x): return str(x).split('#')[-1].lstrip('_')

def val(g, s, name):
    for p, o in g.predicate_objects(s):
        if sh(p) == name: return o
def vals(g, s, name): return [o for p, o in g.predicate_objects(s) if sh(p) == name]
def cls(g, s): return [sh(o) for o in g.objects(s, RDF.type)]
def of_class(g, c): return [s for s in set(g.subjects(RDF.type, None)) if c in cls(g, s)]
def mrid(g, s):
    v = val(g, s, 'IdentifiedObject.mRID')
    return str(v) if v is not None else frag(s)
def name(g, s):
    v = val(g, s, 'IdentifiedObject.name')
    return str(v) if v is not None else ''

zp = zipfile.ZipFile(P_ZIP)
G = {}
for t in TSOS:
    for kind in ('RA', 'SIS', 'CO', 'AE'):
        g = Graph(); g.parse(data=zp.read(f'{t}_{kind}.xml'), format='xml'); G[(t, kind)] = g
org = Graph(); org.parse(data=zp.read('Org-NineRealms_CD.xml'), format='xml')
org_name = {}
for s in set(org.subjects(RDF.type, None)):
    n = name(org, s)
    if n: org_name[frag(s)] = (n, cls(org, s)[0])
    m = mrid(org, s);
    if n: org_name[m] = (n, cls(org, s)[0])

# ---- CGM
net = cgmes_loader.load_cgm(cgm_zip_override=CGM_ZIP)
import tempfile
cgm_dir = pathlib.Path(tempfile.mkdtemp(prefix='inventory_cgm_'))
cgmes_loader.extract_cgm_zip(CGM_ZIP, cgm_dir)
xml_files = sorted(cgm_dir.rglob('*.xml'))
t2t = {}
for f in xml_files:
    if '_EQ_' in f.name or f.name.endswith('EQ.xml') or 'EQ' in f.stem.split('_'):
        try:
            t2t.update(ncp_parser.build_tap_changer_to_transformer_map(f))
        except Exception as e:
            pass
ptc = net.get_phase_tap_changers()
trafo = net.get_2_windings_transformers()
gens = net.get_generators(all_attributes=True)
vls = net.get_voltage_levels()
subs = net.get_substations(all_attributes=True)
try:
    avl = net.get_areas_voltage_levels()
except Exception:
    avl = None
areas = net.get_areas()
vl_area = {}
if avl is not None and len(avl):
    for idx, row in avl.reset_index().iterrows():
        vl_area.setdefault(row['voltage_level_id'], []).append(areas.loc[row['id'], 'name'] if row['id'] in areas.index else row['id'])

texts = {f: f.read_text(encoding='utf-8', errors='replace') for f in xml_files}
def cgm_name(mid):
    pat = re.compile(r'rdf:(?:ID|about)="#?_?' + re.escape(mid) + r'"[^>]*>(.*?)</cim:\w+>', re.S)
    for f, tx in texts.items():
        m = pat.search(tx)
        if m:
            n = re.search(r'<cim:IdentifiedObject\.name>([^<]*)<', m.group(1))
            if n: return n.group(1)
    return ''

# control area of a CIM GeneratingUnit (ControlAreaGeneratingUnit in the EQ files)
unit_area = {}
cagu = re.compile(r'<cim:ControlAreaGeneratingUnit[^>]*>(.*?)</cim:ControlAreaGeneratingUnit>', re.S)
for f, tx in texts.items():
    for m in cagu.finditer(tx):
        u = re.search(r'ControlAreaGeneratingUnit\.GeneratingUnit rdf:resource="#_?([^"]+)"', m.group(1))
        a = re.search(r'ControlAreaGeneratingUnit\.ControlArea rdf:resource="#_?([^"]+)"', m.group(1))
        if u and a: unit_area[u.group(1)] = cgm_name(a.group(1)) or a.group(1)

def loc_of_vl(vl):
    if vl not in vls.index: return ('', '', '', '', '')
    r = vls.loc[vl]; sid = r['substation_id']
    sname = subs.loc[sid, 'name'] if sid in subs.index else ''
    region = subs.loc[sid, 'CGMES.regionName'] if sid in subs.index else ''
    country = subs.loc[sid, 'country'] if sid in subs.index else ''
    return (sname, f"{r['name']} ({r['nominal_v']:g} kV)", str(country) or '', region, ' | '.join(vl_area.get(vl, [])))

# generators: CIM unit id -> generator ids
gens_by_unit = {}
for gid, u in gens['CGMES.GeneratingUnit'].items():
    if isinstance(u, str) and u:
        gens_by_unit.setdefault(u.lstrip('_'), []).append(str(gid))

# ---- contingencies per TSO
co_info = {}   # id -> (name, class, file tso)
for t in TSOS:
    g = G[(t, 'CO')]
    for c in ('OrdinaryContingency', 'ExceptionalContingency', 'OutOfRangeContingency'):
        for s in of_class(g, c):
            co_info[mrid(g, s)] = (name(g, s), c, t)

odd = []
rd_gens = []
pst_rows, rd_rows, bid_rows = [], [], []
summary = {}
link_ids_by_tso = collections.defaultdict(set)
gens_used_by_tso = collections.defaultdict(set)
all_ra_ids = {}

def ra_links(t, ra_id):
    g = G[(t, 'RA')]
    out = []
    for s in of_class(g, 'ContingencyWithRemedialAction'):
        r = val(g, s, 'ContingencyWithRemedialAction.RemedialAction')
        if r is not None and frag(r) == ra_id:
            c = frag(val(g, s, 'ContingencyWithRemedialAction.Contingency'))
            kind = last(val(g, s, 'ContingencyWithRemedialAction.combinationConstraintKind')) or 'missing'
            out.append((c, kind))
    return sorted(out)

def link_text(t, ra_id, kind):
    L = ra_links(t, ra_id)
    if not L:
        if kind == 'curative': odd.append(f'{t}: curative RA {ra_id} has no contingency link')
        return 'all (no link)', '', 0
    for c, _ in L:
        link_ids_by_tso[t].add(c)
        if c not in co_info: odd.append(f'{t}: RA {ra_id} links contingency {c} that is in no CO file')
    ids = ' | '.join(f"{c} {co_info.get(c, ('?',))[0]}" for c, _ in L)
    kinds = ' | '.join(f"{co_info.get(c, ('?',))[0]}={k}" for c, k in L)
    return ids, kinds, len(L)

def group_of(g_ra, s):
    out = []
    for p, o in g_ra.predicate_objects(s):
        pass
    for dep in of_class(g_ra, 'RemedialActionDependency'):
        r = val(g_ra, dep, 'RemedialActionDependency.RemedialAction')
        if r is not None and frag(r) == frag(s):
            out.append(frag(val(g_ra, dep, 'RemedialActionDependency.DependingRemedialActionGroup')))
    return ' | '.join(out) if out else 'none'

for t in TSOS:
    g = G[(t, 'RA')]
    # PST RAs
    n_pst = collections.Counter()
    for tpa in of_class(g, 'TapPositionAction'):
        ra = val(g, tpa, 'GridStateAlteration.GridStateAlterationRemedialAction')
        ra_id = frag(ra); kind = last(val(g, ra, 'RemedialAction.kind'))
        n_pst[kind] += 1
        tc = frag(val(g, tpa, 'TapPositionAction.TapChanger'))
        tr = t2t.get(tc)
        if tr is None or tr not in ptc.index:
            odd.append(f'{t}: PST RA {ra_id} TapChanger {tc} has no phase tap changer in the CGM')
            info = {}
        else:
            r = ptc.loc[tr]; tw = trafo.loc[tr]
            l1 = loc_of_vl(tw['voltage_level1_id']); l2 = loc_of_vl(tw['voltage_level2_id'])
            info = dict(tr=tr, trname=tw['name'], low=int(r['low_tap']), high=int(r['high_tap']), tap=int(r['tap']),
                        l1=l1, l2=l2)
        ids, kinds, nlinks = link_text(t, ra_id, kind)
        rng_in_ra = [x for x in of_class(g, 'StaticPropertyRange')]
        pst_rows.append(dict(
            TSO=t, ra_mrid=ra_id, ra_name=name(g, ra), kind=kind,
            pst_equipment_id=info.get('tr', ''), pst_name=info.get('trname', ''), tap_changer_id=tc, tap_changer_name=cgm_name(tc),
            reaction_time=str(val(g, ra, 'RemedialAction.timeToImplement') or ''),
            time_per_stage=str(val(g, tpa, 'GridStateAlteration.timePerStage') or ''),
            range_in_ra='none (no StaticPropertyRange)' if not rng_in_ra else 'see RA file',
            cgm_min_tap=info.get('low', ''), cgm_max_tap=info.get('high', ''), cgm_current_tap=info.get('tap', ''), direction='none in the RA',
            contingencies=ids, link_kinds=kinds, n_links=nlinks, group=group_of(g, ra),
            applied_region_AppointedToRegion='not set' if val(g, ra, 'RemedialAction.AppointedToRegion') is None else org_name.get(frag(val(g, ra, 'RemedialAction.AppointedToRegion')), ('?',))[0],
            substation=info['l1'][0] if info else '', voltage_level=info['l1'][1] if info else '',
            other_side_substation=info['l2'][0] if info else '', other_side_voltage_level=info['l2'][1] if info else '',
            cgm_country=info['l1'][2] if info else '', cgm_region=info['l1'][3] if info else '', cgm_area='n/a (no area membership of a transformer in the CGM; see the CGM region)',
        ))
    summary.setdefault(t, {})['pst'] = n_pst

    # RD RAs, bids
    s_g = G[(t, 'SIS')]
    rd = of_class(g, 'RedispatchRemedialAction')
    rd_ids = {mrid(g, s): s for s in rd}
    by_bid, by_strat = ncp_parser.read_key_routes(s_g, g, set(rd_ids))
    key_unit = {}
    key_pf = collections.defaultdict(list)
    for k in of_class(s_g, 'PowerShiftKeySchedule'):
        key_unit[mrid(s_g, k)] = [frag(u) for u in vals(s_g, k, 'PowerShiftKeySchedule.GeneratingUnit')]
        for pf in of_class(s_g, 'ParticipationFactorTimePoint'):
            r = val(s_g, pf, 'ParticipationFactorTimePoint.PowerShiftKeySchedule')
            if r is not None and frag(r) == mrid(s_g, k):
                key_pf[mrid(s_g, k)].append((str(val(s_g, pf, 'ParticipationFactorTimePoint.atTime')), str(val(s_g, pf, 'ParticipationFactorTimePoint.participationFactor'))))
    # check: every key has a participation factor and a unit
    for k, u in key_unit.items():
        if not u: odd.append(f'{t}: key {k} has no GeneratingUnit')
        if k not in key_pf: odd.append(f'{t}: key {k} has no participation factor')
    existing = {k for k, u in key_unit.items()}
    n_rd = collections.Counter()
    for ra_id, s in sorted(rd_ids.items(), key=lambda kv: name(g, kv[1])):
        kind = last(val(g, s, 'RemedialAction.kind')); n_rd[kind] += 1
        ids, kinds, nlinks = link_text(t, ra_id, kind)
        used = (by_bid[ra_id] & existing) or by_strat[ra_id]
        route_used = 'bid route' if (by_bid[ra_id] & existing) else 'strategy route'
        if by_bid[ra_id] and by_strat[ra_id]:
            ub = {u for k in by_bid[ra_id] for u in key_unit.get(k, [])}; us = {u for k in by_strat[ra_id] for u in key_unit.get(k, [])}
            if ub != us: odd.append(f'{t}: RD RA {ra_id}: bid route units {sorted(ub)} differ from strategy route units {sorted(us)}')
        units = sorted({u for k in used for u in key_unit.get(k, [])})
        if not units: odd.append(f'{t}: RD RA {ra_id} has no generating unit in its keys')
        cells = collections.defaultdict(list)
        for u in units:
            gl = gens_by_unit.get(u, [])
            if len(gl) != 1: odd.append(f'{t}: GeneratingUnit {u} maps to {len(gl)} generators {gl}')
            for gid in gl:
                gens_used_by_tso[t].add(gid); rd_gens.append((ra_id, kind, gid))
                gr = gens.loc[gid]
                l = loc_of_vl(gr['voltage_level_id'])
                cells['unit'].append(f"{u} {cgm_name(u)}"); cells['gen'].append(f"{gid} ({gens.loc[gid, 'name']})")
                cells['sub'].append(l[0]); cells['vl'].append(l[1]); cells['cty'].append(l[2]); cells['reg'].append(l[3]); cells['area'].append(unit_area.get(u, ''))
                cells['pmin'].append(f"{gr['min_p']:g}"); cells['pmax'].append(f"{gr['max_p']:g}"); cells['tp'].append(f"{gr['target_p']:g}")
                cells['conn'].append(str(gr['connected']))
        bz = val(g, s, 'PowerRemedialAction.BiddingZone')
        j = lambda k: ' | '.join(cells[k])
        rd_rows.append(dict(
            TSO=t, ra_mrid=ra_id, ra_name=name(g, s), kind=kind,
            reaction_time=str(val(g, s, 'RemedialAction.timeToImplement') or 'not set'),
            contingencies=ids, link_kinds=kinds, n_links=nlinks,
            applied_region_AppointedToRegion='not set' if val(g, s, 'RemedialAction.AppointedToRegion') is None else org_name.get(frag(val(g, s, 'RemedialAction.AppointedToRegion')), ('?',))[0],
            bidding_zone=org_name.get(frag(bz), ('?',))[0] if bz is not None else 'not set',
            key_route_used=route_used, key_schedules=' | '.join(sorted(used)),
            cim_generating_unit=j('unit'), generator_id=j('gen'), substation=j('sub'), voltage_level=j('vl'),
            cgm_country=j('cty'), cgm_region=j('reg'), cgm_area=j('area'),
            pmin_mw=j('pmin'), pmax_mw=j('pmax'), target_p_mw=j('tp'), connected=j('conn'), group=group_of(g, s),
        ))
    summary[t]['rd'] = n_rd
    # bids
    n_bid = collections.Counter()
    for b in sorted(of_class(s_g, 'PowerBidSchedule'), key=name.__get__ if False else (lambda x: name(s_g, x))):
        b_id = mrid(s_g, b)
        ra = val(s_g, b, 'PowerBidSchedule.PowerRemedialAction')
        ra_id = frag(ra) if ra is not None else ''
        if ra is None or ra_id not in rd_ids: odd.append(f'{t}: bid {b_id} belongs to no redispatch RA of the RA file (RA {ra_id or "none"})')
        direction = last(val(s_g, b, 'PowerBidSchedule.direction')) or 'none'
        n_bid[direction] += 1
        tps = [x for x in of_class(s_g, 'PowerBidScheduleTimePoint') if frag(val(s_g, x, 'PowerBidScheduleTimePoint.PowerBidSchedule')) == b_id]
        # bid route keys of this bid
        bid_keys = set()
        for d in of_class(s_g, 'PowerShiftKeyDistribution'):
            bb = val(s_g, d, 'PowerShiftKeyDistribution.PowerBidSchedule')
            if bb is not None and frag(bb) == b_id:
                bid_keys.update(frag(o) for o in vals(s_g, d, 'PowerShiftKeyDistribution.PowerShiftKeySchedule'))
        strat_keys = by_strat.get(ra_id, set())
        use_bid = bool(bid_keys & existing)
        keys = bid_keys if use_bid else strat_keys
        # key ids are mRIDs in the maps; map to mrid via lookup
        gen_ids = []
        for k in keys:
            for u in key_unit.get(k, []):
                gen_ids += gens_by_unit.get(u, [])
        pf = ' | '.join(f"{v} @ {a}" for k in keys for a, v in key_pf.get(k, []))
        bid_rows.append(dict(
            TSO=t, bid_mrid=b_id, bid_name=name(s_g, b), ra_mrid=ra_id, ra_name=name(g, ra) if ra is not None and ra_id in rd_ids else '',
            ra_kind=last(val(g, rd_ids[ra_id], 'RemedialAction.kind')) if ra_id in rd_ids else '',
            direction=direction, p_mw=' | '.join(str(val(s_g, x, 'PowerBidScheduleTimePoint.p')) for x in tps),
            price_eur_per_mw=' | '.join(str(val(s_g, x, 'PowerBidScheduleTimePoint.price')) for x in tps),
            time_point=' | '.join(str(val(s_g, x, 'PowerBidScheduleTimePoint.atTime')) for x in tps),
            activation_cost=str(val(s_g, b, 'PowerBidSchedule.activationCost') or ''),
            interpolation_kind=last(val(s_g, b, 'BaseTimeSeries.interpolationKind')) or '',
            lead_time=str(val(s_g, b, 'PowerBidSchedule.leadTime') or ''), priority=str(val(s_g, b, 'PowerBidSchedule.priority') or ''),
            route_used='bid route' if use_bid else 'strategy route',
            bid_route_key=' | '.join(sorted(bid_keys)), strategy_route_key=' | '.join(sorted(strat_keys)),
            key_schedule_used=' | '.join(sorted(keys)), participation_factor=pf, generator_id=' | '.join(gen_ids),
        ))
        if not tps: odd.append(f'{t}: bid {b_id} has no time point')
    summary[t]['bid'] = n_bid
    # RAs without a bid
    bid_ras = {r['ra_mrid'] for r in bid_rows if r['TSO'] == t}
    for ra_id in rd_ids:
        if ra_id not in bid_ras: odd.append(f'{t}: RD RA {ra_id} has no bid')
    # contingencies of the CO file never linked by an RA
    summary[t]['co_in_file'] = sum(1 for v in co_info.values() if v[2] == t)

# generator shared by several RAs / bids
gcount = collections.Counter(g for _, _, g in rd_gens)
notes = []
for gid, n in sorted(gcount.items()):
    nm_ = gens.loc[gid, 'name']
    rs = [k for _, k, g_ in rd_gens if g_ == gid]
    if n != 2 and not (n == 4 and set(rs) == {'preventive', 'curative'}):
        odd.append(f'generator {gid} ({nm_}): used by {n} RD RAs')
    if n == 4:
        notes.append(f'{gid} ({nm_}) is the unit of 4 RD RAs: up and down, preventive and curative') if False else notes.append(f'{gid} ({nm_}) is the unit of 4 RD RAs: up and down, preventive and curative')
# duplicate names
for rows, label in ((pst_rows, 'PST RA'), (rd_rows, 'RD RA')):
    c = collections.Counter(r['ra_name'] for r in rows)
    for nme, n in c.items():
        if n > 1: odd.append(f'{label} name {nme!r} used {n} times')
# contingencies not linked by any RA
linked_all = set().union(*link_ids_by_tso.values())
for cid, (cn, cc, ct) in co_info.items():
    if cid not in linked_all: odd.append(f'{ct}: contingency {cid} {cn} ({cc}) is linked by no RA')

# ---- write CSV
docs = OUT_DIR
docs.mkdir(parents=True, exist_ok=True)
def write_csv(path, rows):
    with open(path, 'w', newline='', encoding='utf-8') as f:
        w = csv.DictWriter(f, fieldnames=list(rows[0].keys()), lineterminator='\r\n'); w.writeheader(); w.writerows(rows)
write_csv(docs / 'ncp_p_inventory_pst.csv', pst_rows)
write_csv(docs / 'ncp_p_inventory_rd.csv', rd_rows)
write_csv(docs / 'ncp_p_inventory_bids.csv', bid_rows)

# ---- markdown
def tab(rows, cols, heads=None):
    heads = heads or cols
    out = ['| ' + ' | '.join(heads) + ' |', '|' + '---|' * len(cols)]
    for r in rows:
        out.append('| ' + ' | '.join(str(r[c]).replace('|', '/').replace('\n', ' ') for c in cols) + ' |')
    return '\n'.join(out)

region_names = sorted({v[0] for v in org_name.values() if v[1] == 'CapacityCalculationRegion'})
ae_regions = collections.Counter()
for t in TSOS:
    ga = G[(t, 'AE')]
    for s in of_class(ga, 'AssessedElement'):
        r = val(ga, s, 'AssessedElement.SecuredForRegion')
        if r is not None: ae_regions[(t, org_name.get(frag(r), (frag(r),))[0])] += 1
sumrows = []
tot = collections.Counter()
for t in TSOS:
    pr = [r for r in pst_rows if r['TSO'] == t]; rr = [r for r in rd_rows if r['TSO'] == t]; br = [r for r in bid_rows if r['TSO'] == t]
    row = dict(TSO=t, pst=f"{len(pr)} ({summary[t]['pst']['preventive']} prev / {summary[t]['pst']['curative']} cur)",
               rd=f"{len(rr)} ({summary[t]['rd']['preventive']} prev / {summary[t]['rd']['curative']} cur)",
               bids=f"{len(br)} ({summary[t]['bid']['up']} up / {summary[t]['bid']['down']} down)",
               gens=len(gens_used_by_tso[t]), cos=f"{len(link_ids_by_tso[t])} of {summary[t]['co_in_file']}")
    sumrows.append(row)
tp = len(pst_rows); tr_ = len(rd_rows); tb = len(bid_rows)
tg = len(set().union(*gens_used_by_tso.values()))
tc = len(linked_all)
sumrows.append(dict(TSO='**Total**', pst=f"{tp} ({sum(1 for r in pst_rows if r['kind']=='preventive')} prev / {sum(1 for r in pst_rows if r['kind']=='curative')} cur)",
                    rd=f"{tr_} ({sum(1 for r in rd_rows if r['kind']=='preventive')} prev / {sum(1 for r in rd_rows if r['kind']=='curative')} cur)",
                    bids=f"{tb} ({sum(1 for r in bid_rows if r['direction']=='up')} up / {sum(1 for r in bid_rows if r['direction']=='down')} down)",
                    gens=tg, cos=f"{tc} of {len(co_info)}"))

md = []
md.append('# Inventory of the standard-form mock P: PST RAs, redispatch RAs, bids\n')
md.append('Counted from the XML of `tests/fixtures/NCP_mock_standard.zip` (RA, SIS, CO, AE files and `Org-NineRealms_CD.xml`) and, for locations, tests, names and limits, from `tests/fixtures/CGM_package.zip` (read with pypowsybl; EQ files for the tap changer to transformer link and for names). Nothing was run through the optimiser. The same tables are in `ncp_p_inventory_pst.csv`, `ncp_p_inventory_rd.csv` and `ncp_p_inventory_bids.csv` (all columns; the tables below show the main ones). Generated by a one-off script; not part of the pipeline.\n')
md.append('Reading notes:\n- A generating unit is the CIM `GeneratingUnit` of the shift key; the "generator id" is the network generator (SynchronousMachine) the pipeline maps it to (`CGMES.GeneratingUnit`).\n- P has **no** `RemedialAction.AppointedToRegion` and no `StaticPropertyRange` on any RA, so "region" and "ranges" cannot be given from the RA. The region column shows "not set"; the region the TSO\'s assessed elements are secured for (`AssessedElement.SecuredForRegion`) is given below. The CGM gives no country on the substations (empty), so "country" is the CGM region name of the substation (`CGMES.regionName`). "Area" is the control area of the generating unit (`ControlAreaGeneratingUnit` in the CGM EQ files); a transformer has no control area in the CGM, so a PST row has only the region.\n- PST ranges: the RA has none, so the model uses the tap range of the transformer in the CGM (min / max tap and current tap are shown); direction is not a property of a PST RA in the profile.\n- A preventive RA has no contingency link by design ("all (no link)").\n')
md.append('## D. Summary per TSO\n')
md.append(tab(sumrows, ['TSO', 'pst', 'rd', 'bids', 'gens', 'cos'], ['TSO', 'PST RAs', 'RD RAs', 'Bids', 'Generators used', 'Contingencies linked (of those in the CO file)']))
md.append('\nRegions in the CD file (`CapacityCalculationRegion`): ' + ', '.join(region_names) + '. `AssessedElement.SecuredForRegion` of the AEs: ' + '; '.join(f"{t}: {r} ({n} AEs)" for (t, r), n in sorted(ae_regions.items())) + '.\n')

md.append('## A. PST RAs\n')
ptab = []
for t in TSOS:
    ptab.append(dict(TSO=t, prev=summary[t]['pst']['preventive'], cur=summary[t]['pst']['curative'], tot=sum(summary[t]['pst'].values())))
ptab.append(dict(TSO='**Total**', prev=sum(r['prev'] for r in ptab), cur=sum(r['cur'] for r in ptab), tot=sum(r['tot'] for r in ptab)))
md.append(tab(ptab, ['TSO', 'prev', 'cur', 'tot'], ['TSO', 'Preventive', 'Curative', 'Total']))
md.append('\nNo PST RA belongs to a group. Distinct PSTs: ' + str(len({r['pst_equipment_id'] for r in pst_rows})) + ' (each PST has one preventive and one curative RA).\n')
md.append(tab(pst_rows, ['TSO', 'ra_mrid', 'ra_name', 'pst_equipment_id', 'pst_name', 'kind', 'reaction_time', 'cgm_min_tap', 'cgm_max_tap', 'cgm_current_tap', 'contingencies', 'link_kinds', 'group', 'substation', 'voltage_level', 'cgm_region'],
            ['TSO', 'RA mRID', 'RA name', 'PST equipment id', 'PST name', 'Kind', 'Reaction time', 'Min tap (CGM)', 'Max tap (CGM)', 'Tap (CGM)', 'Contingencies (id name)', 'Link kind', 'Group', 'Substation', 'Voltage level', 'CGM region']))
md.append('\nCSV adds: tap changer id and name, timePerStage, range in RA, direction, other-side substation and voltage level, AppointedToRegion.\n')

md.append('## B. Redispatch RAs\n')
rtab = []
for t in TSOS:
    rtab.append(dict(TSO=t, prev=summary[t]['rd']['preventive'], cur=summary[t]['rd']['curative'], tot=sum(summary[t]['rd'].values())))
rtab.append(dict(TSO='**Total**', prev=sum(r['prev'] for r in rtab), cur=sum(r['cur'] for r in rtab), tot=sum(r['tot'] for r in rtab)))
md.append(tab(rtab, ['TSO', 'prev', 'cur', 'tot'], ['TSO', 'Preventive', 'Curative', 'Total']))
md.append('\nNo RD RA has a reaction time (`timeToImplement`) or a group; every RD RA has one bid and one unit. Bidding zone is `PowerRemedialAction.BiddingZone` by name in the CD file.\n')
md.append(tab(rd_rows, ['TSO', 'ra_mrid', 'ra_name', 'kind', 'reaction_time', 'contingencies', 'link_kinds', 'bidding_zone', 'cim_generating_unit', 'generator_id', 'substation', 'voltage_level', 'cgm_region', 'cgm_area', 'pmin_mw', 'pmax_mw', 'target_p_mw'],
            ['TSO', 'RA mRID', 'RA name', 'Kind', 'Reaction time', 'Contingencies (id name)', 'Link kind', 'Bidding zone', 'CIM GeneratingUnit (id name)', 'Generator id (name)', 'Substation', 'Voltage level', 'CGM region', 'CGM area', 'Pmin MW', 'Pmax MW', 'Target P MW']))
md.append('\nCSV adds: region (AppointedToRegion), key route used, key schedule ids, connected, group.\n')

md.append('## C. Bids (`PowerBidSchedule`)\n')
md.append('Each bid has a bid route (bid, `PowerShiftKeyDistribution`, key schedule) and its RA has a strategy route (strategy, `PowerShiftKeyDistribution`, key schedule); the pipeline uses the bid route when it reaches an existing key, otherwise the strategy route. Both routes exist in P and lead to the same unit.\n')
md.append(tab(bid_rows, ['TSO', 'bid_mrid', 'ra_mrid', 'ra_name', 'direction', 'p_mw', 'price_eur_per_mw', 'activation_cost', 'interpolation_kind', 'route_used', 'key_schedule_used', 'participation_factor', 'generator_id'],
            ['TSO', 'Bid mRID', 'RA mRID', 'RA name', 'Direction', 'p MW', 'Price EUR/MW', 'Activation cost', 'Interpolation', 'Route used', 'Key schedule (used)', 'Participation factor @ time', 'Generator id']))
md.append('\nCSV adds: bid name, RA kind, time point, lead time, priority, both route keys.\n')

md.append('## Odd findings\n')
if odd:
    md.extend('- ' + o for o in sorted(set(odd)))
else:
    md.append('None.')
md.append('\nNot errors, but worth knowing:\n')
md.extend('- ' + o for o in notes)
md.append('- Every RD RA has exactly one bid, one participation factor of 1.0 and one unit; bid route and strategy route agree for all 32 RAs (checked).')
md.append('- Preventive RAs carry no contingency link by design; no curative RA lacks one.')
md.append('- No RA has `AppointedToRegion`, a group, a `StaticPropertyRange` or (RD) a reaction time.')
(docs / 'ncp_p_ra_inventory.md').write_bytes(('\n'.join(md) + '\n').replace('\n', '\r\n').encode('utf-8'))
print('PST', len(pst_rows), 'RD', len(rd_rows), 'bids', len(bid_rows))
print('summary'); [print(r) for r in sumrows]
print('odd:'); [print(' -', o) for o in sorted(set(odd))]
print('t2t', len(t2t))
import shutil
shutil.rmtree(cgm_dir, ignore_errors=True)
