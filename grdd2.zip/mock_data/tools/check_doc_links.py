"""Link checker for the documentation: python mock_data/tools/check_doc_links.py [--live-only]

Checks, in docs/, mock_data/, .github/, reference/technical/ and the root README.md (all *.md files):
- every relative markdown link [text](target) resolves (relative to the file, anchors and http(s)/mailto skipped);
- every path written in backticks or plain text that starts with docs/, reference/, src/, tests/ or mock_data/ and ends in a
  known extension exists (relative to the repository root; a trailing :line, line range or section is ignored).
Also checks the same path strings in the comments and docstrings of src/, tests/ and mock_data/ (*.py, *.yaml).
Prints the dead ones, one per line, with file and line; the exit code is the number of dead ones capped at 1.
History rule: docs/CHANGELOG.md, docs/DECISIONS.md and everything under docs/archive/ quote old paths as they were when written,
so a dead path there is not a live link: it is listed as "history" (hidden by --live-only) and never fails the check.
Whitelist (WHITELIST below): live links that are dead on purpose. The exit code is 1 when a live, non-whitelisted link is dead."""
import pathlib
import re
import sys

THIS = pathlib.Path(__file__).resolve()      # not checked itself: its whitelist names dead paths on purpose
ROOT = THIS.parents[2]
MD_LINK = re.compile(r"\]\(([^)\s]+)\)")
PATH = re.compile(r"(?<![\w/.-])((?:docs|reference|src|tests|mock_data)/[\w./-]*[\w-]\.(?:md|py|csv|yaml|yml|txt|json|zip))")
HISTORY = ("docs/CHANGELOG.md", "docs/DECISIONS.md")
# (file, target) pairs that are dead on purpose:
# - docs/Next_Steps.md names docs/Real_Data_Results.md, which the real-data run creates (it is not committed);
# - docs/User_Guide.md quotes the names before the rename of 24 Oct 2026 (the "Was" column of section 5 and the earliest-trace
#   note): they are history inside a live file, the "Is" column holds the current names.
WHITELIST = {
    ("docs/Next_Steps.md", "docs/Real_Data_Results.md"),
    ("docs/User_Guide.md", "tests/test_incremental_ac_fallback.py"),
    ("docs/User_Guide.md", "tests/fixtures/NCP_pst_fallback_scenario.zip"),
    ("docs/User_Guide.md", "tests/fixtures/NCP_pst_fallback_scenario_legacy.zip"),
    ("docs/User_Guide.md", "tests/fixtures/NCP_generic.zip"),
    ("docs/User_Guide.md", "tests/ct_mock.py"),
}


def files(root: pathlib.Path = ROOT):
    for pattern in ("docs/**/*.md", "mock_data/**/*.md", ".github/**/*.md", "reference/technical/**/*.md", "README.md"):
        yield from root.glob(pattern)
    for folder in ("src", "tests", "mock_data"):
        for pattern in ("*.py", "*.yaml"):
            yield from (p for p in (root / folder).rglob(pattern) if "__pycache__" not in p.parts and p.resolve() != THIS)


def is_history(rel: str) -> bool:
    return rel in HISTORY or rel.startswith("docs/archive/")


def main(live_only: bool, root: pathlib.Path = ROOT) -> int:
    live, history = [], []
    for path in sorted(set(files(root))):
        rel = path.relative_to(root).as_posix()
        for number, line in enumerate(path.read_text(encoding="utf-8", errors="replace").splitlines(), 1):
            targets = []
            if path.suffix == ".md":
                for target in MD_LINK.findall(line):
                    if not re.match(r"(https?:|mailto:|#)", target):
                        targets.append((target, (path.parent / target.split("#")[0]).resolve() if target.split("#")[0] else None))
            for target in PATH.findall(line):
                targets.append((target, (root / target).resolve()))
            for text, resolved in targets:
                if resolved is not None and not resolved.exists() and (rel, text) not in WHITELIST:
                    (history if is_history(rel) else live).append(f"{rel}:{number}: {text}")
    for item in live:
        print("DEAD", item)
    if not live_only:
        for item in history:
            print("history", item)
    print(f"{len(live)} dead in live files, {len(history)} in history files (CHANGELOG, DECISIONS, archive)")
    return 1 if live else 0


if __name__ == "__main__":
    sys.exit(main("--live-only" in sys.argv))
