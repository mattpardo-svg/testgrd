"""
hvdc_mock.py — the mock NCP of the HVDC RA tests (docs/specs/hvdc_ra_specs.md H13.1, H13.2).

build_hvdc_mock_ncp(dest) copies NCP_mock_standard.zip and adds to Svedala_RA.xml two
HVDC remedial actions on EquivalentInjections of the CGM (Injection_SD_EH1, P0 418.5 MW, and
Injection_SD_BO3, P0 1.56 MW) in one balanced group, and a Svedala_SHS.xml that lowers the PATL of
TieLine_SD-EH1 (about 212 A in the CGM) so that moving the pair relieves it (about -2.2 A per MW of
the pair). Everything is parameterised so the tests build their variants (curative, penalty
factors, bad groups) from the same code. The CGM stays tests/fixtures/CGM_package.zip.
"""
import uuid
import zipfile
from pathlib import Path

from .paths import FIXTURES as _FIXTURES
from .standard import base_zip

# EquivalentInjections of CGM_package.zip (pypowsybl generator ids)
EI_SD_EH1 = "be3dee27-ce09-4de3-8417-8e6f8f79c5e6"   # Injection_SD_EH1, target_p 418.468 MW
EI_SD_BO3 = "ce437259-5cdd-4e3f-93a3-d333c0951454"   # Injection_SD_BO3, target_p 1.55864 MW
P0_SD_EH1, P0_SD_BO3 = 418.468, 1.55864
# the monitored branch the pair acts on: TieLine_SD-EH1 and its OperationalLimit in Svedala_AE.xml
XNE_BRANCH = "632d9eaa-06f7-4b7b-8f8f-ae248941efe2"
XNE_OPERATIONAL_LIMIT = "05f472d9-42d4-af2c-38e0-45a21830d53a"
SVEDALA = "Svedala"

ENUM = "https://cim4.eu/ns/nc#"


def _uid(*parts):
    """A deterministic id for a generated element."""
    return str(uuid.uuid5(uuid.NAMESPACE_URL, "/".join(str(p) for p in parts)))


def ra(mrid, ei, kind="preventive", available=True, penalty=1.0, time_to_implement=None, contingencies=(),
       ranges=(), name=None):
    """One HVDC RA spec. ranges: (direction, valueKind, value) tuples."""
    return dict(mrid=mrid, ei=ei, kind=kind, available=available, penalty=penalty,
                time_to_implement=time_to_implement, contingencies=list(contingencies), ranges=list(ranges),
                name=name or f"HVDC RA {mrid}")


def default_ras():
    """g1 absolute upAndDown 450 (range [-450, 450]); g2 incremental up 60 and down 60 and a second,
    lower down range 40 (lowest wins: [P0 - 40, P0 + 60])."""
    return [
        ra("11111111-0000-4000-8000-000000000001", EI_SD_EH1, ranges=[("upAndDown", "absolute", 450)],
           name="HVDC unit SD-EH1"),
        ra("11111111-0000-4000-8000-000000000002", EI_SD_BO3,
           ranges=[("up", "incremental", 60), ("down", "incremental", 60), ("down", "incremental", 40)],
           name="HVDC unit SD-BO3"),
    ]


# two contingencies of the mock that overload TieLine_SD-EH1 (N-0 212 A): 323.5 A and 323.1 A at 1030Z
CO_OVERLOAD_A = "f3a8c241-7b5e-4d92-b1c6-8e3f092a4d71"
CO_OVERLOAD_B = "92d4f3c9-32e1-47fd-8762-d0e9a042c5a3"
CURATIVE_GROUP = "22222222-0000-4000-8000-000000000002"


def curative_ras(contingencies=(CO_OVERLOAD_A,), time_to_implement="PT5M", factors=(1.0, 1.0), own_ranges=True,
                 linked=(True, True)):
    """The curative pair on the same two EIs: kind curative, linked to `contingencies` (empty: every contingency),
    reaction time `time_to_implement` (the TATL duration of the mock branch is 10 minutes), own ranges as in
    default_ras or none (then the preventive ranges of the unit apply)."""
    first = [("upAndDown", "absolute", 450)] if own_ranges else []
    second = [("up", "incremental", 60), ("down", "incremental", 60), ("down", "incremental", 40)] if own_ranges else []
    return [
        ra("33333333-0000-4000-8000-000000000001", EI_SD_EH1, kind="curative", penalty=factors[0],
           time_to_implement=time_to_implement, contingencies=contingencies if linked[0] else (), ranges=first,
           name="HVDC curative SD-EH1"),
        ra("33333333-0000-4000-8000-000000000002", EI_SD_BO3, kind="curative", penalty=factors[1],
           time_to_implement=time_to_implement, contingencies=contingencies if linked[1] else (), ranges=second,
           name="HVDC curative SD-BO3"),
    ]


def curative_groups(ras):
    return [(CURATIVE_GROUP, [r["mrid"] for r in ras[:2]])]

def default_groups(ras):
    return [("22222222-0000-4000-8000-000000000001", [r["mrid"] for r in ras[:2]])]


def _ra_xml(spec):
    mrid = spec["mrid"]
    action = _uid("action", mrid)
    parts = [f"""
  <nc:GridStateAlterationRemedialAction rdf:ID="_{mrid}">
    <cim:IdentifiedObject.mRID>{mrid}</cim:IdentifiedObject.mRID>
    <cim:IdentifiedObject.name>{spec['name']}</cim:IdentifiedObject.name>
    <nc:RemedialAction.normalAvailable>{str(spec['available']).lower()}</nc:RemedialAction.normalAvailable>
    <nc:RemedialAction.kind rdf:resource="{ENUM}RemedialActionKind.{spec['kind']}"/>"""]
    if spec["penalty"] is not None:
        parts.append(f"    <nc:RemedialAction.penaltyFactor>{spec['penalty']}</nc:RemedialAction.penaltyFactor>")
    if spec["time_to_implement"]:
        parts.append(f"    <nc:RemedialAction.timeToImplement>{spec['time_to_implement']}</nc:RemedialAction.timeToImplement>")
    parts.append("  </nc:GridStateAlterationRemedialAction>")
    parts.append(f"""  <nc:EquivalentInjectionAction rdf:ID="_{action}">
    <cim:IdentifiedObject.mRID>{action}</cim:IdentifiedObject.mRID>
    <nc:GridStateAlteration.GridStateAlterationRemedialAction rdf:resource="#_{mrid}"/>
    <nc:EquivalentInjectionAction.EquivalentInjection rdf:resource="#_{spec['ei']}"/>
    <nc:GridStateAlteration.PropertyReference rdf:resource="https://energy.referencedata.eu/PropertyReference/EquivalentInjection.p"/>
  </nc:EquivalentInjectionAction>""")
    for index, (direction, kind, value) in enumerate(spec["ranges"]):
        range_id = _uid("range", mrid, index)
        parts.append(f"""  <nc:StaticPropertyRange rdf:ID="_{range_id}">
    <nc:RangeConstraint.GridStateAlteration rdf:resource="#_{action}"/>
    <nc:RangeConstraint.direction rdf:resource="{ENUM}RelativeDirectionKind.{direction}"/>
    <nc:RangeConstraint.valueKind rdf:resource="{ENUM}ValueOffsetKind.{kind}"/>
    <nc:StaticPropertyRange.PropertyReference rdf:resource="https://energy.referencedata.eu/PropertyReference/EquivalentInjection.p"/>
    <nc:RangeConstraint.normalValue>{value}</nc:RangeConstraint.normalValue>
  </nc:StaticPropertyRange>""")
    for index, contingency in enumerate(spec["contingencies"]):
        parts.append(f"""  <nc:ContingencyWithRemedialAction rdf:ID="_{_uid('link', mrid, index)}">
    <nc:ContingencyWithRemedialAction.RemedialAction rdf:resource="#_{mrid}"/>
    <nc:ContingencyWithRemedialAction.Contingency rdf:resource="#_{contingency}"/>
  </nc:ContingencyWithRemedialAction>""")
    return "\n".join(parts)


def _group_xml(group_mrid, ra_mrids, kind="balanced", predicate="DependingRemedialActionGroup"):
    parts = [f"""  <nc:RemedialActionGroup rdf:ID="_{group_mrid}">
    <cim:IdentifiedObject.mRID>{group_mrid}</cim:IdentifiedObject.mRID>
    <cim:IdentifiedObject.name>HVDC link {group_mrid[-4:]}</cim:IdentifiedObject.name>
  </nc:RemedialActionGroup>"""]
    for index, ra_mrid in enumerate(ra_mrids):
        parts.append(f"""  <nc:RemedialActionDependency rdf:ID="_{_uid('dependency', group_mrid, ra_mrid)}">
    <nc:RemedialActionDependency.kind rdf:resource="{ENUM}RemedialActionDependencyKind.{kind}"/>
    <nc:RemedialActionDependency.{predicate} rdf:resource="#_{group_mrid}"/>
    <nc:RemedialActionDependency.RemedialAction rdf:resource="#_{ra_mrid}"/>
  </nc:RemedialActionDependency>""")
    return "\n".join(parts)


def _shs_xml(limit_a):
    return f"""<?xml version='1.0' encoding='UTF-8'?>
<rdf:RDF xmlns:rdf="http://www.w3.org/1999/02/22-rdf-syntax-ns#" xmlns:nc="{ENUM}" xmlns:cim="https://cim.ucaiug.io/ns#">
  <nc:CurrentLimitSchedule rdf:ID="_eeeeeeee-0000-4000-8000-000000000001">
    <cim:IdentifiedObject.name>HVDC mock PATL</cim:IdentifiedObject.name>
    <cim:IdentifiedObject.mRID>eeeeeeee-0000-4000-8000-000000000001</cim:IdentifiedObject.mRID>
    <nc:CurrentLimitSchedule.CurrentLimit rdf:resource="#_{XNE_OPERATIONAL_LIMIT}"/>
  </nc:CurrentLimitSchedule>
  <nc:CurrentLimitTimePoint rdf:ID="_eeeeeeee-0000-4000-8000-000000000002">
    <nc:CurrentLimitTimePoint.CurrentLimitSchedule rdf:resource="#_eeeeeeee-0000-4000-8000-000000000001"/>
    <nc:CurrentLimitTimePoint.atTime>2022-06-15T10:30:00Z</nc:CurrentLimitTimePoint.atTime>
    <nc:CurrentLimitTimePoint.value>{limit_a}</nc:CurrentLimitTimePoint.value>
  </nc:CurrentLimitTimePoint>
</rdf:RDF>
"""


# a contingency that removes the EquivalentInjection of g2 itself (the outage-element gate, H6.2, H11.1)
CO_EI_OUT = "44444444-0000-4000-8000-000000000001"
# a contingency of the two circuits at the bus of Injection_SD_BO3: it islands the unit, whose N-X sensitivities
# are then exactly zero (the N-X silent-zero guard, H8.2); the EI itself is not an outage element
CO_ISLAND_BO3 = "44444444-0000-4000-8000-000000000002"
ISLAND_BO3_LINES = ("536f4b84-db4c-4545-96e9-bb5a87f65d13", "d9622e7f-5bf0-4e7e-b766-b8596c6fe4ae")


def contingency_xml(mrid, equipment, name):
    """An ordinary must-study contingency (Svedala_CO.xml) with one ContingencyEquipment per equipment mRID."""
    parts = [f"""<nc:OrdinaryContingency rdf:ID="_{mrid}">
  <nc:Contingency.normalMustStudy>true</nc:Contingency.normalMustStudy>
  <cim:IdentifiedObject.mRID>{mrid}</cim:IdentifiedObject.mRID>
  <cim:IdentifiedObject.name>{name}</cim:IdentifiedObject.name>
</nc:OrdinaryContingency>"""]
    for equipment_mrid in equipment:
        element = _uid("element", mrid, equipment_mrid)
        parts.append(f"""<cim:ContingencyEquipment rdf:ID="_{element}">
  <cim:ContingencyElement.Contingency rdf:resource="#_{mrid}" />
  <cim:ContingencyEquipment.Equipment rdf:resource="#_{equipment_mrid}" />
  <cim:ContingencyEquipment.contingentStatus rdf:resource="https://cim.ucaiug.io/ns#ContingencyEquipmentStatusKind.outOfService" />
  <cim:IdentifiedObject.mRID>{element}</cim:IdentifiedObject.mRID>
</cim:ContingencyEquipment>""")
    return "\n".join(parts)


def _append(data: bytes, block: str) -> bytes:
    text = data.decode("utf-8")
    end = text.rindex("</rdf:RDF>")
    return (text[:end] + block + "\n" + text[end:]).encode("utf-8")


def build_hvdc_mock_ncp(dest, ras=None, groups=None, patl_a=190.0, extra_ra_xml="", source_zip=None,
                        extra_co_xml=""):
    """Write the mock NCP zip to `dest` and return it. ras / groups: see default_ras / default_groups
    (groups: [(group mRID, [RA mRIDs])]); patl_a: PATL (A) of TieLine_SD-EH1 at 1030Z (None: no
    Svedala_SHS.xml, the CGM limit stays); extra_ra_xml is appended to Svedala_RA.xml, extra_co_xml
    (see contingency_xml) to Svedala_CO.xml."""
    ras = default_ras() if ras is None else ras
    groups = default_groups(ras) if groups is None else groups
    block = "\n".join([_ra_xml(spec) for spec in ras] + [_group_xml(g, members) for g, members in groups]) + extra_ra_xml
    dest = Path(dest)
    with zipfile.ZipFile(base_zip() if source_zip is None else source_zip) as source, zipfile.ZipFile(dest, "w") as out:
        for item in source.infolist():
            data = source.read(item.filename)
            if item.filename == f"{SVEDALA}_RA.xml":
                data = _append(data, block)
            elif item.filename == f"{SVEDALA}_CO.xml" and extra_co_xml:
                data = _append(data, extra_co_xml)
            out.writestr(item.filename, data)
        if patl_a is not None:
            out.writestr(f"{SVEDALA}_SHS.xml", _shs_xml(patl_a))
    return dest
