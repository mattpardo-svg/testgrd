"""standard.py - the standard-form mock NCP.

base: the legacy mock converted by convert_ncp_to_standard with every section, the non-standard bid attributes dropped
and the bid signs corrected (the converter default). It has no countertrade RA; the builders of the countertrade, HVDC
and dataset mocks and the shared-bid cases start from it, so they mean what they always meant.
shipped: the base plus one preventive and one curative countertrade RA per region with their bids (countertrade_p).
`python -m mock_data standard` writes the shipped one; test_rao_ncp_standard_equivalence asserts that the file in
tests/fixtures equals this output byte for byte."""
import functools
import io
from pathlib import Path

from . import convert_ncp_to_standard as conv
from .countertrade_p import add_countertrade
from .paths import CGM_ZIP, LEGACY_ZIP
from .zipio import write_zip


def converter_options():
    return conv.Options(drop_nonstandard_bid_attributes=True)


@functools.lru_cache(maxsize=None)
def _base_files(legacy=str(LEGACY_ZIP), cgm=str(CGM_ZIP)):
    files, _log = conv.convert_files(conv._read_zip(legacy), conv._read_zip(cgm), converter_options())
    return files


def base_files() -> dict:
    """{name: bytes} of the standard-form mock without countertrade (a copy)."""
    return dict(_base_files())


def build_base(dest) -> Path:
    """Write the standard-form mock without countertrade to dest and return it."""
    write_zip(_base_files(), dest)
    return Path(dest)


def base_zip() -> io.BytesIO:
    """The standard-form mock without countertrade as a readable zip (a new buffer each call)."""
    buffer = io.BytesIO()
    write_zip(_base_files(), buffer)
    buffer.seek(0)
    return buffer


def shipped_files() -> dict:
    return add_countertrade(_base_files())


def build_standard(dest) -> Path:
    """Write the shipped standard-form mock (base plus the countertrade RAs) to dest and return it."""
    write_zip(shipped_files(), dest)
    return Path(dest)
