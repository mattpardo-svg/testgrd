"""ae_switch_variants.py - the standard-form mock with NCP switches on one assessed element of one TSO, to test that the
switches are applied (normalEnabled, inBaseCase, links to contingencies, an enabled flag at the run time).

`build_ae_switch_variant(source_zip, out_zip, tso, ae_mrid, properties=None, links=(), schedule=None)`:
- properties: {"normalEnabled": "false", "inBaseCase": "false"}: set on the AssessedElement (replaced when present);
- links: [(contingency mrid, kind)] with kind "included" / "excluded": AssessedElementWithContingency objects;
- schedule: (ISO time, enabled): an AssessedElementSchedule with one AssessedElementTimePoint in the SIS file.
"""

from __future__ import annotations

import re
import uuid
import zipfile
from pathlib import Path

from .zipio import fixed_entry

NC = "https://cim4.eu/ns/nc#"


def _new_id(seed: str) -> str:
    return str(uuid.uuid5(uuid.NAMESPACE_URL, "ae-switch-variant/" + seed))


def build_ae_switch_variant(source_zip: Path, out_zip: Path, tso: str, ae_mrid: str, properties: dict | None = None,
                            links: tuple | list = (), schedule: tuple | None = None) -> Path:
    ae_name, sis_name = f"{tso}_AE.xml", f"{tso}_SIS.xml"
    with zipfile.ZipFile(source_zip) as source, zipfile.ZipFile(out_zip, "w", zipfile.ZIP_DEFLATED) as out:
        for info in source.infolist():
            data = source.read(info.filename)
            if info.filename == ae_name:
                text = data.decode("utf-8")
                block = re.search(rf'<nc:AssessedElement rdf:ID="_{re.escape(ae_mrid)}">.*?</nc:AssessedElement>', text, re.S)
                assert block, f"{ae_mrid} not found in {ae_name}"
                new_block = block.group(0)
                for name, value in (properties or {}).items():
                    tag = f"nc:AssessedElement.{name}"
                    line = f"<{tag}>{value}</{tag}>"
                    if re.search(rf"<{tag}>.*?</{tag}>", new_block, re.S):
                        new_block = re.sub(rf"<{tag}>.*?</{tag}>", line, new_block, flags=re.S)
                    else:
                        new_block = new_block.replace("</nc:AssessedElement>", f"  {line}\n</nc:AssessedElement>")
                text = text.replace(block.group(0), new_block)
                link_xml = "".join(
                    f'<nc:AssessedElementWithContingency rdf:ID="_{_new_id(ae_mrid + contingency + kind)}">\n'
                    f'  <nc:AssessedElementWithContingency.AssessedElement rdf:resource="#_{ae_mrid}"/>\n'
                    f'  <nc:AssessedElementWithContingency.Contingency rdf:resource="#_{contingency}"/>\n'
                    f'  <nc:AssessedElementWithContingency.combinationConstraintKind rdf:resource="{NC}ElementCombinationConstraintKind.{kind}"/>\n'
                    "</nc:AssessedElementWithContingency>\n"
                    for contingency, kind in links
                )
                text = text.replace("</rdf:RDF>", link_xml + "</rdf:RDF>")
                data = text.encode("utf-8")
            elif info.filename == sis_name and schedule is not None:
                at_time, enabled = schedule
                schedule_id, point_id = _new_id(ae_mrid + "schedule"), _new_id(ae_mrid + "point")
                text = data.decode("utf-8").replace("</rdf:RDF>", (
                    f'<nc:AssessedElementSchedule rdf:ID="_{schedule_id}">\n'
                    f'  <nc:AssessedElementSchedule.AssessedElement rdf:resource="#_{ae_mrid}"/>\n'
                    f'  <nc:BaseTimeSeries.interpolationKind rdf:resource="{NC}TimeSeriesInterpolationKind.none"/>\n'
                    "</nc:AssessedElementSchedule>\n"
                    f'<nc:AssessedElementTimePoint rdf:ID="_{point_id}">\n'
                    f'  <nc:AssessedElementTimePoint.AssessedElementSchedule rdf:resource="#_{schedule_id}"/>\n'
                    f"  <nc:AssessedElementTimePoint.atTime>{at_time}</nc:AssessedElementTimePoint.atTime>\n"
                    f"  <nc:AssessedElementTimePoint.enabled>{str(enabled).lower()}</nc:AssessedElementTimePoint.enabled>\n"
                    "</nc:AssessedElementTimePoint>\n</rdf:RDF>"))
                data = text.encode("utf-8")
            out.writestr(fixed_entry(info.filename), data)
    return out_zip
