﻿"""One golden-matrix run: python mock_data/golden/run_case.py CASE OUTROOT  (CASE = input__mode__ratypes__nx0|nx1).

input: mock (the standard-form P), mockpruned (the same with the N-X pruning thresholds at 0.02 %, DECISIONS 142), generic (the official sample), ct, hvdc, cthvdc (the mock builders of mock_data).
The run happens in a temporary folder; the output files are copied to OUTROOT/CASE."""
import os, sys, shutil, pathlib, tempfile
repo = pathlib.Path(__file__).resolve().parents[2]
sys.path[:0] = [str(repo / "tests"), str(repo / "src" / "rao"), str(repo)]
import helpers
from mock_data import ct_mock, hvdc_mock
case, outroot = sys.argv[1], pathlib.Path(sys.argv[2])
inp, mode, ras, nx = case.split("__")
work = pathlib.Path(tempfile.mkdtemp(prefix="gm_"))
zips = {
    "mock": helpers._MOCK_NX_NCP_ZIP,
    "mockpruned": helpers._MOCK_NX_NCP_ZIP,
    "generic": helpers.FIXTURE_NCP_GENERIC_ZIP,
    "ct": lambda: ct_mock.build_ct_mock_ncp(work / "ct.zip"),
    "hvdc": lambda: hvdc_mock.build_hvdc_mock_ncp(work / "hvdc.zip"),
    "cthvdc": lambda: ct_mock.build_ct_and_hvdc_mock_ncp(work / "cthvdc.zip"),
}
z = zips[inp]
z = z() if callable(z) else z
def prune(rp, monkeypatch):
    monkeypatch.setattr(rp, "SENSITIVITY_THRESHOLD_PCT_PST_NX", 0.02)
    monkeypatch.setattr(rp, "SENSITIVITY_THRESHOLD_PCT_RD_NX", 0.02)


res = helpers.run_pipeline_on_fixture_inputs(work, z, enable_nx_analysis=(nx == "nx1"), ra_types=tuple(ras.split("+")), calculation_mode=mode,
                                             customize_pipeline=prune if inp == "mockpruned" else None)
dest = outroot / case
if dest.exists():
    shutil.rmtree(dest)
shutil.copytree(res.output_dir, dest)
print("done", case, len(list(dest.iterdir())), "files")
