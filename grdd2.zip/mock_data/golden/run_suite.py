﻿"""The test suite in parallel by file: python mock_data/golden/run_suite.py OUTDIR WORKERS"""
import subprocess, sys, pathlib, time, re, concurrent.futures as cf
repo = pathlib.Path(__file__).resolve().parents[2]
out = pathlib.Path(sys.argv[1]); out.mkdir(parents=True, exist_ok=True)
files = sorted((repo / "tests").glob("test_rao_*.py"))
def run(f):
    t = time.time()
    p = subprocess.run([sys.executable, "-m", "pytest", str(f), "-q", "-p", "no:cacheprovider", "--basetemp", str(out / ("tmp_" + f.stem))],
                       cwd=repo, capture_output=True, text=True, encoding="utf-8", errors="replace")
    (out / (f.stem + ".log")).write_text(p.stdout + p.stderr, encoding="utf-8")
    last = [l for l in p.stdout.strip().splitlines() if l.strip()][-1] if p.stdout.strip() else "no output"
    return f.name, p.returncode, last, round(time.time() - t)
tot = {"passed": 0, "failed": 0, "skipped": 0, "xfailed": 0, "error": 0}
with cf.ThreadPoolExecutor(int(sys.argv[2])) as ex:
    for name, rc, last, secs in ex.map(run, files):
        print(f"{name:55} rc={rc} {secs:4}s  {last}", flush=True)
        for k in tot:
            m = re.search(r"(\d+) " + k, last)
            if m: tot[k] += int(m.group(1))
print("TOTAL", tot, "files", len(files))
