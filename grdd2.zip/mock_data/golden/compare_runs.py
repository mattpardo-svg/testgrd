"""Compare two matrix output roots with the rule of Next_Steps section 3.2."""
import sys, pathlib, csv, math, re
a_root, b_root = map(pathlib.Path, sys.argv[1:3])
TOL = 1e-9
INTEGER = re.compile(r"[+-]?\d+")   # a count, a status code, a tap position: exact (DECISIONS 112)
def num(x):
    try: return float(x)
    except: return None
tot = {"cases": 0, "files": 0, "cells": 0, "diff": 0, "byte_identical": 0}
problems = []
for case in sorted(p.name for p in a_root.iterdir() if p.is_dir()):
    if not (b_root / case).is_dir():
        problems.append((case, "missing in B")); continue
    tot["cases"] += 1
    names = sorted({p.name for p in (a_root / case).iterdir()} | {p.name for p in (b_root / case).iterdir()})
    for name in names:
        if name == "run_log.txt": continue
        fa, fb = a_root / case / name, b_root / case / name
        if not fa.exists() or not fb.exists():
            problems.append((case, name, "file missing")); continue
        tot["files"] += 1
        if fa.read_bytes() == fb.read_bytes():
            tot["byte_identical"] += 1; continue
        if fa.suffix != ".csv":
            problems.append((case, name, "non-csv differs")); continue
        ra, rb = list(csv.reader(fa.open(encoding="utf-8"))), list(csv.reader(fb.open(encoding="utf-8")))
        if len(ra) != len(rb) or (ra and ra[0] != rb[0]):
            problems.append((case, name, "shape/header")); continue
        header = ra[0] if ra else []
        colmax = {}
        for j, h in enumerate(header):
            vals = [abs(num(r[j])) for r in ra[1:] if j < len(r) and num(r[j]) is not None and math.isfinite(num(r[j]))]
            colmax[j] = max(vals) if vals else 0.0
        worst = 0.0
        for i in range(1, len(ra)):
            for j, (x, y) in enumerate(zip(ra[i], rb[i])):
                if header[j].startswith("seconds_"): continue
                tot["cells"] += 1
                if x == y: continue
                if INTEGER.fullmatch(x) and INTEGER.fullmatch(y):
                    tot["diff"] += 1; problems.append((case, name, f"count {header[j]} row {i}")); continue
                nx_, ny = num(x), num(y)
                if nx_ is None or ny is None:
                    tot["diff"] += 1; problems.append((case, name, f"text {header[j]} row {i}")); continue
                d = abs(nx_ - ny)
                if abs(nx_) <= 1e-9 and abs(ny) <= 1e-9: continue
                if d <= TOL * max(abs(nx_), abs(ny)) or d <= TOL * colmax[j] or (header[j].endswith("_model_diff_pct") and d <= 1e-6): continue
                if header[j].startswith("last_solve_") and d <= 1e-6: continue       # diagnostic of the last solve: solver tolerance
                tot["diff"] += 1; worst = max(worst, d / max(abs(nx_), abs(ny), 1e-300))
                problems.append((case, name, f"num {header[j]} row {i} rel {d/max(abs(nx_),abs(ny),1e-300):.2e}"))
print(tot)
for p in problems[:40]: print(p)
print("problems", len(problems))

