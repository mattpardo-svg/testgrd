"""Wall time and peak memory of golden-matrix runs: python mock_data/golden/timing.py [--repeat N] CASE [CASE ...]

Each run is run_case.py in its own process (PYTHONHASHSEED=0, outputs in a temporary folder that is removed). The
peak memory is the peak working set of that process, read at its end with the Windows API (ctypes); on other
systems only the time is reported. Prints one line per case: best and all wall times in seconds, peak memory in MB."""
import os, sys, time, shutil, tempfile, subprocess, pathlib

here = pathlib.Path(__file__).resolve().parent
repo = here.parents[1]


CHILD = """
import runpy, sys, ctypes, os
from ctypes import wintypes
sys.argv = [sys.argv[1], sys.argv[2], sys.argv[3]]
runpy.run_path(sys.argv[0], run_name="__main__")
if os.name == "nt":
    class C(ctypes.Structure):
        _fields_ = [("cb", wintypes.DWORD), ("PageFaultCount", wintypes.DWORD), ("PeakWorkingSetSize", ctypes.c_size_t),
                    ("WorkingSetSize", ctypes.c_size_t), ("a", ctypes.c_size_t), ("b", ctypes.c_size_t), ("c", ctypes.c_size_t),
                    ("d", ctypes.c_size_t), ("PagefileUsage", ctypes.c_size_t), ("PeakPagefileUsage", ctypes.c_size_t)]
    c = C(); c.cb = ctypes.sizeof(c)
    ctypes.windll.kernel32.GetCurrentProcess.restype = ctypes.c_void_p
    ctypes.windll.psapi.GetProcessMemoryInfo.argtypes = [ctypes.c_void_p, ctypes.c_void_p, wintypes.DWORD]
    ctypes.windll.psapi.GetProcessMemoryInfo(ctypes.windll.kernel32.GetCurrentProcess(), ctypes.byref(c), c.cb)
    print("PEAK_MB", c.PeakWorkingSetSize / 1e6)
"""


def measure(case: str) -> tuple[float, float]:
    out = pathlib.Path(tempfile.mkdtemp(prefix="timing_"))
    env = dict(os.environ, PYTHONHASHSEED="0")
    start = time.time()
    done = subprocess.run([sys.executable, "-c", CHILD, str(here / "run_case.py"), case, str(out)], cwd=repo, env=env,
                          capture_output=True, text=True, encoding="utf-8", errors="replace")
    seconds = time.time() - start
    shutil.rmtree(out, ignore_errors=True)
    if done.returncode:
        raise SystemExit(f"{case}: run failed (exit code {done.returncode}): {done.stderr[-500:]}")
    peak = [float(line.split()[1]) for line in done.stdout.splitlines() if line.startswith("PEAK_MB")]
    return seconds, peak[-1] if peak else 0.0


if __name__ == "__main__":
    args = sys.argv[1:]
    repeat = 1
    if args[:1] == ["--repeat"]:
        repeat, args = int(args[1]), args[2:]
    for case in args:
        runs = [measure(case) for _ in range(repeat)]
        times = [round(t, 1) for t, _ in runs]
        print(f"{case}: best {min(times)} s (all {times}), peak memory {max(m for _, m in runs):.0f} MB", flush=True)
