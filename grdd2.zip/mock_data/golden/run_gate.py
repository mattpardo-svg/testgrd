﻿"""The gate: python mock_data/golden/run_gate.py OUTDIR TAG SECTIONS [BASELINE_DIR ...]

1. the test suite in parallel by file (run_suite.py, 4 workers)
2. the 52-run golden matrix (run_matrix.py, 5 workers) into OUTDIR/mx_TAG
3. the matrix against each BASELINE_DIR (compare_runs.py); without a BASELINE_DIR the stored golden/baseline.zip is
   extracted to OUTDIR/baseline and used
4. the MILP fingerprints of the mock converted with SECTIONS ('none' = the shipped mock as it is)
5. the link check of the documentation (mock_data/tools/check_doc_links.py: 0 dead links in live files; history files and a small
   whitelist are exempt); a dead link makes the gate fail (report line LINKS DEAD, exit code 1)
The report is written to OUTDIR/gate_TAG.txt (it ends with GATE DONE)."""
import subprocess, sys, os, pathlib, zipfile
here = pathlib.Path(__file__).resolve().parent
repo = here.parents[1]
out_dir = pathlib.Path(sys.argv[1]); tag = sys.argv[2]; sections = sys.argv[3]
baselines = [pathlib.Path(p) for p in sys.argv[4:]]
out_dir.mkdir(parents=True, exist_ok=True)
if not baselines:
    target = out_dir / "baseline"
    if not target.exists():
        with zipfile.ZipFile(here / "baseline.zip") as zf:
            zf.extractall(target)
    baselines = [target]
env = dict(os.environ, PYTHONHASHSEED="0")
out = open(out_dir / f"gate_{tag}.txt", "w", encoding="utf-8")
def run(args, label):
    p = subprocess.run([sys.executable] + args, capture_output=True, text=True, encoding="utf-8", errors="replace", env=env, cwd=repo)
    out.write(f"=== {label}\n{p.stdout}\n{p.stderr[-1500:] if p.returncode else ''}\n"); out.flush()
    return p
run([str(here / "run_suite.py"), str(out_dir / f"suite_{tag}"), "4"], "suite")
run([str(here / "run_matrix.py"), str(out_dir / f"mx_{tag}"), "5"], "matrix runs")
for number, baseline in enumerate(baselines, 1):
    run([str(here / "compare_runs.py"), str(baseline), str(out_dir / f"mx_{tag}")], f"matrix vs baseline {number} ({baseline.name})")
run([str(here / "fp_check.py"), sections], f"fingerprints {sections}")
links = run([str(repo / "mock_data" / "tools" / "check_doc_links.py"), "--live-only"], "link check")
out.write("LINKS OK\n" if links.returncode == 0 else "LINKS DEAD\n")
out.write("GATE DONE\n"); out.close()
sys.exit(links.returncode)
