﻿"""The 52-run golden matrix: python mock_data/golden/run_matrix.py OUTROOT WORKERS [ONLY]
8 input/ra_types combinations x 3 calculation modes x N-X off/on = 48 cases, plus 4 cases with the N-X pruning thresholds at
0.02 % (input mockpruned, N-X on, ac_iterative and dc, pst+rd and pst+rd+countertrade); each run by run_case.py in its own process.
ONLY: run only the cases whose name contains this text (e.g. countertrade)."""
import subprocess, sys, pathlib, os, time, concurrent.futures as cf
here = pathlib.Path(__file__).resolve().parent
repo = here.parents[1]
root = pathlib.Path(sys.argv[1]); workers = int(sys.argv[2])
combos = [("mock","pst+rd"),("mock","rd"),("generic","pst+rd"),("ct","countertrade"),("ct","countertrade+rd"),("hvdc","hvdc"),("cthvdc","countertrade+hvdc"),
          ("mock","pst+rd+countertrade")]      # the shipped mock with its 8 countertrade RAs switched on
cases = [f"{i}__{m}__{r}__nx{n}" for i, r in combos for m in ("ac_iterative","ac_single_pass","dc") for n in (0,1)]
assert len(cases) == 48
cases += [f"mockpruned__{m}__{r}__nx1" for r in ("pst+rd", "pst+rd+countertrade") for m in ("ac_iterative", "dc")]
assert len(cases) == 52
if len(sys.argv) > 3:
    cases = [c for c in cases if sys.argv[3] in c]
env = dict(os.environ, PYTHONHASHSEED="0")
def run(c):
    t = time.time()
    p = subprocess.run([sys.executable, str(here / "run_case.py"), c, str(root)],
                       capture_output=True, text=True, encoding="utf-8", errors="replace", env=env, cwd=repo)
    return c, p.returncode, round(time.time() - t), (p.stdout.strip().splitlines() or [""])[-1], p.stderr.strip().splitlines()[-1:]
with cf.ThreadPoolExecutor(workers) as ex:
    for r in ex.map(run, cases):
        print(*r, flush=True)
