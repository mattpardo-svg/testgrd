"""countertrade_p.py - the countertrade RAs and bids that the shipped standard-form mock carries.

Per region (Belgovia, Espheim, Galia, Svedala) one preventive and one curative nc:CountertradeRemedialAction in the
standard form of the profile (bidding zone, kind, availability, penaltyFactor; no strategy, powerShiftKey or method
attribute: the profile has none). The curative RA is linked (combinationConstraintKind included) to every
contingency of the region's CO file. Bids are nc:PowerBidSchedule of the RA with one time point at the run time stamp:
direction literal, p > 0 for up and p < 0 for down (size |p|), price in EUR/MW. Espheim has a supply function of three
up and three down bids per RA (100 MW each at 40 / 70 / 110 EUR/MW), the other regions one up and one down bid of
100 MW. The code reads no shift key of a countertrade bid (the units and weights of a zone come from its control areas,
docs/specs/countertrade_ra_specs.md C3), so none is written. Ids are deterministic."""
from __future__ import annotations

import re
import uuid

ENUM = "https://cim4.eu/ns/nc#"
CIM_CURRENCY = "https://cim.ucaiug.io/ns#Currency.EUR"
RUN_TIME = "2022-06-15T10:30:00Z"
_NAMESPACE = uuid.UUID("0b6f6a6c-1d10-4e47-9a53-5c1f3b1e9d2a")

# TSO -> (bidding zone mRID of Org-NineRealms_CD.xml, [(volume MW, price EUR/MW), ...] of each direction)
REGIONS = {
    "Belgovia": ("87fb9f56-fd86-446f-b35d-c0abba19925f", [(100, 50)]),
    "Espheim": ("cf8a8cc9-4b94-4983-8a36-e3f84888f461", [(100, 40), (100, 70), (100, 110)]),
    "Galia": ("4d4166a4-c0dc-4c77-9b67-a04a7e68ddf2", [(100, 50)]),
    "Svedala": ("f8d26efa-aaaf-49d2-97f8-24de7660047b", [(100, 60)]),
}
CONTINGENCY_COUNTS = {"Belgovia": 2, "Espheim": 5, "Galia": 1, "Svedala": 8}


def _uid(*parts) -> str:
    return str(uuid.uuid5(_NAMESPACE, "/".join(str(p) for p in parts)))


def ra_name(tso: str, kind: str) -> str:
    return f"{'PRA' if kind == 'preventive' else 'CRA'}_CT_{tso.upper()}"


def ra_mrid(tso: str, kind: str) -> str:
    return _uid("ct ra", ra_name(tso, kind))


def contingencies_of(co_text: str) -> list[str]:
    """The mRIDs of the contingencies of a CO file, in file order."""
    return re.findall(r'<nc:(?:Ordinary|Exceptional|OutOfRange)Contingency rdf:ID="_([^"]+)"', co_text)


def _ra_xml(tso: str, kind: str, zone: str, contingencies: list[str]) -> str:
    name, mrid = ra_name(tso, kind), ra_mrid(tso, kind)
    parts = [f"""  <nc:CountertradeRemedialAction rdf:ID="_{mrid}">
    <nc:PowerRemedialAction.BiddingZone rdf:resource="#_{zone}" />
    <cim:IdentifiedObject.description>Mocked {kind} countertrade RA of {tso}.</cim:IdentifiedObject.description>
    <cim:IdentifiedObject.mRID>{mrid}</cim:IdentifiedObject.mRID>
    <cim:IdentifiedObject.name>{name}</cim:IdentifiedObject.name>
    <nc:RemedialAction.isCrossBorderRelevant>true</nc:RemedialAction.isCrossBorderRelevant>
    <nc:RemedialAction.kind rdf:resource="{ENUM}RemedialActionKind.{kind}" />
    <nc:RemedialAction.normalAvailable>true</nc:RemedialAction.normalAvailable>
    <nc:RemedialAction.penaltyFactor>1.0</nc:RemedialAction.penaltyFactor>
  </nc:CountertradeRemedialAction>"""]
    for contingency in contingencies:
        link = _uid("ct link", name, contingency)
        parts.append(f"""  <nc:ContingencyWithRemedialAction rdf:ID="_{link}">
    <nc:ContingencyWithRemedialAction.Contingency rdf:resource="#_{contingency}" />
    <nc:ContingencyWithRemedialAction.RemedialAction rdf:resource="#_{mrid}" />
    <nc:ContingencyWithRemedialAction.combinationConstraintKind rdf:resource="{ENUM}ElementCombinationConstraintKind.included" />
    <nc:ContingencyWithRemedialAction.mRID>{link}</nc:ContingencyWithRemedialAction.mRID>
  </nc:ContingencyWithRemedialAction>""")
    return "\n".join(parts)


def _bids_xml(tso: str, kind: str, bids: list[tuple[int, int]]) -> str:
    name, mrid = ra_name(tso, kind), ra_mrid(tso, kind)
    parts = []
    for direction, sign in (("up", 1), ("down", -1)):
        for number, (volume, price) in enumerate(bids, 1):
            bid_name = f"PB_{name}_{direction.upper()}_{number}"
            bid = _uid("ct bid", bid_name)
            point = _uid("ct bid point", bid_name)
            parts.append(f"""  <nc:PowerBidSchedule rdf:ID="_{bid}">
    <cim:IdentifiedObject.description>Mocked {direction}ward countertrade bid {number} for {name}.</cim:IdentifiedObject.description>
    <cim:IdentifiedObject.mRID>{bid}</cim:IdentifiedObject.mRID>
    <cim:IdentifiedObject.name>{bid_name}</cim:IdentifiedObject.name>
    <nc:PowerBidSchedule.PowerRemedialAction rdf:resource="#_{mrid}" />
    <nc:PowerBidSchedule.currency rdf:resource="{CIM_CURRENCY}" />
    <nc:PowerBidSchedule.direction rdf:resource="{ENUM}MarketRegulationDirectionKind.{direction}" />
    <nc:PowerBidSchedule.leadTime>P0Y0M0DT0H0M0S</nc:PowerBidSchedule.leadTime>
    <nc:PowerBidSchedule.activationCost>0</nc:PowerBidSchedule.activationCost>
    <nc:PowerBidSchedule.priority>1</nc:PowerBidSchedule.priority>
    <nc:BaseTimeSeries.interpolationKind rdf:resource="{ENUM}TimeSeriesInterpolationKind.next" />
  </nc:PowerBidSchedule>

  <nc:PowerBidScheduleTimePoint rdf:ID="_{point}">
    <nc:PowerBidScheduleTimePoint.atTime>{RUN_TIME}</nc:PowerBidScheduleTimePoint.atTime>
    <nc:PowerBidScheduleTimePoint.PowerBidSchedule rdf:resource="#_{bid}" />
    <nc:PowerBidScheduleTimePoint.p>{sign * volume}</nc:PowerBidScheduleTimePoint.p>
    <nc:PowerBidScheduleTimePoint.price>{price}</nc:PowerBidScheduleTimePoint.price>
  </nc:PowerBidScheduleTimePoint>""")
    return "\n\n".join(parts)


def _append(data: bytes, block: str) -> bytes:
    text = data.decode("utf-8")
    end = text.rindex("</rdf:RDF>")
    return (text[:end].rstrip("\n") + "\n\n" + block + "\n" + text[end:]).encode("utf-8")


def add_countertrade(files: dict) -> dict:
    """The NCP files {name: bytes} of the standard-form mock with the countertrade RAs and bids of every region
    appended to its RA and SIS file (a new dict; the input is not changed)."""
    result = dict(files)
    for tso, (zone, bids) in REGIONS.items():
        contingencies = contingencies_of(files[f"{tso}_CO.xml"].decode("utf-8"))
        if len(contingencies) != CONTINGENCY_COUNTS[tso]:
            raise ValueError(f"{tso}_CO.xml has {len(contingencies)} contingencies, expected {CONTINGENCY_COUNTS[tso]}")
        result[f"{tso}_RA.xml"] = _append(result[f"{tso}_RA.xml"], "\n".join(
            _ra_xml(tso, kind, zone, contingencies if kind == "curative" else []) for kind in ("preventive", "curative")))
        result[f"{tso}_SIS.xml"] = _append(result[f"{tso}_SIS.xml"], "\n\n".join(
            _bids_xml(tso, kind, bids) for kind in ("preventive", "curative")))
    return result
