# mock_data

Generators of the mock and test data of the RAO prototype, and the scripts that check a change against the golden runs. Generators only: nothing in `src/` imports this folder (the GUI never does), and no real data is ever put here.

## Content

| Path | What |
|---|---|
| `paths.py` | Where the data files are and what they are called (the one place to rename a zip). Imports nothing but `pathlib`. |
| `convert_ncp_to_standard.py` | Converter: old-form mock NCP zip to the standard form (RemedialAction 2.5, StateInstructionSchedule 2.5); has its own command line. |
| `standard.py` | The standard-form mock. `base_zip()` / `build_base()`: the legacy mock converted by the converter, without countertrade; the builders below start from it. `build_standard()`: the shipped mock = base plus the 8 countertrade RAs. |
| `countertrade_p.py` | The countertrade RAs and bids of the shipped mock (a preventive and a curative RA per region; Espheim with three bids per direction). |
| `hvdc_mock.py`, `ct_mock.py` | Mock NCPs of the HVDC and countertrade tests, built on top of the base of the standard mock. |
| `ncp_dataset.py` | The NCP test dataset (valid package, invalid and warning variants, data rules) and the shared-bid redispatch cases. |
| `zipio.py` | Zip helper: entries with fixed time stamps, so equal input gives equal bytes. |
| `cli.py`, `__main__.py` | The command line, `python -m mock_data`. |
| `golden/` | Golden matrix (52 runs of `run_pipeline.main()`, among them the mock with its countertrade RAs on, `pst+rd+countertrade`, and 4 runs of the mock with the N-X pruning thresholds at 0.02 %, `mockpruned`), the comparison rule of `docs/Next_Steps.md` section 3 rule 2, the suite in parallel by file, the fingerprint check and the gate; see `golden/README.md`. |
| `tools/inventory_p.py` | Inventory (markdown and CSV) of the PST and RD RAs, bids and generators of the standard mock. |
| `tools/gitc.py` | Local commits without a git executable (dulwich). |

## Commands (from the repo root)

```
python -m mock_data standard [--out PATH]       write the standard-form mock (default: the fixture path)
python -m mock_data check                        SHA-256 of the fixture zips; standard = converter(legacy); copies in input/
python -m mock_data variant ct|hvdc|cthvdc|dataset OUT.zip
python -m mock_data dataset-variant --list       names of the invalid / warning variants
python -m mock_data dataset-variant NAME OUT.zip
python -m mock_data shared-bid CASE OUT.zip      A, A_strategy, B_preventive, C_preventive, D_espheim
python -m mock_data install-input [--input-dir D] [--force]
python -m mock_data inventory-p [--out-dir D]    default D = docs/
```
`install-input` copies the CGM zip and the standard mock (the old pair) into `input/`; `input/` itself now holds the HVDC pair (`CGM_package_hvdc.zip`, `NCP_mock_hvdc.zip`), so `install-input` stops there until those two are moved out (the old pair is also in `input_old/`). The pipeline needs exactly one `cgm*.zip` and one `ncp*.zip` there, so it stops (nothing written) when another zip with such a prefix is present; a file of the same name with other content is replaced only with `--force`.

The golden matrix, the baseline, the comparison rule, the gate (`python mock_data/golden/run_gate.py OUTDIR TAG none`, about 25 minutes, with the link check of the docs as its last step) and the timing script are described in `golden/README.md`.

## Files in `tests/fixtures/` and `input/`

Set in `paths.py`: `CGM_package.zip`, `NCP_mock_standard.zip` (the shipped standard mock), `NCP_mock_legacy.zip` (old form, source of the converter), `NCP_sample_generic_2_4.zip` (official sample, profile 2.4), `milp_model_fingerprints.json`. `input/` holds the HVDC pair `CGM_package_hvdc.zip` and `NCP_mock_hvdc.zip`; `input_old/` holds `CGM_package.zip` and a copy of `NCP_mock_standard.zip` (what `install-input` writes); no test reads `input/`.

## Rules

- The zips written here are byte-stable (fixed zip time stamps, deterministic mRIDs). The byte-equality test `test_rao_the_shipped_mock_is_the_generated_standard_mock` guards the standard mock.
- The sample zips (the CGM and the generic NCP sample) are official and never changed; the legacy mock is hand-made and cannot be regenerated.
- A generator never imports a test file; tests import generators with `from mock_data import ...`.

## Adding a variant

Write the builder next to the others (copy the standard mock, change what the variant is about, write with `zipio.fixed_entry`), add a command or a case name to `cli.py`, add a test, and add the row to `docs/data/ncp_dataset_coverage.md`.
