"""
ncp_dataset.py — the generated NCP test dataset that covers the rows of docs/data/ncp_data_requirements.md
(docs/data/ncp_dataset_coverage.md maps every row to its data and its test).

build_valid_ncp(dest) builds one valid package for tests/fixtures/CGM_package.zip, in three steps:
  1. hvdc_mock: the preventive HVDC pair and a curative pair (one curative unit with a range below its set point,
     which is widened), the PATL of TieLine_SD-EH1 and a contingency that trips the EquivalentInjection of a unit;
  2. ct_mock on top: countertrade RAs for BZ-Belgovia and BZ-Galia (preventive and curative, penaltyFactor 0,
     above 0 and missing), the PATL of the Belgovia half of TieLine_GA_BO4, the outage of TieLine_GA_BO5 and a
     restrictive group with RD and countertrade members;
  3. patches of this module (DATASET_EDITS): assessed elements for every classification and PATL source,
     contingencies for every equipment type the loader maps (and one it does not, one that is not must-study,
     one that trips a PST of its curative group), PST groups and a curative range, availability and timing
     variants, extra RD bids (several per RA, lead time, time-point activation cost, reservation price), a GLSK
     over several units, unit costs in SIS and ER.
build_variant_ncp(dest, case) builds the invalid and warning variants of VARIANTS: each is the valid package with
one change. check_data_rules(zip) returns the violations of the dataset's data rules (empty for a valid build).
Every mRID the package refers to is an object of CGM_package.zip or of the package itself; no real data.
"""
import io
import re
import uuid
import zipfile
from pathlib import Path

from . import ct_mock, hvdc_mock
from .standard import base_zip
from .zipio import fixed_entry as _fixed_entry

ENUM = "https://cim4.eu/ns/nc#"
CIM_NS = "https://cim.ucaiug.io/ns#"
RUN_TIME = ct_mock.RUN_TIME
REGION = "56d81c91-4fb8-47a2-9d7c-baa13dedd605"       # the SecuredForRegion / ScannedForRegion of the base AE files


def _uid(*parts):
    """A deterministic id for a generated element."""
    return str(uuid.uuid5(uuid.NAMESPACE_URL, "ncp-dataset/" + "/".join(str(p) for p in parts)))


# ---------------------------------------------------------------------------
# objects of CGM_package.zip (pypowsybl ids = CGMES mRIDs)
# ---------------------------------------------------------------------------

# branches without a CGM TATL (the classification and PATL-source elements)
EH_LINE1 = "bb8787ff-96b9-4618-85d5-d1bcad51337f"                 # Espheim, about 440 A
EH_LINE1_LIMIT = "24e22dc0-1290-e64f-c896-49e4938e8f9d"           # its CurrentLimit, side 1, 1000 A
LINE_EH_SD4 = "2dcdd195-4893-42e0-b4d7-36d7e32e669a"              # Espheim, about 767 A
TIE_EH_SD2 = "a04e4e41-c0b4-496e-9ef3-390ea089411f"               # Espheim half, about 387 A
TIE_EH_HVDC = "6dbe5760-eb4c-4d0d-bcff-fba0f26f5cff"              # Espheim, about 774 A
TIE_GA_HVDC_BH = "8d5bb92f-4938-4027-9322-f1b502b28fbe"           # Galia, about 188 A
TIE_GA_HVDC_NH = "1ea986bc-7cb9-4efb-b524-69c5dc1372bc"           # Galia, about 417 A
SER_RLC = "df16b3dd-c905-4a6f-84ee-f067be86f5da"                  # Belgovia, about 57 A
SER_RLC_LIMIT = "9bb79911-0692-a888-e3d7-b141c3e8e8c1"            # its CurrentLimit (EQ), side 1, CGM PATL 500 A
SER_RLC_CGM_PATL_A = 500.0
TIE_SD_HVDC = "7b858bec-17c8-4cab-bfcb-6bbd645af2db"              # Svedala, about 776 A
# contingency equipment: one per type of cgmes_loader.build_equipment_mrid_to_type that the base package lacks
BREAKER_BO = "925a3a38-cd26-4f89-8891-c5bc8494e1ae"               # switch CIRCB-1230991526 (Belgovia)
SVC_BO = "3c69652c-ff14-4550-9a87-b6fdaccbb5f4"                   # staticVarCompensator SVC-1230797516 (Belgovia)
BUSBAR_BO = "0666f326-3c55-8bd6-da2b-027fc9b6676a"                # busbar N1230992288 (Belgovia)
DC_LINE_EH_SD = "be09fc02-de3f-49e4-aa84-94803bcc5d76"            # an HVDC line: not a mapped equipment type
LINE_25_27 = "048481d0-c766-11e1-8775-005056c00008"               # Espheim line 25-27 (outage of CO2 too)
BO_TR2_1 = "a708c3bc-465d-4fe7-b6ef-6fa6408a62b0"                 # PST transformer BO-TR2_1
# tap changers (EQ) of the PSTs
TC_BO_TR2_1, TC_BO_TR2_2 = "8058f222-a4c2-e7b9-abf2-bfe4cf13bc02", "e3c6a976-734e-cd25-ba99-925c00aa1223"
TC_RATIO_BO_TR2_3 = "82b23827-3189-4a7f-b283-0ed5733a9e64"        # a RatioTapChanger (not a PST)
# generators and their CGMES GeneratingUnits (Svedala)
STORFORS_G1, STORFORS_G1_UNIT = "9cfd2812-b0d8-4dff-9c7f-a04b911a85c8", "5860f607-e1bc-fffe-08d3-8848d517d58f"
STENFORSEN_G1, STENFORSEN_G1_UNIT = "cf9bf157-9b80-48be-aaf6-7368966d74bd", "7ec185f6-e72f-cb53-d4b0-7899558f8061"
KARNAN_G3 = "f4cde1f4-51c6-446b-8f1f-3e6835a8df6f"                 # not connected in the CGM
GA_G1 = ct_mock.GA_G1

# the CGM TATL (A) of the branches whose PATL this module or the mocks write; None: the CGM has no TATL there
CGM_TATL_A = {
    ct_mock.BRANCH_GA_BO4_BELGOVIA: 500.0, hvdc_mock.XNE_BRANCH: None, EH_LINE1: None, LINE_EH_SD4: None,
    TIE_EH_SD2: None, TIE_EH_HVDC: None, TIE_GA_HVDC_BH: None, TIE_GA_HVDC_NH: None, SER_RLC: None, TIE_SD_HVDC: None,
}
# usable countertrade units per zone (connected, main component, bounded limits; ct_mock facts)
CT_ZONE_UNITS = {ct_mock.ZONE_BELGOVIA: (ct_mock.BO_G1, ct_mock.BO_G2), ct_mock.ZONE_GALIA: (ct_mock.GA_G1, ct_mock.GA_G2, ct_mock.GA_G3)}

# ---------------------------------------------------------------------------
# objects of the base package (NCP_mock_standard.zip) the dataset changes
# ---------------------------------------------------------------------------

PRA_PST_BO_TR2_1, PRA_PST_BO_TR2_2 = "ca0064b9-f037-58e5-96e2-4e3d632b3f22", "e7438a6e-89f6-51a6-88f6-f44b1cdd5490"
CRA_PST_BO_TR2_1, CRA_PST_BO_TR2_2 = "a3169960-996a-5838-8372-307036b7cf0f", "8cb4ebb9-7ede-5bb6-b45c-47445b87fb68"
PRA_PST_AAC, CRA_PST_AAC = "64817939-33a6-5ce0-a754-8f84768d72b3", "424db5b8-dd9f-500b-83ef-e365b2a6cbfc"
CRA_PST_AAA1 = "f7693938-7a8a-5e31-a8d7-64c45487dde9"
PRA_PST_GA_TR2_1, PRA_PST_GA_TR2_2 = "6fb7ac93-287a-56aa-93f1-a6c22a1c19f9", "f313478c-6b71-595c-8e52-16c5892d540d"
CRA_PST_GA_TR2_2 = "ea8a628a-97c6-5d5a-acfc-707d6a653e25"
PRA_RD_BO_G1_UP, PRA_RD_BO_G2_UP = "c3fac5d0-afef-5d6b-a34f-cc8002bc6f31", "203df9f2-582a-5120-b679-32c35090217d"
PRA_RD_GA_G1_UP, CRA_RD_GA_G1_UP = "2e3d5162-ad8f-52dd-a236-41cd607f6c64", "b0ca260f-dae2-5893-a9a2-1a91bf719011"
BELGOVIA_CO3 = ct_mock.CONTINGENCY_BELGOVIA_CO3          # linked to CRA_PST_BO_TR2_1 and _2 in the base package

# ---------------------------------------------------------------------------
# objects the dataset adds
# ---------------------------------------------------------------------------

PST_GROUP_PRA = _uid("ra", "PRA_PST_BO_GROUP")
PST_GROUP_CRA = _uid("ra", "CRA_PST_BO_GROUP")
CO_BO_TR2_1_OUT = _uid("contingency", "BO-TR2_1 outage")          # trips a member of the curative PST group
CO_SWITCH = _uid("contingency", "breaker outage")
CO_SVC = _uid("contingency", "SVC outage")
CO_BUSBAR = _uid("contingency", "busbar outage")                  # normalMustStudy false
CO_DC_LINE = _uid("contingency", "DC line outage")                # unmappable equipment
CO_NOT_STUDIED = _uid("contingency", "line 25-27, not studied")   # normalMustStudy false
RD_MULTI_GLSK = _uid("ra", "PRA_RD_SV_MULTI")
GA_G1_SECOND_BID = _uid("bid", "GA-G1 up, second bid")
GA_G1_LEAD_TIME_BID = _uid("bid", "GA-G1 up, lead time")
GA_G1_CURATIVE_RESERVE_BID = _uid("bid", "GA-G1 curative up, reserve price")
RD_GROUP = ct_mock.group("RD and CT", [{"mrid": PRA_RD_BO_G1_UP}, {"mrid": PRA_RD_BO_G2_UP}], max_up=80.0, max_down=120.0)
AAC_RANGE_UP, AAC_RANGE_DOWN = 5, -5                              # the curative range of PST Aac (tap 0 in the CGM)
FAST_REACTION, SLOW_REACTION = "PT1M", "PT15M"                     # against the TATL duration of 10 minutes
CURATIVE_REACTION = "PT5M"

# assessed elements: (key, TSO, branch, branch predicate, OperationalLimit, BaseCaseCurrentLimit A or None,
# secured, scanned, exclusionReason token or None)
# (the BaseCaseCurrentLimit values differ from the CGM PATL of the branch, so the source of a PATL is visible)
AE_SPECS = [
    ("secured+scanned", "Espheim", EH_LINE1, "ConductingEquipment", EH_LINE1_LIMIT, 950.0, True, True, None),
    ("scanned+systemOperator", "Espheim", LINE_EH_SD4, "ConductingEquipment", _uid("limit", LINE_EH_SD4), 950.0, False, True, "systemOperator"),
    ("all three, capacityCalculationRegion", "Espheim", TIE_EH_SD2, "ConductingEquipment", _uid("limit", TIE_EH_SD2), 950.0, True, True, "capacityCalculationRegion"),
    ("secured+nonNative", "Espheim", TIE_EH_HVDC, "ConductingEquipment", _uid("limit", TIE_EH_HVDC), 950.0, True, False, "nonNativeCapacityCalculationRegion"),
    ("no region code", "Galia", TIE_GA_HVDC_BH, "ConductingEquipment", _uid("limit", TIE_GA_HVDC_BH), 1500.0, False, False, None),
    ("scanned only", "Galia", TIE_GA_HVDC_NH, "ConductingEquipment", _uid("limit", TIE_GA_HVDC_NH), 1500.0, False, True, None),
    ("CGM PATL fallback", "Belgovia", SER_RLC, "ConductingEquipment", SER_RLC_LIMIT, None, True, False, None),
    ("Line predicate", "Svedala", TIE_SD_HVDC, "Line", _uid("limit", TIE_SD_HVDC), 1200.0, True, False, None),
]
AE_PATL_A = {branch: patl for _k, _t, branch, _p, _l, patl, *_rest in AE_SPECS}


def ae_mrid(key):
    return _uid("ae", key)


# ---------------------------------------------------------------------------
# XML blocks
# ---------------------------------------------------------------------------

def ae_xml(key, branch, predicate, limit, patl_a, secured, scanned, reason, equipment=True):
    lines = [f'  <nc:AssessedElement rdf:ID="_{ae_mrid(key)}">',
             f"    <cim:IdentifiedObject.mRID>{ae_mrid(key)}</cim:IdentifiedObject.mRID>",
             f"    <cim:IdentifiedObject.name>XNE dataset {key}</cim:IdentifiedObject.name>"]
    if equipment:
        lines.append(f'    <nc:AssessedElement.{predicate} rdf:resource="#_{branch}"/>')
    if limit is not None:
        lines.append(f'    <nc:AssessedElement.OperationalLimit rdf:resource="#_{limit}"/>')
    if secured:
        lines.append(f'    <nc:AssessedElement.SecuredForRegion rdf:resource="#_{REGION}"/>')
    if scanned:
        lines.append(f'    <nc:AssessedElement.ScannedForRegion rdf:resource="#_{REGION}"/>')
    if reason:
        lines.append(f'    <nc:AssessedElement.exclusionReason rdf:resource="{ENUM}SecuredExclusionReasonKind.{reason}"/>')
    lines.append("  </nc:AssessedElement>")
    if patl_a is not None:
        lines += [f'  <cim:BaseCaseCurrentLimit rdf:ID="_{limit}">',
                  f"    <nc:BaseCaseCurrentLimit.normalValue>{patl_a}</nc:BaseCaseCurrentLimit.normalValue>",
                  f"    <cim:IdentifiedObject.mRID>{limit}</cim:IdentifiedObject.mRID>",
                  "  </cim:BaseCaseCurrentLimit>"]
    return "\n".join(lines)


def contingency_xml(mrid, equipment, name, kind="OrdinaryContingency", must_study="true"):
    """A contingency of class `kind` with one ContingencyEquipment per equipment mRID; must_study None: no
    normalMustStudy."""
    study = f"\n  <nc:Contingency.normalMustStudy>{must_study}</nc:Contingency.normalMustStudy>" if must_study is not None else ""
    parts = [f"""<nc:{kind} rdf:ID="_{mrid}">{study}
  <cim:IdentifiedObject.mRID>{mrid}</cim:IdentifiedObject.mRID>
  <cim:IdentifiedObject.name>{name}</cim:IdentifiedObject.name>
</nc:{kind}>"""]
    for equipment_mrid in equipment:
        element = _uid("element", mrid, equipment_mrid)
        parts.append(f"""<cim:ContingencyEquipment rdf:ID="_{element}">
  <cim:ContingencyElement.Contingency rdf:resource="#_{mrid}" />
  <cim:ContingencyEquipment.Equipment rdf:resource="#_{equipment_mrid}" />
  <cim:IdentifiedObject.mRID>{element}</cim:IdentifiedObject.mRID>
</cim:ContingencyEquipment>""")
    return "\n".join(parts)


def link_xml(ra_mrid, contingency_mrid):
    link = _uid("link", ra_mrid, contingency_mrid)
    return f"""  <nc:ContingencyWithRemedialAction rdf:ID="_{link}">
    <nc:ContingencyWithRemedialAction.RemedialAction rdf:resource="#_{ra_mrid}"/>
    <nc:ContingencyWithRemedialAction.Contingency rdf:resource="#_{contingency_mrid}"/>
  </nc:ContingencyWithRemedialAction>"""


def gsara_xml(mrid, name, kind, available="true", penalty="1.0", time_to_implement=None, rdf_id=None):
    """A GridStateAlterationRemedialAction; available / penalty / time_to_implement None: the attribute is left out.
    rdf_id: an rdf:ID other than "_" + mRID."""
    lines = [f'  <nc:GridStateAlterationRemedialAction rdf:ID="_{rdf_id or mrid}">',
             f"    <cim:IdentifiedObject.mRID>{mrid}</cim:IdentifiedObject.mRID>",
             f"    <cim:IdentifiedObject.name>{name}</cim:IdentifiedObject.name>",
             f'    <nc:RemedialAction.kind rdf:resource="{ENUM}RemedialActionKind.{kind}"/>']
    if available is not None:
        lines.append(f"    <nc:RemedialAction.normalAvailable>{available}</nc:RemedialAction.normalAvailable>")
    if penalty is not None:
        lines.append(f"    <nc:RemedialAction.penaltyFactor>{penalty}</nc:RemedialAction.penaltyFactor>")
    if time_to_implement is not None:
        lines.append(f"    <nc:RemedialAction.timeToImplement>{time_to_implement}</nc:RemedialAction.timeToImplement>")
    lines.append("  </nc:GridStateAlterationRemedialAction>")
    return "\n".join(lines)


def tap_action_xml(ra_mrid, tap_changer, time_per_stage="PT1M", key=None):
    action = _uid("tap action", ra_mrid, key or tap_changer)
    stage = f"\n    <nc:GridStateAlteration.timePerStage>{time_per_stage}</nc:GridStateAlteration.timePerStage>" if time_per_stage else ""
    return action, f"""  <nc:TapPositionAction rdf:ID="_{action}">
    <cim:IdentifiedObject.mRID>{action}</cim:IdentifiedObject.mRID>
    <nc:GridStateAlteration.GridStateAlterationRemedialAction rdf:resource="#_{ra_mrid}"/>
    <nc:TapPositionAction.TapChanger rdf:resource="#_{tap_changer}"/>{stage}
  </nc:TapPositionAction>"""


def rotating_machine_action_xml(ra_mrid, machine):
    action = _uid("machine action", ra_mrid, machine)
    return f"""  <nc:RotatingMachineAction rdf:ID="_{action}">
    <cim:IdentifiedObject.mRID>{action}</cim:IdentifiedObject.mRID>
    <nc:GridStateAlteration.GridStateAlterationRemedialAction rdf:resource="#_{ra_mrid}"/>
    <nc:RotatingMachineAction.RotatingMachine rdf:resource="#_{machine}"/>
  </nc:RotatingMachineAction>"""


def range_xml(action, direction, value, value_kind="absolute", key=None):
    range_id = _uid("range", action, key or direction)
    return f"""  <nc:StaticPropertyRange rdf:ID="_{range_id}">
    <nc:RangeConstraint.GridStateAlteration rdf:resource="#_{action}"/>
    <nc:RangeConstraint.direction rdf:resource="{ENUM}RelativeDirectionKind.{direction}"/>
    <nc:RangeConstraint.valueKind rdf:resource="{ENUM}ValueOffsetKind.{value_kind}"/>
    <nc:RangeConstraint.normalValue>{value}</nc:RangeConstraint.normalValue>
  </nc:StaticPropertyRange>"""


def bid_xml(bid, ra_mrid, direction="up", volume="100.0", price="20.0", at_time=RUN_TIME, lead_time="P0Y0M0DT0H0M0S",
            activation_cost=None, time_point_activation_cost=None, reserve_price=None, currency="EUR",
            extra_schedule=""):
    """A PowerBidSchedule with one time point; direction / volume / price / currency None: left out (volume None:
    no time point at all)."""
    schedule = [f'  <nc:PowerBidSchedule rdf:ID="_{bid}">',
                f"    <cim:IdentifiedObject.mRID>{bid}</cim:IdentifiedObject.mRID>",
                f'    <nc:PowerBidSchedule.PowerRemedialAction rdf:resource="#_{ra_mrid}"/>',
                f"    <nc:PowerBidSchedule.leadTime>{lead_time}</nc:PowerBidSchedule.leadTime>"]
    if direction is not None:
        schedule.append(f'    <nc:PowerBidSchedule.direction rdf:resource="{ENUM}BidDirectionKind.{direction}"/>')
    if currency is not None:
        schedule.append(f'    <nc:PowerBidSchedule.currency rdf:resource="{CIM_NS}Currency.{currency}"/>')
    if activation_cost is not None:
        schedule.append(f"    <nc:PowerBidSchedule.activationCost>{activation_cost}</nc:PowerBidSchedule.activationCost>")
    if extra_schedule:
        schedule.append(extra_schedule)
    schedule.append("  </nc:PowerBidSchedule>")
    if volume is None:
        return "\n".join(schedule)
    point = [f'  <nc:PowerBidScheduleTimePoint rdf:ID="_{_uid("bid point", bid, at_time)}">',
             f'    <nc:PowerBidScheduleTimePoint.PowerBidSchedule rdf:resource="#_{bid}"/>',
             f"    <nc:PowerBidScheduleTimePoint.atTime>{at_time}</nc:PowerBidScheduleTimePoint.atTime>",
             f"    <nc:PowerBidScheduleTimePoint.p>{volume}</nc:PowerBidScheduleTimePoint.p>"]
    if price is not None:
        point.append(f"    <nc:PowerBidScheduleTimePoint.price>{price}</nc:PowerBidScheduleTimePoint.price>")
    if time_point_activation_cost is not None:
        point.append(f"    <nc:PowerBidScheduleTimePoint.activationCost>{time_point_activation_cost}</nc:PowerBidScheduleTimePoint.activationCost>")
    if reserve_price is not None:
        point.append(f"    <nc:PowerBidScheduleTimePoint.reservePrice>{reserve_price}</nc:PowerBidScheduleTimePoint.reservePrice>")
    point.append("  </nc:PowerBidScheduleTimePoint>")
    return "\n".join(schedule + point)


def glsk_xml(bid, units_and_factors, at_time=RUN_TIME, key=""):
    """One PowerShiftKeyDistribution of `bid` with one PowerShiftKeySchedule (and factor time point) per
    (generator or tuple of generators, factor)."""
    distribution = _uid("distribution", bid, key)
    schedules = []
    parts = []
    for index, (units, factor) in enumerate(units_and_factors):
        units = units if isinstance(units, tuple) else (units,)
        schedule = _uid("shift key schedule", bid, key, index)
        schedules.append(schedule)
        unit_refs = "".join(f'\n    <nc:PowerShiftKeySchedule.GeneratingUnit rdf:resource="#_{unit}"/>' for unit in units)
        parts.append(f"""  <nc:PowerShiftKeySchedule rdf:ID="_{schedule}">
    <cim:IdentifiedObject.mRID>{schedule}</cim:IdentifiedObject.mRID>{unit_refs}
  </nc:PowerShiftKeySchedule>
  <nc:ParticipationFactorTimePoint rdf:ID="_{_uid('factor point', schedule)}">
    <nc:ParticipationFactorTimePoint.PowerShiftKeySchedule rdf:resource="#_{schedule}"/>
    <nc:ParticipationFactorTimePoint.atTime>{at_time}</nc:ParticipationFactorTimePoint.atTime>
    <nc:ParticipationFactorTimePoint.participationFactor>{factor}</nc:ParticipationFactorTimePoint.participationFactor>
  </nc:ParticipationFactorTimePoint>""")
    refs = "".join(f'\n    <nc:PowerShiftKeyDistribution.PowerShiftKeySchedule rdf:resource="#_{s}"/>' for s in schedules)
    parts.insert(0, f"""  <nc:PowerShiftKeyDistribution rdf:ID="_{distribution}">
    <cim:IdentifiedObject.mRID>{distribution}</cim:IdentifiedObject.mRID>
    <nc:PowerShiftKeyDistribution.PowerBidSchedule rdf:resource="#_{bid}"/>{refs}
  </nc:PowerShiftKeyDistribution>""")
    return "\n".join(parts)


def unit_cost_sis_xml(unit, warm_startup=None, startup=None, shutdown=None, currency="EUR", at_time=RUN_TIME):
    schedule = _uid("unit cost schedule", unit)
    values = "".join(
        f"\n    <nc:UnitCostTimePoint.{name}>{value}</nc:UnitCostTimePoint.{name}>"
        for name, value in (("warmStartupCost", warm_startup), ("startupCost", startup), ("shutdownCost", shutdown)) if value is not None
    )
    return f"""  <nc:UnitCostSchedule rdf:ID="_{schedule}">
    <cim:IdentifiedObject.mRID>{schedule}</cim:IdentifiedObject.mRID>
    <nc:UnitCostSchedule.GeneratingUnit rdf:resource="#_{unit}"/>
    <nc:UnitCostSchedule.currency rdf:resource="{CIM_NS}Currency.{currency}"/>
  </nc:UnitCostSchedule>
  <nc:UnitCostTimePoint rdf:ID="_{_uid('unit cost point', schedule)}">
    <nc:UnitCostTimePoint.UnitCostSchedule rdf:resource="#_{schedule}"/>
    <nc:UnitCostTimePoint.atTime>{at_time}</nc:UnitCostTimePoint.atTime>{values}
  </nc:UnitCostTimePoint>"""


def er_xml(units):
    """A {TSO}_ER.xml: start-up / shut-down costs per CGMES GeneratingUnit. units: [(unit, warm start-up, shut-down)]."""
    body = "\n".join(f"""  <nc:GeneratingUnit rdf:about="#_{unit}">
    <nc:GeneratingUnit.normalWarmStartupCost>{startup}</nc:GeneratingUnit.normalWarmStartupCost>
    <nc:GeneratingUnit.normalShutdownCost>{shutdown}</nc:GeneratingUnit.normalShutdownCost>
    <nc:GeneratingUnit.costCurrency rdf:resource="{CIM_NS}Currency.EUR"/>
  </nc:GeneratingUnit>""" for unit, startup, shutdown in units)
    return (f'<?xml version="1.0" encoding="UTF-8"?>\n<rdf:RDF xmlns:rdf="http://www.w3.org/1999/02/22-rdf-syntax-ns#" '
            f'xmlns:nc="{ENUM}" xmlns:cim="{CIM_NS}">\n{body}\n</rdf:RDF>\n')


ER_UNITS = [(STENFORSEN_G1_UNIT, 400.0, 200.0)]
SIS_UNIT_COSTS = [(STORFORS_G1_UNIT, dict(warm_startup=500.0, startup=600.0, shutdown=300.0))]

# ---------------------------------------------------------------------------
# text edits of the RDF/XML files
# ---------------------------------------------------------------------------


def _element(text, mrid):
    """(start, end) of the element with rdf:ID "_<mrid>" in text, including its leading indentation."""
    match = re.search(rf'[ \t]*<(?P<tag>\w+:\w+) rdf:ID="_{re.escape(mrid)}"\s*>.*?</(?P=tag)>\s*?\n', text, re.S)
    if match is None:
        raise ValueError(f"element {mrid} not found")
    return match.start(), match.end()


def drop_element(text, mrid):
    start, end = _element(text, mrid)
    return text[:start] + text[end:]


def elements_referring_to(text, tag, mrid):
    """The rdf:IDs (without "_") of the <tag> elements that hold rdf:resource="#_<mrid>"."""
    found = []
    for match in re.finditer(rf'<{tag} rdf:ID="_(?P<id>[^"]+)"\s*>(?P<body>.*?)</{tag}>', text, re.S):
        if f'"#_{mrid}"' in match.group("body"):
            found.append(match.group("id"))
    return found


def drop_ra(text, mrid):
    """Drop a GSARA with its actions and contingency links."""
    for tag in ("nc:TapPositionAction", "nc:RotatingMachineAction", "nc:ContingencyWithRemedialAction"):
        for element in elements_referring_to(text, tag, mrid):
            text = drop_element(text, element)
    return drop_element(text, mrid)


def set_property(text, mrid, predicate, value):
    """Set (value a str: literal, or ("resource", uri)) or remove (value None) one property of the element mrid."""
    start, end = _element(text, mrid)
    body = text[start:end]
    body = re.sub(rf"\s*<{re.escape(predicate)}(\s[^>]*)?/>", "", body)
    body = re.sub(rf"\s*<{re.escape(predicate)}(\s[^>]*)?>.*?</{re.escape(predicate)}>", "", body, flags=re.S)
    if value is not None:
        line = (f'<{predicate} rdf:resource="{value[1]}"/>' if isinstance(value, tuple)
                else f"<{predicate}>{value}</{predicate}>")
        close = body.rindex("</")
        body = body[:close].rstrip() + f"\n    {line}\n  " + body[close:]
    return text[:start] + body + text[end:]


def add_reaction_time_to_curative_ras(text, time_to_implement=CURATIVE_REACTION):
    """Give every curative GSARA or RedispatchRemedialAction without a timeToImplement one (the data rule: a readable reaction time)."""
    for match in list(re.finditer(r'<nc:(?P<cls>GridStateAlterationRemedialAction|RedispatchRemedialAction) rdf:ID="_(?P<id>[^"]+)"\s*>(?P<body>.*?)</nc:(?P=cls)>', text, re.S)):
        body = match.group("body")
        if "RemedialActionKind.curative" in body and "timeToImplement" not in body:
            text = set_property(text, match.group("id"), "nc:RemedialAction.timeToImplement", time_to_implement)
    return text


def append_block(text, block):
    end = text.rindex("</rdf:RDF>")
    return text[:end] + block + "\n" + text[end:]


def tap_action_of(text, ra_mrid):
    actions = elements_referring_to(text, "nc:TapPositionAction", ra_mrid)
    if len(actions) != 1:
        raise ValueError(f"{ra_mrid} has {len(actions)} TapPositionActions")
    return actions[0]


# ---------------------------------------------------------------------------
# the valid dataset
# ---------------------------------------------------------------------------

def hvdc_ras():
    """The preventive pair of the HVDC mock (penalty factor of the CT+HVDC scenario) and the curative pair; the
    curative SD-BO3 unit has an absolute up range of 1 MW below its set point of 1.56 MW (widened, H3.4) and the
    incremental down ranges."""
    preventive = [dict(spec, penalty=ct_mock.CT_HVDC_HVDC_PENALTY) for spec in hvdc_mock.default_ras()]
    curative = hvdc_mock.curative_ras(contingencies=(hvdc_mock.CO_OVERLOAD_A,), time_to_implement=CURATIVE_REACTION)
    curative[1] = dict(curative[1], ranges=[("up", "absolute", 1.0), ("down", "incremental", 60), ("down", "incremental", 40)])
    return preventive + curative


def ct_ras():
    """BZ-Belgovia and BZ-Galia, up and down, preventive (penaltyFactor 0 and 0.05) and curative (missing and 1.0)."""
    preventive = ct_mock.default_ras(penalties=(0.0, ct_mock.CT_HVDC_CT_PENALTY))
    curative = ct_mock.curative_ras(time_to_implement=CURATIVE_REACTION)
    curative[0] = dict(curative[0], penalty=None)
    return preventive + curative


def _ae_edits():
    by_tso = {}
    for key, tso, branch, predicate, limit, patl, secured, scanned, reason in AE_SPECS:
        by_tso.setdefault(f"{tso}_AE.xml", []).append(ae_xml(key, branch, predicate, limit, patl, secured, scanned, reason))
    return {name: [lambda text, blocks=blocks: append_block(text, "\n".join(blocks))] for name, blocks in by_tso.items()}


def _belgovia_ra(text):
    # one preventive PST RA with both Belgovia PSTs (a group) instead of one RA each
    text = drop_ra(drop_ra(text, PRA_PST_BO_TR2_1), PRA_PST_BO_TR2_2)
    # one curative group instead of the two curative RAs, linked to their contingencies and to the outage of a member
    linked = sorted({
        re.search(r'ContingencyWithRemedialAction\.Contingency rdf:resource="#_([^"]+)"', text[slice(*_element(text, link))]).group(1)
        for ra in (CRA_PST_BO_TR2_1, CRA_PST_BO_TR2_2)
        for link in elements_referring_to(text, "nc:ContingencyWithRemedialAction", ra)
    })
    assert linked == [BELGOVIA_CO3], linked
    text = drop_ra(drop_ra(text, CRA_PST_BO_TR2_1), CRA_PST_BO_TR2_2)
    blocks = [gsara_xml(PST_GROUP_PRA, "PRA_PST_BO_GROUP", "preventive")]
    blocks += [tap_action_xml(PST_GROUP_PRA, tc)[1] for tc in (TC_BO_TR2_1, TC_BO_TR2_2)]
    blocks.append(gsara_xml(PST_GROUP_CRA, "CRA_PST_BO_GROUP", "curative", time_to_implement=CURATIVE_REACTION))
    blocks += [tap_action_xml(PST_GROUP_CRA, tc)[1] for tc in (TC_BO_TR2_1, TC_BO_TR2_2)]
    blocks += [link_xml(PST_GROUP_CRA, co) for co in (BELGOVIA_CO3, CO_BO_TR2_1_OUT)]
    return append_block(text, "\n".join(blocks))


def _espheim_ra(text):
    # Aac: curative only, fast, with a curative range (separate up and down); Aaa(1): slow
    text = drop_ra(text, PRA_PST_AAC)
    text = set_property(text, CRA_PST_AAC, "nc:RemedialAction.timeToImplement", FAST_REACTION)
    text = set_property(text, CRA_PST_AAA1, "nc:RemedialAction.timeToImplement", SLOW_REACTION)
    action = tap_action_of(text, CRA_PST_AAC)
    return append_block(text, range_xml(action, "up", AAC_RANGE_UP) + "\n" + range_xml(action, "down", AAC_RANGE_DOWN))


def _galia_ra(text):
    text = set_property(text, PRA_PST_GA_TR2_2, "nc:RemedialAction.penaltyFactor", None)        # missing: 1.0
    text = set_property(text, CRA_PST_GA_TR2_2, "nc:RemedialAction.normalAvailable", "false")
    return set_property(text, PRA_PST_GA_TR2_1, "nc:RemedialAction.normalAvailable", None)      # missing: not available


def _galia_sis(text):
    blocks = [
        # a second up bid of PRA_RD_GA_G1_UP whose time point carries the activation cost
        bid_xml(GA_G1_SECOND_BID, PRA_RD_GA_G1_UP, volume="50.0", price="60.0", activation_cost="100.0", time_point_activation_cost="150.0"),
        glsk_xml(GA_G1_SECOND_BID, [(GA_G1, 1.0)]),
        # a bid with a lead time of 2 hours
        bid_xml(GA_G1_LEAD_TIME_BID, PRA_RD_GA_G1_UP, volume="30.0", price="40.0", lead_time="PT2H"),
        glsk_xml(GA_G1_LEAD_TIME_BID, [(GA_G1, 1.0)]),
        # a curative bid with a reservation price
        bid_xml(GA_G1_CURATIVE_RESERVE_BID, CRA_RD_GA_G1_UP, volume="40.0", price="55.0", reserve_price="3.0"),
        glsk_xml(GA_G1_CURATIVE_RESERVE_BID, [(GA_G1, 1.0)]),
    ]
    return append_block(text, "\n".join(blocks))


def _svedala_ra(text):
    blocks = [gsara_xml(RD_MULTI_GLSK, "PRA_RD_SV_MULTI", "preventive"), rotating_machine_action_xml(RD_MULTI_GLSK, STORFORS_G1)]
    return append_block(text, "\n".join(blocks))


RD_MULTI_UP, RD_MULTI_DOWN = _uid("bid", "SV multi up"), _uid("bid", "SV multi down")
# the GLSK of PRA_RD_SV_MULTI: two connected units 0.6 / 0.4 and an unconnected one 0.2 (removed, redistributed)
RD_MULTI_GLSK_FACTORS = [(STORFORS_G1, 0.6), (STENFORSEN_G1, 0.4), (KARNAN_G3, 0.2)]


def _svedala_sis(text):
    blocks = []
    for bid, direction in ((RD_MULTI_UP, "up"), (RD_MULTI_DOWN, "down")):
        blocks += [bid_xml(bid, RD_MULTI_GLSK, direction=direction, volume="100.0", price="30.0"),
                   glsk_xml(bid, RD_MULTI_GLSK_FACTORS)]
    blocks += [unit_cost_sis_xml(unit, **costs) for unit, costs in SIS_UNIT_COSTS]
    return append_block(text, "\n".join(blocks))


def _belgovia_co(text):
    blocks = [
        contingency_xml(CO_BO_TR2_1_OUT, [BO_TR2_1], "dataset outage BO-TR2_1"),
        contingency_xml(CO_SWITCH, [BREAKER_BO], "dataset outage breaker"),
        contingency_xml(CO_SVC, [SVC_BO], "dataset outage SVC"),
        contingency_xml(CO_BUSBAR, [BUSBAR_BO], "dataset outage busbar (not studied)", must_study="false"),
        contingency_xml(CO_DC_LINE, [DC_LINE_EH_SD], "dataset outage DC line (unmappable)"),
    ]
    return append_block(text, "\n".join(blocks))


def _espheim_co(text):
    return append_block(text, contingency_xml(CO_NOT_STUDIED, [LINE_25_27], "dataset line 25-27 not studied", must_study="false"))


def _all_ra(text):
    return add_reaction_time_to_curative_ras(text)


def dataset_edits():
    """{file name: [text -> text]} of step 3, in order; "*_RA.xml" applies to every RA file."""
    edits = {
        "Belgovia_RA.xml": [_belgovia_ra], "Espheim_RA.xml": [_espheim_ra], "Galia_RA.xml": [_galia_ra],
        "Svedala_RA.xml": [_svedala_ra], "Galia_SIS.xml": [_galia_sis], "Svedala_SIS.xml": [_svedala_sis],
        "Belgovia_CO.xml": [_belgovia_co], "Espheim_CO.xml": [_espheim_co],
    }
    for name, functions in _ae_edits().items():
        edits.setdefault(name, []).extend(functions)
    return edits


NEW_FILES = {"Svedala_ER.xml": lambda: er_xml(ER_UNITS)}


def _rewrite(source, dest, edits, new_files):
    """Copy the zip source to dest with edits {name: [text -> text]} ("*_RA.xml": every RA file, after the named
    ones) and new_files {name: () -> text} (None: the file is left out)."""
    dest = Path(dest)
    with zipfile.ZipFile(source) as zin, zipfile.ZipFile(dest, "w") as zout:
        for item in zin.infolist():
            if item.filename in new_files and new_files[item.filename] is None:
                continue
            data = zin.read(item.filename)
            functions = list(edits.get(item.filename, []))
            if item.filename.endswith("_RA.xml"):
                functions += edits.get("*_RA.xml", [])
            if functions:
                text = data.decode("utf-8")
                for function in functions:
                    text = function(text)
                data = text.encode("utf-8")
            zout.writestr(_fixed_entry(item.filename), data)
        existing = set(zin.namelist())
        for name, make in new_files.items():
            if make is not None and name not in existing:
                zout.writestr(_fixed_entry(name), make().encode("utf-8"))
    return dest


def build_valid_ncp(dest, extra_edits=None, extra_files=None, check=True):
    """Build the valid dataset zip at dest and return it. extra_edits / extra_files: more edits and new files
    (build_variant_ncp); check: assert the data rules (check_data_rules)."""
    dest = Path(dest)
    work = dest.with_name(dest.stem + "_steps")
    work.mkdir(parents=True, exist_ok=True)
    ras = hvdc_ras()
    hvdc_zip = hvdc_mock.build_hvdc_mock_ncp(
        work / "hvdc.zip", ras=ras, groups=hvdc_mock.default_groups(ras) + hvdc_mock.curative_groups(ras[2:]),
        patl_a=ct_mock.CT_HVDC_HVDC_PATL_A,
        extra_co_xml=hvdc_mock.contingency_xml(hvdc_mock.CO_EI_OUT, [hvdc_mock.EI_SD_BO3], "dataset outage of the EI of SD-BO3"),
    )
    ct_zip = ct_mock.build_ct_mock_ncp(
        work / "ct.zip", ras=ct_ras(), patl_a=ct_mock.CT_HVDC_PATL_A, source_zip=hvdc_zip, groups=[RD_GROUP],
        contingencies=[ct_mock.ga_bo5_outage()],
    )
    edits = dataset_edits()
    edits.setdefault("*_RA.xml", []).append(_all_ra)
    for name, functions in (extra_edits or {}).items():
        edits.setdefault(name, []).extend(functions)
    files = dict(NEW_FILES)
    files.update(extra_files or {})
    _rewrite(ct_zip, dest, edits, files)
    if check:
        violations = check_data_rules(dest)
        assert not violations, violations
    return dest


# ---------------------------------------------------------------------------
# the invalid and warning variants: the valid package with one change each
# ---------------------------------------------------------------------------

EI_SD_EH2 = "24c845f6-ad68-4472-8d01-6491769a2f31"                 # Injection_SD_EH2 (Svedala)
EI_SD_EH3 = "bfe2d3b9-21c4-44fd-b86f-a0bb381afafb"                 # Injection_SD_EH3 (Svedala)
HVDC_PREVENTIVE = [spec["mrid"] for spec in hvdc_mock.default_ras()]
HVDC_CURATIVE = [spec["mrid"] for spec in hvdc_mock.curative_ras()]
HVDC_PREVENTIVE_GROUP = hvdc_mock.default_groups(hvdc_mock.default_ras())[0][0]
CT_BO, CT_GA = ct_mock._uid("ra", "BO"), ct_mock._uid("ra", "GA")
CT_BID = {key: ct_mock._uid("bid", ra, key) for ra, key in (("BO", "BO-up"), ("BO", "BO-down"), ("GA", "GA-up"), ("GA", "GA-down"))}
UNKNOWN_MACHINE = _uid("machine", "not in the CGM")
MRID_DIFFERS_RA = _uid("ra", "mRID differs from rdf:ID")
MRID_DIFFERS_RDF_ID = _uid("rdf:ID", "mRID differs from rdf:ID")
MRID_DIFFERS_BID = _uid("bid", "mRID differs from rdf:ID")
VARIANT_AE = ae_mrid("variant")
VARIANT_CONTINGENCY = _uid("contingency", "variant")
VARIANT_RA = _uid("ra", "variant")
VARIANT_BID = _uid("bid", "variant")
VARIANT_GROUP = _uid("group", "variant")


def _append_to(name, block):
    return {name: [lambda text: append_block(text, block)]}


def _edit(name, function):
    return {name: [function]}


def _hvdc_ra(mrid, ei, kind="preventive", ranges=(("upAndDown", "absolute", 100),), time_to_implement=None):
    return hvdc_mock._ra_xml(hvdc_mock.ra(mrid, ei, kind=kind, ranges=ranges, time_to_implement=time_to_implement))


def _dependency_xml(group, ra, kind="balanced", predicate="DependingRemedialActionGroup"):
    return f"""  <nc:RemedialActionDependency rdf:ID="_{_uid('dependency', group, ra)}">
    <nc:RemedialActionDependency.kind rdf:resource="{ENUM}RemedialActionDependencyKind.{kind}"/>
    <nc:RemedialActionDependency.{predicate} rdf:resource="#_{group}"/>
    <nc:RemedialActionDependency.RemedialAction rdf:resource="#_{ra}"/>
  </nc:RemedialActionDependency>"""


def _hvdc_range(ra_mrid, direction, kind, value, prop="EquivalentInjection.p"):
    action = hvdc_mock._uid("action", ra_mrid)
    return f"""  <nc:StaticPropertyRange rdf:ID="_{_uid('variant range', ra_mrid, direction, kind, value, prop)}">
    <nc:RangeConstraint.GridStateAlteration rdf:resource="#_{action}"/>
    <nc:RangeConstraint.direction rdf:resource="{ENUM}RelativeDirectionKind.{direction}"/>
    <nc:RangeConstraint.valueKind rdf:resource="{ENUM}ValueOffsetKind.{kind}"/>
    <nc:StaticPropertyRange.PropertyReference rdf:resource="https://energy.referencedata.eu/PropertyReference/{prop}"/>
    <nc:RangeConstraint.normalValue>{value}</nc:RangeConstraint.normalValue>
  </nc:StaticPropertyRange>"""


def _variant_ae(reason=None, equipment=True, branch=SER_RLC, predicate="ConductingEquipment", patl="700.0", extra=""):
    """An AE in Belgovia_AE.xml; equipment False: no ConductingEquipment, no OperationalLimit (extra may add a
    corridor)."""
    limit = _uid("limit", "variant") if equipment else None
    block = ae_xml("variant", branch, predicate, limit, patl if equipment else None, True, False, reason, equipment=equipment)
    if extra:
        block = block.replace("  </nc:AssessedElement>", f"{extra}\n  </nc:AssessedElement>", 1)
    return _append_to("Belgovia_AE.xml", block)


def _ct_bid_text(name, bid, function):
    return _edit(name, lambda text: function(text, bid))


def _svedala_rd_ra(rd_ra=VARIANT_RA, machine=STORFORS_G1, **gsara):
    return gsara_xml(rd_ra, "PRA_RD_SV_VARIANT", "preventive", **gsara) + "\n" + rotating_machine_action_xml(rd_ra, machine)


def _variant_bid(**bid_kwargs):
    """A preventive RD RA of its own (Svedala, on STORFORS_G1) with one bid and a GLSK on STORFORS_G1 (the GLSK of an
    RA sums over its bids, so the variant needs an RA of its own)."""
    edits = _append_to("Svedala_RA.xml", _svedala_rd_ra())
    edits.update(_append_to("Svedala_SIS.xml", bid_xml(VARIANT_BID, VARIANT_RA, **bid_kwargs) + "\n" + glsk_xml(VARIANT_BID, [(STORFORS_G1, 1.0)])))
    return edits


def _variant_glsk(units_and_factors):
    edits = _append_to("Svedala_RA.xml", _svedala_rd_ra())
    edits.update(_append_to("Svedala_SIS.xml", bid_xml(VARIANT_BID, VARIANT_RA) + "\n" + glsk_xml(VARIANT_BID, units_and_factors)))
    return edits


def _set_in(name, mrid, predicate, value):
    return _edit(name, lambda text: set_property(text, mrid, predicate, value))


def _aac_tap_action(text):
    return tap_action_of(text, CRA_PST_AAC)


def _aac_ranges(ranges):
    """Replace the curative range of Aac by `ranges` [(direction, value)]."""
    def edit(text):
        action = _aac_tap_action(text)
        for range_id in elements_referring_to(text, "nc:StaticPropertyRange", action):
            text = drop_element(text, range_id)
        return append_block(text, "\n".join(range_xml(action, d, v, key=f"variant {i}") for i, (d, v) in enumerate(ranges)))
    return _edit("Espheim_RA.xml", edit)


def _time_per_stage_of_aac(value):
    def edit(text):
        return set_property(text, _aac_tap_action(text), "nc:GridStateAlteration.timePerStage", value)
    return _edit("Espheim_RA.xml", edit)


def _mrid_differs():
    """An RD RA whose rdf:ID differs from its mRID, with a contingency link and a bid that refer to its rdf:ID."""
    ra = gsara_xml(MRID_DIFFERS_RA, "PRA_RD_SV_MRID_DIFFERS", "curative", time_to_implement=CURATIVE_REACTION,
                   rdf_id=MRID_DIFFERS_RDF_ID)
    ra += "\n" + rotating_machine_action_xml(MRID_DIFFERS_RDF_ID, STORFORS_G1)
    ra += "\n" + link_xml(MRID_DIFFERS_RDF_ID, hvdc_mock.CO_OVERLOAD_A)
    bid = bid_xml(MRID_DIFFERS_BID, MRID_DIFFERS_RDF_ID) + "\n" + glsk_xml(MRID_DIFFERS_BID, [(STORFORS_G1, 1.0)])
    edits = _append_to("Svedala_RA.xml", ra)
    edits.update(_append_to("Svedala_SIS.xml", bid))
    return edits


def _contingency_twice():
    block = contingency_xml(VARIANT_CONTINGENCY, [LINE_25_27], "variant contingency in two files")
    edits = _append_to("Espheim_CO.xml", block)
    edits.update(_append_to("Galia_CO.xml", block))
    return edits


def _hvdc_defined_twice():
    spec = hvdc_mock.default_ras()[0]
    return _append_to("Belgovia_RA.xml", hvdc_mock._ra_xml(spec))


def _ct_without_bids(text):
    for key in ("GA-up", "GA-down"):
        bid = CT_BID[key]
        text = drop_element(text, bid)
        text = drop_element(text, ct_mock._uid("tp", bid))
    return text


def _ct_bid_without_volume(text):
    return drop_element(text, ct_mock._uid("tp", CT_BID["BO-up"]))


def _ct_bid_strategy(strategies):
    """Galia_SIS: gLSKStrategy tokens on the GA bids {key: token}."""
    def edit(text):
        for key, token in strategies.items():
            text = set_property(text, CT_BID[key], "nc:PowerBidSchedule.gLSKStrategy", ("resource", f"{ENUM}GLSKStrategyKind.{token}"))
        return text
    return _edit("Galia_SIS.xml", edit)


def _group(max_up, max_down):
    spec = ct_mock.group("variant", [{"mrid": "203df9f2-582a-5120-b679-32c35090217d"}], max_up=max_up, max_down=max_down)
    spec["mrid"] = VARIANT_GROUP
    edits = _append_to("Belgovia_RA.xml", ct_mock._group_ra_xml(spec))
    if max_up is not None or max_down is not None:
        edits.update(_append_to("Belgovia_SIS.xml", ct_mock._group_sis_xml(spec)))
    return edits


VARIANTS = {
    # assessed elements and limits
    "invalid_exclusion_reason": lambda: _variant_ae(reason="noSuchReason"),
    "ae_without_equipment": lambda: _variant_ae(equipment=False),
    "ae_corridor_only": lambda: _variant_ae(equipment=False, extra=f'    <nc:AssessedElement.DCTieCorridor rdf:resource="#_{_uid("corridor")}"/>'),
    "ae_on_busbar": lambda: _variant_ae(branch=BUSBAR_BO),
    "bccl_non_numeric": lambda: _variant_ae(patl="high"),
    "patl_zero": lambda: _variant_ae(patl="0"),
    "shs_non_numeric": lambda: _append_to("Belgovia_SHS.xml", ct_mock._shs_xml("n/a").replace(ct_mock.XNE_OPERATIONAL_LIMIT, SER_RLC_LIMIT)
                                          .replace(ct_mock._uid("shs-schedule"), _uid("shs schedule", "variant"))
                                          .replace(ct_mock._uid("shs-point"), _uid("shs point", "variant"))),
    # contingencies
    "contingency_without_equipment": lambda: _append_to("Espheim_CO.xml", contingency_xml(VARIANT_CONTINGENCY, [], "variant without equipment")),
    "contingency_must_study_missing": lambda: _append_to("Espheim_CO.xml", contingency_xml(VARIANT_CONTINGENCY, [LINE_25_27], "variant", must_study=None)),
    "contingency_in_two_files": _contingency_twice,
    # common RA attributes
    "ra_kind_unknown": lambda: _set_in("Galia_RA.xml", CRA_PST_GA_TR2_2, "nc:RemedialAction.kind", ("resource", f"{ENUM}RemedialActionKind.sometimes")),
    "ra_kind_missing": lambda: _set_in("Galia_RA.xml", CRA_PST_GA_TR2_2, "nc:RemedialAction.kind", None),
    "penalty_factor_non_numeric": lambda: _set_in("Svedala_RA.xml", RD_MULTI_GLSK, "nc:RemedialAction.penaltyFactor", "high"),
    "reaction_time_unreadable_rd": lambda: _set_in("Galia_RA.xml", CRA_RD_GA_G1_UP, "nc:RemedialAction.timeToImplement", "P1M"),
    "reaction_time_unreadable_pst": lambda: _set_in("Espheim_RA.xml", CRA_PST_AAC, "nc:RemedialAction.timeToImplement", "soon"),
    "mrid_differs_from_rdf_id": _mrid_differs,
    # PST
    "time_per_stage_zero": lambda: _time_per_stage_of_aac("PT0S"),
    "time_per_stage_unreadable": lambda: _time_per_stage_of_aac("one minute"),
    "tap_action_on_ratio_tap_changer": lambda: _append_to("Belgovia_RA.xml", gsara_xml(VARIANT_RA, "PRA_RATIO", "preventive") + "\n" + tap_action_xml(VARIANT_RA, TC_RATIO_BO_TR2_3)[1]),
    "empty_curative_tap_range": lambda: _aac_ranges([("up", -5), ("down", 5)]),
    "fixed_curative_tap_range": lambda: _aac_ranges([("up", 2), ("down", 2)]),
    "curative_range_up_and_down": lambda: _aac_ranges([("upAndDown", 3)]),
    "curative_range_none": lambda: _aac_ranges([("none", 3), ("up", 5), ("down", -5)]),
    "curative_range_one_sided": lambda: _aac_ranges([("up", 5)]),
    # RD: groups, bids, GLSK, units
    "group_without_limit": lambda: _group(None, None),
    "group_up_only": lambda: _group(40.0, None),
    "bid_price_missing": lambda: _variant_bid(price=None),
    "bid_price_negative": lambda: _variant_bid(price="-5.0"),
    "bid_reserve_price_negative": lambda: _variant_bid(reserve_price="-2.0"),
    "bid_currency_not_eur": lambda: _variant_bid(currency="USD"),
    "bid_direction_missing": lambda: _variant_bid(direction=None),
    "bid_without_volume": lambda: _variant_bid(volume=None),
    "bid_energy_fields": lambda: _variant_bid(extra_schedule="    <nc:PowerBidSchedule.minEnergyBid>10.0</nc:PowerBidSchedule.minEnergyBid>\n"
                                                             "    <nc:PowerBidSchedule.maxEnergyBid>90.0</nc:PowerBidSchedule.maxEnergyBid>\n"
                                                             "    <nc:PowerBidSchedule.stepSizeCTRD>5.0</nc:PowerBidSchedule.stepSizeCTRD>"),
    "bid_time_point_other_day": lambda: _variant_bid(at_time="2024-03-01T10:30:00Z"),
    "glsk_schedule_with_two_units": lambda: _variant_glsk([((STORFORS_G1, STENFORSEN_G1), 1.0)]),
    "glsk_factor_non_numeric": lambda: _variant_glsk([(STORFORS_G1, "a lot")]),
    "glsk_factors_zero": lambda: _variant_glsk([(STORFORS_G1, 0.0), (STENFORSEN_G1, 0.0)]),
    "glsk_factor_negative": lambda: _variant_glsk([(STORFORS_G1, 1.0), (STENFORSEN_G1, -0.5)]),
    "rd_machine_not_in_cgm": lambda: _append_to("Svedala_RA.xml", _svedala_rd_ra(machine=UNKNOWN_MACHINE)),
    "unit_cost_negative": lambda: _append_to("Svedala_SIS.xml", unit_cost_sis_xml(STENFORSEN_G1_UNIT, warm_startup=-5.0)),
    # HVDC
    "hvdc_group_of_three": lambda: _append_to("Svedala_RA.xml", _hvdc_ra(VARIANT_RA, EI_SD_EH2) + "\n" + _dependency_xml(HVDC_PREVENTIVE_GROUP, VARIANT_RA)),
    "hvdc_unit_without_group": lambda: _append_to("Svedala_RA.xml", _hvdc_ra(VARIANT_RA, EI_SD_EH2)),
    "hvdc_mixed_kinds": lambda: _append_to("Svedala_RA.xml", "\n".join([
        _hvdc_ra(VARIANT_RA, EI_SD_EH2), _hvdc_ra(_uid("ra", "variant 2"), EI_SD_EH3, kind="curative", time_to_implement="PT5M"),
        _dependency_xml(VARIANT_GROUP, VARIANT_RA), _dependency_xml(VARIANT_GROUP, _uid("ra", "variant 2"))])),
    "hvdc_same_ei_twice": lambda: _append_to("Svedala_RA.xml", "\n".join([
        _hvdc_ra(VARIANT_RA, EI_SD_EH2), _hvdc_ra(_uid("ra", "variant 2"), EI_SD_EH2),
        _dependency_xml(VARIANT_GROUP, VARIANT_RA), _dependency_xml(VARIANT_GROUP, _uid("ra", "variant 2"))])),
    "hvdc_two_actions": lambda: _append_to("Svedala_RA.xml", f"""  <nc:EquivalentInjectionAction rdf:ID="_{_uid('action', 'variant')}">
    <nc:GridStateAlteration.GridStateAlterationRemedialAction rdf:resource="#_{HVDC_PREVENTIVE[0]}"/>
    <nc:EquivalentInjectionAction.EquivalentInjection rdf:resource="#_{EI_SD_EH2}"/>
  </nc:EquivalentInjectionAction>"""),
    "hvdc_defined_twice": _hvdc_defined_twice,
    "hvdc_unit_in_two_groups": lambda: _append_to("Svedala_RA.xml", _dependency_xml(hvdc_mock.CURATIVE_GROUP, HVDC_PREVENTIVE[0])),
    "hvdc_unit_unavailable": lambda: _set_in("Svedala_RA.xml", HVDC_PREVENTIVE[1], "nc:RemedialAction.normalAvailable", "false"),
    "hvdc_penalty_missing": lambda: _set_in("Svedala_RA.xml", HVDC_PREVENTIVE[0], "nc:RemedialAction.penaltyFactor", None),
    "hvdc_range_none": lambda: _append_to("Svedala_RA.xml", _hvdc_range(HVDC_PREVENTIVE[0], "none", "absolute", 300)),
    "hvdc_range_unknown_value_kind": lambda: _append_to("Svedala_RA.xml", _hvdc_range(HVDC_PREVENTIVE[0], "up", "relative", 300)),
    "hvdc_range_non_numeric": lambda: _append_to("Svedala_RA.xml", _hvdc_range(HVDC_PREVENTIVE[0], "up", "absolute", "wide")),
    "hvdc_range_other_property": lambda: _append_to("Svedala_RA.xml", _hvdc_range(HVDC_PREVENTIVE[0], "up", "absolute", 10, prop="EquivalentInjection.q")),
    "hvdc_negative_incremental": lambda: _append_to("Svedala_RA.xml", _hvdc_range(HVDC_PREVENTIVE[1], "up", "incremental", -10)),
    "hvdc_group_predicate_remedial_action_group": lambda: _edit("Svedala_RA.xml", lambda text: text.replace(
        "RemedialActionDependency.DependingRemedialActionGroup", "RemedialActionDependency.RemedialActionGroup")),
    "hvdc_ei_in_rd_glsk": lambda: _variant_glsk([(STORFORS_G1, 1.0), (hvdc_mock.EI_SD_EH1, 0.5)]),
    # countertrade
    "ct_unknown_strategy": lambda: _set_in("Belgovia_RA.xml", CT_BO, "nc:CountertradeRemedialAction.gLSKStrategy", ("resource", f"{ENUM}GLSKStrategyKind.explicitInstruction")),
    "ct_mixed_strategy": lambda: _ct_bid_strategy({"GA-up": "proportionalForGenerator"}),
    "ct_strategy_on_bids_only": lambda: {**_set_in("Galia_RA.xml", CT_GA, "nc:CountertradeRemedialAction.gLSKStrategy", None),
                                         **_ct_bid_strategy({"GA-up": ct_mock.STRATEGY, "GA-down": ct_mock.STRATEGY})},
    "ct_without_zone": lambda: _set_in("Belgovia_RA.xml", CT_BO, "nc:PowerRemedialAction.BiddingZone", None),
    "ct_zone_without_units": lambda: _set_in("Belgovia_RA.xml", CT_BO, "nc:PowerRemedialAction.BiddingZone", ("resource", f"#_{ct_mock.ZONE_NORDHEIM}")),
    "ct_zone_unknown": lambda: _set_in("Belgovia_RA.xml", CT_BO, "nc:PowerRemedialAction.BiddingZone", ("resource", f"#_{ct_mock.ZONE_UNKNOWN}")),
    "ct_bid_without_volume": lambda: _edit("Belgovia_SIS.xml", _ct_bid_without_volume),
    "ct_ra_without_bids": lambda: _edit("Galia_SIS.xml", _ct_without_bids),
}

# loader variants: new files ({name: text maker}, None removes the file)
FILE_VARIANTS = {
    "loader_unrecognized_file": {"Atlantis_AE.xml": lambda: er_xml([])},
    "loader_cross_tso_export": {"Galia-Belgovia_CO.xml": lambda: er_xml([])},
    "loader_missing_ra": {"Svedala_RA.xml": None},
}


def build_variant_ncp(dest, case):
    """The valid package with the one change of VARIANTS[case] or FILE_VARIANTS[case]. The data rules are not
    checked (a variant breaks some on purpose)."""
    if case in FILE_VARIANTS:
        return build_valid_ncp(dest, extra_files=FILE_VARIANTS[case], check=False)
    return build_valid_ncp(dest, extra_edits=VARIANTS[case](), check=False)


# ---------------------------------------------------------------------------
# the data rules
# ---------------------------------------------------------------------------

def read_package(path):
    """{file name: rdflib Graph} of the NCP files of a dataset zip (not the Organisation profile)."""
    from rdflib import Graph
    graphs = {}
    with zipfile.ZipFile(path) as zf:
        for name in zf.namelist():
            if name.endswith(".xml") and not name.startswith("Org-"):
                graph = Graph()
                graph.parse(io.BytesIO(zf.read(name)), format="xml")
                graphs[name] = graph
    return graphs


def check_data_rules(path):
    """The violations (list of text) of the dataset's data rules:
    - PATL > 0 for every secured element, and not above the CGM TATL of branches the dataset writes a PATL for;
    - every RA mRID in one RA file only; every curative RA with a readable timeToImplement;
    - every bid with a direction, a volume and a price at the run timestamp;
    - every HVDC balanced group with exactly two members;
    - every countertrade zone with at least two usable generators."""
    from rdflib import Namespace, RDF
    import sys
    nc, cim = Namespace(ENUM), Namespace(CIM_NS)
    sys.path.insert(0, str(Path(__file__).resolve().parents[1] / "src" / "rao"))
    from pre_milp.ncp_parser import _parse_iso_duration_hours_or_none

    graphs = read_package(path)
    violations = []
    # PATL: BaseCaseCurrentLimit and SHS values
    shs_points = {}
    for name, graph in graphs.items():
        if name.endswith("_SHS.xml"):
            schedules = {s: graph.value(s, nc["CurrentLimitSchedule.CurrentLimit"]) for s in graph.subjects(RDF.type, nc.CurrentLimitSchedule)}
            for point in graph.subjects(RDF.type, nc.CurrentLimitTimePoint):
                if str(graph.value(point, nc["CurrentLimitTimePoint.atTime"])) == RUN_TIME:
                    limit = schedules.get(graph.value(point, nc["CurrentLimitTimePoint.CurrentLimitSchedule"]))
                    shs_points[str(limit).rsplit("#_", 1)[-1]] = float(graph.value(point, nc["CurrentLimitTimePoint.value"]))
    for name, graph in graphs.items():
        if not name.endswith("_AE.xml"):
            continue
        for ae in graph.subjects(RDF.type, nc.AssessedElement):
            if graph.value(ae, nc["AssessedElement.SecuredForRegion"]) is None or graph.value(ae, nc["AssessedElement.exclusionReason"]) is not None:
                continue
            branch = graph.value(ae, nc["AssessedElement.ConductingEquipment"]) or graph.value(ae, nc["AssessedElement.Line"])
            limit = graph.value(ae, nc["AssessedElement.OperationalLimit"])
            branch_mrid = str(branch).rsplit("#_", 1)[-1]
            limit_mrid = str(limit).rsplit("#_", 1)[-1] if limit is not None else None
            value = shs_points.get(limit_mrid)
            if value is None and limit is not None and graph.value(limit, nc["BaseCaseCurrentLimit.normalValue"]) is not None:
                value = float(graph.value(limit, nc["BaseCaseCurrentLimit.normalValue"]))
            if value is None and branch_mrid == SER_RLC:
                value = SER_RLC_CGM_PATL_A
            if value is not None and value <= 0:
                violations.append(f"{name}: secured AE on {branch_mrid} has PATL {value} <= 0")
            tatl = CGM_TATL_A.get(branch_mrid)
            if value is not None and branch_mrid in CGM_TATL_A and tatl is not None and value > tatl:
                violations.append(f"{name}: PATL {value} A of {branch_mrid} above its CGM TATL {tatl} A")
    # RAs
    ra_files = {}
    for name, graph in graphs.items():
        if not name.endswith("_RA.xml"):
            continue
        for cls in (nc.GridStateAlterationRemedialAction, nc.CountertradeRemedialAction):
            for ra in graph.subjects(RDF.type, cls):
                mrid = str(graph.value(ra, cim["IdentifiedObject.mRID"]))
                ra_files.setdefault(mrid, []).append(name)
                if "curative" in str(graph.value(ra, nc["RemedialAction.kind"])):
                    duration = graph.value(ra, nc["RemedialAction.timeToImplement"])
                    if duration is None or _parse_iso_duration_hours_or_none(str(duration)) is None:
                        violations.append(f"{name}: curative RA {mrid} without a readable timeToImplement")
    violations += [f"RA {mrid} in several RA files {files}" for mrid, files in ra_files.items() if len(files) > 1]
    # bids
    for name, graph in graphs.items():
        if not name.endswith("_SIS.xml"):
            continue
        points = {}
        for point in graph.subjects(RDF.type, nc.PowerBidScheduleTimePoint):
            if str(graph.value(point, nc["PowerBidScheduleTimePoint.atTime"])) == RUN_TIME:
                points[graph.value(point, nc["PowerBidScheduleTimePoint.PowerBidSchedule"])] = point
        for bid in graph.subjects(RDF.type, nc.PowerBidSchedule):
            point = points.get(bid)
            if graph.value(bid, nc["PowerBidSchedule.direction"]) is None or point is None \
                    or graph.value(point, nc["PowerBidScheduleTimePoint.p"]) is None \
                    or graph.value(point, nc["PowerBidScheduleTimePoint.price"]) is None:
                violations.append(f"{name}: bid {bid} without direction, volume or price at {RUN_TIME}")
    # HVDC groups and countertrade zones
    for name, graph in graphs.items():
        if not name.endswith("_RA.xml"):
            continue
        members = {}
        for dependency in graph.subjects(RDF.type, nc.RemedialActionDependency):
            if str(graph.value(dependency, nc["RemedialActionDependency.kind"])).endswith(".balanced"):
                group = graph.value(dependency, nc["RemedialActionDependency.DependingRemedialActionGroup"]) or \
                    graph.value(dependency, nc["RemedialActionDependency.RemedialActionGroup"])
                members.setdefault(group, set()).add(graph.value(dependency, nc["RemedialActionDependency.RemedialAction"]))
        violations += [f"{name}: balanced group {g} with {len(m)} members" for g, m in members.items() if len(m) != 2]
        for ra in graph.subjects(RDF.type, nc.CountertradeRemedialAction):
            zone = str(graph.value(ra, nc["PowerRemedialAction.BiddingZone"])).rsplit("#_", 1)[-1]
            if len(CT_ZONE_UNITS.get(zone, ())) < 2:
                violations.append(f"{name}: countertrade zone {zone} with fewer than two usable generators")
    return violations


# ---------------------------------------------------------------------------
# shared-bid redispatch use cases (docs/data/ncp_dataset_coverage.md section 8): redispatch RAs whose bid is shared by
# several generating units through participation factors, built on the standard-form mock P (the existing RD RAs of
# the generators involved are removed, so the shared bid is their only RD route; everything else stays).
# Not part of VARIANTS: the variants of the dataset are built on the old-form builders, these on P itself.
# ---------------------------------------------------------------------------

ZONE_ESPHEIM = "cf8a8cc9-4b94-4983-8a36-e3f84888f461"
ZONE_GALIA_SHARED = ct_mock.ZONE_GALIA
BREED_UNIT, PHILO_UNIT = "0a3ae8d8-5c36-b14e-1f01-74fffe7a1be0", "cd1eb711-7df2-e214-423a-b6c54fcb40d5"
GALIA_G1_UNIT, GALIA_G2_UNIT, GALIA_G3_UNIT = (
    "2a2d438f-41b3-a9ea-f897-20ae9f28fbec", "6abc98ff-2596-a3ed-4540-f77045fad7bc", "aa9b291a-1be8-7a5f-0820-f56c324b22b2")
CABINCRK_UNIT, CLAYTOR_UNIT ="a9144b56-c94a-0575-565d-665d36cf7e06", "66943952-afa5-ff3b-42b0-60b9c9d0badf"
# the 5 contingencies of Espheim_CO.xml (the links of the curative RD RAs of P)
ESPHEIM_CONTINGENCIES = [
    "b6b780cb-9fe5-4c45-989d-447a927c3874", "13334fdf-9cc2-4341-adb6-1281269040b4", "9d17b84c-33b5-4a68-b8b9-ed5b31038d40",
    "ce19dd34-429e-4b72-8813-7615cc57b4a4", "62eac668-82a1-4739-8cfc-de929b78ef7e",
]

# case -> {tso, drop: names of the P redispatch RAs removed, ras: the new RAs}. An RA: name, direction (up p>0, down
# p<0), kind, bid_route (True: the bid has its own PowerShiftKeyDistribution, False: the RA has a
# PowerShiftKeyStrategy), zone, contingencies (None: no link), volume MW, price EUR/MW, units [(CIM unit, factor)]
def _pair(stem, tso, kind, bid_route, zone, contingencies, volume, price, units):
    return [dict(name=f"{stem}_{direction.upper()}", direction=direction, kind=kind, bid_route=bid_route, zone=zone,
                 contingencies=contingencies, volume=volume, price=price, units=units) for direction in ("up", "down")]


_A_UNITS = [(BREED_UNIT, 0.6), (PHILO_UNIT, 0.4)]
_GALIA_UNITS = [(GALIA_G1_UNIT, 0.5), (GALIA_G2_UNIT, 0.3), (GALIA_G3_UNIT, 0.2)]
_GALIA_DROP = ["PRA_RD_GA_G1_UP", "PRA_RD_GA_G1_DOWN", "PRA_RD_GA_G2_UP", "PRA_RD_GA_G2_DOWN",
               "CRA_RD_GA_G1_UP", "CRA_RD_GA_G1_DOWN", "CRA_RD_GA_G3_UP", "CRA_RD_GA_G3_DOWN"]
SHARED_BID_CASES = {
    "A": dict(tso="Espheim", drop=["PRA_RD_ES_BREED_UP", "PRA_RD_ES_BREED_DOWN", "PRA_RD_ES_PHILO_UP", "PRA_RD_ES_PHILO_DOWN"],
              ras=_pair("PRA_RD_ES_BREED_PHILO", "Espheim", "preventive", True, ZONE_ESPHEIM, None, 100, 90, _A_UNITS)),
    "B_preventive": dict(tso="Galia", drop=_GALIA_DROP,
                         ras=_pair("PRA_RD_GA_G123", "Galia", "preventive", False, ZONE_GALIA_SHARED, None, 150, 60, _GALIA_UNITS)),
    # D_espheim: the four Espheim generators at four substations (Breed, Philo, CabinCrk, Claytor). Preventive downs with
    # 3 and 2 units (the useful preventive direction: Breed relieves CL5 when it goes down), curative downs with 3 and 2
    # units on the units with the weakest effect on the curative overload (23-25 under CO2), the kept curative ups of
    # CabinCrk and Claytor of P as balance partners (the curative downs of P on the same two units would cancel them:
    # removed, as are the preventive RAs of Breed and Philo of P)
    "D_espheim": dict(
        tso="Espheim",
        drop=["PRA_RD_ES_BREED_UP", "PRA_RD_ES_BREED_DOWN", "PRA_RD_ES_PHILO_UP", "PRA_RD_ES_PHILO_DOWN",
              "CRA_RD_ES_CABINCRK_DOWN", "CRA_RD_ES_CLAYTOR_DOWN"],
        ras=[
            dict(name="PRA_RD_ES_SHARED3_DOWN", direction="down", kind="preventive", bid_route=True, zone=ZONE_ESPHEIM,
                 contingencies=None, volume=60, price=85,
                 units=[(BREED_UNIT, 0.5), (PHILO_UNIT, 0.3), (CLAYTOR_UNIT, 0.2)]),
            dict(name="PRA_RD_ES_SHARED2_DOWN", direction="down", kind="preventive", bid_route=True, zone=ZONE_ESPHEIM,
                 contingencies=None, volume=40, price=90, units=[(BREED_UNIT, 0.6), (PHILO_UNIT, 0.4)]),
            dict(name="CRA_RD_ES_SHARED3_DOWN", direction="down", kind="curative", bid_route=False, zone=ZONE_ESPHEIM,
                 contingencies=ESPHEIM_CONTINGENCIES, volume=100, price=85,
                 units=[(BREED_UNIT, 0.5), (PHILO_UNIT, 0.3), (CLAYTOR_UNIT, 0.2)]),
            dict(name="CRA_RD_ES_SHARED2_DOWN", direction="down", kind="curative", bid_route=False, zone=ZONE_ESPHEIM,
                 contingencies=ESPHEIM_CONTINGENCIES, volume=40, price=90, units=[(BREED_UNIT, 0.6), (PHILO_UNIT, 0.4)]),
        ]),
}
SHARED_BID_CASES["A_strategy"] = dict(
    SHARED_BID_CASES["A"], ras=[dict(ra, bid_route=False) for ra in SHARED_BID_CASES["A"]["ras"]])
# B and C of round 1 (a curative up / down pair on one key) were dropped: they could not be activated (no other RA was
# linked to the contingency, the curative balance of a contingency sums to 0). C_preventive: bids of 200 MW, the
# first unit limit (GA-G2 at 45 MW) stops the total at 150 MW
SHARED_BID_CASES["C_preventive"] = dict(
    SHARED_BID_CASES["B_preventive"], ras=[dict(ra, volume=200) for ra in SHARED_BID_CASES["B_preventive"]["ras"]])


def shared_bid_ras(case, overrides=None):
    """The new RAs of the case with their deterministic ids: dicts with mrid, bid, strategy and sign added.
    overrides: {RA name: {field: value}} (for example price or volume) applied before."""
    result = []
    for ra in SHARED_BID_CASES[case]["ras"]:
        ra = dict(ra, **(overrides or {}).get(ra["name"], {}))
        result.append(dict(ra, mrid=_uid("shared ra", ra["name"]), bid=_uid("shared bid", ra["name"]),
                           strategy=_uid("shared strategy", ra["name"]), sign=1 if ra["direction"] == "up" else -1))
    return result


def shared_bid_ra_pair(case):
    """{direction: RA dict} of a case with one up and one down RA (A, A_strategy, B_preventive, C_preventive)."""
    return {ra["direction"]: ra for ra in shared_bid_ras(case)}


def _ra_mrid_of(text, name):
    match = re.search(rf'<nc:RedispatchRemedialAction rdf:ID="_([^"]+)"\s*>(?:(?!</nc:RedispatchRemedialAction>).)*?'
                      rf'<cim:IdentifiedObject.name>{re.escape(name)}<', text, re.S)
    if match is None:
        raise ValueError(f"redispatch RA {name} not found")
    return match.group(1)


def _drop_rd_ras(ra_text, sis_text, names):
    """(ra_text, sis_text) without the redispatch RAs `names`, their strategies, contingency links, bids, bid time
    points, key distributions, key schedules and participation factors."""
    for name in names:
        ra = _ra_mrid_of(ra_text, name)
        strategies = elements_referring_to(ra_text, "nc:PowerShiftKeyStrategy", ra)
        links = elements_referring_to(ra_text, "nc:ContingencyWithRemedialAction", ra)
        bids = elements_referring_to(sis_text, "nc:PowerBidSchedule", ra)
        points = [p for bid in bids for p in elements_referring_to(sis_text, "nc:PowerBidScheduleTimePoint", bid)]
        distributions = sorted({d for owner in strategies + bids
                                for d in elements_referring_to(sis_text, "nc:PowerShiftKeyDistribution", owner)})
        keys = set()
        for distribution in distributions:
            start, end = _element(sis_text, distribution)
            keys.update(re.findall(r'PowerShiftKeySchedule rdf:resource="#_([^"]+)"', sis_text[start:end]))
        factors = [f for key in keys for f in elements_referring_to(sis_text, "nc:ParticipationFactorTimePoint", key)]
        for element in strategies + links:
            ra_text = drop_element(ra_text, element)
        ra_text = drop_element(ra_text, ra)
        for element in points + factors + distributions + sorted(keys) + bids:
            sis_text = drop_element(sis_text, element)
    return ra_text, sis_text


def _shared_bid_blocks(case, overrides=None):
    """(RA-file block, SIS-file block) with the new RAs of the case in the standard form."""
    ra_parts, sis_parts = [], []
    for item in shared_bid_ras(case, overrides):
        mrid, bid, strategy, direction = item["mrid"], item["bid"], item["strategy"], item["direction"]
        ra_parts.append(f"""  <nc:RedispatchRemedialAction rdf:ID="_{mrid}">
    <nc:PowerRemedialAction.BiddingZone rdf:resource="#_{item['zone']}"/>
    <cim:IdentifiedObject.description>Shared-bid use case {case}: {direction} redispatch over {len(item['units'])} generating units.</cim:IdentifiedObject.description>
    <cim:IdentifiedObject.mRID>{mrid}</cim:IdentifiedObject.mRID>
    <cim:IdentifiedObject.name>{item['name']}</cim:IdentifiedObject.name>
    <nc:RemedialAction.isCrossBorderRelevant>true</nc:RemedialAction.isCrossBorderRelevant>
    <nc:RemedialAction.kind rdf:resource="{ENUM}RemedialActionKind.{item['kind']}"/>
    <nc:RemedialAction.normalAvailable>true</nc:RemedialAction.normalAvailable>
    <nc:RemedialAction.penaltyFactor>1.0</nc:RemedialAction.penaltyFactor>
  </nc:RedispatchRemedialAction>""")
        if not item["bid_route"]:
            ra_parts.append(f"""  <nc:PowerShiftKeyStrategy rdf:ID="_{strategy}">
    <cim:IdentifiedObject.mRID>{strategy}</cim:IdentifiedObject.mRID>
    <nc:PowerShiftKeyStrategy.PowerRemedialAction rdf:resource="#_{mrid}"/>
  </nc:PowerShiftKeyStrategy>""")
        for contingency in item["contingencies"] or []:
            ra_parts.append(link_xml(mrid, contingency).replace(
                "</nc:ContingencyWithRemedialAction>",
                f'  <nc:ContingencyWithRemedialAction.combinationConstraintKind rdf:resource="{ENUM}ElementCombinationConstraintKind.included"/>\n  </nc:ContingencyWithRemedialAction>'))
        sis_parts.append(f"""  <nc:PowerBidSchedule rdf:ID="_{bid}">
    <cim:IdentifiedObject.mRID>{bid}</cim:IdentifiedObject.mRID>
    <cim:IdentifiedObject.name>PB_{item['name']}</cim:IdentifiedObject.name>
    <nc:PowerBidSchedule.PowerRemedialAction rdf:resource="#_{mrid}"/>
    <nc:PowerBidSchedule.currency rdf:resource="{CIM_NS}Currency.EUR"/>
    <nc:PowerBidSchedule.direction rdf:resource="{ENUM}MarketRegulationDirectionKind.{direction}"/>
    <nc:PowerBidSchedule.leadTime>P0Y0M0DT0H0M0S</nc:PowerBidSchedule.leadTime>
    <nc:PowerBidSchedule.activationCost>0</nc:PowerBidSchedule.activationCost>
    <nc:PowerBidSchedule.priority>1</nc:PowerBidSchedule.priority>
    <nc:BaseTimeSeries.interpolationKind rdf:resource="{ENUM}TimeSeriesInterpolationKind.next"/>
  </nc:PowerBidSchedule>
  <nc:PowerBidScheduleTimePoint rdf:ID="_{_uid('shared bid point', bid)}">
    <nc:PowerBidScheduleTimePoint.atTime>{RUN_TIME}</nc:PowerBidScheduleTimePoint.atTime>
    <nc:PowerBidScheduleTimePoint.PowerBidSchedule rdf:resource="#_{bid}"/>
    <nc:PowerBidScheduleTimePoint.p>{item['sign'] * item['volume']}</nc:PowerBidScheduleTimePoint.p>
    <nc:PowerBidScheduleTimePoint.price>{item['price']}</nc:PowerBidScheduleTimePoint.price>
  </nc:PowerBidScheduleTimePoint>""")
        keys = []
        for index, (unit, factor) in enumerate(item["units"]):
            key = _uid("shared key", item["name"], index)
            keys.append(key)
            sis_parts.append(f"""  <nc:PowerShiftKeySchedule rdf:ID="_{key}">
    <cim:IdentifiedObject.mRID>{key}</cim:IdentifiedObject.mRID>
    <cim:IdentifiedObject.name>PSKS_{item['name']}_{index + 1}</cim:IdentifiedObject.name>
    <nc:PowerShiftKeySchedule.GeneratingUnit rdf:resource="#_{unit}"/>
    <nc:BaseTimeSeries.interpolationKind rdf:resource="{ENUM}TimeSeriesInterpolationKind.none"/>
  </nc:PowerShiftKeySchedule>
  <nc:ParticipationFactorTimePoint rdf:ID="_{_uid('shared factor point', key)}">
    <nc:ParticipationFactorTimePoint.atTime>{RUN_TIME}</nc:ParticipationFactorTimePoint.atTime>
    <nc:ParticipationFactorTimePoint.participationFactor>{factor}</nc:ParticipationFactorTimePoint.participationFactor>
    <nc:ParticipationFactorTimePoint.PowerShiftKeySchedule rdf:resource="#_{key}"/>
  </nc:ParticipationFactorTimePoint>""")
        owner = "PowerBidSchedule" if item["bid_route"] else "PowerShiftKeyStrategy"
        owner_id = bid if item["bid_route"] else strategy
        # bid route: one distribution with all the keys; strategy route: one distribution per key
        groups = [keys] if item["bid_route"] else [[key] for key in keys]
        for index, group in enumerate(groups):
            distribution = _uid("shared distribution", item["name"], index)
            refs = "".join(f'\n    <nc:PowerShiftKeyDistribution.PowerShiftKeySchedule rdf:resource="#_{key}"/>' for key in group)
            sis_parts.append(f"""  <nc:PowerShiftKeyDistribution rdf:ID="_{distribution}">
    <cim:IdentifiedObject.mRID>{distribution}</cim:IdentifiedObject.mRID>
    <nc:PowerShiftKeyDistribution.{owner} rdf:resource="#_{owner_id}"/>{refs}
  </nc:PowerShiftKeyDistribution>""")
    return "\n".join(ra_parts), "\n".join(sis_parts)


def build_shared_bid_ncp(dest, case, source=None, overrides=None):
    """The standard-form mock P with the new RAs of SHARED_BID_CASES[case] (the RD RAs of its generators removed).
    Nothing else changes; the zip entries are written with fixed time stamps. overrides: see shared_bid_ras."""
    spec = SHARED_BID_CASES[case]
    dest = Path(dest)
    ra_name, sis_name = f"{spec['tso']}_RA.xml", f"{spec['tso']}_SIS.xml"
    with zipfile.ZipFile(base_zip() if source is None else source) as zin, zipfile.ZipFile(dest, "w") as zout:
        ra_text, sis_text = zin.read(ra_name).decode("utf-8"), zin.read(sis_name).decode("utf-8")
        ra_text, sis_text = _drop_rd_ras(ra_text, sis_text, spec["drop"])
        ra_block, sis_block = _shared_bid_blocks(case, overrides)
        ra_text, sis_text = append_block(ra_text, ra_block), append_block(sis_text, sis_block)
        for item in zin.infolist():
            data = {ra_name: ra_text.encode("utf-8"), sis_name: sis_text.encode("utf-8")}.get(item.filename)
            zout.writestr(_fixed_entry(item.filename), data if data is not None else zin.read(item.filename))
    return dest
