"""convert_ncp_to_standard.py - rewrite an old-form mock NCP zip into the standard form of the
ENTSO-E profiles (RemedialAction 2.5, StateInstructionSchedule 2.5).

Not imported by src/. Values and units are never changed; only the shape of the data is. The one exception is the
sign of the bid volumes (bids section, option correct_bid_signs): down bids get p < 0 and up bids p > 0 with the same |p|.
Six independent sections (each can be switched off):

  groups        dependency predicate `RemedialActionGroup` -> `DependingRemedialActionGroup`; group limits on the
                chain RemedialActionGroupTimePoint -> RemedialActionGroupSchedule -> RemedialActionGroup with the
                limits declared by RemedialActionGroupTimePoint
  bids          direction literal -> MarketRegulationDirectionKind, interpolationKind on every bid schedule;
                options: drop_nonstandard_bid_attributes, strip_direction_of (one bid without a direction)
  redispatch    GridStateAlterationRemedialAction with RotatingMachineActions -> RedispatchRemedialAction (+ its
                bidding zone from the Organisation profile); both unit routes (bid route, and RA strategy route
                through a PowerShiftKeyStrategy element that points at the RA)
  glsk          PowerShiftKeySchedule.GeneratingUnit carries the CIM GeneratingUnit id (needs the CGM zip);
                interpolationKind on every shift key schedule
  countertrade  old-version attributes gLSKStrategy (RA and bid), powerShiftKey, method are removed
  other         dataset header conformsTo; AssessedElementSchedule / AssessedElementTimePoint (option)

Every change is written to the conversion log. A file that needs no change is returned byte for byte, so
converting a standard file changes nothing and converting twice gives the same bytes.

Usage: python mock_data/convert_ncp_to_standard.py OLD.zip NEW.zip --cgm CGM.zip [--log LOG.csv]
       [--skip SECTION ...] [--routes bid|strategy|both] [--strip-direction BID_MRID]
       [--ae-schedule TSO:AE_MRID:true|false] [--drop-nonstandard-bid-attributes]
       [--keep-bid-signs]
"""
from __future__ import annotations

import argparse
import csv
import io
import re
import sys
import uuid
import xml.etree.ElementTree as ET
import zipfile
from dataclasses import dataclass, field
from pathlib import Path
from typing import Optional

NC = "https://cim4.eu/ns/nc#"
CIM = "https://cim.ucaiug.io/ns#"
RDF = "http://www.w3.org/1999/02/22-rdf-syntax-ns#"
SECTIONS = ("groups", "bids", "redispatch", "glsk", "countertrade", "other")
_UUID_NAMESPACE = uuid.UUID("5c1f3b1e-9d2a-4e47-9a53-0b6f6a6c1d10")
_RUN_TIME = "2022-06-15T10:30:00Z"
_PROFILE_VERSION = {"RA": "https://ap.cim4.eu/RemedialAction/", "SIS": "https://ap.cim4.eu/StateInstructionSchedule/"}
_NON_STANDARD_BID_ATTRIBUTES = ("penaltyFactor", "minEnergyBid", "maxEnergyBid", "stepSizeCTRD")


def _nc(local: str) -> str:
    return f"{{{NC}}}{local}"


def _cim(local: str) -> str:
    return f"{{{CIM}}}{local}"


def _rdf(local: str) -> str:
    return f"{{{RDF}}}{local}"


def _local(tag: str) -> str:
    return tag.rsplit("}", 1)[-1]


def _fragment(uri: Optional[str]) -> str:
    return (uri or "").rsplit("#", 1)[-1].lstrip("_")


def new_id(*parts: str) -> str:
    """A deterministic UUID from the given key parts."""
    return str(uuid.uuid5(_UUID_NAMESPACE, "|".join(parts)))


@dataclass
class Options:
    sections: tuple = SECTIONS
    group_limit_chain: bool = True             # groups: also move the limits to the schedule / time point chain
    routes: str = "both"                       # redispatch unit routes: bid, strategy, both
    drop_nonstandard_bid_attributes: bool = False
    correct_bid_signs: bool = True             # bids: p < 0 for a down bid, p > 0 for an up bid (same |p|)
    strip_direction_of: tuple = ()             # bid mRIDs written without a direction (test variant)
    ae_schedules: tuple = ()                   # (tso, assessed element mRID, enabled) triples


@dataclass
class Log:
    entries: list = field(default_factory=list)

    def add(self, file: str, section: str, action: str, element: str = "", detail: str = "") -> None:
        self.entries.append({"file": file, "section": section, "action": action, "element": element, "detail": detail})


class Doc:
    """One parsed RDF/XML file; `changed` is set by every edit."""

    def __init__(self, name: str, data: bytes):
        self.name = name
        self.original = data
        text = data.decode("utf-8")
        for prefix, uri in re.findall(r'xmlns:([A-Za-z0-9_.-]+)="([^"]+)"', text):
            try:
                ET.register_namespace(prefix, uri)
            except ValueError:      # a prefix of the form ns<digits> is reserved by ElementTree; it gets a generated one
                pass
        builder = ET.TreeBuilder(insert_comments=True)
        self.root = ET.XMLParser(target=builder)
        self.root.feed(data)
        self.root = self.root.close()
        self.changed = False

    def elements(self, local: str):
        return [e for e in self.root if _local(e.tag) == local and e.tag.startswith("{" + NC)]

    @staticmethod
    def ident(element) -> str:
        return _fragment(element.get(_rdf("ID")) or element.get(_rdf("about")))

    def by_id(self, local: str) -> dict:
        return {self.ident(e): e for e in self.elements(local)}

    def dump(self) -> bytes:
        if not self.changed:
            return self.original
        ET.indent(self.root, space="  ")
        return ET.tostring(self.root, encoding="utf-8", xml_declaration=True) + b"\n"


def _child(element, tag: str):
    for c in element:
        if c.tag == tag:
            return c
    return None


def _children(element, tag: str):
    return [c for c in element if c.tag == tag]


def _text(element, tag: str) -> str:
    c = _child(element, tag)
    return (c.text or "").strip() if c is not None else ""


def _ref(element, tag: str) -> str:
    c = _child(element, tag)
    return _fragment(c.get(_rdf("resource"))) if c is not None else ""


def _new_element(tag: str, ident: str, about: bool = False):
    e = ET.Element(tag)
    e.set(_rdf("about") if about else _rdf("ID"), ("#_" if about else "_") + ident)
    return e


def _add_literal(element, tag: str, value: str):
    c = ET.SubElement(element, tag)
    c.text = value
    return c


def _add_ref(element, tag: str, ident: str):
    c = ET.SubElement(element, tag)
    c.set(_rdf("resource"), "#_" + ident)
    return c


def _add_enum(element, tag: str, uri: str):
    c = ET.SubElement(element, tag)
    c.set(_rdf("resource"), uri)
    return c


def _identified(element, ident: str, name: str = "", description: str = ""):
    if description:
        _add_literal(element, _cim("IdentifiedObject.description"), description)
    _add_literal(element, _cim("IdentifiedObject.mRID"), ident)
    if name:
        _add_literal(element, _cim("IdentifiedObject.name"), name)


def _last_word(value: str) -> str:
    return re.split(r"[#.]", value)[-1]


def _insert_after(root, new, anchor) -> None:
    root.insert(list(root).index(anchor) + 1, new)


def _insert_before(root, new, anchor) -> None:
    root.insert(list(root).index(anchor), new)


# ---------------------------------------------------------------------------
# section: groups
# ---------------------------------------------------------------------------

def convert_groups(files: dict, options: Options, log: Log) -> None:
    for name, doc in files.items():
        if name.endswith("_RA.xml"):
            for dep in doc.elements("RemedialActionDependency"):
                old = _child(dep, _nc("RemedialActionDependency.RemedialActionGroup"))
                if old is not None and _child(dep, _nc("RemedialActionDependency.DependingRemedialActionGroup")) is None:
                    old.tag = _nc("RemedialActionDependency.DependingRemedialActionGroup")
                    doc.changed = True
                    log.add(name, "groups", "renamed predicate", Doc.ident(dep),
                            "RemedialActionDependency.RemedialActionGroup -> .DependingRemedialActionGroup")
        if name.endswith("_SIS.xml") and options.group_limit_chain:
            _convert_group_limits(name, doc, log)


def _convert_group_limits(name: str, doc: Doc, log: Log) -> None:
    schedules = {}
    for point in doc.elements("RemedialActionGroupTimePoint"):
        link = _child(point, _nc("RemedialActionGroupTimePoint.RemedialActionGroup"))
        if link is None:
            continue
        group = _fragment(link.get(_rdf("resource")))
        if group not in schedules:
            schedule_id = new_id("group-schedule", group)
            schedule = _new_element(_nc("RemedialActionGroupSchedule"), schedule_id)
            _identified(schedule, schedule_id, name=f"Limits of group {group}")
            _add_ref(schedule, _nc("RemedialActionGroupSchedule.RemedialActionGroup"), group)
            _add_enum(schedule, _nc("BaseTimeSeries.interpolationKind"), NC + "TimeSeriesInterpolationKind.none")
            _insert_before(doc.root, schedule, point)
            schedules[group] = schedule_id
            log.add(name, "groups", "added", schedule_id, f"RemedialActionGroupSchedule of group {group}, interpolationKind none")
        index = list(point).index(link)
        point.remove(link)
        ref = ET.Element(_nc("RemedialActionGroupTimePoint.RemedialActionGroupSchedule"))
        ref.set(_rdf("resource"), "#_" + schedules[group])
        point.insert(index, ref)
        for limit in ("maxRegulatingUp", "maxRegulatingDown"):
            old = _child(point, _nc(f"RemedialActionGroup.{limit}"))
            if old is not None:
                old.tag = _nc(f"RemedialActionGroupTimePoint.{limit}")
        doc.changed = True
        log.add(name, "groups", "re-linked time point", group,
                "RemedialActionGroupTimePoint.RemedialActionGroup -> .RemedialActionGroupSchedule; "
                "RemedialActionGroup.maxRegulating* -> RemedialActionGroupTimePoint.maxRegulating*")


# ---------------------------------------------------------------------------
# section: bids
# ---------------------------------------------------------------------------

def convert_bids(files: dict, options: Options, log: Log) -> None:
    for name, doc in files.items():
        if not name.endswith("_SIS.xml"):
            continue
        points_of_bid: dict = {}
        for point in doc.elements("PowerBidScheduleTimePoint"):
            points_of_bid.setdefault(_ref(point, _nc("PowerBidScheduleTimePoint.PowerBidSchedule")), []).append(point)
        for bid in doc.elements("PowerBidSchedule"):
            bid_id = Doc.ident(bid)
            direction = _child(bid, _nc("PowerBidSchedule.direction"))
            if direction is not None and bid_id in options.strip_direction_of:
                bid.remove(direction)
                doc.changed = True
                log.add(name, "bids", "removed direction (test variant)", bid_id, direction.get(_rdf("resource"), ""))
            elif direction is not None:
                word = _last_word(direction.get(_rdf("resource"), ""))
                target = f"{NC}MarketRegulationDirectionKind.{word}"
                if direction.get(_rdf("resource")) != target:
                    log.add(name, "bids", "direction literal", bid_id, f"{direction.get(_rdf('resource'))} -> {target}")
                    direction.set(_rdf("resource"), target)
                    doc.changed = True
            direction_now = _child(bid, _nc("PowerBidSchedule.direction"))
            if options.correct_bid_signs and direction_now is not None:
                word = _last_word(direction_now.get(_rdf("resource"), ""))
                if word in ("up", "down"):
                    for point in points_of_bid.get(bid_id, []):
                        p = _child(point, _nc("PowerBidScheduleTimePoint.p"))
                        if p is None or not (p.text or "").strip():
                            continue
                        value = p.text.strip()
                        magnitude = value[1:] if value.startswith(("-", "+")) else value
                        target = ("-" if word == "down" and float(magnitude) != 0 else "") + magnitude
                        if target != value:
                            log.add(name, "bids", "bid sign", bid_id, f"PowerBidScheduleTimePoint.p {value} -> {target} ({word} bid)")
                            p.text = target
                            doc.changed = True
            if _child(bid, _nc("BaseTimeSeries.interpolationKind")) is None:
                _add_enum(bid, _nc("BaseTimeSeries.interpolationKind"), NC + "TimeSeriesInterpolationKind.none")
                doc.changed = True
                log.add(name, "bids", "added interpolationKind none", bid_id, "no interpolation, as the parser reads exact time points")
            for attribute in _NON_STANDARD_BID_ATTRIBUTES:
                old = _child(bid, _nc(f"PowerBidSchedule.{attribute}"))
                if old is None:
                    continue
                if options.drop_nonstandard_bid_attributes:
                    bid.remove(old)
                    doc.changed = True
                    log.add(name, "bids", "removed non-standard attribute", bid_id, f"PowerBidSchedule.{attribute}={old.text}")
                else:
                    log.add(name, "bids", "kept non-standard attribute", bid_id, f"PowerBidSchedule.{attribute}={old.text} (the parser still reads it)")


# ---------------------------------------------------------------------------
# section: redispatch (+ unit routes)
# ---------------------------------------------------------------------------

def bidding_zone_by_tso(organisation: Optional[Doc]) -> dict:
    """{TSO name without 'TSO-': bidding zone mRID} from the Organisation profile."""
    if organisation is None:
        return {}
    tso_name = {Doc.ident(t): _text(t, _cim("IdentifiedObject.name")) for t in organisation.elements("TransmissionSystemOperator")}
    result = {}
    for area in organisation.elements("SchedulingArea"):
        name = tso_name.get(_ref(area, _nc("SchedulingArea.SystemOperator")), "")
        zone = _ref(area, _nc("SchedulingArea.BiddingZone"))
        if name and zone:
            result[name.removeprefix("TSO-")] = zone
    return result


def convert_redispatch(files: dict, options: Options, zones: dict, log: Log) -> None:
    for name in sorted(files):
        if not name.endswith("_RA.xml"):
            continue
        tso = name.removesuffix("_RA.xml")
        ra_doc = files[name]
        sis_doc = files.get(f"{tso}_SIS.xml")
        machines: dict = {}
        for action in ra_doc.elements("RotatingMachineAction"):
            machines.setdefault(_ref(action, _nc("GridStateAlteration.GridStateAlterationRemedialAction")), []).append(action)
        if not machines:
            continue
        other_actions = set()
        for local in ("TapPositionAction", "EquivalentInjectionAction"):
            for action in ra_doc.elements(local):
                other_actions.add(_ref(action, _nc("GridStateAlteration.GridStateAlterationRemedialAction")))
        converted = []
        for gsara in list(ra_doc.elements("GridStateAlterationRemedialAction")):
            ra_id = Doc.ident(gsara)
            actions = machines.get(ra_id)
            if not actions:
                continue
            if ra_id in other_actions:
                log.add(name, "redispatch", "skipped", ra_id, "the RA also has a tap position or equivalent injection action; left unchanged")
                continue
            _convert_one_redispatch(name, ra_doc, gsara, actions, zones.get(tso), log)
            converted.append(ra_id)
        if converted and sis_doc is not None and options.routes in ("strategy", "both"):
            _add_strategy_routes(name, ra_doc, sis_doc, converted, log)


def _convert_one_redispatch(name, ra_doc, gsara, actions, zone, log) -> None:
    ra_id = Doc.ident(gsara)
    new = ET.Element(_nc("RedispatchRemedialAction"), dict(gsara.attrib))
    for child in gsara:
        if child.tag == _nc("GridStateAlterationRemedialAction.isActivationRestricted"):
            log.add(name, "redispatch", "removed", ra_id, "GridStateAlterationRemedialAction.isActivationRestricted (not an attribute of RedispatchRemedialAction)")
            continue
        new.append(child)
    if zone is not None:
        zone_ref = ET.Element(_nc("PowerRemedialAction.BiddingZone"))
        zone_ref.set(_rdf("resource"), "#_" + zone)
        new.insert(0, zone_ref)
        log.add(name, "redispatch", "added bidding zone", ra_id, zone)
    else:
        log.add(name, "redispatch", "no bidding zone", ra_id, "the Organisation profile gives none for this TSO (association is optional)")
    ra_doc.root.insert(list(ra_doc.root).index(gsara), new)
    ra_doc.root.remove(gsara)
    for action in actions:
        ra_doc.root.remove(action)
        rates = {k: _text(action, _nc(f"RotatingMachineAction.{k}")) for k in ("raiseRampRate", "lowerRampRate")}
        log.add(name, "redispatch", "removed RotatingMachineAction", Doc.ident(action),
                f"machine {_ref(action, _nc('RotatingMachineAction.RotatingMachine'))}; ramp rates {rates} are not in the profile")
    ra_doc.changed = True
    log.add(name, "redispatch", "class", ra_id, "GridStateAlterationRemedialAction -> RedispatchRemedialAction")


def _add_strategy_routes(ra_name, ra_doc, sis_doc, ra_ids, log) -> None:
    """Route (b): RA <- PowerShiftKeyStrategy <- PowerShiftKeyDistribution -> PowerShiftKeySchedule, one copy of
    the schedules (and their participation factors) that the bid route of the RA uses."""
    sis_name = ra_name.replace("_RA.xml", "_SIS.xml")
    bids_of_ra: dict = {}
    for bid in sis_doc.elements("PowerBidSchedule"):
        bids_of_ra.setdefault(_ref(bid, _nc("PowerBidSchedule.PowerRemedialAction")), set()).add(Doc.ident(bid))
    distributions = sis_doc.elements("PowerShiftKeyDistribution")
    schedules = sis_doc.by_id("PowerShiftKeySchedule")
    points: dict = {}
    for point in sis_doc.elements("ParticipationFactorTimePoint"):
        points.setdefault(_ref(point, _nc("ParticipationFactorTimePoint.PowerShiftKeySchedule")), []).append(point)
    existing_strategies = {_ref(s, _nc("PowerShiftKeyStrategy.PowerRemedialAction")) for s in ra_doc.elements("PowerShiftKeyStrategy")}
    insert_after = list(sis_doc.root)[-1]
    for ra_id in ra_ids:
        if ra_id in existing_strategies:
            continue
        keys = []
        for dist in distributions:
            if _ref(dist, _nc("PowerShiftKeyDistribution.PowerBidSchedule")) in bids_of_ra.get(ra_id, set()):
                schedule_id = _ref(dist, _nc("PowerShiftKeyDistribution.PowerShiftKeySchedule"))
                if schedule_id in schedules and schedule_id not in keys:
                    keys.append(schedule_id)
        if not keys:
            log.add(sis_name, "redispatch", "no strategy route", ra_id, "the bid route of the RA has no shift key")
            continue
        strategy_id = new_id("strategy", ra_id)
        strategy = _new_element(_nc("PowerShiftKeyStrategy"), strategy_id, about=True)
        _add_ref(strategy, _nc("PowerShiftKeyStrategy.PowerRemedialAction"), ra_id)
        _add_literal(strategy, _cim("IdentifiedObject.mRID"), strategy_id)
        ra_doc.root.append(strategy)
        ra_doc.changed = True
        log.add(ra_name, "redispatch", "added PowerShiftKeyStrategy", strategy_id, f"PowerShiftKeyStrategy.PowerRemedialAction -> {ra_id}")
        for schedule_id in keys:
            source = schedules[schedule_id]
            copy_id = new_id("strategy-schedule", ra_id, schedule_id)
            dist_id = new_id("strategy-distribution", ra_id, schedule_id)
            dist = _new_element(_nc("PowerShiftKeyDistribution"), dist_id)
            _identified(dist, dist_id, name=f"Strategy distribution of {ra_id}")
            _add_ref(dist, _nc("PowerShiftKeyDistribution.PowerShiftKeySchedule"), copy_id)
            _add_ref(dist, _nc("PowerShiftKeyDistribution.PowerShiftKeyStrategy"), strategy_id)
            copy = _new_element(_nc("PowerShiftKeySchedule"), copy_id)
            for child in source:
                if _local(child.tag) in ("IdentifiedObject.mRID", "IdentifiedObject.name", "IdentifiedObject.description"):
                    continue
                clone = ET.SubElement(copy, child.tag, dict(child.attrib))
                clone.text = child.text
            _identified(copy, copy_id, name=f"Strategy key of {ra_id}")
            new_points = []
            for point in points.get(schedule_id, []):
                new_points.append(_new_element(_nc("ParticipationFactorTimePoint"), new_id("strategy-point", ra_id, schedule_id, Doc.ident(point))))
                for child in point:
                    if child.tag == _nc("ParticipationFactorTimePoint.PowerShiftKeySchedule"):
                        _add_ref(new_points[-1], child.tag, copy_id)
                    else:
                        clone = ET.SubElement(new_points[-1], child.tag, dict(child.attrib))
                        clone.text = child.text
            for element in [dist, copy] + new_points:
                _insert_after(sis_doc.root, element, insert_after)
                insert_after = element
            sis_doc.changed = True
            log.add(sis_name, "redispatch", "added strategy route", dist_id,
                    f"distribution -> strategy {strategy_id}, key copy {copy_id} of {schedule_id}, {len(new_points)} participation factor(s)")


# ---------------------------------------------------------------------------
# section: glsk
# ---------------------------------------------------------------------------

def generating_unit_by_machine(cgm_files: dict) -> dict:
    """{RotatingMachine mRID: GeneratingUnit mRID} and the set of GeneratingUnit mRIDs of the CGM EQ files."""
    pattern = re.compile(
        r'<cim:(?:SynchronousMachine|AsynchronousMachine) rdf:ID="_([^"]+)">(.*?)</cim:(?:SynchronousMachine|AsynchronousMachine)>', re.S)
    unit_pattern = re.compile(r'<cim:RotatingMachine\.GeneratingUnit rdf:resource="#_([^"]+)"')
    machines, units = {}, set()
    for name, data in cgm_files.items():
        if "_EQ_" not in name:
            continue
        text = data.decode("utf-8")
        units.update(re.findall(r'<cim:[A-Za-z]*GeneratingUnit rdf:ID="_([^"]+)"', text))
        for machine, body in pattern.findall(text):
            unit = unit_pattern.search(body)
            if unit:
                machines[machine] = unit.group(1)
    return machines, units


def convert_glsk(files: dict, cgm: Optional[tuple], log: Log) -> None:
    machines, units = cgm if cgm is not None else ({}, set())
    for name, doc in files.items():
        if not name.endswith("_SIS.xml"):
            continue
        for schedule in doc.elements("PowerShiftKeySchedule"):
            schedule_id = Doc.ident(schedule)
            link = _child(schedule, _nc("PowerShiftKeySchedule.GeneratingUnit"))
            if link is not None:
                ident = _fragment(link.get(_rdf("resource")))
                if ident in machines:
                    link.set(_rdf("resource"), "#_" + machines[ident])
                    doc.changed = True
                    log.add(name, "glsk", "GeneratingUnit id", schedule_id, f"machine {ident} -> GeneratingUnit {machines[ident]}")
                elif ident not in units:
                    log.add(name, "glsk", "unresolved unit", schedule_id, f"{ident} is neither a machine nor a GeneratingUnit of the CGM; kept")
            if _child(schedule, _nc("BaseTimeSeries.interpolationKind")) is None:
                _add_enum(schedule, _nc("BaseTimeSeries.interpolationKind"), NC + "TimeSeriesInterpolationKind.none")
                doc.changed = True
                log.add(name, "glsk", "added interpolationKind none", schedule_id, "the schedule has one participation factor per time point")


# ---------------------------------------------------------------------------
# section: countertrade
# ---------------------------------------------------------------------------

def convert_countertrade(files: dict, log: Log) -> None:
    for name, doc in files.items():
        if name.endswith("_RA.xml"):
            for ra in doc.elements("CountertradeRemedialAction"):
                for attribute in ("gLSKStrategy", "powerShiftKey", "method"):
                    old = _child(ra, _nc(f"CountertradeRemedialAction.{attribute}"))
                    if old is not None:
                        ra.remove(old)
                        doc.changed = True
                        log.add(name, "countertrade", "removed attribute", Doc.ident(ra),
                                f"CountertradeRemedialAction.{attribute}={old.get(_rdf('resource'), old.text)} (not in the profile)")
        if name.endswith("_SIS.xml"):
            for bid in doc.elements("PowerBidSchedule"):
                old = _child(bid, _nc("PowerBidSchedule.gLSKStrategy"))
                if old is not None:
                    bid.remove(old)
                    doc.changed = True
                    log.add(name, "countertrade", "removed attribute", Doc.ident(bid),
                            f"PowerBidSchedule.gLSKStrategy={old.get(_rdf('resource'), old.text)} (not in the profile)")


# ---------------------------------------------------------------------------
# section: other
# ---------------------------------------------------------------------------

def convert_other(files: dict, options: Options, log: Log) -> None:
    for name, doc in files.items():
        profile = "RA" if name.endswith("_RA.xml") else "SIS" if name.endswith("_SIS.xml") else None
        if profile is None:
            continue
        for dataset in doc.root:
            if not dataset.tag.endswith("}Dataset"):
                continue
            for conforms in dataset:
                resource = conforms.get(_rdf("resource"), "")
                if conforms.tag.endswith("}conformsTo") and resource.startswith(_PROFILE_VERSION[profile]) \
                        and not resource.endswith("/2.5"):
                    conforms.set(_rdf("resource"), _PROFILE_VERSION[profile] + "2.5")
                    doc.changed = True
                    log.add(name, "other", "header", "", f"conformsTo {resource} -> {_PROFILE_VERSION[profile]}2.5")
    for tso, ae_id, enabled in options.ae_schedules:
        doc = files.get(f"{tso}_SIS.xml")
        if doc is None:
            log.add(f"{tso}_SIS.xml", "other", "skipped", ae_id, "no SIS file for this TSO")
            continue
        schedule_id = new_id("ae-schedule", tso, ae_id)
        point_id = new_id("ae-time-point", tso, ae_id)
        schedule = _new_element(_nc("AssessedElementSchedule"), schedule_id)
        _identified(schedule, schedule_id, name=f"Schedule-{ae_id}")
        _add_ref(schedule, _nc("AssessedElementSchedule.AssessedElement"), ae_id)
        _add_enum(schedule, _nc("BaseTimeSeries.interpolationKind"), NC + "TimeSeriesInterpolationKind.none")
        point = _new_element(_nc("AssessedElementTimePoint"), point_id)
        _add_ref(point, _nc("AssessedElementTimePoint.AssessedElementSchedule"), schedule_id)
        _add_literal(point, _nc("AssessedElementTimePoint.atTime"), _RUN_TIME)
        _add_literal(point, _nc("AssessedElementTimePoint.enabled"), "true" if enabled else "false")
        doc.root.append(schedule)
        doc.root.append(point)
        doc.changed = True
        log.add(f"{tso}_SIS.xml", "other", "added AssessedElementSchedule", schedule_id, f"assessed element {ae_id}, enabled {enabled} at {_RUN_TIME}")


# ---------------------------------------------------------------------------
# driver
# ---------------------------------------------------------------------------

def convert_files(files: dict, cgm_files: Optional[dict] = None, options: Optional[Options] = None) -> tuple:
    """files: {name: bytes} of an NCP zip. Returns ({name: bytes}, [log entries])."""
    options = options or Options()
    log = Log()
    docs = {name: Doc(name, data) if name.endswith(".xml") and name != "Org-NineRealms_CD_OR.xml" else None
            for name, data in files.items()}
    parsed = {name: doc for name, doc in docs.items() if doc is not None}
    if "groups" in options.sections:
        convert_groups(parsed, options, log)
    if "bids" in options.sections:
        convert_bids(parsed, options, log)
    if "redispatch" in options.sections:
        convert_redispatch(parsed, options, bidding_zone_by_tso(parsed.get("Org-NineRealms_CD.xml")), log)
    if "glsk" in options.sections:
        if cgm_files is None:
            log.add("", "glsk", "skipped GeneratingUnit ids", "", "no CGM given")
        convert_glsk(parsed, generating_unit_by_machine(cgm_files) if cgm_files is not None else None, log)
    if "countertrade" in options.sections:
        convert_countertrade(parsed, log)
    if "other" in options.sections:
        convert_other(parsed, options, log)
    return {name: (docs[name].dump() if docs[name] is not None else data) for name, data in files.items()}, log.entries


def _read_zip(path) -> dict:
    with zipfile.ZipFile(path) as z:
        return {item.filename: z.read(item.filename) for item in z.infolist() if not item.is_dir()}


def convert_zip(source, dest, cgm_zip=None, options: Optional[Options] = None) -> list:
    """Convert the NCP zip `source` into `dest` (fixed zip time stamps, so equal input gives equal bytes)."""
    converted, entries = convert_files(_read_zip(source), _read_zip(cgm_zip) if cgm_zip else None, options)
    with zipfile.ZipFile(dest, "w", zipfile.ZIP_DEFLATED) as out:
        for name in sorted(converted):
            info = zipfile.ZipInfo(name, date_time=(1980, 1, 1, 0, 0, 0))
            info.external_attr = 0o644 << 16
            info.compress_type = zipfile.ZIP_DEFLATED
            out.writestr(info, converted[name])
    return entries


def write_log(entries: list, path) -> None:
    buffer = io.StringIO()
    writer = csv.DictWriter(buffer, fieldnames=["file", "section", "action", "element", "detail"], lineterminator="\n")
    writer.writeheader()
    writer.writerows(entries)
    Path(path).write_text(buffer.getvalue(), encoding="utf-8", newline="")


def main(argv=None) -> int:
    parser = argparse.ArgumentParser(description=__doc__.split("\n\n")[0])
    parser.add_argument("source", type=Path)
    parser.add_argument("dest", type=Path)
    parser.add_argument("--cgm", type=Path, help="CGM zip (needed for the glsk section)")
    parser.add_argument("--log", type=Path)
    parser.add_argument("--skip", nargs="*", default=[], choices=SECTIONS)
    parser.add_argument("--routes", choices=("bid", "strategy", "both"), default="both")
    parser.add_argument("--strip-direction", nargs="*", default=[], metavar="BID_MRID")
    parser.add_argument("--ae-schedule", nargs="*", default=[], metavar="TSO:AE_MRID:true|false")
    parser.add_argument("--drop-nonstandard-bid-attributes", action="store_true")
    parser.add_argument("--keep-bid-signs", action="store_true", help="do not set p < 0 for down bids and p > 0 for up bids")
    args = parser.parse_args(argv)
    ae = tuple((t, a, e == "true") for t, a, e in (item.split(":") for item in args.ae_schedule))
    options = Options(
        sections=tuple(s for s in SECTIONS if s not in args.skip), routes=args.routes,
        drop_nonstandard_bid_attributes=args.drop_nonstandard_bid_attributes, correct_bid_signs=not args.keep_bid_signs,
        strip_direction_of=tuple(args.strip_direction), ae_schedules=ae,
    )
    entries = convert_zip(args.source, args.dest, args.cgm, options)
    if args.log:
        write_log(entries, args.log)
    print(f"{len(entries)} change(s) logged")
    return 0


if __name__ == "__main__":
    sys.exit(main())
