"""cli.py - python -m mock_data COMMAND ...

  standard [--out PATH]           the shipped standard-form mock NCP, made from the legacy mock by the converter
  check                           SHA-256 of the fixture zips, standard = converter(legacy), copies in input/
  variant ct|hvdc|cthvdc|dataset OUT.zip
  dataset-variant NAME OUT.zip    one invalid / warning variant of the NCP test dataset (--list shows the names)
  shared-bid CASE OUT.zip         a shared-bid redispatch case on the standard-form mock
  install-input [--input-dir D]   copy the CGM and the standard mock (the old pair) into input/ (one cgm*, one ncp* zip;
                                  stops while input/ holds another one, e.g. the HVDC pair)
  inventory-p [--out-dir D]       the inventory of the PST / RD RAs, bids and generators of the standard mock
All outputs are deterministic (fixed zip time stamps, deterministic mRIDs)."""
from __future__ import annotations

import argparse
import hashlib
import shutil
import subprocess
import sys
from pathlib import Path

from . import paths

HERE = Path(__file__).resolve().parent


def sha256(path) -> str:
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def install_input(input_dir=None, force=False) -> list:
    """Copy the CGM zip and the standard-form mock NCP zip into input_dir (default input/). The pipeline needs
    exactly one cgm*.zip and one ncp*.zip there (prefix match, case-insensitive): another zip with such a prefix
    stops the copy (ValueError, nothing written); a file of the same name with other content is replaced only with
    force. Returns the list of what was done."""
    input_dir = Path(input_dir) if input_dir is not None else paths.INPUT_DIR
    input_dir.mkdir(parents=True, exist_ok=True)
    plan = []
    for source in (paths.CGM_ZIP, paths.STANDARD_ZIP):
        prefix = source.name[:3].lower()
        others = sorted(p.name for p in input_dir.glob("*.zip") if p.name.lower().startswith(prefix) and p.name != source.name)
        if others:
            raise ValueError(f"{input_dir} already holds {others}: a run needs exactly one {prefix}*.zip; remove it first")
        target = input_dir / source.name
        if target.exists() and sha256(target) != sha256(source) and not force:
            raise ValueError(f"{target} exists with other content; use --force to replace it")
        plan.append((source, target))
    done = []
    for source, target in plan:
        if target.exists() and sha256(target) == sha256(source):
            done.append(f"{target.name}: already identical")
            continue
        shutil.copyfile(source, target)
        done.append(f"{target.name}: written")
    return done


def check() -> int:
    """Print the fixture zips with their SHA-256 and compare the standard mock with the converter output."""
    from . import standard

    problems = 0
    for label, path in (("CGM", paths.CGM_ZIP), ("standard", paths.STANDARD_ZIP), ("legacy", paths.LEGACY_ZIP),
                        ("generic sample", paths.SAMPLE_GENERIC_ZIP)):
        print(f"{label:15} {sha256(path)[:16]}  {path.stat().st_size:>9} bytes  {path.name}")
    import tempfile
    with tempfile.TemporaryDirectory() as folder:
        regenerated = standard.build_standard(Path(folder) / "standard.zip")
        same = regenerated.read_bytes() == paths.STANDARD_ZIP.read_bytes()
    print("standard = converter(legacy):", "yes" if same else "NO")
    problems += 0 if same else 1
    for name in sorted(p.name for p in paths.INPUT_DIR.glob("*.zip")) if paths.INPUT_DIR.is_dir() else []:
        target = paths.INPUT_DIR / name
        known = [label for label, path in (("CGM", paths.CGM_ZIP), ("standard", paths.STANDARD_ZIP), ("legacy", paths.LEGACY_ZIP),
                                           ("generic sample", paths.SAMPLE_GENERIC_ZIP)) if sha256(path) == sha256(target)]
        print(f"input/{name}: " + (f"identical to the {known[0]} fixture" if known else "not a fixture copy"))
    return problems


def main(argv=None) -> int:
    parser = argparse.ArgumentParser(prog="python -m mock_data", description=__doc__.split("\n\n")[0])
    sub = parser.add_subparsers(dest="command", required=True)
    p = sub.add_parser("standard", help="write the standard-form mock NCP")
    p.add_argument("--out", type=Path, default=paths.STANDARD_ZIP)
    sub.add_parser("check", help="hashes of the fixture zips, standard = converter(legacy)")
    p = sub.add_parser("variant", help="a mock NCP of the countertrade / HVDC / dataset builders")
    p.add_argument("name", choices=("ct", "hvdc", "cthvdc", "dataset"))
    p.add_argument("out", type=Path)
    p = sub.add_parser("dataset-variant", help="one variant of the NCP test dataset")
    p.add_argument("name", nargs="?")
    p.add_argument("out", type=Path, nargs="?")
    p.add_argument("--list", action="store_true")
    p = sub.add_parser("shared-bid", help="a shared-bid redispatch case")
    p.add_argument("case")
    p.add_argument("out", type=Path)
    p = sub.add_parser("install-input", help="copy the CGM and the standard mock into input/")
    p.add_argument("--input-dir", type=Path)
    p.add_argument("--force", action="store_true")
    p = sub.add_parser("inventory-p", help="inventory of the standard mock")
    p.add_argument("--out-dir", type=Path, default=paths.REPO_ROOT / "docs")
    args = parser.parse_args(argv)

    if args.command == "standard":
        from . import standard
        out = standard.build_standard(args.out)
        print(f"{out}  {sha256(out)[:16]}")
        return 0
    if args.command == "check":
        return check()
    if args.command == "variant":
        from . import ct_mock, hvdc_mock, ncp_dataset
        builders = {"ct": ct_mock.build_ct_mock_ncp, "hvdc": hvdc_mock.build_hvdc_mock_ncp,
                    "cthvdc": ct_mock.build_ct_and_hvdc_mock_ncp, "dataset": ncp_dataset.build_valid_ncp}
        print(builders[args.name](args.out))
        return 0
    if args.command == "dataset-variant":
        from . import ncp_dataset
        names = sorted(set(ncp_dataset.VARIANTS) | set(ncp_dataset.FILE_VARIANTS))
        if args.list or args.name is None:
            print("\n".join(names))
            return 0
        if args.name not in names or args.out is None:
            parser.error("dataset-variant NAME OUT.zip (NAME from --list)")
        print(ncp_dataset.build_variant_ncp(args.out, args.name))
        return 0
    if args.command == "shared-bid":
        from . import ncp_dataset
        if args.case not in ncp_dataset.SHARED_BID_CASES:
            parser.error(f"case must be one of {sorted(ncp_dataset.SHARED_BID_CASES)}")
        print(ncp_dataset.build_shared_bid_ncp(args.out, args.case))
        return 0
    if args.command == "install-input":
        try:
            for line in install_input(args.input_dir, args.force):
                print(line)
        except ValueError as error:
            print(f"install-input stopped: {error}", file=sys.stderr)
            return 1
        return 0
    if args.command == "inventory-p":
        return subprocess.run([sys.executable, str(HERE / "tools" / "inventory_p.py"), str(args.out_dir)]).returncode
    return 2
