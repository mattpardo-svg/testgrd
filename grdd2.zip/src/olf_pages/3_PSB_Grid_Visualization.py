"""
Grid Visualization page.
Source: pyTSC crosa_app.py Step 2 – "Grid Visualizations" section,
        adapted for multi-page navigation.
Expects a solved network in st.session_state["powsybl_solver"].
"""
import os
import math
import pandas as pd
import streamlit as st

from src.core.ui.sidebar_actions import render_step_actions
from src.core.olf.lf_visualization import (
    build_branch_detail_map,
    build_injection_detail_map,
    build_injection_markers,
    build_network_visual_frames_cached,
    build_node_detail_map,
    coerce_float,
    create_network_overview_figure,
    format_metric,
    get_selected_plotly_item,
    get_single_line_diagram_svg,
    render_compact_details,
    render_svg_panel,
)

st.markdown("# Grid Visualization")
st.sidebar.header("Grid Visualization")

if not st.session_state.get('grid_model_read') and not st.session_state.get('powsybl_solver'):
    st.warning("Load a grid model first in 'PowSyBl Grid Model'.")
    render_step_actions('Grid Visualization')
    st.stop()

if not st.session_state.get('olf_lf_result'):
    st.warning("Run Load Flow first to populate the solved network for visualization.")
    render_step_actions('Grid Visualization')
    st.stop()

st.caption(f"Active CGM Source: {st.session_state["olf_grid_model_file_path"]}")

n = st.session_state.powsybl_solver.network

try:
    mandatory_equipment = {
        "buses": n.get_buses(),
        "branches": n.get_branches(),
        "lines": n.get_lines(),
    }
except Exception as exc:
    st.error(
        "Grid Visualization cannot be built because mandatory equipment data could not be read from the solved network. "
        "Mandatory equipment includes buses, branches, and lines."
    )
    st.code(str(exc))
    st.info("Please verify the imported CGM contains these mandatory equipment classes and run Load Flow again.")
    render_step_actions('Grid Visualization')
    st.stop()

missing_mandatory = []
for equipment_name, equipment_df in mandatory_equipment.items():
    if equipment_df is None or equipment_df.empty:
        missing_mandatory.append(equipment_name)

if missing_mandatory:
    missing_label = ", ".join(missing_mandatory)
    st.error(
        f"Grid Visualization failed: missing mandatory equipment in the solved network ({missing_label}). "
        "Lines are mandatory for this page."
    )
    st.info("Check model import completeness, then reload the grid model and rerun Load Flow.")
    render_step_actions('Grid Visualization')
    st.stop()

# ---- Derived frames ----
vls = n.get_voltage_levels().reset_index().rename(
    columns={"index": "voltage_level_id", "id": "voltage_level_id", "nominal_v": "nominal_kv", "name": "voltage_level_name"}
)
substations_df = n.get_substations().reset_index().rename(
    columns={"index": "substation_id", "id": "substation_id", "name": "substation_name"}
)
if "substation_id" in vls.columns and "substation_id" in substations_df.columns:
    sub_cols = [c for c in ["substation_id", "substation_name"] if c in substations_df.columns]
    vls = vls.merge(substations_df[sub_cols], on="substation_id", how="left")

buses_df = mandatory_equipment["buses"].reset_index().rename(columns={"index": "bus_id", "id": "bus_id"})
if "bus_id" not in buses_df.columns:
    buses_df["bus_id"] = pd.NA
for col in ["v_mag", "v_angle", "voltage_level_id"]:
    if col not in buses_df.columns:
        buses_df[col] = pd.NA

try:
    bb_df = n.get_bus_breaker_view_buses().reset_index().rename(columns={"index": "bus_id", "id": "bus_id"})
    bb_cols = [c for c in ["bus_id", "voltage_level_id"] if c in bb_df.columns]
    if "voltage_level_id" in bb_cols:
        buses_df = buses_df.merge(bb_df[bb_cols].drop_duplicates(subset=["bus_id"]),
                                    on="bus_id", how="left", suffixes=("", "_bb"))
        if "voltage_level_id_bb" in buses_df.columns:
            buses_df["voltage_level_id"] = buses_df["voltage_level_id"].combine_first(buses_df["voltage_level_id_bb"])
            buses_df = buses_df.drop(columns=["voltage_level_id_bb"])
except Exception:
    pass

try:
    terminals_df = n.get_terminals().reset_index(drop=True)
    if "bus_id" in terminals_df.columns and "voltage_level_id" in terminals_df.columns:
        term_vl = (terminals_df.dropna(subset=["bus_id", "voltage_level_id"])
                    .astype({"bus_id": str})
                    .groupby("bus_id", as_index=False)["voltage_level_id"].first())
        buses_df = buses_df.merge(term_vl, on="bus_id", how="left", suffixes=("", "_term"))
        if "voltage_level_id_term" in buses_df.columns:
            buses_df["voltage_level_id"] = buses_df["voltage_level_id"].combine_first(buses_df["voltage_level_id_term"])
            buses_df = buses_df.drop(columns=["voltage_level_id_term"])
except Exception:
    pass

buses_df["bus_id"] = buses_df["bus_id"].astype(str)
buses_df = buses_df[[c for c in ["bus_id", "v_mag", "v_angle", "voltage_level_id"] if c in buses_df.columns]]
if "voltage_level_id" in buses_df.columns and "voltage_level_id" in vls.columns:
    vl_merge_cols = [c for c in ["voltage_level_id", "voltage_level_name", "nominal_kv", "substation_id", "substation_name"] if c in vls.columns]
    buses_df = buses_df.merge(vls[vl_merge_cols], on="voltage_level_id", how="left")
buses_df = buses_df.rename(columns={"v_mag": "bus_v_mag", "v_angle": "bus_v_angle"})

loads_df = n.get_loads().reset_index().rename(columns={"index": "item_id", "id": "item_id"})
generators_df = n.get_generators().reset_index().rename(columns={"index": "item_id", "id": "item_id"})
for inj_df in (loads_df, generators_df):
    for col in ["item_id", "bus_id", "voltage_level_id", "name", "p", "q", "i"]:
        if col not in inj_df.columns:
            inj_df[col] = pd.NA

op_branches = mandatory_equipment["branches"].reset_index().rename(columns={"index": "branch_id", "id": "branch_id"})
op_3w = n.get_3_windings_transformers().reset_index().rename(columns={"index": "branch_id", "id": "branch_id"})

op_line_names = mandatory_equipment["lines"].reset_index().rename(columns={"index": "equipment_id", "id": "equipment_id"})
op_line_name_map = {str(r["equipment_id"]): r.get("name") for _, r in op_line_names.iterrows() if pd.notna(r.get("name"))}
op_twt_names = n.get_2_windings_transformers().reset_index().rename(columns={"index": "equipment_id", "id": "equipment_id"})
op_twt_name_map = {str(r["equipment_id"]): r.get("name") for _, r in op_twt_names.iterrows() if pd.notna(r.get("name"))}

def _resolve_op_name(row):
    cur = row.get("name")
    if pd.notna(cur) and str(cur).strip():
        return cur
    bid = str(row.get("branch_id", ""))
    btype = str(row.get("type", ""))
    if btype == "LINE":
        return op_line_name_map.get(bid, cur)
    if btype == "TWO_WINDINGS_TRANSFORMER":
        return op_twt_name_map.get(bid, cur)
    if btype == "TIE_LINE":
        return " + ".join([op_line_name_map.get(p.strip(), p.strip()) for p in bid.split("+")])
    return cur

op_branches["name"] = op_branches.apply(_resolve_op_name, axis=1)

op_branch_cols = ["branch_id", "type", "name", "bus1_id", "bus2_id", "bus3_id",
                    "p1", "q1", "i1", "p2", "q2", "i2", "p3", "q3", "i3"]

if not op_3w.empty:
    op_3w["type"] = "THREE_WINDINGS_TRANSFORMER"
    for col in ["name", "type", "p1", "q1", "i1", "p2", "q2", "i2", "p3", "q3", "i3", "bus1_id", "bus2_id", "bus3_id"]:
        if col not in op_3w.columns:
            op_3w[col] = pd.NA
    op_branches = pd.concat([
        op_branches[[c for c in op_branch_cols if c in op_branches.columns]],
        op_3w[[c for c in op_branch_cols if c in op_3w.columns]],
    ], ignore_index=True, sort=False)

for col in op_branch_cols:
    if col not in op_branches.columns:
        op_branches[col] = pd.NA

for side in (1, 2, 3):
    bk = f"bus{side}_id"
    op_branches = op_branches.merge(
        buses_df.rename(columns={"bus_id": bk, "bus_v_mag": f"v_mag_{side}", "bus_v_angle": f"v_angle_{side}"}),
        on=bk, how="left",
    )

# ---- Consolidated Operating Point ----
#st.write("### Consolidated Operating Point (Branch + Bus)")
#consol_cols = ["branch_id", "type", "name",
#                "bus1_id", "v_mag_1", "v_angle_1", "p1", "q1", "i1",
#                "bus2_id", "v_mag_2", "v_angle_2", "p2", "q2", "i2",
#                "bus3_id", "v_mag_3", "v_angle_3", "p3", "q3", "i3"]
#consol_cols = [c for c in consol_cols if c in op_branches.columns]
#####st.dataframe(op_branches[consol_cols], use_container_width=True)

# ---- Branch Thermal Loading ----
branches_df = mandatory_equipment["branches"].copy().reset_index().rename(columns={"index": "branch_id", "id": "branch_id"})

line_names = mandatory_equipment["lines"].reset_index().rename(columns={"index": "equipment_id", "id": "equipment_id"})
line_name_map = {str(r["equipment_id"]): r.get("name") for _, r in line_names.iterrows() if pd.notna(r.get("name"))}
twt_names = n.get_2_windings_transformers().reset_index().rename(columns={"index": "equipment_id", "id": "equipment_id"})
twt_name_map = {str(r["equipment_id"]): r.get("name") for _, r in twt_names.iterrows() if pd.notna(r.get("name"))}

def resolve_branch_name(row):
    cur = row.get("name")
    if pd.notna(cur) and str(cur).strip():
        return cur
    bid = str(row.get("branch_id", ""))
    btype = str(row.get("type", ""))
    if btype == "LINE":
        return line_name_map.get(bid, cur)
    if btype == "TWO_WINDINGS_TRANSFORMER":
        return twt_name_map.get(bid, cur)
    if btype == "TIE_LINE":
        return " + ".join([line_name_map.get(p.strip(), p.strip()) for p in bid.split("+")])
    return cur

branches_df["name"] = branches_df.apply(resolve_branch_name, axis=1)

three_w_df = n.get_3_windings_transformers().copy().reset_index().rename(columns={"index": "branch_id", "id": "branch_id"})
if not three_w_df.empty:
    bl_cols = ["branch_id", "name", "type", "p1", "q1", "i1", "p2", "q2", "i2", "p3", "q3", "i3",
                "voltage_level1_id", "voltage_level2_id", "voltage_level3_id", "rated_u1", "rated_u2", "rated_u3"]
    three_w_df["type"] = "THREE_WINDINGS_TRANSFORMER"
    for col in bl_cols:
        if col not in three_w_df.columns:
            three_w_df[col] = pd.NA
    branches_df = pd.concat([
        branches_df[[c for c in bl_cols if c in branches_df.columns]],
        three_w_df[[c for c in bl_cols if c in three_w_df.columns]],
    ], ignore_index=True, sort=False)
    for col in bl_cols:
        if col not in branches_df.columns:
            branches_df[col] = pd.NA

limits = n.get_operational_limits().reset_index()
for col in ["element_type", "type", "name", "side", "value", "element_id"]:
    if col not in limits.columns:
        limits[col] = pd.NA
limits = limits[
    (limits["element_type"].isin(["LINE", "TIE_LINE", "TWO_WINDINGS_TRANSFORMER", "THREE_WINDINGS_TRANSFORMER"]))
    & (limits["type"] == "CURRENT") & (limits["name"] == "permanent_limit")
].copy()
side_map = {"ONE": 1, "TWO": 2, "THREE": 3}
limits["side_idx"] = limits["side"].map(side_map)
limits = limits.dropna(subset=["side_idx"])
limits["side_idx"] = limits["side_idx"].astype(int)
limit_by_side = limits.groupby(["element_id", "side_idx"], as_index=False)["value"].min()
limit_by_side = limit_by_side.pivot(index="element_id", columns="side_idx", values="value").reset_index().rename(
    columns={"element_id": "branch_id", 1: "thermal_limit_a_1", 2: "thermal_limit_a_2", 3: "thermal_limit_a_3"}
)

for vl_col, kv_col in [("voltage_level1_id", "vl_nominal_kv_1"), ("voltage_level2_id", "vl_nominal_kv_2"),
                            ("voltage_level3_id", "vl_nominal_kv_3")]:
    if vl_col in branches_df.columns:
        branches_df = branches_df.merge(vls.rename(columns={"voltage_level_id": vl_col, "nominal_kv": kv_col}),
                                        on=vl_col, how="left")
    else:
        branches_df[kv_col] = pd.NA

branches_df = branches_df.merge(limit_by_side, on="branch_id", how="left")

for idx in (1, 2, 3):
    ru = f"rated_u{idx}"
    vl_kv = f"vl_nominal_kv_{idx}"
    branches_df[f"nominal_kv_{idx}"] = (branches_df[ru].combine_first(branches_df[vl_kv])
                                            if ru in branches_df.columns else branches_df.get(vl_kv, pd.NA))

for idx in (1, 2, 3):
    for col in (f"p{idx}", f"q{idx}", f"i{idx}", f"thermal_limit_a_{idx}", f"nominal_kv_{idx}"):
        if col not in branches_df.columns:
            branches_df[col] = pd.NA

for idx in (1, 2, 3):
    p_col, q_col, i_col = f"p{idx}", f"q{idx}", f"i{idx}"
    lim_a, kv = f"thermal_limit_a_{idx}", f"nominal_kv_{idx}"
    branches_df[f"s{idx}_mva"] = (pd.to_numeric(branches_df[p_col], errors="coerce").pow(2)
                                    + pd.to_numeric(branches_df[q_col], errors="coerce").pow(2)).pow(0.5)
    branches_df[f"i{idx}_abs_a"] = pd.to_numeric(branches_df[i_col], errors="coerce").abs()
    branches_df[f"thermal_limit_mva_{idx}"] = (
        math.sqrt(3.0) * pd.to_numeric(branches_df[kv], errors="coerce")
        * (pd.to_numeric(branches_df[lim_a], errors="coerce") / 1000.0)
    )
    branches_df[f"loading_current_pct_{idx}"] = (
        branches_df[f"i{idx}_abs_a"] / pd.to_numeric(branches_df[lim_a], errors="coerce") * 100.0
    )
    branches_df[f"loading_power_pct_{idx}"] = branches_df[f"s{idx}_mva"] / branches_df[f"thermal_limit_mva_{idx}"] * 100.0

branches_df["s_max_mva"] = branches_df[["s1_mva", "s2_mva", "s3_mva"]].max(axis=1, skipna=True)
branches_df["i_max_a"] = branches_df[["i1_abs_a", "i2_abs_a", "i3_abs_a"]].max(axis=1, skipna=True)
branches_df["thermal_limit_a"] = branches_df[["thermal_limit_a_1", "thermal_limit_a_2", "thermal_limit_a_3"]].min(axis=1, skipna=True)
branches_df["thermal_limit_mva"] = branches_df[["thermal_limit_mva_1", "thermal_limit_mva_2", "thermal_limit_mva_3"]].min(axis=1, skipna=True)
branches_df["loading_current_pct"] = branches_df[["loading_current_pct_1", "loading_current_pct_2", "loading_current_pct_3"]].max(axis=1, skipna=True)
branches_df["loading_power_pct"] = branches_df[["loading_power_pct_1", "loading_power_pct_2", "loading_power_pct_3"]].max(axis=1, skipna=True)

def classify_loading(pwr, cur):
    if pd.isna(pwr) and pd.isna(cur):
        return "Unknown"
    score = pd.Series([pwr, cur]).max(skipna=True)
    if pd.isna(score):
        return "Unknown"
    return "Overloaded" if score > 100 else ("High" if score >= 80 else "Normal")

branches_df["status"] = branches_df.apply(
    lambda row: classify_loading(row.get("loading_power_pct"), row.get("loading_current_pct")), axis=1
)

#st.write("### Branch Thermal Loading")
#st.caption(
#    "Thermal limits are taken per side from CURRENT permanent_limit for lines, tie-lines, 2W and 3W transformers. "
#    "Displayed loading uses the worst side (max loading) and the most restrictive limit."
#)
thermal_cols = ["branch_id", "type", "name", "thermal_limit_a", "thermal_limit_mva",
                "s1_mva", "s2_mva", "s3_mva", "s_max_mva", "i1", "i2", "i3", "i_max_a",
                "loading_power_pct", "loading_current_pct", "status"]
thermal_cols = [c for c in thermal_cols if c in branches_df.columns]
thermal_df = branches_df[thermal_cols].sort_values("loading_power_pct", ascending=False, na_position="last")

def style_status(row):
    s = row.get("Load Status", row.get("status", ""))
    if s == "Overloaded":
        return ["background-color: #f8d7da"] * len(row)
    if s == "High":
        return ["background-color: #fff3cd"] * len(row)
    if s == "Normal":
        return ["background-color: #d4edda"] * len(row)
    return [""] * len(row)

thermal_display_df = thermal_df.rename(columns={
    "branch_id": "Branch ID", "type": "Branch Type", "name": "Branch Name",
    "thermal_limit_a": "Thermal Limit (A)", "thermal_limit_mva": "Thermal Limit (MVA)",
    "s1_mva": "Load Flow Power Side 1 (MVA)", "s2_mva": "Load Flow Power Side 2 (MVA)",
    "s3_mva": "Load Flow Power Side 3 (MVA)", "s_max_mva": "Load Flow Power Max (MVA)",
    "i1": "Load Flow Current Side 1 (A)", "i2": "Load Flow Current Side 2 (A)",
    "i3": "Load Flow Current Side 3 (A)", "i_max_a": "Load Flow Current Max (A)",
    "loading_power_pct": "Power Loading (%)", "loading_current_pct": "Current Loading (%)",
    "status": "Load Status",
})
#####st.dataframe(thermal_display_df.style.format(na_rep="N/A").apply(style_status, axis=1), use_container_width=True)

# Cache frames for the Visualization page
st.session_state["lf_branches_df"] = branches_df
st.session_state["lf_op_branches"] = op_branches
st.session_state["lf_buses_df"] = buses_df
st.session_state["lf_vls"] = vls
st.session_state["lf_substations_df"] = substations_df
st.session_state["lf_loads_df"] = loads_df
st.session_state["lf_generators_df"] = generators_df


# ---- Recompute data frames from solved network ----
# vls = n.get_voltage_levels().reset_index().rename(
#     columns={"index": "voltage_level_id", "id": "voltage_level_id", "nominal_v": "nominal_kv", "name": "voltage_level_name"}
# )
# substations_df = n.get_substations().reset_index().rename(
#     columns={"index": "substation_id", "id": "substation_id", "name": "substation_name"}
# )
# if "substation_id" in vls.columns and "substation_id" in substations_df.columns:
#     sub_cols = [c for c in ["substation_id", "substation_name"] if c in substations_df.columns]
#     vls = vls.merge(substations_df[sub_cols], on="substation_id", how="left")

# buses_df = n.get_buses().reset_index().rename(columns={"index": "bus_id", "id": "bus_id"})
# if "bus_id" not in buses_df.columns:
#     buses_df["bus_id"] = pd.NA
# for col in ["v_mag", "v_angle", "voltage_level_id"]:
#     if col not in buses_df.columns:
#         buses_df[col] = pd.NA

# try:
#     bb_df = n.get_bus_breaker_view_buses().reset_index().rename(columns={"index": "bus_id", "id": "bus_id"})
#     bb_cols = [c for c in ["bus_id", "voltage_level_id"] if c in bb_df.columns]
#     if "voltage_level_id" in bb_cols:
#         buses_df = buses_df.merge(bb_df[bb_cols].drop_duplicates(subset=["bus_id"]),
#                                   on="bus_id", how="left", suffixes=("", "_bb"))
#         if "voltage_level_id_bb" in buses_df.columns:
#             buses_df["voltage_level_id"] = buses_df["voltage_level_id"].combine_first(buses_df["voltage_level_id_bb"])
#             buses_df = buses_df.drop(columns=["voltage_level_id_bb"])
# except Exception:
#     pass

# try:
#     terminals_df = n.get_terminals().reset_index(drop=True)
#     if "bus_id" in terminals_df.columns and "voltage_level_id" in terminals_df.columns:
#         term_vl = (terminals_df.dropna(subset=["bus_id", "voltage_level_id"])
#                    .astype({"bus_id": str})
#                    .groupby("bus_id", as_index=False)["voltage_level_id"].first())
#         buses_df = buses_df.merge(term_vl, on="bus_id", how="left", suffixes=("", "_term"))
#         if "voltage_level_id_term" in buses_df.columns:
#             buses_df["voltage_level_id"] = buses_df["voltage_level_id"].combine_first(buses_df["voltage_level_id_term"])
#             buses_df = buses_df.drop(columns=["voltage_level_id_term"])
# except Exception:
#     pass

# buses_df["bus_id"] = buses_df["bus_id"].astype(str)
# buses_df = buses_df[[c for c in ["bus_id", "v_mag", "v_angle", "voltage_level_id"] if c in buses_df.columns]]
# if "voltage_level_id" in buses_df.columns and "voltage_level_id" in vls.columns:
#     vl_mc = [c for c in ["voltage_level_id", "voltage_level_name", "nominal_kv", "substation_id", "substation_name"] if c in vls.columns]
#     buses_df = buses_df.merge(vls[vl_mc], on="voltage_level_id", how="left")
# buses_df = buses_df.rename(columns={"v_mag": "bus_v_mag", "v_angle": "bus_v_angle"})

# loads_df = n.get_loads().reset_index().rename(columns={"index": "item_id", "id": "item_id"})
# generators_df = n.get_generators().reset_index().rename(columns={"index": "item_id", "id": "item_id"})
# for inj_df in (loads_df, generators_df):
#     for col in ["item_id", "bus_id", "voltage_level_id", "name", "p", "q", "i"]:
#         if col not in inj_df.columns:
#             inj_df[col] = pd.NA

# branches_df = st.session_state.get("lf_branches_df")
# op_branches = st.session_state.get("lf_op_branches")
if branches_df is None or op_branches is None:
    st.info("Note: LF result frames not cached – some visualizations may be simplified.")
    branches_df = pd.DataFrame()
    op_branches = n.get_branches().reset_index().rename(columns={"index": "branch_id", "id": "branch_id"})

if not branches_df.empty:
    merge_cols = [c for c in ["branch_id", "loading_power_pct", "loading_current_pct",
                               "thermal_limit_a", "thermal_limit_mva", "status",
                               "s_max_mva", "i_max_a", "nominal_kv_1", "nominal_kv_2", "nominal_kv_3",
                               "voltage_level1_id", "voltage_level2_id", "voltage_level3_id"]
                  if c in branches_df.columns]
    graph_branch_df = op_branches.merge(branches_df[merge_cols], on="branch_id", how="left")
else:
    graph_branch_df = op_branches.copy()
    for col in ["status", "loading_power_pct", "loading_current_pct"]:
        graph_branch_df[col] = pd.NA

if "status" in graph_branch_df.columns:
    graph_branch_df["status"] = graph_branch_df["status"].fillna("Unknown")

# ---- Tabs ----
viz_tabs = st.tabs(["Interactive overview", "Navigable single-line diagrams", "Full network SVG"])

# == Tab 0: Interactive Plotly overview ==
with viz_tabs[0]:
    st.caption(
        "This view is optimized for exploration: filter the network, hover for electrical details, "
        "and click buses or branch markers to populate the side panel."
    )
    filter_c1, filter_c2, filter_c3, filter_c4 = st.columns([1.3, 1.3, 1, 1.4])
    detail_display_mode = st.radio("Details display", options=["Side panel", "On map"], horizontal=True, key="lf_detail_display_mode")
    avail_statuses = [s for s in ["Overloaded", "High", "Normal", "Unknown"]
                      if s in graph_branch_df["status"].fillna("Unknown").unique().tolist()] if "status" in graph_branch_df.columns else []
    avail_types = sorted([str(v) for v in graph_branch_df["type"].dropna().unique().tolist()]) if "type" in graph_branch_df.columns else []
    with filter_c1:
        sel_statuses = st.multiselect("Severity", options=avail_statuses, default=avail_statuses, key="lf_graph_status_filter")
    with filter_c2:
        sel_types = st.multiselect("Equipment type", options=avail_types, default=avail_types, key="lf_graph_type_filter")
    default_min_loading = 30 if len(graph_branch_df) > 5000 else 0
    with filter_c3:
        min_loading = st.slider("Min loading (%)", min_value=0, max_value=150, value=default_min_loading, step=5, key="lf_graph_loading_filter")
    with filter_c4:
        search_term = st.text_input("Find bus or branch", key="lf_graph_search", placeholder="Bus ID, branch ID, or name")
    vis_branch = graph_branch_df.copy()
    if avail_statuses:
        vis_branch = vis_branch[vis_branch["status"].isin(sel_statuses)]
    if avail_types:
        vis_branch = vis_branch[vis_branch["type"].astype(str).isin(sel_types)]
    if "loading_power_pct" in vis_branch.columns:
        vis_branch["_lpn"] = vis_branch["loading_power_pct"].apply(coerce_float)
        vis_branch = vis_branch[vis_branch["_lpn"].fillna(-1) >= min_loading]
    if search_term:
        sv = search_term.strip().lower()
        ss = pd.Series("", index=vis_branch.index, dtype="object")
        for sc in ["branch_id", "name", "bus1_id", "bus2_id", "bus3_id"]:
            if sc in vis_branch.columns:
                ss = ss + " " + vis_branch[sc].fillna("").astype(str)
        vis_branch = vis_branch[ss.str.lower().str.contains(sv, regex=False)]

    graph_size = len(graph_branch_df)
    if graph_size > 5000:
        st.info("Large network detected. Building the map layout may take longer the first time.")

    model_id = str(st.session_state.get("olf_grid_model_file_path", "unknown_model"))
    network_id = str(id(n))
    layout_cache_key = f"{model_id}|{network_id}|{len(buses_df)}|{graph_size}"
    has_cached_layout = (
        st.session_state.get("lf_layout_cache_key") == layout_cache_key
        and "lf_layout_nodes" in st.session_state
        and "lf_layout_edges" in st.session_state
    )
    if has_cached_layout:
        full_nodes_df = st.session_state["lf_layout_nodes"]
        full_edges_df = st.session_state["lf_layout_edges"]
    else:
        with st.spinner("Loading interactive map. This can take some time for large models..."):
            full_nodes_df, full_edges_df = build_network_visual_frames_cached(buses_df, graph_branch_df, vls)
        st.session_state["lf_layout_cache_key"] = layout_cache_key
        st.session_state["lf_layout_nodes"] = full_nodes_df
        st.session_state["lf_layout_edges"] = full_edges_df

    if "branch_id" in vis_branch.columns and "selection_id" in full_edges_df.columns:
        vis_ids = set(vis_branch["branch_id"].astype(str).tolist())
        edges_df = full_edges_df[full_edges_df["selection_id"].astype(str).isin(vis_ids)].copy()
    else:
        edges_df = full_edges_df.copy()
    if "node_id" in full_nodes_df.columns and "source" in edges_df.columns:
        vis_node_ids = set(edges_df["source"].astype(str)) | set(edges_df["target"].astype(str))
        nodes_df = full_nodes_df[full_nodes_df["node_id"].astype(str).isin(vis_node_ids)].copy()
    else:
        nodes_df = full_nodes_df.copy()
    injections_df = build_injection_markers(nodes_df, loads_df, generators_df)
    sel_kind = st.session_state.get("lf_selected_kind")
    sel_id = st.session_state.get("lf_selected_item_id")
    if nodes_df.empty or edges_df.empty:
        st.warning("No visible network elements match the current filters.")
    else:
        vn_ids = set(nodes_df["node_id"].astype(str))
        vs_ids = set(edges_df["selection_id"].astype(str)) if "selection_id" in edges_df.columns else set()
        vi_ids = set(injections_df["item_id"].astype(str)) if not injections_df.empty else set()
        if sel_kind == "node" and str(sel_id) not in vn_ids: sel_kind = sel_id = None
        if sel_kind == "branch" and str(sel_id) not in vs_ids: sel_kind = sel_id = None
        if sel_kind == "injection" and str(sel_id) not in vi_ids: sel_kind = sel_id = None
        if detail_display_mode == "On map":
            fig_col = st.container(); side_col = None
        else:
            fig_col, side_col = st.columns([3.2, 1.2], gap="large")
        with fig_col:
            fig = create_network_overview_figure(nodes_df, edges_df, selected_kind=sel_kind, selected_id=sel_id, injections_df=injections_df)
            if detail_display_mode == "On map" and sel_kind and sel_id is not None:
                dm = None
                if sel_kind == "node":
                    sn = nodes_df[nodes_df["node_id"].astype(str) == str(sel_id)]
                    if not sn.empty: dm = build_node_detail_map(sn.iloc[0].to_dict())
                elif sel_kind == "branch":
                    sb = vis_branch[vis_branch["branch_id"].astype(str) == str(sel_id)]
                    if not sb.empty:
                        bp = sb.iloc[0].to_dict(); bp["branch_name"] = bp.get("name") or bp.get("branch_id"); bp["branch_type"] = bp.get("type")
                        dm = build_branch_detail_map(bp)
                elif sel_kind == "injection" and not injections_df.empty:
                    si = injections_df[injections_df["item_id"].astype(str) == str(sel_id)]
                    if not si.empty: dm = build_injection_detail_map(si.iloc[0].to_dict())
                if dm:
                    fig.add_annotation(xref="paper", yref="paper", x=0.01, y=0.99, xanchor="left", yanchor="top", align="left",
                                       text="<br>".join([f"<b>{k}</b>: {v}" for k, v in dm.items()]), showarrow=False,
                                       bordercolor="#CBD5E1", borderwidth=1, borderpad=8,
                                       bgcolor="rgba(255,255,255,0.88)", font={"size": 11, "color": "#1F2937"})
            event = st.plotly_chart(fig, key="lf_network_plotly_overview", on_select="rerun",
                                    selection_mode=("points",), use_container_width=True,
                                    config={"scrollZoom": False, "displaylogo": False, "doubleClick": False,
                                            "modeBarButtonsToRemove": ["lasso2d", "select2d"]})
            ek, eid = get_selected_plotly_item(event, current_kind=sel_kind, current_id=sel_id)
            if ek and eid:
                if (st.session_state.get("lf_selected_kind") != ek or str(st.session_state.get("lf_selected_item_id")) != str(eid)):
                    st.session_state["lf_selected_kind"] = ek; st.session_state["lf_selected_item_id"] = eid; st.rerun()
        if side_col is not None:
            with side_col:
                st.markdown("#### Selected element")
                if st.button("Clear selection", key="lf_clear_selection"):
                    st.session_state.pop("lf_selected_kind", None); st.session_state.pop("lf_selected_item_id", None); st.rerun()
                if sel_kind == "node" and sel_id is not None:
                    sn = nodes_df[nodes_df["node_id"].astype(str) == str(sel_id)]
                    if not sn.empty: render_compact_details("Selected element", build_node_detail_map(sn.iloc[0].to_dict()))
                elif sel_kind == "branch" and sel_id is not None:
                    sb = vis_branch[vis_branch["branch_id"].astype(str) == str(sel_id)]
                    if not sb.empty:
                        bp = sb.iloc[0].to_dict(); bp["branch_name"] = bp.get("name") or bp.get("branch_id"); bp["branch_type"] = bp.get("type")
                        render_compact_details("Selected element", build_branch_detail_map(bp))
                elif sel_kind == "injection" and sel_id is not None and not injections_df.empty:
                    si = injections_df[injections_df["item_id"].astype(str) == str(sel_id)]
                    if not si.empty: render_compact_details("Selected element", build_injection_detail_map(si.iloc[0].to_dict()))
                else:
                    st.caption("Click a bus, branch, load, or generator on the map to inspect it.")
        else:
            if st.button("Clear selection", key="lf_clear_selection_on_map"):
                st.session_state.pop("lf_selected_kind", None); st.session_state.pop("lf_selected_item_id", None); st.rerun()

# == Tab 1: Navigable single-line diagrams ==
with viz_tabs[1]:
    st.caption("Browse focused single-line diagrams by voltage level or substation.")
    nav_mode = st.radio("Diagram mode", options=["Voltage level", "Substation"], horizontal=True, key="lf_single_line_mode")
    if nav_mode == "Voltage level":
        vl_opts = vls[[c for c in ["voltage_level_id", "voltage_level_name", "nominal_kv", "substation_name", "substation_id"] if c in vls.columns]].drop_duplicates()
        if vl_opts.empty:
            st.warning("No voltage levels available.")
        else:
            sel_vl = st.selectbox(
                "Voltage level",
                options=vl_opts["voltage_level_id"].astype(str).tolist(),
                format_func=lambda val: next(
                    (f"{r.get('voltage_level_name') or r.get('voltage_level_id')} | {format_metric(r.get('nominal_kv'), suffix=' kV')} | {r.get('substation_name') or r.get('substation_id') or 'No substation'}"
                     for r in vl_opts.to_dict("records") if str(r.get("voltage_level_id")) == str(val)),
                    str(val),
                ),
                key="lf_single_line_voltage_level",
            )
            try:
                svg_data = get_single_line_diagram_svg(n, sel_vl)
                st.write(f"**Voltage-level single-line diagram: {sel_vl}**")
                render_svg_panel(svg_data, f"single_line_voltage_level_{sel_vl}.svg")
            except Exception as exc:
                st.error("Unable to generate the selected voltage-level single-line diagram.")
                st.code(str(exc))
    else:
        sub_opts = substations_df[[c for c in ["substation_id", "substation_name"] if c in substations_df.columns]].drop_duplicates()
        if sub_opts.empty:
            st.warning("No substations available.")
        else:
            sel_sub = st.selectbox(
                "Substation",
                options=sub_opts["substation_id"].astype(str).tolist(),
                format_func=lambda val: next(
                    (f"{r.get('substation_name') or r.get('substation_id')}"
                     for r in sub_opts.to_dict("records") if str(r.get("substation_id")) == str(val)),
                    str(val),
                ),
                key="lf_single_line_substation",
            )
            try:
                svg_data = get_single_line_diagram_svg(n, sel_sub)
                st.write(f"**Substation single-line diagram: {sel_sub}**")
                render_svg_panel(svg_data, f"single_line_substation_{sel_sub}.svg")
            except Exception as exc:
                st.error("Unable to generate the selected substation single-line diagram.")
                st.code(str(exc))

# == Tab 2: Full network SVG ==
with viz_tabs[2]:
    st.caption("Full-network pypowsybl area diagram.")
    svg_path = os.path.join("results", "full.svg")
    if not os.path.exists(svg_path):
        try:
            os.makedirs("results", exist_ok=True)
            svg_obj = n.get_network_area_diagram()
            with open(svg_path, "w", encoding="utf-8") as f:
                f.write(str(svg_obj))
        except Exception as exc:
            st.warning(f"Could not generate full network SVG: {exc}")
    if os.path.exists(svg_path) and os.path.getsize(svg_path) > 0:
        with open(svg_path, "r", encoding="utf-8") as f:
            svg_data = f.read()
        st.write("**Network Diagram (SVG):**")
        render_svg_panel(svg_data, "network_diagram.svg")
    else:
        st.warning("Full network SVG not available. Visit this page again after running Load Flow.")

render_step_actions("Load Flow")
