"""src/rao_pages/_gui_common.py

Shared helper module for the Closed RAO GUI's 3 pages (1_Main.py,
2_Load_Flow_Settings.py, 3_RAO_Settings.py). NOT a page itself — no
st.Page() reference to this file in app.py, and it deliberately has no
Streamlit UI calls of its own (st.write, st.button, etc.) — every
function here is plain Python, independently testable without a running
Streamlit session, matching this whole project's own established
"verify against real logic, not just trust the UI" discipline.

Rule: run_pipeline.py is NEVER
modified by the GUI. Every function below either prepares inputs for it (temp
directory, config files, uploaded zips) or reads its outputs (results
CSVs) — none of them import run_pipeline.py itself, since it is launched
as an isolated subprocess, not called in-process.

Per Section 1's "Platform integration constraints": this module's own
logging goes through the platform's shared src.core.logger, not a
separate mechanism — kept deliberately distinct from the PIPELINE
SUBPROCESS's own, independent logging system (src/rao/config/rao_config.yaml's
own debug_log_mode, output/run_log.txt), which is untouched by this file
and continues to work exactly as already built and verified.
"""

from __future__ import annotations

import importlib.util
import io
import json
import os
import re
import shutil
import subprocess
import sys
import tempfile
import zipfile
from pathlib import Path
from typing import Iterator, Optional

import yaml

try:
    # Platform's own shared logger — confirmed, per the design doc's own
    # "Platform integration constraints", that this GUI layer's code uses
    # it. Wrapped in try/except ONLY so this module stays importable (for
    # its own direct, non-Streamlit unit testing) in an environment that
    # does not have the platform's src.core package on the path — falls
    # back to the standard library's own logging in that case, never
    # silently swallowing anything.
    from src.core.logger import get_logger
    logger = get_logger(__name__)
except ImportError:
    import logging
    logger = logging.getLogger(__name__)


# ---------------------------------------------------------------------------
# Locating the pipeline source and the top-level repo root.
#
# THIRD CORRECTION to this section's own history, recorded plainly rather
# than silently overwritten — see the two corrections still recorded
# below for the full history of how this resolution logic got here.
#
# NOW: config/ has moved to src/rao/config/ (Option B — run_pipeline.py's own
# two hardcoded config paths were updated directly to match, an explicit,
# deliberate exception to that file's normal "never modified" rule,
# confirmed and approved before making this change). This actually
# SIMPLIFIES what was previously a real complication: config-reading no
# longer needs a separate ACTUAL_REPO_ROOT-based path distinct from
# SRC_ROOT — both the pipeline source and its config now live under the
# same src/ directory, alongside rao_pages/ itself. ACTUAL_REPO_ROOT
# still exists below, kept for the one thing that's still genuinely
# top-level and unrelated to the pipeline's own config:
# .rao_gui_settings.json (this GUI's own settings-persistence file).
#
# SECOND CORRECTION (kept for history): the first version assumed
# rao_pages/ was a sibling of src/rao/ under a shared src/. That was
# wrong at the time — app.py lived at the actual repo root, and
# st.Page() resolves relative to app.py's own directory (confirmed
# directly from Streamlit's own source: streamlit/navigation/page.py),
# so rao_pages/ had to be a repo-root-level sibling of app.py instead.
# That was fixed accordingly, then app.py itself later moved to
# src/app.py (alongside .streamlit/, static/, rao_pages/, olf_pages/,
# pf_pages/, home.py — all moving together, confirmed consistent via the
# same Streamlit-source-level checks), making rao_pages/ genuinely a
# sibling of src/rao/ again — the ORIGINAL assumption, now actually
# correct for a different reason than before.
# ---------------------------------------------------------------------------
_THIS_FILE = Path(__file__).resolve()
RAO_PAGES_DIR = _THIS_FILE.parent          # .../src/rao_pages/
SRC_ROOT = RAO_PAGES_DIR.parent            # .../src/  (rao_pages/, rao/, and now config/ are siblings here)
PIPELINE_SRC_DIR = SRC_ROOT / "rao"        # .../src/rao/
ACTUAL_REPO_ROOT = SRC_ROOT.parent         # the real top-level repo root — where app.py, input/, output/, .rao_gui_settings.json live


def _pipeline_text_encoding() -> str:
    """TEXT_ENCODING of src/rao/text_encoding.py (the one encoding rule of the pipeline and its
    GUI: UTF-8 without BOM), loaded by file path because the GUI does not put src/rao on sys.path."""
    spec = importlib.util.spec_from_file_location("rao_text_encoding", PIPELINE_SRC_DIR / "text_encoding.py")
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module.TEXT_ENCODING


TEXT_ENCODING = _pipeline_text_encoding()


# ---------------------------------------------------------------------------
# Confirmed exact defaults — read directly from the real config files at
# import time, NOT hand-copied constants that could silently drift out of
# sync with the actual codebase. If src/rao/config/rao_config.default.yaml
# or src/rao/config/load_flow_config.yaml themselves change, these follow
# automatically without this file needing an edit.
#
# CORRECTED placement: config/ nests under src/rao/ specifically (not
# src/ directly) — matching run_pipeline.py's own updated
# RAO_CONFIG_PATH/LOAD_FLOW_CONFIG_PATH. Reads via PIPELINE_SRC_DIR
# (src/rao/), not SRC_ROOT (src/), since config/ is now a direct sibling
# of run_pipeline.py itself, one level deeper than the first version of
# this move placed it.
# ---------------------------------------------------------------------------

def _default_rao_config() -> dict:
    path = PIPELINE_SRC_DIR / "config" / "rao_config.default.yaml"
    if not path.exists():
        path = PIPELINE_SRC_DIR / "config" / "rao_config.yaml"
    with open(path, encoding=TEXT_ENCODING) as f:
        config = yaml.safe_load(f)
    # the correction factors of calculation_mode dc are edited in the config file only: a GUI run uses
    # the table of the active file (the user's entries), not the default file's
    active_path = PIPELINE_SRC_DIR / "config" / "rao_config.yaml"
    if active_path.exists():
        with open(active_path, encoding=TEXT_ENCODING) as f:
            active = yaml.safe_load(f) or {}
        if isinstance(active.get("dc_mode"), dict):
            config["dc_mode"] = active["dc_mode"]
    return config


def _default_load_flow_config() -> dict:
    path = PIPELINE_SRC_DIR / "config" / "load_flow_config.yaml"
    with open(path, encoding=TEXT_ENCODING) as f:
        return yaml.safe_load(f)


DEFAULT_RAO_CONFIG = _default_rao_config()
DEFAULT_LOAD_FLOW_CONFIG = _default_load_flow_config()

# Safety net against config drift — found directly from a real failure:
# a KeyError crash when the user's own on-disk config/rao_config.yaml
# predates a section this GUI code expects (logging_options, added
# alongside debug_log_mode). Rather than let a config file that's simply
# a few changes behind hard-crash the whole page, any top-level section
# missing from what was actually loaded off disk is filled in here from
# a hardcoded, known-correct minimal shape — the GUI stays usable, and a
# warning is logged so the real fix (updating the on-disk config file)
# doesn't go unnoticed.
_HARDCODED_SECTION_FALLBACKS = {
    "workflow_toggles": {
        "ra_types": ["pst", "rd"], "calculation_mode": "ac_iterative",
        "enable_nx_analysis": False, "pst_taping_discrete": True,
        "ra_limit_constraint_hard": True, "scanned_element_constraint_hard": True,
    },
    "thresholds": {
        "min_loading_threshold_pct": 0.0, "min_loading_threshold_pct_nx": 0.0,
        "sensitivity_threshold_pct_pst": 0.0, "sensitivity_threshold_pct_rd": 0.0,
        "sensitivity_threshold_pct_pst_nx": 0.0, "sensitivity_threshold_pct_rd_nx": 0.0,
        "max_change_ra_sum_threshold": 1.0, "max_change_ra": 1.0, "max_change_overload": 1.0,
    },
    "iteration_caps": {
        "max_linearisation_iterations": 10, "max_completeness_iterations": 5,
        "incremental_ac_fallback_max_steps": 5,
    },
    "ra_limits": {
        "max_ra_count_per_timestamp_tso": None, "max_ra_count_per_timeframe_tso": None,
        "ra_limit_penalty": 100.0, "max_taps_per_tso": 6,
    },
    "penalty_costs": {
        "penalty_reference_pst_pra": 100.0, "penalty_reference_rd_pra": 100.0,
        "penalty_reference_hvdc_pra": 100.0, "penalty_reference_hvdc_cra": 100.0,
        "penalty_reference_ct_pra": 100.0, "penalty_reference_ct_cra": 100.0,
        "penalty_cost_overload_n0": 10000.0, "penalty_cost_overload_nx_patl": 10000.0,
        "penalty_cost_overload_nx_tatl": 100000.0, "penalty_cost_overload_nx_scanned": 10000.0,
        "scanned_element_penalty_eur_per_ka": 0.0,
    },
    "logging_options": {"debug_log_mode": False},
    "dc_mode": {"current_factor_by_nominal_voltage_kv": {"default": 1.0}},
}
_missing_keys_found: list[str] = []
for _section, _fallback_values in _HARDCODED_SECTION_FALLBACKS.items():
    if _section not in DEFAULT_RAO_CONFIG:
        DEFAULT_RAO_CONFIG[_section] = dict(_fallback_values)
        _missing_keys_found.append(f"{_section} (entire section)")
        continue
    # Section exists but may itself be missing individual keys — found
    # directly from a real second failure: 'thresholds' was present, but
    # missing max_change_ra/max_change_overload specifically (added by
    # the R1.7 criteria 3/4 work). Whole-section-only checking missed
    # this entirely; merge key-by-key within every existing section too.
    for _key, _fallback_value in _fallback_values.items():
        if _key not in DEFAULT_RAO_CONFIG[_section]:
            DEFAULT_RAO_CONFIG[_section][_key] = _fallback_value
            _missing_keys_found.append(f"{_section}.{_key}")

if _missing_keys_found:
    logger.warning(
        "src/rao/config/rao_config.yaml on disk is missing %d key(s) the code "
        "expects: %s — the on-disk config file is behind the code and "
        "should be updated. Using hardcoded fallback values for these "
        "so the GUI stays usable in the meantime.",
        len(_missing_keys_found), ", ".join(_missing_keys_found),
    )

# Same class of protection, same reasoning, for load_flow_config.yaml —
# no confirmed real failure here yet, but the same drift risk applies
# equally, and closing it off now is cheap versus discovering it one
# missing key at a time the way rao_config.yaml's gaps were found.
_LOAD_FLOW_CONFIG_FALLBACKS = {
    "use_reactive_limits": False, "voltage_init_mode": "UNIFORM_VALUES",
    "transformer_voltage_control_on": False, "phase_shifter_regulation_on": False,
    "twt_split_shunt_admittance": False, "shunt_compensator_voltage_control_on": False,
    "read_slack_bus": True, "write_slack_bus": True, "distributed_slack": True,
    "balance_type": "PROPORTIONAL_TO_GENERATION_P_MAX", "component_mode": "MAIN_SYNCHRONOUS",
    "hvdc_ac_emulation": True, "dc_power_factor": 1.0,
}
_missing_lf_keys = [k for k in _LOAD_FLOW_CONFIG_FALLBACKS if k not in DEFAULT_LOAD_FLOW_CONFIG]
if _missing_lf_keys:
    logger.warning(
        "src/rao/config/load_flow_config.yaml on disk is missing %d key(s) the "
        "code expects: %s — using hardcoded fallback values so the GUI "
        "stays usable in the meantime.",
        len(_missing_lf_keys), ", ".join(_missing_lf_keys),
    )
    for _key in _missing_lf_keys:
        DEFAULT_LOAD_FLOW_CONFIG[_key] = _LOAD_FLOW_CONFIG_FALLBACKS[_key]

# Confirmed via pypowsybl directly (not guessed) — see this module's own
# development notes: pp.loadflow.VoltageInitMode, .BalanceType,
# .ComponentMode. ComponentMode is the RIGHT enum for the
# "component_mode" LoadFlowParameters field specifically — a genuinely
# different, easily-confused sibling enum, pp.loadflow.ConnectedComponentMode
# (values ALL / MAIN), exists too but is NOT what this field uses.
VOLTAGE_INIT_MODE_OPTIONS = ["DC_VALUES", "PREVIOUS_VALUES", "UNIFORM_VALUES"]
BALANCE_TYPE_OPTIONS = [
    "PROPORTIONAL_TO_CONFORM_LOAD",
    "PROPORTIONAL_TO_GENERATION_P",
    "PROPORTIONAL_TO_GENERATION_PARTICIPATION_FACTOR",
    "PROPORTIONAL_TO_GENERATION_P_MAX",
    "PROPORTIONAL_TO_GENERATION_REMAINING_MARGIN",
    "PROPORTIONAL_TO_LOAD",
]
COMPONENT_MODE_OPTIONS = ["ALL_CONNECTED", "MAIN_CONNECTED", "MAIN_SYNCHRONOUS"]

# RAO Settings page fields explicitly EXCLUDED from the GUI, per the
# confirmed design decision — config-file-editable only. See the design
# doc's own per-item reasoning (Section 4/Page 1) for why each one:
# pst_taping_discrete (modeling-fidelity risk), ra_limit_constraint_hard
# (inert while its own limits default to None), scanned_element_constraint_hard
# (narrower, one-shot SNEC concept). Never rendered as a widget anywhere.
WORKFLOW_TOGGLES_HIDDEN_FROM_GUI = {
    "pst_taping_discrete", "ra_limit_constraint_hard", "scanned_element_constraint_hard",
}
# penalty_costs section: not configurable in v1, except the HVDC and countertrade references (3_RAO_Settings.py).
RA_LIMITS_HIDDEN_FROM_GUI = {"ra_limit_penalty"}  # grouped with penalty costs, not a structural limit


# ---------------------------------------------------------------------------
# Settings persistence — confirmed design: survives a full app restart,
# single local user, no concurrency concerns (Section 6).
# ---------------------------------------------------------------------------

SETTINGS_FILE_PATH = ACTUAL_REPO_ROOT / ".rao_gui_settings.json"


def migrate_saved_workflow_toggles(saved_toggles: dict) -> dict:
    """Settings saved before ra_types existed hold enable_pst_remedial_actions and
    enable_rd_remedial_actions, which the pipeline rejects. Drop them and, when the saved
    settings have no ra_types, derive it from them."""
    migrated = dict(saved_toggles)
    old_pst = migrated.pop("enable_pst_remedial_actions", None)
    old_rd = migrated.pop("enable_rd_remedial_actions", None)
    if "ra_types" not in migrated and (old_pst is not None or old_rd is not None):
        migrated["ra_types"] = [
            ra_type for ra_type, enabled in (("pst", old_pst is not False), ("rd", old_rd is not False)) if enabled
        ]
    return migrated


def migrate_saved_load_flow_config(saved_load_flow_config: dict) -> tuple[dict, list[str]]:
    """Settings saved while the Load Flow page still accepted dc_power_factor 0.0 (minimum 0.0) hold
    a value the page (minimum 0.01) and a calculation_mode dc run reject. A saved dc_power_factor
    that is not a number > 0 becomes the default 1.0. Returns (migrated settings, notes for the
    pages; empty when nothing changed)."""
    migrated = dict(saved_load_flow_config)
    if "dc_power_factor" not in migrated:
        return migrated, []
    value = migrated["dc_power_factor"]
    if not isinstance(value, bool) and isinstance(value, (int, float)) and value > 0:
        return migrated, []
    default = _LOAD_FLOW_CONFIG_FALLBACKS["dc_power_factor"]
    migrated["dc_power_factor"] = default
    return migrated, [
        f"The saved load flow setting dc_power_factor = {value!r} is not a number greater than 0; the "
        f"default {default} is used. Save the load flow settings to keep it."
    ]


# The calculation mode chosen on the Main page for the next run. Kept under a plain (non-widget)
# session-state key: Streamlit deletes the state of a widget that is not rendered in a run, so the
# selectbox's own key is gone on the RAO Settings page and after returning to Main.
CALCULATION_MODE_STATE_KEY = "selected_calculation_mode"
CALCULATION_MODE_OPTIONS = ["ac_iterative", "ac_single_pass", "dc"]
# the modes that run one pass: they ignore the iteration caps and the convergence thresholds
ONE_PASS_CALCULATION_MODES = ("ac_single_pass", "dc")


def ignores_loop_settings(calculation_mode: str) -> bool:
    """True for the one-pass modes (ac_single_pass, dc): the RAO Settings page greys out the iteration
    caps and the convergence thresholds."""
    return calculation_mode in ONE_PASS_CALCULATION_MODES


def selected_calculation_mode(session_state, workflow_toggles: dict) -> str:
    """The calculation mode of the next run: the one chosen on the Main page in this session,
    else the saved / default setting."""
    return session_state.get(CALCULATION_MODE_STATE_KEY, workflow_toggles["calculation_mode"])


def load_settings() -> dict:
    """Loads persisted settings from disk. Falls back to the codebase's
    own real defaults (read from the actual config files, not
    hand-copied) if the settings file is absent or unreadable — never
    raises for a missing/corrupt settings file, since that would block
    the GUI from starting at all over a recoverable condition.
    "notes": what a migration of the saved settings changed (each page shows them).
    """
    defaults = {"rao_config": DEFAULT_RAO_CONFIG, "load_flow_config": DEFAULT_LOAD_FLOW_CONFIG, "notes": []}
    if not SETTINGS_FILE_PATH.exists():
        return defaults
    try:
        with open(SETTINGS_FILE_PATH, encoding=TEXT_ENCODING) as f:
            saved = json.load(f)
        # Merge shallowly over defaults section-by-section, so a settings
        # file saved before a new config key existed doesn't silently
        # drop that new key — it still gets its real default.
        merged = {"rao_config": {}, "load_flow_config": {}, "notes": []}
        for section, default_values in DEFAULT_RAO_CONFIG.items():
            saved_values = saved.get("rao_config", {}).get(section, {})
            if section == "workflow_toggles":
                saved_values = migrate_saved_workflow_toggles(saved_values)
            if section == "dc_mode":
                saved_values = {}  # edited in the config file only: never frozen into the saved settings
            merged["rao_config"][section] = {**default_values, **saved_values}
        saved_load_flow_config, merged["notes"] = migrate_saved_load_flow_config(saved.get("load_flow_config", {}))
        merged["load_flow_config"] = {**DEFAULT_LOAD_FLOW_CONFIG, **saved_load_flow_config}
        return merged
    except (json.JSONDecodeError, OSError) as e:
        logger.warning("Could not read settings file (%s) — using defaults: %s", SETTINGS_FILE_PATH, e)
        return defaults


def save_settings(rao_config: dict, load_flow_config: dict) -> None:
    # the dc_mode factor table is edited in the config file only: never stored here (DECISIONS 56)
    rao_config = {section: values for section, values in rao_config.items() if section != "dc_mode"}
    payload = {"rao_config": rao_config, "load_flow_config": load_flow_config}
    with open(SETTINGS_FILE_PATH, "w", encoding=TEXT_ENCODING) as f:
        json.dump(payload, f, indent=2)


# ---------------------------------------------------------------------------
# CGM upload validation (Section 2) — light, advisory structural check.
# pypowsybl's own loading remains the real authority; this only exists to
# turn a cryptic deep pypowsybl error into an early, readable one for the
# common case (empty zip, obviously wrong file type).
# ---------------------------------------------------------------------------

def validate_cgm_upload(zip_bytes: bytes) -> tuple[bool, list[str]]:
    """Returns (is_valid, messages). Advisory only — a pass here does not
    guarantee pypowsybl will accept the file; a failure here means
    something is obviously, cheaply wrong before even trying.
    """
    messages: list[str] = []
    try:
        with zipfile.ZipFile(io.BytesIO(zip_bytes)) as zf:
            names = zf.namelist()
    except zipfile.BadZipFile:
        return False, ["Not a valid zip file."]

    if not names:
        return False, ["Zip file is empty."]

    eq_files = [n for n in names if re.search(r"_EQ_", n, re.IGNORECASE)]
    if not eq_files:
        messages.append(
            "No file matching the expected *_EQ_*.xml naming pattern was found. "
            "This may not be a valid CGM package — pypowsybl's own loading is the "
            "final authority, but this is worth checking before running."
        )
        return False, messages

    messages.append(f"{len(names)} file(s) found, including {len(eq_files)} EQ profile(s).")
    return True, messages


# ---------------------------------------------------------------------------
# NCP upload validation (Section 3) — CONFIRMED to reuse the pipeline's
# own real ncp_loader functions directly, NOT a separate re-implementation
# of the same rules. Found directly in ncp_loader.py's own docstring:
# classify_extracted_ncp_files's validation is explicitly "the same rules
# agreed for the equivalent GUI-facing design" — meaning the pipeline
# code already IS this validation; calling it directly here gives
# genuine, accurate "will this actually work" validation rather than a
# second implementation that could silently drift out of sync with the
# real one.
# ---------------------------------------------------------------------------

def validate_ncp_upload(zip_bytes: bytes) -> tuple[bool, list[str], Optional[dict]]:
    """Returns (is_valid, messages, ncp_files_or_None).

    Extracts to a scratch temp directory, runs the REAL
    ncp_loader.extract_ncp_zip / classify_extracted_ncp_files against it,
    and reports whatever those real functions find — including their own
    hard-error conditions (duplicate TSO+profile, missing required
    profile) surfaced as validation failures here, not just at Run time.
    """
    sys.path.insert(0, str(PIPELINE_SRC_DIR)) if str(PIPELINE_SRC_DIR) not in sys.path else None
    from pre_milp import ncp_loader, tso_name_resolver  # local import: only needed here

    messages: list[str] = []
    with tempfile.TemporaryDirectory(prefix="rao_gui_ncp_validate_") as scratch:
        scratch_path = Path(scratch)
        zip_path = scratch_path / "ncp_upload.zip"
        zip_path.write_bytes(zip_bytes)
        extract_dir = scratch_path / "_extracted_ncp"
        try:
            org_cd_path = ncp_loader.extract_ncp_zip(zip_path, extract_dir)
        except FileNotFoundError as e:
            return False, [str(e)], None
        except ValueError as e:
            return False, [f"Duplicate file basename in upload: {e}"], None

        try:
            tso_name_map = tso_name_resolver.build_tso_name_map(org_cd_path)
        except Exception as e:  # noqa: BLE001 — surfaced as a validation message either way
            return False, [f"Could not resolve TSO names from Organisation profile: {e}"], None

        try:
            ncp_files = ncp_loader.classify_extracted_ncp_files(extract_dir, tso_name_map)
        except ValueError as e:
            # Real hard-error conditions from the pipeline's own logic —
            # duplicate (TSO, profile) or a TSO missing a required
            # profile — surfaced exactly as the pipeline itself would
            # raise them.
            return False, [str(e)], None

        messages.append(f"{len(ncp_files)} TSO(s) recognized: {sorted(ncp_files.keys())}")
        for tso, profiles in sorted(ncp_files.items()):
            missing_optional = {"SHS", "SIS"} - profiles.keys()
            if missing_optional:
                messages.append(
                    f"{tso}: missing optional profile(s) {sorted(missing_optional)} — "
                    f"not an error, matches existing pipeline behaviour."
                )
        return True, messages, ncp_files


# ---------------------------------------------------------------------------
# Subprocess isolation (Section 1) — run_pipeline.py itself is NEVER
# modified. This builds a temp directory shaped exactly as REPO_ROOT
# resolution requires it (confirmed directly from run_pipeline.py's own
# _find_repo_root: walks UPWARD from wherever run_pipeline.py itself
# physically lives on disk until it finds src/rao/data_model.py — NOT
# based on cwd at all), copies the real pipeline source into it, writes
# the config files run_pipeline.py already reads unmodified from fixed,
# REPO_ROOT-relative paths, and launches it by its own absolute path.
# ---------------------------------------------------------------------------

def build_temp_run_dir(cgm_zip_bytes: bytes, ncp_zip_bytes: bytes, rao_config: dict, load_flow_config: dict) -> Path:
    """Builds a complete, self-contained temp directory a pipeline
    subprocess can run against, matching run_pipeline.py's own REPO_ROOT
    resolution and fixed config/input path expectations exactly.
    """
    tmpdir = Path(tempfile.mkdtemp(prefix="rao_gui_run_"))

    # src/rao/ — a real copy, not a symlink. Symlinks are avoided
    # deliberately: _find_repo_root walks Path(__file__).parent, which
    # resolves through symlinks inconsistently across platforms — a
    # plain copy sidesteps that entirely. Confirmed as an "open
    # implementation detail" in the design doc (Section 12); resolved
    # here as: copy, not symlink.
    dest_src_rao = tmpdir / "src" / "rao"
    shutil.copytree(PIPELINE_SRC_DIR, dest_src_rao)

    # src/rao/config/ — the exact 2 YAML files run_pipeline.py reads from
    # fixed, REPO_ROOT-relative paths (src/rao/config/rao_config.yaml,
    # src/rao/config/load_flow_config.yaml — confirmed directly from
    # run_pipeline.py's own LOAD_FLOW_CONFIG_PATH/RAO_CONFIG_PATH
    # constants, updated when config/ moved under src/rao/ specifically
    # — Option B, an explicit, approved exception to this file's normal
    # never-modified rule). CORRECTED placement: config/ nests under
    # src/rao/, not src/ directly — the shutil.copytree call above
    # already copies whatever config/ exists on disk as part of copying
    # the whole src/rao/ tree; this write-out then OVERWRITES those 2
    # files specifically with the user's actual, current GUI-configured
    # settings (which may differ from whatever was on disk), ensuring
    # the subprocess runs with what the user actually intended, not
    # just a stale copy.
    config_dir = dest_src_rao / "config"
    config_dir.mkdir(parents=True, exist_ok=True)
    with open(config_dir / "rao_config.yaml", "w", encoding=TEXT_ENCODING) as f:
        yaml.safe_dump(rao_config, f, default_flow_style=False, sort_keys=False)
    with open(config_dir / "load_flow_config.yaml", "w", encoding=TEXT_ENCODING) as f:
        yaml.safe_dump(load_flow_config, f, default_flow_style=False, sort_keys=False)

    # input/ — confirmed exact expected shape (INPUT_DIR = REPO_ROOT /
    # "input", _find_unique_zip_by_prefix matches by case-insensitive
    # filename PREFIX, not exact name) — "cgm_package.zip" and
    # "ncp_upload.zip" both satisfy their respective "cgm"/"ncp" prefix
    # match.
    input_dir = tmpdir / "input"
    input_dir.mkdir(parents=True, exist_ok=True)
    (input_dir / "cgm_package.zip").write_bytes(cgm_zip_bytes)
    (input_dir / "ncp_upload.zip").write_bytes(ncp_zip_bytes)

    return tmpdir


def run_pipeline_subprocess(tmpdir: Path) -> Iterator[str]:
    """Launches the pipeline as an isolated subprocess and yields its
    combined stdout/stderr, one line at a time, as it arrives — for live
    streaming into the GUI's log panel (Section 1, Section 8).

    Launched by the COPIED file's own absolute path
    (tmpdir/src/rao/run_pipeline.py), not via cwd + relative path or
    python -m — confirmed this is what makes _find_repo_root's own
    upward walk resolve to tmpdir correctly, since that walk starts from
    Path(__file__).parent of whichever file is actually executing.
    """
    pipeline_script = tmpdir / "src" / "rao" / "run_pipeline.py"
    # the pipeline's console output (stdout and the logging stream on stderr) is written and read
    # as TEXT_ENCODING: a pipe would otherwise use the locale codepage on both sides
    env = dict(os.environ, PYTHONIOENCODING=TEXT_ENCODING)
    process = subprocess.Popen(
        [sys.executable, str(pipeline_script)],
        cwd=str(tmpdir),
        stdout=subprocess.PIPE,
        stderr=subprocess.STDOUT,
        text=True,
        encoding=TEXT_ENCODING,
        bufsize=1,
        env=env,
    )
    assert process.stdout is not None
    for line in process.stdout:
        yield line.rstrip("\n")
    process.wait()
    yield f"__RAO_GUI_PROCESS_EXIT_CODE__:{process.returncode}"


def cleanup_temp_run_dir(tmpdir: Path) -> None:
    """Section 12: cleanup policy decided as "clean up after the user has
    downloaded whatever they want" — called explicitly by the page after
    results have been read and offered for download, not automatically
    on every rerun.
    """
    shutil.rmtree(tmpdir, ignore_errors=True)


# ---------------------------------------------------------------------------
# Inventory reporting (Section 7) — Tier 1 ("Parsed") and Tier 2 ("Passed
# to MILP").
# ---------------------------------------------------------------------------

def compute_tier1_inventory(ncp_zip_bytes: bytes) -> dict:
    """Tier 1 — "Parsed", shown before Run.

    IMPORTANT, CONFIRMED DEVIATION FROM THE ORIGINAL DESIGN DOC, NOT A
    SILENT SIMPLIFICATION: the design doc's own Section 7 envisioned
    Tier 1 as PRA/CRA-classified AE/PST/RD/bid counts, closely matching
    inventory_summary.print_inventory_summary()'s own output. Checked
    directly against the real code: parse_assessed_elements/parse_psts/
    parse_rd_units ALL require CGM-derived data as required arguments
    (cgm_static_patl, cgm_tap_changers, cgm_generating_units) — and
    confirmed directly in run_pipeline.py's own real call order, even
    the ACTUAL PIPELINE cannot produce this summary until AFTER its own
    full CGM load (R0.1, a genuinely expensive pypowsybl operation) has
    already happened. There is no cheap shortcut to the classified
    numbers — computing them here would mean either duplicating that
    same expensive CGM load a second time before Run, or showing numbers
    that don't actually match what the real run will use.

    What this function actually returns instead: RAW, file-level counts
    — how many of each recognized CIM element type exist per TSO's XML
    files, via direct XML parsing, with NO classification into PRA/CRA,
    SECURED/SCANNED, or anything requiring CGM cross-referencing. Cheap,
    fast, genuinely available at upload time — but a different, coarser
    signal than the design doc originally described. Answers "did my
    upload look structurally right" honestly; does NOT answer "how many
    PST/RD/bids will the MILP actually use" (that's what Tier 2 is for,
    computed from the real, completed run's own output).
    """
    import xml.etree.ElementTree as ET

    sys.path.insert(0, str(PIPELINE_SRC_DIR)) if str(PIPELINE_SRC_DIR) not in sys.path else None
    from pre_milp import ncp_loader, tso_name_resolver

    with tempfile.TemporaryDirectory(prefix="rao_gui_tier1_") as scratch:
        scratch_path = Path(scratch)
        ncp_zip_path = scratch_path / "ncp.zip"
        ncp_zip_path.write_bytes(ncp_zip_bytes)
        extract_dir = scratch_path / "_extracted_ncp"
        org_cd_path = ncp_loader.extract_ncp_zip(ncp_zip_path, extract_dir)
        tso_name_map = tso_name_resolver.build_tso_name_map(org_cd_path)
        ncp_files = ncp_loader.classify_extracted_ncp_files(extract_dir, tso_name_map)

        per_tso: dict[str, dict] = {}
        for tso, profiles in sorted(ncp_files.items()):
            counts = {"profiles_present": sorted(profiles.keys())}
            ae_path = profiles.get("AE")
            if ae_path is not None:
                tree = ET.parse(ae_path)
                ns = {"cim": "http://iec.ch/TC57/2013/CIM-schema-cim16#"}
                # Tag-name count only (no ae_type classification, which
                # requires cross-referencing CO_flat_list — CGM-adjacent
                # data this function deliberately does not load).
                counts["assessed_element_tag_count"] = len(
                    tree.getroot().findall(".//cim:AssessedElement", ns)
                ) or len(tree.getroot().findall(".//{*}AssessedElement"))
            ra_path = profiles.get("RA")
            if ra_path is not None:
                tree = ET.parse(ra_path)
                counts["tap_position_action_tag_count"] = len(
                    tree.getroot().findall(".//{*}TapPositionAction")
                )
                counts["rotating_machine_action_tag_count"] = len(
                    tree.getroot().findall(".//{*}RotatingMachineAction")
                )
            sis_path = profiles.get("SIS")
            if sis_path is not None:
                tree = ET.parse(sis_path)
                counts["power_bid_schedule_tag_count"] = len(
                    tree.getroot().findall(".//{*}PowerBidSchedule")
                )
            per_tso[tso] = counts
        return per_tso


def read_tier2_inventory(output_dir: Path) -> dict:
    """Tier 2 — the real, final numbers after a completed run: read
    directly from the actual results CSVs in output_dir, not re-derived.
    """
    import csv

    def _count_rows(csv_path: Path) -> int:
        if not csv_path.exists():
            return 0
        with open(csv_path, newline="", encoding=TEXT_ENCODING) as f:
            return sum(1 for _ in csv.DictReader(f))

    return {
        "pst_count": _count_rows(output_dir / "results_pst.csv"),
        "rd_bid_count": _count_rows(output_dir / "results_preventive_rd.csv"),
        "ra_count_rows": _count_rows(output_dir / "results_preventive_rd_ra_count.csv"),
    }
