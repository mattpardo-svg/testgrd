import streamlit as st
import tempfile
from typing import Any
from src.core.pf.security_analysis_request import request_security_analysis
from src.core.parser_contingencies import parse_contingencies
from src.core.config import config

st.markdown("# Security Analysis")
st.sidebar.header("Security Analysis")

def file_upload():
    uploaded_ncp = st.session_state.sa_uploaded_ncp_xml
    if uploaded_ncp is not None:
        with tempfile.NamedTemporaryFile(delete=False, prefix="pytsc_co_", suffix=".xml") as tmp:
            tmp.write(uploaded_ncp.getbuffer())
            st.session_state["contingencies_file_path"] = tmp.name
        st.session_state['pf_sa_contingencies'] = parse_contingencies(tmp.name, '_')

def perform_sa() -> None:
    with st.spinner("Running Security Analysis..."):
        if 'pf_current_model' in st.session_state and st.session_state['pf_current_model'] is not None:
            result, sa_results, output = request_security_analysis(st.session_state['pf_current_model'], st.session_state["contingencies_file_path"])
            st.session_state['pf_sa_result'] = result
            st.session_state['pf_sa_output'] = output
            if result:
                st.session_state['pf_sa_results'] = sa_results

def get_sa_results() -> Any:
    if 'pf_sa_results' in st.session_state and st.session_state['pf_sa_results'] is not None:
        return st.session_state['pf_sa_results']

if 'pf_current_model' in st.session_state and st.session_state['pf_current_model'] is not None and \
'pf_db_checked' in st.session_state and st.session_state.pf_db_checked:
    st.caption(f'Current Grid Model: {st.session_state.pf_current_model}. Verified in DB: {st.session_state.pf_db_checked}')
elif 'pf_current_model' in st.session_state:
    st.warning(f'Current Grid Model: {st.session_state.pf_current_model}. Verified in DB: No')
else:
    st.session_state.pf_current_model = config.get('paths', 'last_pf_model', '')
    st.error(f'Default Grid Model: {st.session_state.pf_current_model}. Verified in DB: No')
if 'contingencies_file_path' in st.session_state:
    st.caption(f"Active Contingencies NC Profile: {st.session_state['contingencies_file_path']}")

st.write("**Upload or select an NCP XML contingency file**")
uploaded_ncp = st.file_uploader("Upload NCP XML", type=["xml"], key="sa_uploaded_ncp_xml", on_change=file_upload)

enabled = 'pf_current_model' in st.session_state and st.session_state['pf_current_model'] is not None
st.button("Perform Security Analysis", type="primary", on_click=perform_sa, disabled=not enabled)

sa_result = st.session_state.get('pf_sa_result')
sa_attempted = 'pf_sa_result' in st.session_state
sa_has_results = st.session_state.get('pf_sa_results') is not None
sa_has_output = st.session_state.get('pf_sa_output') is not None
sa_contingencies = st.session_state.get("pf_sa_contingencies") is not None

# ---- Security Analysis Summary ----
if sa_attempted or sa_contingencies or sa_has_output:
    if sa_result is False:
        st.error("Security Analysis failed.")
    with st.expander("Security Analysis Summary", expanded=False):
        if sa_contingencies:
            with st.expander("Contingencies Definition"):
                st.table(st.session_state.pf_sa_contingencies)

        if sa_has_output:
             with st.expander("Security Analysis Log"):
                 st.text("\n".join(st.session_state['pf_sa_output']))

if sa_has_results:
    # ---- Branch Thermal Loading ----
    st.write("### Post-Contingency Limit Violations")
    pd_res = get_sa_results()
    st.dataframe(pd_res)