import streamlit as st
from pathlib import Path

# Script-relative, not CWD-relative — same fix, same reasoning, as
# app.py's own logo paths: "./src/images/..." only resolved correctly
# from one specific working directory and silently broke once home.py
# moved under src/ alongside app.py. This was found and fixed proactively
# here, before being hit separately — same root cause as the app.py
# failure just diagnosed, not yet reported for this file specifically.
_LOGO_PATH = Path(__file__).resolve().parent / "images" / "TSCNET_Full_Logo_3400px.png"

st.write("# Welcome to pyTSCFlowBox")
st.image(str(_LOGO_PATH), width=400)

with st.container(border=True, horizontal_alignment="center", width="content"):
    st.header("PowSyBl & PowerFactory Modules")
    st.subheader("Feat. Closed RAO (Gurobi) Module")


