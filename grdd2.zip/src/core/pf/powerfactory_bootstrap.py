from __future__ import annotations

import os
import sys
from pathlib import Path

from src.core.config import config

_DLL_HANDLES = []


def load_powerfactory_module():
    """Load the PowerFactory Python module with proper DLL search paths on Windows."""
    pf_path_raw = config.get("paths", "powerfactory_path", "")
    pf_path = Path(pf_path_raw)

    if not pf_path_raw:
        raise ImportError("PowerFactory path is not configured in [paths].powerfactory_path")

    if not pf_path.exists():
        raise ImportError(f"Configured PowerFactory path does not exist: {pf_path_raw}")

    # Ensure Python locates the PowerFactory module before any similarly named package.
    normalized_pf_path = os.path.normcase(os.path.normpath(str(pf_path)))
    sys.path = [
        p for p in sys.path
        if os.path.normcase(os.path.normpath(p)) != normalized_pf_path
    ]
    sys.path.insert(0, str(pf_path))

    # Python 3.8+ on Windows requires explicit DLL directories for dependent DLLs.
    if os.name == "nt" and hasattr(os, "add_dll_directory"):
        candidates = [
            pf_path,
            pf_path.parent,
            pf_path.parent / "bin",
        ]
        for candidate in candidates:
            if candidate.exists():
                _DLL_HANDLES.append(os.add_dll_directory(str(candidate)))

    import powerfactory

    return powerfactory
