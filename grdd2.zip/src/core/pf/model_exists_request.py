import sys
import subprocess
from src.core.json_utilities import str_to_dict
from src.core.logger import get_logger

logger = get_logger(__name__)

def request_model_exists(model_name:str) -> bool:
    try:
        logger.info('Requesting model check in DB...')
        result = False
        sp = subprocess.run([sys.executable, "-m", "src.core.pf.model_exists_subprocess", "--model", model_name],
                                capture_output=True, 
                                check=True,
                                text=True)
        logger.debug(sp.stdout)
        result_dict = str_to_dict(sp.stdout)
        logger.info(result_dict)
        logger.debug(result_dict['result'])
        if 'result' in result_dict:
            result = result_dict['result']
        return result
    except subprocess.CalledProcessError as e:
        logger.error(f"Error running module: {e}")
        return False