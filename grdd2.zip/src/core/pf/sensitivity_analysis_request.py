import sys
import subprocess
import pandas as pd
from typing import Tuple, List
from src.core.logger import get_logger
from src.core.json_utilities import str_to_dict

logger = get_logger(__name__)

def request_sensitivity_analysis(model_name:str, co_file:str) -> Tuple[bool, pd.DataFrame, List]:
    try:
        logger.info('Requesting Sensitivity Analysis...')
        result = False
        sn_results = None
        output = []
        sp = subprocess.run([sys.executable, "-m", "src.core.pf.sensitivity_analysis_subprocess", "--model", model_name,
                             "--ra", co_file],
                                capture_output=True, 
                                check=True,
                                text=True)
        logger.info(sp.stdout)
        result_dict = str_to_dict(sp.stdout)

        if 'result' in result_dict:
            result = result_dict['result']
        if result and 'sn_results' in result_dict and result_dict['sn_results'] is not None:
            full_name = str(result_dict['sn_results'])
            logger.info(f'Reading sensitivity analysis results {full_name}')
            sn_results = pd.read_feather(full_name)
        if 'output' in result_dict and result_dict['output'] is not None:
            full_output_name = str(result_dict['output'])
            logger.info(f'Reading output window {full_output_name}')
            with open(full_output_name, 'r', encoding='utf-8') as file:
                output = file.read().splitlines()
        return result, sn_results, output
    except subprocess.CalledProcessError as e:
        logger.error(f"Error running module: {e}")
        return False, None, None

