import sys
from src.core.config import config

def get_pf_lf_configuration() -> dict:
    # return the lf.Parameters object with the retrieved values
    return {
        'iopt_net': config.getint('powerfactory_loadflow', 'iopt_net', 0),
        'iPST_at': int(config.getboolean('powerfactory_loadflow', 'iPST_at', 0)),
        'iopt_plim': int(config.getboolean('powerfactory_loadflow', 'iopt_plim', 0)),
        'iopt_at': int(config.getboolean('powerfactory_loadflow', 'iopt_at', 0)),
        'iopt_asht': int(config.getboolean('powerfactory_loadflow', 'iopt_asht', 0)),
        'iopt_lim': int(config.getboolean('powerfactory_loadflow', 'iopt_lim', 0)),
        'iopt_pq': int(config.getboolean('powerfactory_loadflow', 'iopt_pq', 0)),
        'iopt_fls': int(config.getboolean('powerfactory_loadflow', 'iopt_fls', 0)),
        'iopt_apdist': config.getint('powerfactory_loadflow', 'iopt_apdist', 0),
        'iPbalancing': config.getint('powerfactory_loadflow', 'iPbalancing', 0),
        'itapopt': config.getint('powerfactory_loadflow', 'itapopt', 0),
        'krelax': config.getfloat('powerfactory_loadflow', 'krelax', 1),
        'maxTapTrans': config.getint('powerfactory_loadflow', 'maxTapTrans', 3),
        'maxQlimTrans': config.getint('powerfactory_loadflow', 'maxQlimTrans', 3),
        'iopt_optaplim': int(config.getboolean('powerfactory_loadflow', 'iopt_optaplim', 1)),
        'iopt_limScale': int(config.getboolean('powerfactory_loadflow', 'iopt_limScale', 0)),
        'i_power': config.getint('powerfactory_loadflow', 'i_power', 0),
        'itrlx': config.getint('powerfactory_loadflow', 'itrlx', 25),
        'ictrlx': config.getint('powerfactory_loadflow', 'ictrlx', 20),
        'nsteps': config.getint('powerfactory_loadflow', 'nsteps', 1),
        'errlf': config.getfloat('powerfactory_loadflow', 'errlf', 1),
        'allowedBusErrMV': config.getfloat('powerfactory_loadflow', 'allowedBusErrMV', 1),
        'allowedBusErrLV': config.getfloat('powerfactory_loadflow', 'allowedBusErrLV', 0.01),
        'erreq': config.getfloat('powerfactory_loadflow', 'erreq', 0.1),
        'iStepAdapt': config.getint('powerfactory_loadflow', 'iStepAdapt', 0),
        'iltAlgStag': int(config.getboolean('powerfactory_loadflow', 'iltAlgStag', 10)),
        'iTrimStep': int(config.getboolean('powerfactory_loadflow', 'iTrimStep', 1)),
        'iopt_lev': int(config.getboolean('powerfactory_loadflow', 'iopt_lev', 0)),
        'iopt_notopo': int(config.getboolean('powerfactory_loadflow', 'iopt_notopo', 1)),
        'maxPhaseShift': config.getint('powerfactory_loadflow', 'maxPhaseShift', 20),
        'utr_init': config.getint('powerfactory_loadflow', 'utr_init', 0)
    }
