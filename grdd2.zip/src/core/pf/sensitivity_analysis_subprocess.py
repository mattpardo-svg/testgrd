import sys
from pathlib import Path
import pandas as pd
import uuid
import time
from argparse import ArgumentParser
import numpy as np
from typing import Any, Tuple, Dict
from src.core.config import config
from src.core.logger import get_logger
from src.core.json_utilities import dict_to_json
from src.core.pf.store_pf_results import store_pf_results, store_pf_output
from src.core.pf.config_pf_lf import get_pf_lf_configuration
from src.core.pf.powerfactory_bootstrap import load_powerfactory_module

logger = get_logger(__name__)

pf_path = config.get("paths", "powerfactory_path", "")
sys.path.append(pf_path)
powerfactory = load_powerfactory_module()

def main(model_name:str, ra_def:str) -> None:
    logger.info(model_name)
    unique_name = f"{int(time.time())}_{uuid.uuid4().hex}"
    pd_ra_def = _get_remedial_actions(ra_def)
    result, full_name, output_name = run_sensitivity_analysis(model_name, unique_name, pd_ra_def)
    result_dict = {
        "model": model_name,
        "result": result,
        "sn_results": None if full_name is None else str(full_name),
        "output": None if output_name is None else str(output_name)
    }
    print(dict_to_json(result_dict))

def run_sensitivity_analysis(model_name:str, unique_name:str, pd_ra_def:pd.DataFrame)  -> Tuple[bool, str, str]:
    logger.info('Running Sensitivity Analysis')
    try:
        app = powerfactory.GetApplicationExt()
        logger.debug('PowerFactory App successfully called')
        if _network_reactivate(app, model_name):
            result, file_results, file_output = _execute_sensitivity_analysis(app, unique_name, pd_ra_def)
            return result, file_results, file_output
        return False, None, None

    except Exception as e:
        logger.error(f"Error during sensitivity analysis execution: {e}", exc_info=True)
        return False, None, None
        
def _network_exists(app:Any, model_name: str) -> bool:
    result = False
    user = app.GetCurrentUser()
    projects = user.GetContents('*.IntPrj',0)
    for project in projects:
        logger.debug(project.loc_name)
        if model_name == project.loc_name:
            result = (True, project.loc_name)
            logger.info(f'Network {model_name} exists')
    if not result:
        logger.info(f'Network {model_name} does not exist')
    return result

def _network_reactivate(app:Any, model_name: str) -> bool:
    exists = _network_exists(app, model_name)
    if exists:
        app.ActivateProject(model_name)
        logger.info('Project activated')
        folder = app.GetProjectFolder('study')
        logger.debug(folder)
        if folder:
            all_studies = folder.GetContents()
            for study in all_studies:
                logger.debug(study)
            if len(all_studies) > 0:
                all_studies[0].Activate()
                logger.info('Study Case activated')
                return True
    else:
        logger.info(f'Network {model_name} does not exist')
    return False

def _execute_sensitivity_analysis(app:Any, unique_name:str, pd_ra_def:pd.DataFrame) -> Tuple[bool, str, str]:
    try:
        logger.info("Running sensitivity analysis...")
        comldf = app.GetFromStudyCase("ComLdf")
        comsn = app.GetFromStudyCase("ComVstab")
        lf_parameters = get_pf_lf_configuration()
        logger.info(lf_parameters)

        # set the parameters for the load flow calculation based on the retrieved configuration values
        _set_lf_configuration(comldf, lf_parameters)

        # set parameters for the sensitivity analysis
        comsn.iopt_method = 0 # AC
        comsn.iscontsens = 0 # do not consider contingencies
        comsn.caclPtdf = 0
        comsn.calcTapChg = 1
        comsn.calcHvdc = 0

        _, set_pst, _ = _define_remedial_actions(app, comsn, pd_ra_def)

        if comsn.calcTapChg == 1:
            comsn.p_tr = set_pst

        # Run the sensitivity analysis
        logger.info("Running sensitivity analysis...")
        error_code = comsn.Execute()
        if error_code != 0:
            # get output messages - before raising the exception
            output_window = app.GetOutputWindow()
            if output_window:
                messages = output_window.GetContent()
                output_file = store_pf_output(messages, unique_name)
            raise RuntimeError(f"Sensitivity analysis failed with error code {error_code}.")
        
        logger.info("Sensitivity analysis completed successfully.")

        # get output messages
        output_window = app.GetOutputWindow()
        if output_window:
            messages = output_window.GetContent()
            output_file = store_pf_output(messages, unique_name)

        sn_results_file = _get_sn_results(app, unique_name, comsn.pResult)
        return True, sn_results_file, output_file
            
    except Exception as e:
        logger.error(f"Error during sensitivity analysis execution: {e}", exc_info=True)
        return False, None, None
    
def _get_sn_results(app:Any, unique_name:str, pResult: Any) -> str:
    # save ElmRes as a csv file and read it back as a pandas dataframe to be able to manipulate it and adapt the format to the needs of the TSCNET platform
    logger.info('Preparing sensitivity analysis results...')
    study_case = app.GetActiveStudyCase()
    # Get results object (assuming results are stored in a table object)
    elmRes = pResult
    if not elmRes:
        raise RuntimeError("No results object found. Ensure the sensitivity analysis is configured to store results.")
    
    # add rfid of element in multiindex columns
    elmRes.Load()
    elements_rdfids = []
    numberOfColumns = elmRes.GetNumberOfColumns()
    for column in range(numberOfColumns):
        obj = elmRes.GetObject(column)
        if obj is not None and obj.GetClassName() in ['ElmLne', 'ElmTr2', 'ElmTr3']:
            rdfid = getattr(obj, 'e:cimRdfId')
            if len(rdfid) > 0:
                elements_rdfids.append(rdfid[0])
            else:
                elements_rdfids.append(None)
        else:
           elements_rdfids.append(None)
    elmRes.Release()

    # Get export command
    comRes = app.GetFromStudyCase('ComRes')
    comsn = app.GetFromStudyCase("ComVstab")
    comRes.pResult = comsn.pResult

    # Export as csv file
    comRes.iopt_exp = 6
    comRes.iopt_locn = 2 # short name and class
    comRes.ciopt_head = 1 # parameter name

    # File path
    RES_DIR = Path(__file__).parent.parent.parent.parent / "pf.tmp"
    full_filename = RES_DIR / f"{unique_name}.csv"
    comRes.f_name = str(full_filename)
    logger.info(f"Saving sensitivity analysis results to {full_filename}")
    comRes.Execute()

    # Read the csv file as a pandas dataframe
    logger.info(f"Retrieving sensitivity analysis results from {full_filename}")
    pd_res = pd.read_csv(full_filename, header=[0,1], low_memory=False, keep_default_na=False, na_values=['   ----', '  ----', ' ----', '----'])

    logger.debug('Adapting security analysis results format')
    # add rdfids as a third level in the column MultiIndex
    # pd_res.columns = pd.MultiIndex.from_arrays(
    #     [
    #         pd_res.columns.get_level_values(0),
    #         pd_res.columns.get_level_values(1),
    #         elements_rdfids,
    #     ]
    # )

    # add rdfid of remedial actions
    # rdfids = []
    # for index, row in pd_res.iterrows():
    #     iobj = int(row.iloc[0])
    #     remedial_action = elmRes.GetObj(iobj)
    #     if remedial_action is not None:
    #         rdfid = getattr(remedial_action, 'e:loc_name')
    #         rdfids.append(rdfid)
    #     else:
    #         rdfids.append(None)

    # pd_res.index = pd.Index(rdfids)

    logger.debug('Saving sensitivity analysis results')
    stored = store_pf_results(pd_res, unique_name)
    store_pf_results(pd_res, unique_name, '.xlsx') # this file is for debugging
    return stored


def _set_lf_configuration(comldf: Any, lf_parameters: dict) -> None:
    # set the parameters for the load flow command
    if comldf is not None:
        comldf.iopt_net = lf_parameters['iopt_net']
        comldf.iPST_at = lf_parameters['iPST_at']
        comldf.iopt_plim = lf_parameters['iopt_plim']
        comldf.iopt_at = lf_parameters['iopt_at']
        comldf.iopt_asht = lf_parameters['iopt_asht']
        comldf.iopt_lim = lf_parameters['iopt_lim']
        comldf.iopt_pq = lf_parameters['iopt_pq']
        comldf.iopt_fls = lf_parameters['iopt_fls']
        comldf.iopt_apdist = lf_parameters['iopt_apdist']
        comldf.iPbalancing = lf_parameters['iPbalancing']

        comldf.itapopt = lf_parameters['itapopt']
        comldf.krelax = lf_parameters['krelax']
        comldf.maxTapTrans = lf_parameters['maxTapTrans']
        comldf.maxQlimTrans = lf_parameters['maxQlimTrans']
        comldf.iopt_optaplim = lf_parameters['iopt_optaplim']
        comldf.iopt_limScale = lf_parameters['iopt_limScale']
        comldf.i_power = lf_parameters['i_power']
        comldf.itrlx = lf_parameters['itrlx']
        comldf.ictrlx = lf_parameters['ictrlx']
        comldf.nsteps = lf_parameters['nsteps']
        comldf.errlf = lf_parameters['errlf']
        comldf.allowedBusErrMV = lf_parameters['allowedBusErrMV']
        comldf.allowedBusErrLV = lf_parameters['allowedBusErrLV']
        comldf.erreq = lf_parameters['erreq']
        comldf.iStepAdapt = lf_parameters['iStepAdapt']
        comldf.iltAlgStag = lf_parameters['iltAlgStag']
        comldf.iTrimStep = lf_parameters['iTrimStep']
        comldf.iopt_lev = lf_parameters['iopt_lev']
        comldf.iopt_notopo = lf_parameters['iopt_notopo']
        comldf.maxPhaseShift = lf_parameters['maxPhaseShift']
        comldf.utr_init = lf_parameters['utr_init']

def _get_remedial_actions(filepath:str) -> pd.DataFrame:
    # parse file and get remedial action info
    #return parse_remedial_actions(filepath, '_')
    return None

def _define_remedial_actions(app:Any, comsn:Any, pd_ra_def:pd.DataFrame) -> Any:
    if pd_ra_def is None:
        # workaround: get all PSTs from DB
        logger.info("Getting all PSTs from database as no remedial action definition provided")
        psts = []
        all_tr2 = app.GetCalcRelevantObjects('*.ElmTr2')
        for tr2 in all_tr2:
            itapch = getattr(tr2, "t:itapch", None)
            tapchtype = getattr(tr2, "t:tapchtype", None)
            dutap = getattr(tr2, "t:dutap", None)
            if itapch == 1 and tapchtype == 2 and dutap is not None and dutap > 0:
                rdfid = getattr(tr2, 'e:cimRdfId', None)
                logger.info(f"Adding PST {rdfid} as remedial action")
                psts.append(tr2)
        # create a set select with PSTs
        set_psts = app.GetFromStudyCase('Set - Transformer/Tap-Controller.SetSelect')
        if set_psts is None:
            set_psts = study_case.CreateObject('SetSelect', 'Set - Transformer/Tap-Controller')
        if set_psts is not None:
            set_psts.Clear()
            set_psts.iused = 31
            set_psts.AddRef(psts)             

            return None, set_psts, None
    return None, None, None

# def _define_contingencies(app:Any, comsa:Any, pd_ctg_set:pd.DataFrame) -> None:
#     logger.info("Adding single element contingencies")
#     if comsa is not None:
#         logger.info('Cleaning existing ComOutages')
#         outages = comsa.GetContents('*.ComOutage')
#         for outage in outages:
#             outage.Delete()

#         # add new column for PF object in pd_ctg_set
#         pd_ctg_set['PFObject'] = None
#         # pd_ctg_set['bnumber'] = -100

#         all_elements = app.GetCalcRelevantObjects('*.ElmLne,*.ElmTr2,*.ElmTr3,*.ElmSym')
#         for element in all_elements: #loop through list
#             rdfid = getattr(element, 'e:cimRdfId')[0]
#             mask = pd_ctg_set['subject_id'] == rdfid
#             if mask.any():
#                 pd_ctg_set.loc[mask, 'PFObject'] = element
#         logger.debug(f"<class '{type(pd_ctg_set).__name__}'>. Size of dataframe: {pd_ctg_set.size}")

#         # create fault cases
#         logger.info('Creating contingencies in database')
#         fault_folder = app.GetProjectFolder('fault')
#         if fault_folder is not None:
#             fault_cases_folders = fault_folder.GetContents('*.IntFltCases')
#             #logger.debug(f"fault cases folders: {fault_cases_folders}")
#             if len(fault_cases_folders) > 0: 
#                 fault_cases_folder = fault_cases_folders[0]
#                 #logger.debug(f"Cleaning fault cases folder: {fault_cases_folder}")
#                 contents = fault_cases_folder.GetContents('*.IntEvt')
#                 for cont in contents:
#                     cont.Delete()
#                 for index, row in pd_ctg_set.iterrows():
#                     ctg_id = row['contingency_id']
#                     eq_id = row['subject_id']
#                     pf_obj = row['PFObject']
#                     intevt = fault_cases_folder.CreateObject('IntEvt', eq_id)
#                     if intevt is not None:
#                         #logger.info(f"intevt: {intevt}")
#                         intevt.mod_cnt = 1
#                         #logger.debug('Create EvtShc')
#                         intshc = intevt.CreateObject('EvtShc', eq_id)
#                         if intshc is not None:
#                             intshc.p_target = pf_obj
#                         #logger.debug('Create ComOutage')
#                         comoutage = comsa.CreateObject('ComOutage', ctg_id)
#                         if comoutage is not None:
#                             comoutage.cpCase = intevt

#         logger.info('Contingencies created in database')
#         logger.debug(f"<class '{type(pd_ctg_set).__name__}'>. Size of dataframe: {pd_ctg_set.size}")

if __name__ == "__main__":
    parser = ArgumentParser()
    parser.add_argument("-m", "--model")
    parser.add_argument("-r", "--ra")

    args = parser.parse_args()
    logger.debug("Calling run sensitivity analysis function")
    main(args.model, args.ra)