import sys
import pandas as pd
import uuid
import time
from argparse import ArgumentParser
from typing import Any, Tuple

from src.core.config import config
from src.core.logger import get_logger
from src.core.json_utilities import dict_to_json
from src.core.pf.store_pf_results import store_pf_results, store_pf_output
from src.core.pf.config_pf_lf import get_pf_lf_configuration
from src.core.pf.powerfactory_bootstrap import load_powerfactory_module

logger = get_logger(__name__)

pf_path = config.get("paths", "powerfactory_path", "")
sys.path.append(pf_path)
powerfactory = load_powerfactory_module()

def main(model_name:str) -> None:
    logger.info(f'Model Name: {model_name}')
    unique_name = f"{int(time.time())}_{uuid.uuid4().hex}"
    result, full_name, output_name = run_loadflow(model_name, unique_name)
    result_dict = {
        "model": model_name,
        "result": result,
        "lf_results": None if full_name is None else str(full_name),
        "output": None if output_name is None else str(output_name)
    }
    print(dict_to_json(result_dict))

def run_loadflow(model_name:str, unique_name:str)  -> Tuple[bool, str, str]:
    logger.info('Running Load Flow...')
    try:
        app = powerfactory.GetApplicationExt()
        logger.info('PowerFactory App successfully called')
        if network_reactivate(app, model_name):
            result, file_results, file_output = execute_loadflow(app, unique_name)
            return result, file_results, file_output
        return False, None, None

    except Exception as e:
        logger.error(f"Error during load flow execution: {e}", exc_info=True)
        return False, None, None
        
def network_exists(app:Any, model_name: str) -> bool:
    result = False
    user = app.GetCurrentUser()
    projects = user.GetContents('*.IntPrj',0)
    for project in projects:
        logger.debug(project.loc_name)
        if model_name == project.loc_name:
            result = (True, project.loc_name)
            logger.info(f'Network {model_name} exists')
    if not result:
        logger.info(f'Network {model_name} does not exist')
    return result

def network_reactivate(app:Any, model_name: str) -> bool:
    exists = network_exists(app, model_name)
    if exists:
        app.ActivateProject(model_name)
        logger.info('Project activated')
        folder = app.GetProjectFolder('study')
        logger.debug(folder)
        if folder:
            all_studies = folder.GetContents()
            for study in all_studies:
                logger.debug(study)
            if len(all_studies) > 0:
                all_studies[0].Activate()
                logger.info('Study Case activated')
                return True
    else:
        logger.info(f'Network {model_name} does not exist')
    return False

def execute_loadflow(app:Any, unique_name:str) -> Tuple[bool, str, str]:
    try:
        logger.info("Running load flow calculation...")
        comldf = app.GetFromStudyCase("ComLdf")
        lf_parameters = get_pf_lf_configuration()
        logger.info(lf_parameters)

        # set the parameters for the load flow calculation based on the retrieved configuration values
        set_lf_configuration(comldf, lf_parameters)

        # perform the load flow calculation and check the result
        result = comldf.Execute()
        # get output messages
        output_window = app.GetOutputWindow()
        if output_window:
            messages = output_window.GetContent()
            output_file = store_pf_output(messages, unique_name)
        if result == 0:
            logger.info("Load flow calculation successful")
            lf_results_file = get_lf_results(app, unique_name)
            return True, lf_results_file, output_file
        else:
            logger.error("Error: Load flow calculation failed")
        return False, None, output_file
    except Exception as e:
        logger.error(f"Error during load flow execution: {e}", exc_info=True)
        return False, None, None

def set_lf_configuration(comldf: Any, lf_parameters: dict) -> None:
    # set the parameters for the load flow command
    if comldf is not None:
        comldf.iopt_net = lf_parameters['iopt_net']
        comldf.iPST_at = lf_parameters['iPST_at']
        comldf.iopt_plim = lf_parameters['iopt_plim']
        comldf.iopt_at = lf_parameters['iopt_at']
        comldf.iopt_asht = lf_parameters['iopt_asht']
        comldf.iopt_lim = lf_parameters['iopt_lim']
        comldf.iopt_pq = lf_parameters['iopt_pq']
        comldf.iopt_fls = lf_parameters['iopt_fls']
        comldf.iopt_apdist = lf_parameters['iopt_apdist']
        comldf.iPbalancing = lf_parameters['iPbalancing']

        comldf.itapopt = lf_parameters['itapopt']
        comldf.krelax = lf_parameters['krelax']
        comldf.maxTapTrans = lf_parameters['maxTapTrans']
        comldf.maxQlimTrans = lf_parameters['maxQlimTrans']
        comldf.iopt_optaplim = lf_parameters['iopt_optaplim']
        comldf.iopt_limScale = lf_parameters['iopt_limScale']
        comldf.i_power = lf_parameters['i_power']
        comldf.itrlx = lf_parameters['itrlx']
        comldf.ictrlx = lf_parameters['ictrlx']
        comldf.nsteps = lf_parameters['nsteps']
        comldf.errlf = lf_parameters['errlf']
        comldf.allowedBusErrMV = lf_parameters['allowedBusErrMV']
        comldf.allowedBusErrLV = lf_parameters['allowedBusErrLV']
        comldf.erreq = lf_parameters['erreq']
        comldf.iStepAdapt = lf_parameters['iStepAdapt']
        comldf.iltAlgStag = lf_parameters['iltAlgStag']
        comldf.iTrimStep = lf_parameters['iTrimStep']
        comldf.iopt_lev = lf_parameters['iopt_lev']
        comldf.iopt_notopo = lf_parameters['iopt_notopo']
        comldf.maxPhaseShift = lf_parameters['maxPhaseShift']
        comldf.utr_init = lf_parameters['utr_init']

def get_lf_results(app:Any, unique_name:str) -> str:
    d = []
    lines = app.GetCalcRelevantObjects('*.ElmLne')
    for line in lines: #loop through list
        rdfid = getattr(line, 'e:cimRdfId')[0]
        p1 = getattr(line, 'm:P:bus1')
        q1 = getattr(line, 'm:Q:bus1')
        i1 = getattr(line, 'm:I:bus1') * 1000
        inom1 = getattr(line, 'c:curnom') * 1000 
        p2 = getattr(line, 'm:P:bus2')
        q2 = getattr(line, 'm:Q:bus2')
        i2 = getattr(line, 'm:I:bus2') * 1000
        inom2 = inom1
        p3 = q3 = i3 = inom3 = 0.
        loading = getattr(line, 'c:loading') #get value for the loading
        # add results
        d.append((rdfid, 'LINE', p1, q1, i1, inom1, p2, q2, i2, inom2, p3, q3, i3, inom3, loading))
    # get 2-w transformers - current results in Amp
    trafos = app.GetCalcRelevantObjects('*.ElmTr2')
    for trafo in trafos: #loop through list
        rdfid = getattr(trafo, 'e:cimRdfId')[0]
        p1 = getattr(trafo, 'm:P:bushv')
        q1 = getattr(trafo, 'm:Q:bushv')
        i1 = getattr(trafo, 'm:I:bushv') * 1000     
        inom1 = getattr(trafo, 'c:Inom_HV') * 1000   
        p2 = getattr(trafo, 'm:P:buslv')
        q2 = getattr(trafo, 'm:Q:buslv')
        i2 = getattr(trafo, 'm:I:buslv') * 1000
        inom2 = getattr(trafo, 'c:Inom_LV') * 1000
        p3 = q3 = i3 = inom3 = 0.
        loading = getattr(trafo, 'c:loading') #get value for the loading
        # add results
        d.append((rdfid, 'TWO_WINDING_TRANSFORMER', p1, q1, i1, inom1, p2, q2, i2, inom2, p3, q3, i3, inom3, loading))
    # get 3-2 transformers - current results in Amp
    w3trafos = app.GetCalcRelevantObjects('*.ElmTr3')
    for w3trafo in w3trafos: #loop through list
        rdfid = getattr(w3trafo, 'e:cimRdfId')[0]
        p1 = getattr(w3trafo, 'm:P:bushv')
        q1 = getattr(w3trafo, 'm:Q:bushv')
        i1 = getattr(w3trafo, 'm:I:bushv') * 1000     
        inom1 = getattr(w3trafo, 'c:Inom_HV') * 1000   
        p2 = getattr(w3trafo, 'm:P:buslv')
        q2 = getattr(w3trafo, 'm:Q:buslv')
        i2 = getattr(w3trafo, 'm:I:buslv') * 1000
        inom2 = getattr(w3trafo, 'c:Inom_LV') * 1000
        p3 = getattr(w3trafo, 'm:P:busmv')
        q3 = getattr(w3trafo, 'm:Q:busmv')
        i3 = getattr(w3trafo, 'm:I:busmv') * 1000
        inom3 = getattr(w3trafo, 'c:Inom_MV') * 1000
        loading = getattr(w3trafo, 'c:loading') #get value for the loading
        # add results
        d.append((rdfid, 'THREE_WINDING_TRANSFORMER', p1, q1, i1, inom1, p2, q2, i2, inom2, p3, q3, i3, inom3, loading))

    # make sure that the dataframe is correctly configured 
    pd_res = pd.DataFrame(d, columns=('rdfid', 'type', 'p1', 'q1', 'i1', 'inom1', 'p2', 'q2', 'i2', 'inom2', 'p3', 'q3', 'i3', 'inom3', 'loading'))
    pd_res['rdfid'] = pd_res['rdfid'].astype(str)
    pd_res['type'] = pd_res['type'].astype(str)
    pd_res[['p1', 'q1', 'i1', 'inom1', 'p2', 'q2', 'i2', 'inom2', 'p3', 'q3', 'i3', 'inom3', 'loading']] = pd_res[['p1', 'q1', 'i1', 'inom1', 'p2', 'q2', 'i2', 'inom2', 'p3', 'q3', 'i3', 'inom3', 'loading']].apply(pd.to_numeric)
    pd_res.set_index("rdfid", inplace=True)
    stored = store_pf_results(pd_res, unique_name)
    return stored
    
if __name__ == "__main__":
    parser = ArgumentParser()
    parser.add_argument("-m", "--model")

    args = parser.parse_args()
    main(args.model)