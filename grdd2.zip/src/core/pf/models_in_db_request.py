import sys
import subprocess
import json
from typing import List
from src.core.json_utilities import str_to_dict
from src.core.logger import get_logger

logger = get_logger(__name__)

def request_models_in_db() -> List:
    try:
        logger.info('Requesting models list in DB...')
        models = []
        sp = subprocess.run([sys.executable, "-m", "src.core.pf.models_in_db_subprocess"],
                                capture_output=True, 
                                check=True,
                                text=True)
        logger.debug(sp.stdout)
        result_dict = str_to_dict(sp.stdout)
        logger.info(result_dict)
        if 'models' in result_dict:
            models = json.loads(result_dict['models'])
        return models
    except subprocess.CalledProcessError as e:
        logger.error(f"Error running module: {e}")
        return []