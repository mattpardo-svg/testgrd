import json
from typing import Dict, Any

def dict_to_json(the_dict:Dict) -> str:
    try:
        json_str = json.dumps(
            the_dict,
            indent=4,        # Pretty print with 4 spaces
            ensure_ascii=False,  # Keep Unicode characters as-is
            sort_keys=False   # Do not sort keys alphabetically
        )

        # Print the JSON string
        return(json_str)
    except (TypeError, ValueError) as e:
        print(f"Error converting Dict to JSON: {e}")
        return ""


def str_to_dict(the_str:str) -> str:
    try:
        # Strip whitespace and parse JSON
        output_str = the_str.strip().replace("'", '"')
        if not output_str:
            raise ValueError("Command returned empty output.")
        return json.loads(output_str)
    except (TypeError, ValueError) as e:
        print(f"Error converting Str to Dict: {e}")
        return ""
    
def list_to_json_field(py_list) -> str:
    """
    Convert a Python list into a JSON string for storage in a JSON field.
    Includes validation to ensure the list is serializable.
    """
    if not isinstance(py_list, list):
        raise TypeError("Input must be a Python list.")

    try:
        # Convert list to JSON string
        json_str = json.dumps(py_list, ensure_ascii=False)
        return json_str
    except (TypeError, ValueError) as e:
        raise ValueError(f"List contains non-serializable data: {e}")
        return ""
    