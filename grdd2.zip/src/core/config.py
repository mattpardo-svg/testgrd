import configparser
from pathlib import Path
from typing import Any, Dict, Optional
from .logger import get_logger

logger = get_logger(__name__)

class ConfigManager:
    """Configuration manager for PyTSC application."""

    def __init__(self, config_file: str = "config.ini"):
        """
        Initialize the configuration manager.

        Args:
            config_file: Path to the configuration file (relative to project root)
        """
        self.project_root = Path(__file__).parent.parent.parent
        self.config_file = self.project_root / config_file
        self.config = configparser.ConfigParser()

        # Load configuration
        self.load_config()

    def load_config(self) -> None:
        """Load configuration from file. Creates default config if file doesn't exist."""
        try:
            if self.config_file.exists():
                self.config.read(self.config_file, encoding='utf-8')
                logger.info(f"Configuration loaded from {self.config_file}")
            else:
                logger.warning(f"Configuration file not found at {self.config_file}, using defaults")
                self._create_default_config()
        except Exception as e:
            logger.error(f"Error loading configuration: {e}")
            self._create_default_config()

    def save_config(self) -> bool:
        """Save current configuration to file."""
        try:
            with open(self.config_file, 'w', encoding='utf-8') as configfile:
                self.config.write(configfile)
            logger.info(f"Configuration saved to {self.config_file}")
            return True
        except Exception as e:
            logger.error(f"Error saving configuration: {e}")
            return False

    def _create_default_config(self) -> None:
        """Create default configuration sections."""
        # Default sections are already defined in config.ini template
        pass

    def get(self, section: str, key: str, fallback: Any = None) -> Any:
        """
        Get a configuration value.

        Args:
            section: Configuration section
            key: Configuration key
            fallback: Fallback value if key not found

        Returns:
            Configuration value or fallback
        """
        try:
            return self.config.get(section, key, fallback=fallback)
        except (configparser.NoSectionError, configparser.NoOptionError):
            return fallback

    def getint(self, section: str, key: str, fallback: int = 0) -> int:
        """Get an integer configuration value."""
        try:
            return self.config.getint(section, key, fallback=fallback)
        except (configparser.NoSectionError, configparser.NoOptionError):
            return fallback

    def getboolean(self, section: str, key: str, fallback: bool = False) -> bool:
        """Get a boolean configuration value."""
        try:
            return self.config.getboolean(section, key, fallback=fallback)
        except (configparser.NoSectionError, configparser.NoOptionError):
            return fallback

    def getfloat(self, section: str, key: str, fallback: float = 0.0) -> float:
        """Get a float configuration value."""
        try:
            return self.config.getfloat(section, key, fallback=fallback)
        except (configparser.NoSectionError, configparser.NoOptionError):
            return fallback

    def set(self, section: str, key: str, value: Any) -> None:
        """
        Set a configuration value.

        Args:
            section: Configuration section
            key: Configuration key
            value: Value to set
        """
        if not self.config.has_section(section):
            self.config.add_section(section)

        self.config.set(section, key, str(value))
        logger.debug(f"Configuration set: [{section}] {key} = {value}")

    def get_section(self, section: str) -> Dict[str, str]:
        """Get all key-value pairs from a section."""
        try:
            return dict(self.config.items(section))
        except configparser.NoSectionError:
            return {}

    def update_last_grid_file_path(self, file_path: str) -> None:
        """Update the last opened file path."""
        self.set('paths', 'last_opened_model', file_path)

    def update_last_pf_model(self, pf_model_name: str) -> None:
        """Update the last model selected in PF."""
        self.set('paths', 'last_pf_model', pf_model_name)

    def update_last_contingency_file_path(self, file_path: str) -> None:
        """Update the last opened file path."""
        self.set('paths', 'last_opened_contingency', file_path)

    def update_window_geometry(self, x: int, y: int, width: int, height: int) -> None:
        """Update window geometry settings."""
        self.set('ui', 'window_x', x)
        self.set('ui', 'window_y', y)
        self.set('ui', 'window_width', width)
        self.set('ui', 'window_height', height)

    def get_window_geometry(self) -> tuple[int, int, int, int]:
        """Get window geometry (x, y, width, height)."""
        x = self.getint('ui', 'window_x', 100)
        y = self.getint('ui', 'window_y', 100)
        width = self.getint('ui', 'window_width', 400)
        height = self.getint('ui', 'window_height', 200)
        return x, y, width, height

# Global configuration instance
config = ConfigManager()