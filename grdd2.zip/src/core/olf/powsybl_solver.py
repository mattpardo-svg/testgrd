import pypowsybl.network as pn
import pypowsybl.loadflow as lf
import pypowsybl.security as ps
import pypowsybl.sensitivity as psn
import pandas as pd
from typing import Any
from src.core.logger import get_logger
from .config_olf_lf import get_olf_lf_configuration
from src.core.store_results import store_lf_results
from src.core.parser_contingencies import parse_contingencies

logger = get_logger(__name__)

class powsybl_solver:
    def __init__(self, file_path):
        self.file_path = file_path
        self.network = None
        self.co_handler = None
        self.contingencies = None
        self.sa_results = None
        self.remedial_actions = None
        self.sn_results = None

    def _run_branch_current_sensitivity(
        self,
        *,
        branch_ids: list[str],
        variable_ids: list[str],
        sensitivity_variable_type,
        matrix_prefix: str,
    ) -> bool:
        sn = psn.create_ac_analysis()
        sn.add_factor_matrix(
            functions_ids=branch_ids,
            variables_ids=variable_ids,
            contingencies_ids=[],
            contingency_context_type=psn.ContingencyContextType.NONE,
            sensitivity_function_type=psn.SensitivityFunctionType.BRANCH_CURRENT_1,
            sensitivity_variable_type=sensitivity_variable_type,
            matrix_id=f"{matrix_prefix}_s1",
        )
        sn.add_factor_matrix(
            functions_ids=branch_ids,
            variables_ids=variable_ids,
            contingencies_ids=[],
            contingency_context_type=psn.ContingencyContextType.NONE,
            sensitivity_function_type=psn.SensitivityFunctionType.BRANCH_CURRENT_2,
            sensitivity_variable_type=sensitivity_variable_type,
            matrix_id=f"{matrix_prefix}_s2",
        )
        self.sn_results = sn.run(self.network)
        return True

    def _get_branch_current_sensitivity_results(self, *, matrix_prefix: str) -> Any:
        if self.sn_results is None:
            return None
        raw_s1 = self.sn_results.get_sensitivity_matrix(f"{matrix_prefix}_s1")
        raw_s2 = self.sn_results.get_sensitivity_matrix(f"{matrix_prefix}_s2")
        # Both matrices are (n_variables x n_branches); transpose to (n_branches x n_variables)
        s1 = raw_s1.T.copy()
        s2 = raw_s2.T.copy()
        # Worst-side: keep sign of s1, use max absolute magnitude across both sides
        worst = s1.where(s1.abs() >= s2.abs(), other=s2)
        return worst

    def read_network(self) -> int:
        try:
            logger.info("Reading network from file...")
            network = pn.load(self.file_path)
            logger.info("Network read successfully")
            self.network = network
            return 0
        except Exception as e:
            logger.error(f"Error during load flow execution: {e}", exc_info=True)
            return 1

    def run_loadflow(self) -> str:
        try:
            logger.info("Running load flow calculation...")
            lf_parameters = get_olf_lf_configuration()
            logger.info(lf_parameters)
            
            res = lf.run_ac(self.network, parameters=lf_parameters)
            logger.info(f"Load Flow Result: {res[0].status}")

            return res
        except Exception as e:
            logger.error(f"Error during load flow execution: {e}", exc_info=True)
            return ""

    def _calc_loading(self, row):
        loading1 = 0
        if row['inom1'] > 0:
            loading1 = row['i1'] / row['inom1']
        loading2 = 0
        if row['inom2'] > 0:
            loading2 = row['i2'] / row['inom2']
        loading3 = 0
        if row['inom3'] > 0:
            loading3 = row['i3'] / row['inom3']
        return max(loading1, loading2, loading3) * 100

    def get_lf_results(self) -> Any:
        try:
            logger.info("Getting LF results...")
            if self.network is not None:
                pd_bra = self.network.get_branches(attributes=['type', 'p1', 'q1', 'i1', 'p2', 'q2', 'i2'])
                pd_3wt = self.network.get_3_windings_transformers(attributes=['p1', 'q1', 'i1', 'p2', 'q2', 'i2', 'p3', 'q3', 'i3'])
                if pd_3wt is not None:
                    pd_3wt.insert(0, 'type', 'THREE_WINDINGS_TRANSFORMER')
                    pd_res = pd.concat([pd_bra, pd_3wt], axis=0, ignore_index=False)
                else:
                    pd_res = pd_bra
                pd_lims = self.network.get_operational_limits()

                pd_lims_filtered = pd_lims.filter(items=['side', 'value'])

                pd_lims_one = pd_lims_filtered.query("side =='ONE' and acceptable_duration == -1").droplevel([1,2,3,4])
                pd_lims_one.rename(columns={'value': 'inom1'}, inplace=True)
                pd_lims_one.rename_axis('id', inplace=True)
                pd_lims_two = pd_lims_filtered.query("side =='TWO' and acceptable_duration == -1").droplevel([1,2,3,4])
                pd_lims_two.rename(columns={'value': 'inom2'}, inplace=True)
                pd_lims_two.rename_axis('id', inplace=True)
                pd_lims_three = pd_lims_filtered.query("side =='THREE' and acceptable_duration == -1").droplevel([1,2,3,4])
                pd_lims_three.rename(columns={'value': 'inom3'}, inplace=True)
                pd_lims_three.rename_axis('id', inplace=True)
                pd_res_1 = pd_res.merge(pd_lims_one, on='id', how='left')
                pd_res_2 = pd_res_1.merge(pd_lims_two, on='id', how='left')
                pd_res_merged = pd_res_2.merge(pd_lims_three, on='id', how='left')
                pd_res_merged['loading'] = pd_res_merged.apply(self._calc_loading, axis=1)
                new_order = ['type', 'p1', 'q1', 'i1', 'inom1', 'p2', 'q2', 'i2', 'inom2', 'p3', 'q3', 'i3', 'inom3', 'loading']
                pd_res_merged = pd_res_merged[new_order]
                logger.info('LF results retrieved')
                return pd_res_merged
        except Exception as e:
            logger.error(f"Error retrieving results: {e}", exc_info=True)
            return None

    def save_lf_results(self) -> None:
        try:
            logger.info("Saving LF results...")
            if self.network is not None:
                pd_res = self.get_lf_results()
                store_lf_results(pd_res, 'olf')

                pd_lims = self.network.get_operational_limits()
                store_lf_results(pd_lims, 'lims')
        except Exception as e:
            logger.error(f"Error saving results: {e}", exc_info=True)

    def set_contingencies(self, filepath:str) -> None:
        # parse file and get contingency info
        pd_ctg = parse_contingencies(filepath)
        # add pre-contingency
        new_row = pd.DataFrame(columns=['counter', 'contingency_id', 'subject_id'], data=[[0, 'base_case', '']])
        self.contingencies = pd.concat([new_row, pd_ctg], ignore_index=True)

    def run_sa(self) -> bool:
        # create security
        sa = ps.create_analysis()
        # define contingencies
        logger.info("Adding single element contingencies")
        for _, row in self.contingencies.iterrows():
            if row['subject_id'] != '' and row['contingency_id'] != "base_case":
                sa.add_single_element_contingency(row['subject_id'], row['contingency_id'])
        # run sa with lf configuration
        lf_parameters = get_olf_lf_configuration()
        logger.info(lf_parameters)
        result = sa.run_ac(self.network, parameters=lf_parameters)
        # update contingencies status
        self.contingencies.loc[self.contingencies['contingency_id'] == 'base_case', 'status'] = result.pre_contingency_result.status.name
        for name, ctg in result.post_contingency_results.items():
            self.contingencies.loc[self.contingencies['contingency_id'] == name, 'status'] = ctg.status.name
        self.sa_results = result.limit_violations
        return True
        
    def get_sa_results(self) -> Any:
        try:
            if self.sa_results is not None:
                pd_lims = self.sa_results
                pd_cur_lims = pd_lims[pd_lims['limit_type'] == 'CURRENT']
                return pd_cur_lims
            return None
        except Exception as e:
            logger.error(f"Error retrieving results: {e}", exc_info=True)
            return None
        
    def save_sa_results(self) -> None:
        try:
            logger.info("Saving SA results...")
            if self.sa_results is not None:
                logger.error('SA RESULTS SAVING TO BE DONE - JSON FILE?')
        except Exception as e:
            logger.error(f"Error saving results: {e}", exc_info=True)

    def set_remedial_actions(self, filepath:str) -> None:
        # parse file and get remedial actions info
        # TODO: implement parsing of remedial actions file and store in self.remedial_actions
        # work-around: get all the PSTs from the network and store as remedial actions
        pd_pst = self.network.get_phase_tap_changers()
        self.remedial_actions = pd_pst

    def run_sn(
        self,
        branch_ids: list[str] | None = None,
        pst_ids: list[str] | None = None,
    ) -> bool:
        """Run AC sensitivity analysis requesting branch-current sensitivities (A/degree).

        Two factor matrices are registered — one per terminal side — so that the
        worst-side (max absolute) sensitivity can be derived in get_sn_results().
        """
        branches = branch_ids if branch_ids is not None else self.network.get_branches().index.tolist()
        psts = pst_ids if pst_ids is not None else self.remedial_actions.index.tolist()
        return self._run_branch_current_sensitivity(
            branch_ids=branches,
            variable_ids=psts,
            sensitivity_variable_type=psn.SensitivityVariableType.TRANSFORMER_PHASE,
            matrix_prefix="current",
        )

    def run_rd_sn(
        self,
        branch_ids: list[str],
        unit_ids: list[str],
    ) -> bool:
        """Run AC branch-current sensitivities with respect to active-power injections."""
        return self._run_branch_current_sensitivity(
            branch_ids=branch_ids,
            variable_ids=unit_ids,
            sensitivity_variable_type=psn.SensitivityVariableType.INJECTION_ACTIVE_POWER,
            matrix_prefix="rd_current",
        )

    def get_sn_results(self) -> Any:
        """Return branch-current sensitivity matrix (n_branches × n_psts) in A/degree.

        Each cell is the worst-side sensitivity: sign is taken from side 1, magnitude
        is the maximum of |side-1| and |side-2| to satisfy the conservative max-side
        consistency rule used throughout the current-based RAO pipeline.
        """
        try:
            return self._get_branch_current_sensitivity_results(matrix_prefix="current")
        except Exception as e:
            logger.error(f"Error retrieving results: {e}", exc_info=True)
            return None

    def get_rd_sn_results(self) -> Any:
        """Return branch-current to active-injection sensitivity matrix (A/MW)."""
        try:
            return self._get_branch_current_sensitivity_results(matrix_prefix="rd_current")
        except Exception as e:
            logger.error(f"Error retrieving results: {e}", exc_info=True)
            return None
