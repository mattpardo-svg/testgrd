import sys
import pypowsybl.loadflow as lf
from src.core.config import config

def get_olf_lf_configuration() -> dict:
    # get the powsybl load flow parameters from the config and convert them to the correct types
    voltage_init_mode = config.get('powsybl_loadflow', 'voltage_init_mode', "UNIFORM_VALUES")
    if voltage_init_mode == "DC_VALUES":
        voltage_init_mode = lf.VoltageInitMode.DC_VALUES
    else:
        voltage_init_mode = lf.VoltageInitMode.UNIFORM_VALUES
    transformer_voltage_control_on = config.getboolean('powsybl_loadflow', 'transformer_voltage_control_on', 1)
    use_reactive_limits = config.getboolean('powsybl_loadflow', 'use_reactive_limits', 1)
    phase_shifter_regulation_on = config.getboolean('powsybl_loadflow', 'phase_shifter_regulation_on', 1)
    twt_split_shunt_admittance = config.getboolean('powsybl_loadflow', 'twt_split_shunt_admittance', 1)
    shunt_compensator_voltage_control_on = config.getboolean('powsybl_loadflow', 'shunt_compensator_voltage_control_on', 1)
    read_slack_bus = config.getboolean('powsybl_loadflow', 'read_slack_bus', 1)
    write_slack_bus = config.getboolean('powsybl_loadflow', 'write_slack_bus', 1)
    distributed_slack = config.getboolean('powsybl_loadflow', 'distributed_slack', 1)
    balance_type = config.get('powsybl_loadflow', 'balance_type', 'PROPORTIONAL_TO_LOAD')
    if balance_type == 'PROPORTIONAL_TO_GENERATION_P_MAX':
        balance_type = lf.BalanceType.PROPORTIONAL_TO_GENERATION_P_MAX
    elif balance_type == 'PROPORTIONAL_TO_GENERATION_P':
        balance_type = lf.BalanceType.PROPORTIONAL_TO_GENERATION_P
    else:
        balance_type = lf.BalanceType.PROPORTIONAL_TO_LOAD
    dc_use_transformer_ratio = config.getboolean('powsybl_loadflow', 'dc_use_transformer_ratio', 1)
    countries_to_balance = config.get('powsybl_loadflow', 'countries_to_balance', '')
    countries_to_balance = [c.strip() for c in countries_to_balance.split(',')] if countries_to_balance else []
    component_mode = config.get('powsybl_loadflow', 'component_mode', 'MAIN_SYNCHRONOUS')
    if component_mode == 'MAIN_CONNECTED':
        component_mode = lf.ComponentMode.MAIN_CONNECTED
    elif component_mode == 'ALL_CONNECTED':
        component_mode = lf.ComponentMode.ALL_CONNECTED
    else:
        component_mode = lf.ComponentMode.MAIN_SYNCHRONOUS
    dc_power_factor = config.getfloat('powsybl_loadflow', 'dc_power_factor', 0.9)
    hvdc_ac_emulation = config.getboolean('powsybl_loadflow', 'hvdc_ac_emulation', 1)
    
    # get the provider parameters from the config and convert them to the correct types
    lowImpedanceBranchMode = str(config.get('powsybl_openloadflow', 'lowImpedanceBranchMode', "REPLACE_BY_ZERO_IMPEDANCE_LINE"))
    lowImpedanceThreshold = str(config.getfloat('powsybl_openloadflow', 'lowImpedanceThreshold', 1e-8))
    slackBusSelectionMode = str(config.get('powsybl_openloadflow', 'slackBusSelectionMode', "MOST_MESHED"))
    areaInterchangeControl = str(config.get('powsybl_openloadflow', 'areaInterchangeControl', 0))
    phaseShifterControlMode = str(config.get('powsybl_openloadflow', 'phaseShifterControlMode', "CONTINUOUS_WITH_DISCRETISATION"))
    transformerVoltageControlMode = str(config.get('powsybl_openloadflow', 'transformerVoltageControlMode', "INCREMENTAL_VOLTAGE_CONTROL"))
    shuntVoltageControlMode = str(config.get('powsybl_openloadflow', 'shuntVoltageControlMode', "WITH_GENERATOR_VOLTAGE_CONTROL"))
    acSolverType = str(config.get('powsybl_openloadflow', 'acSolverType', "NEWTON_RAPHSON"))
    maxOuterLoopIterations = str(config.getint('powsybl_openloadflow', 'maxOuterLoopIterations', 20))
    newtonRaphsonStoppingCriteriaType = str(config.get('powsybl_openloadflow', 'newtonRaphsonStoppingCriteriaType', "UNIFORM_CRITERIA"))
    newtonRaphsonConvEprsPerEq = str(config.getfloat('powsybl_openloadflow', 'newtonRaphsonConvEprsPerEq', 1e-4))
    maxActivePowerMismatch = str(config.getfloat('powsybl_openloadflow', 'maxActivePowerMismatch', 1e-2))
    maxReactivePowerMismatch = str(config.getfloat('powsybl_openloadflow', 'maxReactivePowerMismatch', 1e-2))
    maxVoltageMismatch = str(config.getfloat('powsybl_openloadflow', 'maxVoltageMismatch', 1e-4))
    maxAngleMismatch = str(config.getfloat('powsybl_openloadflow', 'maxAngleMismatch', 1e-5))
    maxRatioMismatch = str(config.getfloat('powsybl_openloadflow', 'maxRatioMismatch', 1e-5))
    maxSusceptanceMismatch = str(config.getfloat('powsybl_openloadflow', 'maxSusceptanceMismatch', 1e-4))
    maxNewtonRaphsonIterations = str(config.getint('powsybl_openloadflow', 'maxNewtonRaphsonIterations', 15))
    useActiveLimits = str(config.getboolean('powsybl_openloadflow', 'useActiveLimits', 1))
    disableVoltageControlOfGeneratorsOutsideActivePowerLimits = str(config.getboolean('powsybl_openloadflow', 'disableVoltageControlOfGeneratorsOutsideActivePowerLimits', 1))
    referenceBusSelectionMode = str(config.get('powsybl_openloadflow', 'referenceBusSelectionMode', "FIRST_SLACK"))

    # set the dict with the provider parameters
    provider_parameters = {
        "lowImpedanceBranchMode": lowImpedanceBranchMode,
        "lowImpedanceThreshold": lowImpedanceThreshold,
        "slackBusSelectionMode": slackBusSelectionMode,
        "areaInterchangeControl": areaInterchangeControl,
        "phaseShifterControlMode": phaseShifterControlMode,
        "transformerVoltageControlMode": transformerVoltageControlMode,
        "shuntVoltageControlMode": shuntVoltageControlMode,
        "acSolverType": acSolverType,
        "maxOuterLoopIterations": maxOuterLoopIterations,
        "newtonRaphsonStoppingCriteriaType": newtonRaphsonStoppingCriteriaType,
        "newtonRaphsonConvEprsPerEq": newtonRaphsonConvEprsPerEq,
        "maxActivePowerMismatch": maxActivePowerMismatch,
        "maxReactivePowerMismatch": maxReactivePowerMismatch,
        "maxVoltageMismatch": maxVoltageMismatch,
        "maxAngleMismatch": maxAngleMismatch,
        "maxRatioMismatch": maxRatioMismatch,
        "maxSusceptanceMismatch": maxSusceptanceMismatch,
        "maxNewtonRaphsonIterations": maxNewtonRaphsonIterations,
        "useActiveLimits": useActiveLimits,
        "disableVoltageControlOfGeneratorsOutsideActivePowerLimits": disableVoltageControlOfGeneratorsOutsideActivePowerLimits,
        "referenceBusSelectionMode": referenceBusSelectionMode
        }
    
    # return the lf.Parameters object with the retrieved values
    return lf.Parameters(voltage_init_mode=voltage_init_mode, 
                        transformer_voltage_control_on=transformer_voltage_control_on, 
                        use_reactive_limits=use_reactive_limits,
                        phase_shifter_regulation_on=phase_shifter_regulation_on,
                        twt_split_shunt_admittance=twt_split_shunt_admittance,
                        shunt_compensator_voltage_control_on=shunt_compensator_voltage_control_on,
                        read_slack_bus=read_slack_bus,
                        write_slack_bus=write_slack_bus,
                        distributed_slack=distributed_slack,
                        balance_type=balance_type,
                        dc_use_transformer_ratio=dc_use_transformer_ratio,
                        countries_to_balance=countries_to_balance,
                        component_mode=component_mode,
                        dc_power_factor=dc_power_factor,
                        hvdc_ac_emulation=hvdc_ac_emulation,
                        provider_parameters=provider_parameters)