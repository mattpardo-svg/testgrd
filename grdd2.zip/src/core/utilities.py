import os

def get_filename_without_extension(file_path) -> str:
    if not isinstance(file_path, str) or not file_path.strip():
        raise ValueError("Invalid file path provided.")
    return os.path.splitext(os.path.basename(file_path))[0]