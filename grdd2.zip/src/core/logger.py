import logging
import logging.handlers
from pathlib import Path
from datetime import datetime

# Get logging configuration from config file
LOG_DIR = Path(__file__).parent.parent.parent / "logs"
LOG_DIR.mkdir(exist_ok=True)

# Log file configuration
LOG_FILE = LOG_DIR / f"pytsc_{datetime.now().strftime('%Y%m%d')}.log"
LOG_FORMAT = "%(asctime)s.%(msecs)03d - %(name)s - %(levelname)s - %(message)s"
LOG_DATE_FORMAT = "%Y-%m-%d %H:%M:%S"

# Get logging settings from config
LOG_TO_FILE = True
LOG_TO_CONSOLE = True
MAX_LOG_SIZE = 5 * 1024 * 1024
BACKUP_COUNT = 5

# Map string log levels to logging constants
LOG_LEVEL_MAP = {
    'DEBUG': logging.DEBUG,
    'INFO': logging.INFO,
    'WARNING': logging.WARNING,
    'ERROR': logging.ERROR,
    'CRITICAL': logging.CRITICAL
}

LOG_LEVEL = 'DEBUG' # Default log level


def get_logger(name: str) -> logging.Logger:
    """
    Get a configured logger instance for the given module name.
    
    Args:
        name: The name of the logger (typically __name__)
        
    Returns:
        A configured Logger instance
    """
    logger = logging.getLogger(name)
    
    # Only configure if the logger hasn't been configured yet
    if not logger.handlers:
        logger.setLevel(LOG_LEVEL)
        
        # Create formatter
        formatter = logging.Formatter(LOG_FORMAT, datefmt=LOG_DATE_FORMAT)
        
        # Console handler (if enabled)
        if LOG_TO_CONSOLE:
            console_handler = logging.StreamHandler()
            console_handler.setLevel(LOG_LEVEL)
            console_handler.setFormatter(formatter)
            logger.addHandler(console_handler)
        
        # File handler (if enabled)
        if LOG_TO_FILE:
            try:
                file_handler = logging.handlers.RotatingFileHandler(
                    LOG_FILE,
                    maxBytes=MAX_LOG_SIZE,
                    backupCount=BACKUP_COUNT
                )
                file_handler.setLevel(logging.DEBUG)  # Always log debug to file
                file_handler.setFormatter(formatter)
                logger.addHandler(file_handler)
            except Exception as e:
                # Fallback to console if file logging fails
                if LOG_TO_CONSOLE:
                    logger.warning(f"Could not set up file logging: {e}")
                else:
                    print(f"Warning: Could not set up file logging: {e}")
    
    return logger


# Convenience function for quick logging setup
def configure_root_logger(level: int = logging.INFO) -> logging.Logger:
    """Configure the root logger for the application."""
    root_logger = logging.getLogger()
    root_logger.setLevel(level)
    return root_logger
