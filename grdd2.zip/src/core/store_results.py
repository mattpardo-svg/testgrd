import pandas as pd
from pathlib import Path
from datetime import datetime

from src.core.logger import get_logger

logger = get_logger(__name__)

# Get logging configuration from config file
RES_DIR = Path(__file__).parent.parent.parent / "results"
RES_DIR.mkdir(exist_ok=True)

def store_lf_results(lf_results: pd.DataFrame, preffix: str=''):
    pd.options.display.float_format = '{:.2f}'.format
    # save to excel
    filename = RES_DIR / f"{preffix}_lf_results_{datetime.now().strftime('%Y%m%d')}.xlsx"
    lf_results.to_excel(filename)
    logger.info(f"Load Flow results saved to {filename}")
