"""dc_conversion.py — calculation_mode dc: the one place where DC active-power results become amperes.

I = f(vl) * |P| * 1000 / (sqrt(3) * V_nom,side * pf)        flows (A)
dI/dx = sign(P_ref) * f(vl) * dP/dx * 1000 / (sqrt(3) * V_nom,side * pf)   sensitivities (A per degree / A per MW)

P in MW, V_nom in kV, pf = dc_power_factor of load_flow_config.yaml (the only power-factor setting),
f(vl) = dc_mode.current_factor_by_nominal_voltage_kv (entry of the nominal voltage of the side, else
"default"). Flows and sensitivities use the same scale (DcCurrentConverter.scale), the same factor.
The current of the pypowsybl DC security analysis (i1/i2) is not used: it cannot apply the factors.
"""

import logging
import math
from typing import Optional

log = logging.getLogger(__name__)

# |P_ref| below this (MW) has no usable sign: +1 is used and one line is logged per run (constant)
P_REF_TOLERANCE_MW = 1e-6
_SQRT3 = math.sqrt(3.0)
DEFAULT_FACTOR_KEY = "default"
# the table of the modes that do not use it (a missing dc_mode section): every factor 1.0
DEFAULT_FACTOR_TABLE = {DEFAULT_FACTOR_KEY: 1.0}
FACTOR_TABLE_KEY = "dc_mode.current_factor_by_nominal_voltage_kv"
DC_POWER_FACTOR_KEY = "dc_power_factor"


def _is_number(value) -> bool:
    return not isinstance(value, bool) and isinstance(value, (int, float)) and math.isfinite(value)


def validate_dc_power_factor(value, source) -> float:
    """dc_power_factor of load_flow_config.yaml: a number > 0 (not a bool); else ValueError naming
    the key and `source`."""
    if not _is_number(value) or not value > 0:
        raise ValueError(f"Invalid config value '{DC_POWER_FACTOR_KEY}' = {value!r} in {source}: must be a number > 0")
    return float(value)


def parse_current_factor_table(table, source) -> tuple[float, dict]:
    """The factor table: a dict containing 'default'; the other keys are nominal voltages in kV
    (numbers or numeric strings, as the GUI settings JSON returns them); every value a finite
    number > 0. Returns (default factor, {kV (float): factor}). Any other key or value raises
    ValueError naming the key."""
    if not isinstance(table, dict):
        raise ValueError(f"Invalid config value '{FACTOR_TABLE_KEY}' = {table!r} in {source}: must be a table")
    if DEFAULT_FACTOR_KEY not in table:
        raise ValueError(f"Missing key '{FACTOR_TABLE_KEY}.{DEFAULT_FACTOR_KEY}' in {source}")
    default_factor = None
    by_kv: dict[float, float] = {}
    for key, value in table.items():
        if not _is_number(value) or not value > 0:
            raise ValueError(
                f"Invalid config value '{FACTOR_TABLE_KEY}.{key}' = {value!r} in {source}: must be a number > 0"
            )
        if key == DEFAULT_FACTOR_KEY:
            default_factor = float(value)
            continue
        try:
            if isinstance(key, bool):
                raise ValueError
            kv = float(key)
            if not math.isfinite(kv) or kv <= 0:
                raise ValueError
        except (TypeError, ValueError):
            raise ValueError(
                f"Unknown key '{FACTOR_TABLE_KEY}.{key}' in {source}: keys are '{DEFAULT_FACTOR_KEY}' or a "
                f"nominal voltage in kV (a number > 0)"
            ) from None
        if kv in by_kv:
            raise ValueError(f"Duplicate key '{FACTOR_TABLE_KEY}.{key}' in {source}: {kv:g} kV is listed twice")
        by_kv[kv] = float(value)
    return default_factor, by_kv


class DcCurrentConverter:
    """Built once per run from the network (kV per branch side) and the settings. All conversions
    of the DC mode go through scale()."""

    def __init__(self, kv_by_branch_side: dict, power_factor: float, default_factor: float = 1.0,
                 factor_by_kv: Optional[dict] = None, levels_with_factor: int = 0):
        self.power_factor = validate_dc_power_factor(power_factor, "DcCurrentConverter")
        self.default_factor = float(default_factor)
        self.factor_by_kv = dict(factor_by_kv or {})
        self.levels_with_factor = int(levels_with_factor)
        self._scale: dict[tuple[str, int], float] = {}
        for key, kv in kv_by_branch_side.items():
            factor = self.factor_by_kv.get(float(kv), self.default_factor)
            self._scale[key] = factor * 1000.0 / (_SQRT3 * float(kv) * self.power_factor)
        self._logged_zero_reference = False

    @classmethod
    def from_network(cls, network, power_factor, factor_table, source="config") -> "DcCurrentConverter":
        """kV per (branch, side) of every line and 2-winding transformer: the nominal voltage of the
        voltage level on that side. Nominal voltages not in the table use 'default' (one INFO line)."""
        default_factor, factor_by_kv = parse_current_factor_table(factor_table, source)
        voltage_levels = network.get_voltage_levels()["nominal_v"]
        kv_by_branch_side: dict[tuple[str, int], float] = {}
        for table in (network.get_lines(), network.get_2_windings_transformers()):
            for branch_mrid, row in table.iterrows():
                for side in (1, 2):
                    kv_by_branch_side[(str(branch_mrid), side)] = float(voltage_levels[row[f"voltage_level{side}_id"]])
        nominal_voltages = {float(kv) for kv in voltage_levels}
        levels_with_factor = sum(1 for kv in voltage_levels if float(kv) in factor_by_kv)
        unmatched = sorted(nominal_voltages - set(factor_by_kv))
        if unmatched:
            log.info(
                "dc_mode: nominal voltage(s) %s kV have no entry in %s - the default factor %g is used",
                [f"{kv:g}" for kv in unmatched], FACTOR_TABLE_KEY, default_factor,
            )
        return cls(kv_by_branch_side, float(power_factor), default_factor, factor_by_kv, levels_with_factor)

    def scale(self, branch_mrid: str, side: int) -> float:
        """A per MW of a branch side (NaN for a side the network does not have)."""
        return self._scale.get((str(branch_mrid), int(side)), float("nan"))

    def current(self, branch_mrid: str, side: int, p_mw) -> float:
        """Current (A) of a branch side from its active power (MW, either sign); NaN stays NaN."""
        return abs(float(p_mw)) * self.scale(branch_mrid, side)

    def sign_of_reference(self, p_ref_mw) -> float:
        """sign(P_ref); +1 when |P_ref| < P_REF_TOLERANCE_MW (one log line per run); NaN stays NaN."""
        p_ref = float(p_ref_mw)
        if p_ref != p_ref:
            return float("nan")
        if abs(p_ref) < P_REF_TOLERANCE_MW:
            if not self._logged_zero_reference:
                self._logged_zero_reference = True
                log.info(
                    "dc_mode: a DC reference flow below %g MW has no sign - +1 is used for its sensitivities "
                    "(logged once per run)", P_REF_TOLERANCE_MW,
                )
            return 1.0
        return math.copysign(1.0, p_ref)

    def sensitivity(self, branch_mrid: str, side: int, dp_dx, p_ref_mw) -> float:
        """dI/dx (A per degree / A per MW) from dP/dx (MW per degree / MW per MW) and the reference
        flow of the same branch side (per contingency for N-X)."""
        return self.sign_of_reference(p_ref_mw) * float(dp_dx) * self.scale(branch_mrid, side)

    def flows_to_currents(self, p_by_branch: dict) -> dict:
        """{branch: {1: P, 2: P}} (MW) -> {branch: {1: A, 2: A}}, NaN sides stay NaN."""
        return {
            branch_mrid: {side: self.current(branch_mrid, side, p) for side, p in per_side.items()}
            for branch_mrid, per_side in p_by_branch.items()
        }
