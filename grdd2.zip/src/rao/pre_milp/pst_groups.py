"""pst_groups.py — equality pairs for the PSTs of one preventive group (MILP input)."""

import logging
from collections import defaultdict
from typing import Dict

from data_model import PST

log = logging.getLogger(__name__)


def build_pst_group_equality_pairs(
    pst_list: list[PST],
    pst_tap_bounds: dict[str, tuple[int, int]],
) -> list[tuple[str, str]]:
    """Build equality constraint pairs for PSTs sharing the same group_id."""
    groups: Dict[str, list[PST]] = defaultdict(list)
    for pst in pst_list:
        if pst.group_id:
            groups[pst.group_id].append(pst)

    equality_pairs: list[tuple[str, str]] = []

    for group_id, group_psts in groups.items():
        if len(group_psts) < 2:
            continue

        if any(not pst.available for pst in group_psts):
            unavailable = [pst.mrid for pst in group_psts if not pst.available]
            log.warning(
                "PST group %s excluded because unavailable PSTs present: %s",
                group_id,
                unavailable,
            )
            continue

        missing_bounds = [pst.mrid for pst in group_psts if pst.mrid not in pst_tap_bounds]
        if missing_bounds:
            log.warning(
                "PST group %s excluded because PST(s) %s have no valid tap "
                "bounds (excluded upstream by build_pst_tap_bounds due to "
                "an empty effective range)",
                group_id,
                missing_bounds,
            )
            continue

        bounds = [pst_tap_bounds[pst.mrid] for pst in group_psts]
        effective_min = max(b[0] for b in bounds)
        effective_max = min(b[1] for b in bounds)

        if effective_min > effective_max:
            log.warning(
                "PST group %s excluded because effective group range [%s, %s] is empty",
                group_id,
                effective_min,
                effective_max,
            )
            continue

        # Build an equality pair for each unique PST pair in the valid group.
        for i in range(len(group_psts)):
            for j in range(i + 1, len(group_psts)):
                equality_pairs.append((group_psts[i].mrid, group_psts[j].mrid))

        log.info(
            "PST group %s valid with %d PSTs and effective range [%s, %s]",
            group_id,
            len(group_psts),
            effective_min,
            effective_max,
        )

    return equality_pairs
