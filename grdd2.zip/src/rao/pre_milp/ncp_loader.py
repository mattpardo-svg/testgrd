"""
ncp_loader.py — NCP file discovery and the timestamp list.

Builds NCP_FILES (dict[tso_display_name, dict[profile, Path]]) from a flat input/ncp*.zip
(extract_ncp_zip, then classify_extracted_ncp_files) or from an Instance/ folder
({Country}/NetworkCode/cimxml/{Country}_{profile}.xml; build_ncp_files). Folder names are
bare country names, display names carry a "TSO-" prefix. Required profiles AE, CO, RA
(missing -> ValueError); optional SHS, SIS (missing -> warning; PATL then falls back to the
CGM static limits). A TSO without NCP files is logged and left out.
"""

from __future__ import annotations

import logging
import re
from pathlib import Path
from typing import Optional

log = logging.getLogger(__name__)

REQUIRED_PROFILES = {"AE", "CO", "RA"}
# ER (EquipmentReliability): GeneratingUnit start-up / shut-down costs, the fallback of the
# SIS UnitCostSchedule values
OPTIONAL_PROFILES = {"SHS", "SIS", "ER"}
ALL_PROFILES = REQUIRED_PROFILES | OPTIONAL_PROFILES

# what a missing optional profile means (logged per TSO); ER is commonly absent, so info only
_MISSING_OPTIONAL_PROFILE = {
    "SHS": (logging.WARNING, "SHS fallback to CGM static value"),
    "SIS": (logging.WARNING, "no power bids, no GLSK, no unit costs from SIS"),
    "ER": (logging.INFO, "no GeneratingUnit start-up/shut-down costs from ER"),
}


def _log_missing_optional_profiles(tso_display: str, present_profiles) -> None:
    for profile in sorted(OPTIONAL_PROFILES - set(present_profiles)):
        level, meaning = _MISSING_OPTIONAL_PROFILE[profile]
        log.log(level, "%s: optional profile %s not found — %s", tso_display, profile, meaning)

# NCP content that is not parsed and is skipped without a warning: *_SSI.xml (Steady State
# Instruction, a different profile from *_SIS.xml) and Org-NineRealms_CD_OR.xml (object registry).
_KNOWN_IRRELEVANT_EXACT_NAMES = {"Org-NineRealms_CD_OR.xml"}


def _classify_ncp_zip_entry(filename: str, known_tsos: set[str]) -> tuple[str, Optional[str], Optional[str]]:
    """Classify one file name of a flat input/ncp*.zip: (category, tso or None, profile or None),
    category one of "recognized", "organisation", "known_irrelevant", "unrecognized".
    known_tsos: bare country names (e.g. "Belgovia"), not "TSO-" display names."""
    if filename == "Org-NineRealms_CD.xml":
        return ("organisation", None, None)

    if filename in _KNOWN_IRRELEVANT_EXACT_NAMES or filename.endswith("_SSI.xml"):
        return ("known_irrelevant", None, None)

    if not filename.endswith(".xml") or "_" not in filename:
        return ("unrecognized", None, None)

    stem = filename[: -len(".xml")]

    # match by TSO-name prefix: suffixes may contain underscores ("Svedala_RAS_Jotunheim_agreed.xml")
    for country in known_tsos:
        prefix = f"{country}_"
        if not stem.startswith(prefix):
            continue
        profile = stem[len(prefix):]
        if profile in ALL_PROFILES:
            return ("recognized", country, profile)
        # a known TSO's file of a profile that is not parsed (ER, PS, RAS, RAS_FAP, OR, AS, ...)
        return ("known_irrelevant", None, None)

    country, _, profile = stem.rpartition("_")
    if "-" in country:
        # "Country-Neighbour" prefix: a cross-TSO contingency export, not parsed
        return ("known_irrelevant", None, None)

    return ("unrecognized", None, None)


def extract_ncp_zip(ncp_zip_path: Path, extract_dir: Path) -> Path:
    """Extract a flat input/ncp*.zip and return the path of the Organisation profile.

    Runs before classify_extracted_ncp_files, which needs the tso_name_map built from that
    profile. Duplicate base names are checked on the zip's entry list before extraction
    (extractall would silently overwrite one with the other).
    Raises FileNotFoundError (no zip, or no Org-NineRealms_CD.xml) or ValueError (duplicate).
    """
    import zipfile

    if not ncp_zip_path.exists():
        raise FileNotFoundError(f"NCP zip not found: {ncp_zip_path}")

    with zipfile.ZipFile(ncp_zip_path) as zf:
        entry_names = [name for name in zf.namelist() if not name.endswith("/")]

        basenames_seen: dict[str, str] = {}
        basename_duplicates: list[str] = []
        for name in entry_names:
            basename = Path(name).name
            if basename in basenames_seen and basenames_seen[basename] != name:
                basename_duplicates.append(
                    f"'{basenames_seen[basename]}' and '{name}' both extract to the same filename '{basename}'"
                )
            else:
                basenames_seen[basename] = name

        if basename_duplicates:
            raise ValueError(
                "extract_ncp_zip: the NCP zip contains multiple entries "
                "that would extract to the same filename — refusing to silently "
                "let one overwrite the other: " + "; ".join(basename_duplicates)
            )

        extract_dir.mkdir(parents=True, exist_ok=True)
        zf.extractall(extract_dir)

    org_cd_path = extract_dir / "Org-NineRealms_CD.xml"
    if not org_cd_path.is_file():
        raise FileNotFoundError(
            f"extract_ncp_zip: no file named exactly 'Org-NineRealms_CD.xml' "
            f"found in {ncp_zip_path} — TSO resolution has no source to work "
            f"from without it."
        )
    return org_cd_path


def classify_extracted_ncp_files(
    extract_dir: Path,
    tso_name_map,
) -> dict[str, dict[str, Path]]:
    """Classify the files extracted by extract_ncp_zip into the NCP_FILES shape
    ({TSO}_{PROFILE}.xml). "recognized" files are returned; "organisation" and "known_irrelevant"
    files are skipped; "unrecognized" files are listed in one warning.
    Raises ValueError for a (TSO, profile) found twice or a TSO missing AE, CO or RA; a
    missing SHS or SIS is not an error.
    """
    if isinstance(tso_name_map, dict):
        tso_display_names = set(tso_name_map.values()) or set(tso_name_map.keys())
    else:
        tso_display_names = set(tso_name_map)
    known_tsos = {_country_from_display(name) for name in tso_display_names}

    ncp_files: dict[str, dict[str, Path]] = {}
    unrecognized: list[str] = []
    duplicates: list[str] = []

    for extracted_file in sorted(extract_dir.iterdir()):
        if not extracted_file.is_file():
            continue
        category, country, profile = _classify_ncp_zip_entry(extracted_file.name, known_tsos)

        if category in ("organisation", "known_irrelevant"):
            continue
        elif category == "unrecognized":
            unrecognized.append(extracted_file.name)
        else:  # "recognized"
            tso_display = f"TSO-{country}"
            profiles = ncp_files.setdefault(tso_display, {})
            if profile in profiles:
                duplicates.append(
                    f"{tso_display}: both {profiles[profile].name} and "
                    f"{extracted_file.name} parse as profile '{profile}'"
                )
                continue
            profiles[profile] = extracted_file

    if unrecognized:
        log.warning(
            "classify_extracted_ncp_files: %d file(s) did not match the expected "
            "{TSO}_{PROFILE}.xml naming for a known TSO and recognized "
            "profile — skipped: %s",
            len(unrecognized), unrecognized,
        )

    if duplicates:
        raise ValueError(
            "classify_extracted_ncp_files: duplicate (TSO, profile) combination(s) "
            "found in the NCP zip — refusing to silently pick one: "
            + "; ".join(duplicates)
        )

    errors: list[str] = []
    for tso_display, profiles in sorted(ncp_files.items()):
        missing_required = REQUIRED_PROFILES - profiles.keys()
        if missing_required:
            errors.append(
                f"{tso_display}: missing required profile(s): "
                f"{', '.join(sorted(missing_required))}"
            )
        _log_missing_optional_profiles(tso_display, profiles.keys())

    if errors:
        raise ValueError(
            "classify_extracted_ncp_files: missing required NCP profile(s):\n"
            + "\n".join(errors)
        )

    return ncp_files


def build_ncp_files(
    instance_root: Path,
    tso_name_map,
) -> dict[str, dict[str, Path]]:
    """Scan instance_root and return NCP_FILES for the TSOs that have a NetworkCode/cimxml/
    folder. tso_name_map: TSO mRID -> display name (tso_name_resolver.build_tso_name_map).
    Raises FileNotFoundError (no instance_root) or ValueError (a required profile is missing).
    """
    if not instance_root.exists():
        raise FileNotFoundError(f"Instance root not found: {instance_root}")

    # tso_name_map: dict (tso_name -> tso_name) or an iterable of display names
    if isinstance(tso_name_map, dict):
        tso_display_names = set(tso_name_map.values()) or set(tso_name_map.keys())
    else:
        try:
            tso_display_names = set(tso_name_map)
        except Exception:
            raise ValueError("tso_name_map must be a dict or iterable of TSO display names")
    ncp_files: dict[str, dict[str, Path]] = {}
    errors: list[str] = []

    for tso_display in sorted(tso_display_names):
        country = _country_from_display(tso_display)
        cimxml_dir = instance_root / country / "NetworkCode" / "cimxml"

        if not cimxml_dir.exists():
            log.info(
                "%s: no NetworkCode/cimxml/ directory — TSO provides no NCP data, skipped",
                tso_display,
            )
            continue

        profiles: dict[str, Path] = {}
        for profile in ALL_PROFILES:
            candidate = cimxml_dir / f"{country}_{profile}.xml"
            if candidate.exists():
                profiles[profile] = candidate
                log.debug("%s: found %s → %s", tso_display, profile, candidate.name)

        # Hard error on missing required profiles (only for TSOs with a cimxml dir)
        missing_required = REQUIRED_PROFILES - profiles.keys()
        if missing_required:
            errors.append(
                f"{tso_display}: missing required profile(s): "
                f"{', '.join(sorted(missing_required))}"
            )

        _log_missing_optional_profiles(tso_display, profiles.keys())

        ncp_files[tso_display] = profiles
        log.info(
            "%s: %d profile(s) found (%s)",
            tso_display,
            len(profiles),
            ", ".join(sorted(profiles)),
        )

    if errors:
        raise ValueError(
            "NCP file discovery failed — missing required files:\n"
            + "\n".join(f"  • {e}" for e in errors)
        )

    log.info(
        "NCP_FILES built: %d TSOs with NCP data (of %d in CGM)",
        len(ncp_files),
        len(tso_display_names),
    )
    return ncp_files


def build_timestamp_list(start_hour: str, n_timestamps: int) -> list[str]:
    """n_timestamps consecutive hourly timestamps from start_hour, e.g. ("1030Z", 4) ->
    ["1030Z", "1130Z", "1230Z", "1330Z"]. ValueError for a bad format or n outside 1..24."""
    if n_timestamps < 1 or n_timestamps > 24:
        raise ValueError(f"n_timestamps must be 1–24, got {n_timestamps}")

    m = re.fullmatch(r"(\d{2})(\d{2})Z", start_hour)
    if not m:
        raise ValueError(
            f"start_hour must be in HHMMZ format (e.g. '1030Z'), got {start_hour!r}"
        )

    hh, mm = int(m.group(1)), int(m.group(2))
    if hh > 23 or mm > 59:
        raise ValueError(f"Invalid time in start_hour: {start_hour!r}")

    timestamps: list[str] = []
    for i in range(n_timestamps):
        total_minutes = hh * 60 + mm + i * 60
        total_minutes %= 24 * 60
        h_new = total_minutes // 60
        m_new = total_minutes % 60
        timestamps.append(f"{h_new:02d}{m_new:02d}Z")

    log.info(
        "TIMESTAMP_LIST: %d entries, %s → %s",
        len(timestamps), timestamps[0], timestamps[-1],
    )
    return timestamps


def _country_from_display(tso_display: str) -> str:
    """Strip a leading 'TSO-': "TSO-Belgovia" -> "Belgovia"."""
    return tso_display.removeprefix("TSO-")


# ---------------------------------------------------------------------------
# CLI entry point
# ---------------------------------------------------------------------------
if __name__ == "__main__":
    import argparse, sys

    logging.basicConfig(level=logging.INFO, format="%(levelname)s %(message)s")

    parser = argparse.ArgumentParser(description="NCP file discovery")
    parser.add_argument("instance_root", type=Path,
                        help="Path to Instance/ directory")
    parser.add_argument("org_cd", type=Path,
                        help="Path to Org-NineRealms_CD.xml")
    parser.add_argument("--start-hour", default="1030Z",
                        help="Anchor timestamp, e.g. 1030Z (default: 1030Z)")
    parser.add_argument("--n-timestamps", type=int, default=4,
                        help="Number of consecutive hourly timestamps (default: 4)")
    args = parser.parse_args()

    sys.path.insert(0, str(Path(__file__).resolve().parents[2]))
    from pre_milp.tso_name_resolver import build_tso_name_map

    tso_name_map = build_tso_name_map(args.org_cd)
    ncp_files = build_ncp_files(args.instance_root, tso_name_map)
    timestamp_list = build_timestamp_list(args.start_hour, args.n_timestamps)

    print("\nNCP_FILES:")
    for tso, profiles in sorted(ncp_files.items()):
        print(f"  {tso}:")
        for profile, path in sorted(profiles.items()):
            print(f"    {profile}: {path.name}")

    print(f"\nTIMESTAMP_LIST: {timestamp_list}")
    print(f"\nTSOs with NCP data: {len(ncp_files)}  |  Timestamps: {len(timestamp_list)}")