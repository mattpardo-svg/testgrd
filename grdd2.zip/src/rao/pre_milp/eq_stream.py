"""eq_stream.py - the few facts of a CGM EQ file that the pipeline needs, read in one streaming pass.

rdflib turns an EQ file into millions of triples (about 1 KB each) just so that three small maps can be read from it:
TapChanger -> PowerTransformer, CurrentLimit -> side and the ControlAreaGeneratingUnit pairs. StreamedEq answers the
two calls those readers make, graph.subjects(RDF.type, class) and graph.value(subject, predicate), from the objects
of a few classes and from a few properties only, so the readers run unchanged on it (same code, same log lines) and
a file of hundreds of MB costs a few MB.

The file is read in streaming mode with xml.etree. Anything that could make the answer differ from rdflib's - a
subject or a reference that is not a local "#id", a property that is not a plain literal or a plain reference, a
subject without an id - makes stream_eq return None, and the caller parses the file with rdflib as before. Objects of
other classes and other properties are ignored, as the readers never ask for them; asking for one raises ValueError
instead of answering None.
"""

from __future__ import annotations

import sys
import xml.etree.ElementTree as ET
from pathlib import Path
from typing import Optional

from rdflib import RDF, Literal, URIRef

RDF_NS = "http://www.w3.org/1999/02/22-rdf-syntax-ns#"
CIM_NAMESPACES = ("https://cim.ucaiug.io/ns#", "http://iec.ch/TC57/CIM100#")

# classes whose subjects the readers list
LISTED_CLASSES = frozenset({
    "CurrentLimit", "ControlAreaGeneratingUnit",
    "PhaseTapChangerSymmetrical", "PhaseTapChangerAsymmetrical", "PhaseTapChangerTabular", "PhaseTapChangerLinear",
})
# the classes whose mRID the readers ask for (the listed ones, and the PowerTransformer a PowerTransformerEnd points to)
MRID_CLASSES = LISTED_CLASSES | {"PowerTransformer"}
# the properties the readers ask for, of a subject of any class: references (value = the local id) and literals
# (value = the text); the mRID is held for the MRID_CLASSES only
REFERENCES = frozenset({
    "OperationalLimit.OperationalLimitSet", "OperationalLimitSet.Terminal", "PhaseTapChanger.TransformerEnd",
    "TapChanger.TransformerEnd", "PowerTransformerEnd.PowerTransformer", "ControlAreaGeneratingUnit.ControlArea",
    "ControlAreaGeneratingUnit.GeneratingUnit",
})
SEQUENCE_NUMBER = "ACDCTerminal.sequenceNumber"
MRID = "IdentifiedObject.mRID"
LITERALS = frozenset({MRID, SEQUENCE_NUMBER})


def _split(name: str) -> tuple[str, str]:
    """('namespace#', 'local') of a Clark name '{namespace#}local' or of a URI 'namespace#local'."""
    if name.startswith("{"):
        namespace, _, local = name[1:].partition("}")
        return namespace, local
    namespace, _, local = name.rpartition("#")
    return namespace + "#" if namespace else "", local


class StreamedEq:
    """Answers graph.subjects(RDF.type, class) and graph.value(subject, predicate) for the classes and properties of
    the module docstring; anything else raises ValueError."""

    def __init__(self):
        self._listed: dict[tuple[str, str], list[str]] = {}            # (namespace, class) -> subject ids in file order
        self._held: dict[tuple[str, str], dict[str, str]] = {}         # (namespace, property) -> {subject id: id / text}

    def subjects(self, predicate=None, obj=None):
        namespace, local = _split(str(obj))
        if predicate != RDF.type or namespace not in CIM_NAMESPACES or local not in LISTED_CLASSES:
            raise ValueError(f"StreamedEq lists the subjects of {sorted(LISTED_CLASSES)} only, not ({predicate}, {obj})")
        return iter([URIRef("#" + key) for key in self._listed.get((namespace, local), ())])

    def value(self, subject=None, predicate=None):
        namespace, local = _split(str(predicate))
        if namespace not in CIM_NAMESPACES or local not in REFERENCES | LITERALS:
            raise ValueError(f"StreamedEq does not hold the property {predicate}")
        text = self._held.get((namespace, local), {}).get(str(subject)[1:])
        if text is None:
            return None
        return URIRef("#" + text) if local in REFERENCES else Literal(text)


def stream_eq(path: Path) -> Optional[StreamedEq]:
    """The StreamedEq of an EQ file, or None when the file has something the stream cannot answer exactly like rdflib
    (the caller then parses it with rdflib)."""
    attribute_id, attribute_about, attribute_resource = f"{{{RDF_NS}}}ID", f"{{{RDF_NS}}}about", f"{{{RDF_NS}}}resource"
    attribute_parse_type = f"{{{RDF_NS}}}parseType"
    streamed = StreamedEq()
    held, listed = streamed._held, streamed._listed
    depth = 0
    root = None
    subject_id: Optional[str] = None
    subject_class: tuple[str, str] = ("", "")              # (namespace, class) of the subject being read
    properties: list[tuple[tuple[str, str], str]] = []
    try:
        for event, element in ET.iterparse(str(path), events=("start", "end")):
            if event == "start":
                depth += 1
                if root is None:
                    root = element
                if depth == 2:
                    subject_class = _split(element.tag)
                    subject_id = element.get(attribute_id)
                    about = element.get(attribute_about)
                    if subject_id is None and about is not None and about.startswith("#"):
                        subject_id = about[1:]
                    if subject_id is None and subject_class[0] in CIM_NAMESPACES and subject_class[1] in LISTED_CLASSES:
                        return None                        # a listed subject must have an id the references can name
                    if subject_id is not None:
                        subject_id = sys.intern(subject_id)
                    properties = []
                continue
            if depth == 3 and subject_id is not None:
                namespace, local = _split(element.tag)
                if namespace in CIM_NAMESPACES and local in REFERENCES | LITERALS:
                    if len(element) or element.get(attribute_parse_type) is not None:
                        return None
                    resource = element.get(attribute_resource)
                    if local in REFERENCES:
                        if resource is None or not resource.startswith("#"):
                            return None
                        properties.append(((namespace, local), sys.intern(resource[1:])))
                    elif resource is not None:
                        return None
                    elif local == SEQUENCE_NUMBER or subject_class[1] in MRID_CLASSES:
                        properties.append(((namespace, local), element.text or ""))
            elif depth == 2:
                if subject_id is not None:
                    if subject_class[0] in CIM_NAMESPACES and subject_class[1] in LISTED_CLASSES:
                        listed.setdefault(subject_class, []).append(subject_id)
                    for name, text in properties:
                        held.setdefault(name, {}).setdefault(subject_id, text)
                element.clear()
                if root is not None:
                    root.clear()
            depth -= 1
    except ET.ParseError:
        return None
    return streamed
