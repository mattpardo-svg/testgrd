"""ct_weights.py — participation factors of a countertrade RA (docs/specs/countertrade_ra_specs.md C3).

The strategy proportionalForRemainingCapacity, direction-aware and computed once from the
ORIGINAL set points of the units of the zone:
  up:   PF_g = (Pmax_g - PROD_g) / sum (Pmax - PROD)
  down: PF_g = (PROD_g - Pmin_g) / sum (PROD - Pmin)
Excluded units (reason in CtWeights.excluded): not connected, limits missing or unbounded, PROD
above Pmax (CT only), off by the F2 rule (a connected unit is on if PROD <> 0 or Pmin <= 0), and
units that cannot move in the direction (up: Pmax reached; down: Pmin reached). The factors are
normalised after the exclusion; this equals PF_g / (1 - sum of the excluded PF) of C3.6, because
a unit without room has the raw factor 0 and an off unit is simply left out. A unit with
0 < PROD < Pmin has its Pmin set to PROD (F2 rule 11), so it has no room to go down.
No unit left: pf is empty, one warning is logged and the caller fixes the bid volume to 0.
"""

from __future__ import annotations

import logging
import math
from dataclasses import dataclass, field

from data_model import BidDirection, CtZoneUnit
from milp.milp_builder import PROD_ZERO_TOLERANCE_MW
from pre_milp.hvdc_units import UNBOUNDED_MW

log = logging.getLogger(__name__)

# room (MW) at or below this counts as no room to move
ROOM_TOLERANCE_MW = 1e-9

REASON_NOT_CONNECTED = "not connected"
REASON_NO_LIMITS = "limits missing or unbounded"
REASON_ABOVE_PMAX = "PROD above Pmax"
REASON_OFF = "off (F2)"
REASON_AT_PMAX = "at Pmax"
REASON_AT_PMIN = "at Pmin"


@dataclass
class CtWeights:
    """pf: {generator id: participation factor}, summing to 1, or empty. excluded: {generator
    id: reason} of the units left out."""
    direction: BidDirection
    pf: dict[str, float] = field(default_factory=dict)
    excluded: dict[str, str] = field(default_factory=dict)


def _is_bounded(value: float) -> bool:
    return value is not None and math.isfinite(value) and abs(value) < UNBOUNDED_MW


def compute_ct_weights(units: list[CtZoneUnit], direction: BidDirection, label: str = "") -> CtWeights:
    """The weights of the units of one zone for one direction (see the module text). label (for
    example "CT RA <mrid>") names the RA in the log lines; an empty label logs nothing."""
    result = CtWeights(direction=direction)
    room: dict[str, float] = {}
    for unit in sorted(units, key=lambda u: u.gu_mrid):
        prod = 0.0 if abs(unit.prod) <= PROD_ZERO_TOLERANCE_MW else float(unit.prod)
        if not unit.connected:
            result.excluded[unit.gu_mrid] = REASON_NOT_CONNECTED
            continue
        if not (_is_bounded(unit.pmin) and _is_bounded(unit.pmax)):
            result.excluded[unit.gu_mrid] = REASON_NO_LIMITS
            continue
        if prod - unit.pmax > ROOM_TOLERANCE_MW:
            result.excluded[unit.gu_mrid] = REASON_ABOVE_PMAX
            continue
        if not (prod != 0.0 or unit.pmin <= 0.0):
            result.excluded[unit.gu_mrid] = REASON_OFF
            continue
        pmin = prod if (unit.pmin > 0.0 and 0.0 < prod < unit.pmin) else unit.pmin
        available = (unit.pmax - prod) if direction == BidDirection.UP else (prod - pmin)
        if available <= ROOM_TOLERANCE_MW:
            result.excluded[unit.gu_mrid] = REASON_AT_PMAX if direction == BidDirection.UP else REASON_AT_PMIN
            continue
        room[unit.gu_mrid] = available

    total = sum(room.values())
    if total > 0.0:
        result.pf = {gu: value / total for gu, value in room.items()}

    if label:
        if not result.pf:
            log.warning(
                "%s: no unit can move %s (%d unit(s) in the zone; %s) - the %s bid volume is fixed to 0",
                label, direction.value, len(units), _describe(result.excluded) or "no unit", direction.value,
            )
        else:
            log.info(
                "%s: %s weights over %d unit(s)%s", label, direction.value, len(result.pf),
                f"; excluded: {_describe(result.excluded)}" if result.excluded else "",
            )
    return result


def _describe(excluded: dict[str, str]) -> str:
    return ", ".join(f"{gu} ({reason})" for gu, reason in sorted(excluded.items()))
