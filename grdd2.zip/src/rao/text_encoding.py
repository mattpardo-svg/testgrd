"""text_encoding.py — the one text-encoding rule of the RAO pipeline and its GUI (DECISIONS 59).

Every text file they write or read (result CSVs, run_log.txt, the YAML config files, the GUI
settings JSON, the pipeline's console output read by the GUI) is UTF-8 without a byte-order
mark, and the encoding is passed explicitly at every call site (the platform default is cp1252
on Windows). Input XML (CGM, NCP) keeps its parser's own handling (the XML declaration).
tests/test_rao_text_encoding.py fails on a call without an explicit encoding.
"""

# "utf-8", not "utf-8-sig": no byte-order mark is written, and one at the start of a file read
# with it is kept as a character (so a BOM is noticed, not silently dropped)
TEXT_ENCODING = "utf-8"


def not_utf8_message(path, error: UnicodeDecodeError) -> str:
    """The error text for a user-supplied text file that is not valid UTF-8: names the file and
    the byte position; nothing is guessed."""
    return (
        f"{path} is not valid UTF-8 (byte {error.start}: {error.reason}). Save the file as UTF-8 "
        f"(without BOM) and run again."
    )
