# rao-prototype
RAO prototype using ReliCapGrid CGMES + NCP, pypowsybl, HiGHS

- `docs/README.md`: scope, flow, how to run and test, code layout, document index.
- `mock_data/README.md`: generators of the mock and test data, the golden-run gate.
- `use_cases/`: live demonstrations of RAO features on mock data; `use_cases/01_pst/README.md` (preventive and curative PST; open `results/index.html` after a run: summary pages with grid schematic, zoom and pan), `use_cases/FINDINGS.md` (tool findings).
- Mock run: `python src/rao/run_pipeline.py` (`input/` holds the HVDC pair `CGM_package_hvdc.zip` + `NCP_mock_hvdc.zip`; the previous pair is in `input_old/` and in `tests/fixtures`; see the User Guide, "HVDC use case"). Tests: `python -m pytest tests -q`.
