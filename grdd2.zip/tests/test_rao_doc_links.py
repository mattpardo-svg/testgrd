"""tests/test_rao_doc_links.py - the documentation link checker (mock_data/tools/check_doc_links.py): a live dead link fails,
a history file, a whitelisted pair and a valid link do not. Works on a temporary folder."""

import importlib.util
import pathlib

D, S = "docs", "src"      # built from variables: the checker scans this file and must not see these paths as literals
CHECKER = pathlib.Path(__file__).resolve().parents[1] / "mock_data" / "tools" / "check_doc_links.py"


def _checker():
    spec = importlib.util.spec_from_file_location("check_doc_links_under_test", CHECKER)
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


def _write(root, relative, text):
    path = root / relative
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(text, encoding="utf-8")


def test_rao_a_valid_link_and_path_pass(tmp_path, capsys):
    _write(tmp_path, f"{D}/a.md", f"See [b](b.md) and `{D}/b.md`.\n")
    _write(tmp_path, f"{D}/b.md", "text\n")
    assert _checker().main(True, tmp_path) == 0
    assert "0 dead in live files" in capsys.readouterr().out


def test_rao_a_broken_markdown_link_and_a_broken_path_fail(tmp_path, capsys):
    _write(tmp_path, f"{D}/a.md", f"See [gone](gone.md).\nand `{D}/missing.md`.\n")
    assert _checker().main(True, tmp_path) == 1
    out = capsys.readouterr().out
    assert f"DEAD {D}/a.md:1: gone.md" in out and f"DEAD {D}/a.md:2: {D}/missing.md" in out


def test_rao_a_broken_path_in_a_comment_of_a_source_file_fails(tmp_path):
    _write(tmp_path, f"{S}/m.py", f"# see {D}/nothing_here.md\n")
    assert _checker().main(True, tmp_path) == 1


def test_rao_history_files_are_listed_apart_and_do_not_fail(tmp_path, capsys):
    for name in (f"{D}/CHANGELOG.md", f"{D}/DECISIONS.md", f"{D}/archive/old.md"):
        _write(tmp_path, name, f"was `{D}/old_name.md`\n")
    assert _checker().main(False, tmp_path) == 0
    out = capsys.readouterr().out
    assert out.count("\nhistory ") + out.startswith("history ") == 3 and "0 dead in live files, 3 in history files" in out


def test_rao_a_whitelisted_pair_passes_only_in_its_own_file(tmp_path):
    module = _checker()
    file, target = sorted(module.WHITELIST)[0]
    _write(tmp_path, file, f"names `{target}`\n")
    assert module.main(True, tmp_path) == 0
    _write(tmp_path, f"{D}/other.md", f"names `{target}`\n")
    assert module.main(True, tmp_path) == 1


def test_rao_the_repository_has_no_dead_live_link(capsys):
    assert _checker().main(True) == 0, capsys.readouterr().out
