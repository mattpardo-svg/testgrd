"""tests/test_rao_n0_check_scale.py - resolve_n0 (the N-0 sensitivity guard: fresh sets, the last valid set per branch)
groups the entries by branch once instead of rescanning the whole set for every branch. Same results as the
rescanning version, and a generated set of 3000 branches x 40 units resolves within a time budget."""

import random
import time

import pytest

from pre_milp.sensitivity_checks import STALE_REUSED, resolve_n0


def _rescanning_resolve_n0(
    fresh_pst, fresh_rd, invalid, monitored_branches, store_pst, store_rd, allowed_branches, allowed_psts, allowed_gus,
    fresh_hvdc=None, store_hvdc=None, allowed_hvdc=None, hvdc_result=None,
):
    """The version before the change (of_branch scans the whole set for each branch), kept as the reference."""
    from pre_milp.sensitivity_checks import _key_mismatch

    def of_branch(values, branch):
        return {key: value for key, value in values.items() if key[0] == branch}

    branches = set(monitored_branches) | {key[0] for key in fresh_pst} | {key[0] for key in fresh_rd}
    if fresh_hvdc is not None:
        branches |= {key[0] for key in fresh_hvdc}
    store_hvdc = store_hvdc if store_hvdc is not None else {}
    pst, rd, stale = dict(fresh_pst), dict(fresh_rd), {}
    hvdc = dict(fresh_hvdc) if fresh_hvdc is not None else None

    def done(failure):
        if hvdc_result is not None:
            hvdc_result.clear()
            if hvdc is not None:
                hvdc_result.update(hvdc)
        return pst, rd, stale, failure

    for branch in sorted(branches | set(invalid)):
        if branch not in invalid:
            store_pst[branch], store_rd[branch] = of_branch(fresh_pst, branch), of_branch(fresh_rd, branch)
            if hvdc is not None:
                store_hvdc[branch] = of_branch(fresh_hvdc, branch)
            continue
        rule = invalid[branch]
        if branch not in store_pst or branch not in store_rd or (hvdc is not None and branch not in store_hvdc):
            return done(f"branch {branch}: N-0 sensitivities invalid ({rule}) and no earlier valid set exists")
        mismatch = (
            _key_mismatch(store_pst[branch], allowed_branches, allowed_psts)
            or _key_mismatch(store_rd[branch], allowed_branches, allowed_gus)
            or (_key_mismatch(store_hvdc[branch], allowed_branches, allowed_hvdc or set()) if hvdc is not None else None)
        )
        if mismatch:
            return done(f"branch {branch}: N-0 sensitivities invalid ({rule}); the stored valid set no longer "
                        f"matches the model keys: {mismatch}")
        pst = {k: v for k, v in pst.items() if k[0] != branch}
        rd = {k: v for k, v in rd.items() if k[0] != branch}
        pst.update(store_pst[branch])
        rd.update(store_rd[branch])
        if hvdc is not None:
            hvdc = {k: v for k, v in hvdc.items() if k[0] != branch}
            hvdc.update(store_hvdc[branch])
        stale[branch] = STALE_REUSED
    return done(None)


def _sets(branch_count, psts=3, units=4, seed=0):
    rng = random.Random(seed)
    branches = [f"br{i:03d}" for i in range(branch_count)]
    pst = {(b, f"pst{j}"): rng.random() for b in branches for j in range(psts)}
    rd = {(b, f"gu{j}"): rng.random() for b in branches for j in range(units)}
    hvdc = {(b, "ei1"): rng.random() for b in branches}
    return branches, pst, rd, hvdc


@pytest.mark.parametrize("with_hvdc", [False, True])
@pytest.mark.parametrize("invalid_branches", [(), ("br002",), ("br001", "br007")])
def test_rao_resolve_n0_gives_the_results_and_stores_of_the_rescanning_version(with_hvdc, invalid_branches):
    branches, pst, rd, hvdc = _sets(10)
    # a valid earlier set for every branch (the stored one differs from the fresh one)
    old_pst, old_rd, old_hvdc = ({k: v + 1.0 for k, v in s.items()} for s in (pst, rd, hvdc))
    groups = lambda values: {b: {k: v for k, v in values.items() if k[0] == b} for b in branches}
    allowed = (set(branches), {f"pst{j}" for j in range(3)}, {f"gu{j}" for j in range(4)})
    invalid = {b: "reference mismatch" for b in invalid_branches}
    outcomes = []
    for function in (resolve_n0, _rescanning_resolve_n0):
        store_pst, store_rd, store_hvdc = groups(old_pst), groups(old_rd), groups(old_hvdc)
        result = {}
        got = function(
            dict(pst), dict(rd), invalid, set(branches), store_pst, store_rd, *allowed,
            fresh_hvdc=dict(hvdc) if with_hvdc else None, store_hvdc=store_hvdc if with_hvdc else None,
            allowed_hvdc={"ei1"} if with_hvdc else None, hvdc_result=result,
        )
        outcomes.append((got, store_pst, store_rd, store_hvdc, result))
    (new, *new_stores), (old, *old_stores) = outcomes
    assert list(new_stores.pop().items()) == list(old_stores.pop().items())            # the HVDC set handed to the builder
    assert new[3] == old[3] is None
    assert list(new[0].items()) == list(old[0].items()) and list(new[1].items()) == list(old[1].items())
    assert new[2] == old[2] == {b: STALE_REUSED for b in invalid_branches}
    for new_store, old_store in zip(new_stores, old_stores):
        assert {b: list(v.items()) for b, v in new_store.items()} == {b: list(v.items()) for b, v in old_store.items()}


def test_rao_resolve_n0_failure_messages_are_unchanged():
    branches, pst, rd, _ = _sets(4)
    for function in (resolve_n0, _rescanning_resolve_n0):
        got = function(dict(pst), dict(rd), {"br001": "bad"}, set(branches), {}, {}, set(branches), set(), set())
        assert got[3] == "branch br001: N-0 sensitivities invalid (bad) and no earlier valid set exists"


def test_rao_a_generated_set_of_3000_branches_resolves_within_the_budget():
    """3000 branches x (3 PSTs + 40 units) = 129000 entries per set: the rescanning version walked the whole set once
    per branch (390 million steps, 12.7 s on the development machine, against 0.1 s now). Budget: 2 s."""
    branches, pst, rd, _ = _sets(3000, psts=3, units=40)
    store_pst, store_rd = {}, {}
    start = time.perf_counter()
    got = resolve_n0(pst, rd, {}, set(branches), store_pst, store_rd, set(branches), set(), set())
    seconds = time.perf_counter() - start
    print(f"resolve_n0 on {len(pst) + len(rd)} entries: {seconds:.2f} s")
    assert got[3] is None and len(store_pst) == 3000 and len(store_rd) == 3000 and len(store_rd["br042"]) == 40
    assert seconds < 2
