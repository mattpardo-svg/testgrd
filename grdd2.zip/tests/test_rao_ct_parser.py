"""
test_rao_ct_parser.py — countertrade remedial actions without a MILP (docs/specs/countertrade_ra_specs.md
C2): pre_milp/ct_units.py on synthetic RA, SIS, Organisation-profile and EQ snippets, and the
fixture CT RA that must be ignored.
"""
import logging
import zipfile
from pathlib import Path

import pytest

from data_model import BidDirection, CtRa, RAKind
from helpers import _RA_FOOTER, _RA_HEADER, FIXTURE_NCP_GENERIC_ZIP
from pre_milp import ct_units, ncp_parser
from pre_milp.ct_units import CtGenerator, CtZone
from text_encoding import TEXT_ENCODING

LOG = ct_units.log.name
TS = "1730Z"
ZONE = "ZONE-1"
STRATEGY = ct_units.STRATEGY_REMAINING_CAPACITY
KIND_NS = "https://cim4.eu/ns/nc#RemedialActionKind."


def _ct_ra(mrid="CT-1", zone=ZONE, strategy=STRATEGY, kind="preventive", available="true", penalty=1.5,
           time_to_implement=None, extra=""):
    zone_xml = f'<nc:PowerRemedialAction.BiddingZone rdf:resource="#_{zone}"/>' if zone else ""
    strategy_xml = (f'<nc:CountertradeRemedialAction.gLSKStrategy rdf:resource="https://cim4.eu/ns/nc#GLSKStrategyKind.{strategy}"/>'
                    if strategy else "")
    penalty_xml = f"<nc:RemedialAction.penaltyFactor>{penalty}</nc:RemedialAction.penaltyFactor>" if penalty is not None else ""
    time_xml = (f"<nc:RemedialAction.timeToImplement>{time_to_implement}</nc:RemedialAction.timeToImplement>"
                if time_to_implement else "")
    return f"""
    <nc:CountertradeRemedialAction rdf:ID="_{mrid}">
      <cim:IdentifiedObject.mRID>{mrid}</cim:IdentifiedObject.mRID>
      <cim:IdentifiedObject.name>CT {mrid}</cim:IdentifiedObject.name>
      <nc:RemedialAction.normalAvailable>{available}</nc:RemedialAction.normalAvailable>
      <nc:RemedialAction.kind rdf:resource="{KIND_NS}{kind}"/>
      {zone_xml}{strategy_xml}{penalty_xml}{time_xml}{extra}
    </nc:CountertradeRemedialAction>"""


def _link(link_id, ra, contingency):
    return f"""
    <nc:ContingencyWithRemedialAction rdf:ID="_{link_id}">
      <nc:ContingencyWithRemedialAction.RemedialAction rdf:resource="#_{ra}"/>
      <nc:ContingencyWithRemedialAction.Contingency rdf:resource="#_{contingency}"/>
    </nc:ContingencyWithRemedialAction>"""


def _bid(mrid, ra, direction, volume=120.0, price=7.0, strategy=None, at="2024-02-22T17:30:00Z"):
    strategy_xml = (f'<nc:PowerBidSchedule.gLSKStrategy rdf:resource="https://cim4.eu/ns/nc#GLSKStrategyKind.{strategy}"/>'
                    if strategy else "")
    point = (f"""
    <nc:PowerBidScheduleTimePoint rdf:ID="_TP-{mrid}">
      <nc:PowerBidScheduleTimePoint.atTime>{at}</nc:PowerBidScheduleTimePoint.atTime>
      <nc:PowerBidScheduleTimePoint.PowerBidSchedule rdf:resource="#_{mrid}"/>
      <nc:PowerBidScheduleTimePoint.p>{volume}</nc:PowerBidScheduleTimePoint.p>
      <nc:PowerBidScheduleTimePoint.price>{price}</nc:PowerBidScheduleTimePoint.price>
    </nc:PowerBidScheduleTimePoint>""" if volume is not None else "")
    return f"""
    <nc:PowerBidSchedule rdf:ID="_{mrid}">
      <cim:IdentifiedObject.mRID>{mrid}</cim:IdentifiedObject.mRID>
      <nc:PowerBidSchedule.PowerRemedialAction rdf:resource="#_{ra}"/>
      <nc:PowerBidSchedule.direction rdf:resource="https://cim4.eu/ns/nc#BidDirectionKind.{direction}"/>
      {strategy_xml}
    </nc:PowerBidSchedule>{point}"""


def _files(tmp_path, ra_body, sis_body=""):
    ra, sis = tmp_path / "T_RA.xml", tmp_path / "T_SIS.xml"
    ra.write_text(_RA_HEADER + ra_body + _RA_FOOTER, encoding=TEXT_ENCODING)
    sis.write_text(_RA_HEADER + sis_body + _RA_FOOTER, encoding=TEXT_ENCODING)
    return ra, sis


def _parse(tmp_path, ra_body, sis_body="", caplog=None):
    ra, sis = _files(tmp_path, ra_body, sis_body)
    if caplog is not None:
        with caplog.at_level(logging.INFO, logger=LOG):
            return ct_units.parse_ct_remedial_actions(ra, sis, "T", [TS])
    return ct_units.parse_ct_remedial_actions(ra, sis, "T", [TS])


def _messages(caplog, level=logging.WARNING):
    return [r.getMessage() for r in caplog.records if r.levelno >= level and r.name == LOG]


# ---------------------------------------------------------------------------
# the RA and its bids
# ---------------------------------------------------------------------------

def test_a_valid_ra_and_its_two_bids_are_parsed(tmp_path):
    ras, bids = _parse(
        tmp_path,
        _ct_ra(kind="curative", time_to_implement="PT5M") + _link("L1", "CT-1", "CO-1"),
        _bid("B-UP", "CT-1", "up", 120, 7) + _bid("B-DN", "CT-1", "down", 90, 3),
    )
    assert len(ras) == 1
    ra = ras[0]
    assert (ra.mrid, ra.tso, ra.zone_mrid, ra.strategy) == ("CT-1", "T", ZONE, STRATEGY)
    assert ra.available and ra.kind == RAKind.CURATIVE and ra.penalty_factor == 1.5
    assert ra.reaction_time_minutes == pytest.approx(5.0) and ra.linked_contingency_mrids == ["CO-1"]
    by_mrid = {b.mrid: b for b in bids}
    assert set(by_mrid) == {"B-UP", "B-DN"}
    assert by_mrid["B-UP"].ra_mrid == "CT-1" and by_mrid["B-UP"].direction == BidDirection.UP
    assert by_mrid["B-UP"].available_mw[TS] == 120.0 and by_mrid["B-UP"].price_eur_mw == 7.0
    assert by_mrid["B-DN"].direction == BidDirection.DOWN and by_mrid["B-DN"].available_mw[TS] == 90.0


def test_a_preventive_ra_without_links_or_reaction_time_has_none(tmp_path):
    ras, _ = _parse(tmp_path, _ct_ra(), _bid("B", "CT-1", "up"))
    assert ras[0].kind == RAKind.PREVENTIVE and ras[0].reaction_time_minutes is None
    assert ras[0].linked_contingency_mrids == []


def test_an_unavailable_ra_is_kept_with_its_flag(tmp_path):
    ras, _ = _parse(tmp_path, _ct_ra(available="false"), _bid("B", "CT-1", "up"))
    assert len(ras) == 1 and ras[0].available is False


def test_the_strategy_may_be_declared_on_the_bids_only(tmp_path):
    ras, bids = _parse(
        tmp_path, _ct_ra(strategy=None), _bid("B1", "CT-1", "up", strategy=STRATEGY) + _bid("B2", "CT-1", "down", strategy=STRATEGY),
    )
    assert len(ras) == 1 and ras[0].strategy == STRATEGY and len(bids) == 2


def test_the_bids_of_an_ignored_ra_are_not_returned(tmp_path):
    ras, bids = _parse(
        tmp_path, _ct_ra("CT-1", strategy="explicitInstruction") + _ct_ra("CT-2"),
        _bid("B1", "CT-1", "up") + _bid("B2", "CT-2", "up"),
    )
    assert [ra.mrid for ra in ras] == ["CT-2"] and [b.mrid for b in bids] == ["B2"]


def test_no_countertrade_ra_gives_empty_results(tmp_path):
    ras, bids = _parse(tmp_path, "")
    assert ras == [] and bids == []


# ---------------------------------------------------------------------------
# ignored RAs (C2.2): one warning each, naming the RA
# ---------------------------------------------------------------------------

@pytest.mark.parametrize("strategy", ["explicitInstruction", "proportionalForGenerator", "generatorPmax", "somethingElse"])
def test_another_strategy_ignores_the_ra_with_a_warning(tmp_path, caplog, strategy):
    ras, bids = _parse(tmp_path, _ct_ra(strategy=strategy), _bid("B", "CT-1", "up"), caplog)
    assert ras == [] and bids == []
    messages = _messages(caplog)
    assert len(messages) == 1 and "CT-1" in messages[0] and "IGNORED" in messages[0] and strategy in messages[0]


def test_a_standard_ra_without_any_strategy_gets_the_default_with_a_warning(tmp_path, caplog):
    """Neither profile has a strategy attribute: the RA is usable and proportionalForRemainingCapacity is
    assumed, with one warning naming the RA (decision 90)."""
    ras, bids = _parse(tmp_path, _ct_ra(strategy=None), _bid("B", "CT-1", "up"), caplog)
    assert len(ras) == 1 and ras[0].strategy == STRATEGY and len(bids) == 1
    messages = [m for m in _messages(caplog) if "assumed" in m]
    assert len(messages) == 1 and "CT-1" in messages[0] and STRATEGY in messages[0]


def test_old_version_attributes_are_not_read_and_are_warned_about(tmp_path, caplog):
    """powerShiftKey and method belong to an older profile version: the value is not used (generatorPmax does
    not make the RA ignored) and one warning names the attributes."""
    extra = ('<nc:CountertradeRemedialAction.powerShiftKey rdf:resource="https://cim4.eu/ns/nc#GLSKStrategyKind.generatorPmax"/>'
             '<nc:CountertradeRemedialAction.method rdf:resource="https://cim4.eu/ns/nc#ShiftMethodKind.shared"/>')
    ras, _ = _parse(tmp_path, _ct_ra(strategy=None, extra=extra), _bid("B", "CT-1", "up"), caplog)
    assert len(ras) == 1 and ras[0].strategy == STRATEGY
    messages = [m for m in _messages(caplog) if "not read" in m]
    assert len(messages) == 1 and "powerShiftKey" in messages[0] and "method" in messages[0] and "CT-1" in messages[0]


def test_the_old_glsk_strategy_attribute_is_a_fallback_with_a_deprecation_warning(tmp_path, caplog):
    ras, _ = _parse(tmp_path, _ct_ra(), _bid("B", "CT-1", "up"), caplog)
    assert ras[0].strategy == STRATEGY
    messages = [r.getMessage() for r in caplog.records if r.levelno >= logging.WARNING and "deprecated" in r.getMessage()]
    assert len(messages) == 1 and "T_RA.xml" in messages[0] and not any("assumed" in m for m in _messages(caplog))


def test_bids_with_different_strategies_ignore_the_ra(tmp_path, caplog):
    ras, bids = _parse(
        tmp_path, _ct_ra(strategy=None),
        _bid("B1", "CT-1", "up", strategy=STRATEGY) + _bid("B2", "CT-1", "down", strategy="explicitInstruction"), caplog,
    )
    assert ras == [] and bids == []
    messages = _messages(caplog)
    assert len(messages) == 1 and "different gLSKStrategy" in messages[0]


def test_an_ra_and_a_bid_with_different_strategies_ignore_the_ra(tmp_path, caplog):
    ras, _ = _parse(tmp_path, _ct_ra(), _bid("B1", "CT-1", "up", strategy="proportionalForGenerator"), caplog)
    assert ras == [] and len(_messages(caplog)) == 1


def test_an_ra_without_a_bidding_zone_is_ignored(tmp_path, caplog):
    ras, _ = _parse(tmp_path, _ct_ra(zone=None), _bid("B", "CT-1", "up"), caplog)
    assert ras == [] and "no bidding zone" in _messages(caplog)[0]


def test_the_fixture_countertrade_ra_is_usable_with_the_default_strategy(tmp_path, caplog):
    """The legacy sample's countertrade RA has powerShiftKey and method (old version) and no gLSKStrategy: it
    is used with the default strategy; the old attributes are named in a warning and not read."""
    with zipfile.ZipFile(FIXTURE_NCP_GENERIC_ZIP) as archive:
        archive.extract("Belgovia_RA.xml", tmp_path)
        archive.extract("Belgovia_SIS.xml", tmp_path)
    with caplog.at_level(logging.INFO, logger=LOG):
        ras, bids = ct_units.parse_ct_remedial_actions(tmp_path / "Belgovia_RA.xml", tmp_path / "Belgovia_SIS.xml", "Belgovia", [TS])
    assert [r.mrid for r in ras] == ["30f6377d-5e35-4dd0-a53d-c1992043855e"] and ras[0].strategy == STRATEGY
    assert len(bids) == 3
    messages = _messages(caplog)
    assert any("not read" in m and "powerShiftKey" in m for m in messages) and any("assumed" in m for m in messages)
    assert not any("IGNORED" in m for m in messages)


# ---------------------------------------------------------------------------
# bids and penalty factor
# ---------------------------------------------------------------------------

def test_a_bid_without_volume_keeps_volume_zero_with_a_warning(tmp_path, caplog):
    ras, bids = _parse(tmp_path, _ct_ra(), _bid("B-UP", "CT-1", "up", volume=None) + _bid("B-DN", "CT-1", "down", 50), caplog)
    assert len(ras) == 1
    by_mrid = {b.mrid: b for b in bids}
    assert by_mrid["B-UP"].available_mw[TS] == 0.0 and by_mrid["B-DN"].available_mw[TS] == 50.0
    messages = [m for m in _messages(caplog) if "no volume" in m]
    assert len(messages) == 1 and "B-UP" in messages[0]


def test_a_bid_with_a_volume_only_at_another_time_has_no_volume_at_the_run_time(tmp_path, caplog):
    _, bids = _parse(tmp_path, _ct_ra(), _bid("B", "CT-1", "up", at="2024-02-22T18:30:00Z"), caplog)
    assert bids[0].available_mw[TS] == 0.0 and any("no volume" in m for m in _messages(caplog))


def test_an_ra_without_bids_is_kept_with_a_warning(tmp_path, caplog):
    ras, bids = _parse(tmp_path, _ct_ra(), "", caplog)
    assert len(ras) == 1 and bids == [] and any("no power bid" in m for m in _messages(caplog))


def test_a_missing_penalty_factor_is_one_with_a_log_line(tmp_path, caplog):
    ras, _ = _parse(tmp_path, _ct_ra(penalty=None), _bid("B", "CT-1", "up"), caplog)
    assert ras[0].penalty_factor == 1.0
    assert any("penaltyFactor" in m and "1.0" in m for m in _messages(caplog))


def test_a_given_penalty_factor_of_zero_is_kept(tmp_path):
    ras, _ = _parse(tmp_path, _ct_ra(penalty=0), _bid("B", "CT-1", "up"))
    assert ras[0].penalty_factor == 0.0


# ---------------------------------------------------------------------------
# the existing warning function and parse_rd_units keep their default behaviour
# ---------------------------------------------------------------------------

def test_the_ignored_ra_warning_keeps_reporting_countertrade_by_default_and_can_skip_it(tmp_path):
    ra, sis = _files(tmp_path, _ct_ra(), _bid("B", "CT-1", "up"))
    ra_graph, sis_graph = ncp_parser._load_graph(ra), ncp_parser._load_graph(sis)
    default = ncp_parser.warn_unsupported_power_remedial_actions(ra_graph, sis_graph, "T")
    skipped = ncp_parser.warn_unsupported_power_remedial_actions(ra_graph, sis_graph, "T", include_countertrade=False)
    assert [(r["class_name"], r["mrid"]) for r in default] == [("CountertradeRemedialAction", "CT-1")]
    assert skipped == []


def test_parse_rd_units_reports_countertrade_unless_told_not_to(tmp_path, caplog):
    ra, sis = _files(tmp_path, _ct_ra(), _bid("B", "CT-1", "up"))
    with caplog.at_level(logging.WARNING, logger=ncp_parser.log.name):
        ncp_parser.parse_rd_units(ra, sis, "T", [TS], {})
        assert sum("IGNORED" in r.getMessage() for r in caplog.records) == 1
        caplog.clear()
        ncp_parser.parse_rd_units(ra, sis, "T", [TS], {}, warn_countertrade=False)
    assert not any("IGNORED" in r.getMessage() for r in caplog.records)


# ---------------------------------------------------------------------------
# zones and units
# ---------------------------------------------------------------------------

CD_XML = _RA_HEADER + """
<nc:BiddingZone rdf:ID="_ZONE-1"><cim:IdentifiedObject.mRID>ZONE-1</cim:IdentifiedObject.mRID><cim:IdentifiedObject.name>BZ-One</cim:IdentifiedObject.name></nc:BiddingZone>
<nc:BiddingZone rdf:ID="_ZONE-2"><cim:IdentifiedObject.mRID>ZONE-2</cim:IdentifiedObject.mRID><cim:IdentifiedObject.name>BZ-Two</cim:IdentifiedObject.name></nc:BiddingZone>
<nc:SchedulingArea rdf:ID="_SA-1"><nc:SchedulingArea.BiddingZone rdf:resource="#_ZONE-1"/><nc:SchedulingArea.ControlArea rdf:resource="#_CA-1"/></nc:SchedulingArea>
<nc:SchedulingArea rdf:ID="_SA-1b"><nc:SchedulingArea.BiddingZone rdf:resource="#_ZONE-1"/><nc:SchedulingArea.ControlArea rdf:resource="#_CA-1b"/></nc:SchedulingArea>
<nc:SchedulingArea rdf:ID="_SA-2"><nc:SchedulingArea.BiddingZone rdf:resource="#_ZONE-2"/><nc:SchedulingArea.ControlArea rdf:resource="#_CA-2"/></nc:SchedulingArea>
""" + _RA_FOOTER


def _eq_row(row, area, unit):
    return (f'<cim:ControlAreaGeneratingUnit rdf:ID="_{row}">'
            f'<cim:ControlAreaGeneratingUnit.ControlArea rdf:resource="#_{area}"/>'
            f'<cim:ControlAreaGeneratingUnit.GeneratingUnit rdf:resource="#_{unit}"/></cim:ControlAreaGeneratingUnit>')


def test_the_bidding_zones_and_their_control_areas_are_read(tmp_path):
    path = tmp_path / "CD.xml"
    path.write_text(CD_XML, encoding=TEXT_ENCODING)
    zones = ct_units.parse_bidding_zones(path)
    assert set(zones) == {"ZONE-1", "ZONE-2"}
    assert zones["ZONE-1"].name == "BZ-One" and sorted(zones["ZONE-1"].control_area_mrids) == ["CA-1", "CA-1b"]
    assert zones["ZONE-2"].control_area_mrids == ["CA-2"]


def test_control_area_units_come_from_the_eq_files_that_have_them(tmp_path):
    (tmp_path / "20220615T2230Z__X_EQ_1.xml").write_text(
        _RA_HEADER + _eq_row("R1", "CA-1", "U1") + _eq_row("R2", "CA-1", "U2") + _eq_row("R3", "CA-2", "U3") + _RA_FOOTER,
        encoding=TEXT_ENCODING)
    (tmp_path / "20220615T2230Z__Y_EQ_1.xml").write_text(_RA_HEADER + _RA_FOOTER, encoding=TEXT_ENCODING)
    assert ct_units.read_control_area_units(tmp_path) == {"CA-1": {"U1", "U2"}, "CA-2": {"U3"}}


def _gen(gu, unit, prod=50.0, pmin=0.0, pmax=100.0, cls="SynchronousMachine", connected=True, main=True):
    return CtGenerator(gu_mrid=gu, unit_mrid=unit, name=gu, original_class=cls, prod=prod, pmin=pmin, pmax=pmax,
                       connected=connected, in_main_component=main)


def _ra_in(zone, mrid="CT-1"):
    return CtRa(mrid=mrid, name="CT", tso="T", zone_mrid=zone, available=True, kind=RAKind.PREVENTIVE,
                penalty_factor=1.0, strategy=STRATEGY)


ZONES = {"ZONE-1": CtZone("ZONE-1", "BZ-One", ["CA-1", "CA-1b"]), "ZONE-2": CtZone("ZONE-2", "BZ-Two", ["CA-2"])}
AREA_UNITS = {"CA-1": {"U1", "U2", "U3", "U4", "U5", "U6", "U7"}, "CA-1b": {"U8"}, "CA-2": {"U9"}}


def test_a_zone_keeps_only_the_usable_units_and_logs_what_was_dropped(caplog):
    generators = {g.gu_mrid: g for g in [
        _gen("G1", "U1"),                                   # kept
        _gen("G2", "U2", cls="EquivalentInjection"),        # not a unit
        _gen("G3", "U3", connected=False, main=False),      # not connected
        _gen("G4", "U4", main=False),                       # outside the main component
        _gen("G5", "U5", pmax=1.797693e308),                # unbounded limits
        _gen("G6", "U8"),                                   # second control area of the zone, kept
        _gen("G7", ""),                                     # no unit id
        _gen("G8", "U99"),                                  # in no control area
        _gen("G9", "U9"),                                   # other zone
    ]}
    with caplog.at_level(logging.INFO, logger=LOG):
        kept, units_by_zone = ct_units.resolve_zone_units([_ra_in("ZONE-1")], ZONES, AREA_UNITS, generators)
    assert [ra.mrid for ra in kept] == ["CT-1"] and kept[0].zone_name == "BZ-One"
    assert [u.gu_mrid for u in units_by_zone["ZONE-1"]] == ["G1", "G6"]
    messages = _messages(caplog, logging.INFO)
    zone_line = next(m for m in messages if "countertrade zone ZONE-1" in m)
    for reason in ("1 not a unit class", "1 not connected", "1 outside the main component", "1 limits unbounded"):
        assert reason in zone_line
    unassigned = next(m for m in messages if "dropped from every zone" in m)
    assert "1 without a GeneratingUnit id" in unassigned and "G7" in unassigned and "1 in no control area" in unassigned and "G8" in unassigned


def test_the_unit_copies_the_original_set_point_and_limits():
    generators = {"G1": _gen("G1", "U1", prod=61.5, pmin=-20.0, pmax=140.0)}
    _, units_by_zone = ct_units.resolve_zone_units([_ra_in("ZONE-1")], ZONES, AREA_UNITS, generators)
    unit = units_by_zone["ZONE-1"][0]
    assert (unit.gu_mrid, unit.unit_mrid, unit.prod, unit.pmin, unit.pmax, unit.connected) == ("G1", "U1", 61.5, -20.0, 140.0, True)


def test_an_ra_with_a_zone_not_in_the_organisation_profile_is_dropped_with_a_warning(caplog):
    generators = {"G1": _gen("G1", "U1")}
    with caplog.at_level(logging.WARNING, logger=LOG):
        kept, _ = ct_units.resolve_zone_units([_ra_in("NO-SUCH-ZONE"), _ra_in("ZONE-1", "CT-2")], ZONES, AREA_UNITS, generators)
    assert [ra.mrid for ra in kept] == ["CT-2"]
    messages = _messages(caplog)
    assert len(messages) == 1 and "CT-1" in messages[0] and "NO-SUCH-ZONE" in messages[0] and "not in the Organisation profile" in messages[0]


def test_an_ra_whose_zone_has_no_usable_unit_is_dropped_with_a_warning(caplog):
    generators = {"G9": _gen("G9", "U9", cls="ExternalNetworkInjection"), "G1": _gen("G1", "U1")}
    with caplog.at_level(logging.WARNING, logger=LOG):
        kept, units_by_zone = ct_units.resolve_zone_units([_ra_in("ZONE-2")], ZONES, AREA_UNITS, generators)
    assert kept == [] and units_by_zone["ZONE-2"] == []
    messages = _messages(caplog)
    assert len(messages) == 1 and "CT-1" in messages[0] and "no generating unit" in messages[0]


def test_an_empty_direction_is_logged_only_for_a_direction_with_a_bid(caplog):
    from data_model import PowerBid
    generators = {"G1": _gen("G1", "U1", prod=100, pmin=0, pmax=100)}   # at Pmax: no room up, room down 100
    kept, units_by_zone = ct_units.resolve_zone_units([_ra_in("ZONE-1")], ZONES, AREA_UNITS, generators)
    up_bid = PowerBid("B", "CT-1", BidDirection.UP, {TS: 10.0}, 1.0, 0.0, 0.0, None, None, None, None)
    with caplog.at_level(logging.WARNING, logger="pre_milp.ct_weights"):
        weights = ct_units.resolve_ct_weights(kept, units_by_zone, [up_bid])
    assert weights[("CT-1", BidDirection.UP)].pf == {} and weights[("CT-1", BidDirection.DOWN)].pf == {"G1": 1.0}
    assert len([r for r in caplog.records if r.levelno == logging.WARNING]) == 1
    caplog.clear()
    with caplog.at_level(logging.WARNING, logger="pre_milp.ct_weights"):
        ct_units.resolve_ct_weights(kept, units_by_zone, [])
    assert caplog.records == []


def test_several_ras_of_one_zone_share_the_units_and_get_their_own_weights():
    generators = {"G1": _gen("G1", "U1", prod=50, pmin=0, pmax=100), "G6": _gen("G6", "U8", prod=20, pmin=0, pmax=100)}
    ras = [_ra_in("ZONE-1", "CT-1"), _ra_in("ZONE-1", "CT-2")]
    kept, units_by_zone = ct_units.resolve_zone_units(ras, ZONES, AREA_UNITS, generators)
    weights = ct_units.resolve_ct_weights(kept, units_by_zone)
    assert set(weights) == {("CT-1", BidDirection.UP), ("CT-1", BidDirection.DOWN), ("CT-2", BidDirection.UP), ("CT-2", BidDirection.DOWN)}
    assert weights[("CT-1", BidDirection.UP)].pf == pytest.approx({"G1": 50 / 130, "G6": 80 / 130})
    assert weights[("CT-2", BidDirection.UP)].pf == weights[("CT-1", BidDirection.UP)].pf
    assert weights[("CT-1", BidDirection.DOWN)].pf == pytest.approx({"G1": 50 / 70, "G6": 20 / 70})
