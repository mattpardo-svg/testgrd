"""tests/test_rao_review_warnings.py - data that the parsers do not read is reported with a counting
warning (shift keys of countertrade, assessed-element switches and links, contingencies without
normalMustStudy, exclusive dependencies, disabled grid state alterations, old actions of a standard
redispatch RA), the reason of the countertrade "IGNORED" line, and the bid lookup by rdf:ID.
Small hand-written files; no fixture zip."""

import logging

import pytest

from pre_milp import ct_units, ncp_parser
from text_encoding import TEXT_ENCODING

HEADER = ('<?xml version="1.0"?><rdf:RDF xmlns:rdf="http://www.w3.org/1999/02/22-rdf-syntax-ns#" '
          'xmlns:cim="https://cim.ucaiug.io/ns#" xmlns:nc="https://cim4.eu/ns/nc#">')
FOOTER = "</rdf:RDF>"
NC_NS = "https://cim4.eu/ns/nc#"


def _file(tmp_path, name, body):
    path = tmp_path / name
    path.write_text(HEADER + body + FOOTER, encoding=TEXT_ENCODING)
    return path


def _warnings(caplog, *needles):
    return [r.getMessage() for r in caplog.records
            if r.levelno >= logging.WARNING and all(n in r.getMessage() for n in needles)]


def _ct_ra(mrid):
    return (f'<nc:CountertradeRemedialAction rdf:ID="_{mrid}"><cim:IdentifiedObject.mRID>{mrid}</cim:IdentifiedObject.mRID>'
            f'<nc:PowerRemedialAction.BiddingZone rdf:resource="#_ZONE"/><nc:RemedialAction.normalAvailable>true</nc:RemedialAction.normalAvailable>'
            f'<nc:RemedialAction.penaltyFactor>1.0</nc:RemedialAction.penaltyFactor></nc:CountertradeRemedialAction>')


def _bid(rdf_id, mrid, ra, direction="up"):
    return (f'<nc:PowerBidSchedule rdf:ID="_{rdf_id}"><cim:IdentifiedObject.mRID>{mrid}</cim:IdentifiedObject.mRID>'
            f'<nc:PowerBidSchedule.PowerRemedialAction rdf:resource="#_{ra}"/>'
            f'<nc:PowerBidSchedule.direction rdf:resource="{NC_NS}BidDirectionKind.{direction}"/>'
            f'<nc:BaseTimeSeries.interpolationKind rdf:resource="{NC_NS}InterpolationKind.next"/></nc:PowerBidSchedule>')


def _point(tp, schedule, at_time, p, price):
    return (f'<nc:PowerBidScheduleTimePoint rdf:ID="_{tp}"><nc:PowerBidScheduleTimePoint.atTime>{at_time}</nc:PowerBidScheduleTimePoint.atTime>'
            f'<nc:PowerBidScheduleTimePoint.PowerBidSchedule rdf:resource="#_{schedule}"/>'
            f'<nc:PowerBidScheduleTimePoint.p>{p}</nc:PowerBidScheduleTimePoint.p>'
            f'<nc:PowerBidScheduleTimePoint.price>{price}</nc:PowerBidScheduleTimePoint.price></nc:PowerBidScheduleTimePoint>')


# --- shift keys on countertrade ---------------------------------------------------------------

def test_rao_shift_keys_of_countertrade_are_counted_in_one_warning(tmp_path, caplog):
    ra = _file(tmp_path, "X_RA.xml", _ct_ra("CT1") + _ct_ra("CT2") + (
        f'<nc:PowerShiftKeyStrategy rdf:ID="_ST1"><nc:PowerShiftKeyStrategy.PowerRemedialAction rdf:resource="#_CT1"/></nc:PowerShiftKeyStrategy>'
        f'<nc:PowerShiftKeyStrategy rdf:ID="_ST-RD"><nc:PowerShiftKeyStrategy.PowerRemedialAction rdf:resource="#_RD1"/></nc:PowerShiftKeyStrategy>'))
    sis = _file(tmp_path, "X_SIS.xml", _bid("B1", "B1", "CT1") + _bid("B-RD", "B-RD", "RD1") + (
        '<nc:PowerShiftKeyDistribution rdf:ID="_D1"><nc:PowerShiftKeyDistribution.PowerBidSchedule rdf:resource="#_B1"/></nc:PowerShiftKeyDistribution>'
        '<nc:PowerShiftKeyDistribution rdf:ID="_D2"><nc:PowerShiftKeyDistribution.PowerShiftKeyStrategy rdf:resource="#_ST1"/></nc:PowerShiftKeyDistribution>'
        '<nc:PowerShiftKeyDistribution rdf:ID="_D-RD"><nc:PowerShiftKeyDistribution.PowerBidSchedule rdf:resource="#_B-RD"/></nc:PowerShiftKeyDistribution>'))
    with caplog.at_level(logging.WARNING, logger=ct_units.log.name):
        ct_units.parse_ct_remedial_actions(ra, sis, "X", ["1730Z"])
    lines = _warnings(caplog, "PowerShiftKeyStrategy", "countertrade")
    assert len(lines) == 1
    assert "1 PowerShiftKeyStrategy element(s)" in lines[0] and "2 PowerShiftKeyDistribution element(s)" in lines[0]


def test_rao_no_shift_key_warning_for_countertrade_without_keys(tmp_path, caplog):
    ra = _file(tmp_path, "X_RA.xml", _ct_ra("CT1"))
    sis = _file(tmp_path, "X_SIS.xml", _bid("B1", "B1", "CT1"))
    with caplog.at_level(logging.WARNING, logger=ct_units.log.name):
        ct_units.parse_ct_remedial_actions(ra, sis, "X", ["1730Z"])
    assert _warnings(caplog, "PowerShiftKey") == []


# --- bid whose mRID differs from its rdf:ID ----------------------------------------------------

def test_rao_a_bid_with_an_mrid_different_from_its_rdf_id_keeps_volume_and_price(tmp_path):
    sis = _file(tmp_path, "X_SIS.xml", _bid("S-ID", "S-MRID", "RA1") + _point("T1", "S-ID", "2024-02-22T17:30:00Z", 100, 7))
    bids = ncp_parser.parse_power_bids(ncp_parser._load_graph(sis), {"RA1"}, "X", ["1730Z"])
    assert len(bids) == 1
    assert bids[0].mrid == "S-MRID"
    assert bids[0].available_mw == {"1730Z": 100.0}
    assert bids[0].price_eur_mw == 7.0


def test_rao_the_bid_route_finds_a_schedule_whose_mrid_differs_from_its_rdf_id(tmp_path):
    sis = _file(tmp_path, "X_SIS.xml", _bid("S-ID", "S-MRID", "RA1") + (
        '<nc:PowerShiftKeyDistribution rdf:ID="_D1"><nc:PowerShiftKeyDistribution.PowerBidSchedule rdf:resource="#_S-ID"/>'
        '<nc:PowerShiftKeyDistribution.PowerShiftKeySchedule rdf:resource="#_K1"/></nc:PowerShiftKeyDistribution>'))
    by_bid, _ = ncp_parser.read_key_routes(ncp_parser._load_graph(sis), None, {"RA1"})
    assert by_bid["RA1"] == {"K1"}


# --- contingencies, dependencies, alterations, old actions ------------------------------------------

def test_rao_contingencies_without_must_study_are_counted(tmp_path, caplog):
    co = _file(tmp_path, "X_CO.xml", (
        '<nc:OrdinaryContingency rdf:ID="_C1"><cim:IdentifiedObject.mRID>C1</cim:IdentifiedObject.mRID></nc:OrdinaryContingency>'
        '<nc:OrdinaryContingency rdf:ID="_C2"><cim:IdentifiedObject.mRID>C2</cim:IdentifiedObject.mRID>'
        '<nc:Contingency.normalMustStudy>true</nc:Contingency.normalMustStudy></nc:OrdinaryContingency>'
        '<nc:OrdinaryContingency rdf:ID="_C3"><cim:IdentifiedObject.mRID>C3</cim:IdentifiedObject.mRID></nc:OrdinaryContingency>'))
    with caplog.at_level(logging.WARNING, logger=ncp_parser.log.name):
        result = ncp_parser.parse_contingencies(co, "X", ["1730Z"], {})
    assert [c.mrid for c in result if c.must_study["1730Z"]] == ["C2"]
    lines = _warnings(caplog, "normalMustStudy")
    assert len(lines) == 1 and "2 contingenc" in lines[0]


def test_rao_exclusive_dependencies_are_counted(tmp_path, caplog):
    def dependency(name, kind):
        return (f'<nc:RemedialActionDependency rdf:ID="_{name}"><nc:RemedialActionDependency.kind rdf:resource="{NC_NS}RemedialActionDependencyKind.{kind}"/>'
                f'<nc:RemedialActionDependency.DependingRemedialActionGroup rdf:resource="#_G1"/>'
                f'<nc:RemedialActionDependency.RemedialAction rdf:resource="#_RA1"/></nc:RemedialActionDependency>')
    ra = _file(tmp_path, "X_RA.xml", dependency("D1", "exclusive") + dependency("D2", "exclusive") + dependency("D3", "balanced"))
    with caplog.at_level(logging.WARNING, logger=ncp_parser.log.name):
        assert ncp_parser.parse_ra_groups(ra, None, "X", "1730Z") == {}
    lines = _warnings(caplog, "RemedialActionDependency", "not read")
    assert len(lines) == 1 and "exclusive: 2" in lines[0] and "balanced" not in lines[0]


def test_rao_disabled_grid_state_alterations_are_counted(tmp_path, caplog):
    def point(name, enabled):
        return (f'<nc:GridStateAlterationTimePoint rdf:ID="_{name}"><nc:GridStateAlterationTimePoint.enabled>{enabled}'
                f'</nc:GridStateAlterationTimePoint.enabled></nc:GridStateAlterationTimePoint>')
    sis = _file(tmp_path, "X_SIS.xml", point("P1", "false") + point("P2", "true") + point("P3", "false"))
    with caplog.at_level(logging.WARNING, logger=ncp_parser.log.name):
        ncp_parser.warn_unsupported_sis_content(sis, "X")
    lines = _warnings(caplog, "GridStateAlterationTimePoint")
    assert len(lines) == 1 and "2 GridStateAlterationTimePoint" in lines[0]


def test_rao_a_standard_redispatch_ra_with_old_actions_is_warned_about(tmp_path, caplog):
    ra = _file(tmp_path, "X_RA.xml", (
        '<nc:RedispatchRemedialAction rdf:ID="_RD1"><cim:IdentifiedObject.mRID>RD1</cim:IdentifiedObject.mRID></nc:RedispatchRemedialAction>'
        '<nc:RotatingMachineAction rdf:ID="_A1"><nc:GridStateAlteration.GridStateAlterationRemedialAction rdf:resource="#_RD1"/>'
        '<nc:RotatingMachineAction.RotatingMachine rdf:resource="#_G1"/></nc:RotatingMachineAction>'))
    with caplog.at_level(logging.WARNING, logger=ncp_parser.log.name):
        ncp_parser.parse_rd_units(ra, None, "X", ["1730Z"], {})
    lines = _warnings(caplog, "also have RotatingMachineAction")
    assert len(lines) == 1 and "1 RedispatchRemedialAction" in lines[0] and "RD1" in lines[0]


# --- the reason of the IGNORED lines ----------------------------------------------------------

def test_rao_an_ignored_countertrade_ra_names_ra_types_as_the_reason(tmp_path, caplog):
    ra = _file(tmp_path, "X_RA.xml", _ct_ra("CT1") + (
        '<nc:RedispatchRemedialAction rdf:ID="_RD1"><cim:IdentifiedObject.mRID>RD1</cim:IdentifiedObject.mRID></nc:RedispatchRemedialAction>'))
    with caplog.at_level(logging.WARNING, logger=ncp_parser.log.name):
        ncp_parser.parse_rd_units(ra, None, "X", ["1730Z"], {})
    ct = _warnings(caplog, "IGNORED", "nc:CountertradeRemedialAction CT1")
    rd = _warnings(caplog, "IGNORED", "nc:RedispatchRemedialAction RD1")
    assert len(ct) == 1 and "countertrade is not in ra_types" in ct[0] and "shift key" not in ct[0]
    assert len(rd) == 1 and "no generating unit in a shift key" in rd[0]


# --- assessed-element switches and links ----------------------------------------------------------

def _assessed_element(name, switches):
    body = "".join(f"<nc:AssessedElement.{key}>{value}</nc:AssessedElement.{key}>" for key, value in switches.items())
    return (f'<nc:AssessedElement rdf:ID="_{name}"><cim:IdentifiedObject.mRID>{name}</cim:IdentifiedObject.mRID>'
            f'<nc:AssessedElement.ConductingEquipment rdf:resource="#_BR-{name}"/>{body}</nc:AssessedElement>')


def _link(cls, name, kind, enabled="true"):
    return (f'<nc:{cls} rdf:ID="_{name}"><nc:{cls}.combinationConstraintKind rdf:resource="{NC_NS}ElementCombinationConstraintKind.{kind}"/>'
            f'<nc:{cls}.normalEnabled>{enabled}</nc:{cls}.normalEnabled></nc:{cls}>')


@pytest.fixture()
def ae_file(tmp_path):
    return _file(tmp_path, "X_AE.xml", (
        _assessed_element("A1", {"normalEnabled": "false", "inBaseCase": "false"})
        + _assessed_element("A2", {"normalEnabled": "false", "inBaseCase": "true", "isCombinableWithContingency": "false"})
        + _assessed_element("A3", {"normalEnabled": "true", "isCombinableWithRemedialAction": "false"})
        + _link("AssessedElementWithContingency", "L1", "excluded")
        + _link("AssessedElementWithContingency", "L2", "included", "false")
        + _link("AssessedElementWithContingency", "L3", "included")
        + _link("AssessedElementWithRemedialAction", "L4", "included")))


def test_rao_the_switches_that_are_not_read_are_counted_one_warning_per_kind(ae_file, caplog):
    """normalEnabled, inBaseCase and the links to contingencies are applied since round 2 (test_rao_ae_switches.py);
    isCombinableWithContingency=false is applied since round 5; isCombinableWithRemedialAction=false and the links to
    remedial actions are still only warned about (OPEN-33)."""
    with caplog.at_level(logging.WARNING, logger=ncp_parser.log.name):
        ncp_parser.parse_assessed_elements(ae_file, None, "X", ["1730Z"], {})
    assert _warnings(caplog, "AssessedElement(s) with normalEnabled=false") == []
    assert _warnings(caplog, "AssessedElement(s) with inBaseCase=false") == []
    assert _warnings(caplog, "AssessedElementWithContingency link(s)", "not read") == []
    assert _warnings(caplog, "AssessedElement(s) with isCombinableWithContingency=false") == []
    assert len(_warnings(caplog, "1 AssessedElement(s) with isCombinableWithRemedialAction=false")) == 1
    assert len(_warnings(caplog, "1 AssessedElementWithRemedialAction link(s)")) == 1
    assert len(_warnings(caplog, "2 assessed element(s) switched off or restricted by NCP switches")) == 1


def test_rao_assessed_element_links_are_not_reported_as_spec_violations(ae_file, caplog):
    with caplog.at_level(logging.WARNING, logger=ncp_parser.log.name):
        result = ncp_parser.parse_assessed_elements(ae_file, None, "X", ["1730Z"], {})
    assert _warnings(caplog, "spec violation") == []
    assert sorted(ae.mrid for ae in result) == ["A1", "A2", "A3"]     # the links are not elements


def test_rao_an_assessed_element_without_any_association_is_still_a_spec_violation(tmp_path, caplog):
    ae = _file(tmp_path, "X_AE.xml", '<nc:AssessedElement rdf:ID="_A1"><cim:IdentifiedObject.mRID>A1</cim:IdentifiedObject.mRID></nc:AssessedElement>')
    with caplog.at_level(logging.WARNING, logger=ncp_parser.log.name):
        assert ncp_parser.parse_assessed_elements(ae, None, "X", ["1730Z"], {}) == []
    assert len(_warnings(caplog, "spec violation")) == 1


def test_rao_enabled_assessed_elements_give_no_switch_warning(tmp_path, caplog):
    ae = _file(tmp_path, "X_AE.xml", _assessed_element("A1", {"normalEnabled": "true", "inBaseCase": "true"}))
    with caplog.at_level(logging.WARNING, logger=ncp_parser.log.name):
        ncp_parser.parse_assessed_elements(ae, None, "X", ["1730Z"], {})
    assert _warnings(caplog, "not read") == []
