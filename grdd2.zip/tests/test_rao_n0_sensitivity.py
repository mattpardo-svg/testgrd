"""tests/test_rao_n0_sensitivity.py - unit tests for n0_sensitivity.py.
"""

import csv
import sys
import types
import pandas as pd
import pytest

from pathlib import Path
from data_model import AEType, AssessedElement, PST, RAKind, RDUnit
from unittest.mock import MagicMock
from pre_milp import n0_sensitivity as sens
from pre_milp.n0_sensitivity import (
    _get_loading_filtered_branch_sides,
    _get_preventive_pst_ids,
    compute_sensitivity_pst_n0,
    write_sensitivity_csv,
)
from text_encoding import TEXT_ENCODING  # noqa: E402

# ---------------------------------------------------------------------------
# pypowsybl stand-ins: sa.add_factor_matrix(...) / sa.run(network) /
# result.get_sensitivity_matrix(matrix_id)
# ---------------------------------------------------------------------------

class DummyResult:
    def __init__(self, matrices: dict):
        self._matrices = matrices  # {matrix_id: DataFrame}

    def get_sensitivity_matrix(self, matrix_id):
        return self._matrices.get(matrix_id)


class DummyAnalysis:
    def __init__(self, matrices: dict):
        self._matrices = matrices
        self.calls = []  # list of kwargs dicts, one per add_factor_matrix call

    def add_factor_matrix(self, **kwargs):
        self.calls.append(kwargs)

    def run(self, network, parameters=None):
        return DummyResult(self._matrices)


class DummyContingencyContextType:
    NONE = "NONE"


class DummySensitivityFunctionType:
    BRANCH_CURRENT_1 = "BRANCH_CURRENT_1"
    BRANCH_CURRENT_2 = "BRANCH_CURRENT_2"


class DummySensitivityVariableType:
    TRANSFORMER_PHASE = "TRANSFORMER_PHASE"


class DummySensitivityModule:
    def __init__(self, matrices: dict):
        self.matrices = matrices
        self.ContingencyContextType = DummyContingencyContextType
        self.SensitivityFunctionType = DummySensitivityFunctionType
        self.SensitivityVariableType = DummySensitivityVariableType

    def create_ac_analysis(self):
        return DummyAnalysis(self.matrices)


class DummyPypowsyblModule:
    def __init__(self, matrices: dict):
        self.sensitivity = DummySensitivityModule(matrices)
        self.loadflow = types.SimpleNamespace(Parameters=lambda **kwargs: types.SimpleNamespace(**kwargs))


def _make_ae_n0(mrid, branch_mrid, branch_side=1, patl_ka=1.0, ae_type=AEType.SECURED):
    return AssessedElement(
        mrid=mrid, name="a", tso="TSO", ae_type=ae_type, branch_mrid=branch_mrid,
        secured_for_region=None, scanned_for_region=None, exclusion_reason=None,
        patl_ka={"1030Z": patl_ka}, branch_side=branch_side,
    )


def _make_pst_n0(mrid, available=True, kind=RAKind.PREVENTIVE):
    return PST(
        mrid=mrid, name="pst", tso="TSO", available=available, kind=kind,
        penalty_factor=1.0, low_step=-10, high_step=10, r0=0,
        operating_tap_min=-10, operating_tap_max=10, group_id=None,
    )


# ---------------------------------------------------------------------------
# _get_loading_filtered_branch_sides
# ---------------------------------------------------------------------------

class TestGetMonitoredBranchSides:
    def test_includes_both_secured_and_scanned(self):
        """SECURED and SCANNED branches are both included: the loading pre-filter does not
        depend on the AE type (the type picks the limit and the constraint later)."""
        ae_flat_list = [
            _make_ae_n0("1", "b1", branch_side=1),
            _make_ae_n0("2", "b2", branch_side=2, ae_type=AEType.SCANNED),
        ]
        result = _get_loading_filtered_branch_sides(ae_flat_list, "1030Z")
        assert result == {"b1": 1, "b2": 2}

    def test_returns_dict_not_list(self):
        # the return type is {branch: side}, not a list
        ae_flat_list = [_make_ae_n0("1", "b1", branch_side=2)]
        result = _get_loading_filtered_branch_sides(ae_flat_list, "1030Z")
        assert isinstance(result, dict)
        assert result["b1"] == 2

    def test_excludes_ae_with_no_branch_mrid(self):
        ae = _make_ae_n0("1", None, branch_side=1)
        result = _get_loading_filtered_branch_sides([ae], "1030Z")
        assert result == {}

    def test_threshold_filtering_uses_correct_side(self):
        # branch is on side 2; lf_initial has different currents per side —
        # the threshold check must read side 2's current, not side 1's.
        ae = _make_ae_n0("1", "b1", branch_side=2, patl_ka=1.0)  # 1000 A PATL
        lf_initial = {"b1": {1: 999.0, 2: 10.0}}  # side 1 would pass threshold, side 2 would not
        result = _get_loading_filtered_branch_sides(
            [ae], "1030Z", lf_initial=lf_initial, sensitivity_threshold_pct=50.0,
        )
        # side 2 current (10A) / patl (1000A) = 1% loading, below 50% threshold -> excluded
        assert result == {}

    def test_missing_side_data_conservatively_included(self):
        ae = _make_ae_n0("1", "b1", branch_side=1, patl_ka=1.0)
        lf_initial = {"b1": {2: 500.0}}  # side 1 missing, only side 2 present
        result = _get_loading_filtered_branch_sides(
            [ae], "1030Z", lf_initial=lf_initial, sensitivity_threshold_pct=10.0,
        )
        # select_by_side falls back to side 2 rather than dropping the branch
        assert "b1" in result

    def test_scanned_branch_threshold_uses_effective_limit(self):
        """A SCANNED branch above its PATL is filtered against the effective limit
        max(patl, initial), not the PATL (the numeric distinction is tested below)."""
        ae = _make_ae_n0("1", "SCANNED1", branch_side=1, patl_ka=1.0, ae_type=AEType.SCANNED)
        lf_initial = {"SCANNED1": {1: 1200.0}}  # already above 1000 A PATL
        result = _get_loading_filtered_branch_sides(
            [ae], "1030Z", lf_initial=lf_initial, sensitivity_threshold_pct=99.0,
        )
        # effective_limit = max(1000, 1200) = 1200 -> 100%, clears a 99% threshold; the PATL
        # would give 120% and clear it too, so only inclusion is asserted here
        assert "SCANNED1" in result


# ---------------------------------------------------------------------------
# _get_preventive_pst_ids
# ---------------------------------------------------------------------------

class TestGetPreventivePstIds:
    def test_filters_available_preventive(self):
        pst_list = [
            _make_pst_n0("p1", available=True, kind=RAKind.PREVENTIVE),
            _make_pst_n0("p2", available=False, kind=RAKind.PREVENTIVE),
            _make_pst_n0("p3", available=True, kind=RAKind.CURATIVE),
        ]
        result = _get_preventive_pst_ids(pst_list)
        assert result == ["p1"]


# ---------------------------------------------------------------------------
# compute_sensitivity_pst_n0 — side-aware dual-matrix computation
# ---------------------------------------------------------------------------

def test_compute_sensitivity_pst_n0_single_side(monkeypatch, tmp_path):
    """All branches on side 1 — only the side-1 matrix should be requested."""
    matrix_side1 = pd.DataFrame(
        [[1.2, -1.2], [0.5, -0.5]],
        index=["p1", "p2"],   # index = variables (PST mRIDs)
        columns=["b1", "b2"],  # columns = functions (branch mRIDs)
    )
    fake_pp = DummyPypowsyblModule({"psdf_n0_side1": matrix_side1})
    monkeypatch.setitem(sys.modules, "pypowsybl", fake_pp)

    ae_flat_list = [_make_ae_n0("1", "b1", branch_side=1), _make_ae_n0("2", "b2", branch_side=1)]
    pst_list = [_make_pst_n0("p1"), _make_pst_n0("p2")]

    result = compute_sensitivity_pst_n0(
        network=None, pst_list=pst_list, ae_flat_list=ae_flat_list,
        timestamp="1030Z", output_path=tmp_path / "sensitivity_pst_n0.csv",
    )

    # matrix_side1 is index=["p1","p2"], columns=["b1","b2"]:
    #   loc["p1","b1"]=1.2   loc["p1","b2"]=-1.2
    #   loc["p2","b1"]=0.5   loc["p2","b2"]=-0.5
    # result[(branch, pst)] = matrix.loc[pst, branch]
    assert result[("b1", "p1")] == 1.2
    assert result[("b1", "p2")] == 0.5
    assert result[("b2", "p1")] == -1.2
    assert result[("b2", "p2")] == -0.5


def test_compute_sensitivity_pst_n0_mixed_sides_issues_two_calls(monkeypatch, tmp_path):
    """One branch on side 1, one on side 2: exactly two add_factor_matrix calls,
    BRANCH_CURRENT_1 and BRANCH_CURRENT_2, each with only its own branch."""
    matrix_side1 = pd.DataFrame([[1.2]], index=["p1"], columns=["b1"])
    matrix_side2 = pd.DataFrame([[7.7]], index=["p1"], columns=["b2"])
    fake_pp = DummyPypowsyblModule({
        "psdf_n0_side1": matrix_side1,
        "psdf_n0_side2": matrix_side2,
    })
    monkeypatch.setitem(sys.modules, "pypowsybl", fake_pp)

    ae_flat_list = [
        _make_ae_n0("1", "b1", branch_side=1),
        _make_ae_n0("2", "b2", branch_side=2),
    ]
    pst_list = [_make_pst_n0("p1")]

    dummy_analysis_holder = {}
    original_create_ac_analysis = fake_pp.sensitivity.create_ac_analysis
    def _capturing_create_ac_analysis():
        analysis = original_create_ac_analysis()
        dummy_analysis_holder["analysis"] = analysis
        return analysis
    fake_pp.sensitivity.create_ac_analysis = _capturing_create_ac_analysis

    result = compute_sensitivity_pst_n0(
        network=None, pst_list=pst_list, ae_flat_list=ae_flat_list, timestamp="1030Z",
    )

    calls = dummy_analysis_holder["analysis"].calls
    assert len(calls) == 2

    side1_call = next(c for c in calls if c["matrix_id"] == "psdf_n0_side1")
    side2_call = next(c for c in calls if c["matrix_id"] == "psdf_n0_side2")
    assert side1_call["functions_ids"] == ["b1"]
    assert side1_call["sensitivity_function_type"] == DummySensitivityFunctionType.BRANCH_CURRENT_1
    assert side2_call["functions_ids"] == ["b2"]
    assert side2_call["sensitivity_function_type"] == DummySensitivityFunctionType.BRANCH_CURRENT_2

    assert result[("b1", "p1")] == 1.2
    assert result[("b2", "p1")] == 7.7


def test_compute_sensitivity_pst_n0_raises_on_no_branches():
    with pytest.raises(ValueError):
        compute_sensitivity_pst_n0(
            network=None, pst_list=[_make_pst_n0("p1")], ae_flat_list=[], timestamp="1030Z",
        )


def test_compute_sensitivity_pst_n0_raises_on_no_psts(monkeypatch):
    fake_pp = DummyPypowsyblModule({})
    monkeypatch.setitem(sys.modules, "pypowsybl", fake_pp)
    ae_flat_list = [_make_ae_n0("1", "b1", branch_side=1)]
    with pytest.raises(ValueError):
        compute_sensitivity_pst_n0(
            network=None, pst_list=[], ae_flat_list=ae_flat_list, timestamp="1030Z",
        )


# ---------------------------------------------------------------------------
# write_sensitivity_csv
# ---------------------------------------------------------------------------

def test_write_sensitivity_csv(tmp_path):
    sensitivity_dict = {("b1", "p1"): 1.23, ("b2", "p2"): -0.45}
    output_path = tmp_path / "sensitivity_pst_n0.csv"
    write_sensitivity_csv(sensitivity_dict, output_path, "1030Z")
    assert output_path.exists()
    lines = output_path.read_text(encoding=TEXT_ENCODING).splitlines()
    assert len(lines) == 3
    assert lines[1] == "b1,p1,1.23,1030Z"
    assert lines[2] == "b2,p2,-0.45,1030Z"


# ---------------------------------------------------------------------------
# compute_sensitivity_rd_n0
# ---------------------------------------------------------------------------

class _FakeSensitivityAnalysis:
    """Records add_factor_matrix() calls and serves canned matrices on run()."""

    def __init__(self, matrices_by_id: dict[str, pd.DataFrame]):
        self._matrices_by_id = matrices_by_id
        self.calls = []

    def add_factor_matrix(self, **kwargs):
        self.calls.append(kwargs)

    def run(self, network, parameters=None):
        result = MagicMock()
        result.get_sensitivity_matrix.side_effect = lambda mid: self._matrices_by_id.get(mid)
        return result


@pytest.fixture(autouse=True)
def _restore_pypowsybl_modules():
    """_install_fake_pypowsybl writes sys.modules directly; without this restore the fake leaked into
    every later test module (they then saw a pypowsybl without loadflow.VoltageInitMode)."""
    names = ("pypowsybl", "pypowsybl.sensitivity")
    saved = {name: sys.modules.get(name) for name in names}
    yield
    for name, module in saved.items():
        if module is None:
            sys.modules.pop(name, None)
        else:
            sys.modules[name] = module


def _install_fake_pypowsybl(matrices_by_id: dict[str, pd.DataFrame]):
    """Install a fake `pypowsybl` (with `.sensitivity`) into sys.modules so
    `import pypowsybl as pp` in n0_sensitivity resolves to it."""
    fake_pp = types.ModuleType("pypowsybl")
    fake_sensitivity_mod = types.ModuleType("pypowsybl.sensitivity")

    fake_sensitivity_mod.ContingencyContextType = types.SimpleNamespace(NONE="NONE")
    fake_sensitivity_mod.SensitivityFunctionType = types.SimpleNamespace(
        BRANCH_CURRENT_1="BRANCH_CURRENT_1", BRANCH_CURRENT_2="BRANCH_CURRENT_2",
        TRANSFORMER_PHASE="TRANSFORMER_PHASE",
    )
    fake_sensitivity_mod.SensitivityVariableType = types.SimpleNamespace(
        INJECTION_ACTIVE_POWER="INJECTION_ACTIVE_POWER", TRANSFORMER_PHASE="TRANSFORMER_PHASE",
    )

    analysis_holder = {}

    def _create_ac_analysis():
        sa = _FakeSensitivityAnalysis(matrices_by_id)
        analysis_holder["sa"] = sa
        return sa

    fake_sensitivity_mod.create_ac_analysis = _create_ac_analysis
    fake_pp.sensitivity = fake_sensitivity_mod
    fake_pp.loadflow = types.SimpleNamespace(Parameters=lambda **kwargs: types.SimpleNamespace(**kwargs))

    sys.modules["pypowsybl"] = fake_pp
    sys.modules["pypowsybl.sensitivity"] = fake_sensitivity_mod
    return analysis_holder


def _make_ae_rd(branch_mrid: str, side: int, mrid: str = None) -> AssessedElement:
    return AssessedElement(
        mrid=mrid or f"AE_{branch_mrid}",
        name=f"AE {branch_mrid}",
        tso="Espheim",
        ae_type=AEType.SECURED,
        branch_mrid=branch_mrid,
        secured_for_region=None,
        scanned_for_region=None,
        exclusion_reason=None,
        patl_ka={},
        branch_side=side,
    )


def _make_rd_unit_rd(mrid: str, gu_mrid: str, available: bool = True, kind=RAKind.PREVENTIVE) -> RDUnit:
    return RDUnit(
        mrid=mrid, name=mrid, tso="Espheim", gu_mrid=gu_mrid, gu_name=gu_mrid,
        available=available, kind=kind, initial_p=0.0, max_p=100.0, min_p=0.0,
        raise_ramp_rate=None, lower_ramp_rate=None,
    )


# ---------------------------------------------------------------------------
# _get_preventive_rd_gu_ids
# ---------------------------------------------------------------------------

def test_get_preventive_rd_gu_ids_filters_and_dedupes():
    """Given RD units with mixed availability/kind and a duplicate gu_mrid
    across two RAs, When resolving preventive gu ids, Then only available
    preventive units are kept and gu_mrids are de-duplicated and sorted."""
    from pre_milp import n0_sensitivity as sens

    rd_list = [
        _make_rd_unit_rd("RA1", "GU_A", available=True, kind=RAKind.PREVENTIVE),
        _make_rd_unit_rd("RA2", "GU_A", available=True, kind=RAKind.PREVENTIVE),  # dup gu_mrid
        _make_rd_unit_rd("RA3", "GU_B", available=True, kind=RAKind.PREVENTIVE),
        _make_rd_unit_rd("RA4", "GU_C", available=False, kind=RAKind.PREVENTIVE),  # unavailable
        _make_rd_unit_rd("RA5", "GU_D", available=True, kind=RAKind.CURATIVE),     # curative
    ]

    result = sens._get_preventive_rd_gu_ids(rd_list)

    assert result == ["GU_A", "GU_B"]


def test_get_preventive_rd_gu_ids_empty_when_none_available():
    """Given no available preventive RD units, When resolving preventive gu
    ids, Then an empty list is returned (caller raises, not this helper)."""
    from pre_milp import n0_sensitivity as sens

    rd_list = [_make_rd_unit_rd("RA1", "GU_A", available=False)]

    assert sens._get_preventive_rd_gu_ids(rd_list) == []


# ---------------------------------------------------------------------------
# compute_sensitivity_rd_n0
# ---------------------------------------------------------------------------

def test_compute_sensitivity_rd_n0_side_routing_and_shape():
    """Given branches on both side 1 and side 2 and two preventive RD units,
    When computing RD sensitivity, Then each branch is routed to the
    correct BRANCH_CURRENT_1/2 call, INJECTION_ACTIVE_POWER is used as the
    variable type, and the returned dict has the (branch_mrid, gu_mrid)
    shape with values in A/MW pulled from the correct side's matrix."""
    from pre_milp import n0_sensitivity as sens

    ae_list = [
        _make_ae_rd("BRANCH_S1", side=1),
        _make_ae_rd("BRANCH_S2", side=2),
    ]
    rd_list = [
        _make_rd_unit_rd("RA1", "GU_A"),
        _make_rd_unit_rd("RA2", "GU_B"),
    ]

    side1_matrix = pd.DataFrame(
        {"BRANCH_S1": [1.5, 2.5]}, index=["GU_A", "GU_B"],
    )
    side2_matrix = pd.DataFrame(
        {"BRANCH_S2": [3.5, 4.5]}, index=["GU_A", "GU_B"],
    )

    analysis_holder = _install_fake_pypowsybl({
        "ptdf_rd_n0_side1": side1_matrix,
        "ptdf_rd_n0_side2": side2_matrix,
    })

    result = sens.compute_sensitivity_rd_n0(
        network=MagicMock(),
        rd_list=rd_list,
        ae_flat_list=ae_list,
        timestamp="1030Z",
    )

    assert result[("BRANCH_S1", "GU_A")] == pytest.approx(1.5)
    assert result[("BRANCH_S1", "GU_B")] == pytest.approx(2.5)
    assert result[("BRANCH_S2", "GU_A")] == pytest.approx(3.5)
    assert result[("BRANCH_S2", "GU_B")] == pytest.approx(4.5)

    sa = analysis_holder["sa"]
    assert len(sa.calls) == 2
    call_by_matrix_id = {c["matrix_id"]: c for c in sa.calls}
    assert call_by_matrix_id["ptdf_rd_n0_side1"]["sensitivity_function_type"] == "BRANCH_CURRENT_1"
    assert call_by_matrix_id["ptdf_rd_n0_side2"]["sensitivity_function_type"] == "BRANCH_CURRENT_2"
    for call in sa.calls:
        assert call["sensitivity_variable_type"] == "INJECTION_ACTIVE_POWER"
        assert sorted(call["variables_ids"]) == ["GU_A", "GU_B"]


def test_compute_sensitivity_rd_n0_raises_when_no_branches():
    """Given an AEFlatList with no SECURED branches, When computing RD
    sensitivity, Then a ValueError is raised before any pypowsybl call."""
    from pre_milp import n0_sensitivity as sens

    rd_list = [_make_rd_unit_rd("RA1", "GU_A")]
    with pytest.raises(ValueError, match="No monitored branch IDs"):
        sens.compute_sensitivity_rd_n0(
            network=MagicMock(), rd_list=rd_list, ae_flat_list=[], timestamp="1030Z",
        )


def test_compute_sensitivity_rd_n0_raises_when_no_preventive_rd_units():
    """Given no available preventive RD units, When computing RD
    sensitivity, Then a ValueError is raised before any pypowsybl call."""
    from pre_milp import n0_sensitivity as sens

    ae_list = [_make_ae_rd("BRANCH_S1", side=1)]
    rd_list = [_make_rd_unit_rd("RA1", "GU_A", available=False)]
    with pytest.raises(ValueError, match="No available preventive RD units"):
        sens.compute_sensitivity_rd_n0(
            network=MagicMock(), rd_list=rd_list, ae_flat_list=ae_list, timestamp="1030Z",
        )


def test_compute_sensitivity_rd_n0_writes_csv_with_side_column(tmp_path):
    """Given output_path is provided, When computing RD sensitivity, Then
    sensitivity_rd_n0.csv is written with a side column matching each
    branch's resolved side."""
    from pre_milp import n0_sensitivity as sens

    ae_list = [_make_ae_rd("BRANCH_S1", side=1), _make_ae_rd("BRANCH_S2", side=2)]
    rd_list = [_make_rd_unit_rd("RA1", "GU_A")]

    side1_matrix = pd.DataFrame({"BRANCH_S1": [1.5]}, index=["GU_A"])
    side2_matrix = pd.DataFrame({"BRANCH_S2": [3.5]}, index=["GU_A"])
    _install_fake_pypowsybl({
        "ptdf_rd_n0_side1": side1_matrix,
        "ptdf_rd_n0_side2": side2_matrix,
    })

    out_path = tmp_path / "sensitivity_rd_n0.csv"
    sens.compute_sensitivity_rd_n0(
        network=MagicMock(), rd_list=rd_list, ae_flat_list=ae_list,
        timestamp="1030Z", output_path=out_path,
    )

    assert out_path.exists()
    with open(out_path, newline="", encoding=TEXT_ENCODING) as f:
        rows = list(csv.DictReader(f))

    assert {"branch_mrid", "gu_mrid", "di_da_ampere_per_mw", "side", "timestamp"} <= set(rows[0].keys())
    by_branch = {r["branch_mrid"]: r for r in rows}
    assert by_branch["BRANCH_S1"]["side"] == "1"
    assert by_branch["BRANCH_S2"]["side"] == "2"
    assert float(by_branch["BRANCH_S1"]["di_da_ampere_per_mw"]) == pytest.approx(1.5)
    assert float(by_branch["BRANCH_S2"]["di_da_ampere_per_mw"]) == pytest.approx(3.5)


def test_compute_sensitivity_rd_n0_respects_loading_threshold_pruning():
    """Given lf_initial and a sensitivity_threshold_pct, When a branch's
    loading_pct falls below the threshold, Then that branch is excluded
    from the monitored set (and therefore from the returned dict)."""
    from pre_milp import n0_sensitivity as sens

    ae_low = _make_ae_rd("BRANCH_LOW", side=1)
    ae_low.patl_ka = {"1030Z": 1.0}  # 1000 A PATL
    ae_high = _make_ae_rd("BRANCH_HIGH", side=1)
    ae_high.patl_ka = {"1030Z": 1.0}

    lf_initial = {
        "BRANCH_LOW": {1: 10.0},    # 1% loading
        "BRANCH_HIGH": {1: 900.0},  # 90% loading
    }

    rd_list = [_make_rd_unit_rd("RA1", "GU_A")]
    side1_matrix = pd.DataFrame({"BRANCH_HIGH": [2.0]}, index=["GU_A"])
    _install_fake_pypowsybl({"ptdf_rd_n0_side1": side1_matrix})

    result = sens.compute_sensitivity_rd_n0(
        network=MagicMock(), rd_list=rd_list, ae_flat_list=[ae_low, ae_high],
        timestamp="1030Z", lf_initial=lf_initial, sensitivity_threshold_pct=50.0,
    )

    assert ("BRANCH_LOW", "GU_A") not in result
    assert ("BRANCH_HIGH", "GU_A") in result


# ---------------------------------------------------------------------------
# prune_sensitivity_by_threshold
# ---------------------------------------------------------------------------

def _make_ae_pruning(branch_mrid: str, side: int, patl_ka: float, timestamp: str = "1030Z") -> AssessedElement:
    return AssessedElement(
        mrid=f"AE_{branch_mrid}",
        name=f"AE {branch_mrid}",
        tso="Espheim",
        ae_type=AEType.SECURED,
        branch_mrid=branch_mrid,
        secured_for_region=None,
        scanned_for_region=None,
        exclusion_reason=None,
        patl_ka={timestamp: patl_ka},
        branch_side=side,
    )


# ---------------------------------------------------------------------------
# Criterion 1: min_loading_threshold_pct (branch-level, RA-type-independent)
# ---------------------------------------------------------------------------

def test_branch_below_min_loading_threshold_is_dropped():
    """Given a branch loaded at 5% of PATL and min_loading_threshold_pct=10,
    When pruning, Then the branch (and all its RA pairs) is dropped."""
    from pre_milp import n0_sensitivity as sens

    ae_list = [_make_ae_pruning("BRANCH_LOW", side=1, patl_ka=1.0)]  # 1000 A PATL
    lf_initial = {"BRANCH_LOW": {1: 50.0}}  # 50 A = 5% loading

    sensitivity_matrix = {("BRANCH_LOW", "RA1"): 999.0}  # huge sensitivity, irrelevant here

    result = sens.prune_sensitivity_by_threshold(
        sensitivity_matrix, ae_list, "1030Z", lf_initial,
        sensitivity_threshold_pct=0.0, min_loading_threshold_pct=10.0,
    )

    assert result == {}


def test_branch_above_min_loading_threshold_is_kept():
    """Given a branch loaded at 90% of PATL and min_loading_threshold_pct=10,
    When pruning, Then the branch is kept."""
    from pre_milp import n0_sensitivity as sens

    ae_list = [_make_ae_pruning("BRANCH_HIGH", side=1, patl_ka=1.0)]
    lf_initial = {"BRANCH_HIGH": {1: 900.0}}  # 90% loading

    sensitivity_matrix = {("BRANCH_HIGH", "RA1"): 5.0}

    result = sens.prune_sensitivity_by_threshold(
        sensitivity_matrix, ae_list, "1030Z", lf_initial,
        sensitivity_threshold_pct=0.0, min_loading_threshold_pct=10.0,
    )

    assert result == {("BRANCH_HIGH", "RA1"): 5.0}


def test_default_min_loading_threshold_is_a_no_op():
    """Given min_loading_threshold_pct is left at its default (0.0), When
    pruning a branch with genuinely zero loading, Then it is still kept
    (0.0 >= 0.0)."""
    from pre_milp import n0_sensitivity as sens

    ae_list = [_make_ae_pruning("BRANCH_ZERO", side=1, patl_ka=1.0)]
    lf_initial = {"BRANCH_ZERO": {1: 0.0}}

    sensitivity_matrix = {("BRANCH_ZERO", "RA1"): 5.0}

    result = sens.prune_sensitivity_by_threshold(
        sensitivity_matrix, ae_list, "1030Z", lf_initial,
    )

    assert result == {("BRANCH_ZERO", "RA1"): 5.0}


# ---------------------------------------------------------------------------
# Criterion 2: sensitivity_threshold_pct (branch-level, RA-type-specific)
# ---------------------------------------------------------------------------

def test_branch_below_sensitivity_threshold_is_dropped():
    """Given a branch whose max |sensitivity| across all its RAs is below
    sensitivity_threshold_pct * patl / 100, When pruning, Then the branch
    (and all its RA pairs) is dropped, even though a different RA on the
    same branch has a small non-zero value."""
    from pre_milp import n0_sensitivity as sens

    ae_list = [_make_ae_pruning("BRANCH_WEAK", side=1, patl_ka=1.0)]  # 1000 A PATL
    # threshold 5% of 1000 A = 50 A; both RAs below that
    sensitivity_matrix = {
        ("BRANCH_WEAK", "RA1"): 10.0,
        ("BRANCH_WEAK", "RA2"): -20.0,
    }

    result = sens.prune_sensitivity_by_threshold(
        sensitivity_matrix, ae_list, "1030Z", lf_initial=None,
        sensitivity_threshold_pct=5.0, min_loading_threshold_pct=0.0,
    )

    assert result == {}


def test_branch_above_sensitivity_threshold_is_kept_entirely():
    """Given a branch where at least one RA's |sensitivity| clears the
    threshold, When pruning, Then ALL of that branch's RA pairs are kept
    (pruning is branch-level via max, not per-RA-pair)."""
    from pre_milp import n0_sensitivity as sens

    ae_list = [_make_ae_pruning("BRANCH_STRONG", side=1, patl_ka=1.0)]  # 1000 A PATL
    sensitivity_matrix = {
        ("BRANCH_STRONG", "RA1"): 5.0,     # below 50 A threshold alone
        ("BRANCH_STRONG", "RA2"): -60.0,   # clears 50 A threshold
    }

    result = sens.prune_sensitivity_by_threshold(
        sensitivity_matrix, ae_list, "1030Z", lf_initial=None,
        sensitivity_threshold_pct=5.0, min_loading_threshold_pct=0.0,
    )

    assert result == sensitivity_matrix


def test_same_branch_pruned_differently_for_pst_vs_rd():
    """A branch with a strong RD and a weak PST sensitivity survives in the RD-pruned matrix
    and is dropped from the PST-pruned one: the two calls are independent."""
    from pre_milp import n0_sensitivity as sens

    ae_list = [_make_ae_pruning("SHARED_BRANCH", side=1, patl_ka=1.0)]  # 1000 A PATL

    sensitivity_pst_n0 = {("SHARED_BRANCH", "PST1"): 5.0}     # weak: below 50A threshold
    sensitivity_rd_n0 = {("SHARED_BRANCH", "GU1"): 200.0}     # strong: clears 50A threshold

    pruned_pst = sens.prune_sensitivity_by_threshold(
        sensitivity_pst_n0, ae_list, "1030Z", lf_initial=None,
        sensitivity_threshold_pct=5.0, min_loading_threshold_pct=0.0,
    )
    pruned_rd = sens.prune_sensitivity_by_threshold(
        sensitivity_rd_n0, ae_list, "1030Z", lf_initial=None,
        sensitivity_threshold_pct=5.0, min_loading_threshold_pct=0.0,
    )

    assert pruned_pst == {}
    assert pruned_rd == {("SHARED_BRANCH", "GU1"): 200.0}


def test_default_sensitivity_threshold_is_a_no_op():
    """Given sensitivity_threshold_pct is left at its default (0.0), When
    pruning a branch with a genuinely zero sensitivity, Then it is still
    kept (0.0 >= 0.0 * patl / 100)."""
    from pre_milp import n0_sensitivity as sens

    ae_list = [_make_ae_pruning("BRANCH_ZERO_SENS", side=1, patl_ka=1.0)]
    sensitivity_matrix = {("BRANCH_ZERO_SENS", "RA1"): 0.0}

    result = sens.prune_sensitivity_by_threshold(
        sensitivity_matrix, ae_list, "1030Z", lf_initial=None,
    )

    assert result == {("BRANCH_ZERO_SENS", "RA1"): 0.0}


# ---------------------------------------------------------------------------
# Missing-data conservatism
# ---------------------------------------------------------------------------

def test_branch_with_no_patl_is_conservatively_kept():
    """Given a branch whose AssessedElement has no PATL for this timestamp,
    When pruning, Then the branch is kept (not evaluable for either
    criterion) and a warning is logged, not silently dropped."""
    from pre_milp import n0_sensitivity as sens

    ae_list = [_make_ae_pruning("BRANCH_NO_PATL", side=1, patl_ka=1.0, timestamp="1130Z")]  # wrong timestamp
    sensitivity_matrix = {("BRANCH_NO_PATL", "RA1"): 1.0}

    result = sens.prune_sensitivity_by_threshold(
        sensitivity_matrix, ae_list, "1030Z", lf_initial=None,
        sensitivity_threshold_pct=50.0, min_loading_threshold_pct=50.0,
    )

    assert result == {("BRANCH_NO_PATL", "RA1"): 1.0}


def test_branch_with_no_assessed_element_is_conservatively_kept():
    """Given a branch present in the sensitivity matrix but absent from
    ae_flat_list entirely, When pruning, Then the branch is kept."""
    from pre_milp import n0_sensitivity as sens

    sensitivity_matrix = {("UNKNOWN_BRANCH", "RA1"): 1.0}

    result = sens.prune_sensitivity_by_threshold(
        sensitivity_matrix, ae_flat_list=[], timestamp="1030Z", lf_initial=None,
        sensitivity_threshold_pct=50.0, min_loading_threshold_pct=50.0,
    )

    assert result == {("UNKNOWN_BRANCH", "RA1"): 1.0}


# ---------------------------------------------------------------------------
# Real-data shape
# ---------------------------------------------------------------------------

def test_pruning_on_the_real_rd_sensitivity_shape():
    """A sensitivity_rd_n0 of the real data's shape (2 generating units x 12 branches,
    -0.46..0.10 A/MW): branches whose strongest sensitivity is tiny relative to PATL are
    dropped, the rest keep all their pairs."""
    from pre_milp import n0_sensitivity as sens

    ae_list = [
        _make_ae_pruning("2ab1b800-0c93-4517-86b5-8fd6a3a24ee7", side=1, patl_ka=1.0),  # 1000 A PATL
        _make_ae_pruning("044a5f09-c766-11e1-8775-005056c00008", side=1, patl_ka=1.0),
    ]

    sensitivity_rd_n0 = {
        ("2ab1b800-0c93-4517-86b5-8fd6a3a24ee7", "3a3b27be-b18b-4385-b557-6735d733baf0"): -0.459074,
        ("2ab1b800-0c93-4517-86b5-8fd6a3a24ee7", "550ebe0d-f2b2-48c1-991f-cebea43a21aa"): -0.355866,
        ("044a5f09-c766-11e1-8775-005056c00008", "3a3b27be-b18b-4385-b557-6735d733baf0"): 0.094083,
        ("044a5f09-c766-11e1-8775-005056c00008", "550ebe0d-f2b2-48c1-991f-cebea43a21aa"): 0.099364,
    }

    # threshold_pct=0.05 -> 0.5 A on 1000 A; the max |sensitivity| (0.459 and 0.099 A/MW)
    # is below it. Checks the calculation threshold_pct * patl / 100, not a real setting.
    result = sens.prune_sensitivity_by_threshold(
        sensitivity_rd_n0, ae_list, "1030Z", lf_initial=None,
        sensitivity_threshold_pct=0.05, min_loading_threshold_pct=0.0,
    )

    assert result == {}  # both branches' max sensitivity (0.459, 0.099) < 0.5 A threshold

    # Lowering the threshold so both clear it confirms pairs are preserved intact.
    result_lower_threshold = sens.prune_sensitivity_by_threshold(
        sensitivity_rd_n0, ae_list, "1030Z", lf_initial=None,
        sensitivity_threshold_pct=0.001, min_loading_threshold_pct=0.0,
    )
    assert result_lower_threshold == sensitivity_rd_n0


# ---------------------------------------------------------------------------
# Scanned branches: effective limit
# ---------------------------------------------------------------------------

def _make_ae_scanned(branch_mrid: str, ae_type: AEType, side: int, patl_ka: float, timestamp: str = "1030Z") -> AssessedElement:
    return AssessedElement(
        mrid=f"AE_{branch_mrid}_{ae_type.value}", name=f"AE {branch_mrid}", tso="TestTSO",
        ae_type=ae_type, branch_mrid=branch_mrid,
        secured_for_region=None, scanned_for_region=None, exclusion_reason=None,
        patl_ka={timestamp: patl_ka}, branch_side=side,
    )


def test_scanned_branch_included_in_monitored_sides():
    """Given an AEFlatList containing only a SCANNED AE (no SECURED at
    all), When _get_loading_filtered_branch_sides runs, Then the scanned branch
    IS included — this used to be silently excluded entirely."""
    ae_list = [_make_ae_scanned("SCANNED_BRANCH", AEType.SCANNED, side=1, patl_ka=1.0)]
    lf_initial = {"SCANNED_BRANCH": {1: 500.0}}  # 50% loading

    result = sens._get_loading_filtered_branch_sides(
        ae_list, "1030Z", lf_initial=lf_initial, sensitivity_threshold_pct=0.0,
    )

    assert "SCANNED_BRANCH" in result
    assert result["SCANNED_BRANCH"] == 1


def test_secured_branch_values_unchanged_by_presence_of_scanned_aes():
    """Given an AEFlatList with BOTH a secured and a scanned AE, When
    _get_loading_filtered_branch_sides runs with a threshold that would exclude
    the scanned branch but not the secured one, Then the secured branch's
    inclusion/side is IDENTICAL to what it would be if the scanned AE
    weren't present at all — widening the scope must not alter any
    existing secured-branch entry."""
    secured_ae = _make_ae_scanned("SECURED_BRANCH", AEType.SECURED, side=2, patl_ka=1.0)
    scanned_ae = _make_ae_scanned("SCANNED_BRANCH", AEType.SCANNED, side=1, patl_ka=1.0)

    lf_initial = {
        "SECURED_BRANCH": {2: 900.0},  # 90% loading -> above threshold
        "SCANNED_BRANCH": {1: 10.0},   # 1% loading -> below threshold
    }

    result_with_scanned = sens._get_loading_filtered_branch_sides(
        [secured_ae, scanned_ae], "1030Z", lf_initial=lf_initial, sensitivity_threshold_pct=50.0,
    )
    result_secured_only = sens._get_loading_filtered_branch_sides(
        [secured_ae], "1030Z", lf_initial=lf_initial, sensitivity_threshold_pct=50.0,
    )

    assert result_with_scanned["SECURED_BRANCH"] == result_secured_only["SECURED_BRANCH"] == 2
    assert "SCANNED_BRANCH" not in result_with_scanned  # correctly excluded by threshold


def test_scanned_branch_uses_effective_limit_not_bare_patl():
    """A scanned branch loaded above its PATL is filtered against the effective limit
    max(patl_scanned, initial_loading), which here differs from the PATL."""
    # PATL = 1.0 kA = 1000 A. Initial loading = 1200 A (already above PATL).
    # effective_limit = max(1000, 1200) = 1200 A -> loading_pct = 100% exactly.
    # Using bare PATL instead would give loading_pct = 120%, a different number.
    scanned_ae = _make_ae_scanned("SCANNED_BRANCH", AEType.SCANNED, side=1, patl_ka=1.0)
    ae_by_branch = {"SCANNED_BRANCH": scanned_ae}
    lf_initial = {"SCANNED_BRANCH": {1: 1200.0}}

    limit_ampere, initial_current_ampere = sens._resolve_branch_patl_ampere_and_initial_current_ampere(
        "SCANNED_BRANCH", ae_by_branch, "1030Z", lf_initial,
    )

    assert limit_ampere == 1200.0  # effective_limit, not bare PATL (1000.0)
    assert initial_current_ampere == 1200.0


def test_secured_branch_still_uses_bare_patl_not_effective_limit():
    """A secured branch with the same loading uses the bare PATL: the effective limit is
    scanned-only."""
    secured_ae = _make_ae_scanned("SECURED_BRANCH", AEType.SECURED, side=1, patl_ka=1.0)
    ae_by_branch = {"SECURED_BRANCH": secured_ae}
    lf_initial = {"SECURED_BRANCH": {1: 1200.0}}

    limit_ampere, initial_current_ampere = sens._resolve_branch_patl_ampere_and_initial_current_ampere(
        "SECURED_BRANCH", ae_by_branch, "1030Z", lf_initial,
    )

    assert limit_ampere == 1000.0  # bare PATL, unaffected by initial loading
    assert initial_current_ampere == 1200.0


def test_prune_sensitivity_by_threshold_evaluates_scanned_branches():
    """A scanned branch's sensitivity entry is evaluated against its effective limit."""
    scanned_ae = _make_ae_scanned("SCANNED_BRANCH", AEType.SCANNED, side=1, patl_ka=1.0)
    lf_initial = {"SCANNED_BRANCH": {1: 900.0}}  # 90% loading, well above threshold

    sensitivity_matrix = {("SCANNED_BRANCH", "RA1"): 5.0}

    result = sens.prune_sensitivity_by_threshold(
        sensitivity_matrix, [scanned_ae], "1030Z", lf_initial,
        sensitivity_threshold_pct=0.0, min_loading_threshold_pct=10.0,
    )

    assert result == sensitivity_matrix  # kept: 90% loading clears the 10% threshold


# ===========================================================================
# An unreadable sensitivity matrix entry is NaN, never 0.0
# ===========================================================================

def test_an_unreadable_matrix_entry_is_nan_not_zero():
    import pandas as pd
    from pre_milp.n0_sensitivity import _matrix_entry
    matrix = pd.DataFrame({"B1": [2.5]}, index=["PST1"])
    assert _matrix_entry(matrix, "PST1", "B1") == 2.5
    value = _matrix_entry(matrix, "PST2", "B1")
    assert value != value
