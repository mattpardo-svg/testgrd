"""tests/test_rao_nx_security_analysis.py - unit tests for nx_security_analysis.py (N-X load flow, TATL data, helpers).
"""

import sys
import pandas as pd
import pytest
import logging

from pathlib import Path
from data_model import AEType, AssessedElement, Contingency, ContingencyType, PST, RAKind, RDUnit
from milp.milp_builder import _get_monitored_branch_sides
from pre_milp.nx_security_analysis import (
    _get_must_study_contingencies,
    _register_contingencies,
    _contingency_result_is_usable,
    compute_lf_nx,
    compute_tatl_data,
    write_lf_nx_csv,
    write_tatl_data_csv,
)
from helpers import (
    DummyContingencyContextType,
    DummyLoadflowModule,
    DummyPostContingencyResult,
    DummyPypowsyblModule,
    DummySecurityAnalysis,
    DummySecurityAnalysisResult,
    DummySecurityModule,
    DummySensitivityAnalysis,
    DummySensitivityFunctionType,
    DummySensitivityModule,
    DummySensitivityResult,
    DummySensitivityVariableType,
    _branch_results_df,
    _make_ae_nx_sec as _make_ae,
    _make_contingency_nx_sec as _make_contingency,
    _make_ae_nx_filters as _make_ae_nx_filters_and_scanned_elements,
    _make_contingency as _make_contingency_nx_filters_and_scanned_elements,
    _make_pst_nx_filters as _make_pst_nx_filters_and_scanned_elements,
)
from text_encoding import TEXT_ENCODING  # noqa: E402

# ---------------------------------------------------------------------------
# TATL fixtures
# ---------------------------------------------------------------------------

def _make_operational_limits_df(rows: list[dict]) -> pd.DataFrame:
    """The index shape of pypowsybl's network.get_operational_limits()."""
    if not rows:
        columns = ["element_id", "side", "type", "acceptable_duration", "group_name", "element_type", "name", "value"]
        return pd.DataFrame(columns=columns).set_index(
            ["element_id", "side", "type", "acceptable_duration", "group_name"]
        )
    df = pd.DataFrame(rows)
    return df.set_index(["element_id", "side", "type", "acceptable_duration", "group_name"])


class DummyNetworkForOperationalLimits:
    def __init__(self, limits_df: pd.DataFrame):
        self._limits_df = limits_df

    def get_operational_limits(self):
        return self._limits_df


# ---------------------------------------------------------------------------
# Dummy pypowsybl stand-ins
# ---------------------------------------------------------------------------


# ---------------------------------------------------------------------------
# _get_monitored_branch_sides
# ---------------------------------------------------------------------------

class TestGetMonitoredBranchSidesNx:
    def test_includes_both_secured_and_scanned_no_threshold(self):
        """Given a SECURED and a SCANNED AE, When resolving monitored
        branch sides for N-X, Then both are included with no
        loading-threshold pre-filter (N-X has no natural single N-0
        loading value to pre-filter on — see module SCOPE NOTE)."""
        ae_flat_list = [
            _make_ae("1", "b1", branch_side=1),
            _make_ae("2", "b2", branch_side=2, ae_type=AEType.SCANNED),
        ]
        result = _get_monitored_branch_sides(ae_flat_list)
        assert result == {"b1": 1, "b2": 2}

    def test_excludes_excluded_ae_type_and_missing_branch_mrid(self):
        ae_flat_list = [
            _make_ae("1", "b1", ae_type=AEType.EXCLUDED),
            _make_ae("2", None, ae_type=AEType.SECURED),
        ]
        result = _get_monitored_branch_sides(ae_flat_list)
        assert result == {}


# ---------------------------------------------------------------------------
# _get_must_study_contingencies
# ---------------------------------------------------------------------------

class TestGetMustStudyContingencies:
    def test_filters_by_must_study_at_timestamp_sorted(self):
        co_flat_list = [
            _make_contingency("co-2", ["eq-2"], must_study=True),
            _make_contingency("co-1", ["eq-1"], must_study=True),
            _make_contingency("co-3", ["eq-3"], must_study=False),
        ]
        result = _get_must_study_contingencies(co_flat_list, "1030Z")
        assert [c.mrid for c in result] == ["co-1", "co-2"]

    def test_missing_timestamp_entry_treated_as_not_studied(self):
        co_flat_list = [_make_contingency("co-1", ["eq-1"], must_study=True, timestamp="1130Z")]
        result = _get_must_study_contingencies(co_flat_list, "1030Z")
        assert result == []


# ---------------------------------------------------------------------------
# _register_contingencies
# ---------------------------------------------------------------------------

class TestRegisterContingencies:
    def test_single_equipment_uses_single_element_contingency(self):
        contingencies = [_make_contingency("co-1", ["eq-1"])]
        container = DummySecurityAnalysis({}, pd.DataFrame())
        _register_contingencies(container, contingencies)
        assert container.single_element_contingencies == [("eq-1", "co-1")]
        assert container.multiple_element_contingencies == []

    def test_multiple_equipment_uses_multiple_elements_contingency(self):
        contingencies = [_make_contingency("co-1", ["eq-1", "eq-2"])]
        container = DummySecurityAnalysis({}, pd.DataFrame())
        _register_contingencies(container, contingencies)
        assert container.multiple_element_contingencies == [(["eq-1", "eq-2"], "co-1")]
        assert container.single_element_contingencies == []


# ---------------------------------------------------------------------------
# _contingency_result_is_usable
# ---------------------------------------------------------------------------

class TestContingencyResultIsUsable:
    def test_converged_with_all_branches_present_is_usable(self):
        contingency = _make_contingency("co-1", ["eq-1"])
        usable, reason = _contingency_result_is_usable(
            contingency, "CONVERGED", {"b1", "b2"}, {"b1", "b2"},
        )
        assert usable is True
        assert reason is None

    def test_no_impact_is_usable(self):
        """NO_IMPACT means the contingency provably did not change the
        network — a valid outcome, not a failure."""
        contingency = _make_contingency("co-1", ["eq-1"])
        usable, reason = _contingency_result_is_usable(
            contingency, "NO_IMPACT", {"b1"}, {"b1"},
        )
        assert usable is True

    def test_non_convergent_is_not_usable(self):
        contingency = _make_contingency("co-1", ["eq-1"])
        usable, reason = _contingency_result_is_usable(
            contingency, "FAILED", {"b1"}, {"b1"},
        )
        assert usable is False
        assert "non-convergent" in reason

    def test_missing_branch_is_treated_as_likely_network_split(self):
        """A monitored branch missing from the contingency's results means a likely network
        split (pypowsybl reports no island count): not usable."""
        contingency = _make_contingency("co-1", ["eq-1"])
        usable, reason = _contingency_result_is_usable(
            contingency, "CONVERGED", {"b1"}, {"b1", "b2"},
        )
        assert usable is False
        assert "network split" in reason

    def test_contingencys_own_tripped_equipment_missing_is_not_a_split(self):
        """When the only missing branch is the contingency's own tripped equipment (no flow by
        definition), the contingency IS usable: its equipment is excluded from the check."""
        contingency = _make_contingency("co-1", ["b2"])  # trips branch b2 itself
        usable, reason = _contingency_result_is_usable(
            contingency, "CONVERGED", {"b1"}, {"b1", "b2"},
        )
        assert usable is True
        assert reason is None

    def test_genuine_split_alongside_own_tripped_equipment_still_detected(self):
        """Given a contingency whose own tripped equipment IS missing
        (expected, excluded) but a DIFFERENT, unrelated branch is ALSO
        missing, When usability is checked, Then it is STILL treated as
        a likely network split — excluding the contingency's own
        equipment must not accidentally mask a genuine split affecting
        some other branch."""
        contingency = _make_contingency("co-1", ["b2"])  # trips branch b2 itself
        usable, reason = _contingency_result_is_usable(
            contingency, "CONVERGED", {"b1"}, {"b1", "b2", "b3"},
        )
        assert usable is False
        assert "network split" in reason
        assert "b3" in reason
        assert "b2" not in reason  # the contingency's own equipment must not appear in the reported reason

    def test_multi_element_contingency_all_own_equipment_excluded(self):
        """Same exclusion, but for a multi-equipment contingency — every
        piece of equipment this contingency trips is excluded, not just
        the first one."""
        contingency = _make_contingency("co-1", ["b1", "b2"])
        usable, reason = _contingency_result_is_usable(
            contingency, "CONVERGED", {"b3"}, {"b1", "b2", "b3"},
        )
        assert usable is True
        assert reason is None


# ---------------------------------------------------------------------------
# compute_lf_nx
# ---------------------------------------------------------------------------

class TestComputeLfNx:
    def test_returns_side_aware_currents_per_contingency(self, monkeypatch):
        """Given one must-study contingency and two monitored branches,
        When compute_lf_nx runs, Then lf_nx contains both sides per
        branch under that contingency's mRID, matching
        cgmes_loader.build_lf_initial's shape exactly."""
        ae_flat_list = [_make_ae("ae-1", "b1", branch_side=1), _make_ae("ae-2", "b2", branch_side=2)]
        co_flat_list = [_make_contingency("co-1", ["eq-1"])]

        branch_results = _branch_results_df([
            {"contingency_id": "co-1", "branch_id": "b1", "i1": 100.0, "i2": 90.0},
            {"contingency_id": "co-1", "branch_id": "b2", "i1": 50.0, "i2": 60.0},
        ])
        post_contingency_results = {"co-1": DummyPostContingencyResult("CONVERGED")}
        fake_pp = DummyPypowsyblModule(
            post_contingency_results=post_contingency_results, branch_results=branch_results,
        )
        monkeypatch.setitem(sys.modules, "pypowsybl", fake_pp)

        lf_nx, skipped = compute_lf_nx(object(), co_flat_list, ae_flat_list, "1030Z")

        assert skipped == {}
        assert lf_nx == {"co-1": {"b1": {1: 100.0, 2: 90.0}, "b2": {1: 50.0, 2: 60.0}}}

    def test_skips_non_convergent_contingency(self, monkeypatch):
        ae_flat_list = [_make_ae("ae-1", "b1", branch_side=1)]
        co_flat_list = [_make_contingency("co-1", ["eq-1"])]

        branch_results = _branch_results_df([])
        post_contingency_results = {"co-1": DummyPostContingencyResult("FAILED")}
        fake_pp = DummyPypowsyblModule(
            post_contingency_results=post_contingency_results, branch_results=branch_results,
        )
        monkeypatch.setitem(sys.modules, "pypowsybl", fake_pp)

        lf_nx, skipped = compute_lf_nx(object(), co_flat_list, ae_flat_list, "1030Z")

        assert lf_nx == {}
        assert "co-1" in skipped
        assert "non-convergent" in skipped["co-1"]

    def test_default_use_reactive_limits_reaches_parameters_construction_as_false(self, monkeypatch):
        """Spy: use_reactive_limits reaches the pp.loadflow.Parameters() passed to
        security_analysis.run_ac(...)."""
        ae_flat_list = [_make_ae("ae-1", "b1", branch_side=1)]
        co_flat_list = [_make_contingency("co-1", ["eq-1"])]
        branch_results = _branch_results_df([{"contingency_id": "co-1", "branch_id": "b1", "i1": 1.0, "i2": 1.0}])
        post_contingency_results = {"co-1": DummyPostContingencyResult("CONVERGED")}
        fake_pp = DummyPypowsyblModule(
            post_contingency_results=post_contingency_results, branch_results=branch_results,
        )
        monkeypatch.setitem(sys.modules, "pypowsybl", fake_pp)
        DummyLoadflowModule.Parameters.last_kwargs = None

        compute_lf_nx(object(), co_flat_list, ae_flat_list, "1030Z")

        assert DummyLoadflowModule.Parameters.last_kwargs == {"use_reactive_limits": False}

    def test_explicit_use_reactive_limits_true_reaches_parameters_construction(self, monkeypatch):
        ae_flat_list = [_make_ae("ae-1", "b1", branch_side=1)]
        co_flat_list = [_make_contingency("co-1", ["eq-1"])]
        branch_results = _branch_results_df([{"contingency_id": "co-1", "branch_id": "b1", "i1": 1.0, "i2": 1.0}])
        post_contingency_results = {"co-1": DummyPostContingencyResult("CONVERGED")}
        fake_pp = DummyPypowsyblModule(
            post_contingency_results=post_contingency_results, branch_results=branch_results,
        )
        monkeypatch.setitem(sys.modules, "pypowsybl", fake_pp)
        DummyLoadflowModule.Parameters.last_kwargs = None

        compute_lf_nx(object(), co_flat_list, ae_flat_list, "1030Z", use_reactive_limits=True)

        assert DummyLoadflowModule.Parameters.last_kwargs == {"use_reactive_limits": True}

    def test_raises_when_no_must_study_contingencies(self):
        with pytest.raises(ValueError, match="must-study"):
            compute_lf_nx(object(), [], [_make_ae("ae-1", "b1")], "1030Z")

    def test_raises_when_no_monitored_branches(self):
        co_flat_list = [_make_contingency("co-1", ["eq-1"])]
        with pytest.raises(ValueError, match="monitored branch"):
            compute_lf_nx(object(), co_flat_list, [], "1030Z")


# ---------------------------------------------------------------------------
# write_lf_nx_csv
# ---------------------------------------------------------------------------

class TestWriteLfNxCsv:
    def test_writes_header_and_rows(self, tmp_path):
        lf_nx = {"co-1": {"b1": {1: 100.0, 2: 90.0}}}
        branch_sides = {"b1": 1}
        output_path = tmp_path / "lf_nx_initial.csv"
        write_lf_nx_csv(lf_nx, branch_sides, {}, [_make_contingency("co-1", ["eq-1"])], output_path, "1030Z")
        content = output_path.read_text(encoding=TEXT_ENCODING)
        assert "contingency_mrid" in content.splitlines()[0]
        assert "co-1" in content


# ---------------------------------------------------------------------------
# compute_tatl_data
# ---------------------------------------------------------------------------

class TestComputeTatlData:
    def test_returns_side_aware_tatl_matching_ae_branch_side(self):
        """Given a branch with a single TATL entry on side ONE, and an AE
        whose resolved branch_side is 1, When compute_tatl_data runs,
        Then it returns the TATL limit/duration for that side."""
        limits_df = _make_operational_limits_df([
            dict(element_id="b1", side="ONE", type="CURRENT", acceptable_duration=1200,
                 group_name="g1", element_type="LINE", name="tatl", value=1200.0),
            dict(element_id="b1", side="ONE", type="CURRENT", acceptable_duration=-1,
                 group_name="g1", element_type="LINE", name="permanent_limit", value=1000.0),
        ])
        network = DummyNetworkForOperationalLimits(limits_df)
        ae_flat_list = [_make_ae("ae-1", "b1", branch_side=1)]

        result = compute_tatl_data(network, ae_flat_list, "1030Z")

        assert result == {"b1": {"tatl_limit_ampere": 1200.0, "tatl_duration_seconds": 1200, "side": 1, "was_corrected": False}}

    def test_no_tatl_row_falls_back_to_patl_with_600s_duration(self):
        """A branch with no acceptable_duration > 0 row gets TATL = its PATL (patl_ka, kA ->
        A) with tatl_duration_seconds 600; only when the CGM has no TATL for that side."""
        limits_df = _make_operational_limits_df([
            dict(element_id="b1", side="ONE", type="CURRENT", acceptable_duration=-1,
                 group_name="g1", element_type="LINE", name="permanent_limit", value=1000.0),
        ])
        network = DummyNetworkForOperationalLimits(limits_df)
        ae_flat_list = [_make_ae("ae-1", "b1", branch_side=1, patl_ka=1.574)]

        result = compute_tatl_data(network, ae_flat_list, "1030Z")

        assert result == {"b1": {"tatl_limit_ampere": 1574.0, "tatl_duration_seconds": 600, "side": 1, "was_corrected": False}}

    def test_the_fallback_duration_is_configurable_and_applies_only_without_a_tatl_row(self):
        """config tatl_fallback_duration_s: b1 (no TATL row) gets the configured duration, b2
        keeps its own CGM duration."""
        limits_df = _make_operational_limits_df([
            dict(element_id="b1", side="ONE", type="CURRENT", acceptable_duration=-1,
                 group_name="g1", element_type="LINE", name="permanent_limit", value=1000.0),
            dict(element_id="b2", side="ONE", type="CURRENT", acceptable_duration=1200,
                 group_name="g1", element_type="LINE", name="tatl", value=1500.0),
        ])
        network = DummyNetworkForOperationalLimits(limits_df)
        ae_flat_list = [_make_ae("ae-1", "b1", branch_side=1, patl_ka=1.0),
                        _make_ae("ae-2", "b2", branch_side=1, patl_ka=1.0)]

        result = compute_tatl_data(network, ae_flat_list, "1030Z", fallback_duration_seconds=900)

        assert result["b1"]["tatl_duration_seconds"] == 900
        assert result["b2"]["tatl_duration_seconds"] == 1200

    def test_tatl_lower_than_patl_is_corrected_to_patl(self, caplog):
        """A CGM TATL below the PATL (a temporary rating is never lower) is raised to the
        PATL, with was_corrected=True."""
        limits_df = _make_operational_limits_df([
            dict(element_id="b1", side="ONE", type="CURRENT", acceptable_duration=600,
                 group_name="g1", element_type="LINE", name="tatl", value=500.0),
        ])
        network = DummyNetworkForOperationalLimits(limits_df)
        ae_flat_list = [_make_ae("ae-1", "b1", branch_side=1, patl_ka=2.0)]

        with caplog.at_level("WARNING"):
            result = compute_tatl_data(network, ae_flat_list, "1030Z")

        assert result == {"b1": {"tatl_limit_ampere": 2000.0, "tatl_duration_seconds": 600, "side": 1, "was_corrected": True}}
        assert "1 of 1" in caplog.text
        assert "corrected to TATL = PATL" in caplog.text

    def test_tatl_above_patl_is_not_corrected(self):
        """A TATL above the PATL (the normal case) passes unchanged."""
        limits_df = _make_operational_limits_df([
            dict(element_id="b1", side="ONE", type="CURRENT", acceptable_duration=600,
                 group_name="g1", element_type="LINE", name="tatl", value=1200.0),
        ])
        network = DummyNetworkForOperationalLimits(limits_df)
        ae_flat_list = [_make_ae("ae-1", "b1", branch_side=1, patl_ka=1.0)]

        result = compute_tatl_data(network, ae_flat_list, "1030Z")

        assert result == {"b1": {"tatl_limit_ampere": 1200.0, "tatl_duration_seconds": 600, "side": 1, "was_corrected": False}}

    def test_no_per_branch_correction_log_only_summary(self, caplog):
        """Corrections are not logged per branch (they can hit most branches), only in one
        summary line."""
        limits_df = _make_operational_limits_df([
            dict(element_id="b1", side="ONE", type="CURRENT", acceptable_duration=600,
                 group_name="g1", element_type="LINE", name="tatl", value=500.0),
            dict(element_id="b2", side="ONE", type="CURRENT", acceptable_duration=600,
                 group_name="g1", element_type="LINE", name="tatl", value=500.0),
        ])
        network = DummyNetworkForOperationalLimits(limits_df)
        ae_flat_list = [
            _make_ae("ae-1", "b1", branch_side=1, patl_ka=2.0),
            _make_ae("ae-2", "b2", branch_side=1, patl_ka=3.0),
        ]

        with caplog.at_level("WARNING"):
            compute_tatl_data(network, ae_flat_list, "1030Z")

        assert caplog.text.count("corrected to TATL = PATL") == 1
        assert "2 of 2" in caplog.text

    def test_several_tatls_on_one_side_give_no_entry_and_no_patl_fallback(self):
        """The PATL fallback does not apply when the CGM has several acceptable_duration > 0
        entries on the same side (ambiguous TATL data is reported, not replaced)."""
        limits_df = _make_operational_limits_df([
            dict(element_id="b1", side="ONE", type="CURRENT", acceptable_duration=1200,
                 group_name="g1", element_type="LINE", name="tatl_20min", value=1200.0),
            dict(element_id="b1", side="ONE", type="CURRENT", acceptable_duration=600,
                 group_name="g1", element_type="LINE", name="tatl_10min", value=1300.0),
        ])
        network = DummyNetworkForOperationalLimits(limits_df)
        ae_flat_list = [_make_ae("ae-1", "b1", branch_side=1, patl_ka=1.574)]

        result = compute_tatl_data(network, ae_flat_list, "1030Z")

        assert result == {}

    def test_different_sides_each_get_their_own_single_tatl(self):
        """Given branch b1 has one TATL on side ONE and a DIFFERENT branch
        b2 has one TATL on side TWO, When compute_tatl_data runs, Then
        both are resolved independently — the 'more than one TATL' skip
        rule is scoped to the SAME side, not the branch as a whole."""
        limits_df = _make_operational_limits_df([
            dict(element_id="b1", side="ONE", type="CURRENT", acceptable_duration=1200,
                 group_name="g1", element_type="LINE", name="tatl", value=1200.0),
            dict(element_id="b2", side="TWO", type="CURRENT", acceptable_duration=900,
                 group_name="g1", element_type="LINE", name="tatl", value=1100.0),
        ])
        network = DummyNetworkForOperationalLimits(limits_df)
        ae_flat_list = [_make_ae("ae-1", "b1", branch_side=1), _make_ae("ae-2", "b2", branch_side=2)]

        result = compute_tatl_data(network, ae_flat_list, "1030Z")

        assert result == {
            "b1": {"tatl_limit_ampere": 1200.0, "tatl_duration_seconds": 1200, "side": 1, "was_corrected": False},
            "b2": {"tatl_limit_ampere": 1100.0, "tatl_duration_seconds": 900, "side": 2, "was_corrected": False},
        }

    def test_branch_with_no_tatl_and_no_patl_is_absent_and_warns(self):
        """A branch with no CGM TATL and no PATL at this timestamp is absent from the result,
        with a warning."""
        limits_df = _make_operational_limits_df([
            dict(element_id="b1", side="ONE", type="CURRENT", acceptable_duration=-1,
                 group_name="g1", element_type="LINE", name="permanent_limit", value=1000.0),
        ])
        network = DummyNetworkForOperationalLimits(limits_df)
        ae_no_patl = AssessedElement(
            mrid="ae-1", name="a", tso="TSO", ae_type=AEType.SECURED, branch_mrid="b1",
            secured_for_region=None, scanned_for_region=None, exclusion_reason=None,
            patl_ka={}, branch_side=1,
        )

        result = compute_tatl_data(network, [ae_no_patl], "1030Z")

        assert "b1" not in result

    def test_excludes_scanned_branches(self):
        """The TATL is for SECURED branches only: with no SECURED branch in AEFlatList it
        raises, as compute_lf_nx does."""
        limits_df = _make_operational_limits_df([
            dict(element_id="b1", side="ONE", type="CURRENT", acceptable_duration=1200,
                 group_name="g1", element_type="LINE", name="tatl", value=1200.0),
        ])
        network = DummyNetworkForOperationalLimits(limits_df)
        ae_flat_list = [_make_ae("ae-1", "b1", branch_side=1, ae_type=AEType.SCANNED)]

        with pytest.raises(ValueError, match="SECURED"):
            compute_tatl_data(network, ae_flat_list, "1030Z")

    def test_excludes_scanned_branch_when_another_secured_branch_exists(self):
        """Given a mix of one SECURED and one SCANNED branch, When
        compute_tatl_data runs, Then only the SECURED branch's TATL is
        resolved — the SCANNED branch's TATL entry (if any) is ignored."""
        limits_df = _make_operational_limits_df([
            dict(element_id="b1", side="ONE", type="CURRENT", acceptable_duration=1200,
                 group_name="g1", element_type="LINE", name="tatl", value=1200.0),
            dict(element_id="b2", side="ONE", type="CURRENT", acceptable_duration=1200,
                 group_name="g1", element_type="LINE", name="tatl", value=999.0),
        ])
        network = DummyNetworkForOperationalLimits(limits_df)
        ae_flat_list = [
            _make_ae("ae-1", "b1", branch_side=1, ae_type=AEType.SECURED),
            _make_ae("ae-2", "b2", branch_side=1, ae_type=AEType.SCANNED),
        ]

        result = compute_tatl_data(network, ae_flat_list, "1030Z")

        assert list(result.keys()) == ["b1"]

    def test_empty_operational_limits_falls_back_to_patl_for_every_branch(self):
        """A network without any operational limits gets the PATL fallback for every branch,
        as a single branch without a TATL row does (no early empty return)."""
        limits_df = _make_operational_limits_df([])
        network = DummyNetworkForOperationalLimits(limits_df)
        ae_flat_list = [_make_ae("ae-1", "b1", branch_side=1, patl_ka=1.574)]

        result = compute_tatl_data(network, ae_flat_list, "1030Z")

        assert result == {"b1": {"tatl_limit_ampere": 1574.0, "tatl_duration_seconds": 600, "side": 1, "was_corrected": False}}

    def test_raises_when_no_secured_branches_in_ae_flat_list(self):
        network = DummyNetworkForOperationalLimits(_make_operational_limits_df([]))
        with pytest.raises(ValueError, match="SECURED"):
            compute_tatl_data(network, [], "1030Z")


# ---------------------------------------------------------------------------
# write_tatl_data_csv
# ---------------------------------------------------------------------------

class TestWriteTatlDataCsv:
    def test_writes_header_and_rows_in_ka(self):
        """tatl_limit_ka column is kA (external files use kA),
        converted from the internal A convention — mirrors PATL/current
        CSV exports elsewhere in this codebase using kA for external
        files while staying in A internally."""
        tatl_data = {"b1": {"tatl_limit_ampere": 1200.0, "tatl_duration_seconds": 1200, "side": 1, "was_corrected": False}}
        output_path_dir = None
        import tempfile
        with tempfile.TemporaryDirectory() as tmp:
            output_path = Path(tmp) / "tatl_data.csv"
            write_tatl_data_csv(tatl_data, {"b1": "Branch One"}, output_path)
            content = output_path.read_text(encoding=TEXT_ENCODING)
        lines = content.splitlines()
        assert lines[0] == "branch_mrid,branch_name,side,tatl_limit_ka,tatl_duration_seconds,was_corrected"
        assert "Branch One" in lines[1]
        assert "1.2" in lines[1]
        assert "1200" in lines[1]
        assert "False" in lines[1]

    def test_empty_input_still_writes_header_only(self):
        import tempfile
        with tempfile.TemporaryDirectory() as tmp:
            output_path = Path(tmp) / "tatl_data.csv"
            write_tatl_data_csv({}, {}, output_path)
            content = output_path.read_text(encoding=TEXT_ENCODING)
        assert len(content.splitlines()) == 1


# ===========================================================================
# NaN currents in the security analysis
# ===========================================================================

# ---------------------------------------------------------------------------
# missing / NaN lf_nx data: skip the pair with a warning, never 0.0 A
# ---------------------------------------------------------------------------

def _compute_lf_nx_with(monkeypatch, rows, contingency_equipment=("eq-1",)):
    import helpers as S
    from pre_milp.nx_security_analysis import compute_lf_nx
    ae_flat_list = [S._make_ae_nx_sec("ae-1", "b1", branch_side=1), S._make_ae_nx_sec("ae-2", "b2", branch_side=1)]
    co_flat_list = [S._make_contingency_nx_sec("co-1", list(contingency_equipment))]
    fake_pp = S.DummyPypowsyblModule(
        post_contingency_results={"co-1": S.DummyPostContingencyResult("CONVERGED")},
        branch_results=S._branch_results_df(rows),
    )
    monkeypatch.setitem(sys.modules, "pypowsybl", fake_pp)
    return compute_lf_nx(object(), co_flat_list, ae_flat_list, "1030Z")


def test_a_nan_current_in_the_security_analysis_is_left_out_of_lf_nx_with_a_warning(monkeypatch, caplog):
    rows = [{"contingency_id": "co-1", "branch_id": "b1", "i1": 100.0, "i2": 90.0},
            {"contingency_id": "co-1", "branch_id": "b2", "i1": float("nan"), "i2": 60.0}]
    with caplog.at_level(logging.WARNING):
        lf_nx, skipped = _compute_lf_nx_with(monkeypatch, rows)
    assert lf_nx == {"co-1": {"b1": {1: 100.0, 2: 90.0}}}
    messages = [r.message for r in caplog.records if r.levelno == logging.WARNING and "co-1" in r.message]
    assert any("1 branch" in m and "b2" in m for m in messages)


def test_the_contingencys_own_tripped_branch_gets_no_zero_entry(monkeypatch):
    rows = [{"contingency_id": "co-1", "branch_id": "b1", "i1": 100.0, "i2": 90.0}]
    lf_nx, skipped = _compute_lf_nx_with(monkeypatch, rows, contingency_equipment=("b2",))
    assert skipped == {}
    assert lf_nx == {"co-1": {"b1": {1: 100.0, 2: 90.0}}}


# ===========================================================================
# Scanned branches
# ===========================================================================

# ---------------------------------------------------------------------------
# scanned branches in the sensitivity candidate-set helper
# ---------------------------------------------------------------------------

def test_get_monitored_branch_sides_nx_already_includes_scanned_branches():
    """_get_monitored_branch_sides returns both SECURED and SCANNED branches (the real data
    has no scanned AE, the code path exists)."""
    from milp.milp_builder import _get_monitored_branch_sides

    ae_list = [
        _make_ae_nx_filters_and_scanned_elements("ae1", "B1", branch_side=1, ae_type=AEType.SECURED),
        _make_ae_nx_filters_and_scanned_elements("ae2", "B2", branch_side=2, ae_type=AEType.SCANNED),
    ]
    result = _get_monitored_branch_sides(ae_list)
    assert result == {"B1": 1, "B2": 2}


def test_a_current_that_is_not_a_number_is_an_error_not_a_missing_current(monkeypatch):
    rows = [{"contingency_id": "co-1", "branch_id": "b1", "i1": "not a number", "i2": 90.0},
            {"contingency_id": "co-1", "branch_id": "b2", "i1": 50.0, "i2": 60.0}]
    with pytest.raises(ValueError):
        _compute_lf_nx_with(monkeypatch, rows)

# ===========================================================================
# One-pass read-back of the security analysis = the per-contingency selection
# ===========================================================================

def _lf_nx_by_selection(result, contingencies, expected_branch_ids):
    """The per-contingency read-back: a boolean selection of the contingency's rows, then
    .xs(branch).iloc[0] per monitored branch (reference for the one-pass read-back)."""
    from pre_milp.nx_security_analysis import _contingency_result_is_usable
    lf_nx, skipped = {}, {}
    for contingency in contingencies:
        post = result.post_contingency_results.get(contingency.mrid)
        if post is None:
            skipped[contingency.mrid] = "no post-contingency result returned"
            continue
        status_name = str(getattr(post.status, "name", post.status))
        rows = result.branch_results.loc[
            result.branch_results.index.get_level_values("contingency_id") == contingency.mrid
        ]
        usable, reason = _contingency_result_is_usable(
            contingency, status_name, set(rows.index.get_level_values("branch_id")), expected_branch_ids,
        )
        if not usable:
            skipped[contingency.mrid] = reason
            continue
        per_branch = {}
        for branch_mrid in sorted(expected_branch_ids):
            try:
                row = rows.xs(branch_mrid, level="branch_id")
                i1, i2 = float(row["i1"].iloc[0]), float(row["i2"].iloc[0])
            except (KeyError, IndexError):
                continue
            if i1 != i1 or i2 != i2:
                continue
            per_branch[branch_mrid] = {1: i1, 2: i2}
        lf_nx[contingency.mrid] = per_branch
    return lf_nx, skipped


def test_one_pass_read_back_equals_the_selection_on_duplicates_nan_missing_and_failures(monkeypatch):
    import helpers as S
    from pre_milp.nx_security_analysis import compute_lf_nx
    rows = [
        {"contingency_id": "", "branch_id": "b1", "i1": 10.0, "i2": 11.0},          # base case
        {"contingency_id": "co-1", "branch_id": "b1", "i1": 100.0, "i2": 90.0},
        {"contingency_id": "co-1", "branch_id": "b1", "i1": 999.0, "i2": 999.0},    # duplicate: first wins
        {"contingency_id": "co-1", "branch_id": "b2", "i1": float("nan"), "i2": 60.0},
        {"contingency_id": "co-1", "branch_id": "b3", "i1": 30.0, "i2": 31.0},
        {"contingency_id": "co-2", "branch_id": "b1", "i1": 50.0, "i2": 51.0},      # b2 missing -> split
        {"contingency_id": "co-3", "branch_id": "b1", "i1": 70.0, "i2": 71.0},      # b2 is its own trip
        {"contingency_id": "co-3", "branch_id": "b3", "i1": 72.0, "i2": 73.0},
        {"contingency_id": "co-4", "branch_id": "b1", "i1": 1.0, "i2": 2.0},        # non-convergent
    ]
    result = S.DummySecurityAnalysisResult(
        post_contingency_results={
            "co-1": S.DummyPostContingencyResult("CONVERGED"), "co-2": S.DummyPostContingencyResult("CONVERGED"),
            "co-3": S.DummyPostContingencyResult("NO_IMPACT"), "co-4": S.DummyPostContingencyResult("FAILED"),
        },
        branch_results=S._branch_results_df(rows),
    )
    ae_flat_list = [S._make_ae_nx_sec(f"ae-{b}", b, branch_side=1) for b in ("b1", "b2", "b3")]
    co_flat_list = [S._make_contingency_nx_sec("co-1", ["eq-1"]), S._make_contingency_nx_sec("co-2", ["eq-2"]),
                    S._make_contingency_nx_sec("co-3", ["b2"]), S._make_contingency_nx_sec("co-4", ["eq-4"]),
                    S._make_contingency_nx_sec("co-5", ["eq-5"])]
    fake_pp = S.DummyPypowsyblModule(post_contingency_results=result.post_contingency_results,
                                     branch_results=result.branch_results)
    monkeypatch.setitem(sys.modules, "pypowsybl", fake_pp)

    lf_nx, skipped = compute_lf_nx(object(), co_flat_list, ae_flat_list, "1030Z")

    assert (lf_nx, skipped) == _lf_nx_by_selection(result, co_flat_list, {"b1", "b2", "b3"})
    assert lf_nx["co-1"] == {"b1": {1: 100.0, 2: 90.0}, "b3": {1: 30.0, 2: 31.0}}


def test_one_pass_read_back_equals_the_selection_on_a_real_security_analysis():
    """IEEE 14, every line as a contingency, every branch monitored."""
    import pypowsybl as pp
    import helpers as S
    from pre_milp.lf_parameters import build_security_analysis_parameters
    from pre_milp.nx_security_analysis import compute_lf_nx, _register_contingencies

    network = pp.network.create_ieee14()
    lines = list(network.get_lines().index)
    branches = lines + list(network.get_2_windings_transformers().index)
    ae_flat_list = [S._make_ae_nx_sec(f"ae-{b}", b, branch_side=1) for b in branches]
    co_flat_list = [S._make_contingency_nx_sec(f"co-{line}", [line]) for line in lines]

    lf_nx, skipped = compute_lf_nx(network, co_flat_list, ae_flat_list, "1030Z")

    analysis = pp.security.create_analysis()
    contingencies = sorted(co_flat_list, key=lambda c: c.mrid)
    _register_contingencies(analysis, contingencies)
    analysis.add_monitored_elements(branch_ids=sorted(branches))
    result = analysis.run_ac(network, parameters=build_security_analysis_parameters(False, None))
    assert (lf_nx, skipped) == _lf_nx_by_selection(result, contingencies, set(branches))
    assert len(lf_nx) > 10
