"""tests/test_rao_nx_export_values.py - the N-X results export reads each solved value of the model once instead of
evaluating the Pyomo variables again for every branch and contingency row; the linearised effect is the same number,
and the export of a generated set (many units, many rows) stays within a time budget."""

import time

import pyomo.environ as pyo
import pytest

from post_milp import nx_results_export as export


def _solved_model(pst_count=4, unit_count=150):
    model = pyo.ConcreteModel()
    model.pst_ids = pyo.Set(initialize=[f"PST{i}" for i in range(pst_count)])
    model.tap_change_upward = pyo.Var(model.pst_ids, initialize=lambda m, p: 1.0 + int(p[3:]) * 0.25)
    model.tap_change_downward = pyo.Var(model.pst_ids, initialize=lambda m, p: 0.5)
    model.gu_ids = pyo.Set(initialize=[f"GU{i:03d}" for i in range(unit_count)])
    model.rd_up = pyo.Var(model.gu_ids, initialize=lambda m, g: 2.0 + int(g[2:]) * 0.1)
    model.rd_down = pyo.Var(model.gu_ids, initialize=lambda m, g: 0.3)
    model.rd_net_injection_g = pyo.Expression(model.gu_ids, rule=lambda m, g: m.rd_up[g] - m.rd_down[g])
    return model


def _sensitivities(model):
    pst = {("B1", p): 0.01 * (i + 1) for i, p in enumerate(model.pst_ids)}
    rd = {("B1", g): (0.002 * i if i % 3 else 0.0) for i, g in enumerate(model.gu_ids)}      # a third are exactly zero
    return {"C1": pst}, {"C1": rd}


@pytest.mark.parametrize("include_curative", [False, True])
def test_rao_the_effect_is_the_same_number_with_values_read_once_or_each_time(include_curative):
    model = _solved_model()
    pst, rd = _sensitivities(model)
    degrees = {p: 0.5 + 0.1 * i for i, p in enumerate(model.pst_ids)}
    each_time = export._linearised_pst_rd_effect(model, "B1", "C1", pst, rd, degrees, include_curative)
    solved = export._SolvedValues(model)
    once = [export._linearised_pst_rd_effect(model, "B1", "C1", pst, rd, degrees, include_curative, solved=solved)
            for _ in range(3)]
    assert once == [each_time] * 3                                       # exactly equal, not approximately
    expected = 0.0
    for p in model.pst_ids:
        expected += pst[("C1")][("B1", p)] * degrees[p] * (pyo.value(model.tap_change_upward[p]) - pyo.value(model.tap_change_downward[p]))
    for g in model.gu_ids:
        if rd["C1"][("B1", g)] != 0.0:
            expected += rd["C1"][("B1", g)] * pyo.value(model.rd_net_injection_g[g])
    assert each_time == expected


def test_rao_only_the_used_values_are_evaluated_and_each_once():
    model = _solved_model(pst_count=2, unit_count=6)
    solved = export._SolvedValues(model)
    assert solved.tap_change("PST1") == pyo.value(model.tap_change_upward["PST1"]) - pyo.value(model.tap_change_downward["PST1"])
    assert set(solved._tap_change) == {"PST1"} and solved._rd_net_injection == {}
    first = solved.rd_net_injection("GU002")
    model.rd_up["GU002"].set_value(99.0)                 # a later change of the model is not seen: read once
    assert solved.rd_net_injection("GU002") == first


def test_rao_the_effect_of_many_rows_is_computed_within_the_budget():
    """3000 rows x 600 units with a third of the sensitivities zero: the effect used to evaluate a Pyomo expression for
    every non-zero sensitivity of every row (4.5 s on the development machine, against 0.3 s now). Budget: 2 s."""
    model = _solved_model(pst_count=4, unit_count=600)
    pst, rd = _sensitivities(model)
    degrees = {p: 1.0 for p in model.pst_ids}
    solved = export._SolvedValues(model)
    start = time.perf_counter()
    values = [export._linearised_pst_rd_effect(model, "B1", "C1", pst, rd, degrees, True, solved=solved) for _ in range(3000)]
    seconds = time.perf_counter() - start
    print(f"3000 rows x 600 units: {seconds:.2f} s")
    assert len(set(values)) == 1
    assert seconds < 2
