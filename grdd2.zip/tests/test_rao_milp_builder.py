"""tests/test_rao_milp_builder.py - tests for milp_builder.py: core model, results, RA limits
and groups, scanned elements, N-0 inputs with zero PATL or a NaN current, and a solve with a
scanned branch (real Pyomo, so not in test_rao_milp_solver.py, whose autouse fixture
replaces pyomo.environ). The PST, RD and N-X blocks have their own files.
"""

import sys
import types
import pytest
import pyomo.environ as pyo
import logging

from pathlib import Path
from data_model import (
    AEType,
    AssessedElement,
    PST,
    RAKind,
    BidDirection,
    PowerBid,
    RDUnit,
    AcVerificationStatus,
)
from milp.milp_builder import build_n0_milp_model, PstMilpInputs, RdMilpInputs
from post_milp.n0_results_export import (
    extract_rd_results,
    extract_results_summary,
    extract_results_generating_units,
)
from helpers import (
    _make_ae_mb_results as _make_ae,
    _make_bid,
    _make_rd_unit,
    _make_ae_mb_scanned as _make_ae_milp_builder_scanned_elements,
    _make_pst_mb_scanned as _make_pst_milp_builder_scanned_elements,
)
from milp.milp_solver import solve_n0_milp_model
from text_encoding import TEXT_ENCODING  # noqa: E402

class DummyPyomoExpression:
    def __init__(self, left, right=None, op=None):
        self.left = left
        self.right = right
        self.op = op

    def __add__(self, other):
        return DummyPyomoExpression(self, other, "+")

    def __radd__(self, other):
        return DummyPyomoExpression(other, self, "+")

    def __sub__(self, other):
        return DummyPyomoExpression(self, other, "-")

    def __rsub__(self, other):
        return DummyPyomoExpression(other, self, "-")

    def __mul__(self, other):
        return DummyPyomoExpression(self, other, "*")

    def __rmul__(self, other):
        return DummyPyomoExpression(other, self, "*")

    def __le__(self, other):
        return DummyPyomoExpression(self, other, "<=")

    def __ge__(self, other):
        return DummyPyomoExpression(self, other, ">=")

    def __eq__(self, other):
        return DummyPyomoExpression(self, other, "==")


class DummyPyomoVar:
    def __init__(self, *args, domain=None):
        self.domain = domain
        self._items = {}

    def __getitem__(self, key):
        if key not in self._items:
            self._items[key] = DummyPyomoVar(domain=self.domain)
        return self._items[key]

    def __add__(self, other):
        return DummyPyomoExpression(self, other, "+")

    def __radd__(self, other):
        return DummyPyomoExpression(other, self, "+")

    def __sub__(self, other):
        return DummyPyomoExpression(self, other, "-")

    def __rsub__(self, other):
        return DummyPyomoExpression(other, self, "-")

    def __mul__(self, other):
        return DummyPyomoExpression(self, other, "*")

    def __rmul__(self, other):
        return DummyPyomoExpression(other, self, "*")

    def __le__(self, other):
        return DummyPyomoExpression(self, other, "<=")

    def __ge__(self, other):
        return DummyPyomoExpression(self, other, ">=")

    def __eq__(self, other):
        return DummyPyomoExpression(self, other, "==")


class DummyPyomoSet(list):
    def __init__(self, initialize=None, dimen=1):
        super().__init__(initialize if initialize is not None else [])
        self.dimen = dimen


class DummyPyomoConstraint:
    def __init__(self, *args, rule=None):
        self.rule = rule


class DummyPyomoExpressionComponent:
    """Fake for the pyo.Expression(index_set, rule=...) COMPONENT (DummyPyomoExpression above
    fakes the arithmetic nodes). Stores the rule without evaluating it: the fake harness only
    checks structural presence, never solved values.
    """
    def __init__(self, *args, rule=None):
        self.rule = rule


class DummyPyomoObjective:
    def __init__(self, expr=None, sense=None):
        self.expr = expr
        self.sense = sense


class DummyPyomoModule:
    class NonNegativeIntegers:
        pass

    class NonNegativeReals:
        pass

    class minimize:
        pass

    class Set(DummyPyomoSet):
        pass

    class Var(DummyPyomoVar):
        def __init__(self, *args, domain=None):
            super().__init__(domain=domain)

    class Constraint(DummyPyomoConstraint):
        def __init__(self, *args, rule=None):
            super().__init__(rule=rule)

    class Expression(DummyPyomoExpressionComponent):
        def __init__(self, *args, rule=None):
            super().__init__(rule=rule)

    class Objective(DummyPyomoObjective):
        def __init__(self, expr=None, sense=None):
            super().__init__(expr=expr, sense=sense)

    class ConcreteModel:
        def __init__(self):
            self.tap_change_upward = None
            self.tap_change_downward = None
            self.overload_slack_n0 = None
            self.tap_upper_bound = None
            self.tap_lower_bound = None
            self.pst_group_equality = None
            self.xne_loading_n0 = None
            self.objective = None


@pytest.fixture
def fake_pyomo(monkeypatch):
    # not autouse: the real-pyomo tests later in this file must not get this fake
    fake_module = DummyPyomoModule()
    fake_environ = fake_module
    fake_pyomo_pkg = types.ModuleType("pyomo")
    fake_environ_pkg = types.ModuleType("pyomo.environ")

    for name in [
        "NonNegativeIntegers",
        "NonNegativeReals",
        "minimize",
        "Set",
        "Var",
        "Constraint",
        "Expression",
        "Objective",
        "ConcreteModel",
    ]:
        setattr(fake_module, name, getattr(DummyPyomoModule, name))
        setattr(fake_environ_pkg, name, getattr(DummyPyomoModule, name))

    monkeypatch.setitem(sys.modules, "pyomo", fake_pyomo_pkg)
    monkeypatch.setitem(sys.modules, "pyomo.environ", fake_environ_pkg)
    return fake_module


def _make_pst_dummy(mrid="p1", **overrides):
    defaults = dict(
        mrid=mrid, name="PST 1", tso="TSO", available=True, kind=RAKind.PREVENTIVE,
        penalty_factor=1.0, low_step=-10, high_step=10, r0=0,
        operating_tap_min=-10, operating_tap_max=10, group_id=None,
    )
    defaults.update(overrides)
    return PST(**defaults)


def _make_ae_dummy(branch_mrid="b1", branch_side=1, **overrides):
    defaults = dict(
        mrid="ae1", name="AE 1", tso="TSO", ae_type=AEType.SECURED,
        branch_mrid=branch_mrid, secured_for_region=None, scanned_for_region=None,
        exclusion_reason=None, patl_ka={"1030Z": 1.2}, branch_side=branch_side,
    )
    defaults.update(overrides)
    return AssessedElement(**defaults)


def test_build_n0_milp_model_constructs_expected_components(fake_pyomo):
    pst_list = [_make_pst_dummy("p1")]
    ae_flat_list = [_make_ae_dummy("b1", branch_side=1)]
    lf_initial = {"b1": {1: 900.0, 2: 850.0}}
    pst_tap_bounds = {"p1": (-10, 10)}
    sensitivity_pst_n0 = {("b1", "p1"): 1.0}
    pst_group_equality_pairs = []
    pst_degrees_per_tap = {"p1": 2.0}

    # PST-only path: only pst_inputs=PstMilpInputs(...) is passed
    pst_inputs = PstMilpInputs(
        pst_list=pst_list,
        pst_tap_bounds=pst_tap_bounds,
        pst_group_equality_pairs=pst_group_equality_pairs,
        sensitivity_pst_n0_pruned=sensitivity_pst_n0,
        pst_degrees_per_tap=pst_degrees_per_tap,
        penalty_reference_pst_pra=100.0,
    )

    model = build_n0_milp_model(
        ae_flat_list,
        "1030Z",
        lf_initial,
        penalty_cost_overload_n0=1000.0,
        pst_inputs=pst_inputs,
    )

    assert model.pst_ids == ["p1"]
    assert model.branch_ids == ["b1"]
    assert isinstance(model.tap_change_upward, DummyPyomoVar)
    assert isinstance(model.tap_change_downward, DummyPyomoVar)
    assert isinstance(model.overload_slack_n0, DummyPyomoVar)
    assert isinstance(model.tap_upper_bound, DummyPyomoConstraint)
    assert isinstance(model.tap_lower_bound, DummyPyomoConstraint)
    assert isinstance(model.xne_loading_n0, DummyPyomoConstraint)
    assert isinstance(model.objective, DummyPyomoObjective)


def test_build_n0_milp_model_requires_pst_list(fake_pyomo):
    pst_inputs = PstMilpInputs(
        pst_list=[],
        pst_tap_bounds={},
        pst_group_equality_pairs=[],
        sensitivity_pst_n0_pruned={},
        pst_degrees_per_tap={},
        penalty_reference_pst_pra=100.0,
    )
    with pytest.raises(ValueError, match="PST list is empty"):
        build_n0_milp_model(
            [],
            "1030Z",
            {},
            penalty_cost_overload_n0=1000.0,
            pst_inputs=pst_inputs,
        )


def test_branch_is_above_threshold_uses_resolved_side():
    """A branch on side 2 whose side-1 current would exceed the loading threshold and whose
    side-2 current does not is excluded: its resolved side is used, not side 1."""
    from milp.milp_builder import _branch_is_above_threshold

    lf_initial = {"b1": {1: 999.0, 2: 10.0}}  # side 1 "hot", side 2 "cold"
    branch_patls = {"b1": 1000.0}
    branch_sides = {"b1": 2}

    result = _branch_is_above_threshold(
        "b1", lf_initial, branch_patls, branch_sides, min_loading_threshold_pct=50.0,
    )
    # side 2 current (10A) / patl (1000A) = 1% loading, below 50% threshold
    assert result is False


def test_branch_is_above_threshold_defaults_to_side_1():
    from milp.milp_builder import _branch_is_above_threshold

    lf_initial = {"b1": {1: 900.0}}
    branch_patls = {"b1": 1000.0}
    branch_sides = {}  # b1 not present -> defaults to side 1

    result = _branch_is_above_threshold(
        "b1", lf_initial, branch_patls, branch_sides, min_loading_threshold_pct=50.0,
    )
    assert result is True


def test_missing_pst_degrees_per_tap_excludes_pst_from_tap_effect(fake_pyomo):
    """A PST missing from pst_degrees_per_tap must be excluded from the
    tap_effect sum for every branch (its sensitivity cannot be safely
    applied without the unit conversion) rather than silently defaulting
    to a wrong conversion factor."""
    pst_list = [_make_pst_dummy("p1"), _make_pst_dummy("p2")]
    ae_flat_list = [_make_ae_dummy("b1", branch_side=1)]
    lf_initial = {"b1": {1: 900.0}}
    pst_tap_bounds = {"p1": (-10, 10), "p2": (-10, 10)}
    sensitivity_pst_n0 = {("b1", "p1"): 1.0, ("b1", "p2"): 1.0}
    pst_degrees_per_tap = {"p1": 2.0}  # p2 deliberately missing

    pst_inputs = PstMilpInputs(
        pst_list=pst_list,
        pst_tap_bounds=pst_tap_bounds,
        pst_group_equality_pairs=[],
        sensitivity_pst_n0_pruned=sensitivity_pst_n0,
        pst_degrees_per_tap=pst_degrees_per_tap,
        penalty_reference_pst_pra=100.0,
    )

    model = build_n0_milp_model(
        ae_flat_list,
        "1030Z",
        lf_initial,
        penalty_cost_overload_n0=1000.0,
        pst_inputs=pst_inputs,
    )
    # Both PSTs still get tap decision variables (bounds still apply to p2)
    # even though only p1 contributes to the xne_loading_n0 tap_effect sum.
    assert model.pst_ids == ["p1", "p2"]


REPO_SRC = Path(__file__).resolve().parents[1] / "src" / "rao"


def _make_ae_real(branch_mrid: str, side: int, patl_ka: float, timestamp: str = "1030Z") -> AssessedElement:
    return AssessedElement(
        mrid=f"AE_{branch_mrid}", name=f"AE {branch_mrid}", tso="TestTSO",
        ae_type=AEType.SECURED, branch_mrid=branch_mrid,
        secured_for_region=None, scanned_for_region=None, exclusion_reason=None,
        patl_ka={timestamp: patl_ka}, branch_side=side,
    )


def _make_pst_real(mrid: str, r0: int = 0) -> PST:
    return PST(
        mrid=mrid, name=mrid, tso="TestTSO", available=True, kind=RAKind.PREVENTIVE,
        penalty_factor=1.0, low_step=-10, high_step=10, r0=r0,
        operating_tap_min=-10, operating_tap_max=10, group_id=None,
    )


def _make_rd_unit_real(mrid: str, gu_mrid: str) -> RDUnit:
    return RDUnit(
        mrid=mrid, name=mrid, tso="TestTSO", gu_mrid=gu_mrid, gu_name=gu_mrid,
        available=True, kind=RAKind.PREVENTIVE, initial_p=50.0, max_p=100.0, min_p=0.0,
        raise_ramp_rate=None, lower_ramp_rate=None,
    )


def _make_bid_real(mrid: str, ra_mrid: str, direction: BidDirection, available_mw: dict) -> PowerBid:
    return PowerBid(
        mrid=mrid, ra_mrid=ra_mrid, direction=direction, available_mw=available_mw,
        price_eur_mw=10.0, penalty_factor=0.0, lead_time_h=0.0,
        activation_cost_eur=None, min_energy_mwh=None, max_energy_mwh=None, step_size_mw=None,
    )


# ---------------------------------------------------------------------------
# Both-None guard
# ---------------------------------------------------------------------------

def test_both_inputs_none_raises_before_model_creation():
    """Given neither pst_inputs nor rd_inputs is provided, When
    build_n0_milp_model is called, Then a ValueError is raised."""
    ae_list = [_make_ae_real("BRANCH1", side=1, patl_ka=1.0)]
    with pytest.raises(ValueError, match="At least one"):
        build_n0_milp_model(
            ae_list, "1030Z", lf_initial={"BRANCH1": {1: 500.0}},
            penalty_cost_overload_n0=1000.0,
        )


# ---------------------------------------------------------------------------
# PST-only workflow
# ---------------------------------------------------------------------------

def test_pst_only_has_zero_rd_components():
    """Given only pst_inputs is provided, When build_n0_milp_model is called,
    Then the model has no RD Var/Constraint/Expression components at all."""
    ae_list = [_make_ae_real("BRANCH1", side=1, patl_ka=1.0)]
    pst_inputs = PstMilpInputs(
        pst_list=[_make_pst_real("PST1")],
        pst_tap_bounds={"PST1": (-10, 10)},
        pst_group_equality_pairs=[],
        sensitivity_pst_n0_pruned={("BRANCH1", "PST1"): 5.0},
        pst_degrees_per_tap={"PST1": 1.5},
        penalty_reference_pst_pra=10.0,
    )

    model = build_n0_milp_model(
        ae_list, "1030Z", lf_initial={"BRANCH1": {1: 500.0}},
        penalty_cost_overload_n0=1000.0, pst_inputs=pst_inputs,
    )

    assert not hasattr(model, "rd_volume_upward")
    assert not hasattr(model, "rd_volume_downward")
    assert not hasattr(model, "rd_net_injection_g")
    assert not hasattr(model, "rd_effect_on_branch")
    assert not hasattr(model, "pmax_pmin_constraint")
    assert not hasattr(model, "bid_ids")
    assert hasattr(model, "tap_change_upward")
    assert hasattr(model, "pst_effect_on_branch")


def test_pst_only_solves_to_expected_tap_change():
    """A single overloaded branch resolvable only by one PST: the PST-only model solved with
    appsi_highs activates exactly enough upward tap change at minimum cost (hand-verified)."""
    # Branch loaded at 1050 A against a 1000 A PATL -> 50 A overload.
    # PST sensitivity: 10 A per tap-degree-equivalent (after deg_per_tap
    # folded in) -> need >= 5 tap-steps upward to clear it exactly.
    ae_list = [_make_ae_real("BRANCH1", side=1, patl_ka=1.0)]
    pst_inputs = PstMilpInputs(
        pst_list=[_make_pst_real("PST1", r0=0)],
        pst_tap_bounds={"PST1": (-10, 10)},
        pst_group_equality_pairs=[],
        sensitivity_pst_n0_pruned={("BRANCH1", "PST1"): -10.0},  # A per (degree * tap)
        pst_degrees_per_tap={"PST1": 1.0},
        penalty_reference_pst_pra=1.0,
    )

    model = build_n0_milp_model(
        ae_list, "1030Z", lf_initial={"BRANCH1": {1: 1050.0}},
        penalty_cost_overload_n0=1000.0, pst_inputs=pst_inputs,
    )

    solver = pyo.SolverFactory("appsi_highs")
    result = solver.solve(model)
    assert str(result.solver.termination_condition) in ("optimal", "TerminationCondition.optimal")

    tap_up = pyo.value(model.tap_change_upward["PST1"])
    tap_down = pyo.value(model.tap_change_downward["PST1"])
    overload_slack = pyo.value(model.overload_slack_n0["BRANCH1"])

    # 1050 + (-10 * 1.0 * (tap_up - tap_down)) <= 1000 -> tap_up - tap_down >= 5
    assert (tap_up - tap_down) >= 5.0 - 1e-6
    assert overload_slack < 1e-6


# ---------------------------------------------------------------------------
# RD-only workflow
# ---------------------------------------------------------------------------

def test_rd_only_has_zero_pst_components():
    """Given only rd_inputs is provided, When build_n0_milp_model is called,
    Then the model has no PST Var/Constraint/Expression components at all."""
    ae_list = [_make_ae_real("BRANCH1", side=1, patl_ka=1.0)]
    rd_inputs = RdMilpInputs(
        rd_list=[_make_rd_unit_real("RA1", "GU1")],
        bid_list=[_make_bid_real("BID1", "RA1", BidDirection.UP, {"1030Z": 20.0})],
        glsk={"RA1": {"GU1": 1.0}},
        sensitivity_rd_n0_pruned={("BRANCH1", "GU1"): -5.0},
        generator_data={"GU1": {"target_p": 50.0, "max_p": 100.0, "min_p": 0.0, "name": "GU1"}},
    )

    model = build_n0_milp_model(
        ae_list, "1030Z", lf_initial={"BRANCH1": {1: 500.0}},
        penalty_cost_overload_n0=1000.0, rd_inputs=rd_inputs,
    )

    assert not hasattr(model, "tap_change_upward")
    assert not hasattr(model, "tap_change_downward")
    assert not hasattr(model, "pst_effect_on_branch")
    assert not hasattr(model, "pst_ids")
    assert hasattr(model, "rd_volume_upward")
    assert hasattr(model, "rd_net_injection_g")
    assert hasattr(model, "pmax_pmin_constraint")


def test_rd_only_bid_direction_bounds():
    """Given one UP bid and one DOWN bid, When the model is built, Then the
    UP bid's rd_volume_downward is bounded to 0 and vice versa — each
    PowerBidSchedule contributes in its own direction only."""
    ae_list = [_make_ae_real("BRANCH1", side=1, patl_ka=1.0)]
    rd_inputs = RdMilpInputs(
        rd_list=[_make_rd_unit_real("RA1", "GU1"), _make_rd_unit_real("RA1", "GU2")],
        bid_list=[
            _make_bid_real("BID_UP", "RA1", BidDirection.UP, {"1030Z": 15.0}),
            _make_bid_real("BID_DOWN", "RA1", BidDirection.DOWN, {"1030Z": 25.0}),
        ],
        glsk={"RA1": {"GU1": 0.5, "GU2": 0.5}},
        sensitivity_rd_n0_pruned={("BRANCH1", "GU1"): -5.0, ("BRANCH1", "GU2"): -5.0},
        generator_data={
            "GU1": {"target_p": 50.0, "max_p": 100.0, "min_p": 0.0, "name": "GU1"},
            "GU2": {"target_p": 50.0, "max_p": 100.0, "min_p": 0.0, "name": "GU2"},
        },
    )

    model = build_n0_milp_model(
        ae_list, "1030Z", lf_initial={"BRANCH1": {1: 500.0}},
        penalty_cost_overload_n0=1000.0, rd_inputs=rd_inputs,
    )

    assert model.rd_volume_upward["BID_UP"].ub == 15.0
    assert model.rd_volume_downward["BID_UP"].ub == 0.0
    assert model.rd_volume_upward["BID_DOWN"].ub == 0.0
    assert model.rd_volume_downward["BID_DOWN"].ub == 25.0


def test_rd_only_solves_and_resolves_overload_via_dispatch():
    """A branch overload fixable only by RD: the RD-only model dispatches enough upward volume
    and rd_net_injection_g reflects it. GU2 (zero sensitivity) is the balancing partner: with
    one unit the balance constraint forces its net injection to 0."""
    ae_list = [_make_ae_real("BRANCH1", side=1, patl_ka=1.0)]
    rd_inputs = RdMilpInputs(
        rd_list=[_make_rd_unit_real("RA1", "GU1"), _make_rd_unit_real("RA2", "GU2")],
        bid_list=[
            _make_bid_real("BID1", "RA1", BidDirection.UP, {"1030Z": 20.0}),
            _make_bid_real("BID2", "RA2", BidDirection.DOWN, {"1030Z": 20.0}),
        ],
        glsk={"RA1": {"GU1": 1.0}, "RA2": {"GU2": 1.0}},
        sensitivity_rd_n0_pruned={("BRANCH1", "GU1"): -10.0},  # A per MW; GU2 has no entry (0 sensitivity)
        generator_data={
            "GU1": {"target_p": 50.0, "max_p": 100.0, "min_p": 0.0, "name": "GU1"},
            "GU2": {"target_p": 50.0, "max_p": 100.0, "min_p": 0.0, "name": "GU2"},
        },
    )

    # 1050 A against 1000 A PATL -> 50 A overload; need >= 5 MW upward
    model = build_n0_milp_model(
        ae_list, "1030Z", lf_initial={"BRANCH1": {1: 1050.0}},
        penalty_cost_overload_n0=1000.0, rd_inputs=rd_inputs,
    )

    solver = pyo.SolverFactory("appsi_highs")
    result = solver.solve(model)
    assert str(result.solver.termination_condition) in ("optimal", "TerminationCondition.optimal")

    rd_volume_up = pyo.value(model.rd_volume_upward["BID1"])
    overload_slack = pyo.value(model.overload_slack_n0["BRANCH1"])
    net_injection = pyo.value(model.rd_net_injection_g["GU1"])

    assert rd_volume_up >= 5.0 - 1e-6
    assert overload_slack < 1e-6
    assert abs(net_injection - rd_volume_up) < 1e-6  # single unit, factor=1.0


def test_rd_only_pmax_pmin_constrains_dispatch():
    """GU1 at target_p=95 MW with max_p=100 MW: rd_net_injection_g respects the 5 MW headroom
    although more RD would help. GU2 (target_p=20, max_p=100) is the balancing partner, GU1
    the Pmax-limited side."""
    ae_list = [_make_ae_real("BRANCH1", side=1, patl_ka=1.0)]
    rd_inputs = RdMilpInputs(
        rd_list=[_make_rd_unit_real("RA1", "GU1"), _make_rd_unit_real("RA2", "GU2")],
        bid_list=[
            _make_bid_real("BID1", "RA1", BidDirection.UP, {"1030Z": 50.0}),
            _make_bid_real("BID2", "RA2", BidDirection.DOWN, {"1030Z": 50.0}),
        ],
        glsk={"RA1": {"GU1": 1.0}, "RA2": {"GU2": 1.0}},
        sensitivity_rd_n0_pruned={("BRANCH1", "GU1"): -10.0},  # GU2 has no entry (0 sensitivity)
        generator_data={
            "GU1": {"target_p": 95.0, "max_p": 100.0, "min_p": 0.0, "name": "GU1"},
            "GU2": {"target_p": 20.0, "max_p": 100.0, "min_p": 0.0, "name": "GU2"},
        },
    )

    # Overload needs 20 MW upward to fully clear (200 A / 10 A per MW), but
    # Pmax only allows 5 MW of headroom on GU1 -> Pmax/Pmin should cap GU1's
    # dispatch at 5 MW, leaving some residual overload absorbed by
    # overload_slack_n0, regardless of GU2's much larger available headroom.
    model = build_n0_milp_model(
        ae_list, "1030Z", lf_initial={"BRANCH1": {1: 1200.0}},
        penalty_cost_overload_n0=1000.0, rd_inputs=rd_inputs,
    )

    solver = pyo.SolverFactory("appsi_highs")
    result = solver.solve(model)
    assert str(result.solver.termination_condition) in ("optimal", "TerminationCondition.optimal")

    net_injection = pyo.value(model.rd_net_injection_g["GU1"])
    assert net_injection <= 5.0 + 1e-6  # Pmax - target_p headroom
    assert net_injection >= 5.0 - 1e-6  # solver should push right up to the Pmax limit, since more relief is still valuable


# ---------------------------------------------------------------------------
# PST + RD together
# ---------------------------------------------------------------------------

def test_pst_and_rd_together_both_present_and_summed():
    """Given both pst_inputs and rd_inputs are provided, When the model is
    built, Then both PST and RD components exist AND xne_loading_n0 sums
    both effects (verified by solving a case only jointly resolvable)."""
    ae_list = [_make_ae_real("BRANCH1", side=1, patl_ka=1.0)]
    pst_inputs = PstMilpInputs(
        pst_list=[_make_pst_real("PST1", r0=0)],
        pst_tap_bounds={"PST1": (-3, 3)},  # deliberately small range
        pst_group_equality_pairs=[],
        sensitivity_pst_n0_pruned={("BRANCH1", "PST1"): -10.0},
        pst_degrees_per_tap={"PST1": 1.0},
        penalty_reference_pst_pra=1.0,
    )
    rd_inputs = RdMilpInputs(
        rd_list=[_make_rd_unit_real("RA1", "GU1"), _make_rd_unit_real("RA2", "GU2")],
        bid_list=[
            _make_bid_real("BID1", "RA1", BidDirection.UP, {"1030Z": 20.0}),
            _make_bid_real("BID2", "RA2", BidDirection.DOWN, {"1030Z": 20.0}),
        ],
        glsk={"RA1": {"GU1": 1.0}, "RA2": {"GU2": 1.0}},
        # GU2: balancing partner with 0 sensitivity to BRANCH1 (GU1 alone could not have a
        # non-zero net injection)
        sensitivity_rd_n0_pruned={("BRANCH1", "GU1"): -10.0},
        generator_data={
            "GU1": {"target_p": 50.0, "max_p": 100.0, "min_p": 0.0, "name": "GU1"},
            "GU2": {"target_p": 50.0, "max_p": 100.0, "min_p": 0.0, "name": "GU2"},
        },
    )

    # Overload needs 8 MW-equivalent to clear (800 A / 10 A per unit).
    # PST alone can only supply 3 tap-steps -> 30 A. RD must supply the rest.
    model = build_n0_milp_model(
        ae_list, "1030Z", lf_initial={"BRANCH1": {1: 1080.0}},
        penalty_cost_overload_n0=1000.0, pst_inputs=pst_inputs, rd_inputs=rd_inputs,
    )

    assert hasattr(model, "tap_change_upward")
    assert hasattr(model, "rd_volume_upward")

    solver = pyo.SolverFactory("appsi_highs")
    result = solver.solve(model)
    assert str(result.solver.termination_condition) in ("optimal", "TerminationCondition.optimal")

    overload_slack = pyo.value(model.overload_slack_n0["BRANCH1"])
    tap_up = pyo.value(model.tap_change_upward["PST1"])
    rd_up = pyo.value(model.rd_volume_upward["BID1"])

    assert overload_slack < 1e-6
    assert tap_up <= 3.0 + 1e-6  # PST capped by its own tap bound
    assert (tap_up * 10.0 + rd_up * 10.0) >= 80.0 - 1e-3  # jointly clears the 80 A overload


# ---------------------------------------------------------------------------
# Empty-GLSK / empty-bid guard
# ---------------------------------------------------------------------------

def test_rd_block_empty_glsk_guard_adds_nothing():
    """rd_inputs with an empty glsk (the real Belgovia shape): no RD Var, Constraint or
    Expression is added."""
    ae_list = [_make_ae_real("BRANCH1", side=1, patl_ka=1.0)]
    rd_inputs = RdMilpInputs(
        rd_list=[_make_rd_unit_real("RA1", "GU1")],
        bid_list=[_make_bid_real("BID1", "RA1", BidDirection.UP, {"1030Z": 20.0})],
        glsk={"RA1": {}},  # real dataset shape: RA present, empty participation
        sensitivity_rd_n0_pruned={("BRANCH1", "GU1"): -10.0},
        generator_data={"GU1": {"target_p": 50.0, "max_p": 100.0, "min_p": 0.0, "name": "GU1"}},
    )

    model = build_n0_milp_model(
        ae_list, "1030Z", lf_initial={"BRANCH1": {1: 500.0}},
        penalty_cost_overload_n0=1000.0, rd_inputs=rd_inputs,
    )

    assert not hasattr(model, "rd_volume_upward")
    assert not hasattr(model, "rd_net_injection_g")
    assert not hasattr(model, "pmax_pmin_constraint")


def test_rd_block_empty_bid_list_guard_adds_nothing():
    """Given rd_inputs is provided but bid_list is empty, When the model is
    built, Then no RD component is added."""
    ae_list = [_make_ae_real("BRANCH1", side=1, patl_ka=1.0)]
    rd_inputs = RdMilpInputs(
        rd_list=[_make_rd_unit_real("RA1", "GU1")],
        bid_list=[],
        glsk={"RA1": {"GU1": 1.0}},
        sensitivity_rd_n0_pruned={("BRANCH1", "GU1"): -10.0},
        generator_data={"GU1": {"target_p": 50.0, "max_p": 100.0, "min_p": 0.0, "name": "GU1"}},
    )

    model = build_n0_milp_model(
        ae_list, "1030Z", lf_initial={"BRANCH1": {1: 500.0}},
        penalty_cost_overload_n0=1000.0, rd_inputs=rd_inputs,
    )

    assert not hasattr(model, "rd_volume_upward")


# ===========================================================================
# Results
# ===========================================================================

def _make_pst(mrid: str, r0: int = 0, tso: str = "TestTSO", penalty_factor: float = 1.0) -> PST:
    return PST(
        mrid=mrid, name=mrid, tso=tso, available=True, kind=RAKind.PREVENTIVE,
        penalty_factor=penalty_factor, low_step=-10, high_step=10, r0=r0,
        operating_tap_min=-10, operating_tap_max=10, group_id=None,
    )


def test_pst_only_summary_reports_zero_rd_not_absent():
    """PST-only workflow: sum_rd_volume_upward_mw and sum_rd_volume_downward_mw are present as
    0.0, not omitted."""
    ae_list = [_make_ae("BRANCH1", side=1, patl_ka=1.0)]
    pst_inputs = PstMilpInputs(
        pst_list=[_make_pst("PST1")], pst_tap_bounds={"PST1": (-10, 10)},
        pst_group_equality_pairs=[], sensitivity_pst_n0_pruned={("BRANCH1", "PST1"): -10.0},
        pst_degrees_per_tap={"PST1": 1.0}, penalty_reference_pst_pra=10.0,
    )
    model = build_n0_milp_model(
        ae_list, "1030Z", lf_initial={"BRANCH1": {1: 1050.0}},
        penalty_cost_overload_n0=1000.0, pst_inputs=pst_inputs,
    )
    solver = pyo.SolverFactory("appsi_highs")
    solver.solve(model)

    summary = extract_results_summary(
        model, objective_value=pyo.value(model.objective),
        pst_list=pst_inputs.pst_list,
        penalty_reference_pst_pra=pst_inputs.penalty_reference_pst_pra,
    )

    assert "sum_rd_volume_upward_mw" in summary
    assert summary["sum_rd_volume_upward_mw"] == 0.0
    assert summary["sum_rd_volume_downward_mw"] == 0.0
    assert summary["sum_rd_cost_eur"] == 0.0
    assert summary["sum_rd_penalty_cost_eur"] == 0.0
    assert summary["sum_pst_penalty_cost_eur"] > 0.0  # PST WAS activated here


def test_rd_only_summary_reports_zero_pst_penalty():
    """Given an RD-only workflow, When results are exported, Then
    sum_pst_penalty_cost_eur == 0.0 (present, not absent)."""
    ae_list = [_make_ae("BRANCH1", side=1, patl_ka=1.0)]
    rd_inputs = RdMilpInputs(
        rd_list=[_make_rd_unit("RA1", "GU1"), _make_rd_unit("RA_BALANCE", "GU_BALANCE")],
        bid_list=[
            _make_bid("BID1", "RA1", BidDirection.UP, {"1030Z": 20.0}),
            _make_bid("BID_BALANCE", "RA_BALANCE", BidDirection.DOWN, {"1030Z": 20.0}),
        ],
        glsk={"RA1": {"GU1": 1.0}, "RA_BALANCE": {"GU_BALANCE": 1.0}},
        sensitivity_rd_n0_pruned={("BRANCH1", "GU1"): -10.0},
        generator_data={
            "GU1": {"target_p": 50.0, "max_p": 200.0, "min_p": 0.0, "name": "GU1"},
            "GU_BALANCE": {"target_p": 50.0, "max_p": 200.0, "min_p": 0.0, "name": "GU_BALANCE"},
        },
    )
    model = build_n0_milp_model(
        ae_list, "1030Z", lf_initial={"BRANCH1": {1: 1050.0}},
        penalty_cost_overload_n0=1000.0, rd_inputs=rd_inputs,
    )
    solver = pyo.SolverFactory("appsi_highs")
    solver.solve(model)

    rd_results = extract_rd_results(
        model, rd_list=rd_inputs.rd_list, bid_list=rd_inputs.bid_list,
        penalty_reference_rd_pra=0.0,
        ac_verification_status=AcVerificationStatus.CONVERGED,
        ac_verification_termination_reason="test fixture",
    )
    summary = extract_results_summary(
        model, objective_value=pyo.value(model.objective), rd_results=rd_results,
    )

    assert summary["sum_pst_penalty_cost_eur"] == 0.0
    assert summary["sum_rd_volume_upward_mw"] >= 5.0 - 1e-6


def test_balanced_dispatch_satisfies_acceptance_criterion_within_001mw():
    """Solved optimally with at least one RD unit activated:
    |sum_rd_volume_upward_mw - sum_rd_volume_downward_mw| < 0.01 MW."""
    ae_list = [_make_ae("BRANCH1", side=1, patl_ka=1.0)]
    rd_inputs = RdMilpInputs(
        rd_list=[_make_rd_unit("RA1", "GU1"), _make_rd_unit("RA_BALANCE", "GU_BALANCE")],
        bid_list=[
            _make_bid("BID1", "RA1", BidDirection.UP, {"1030Z": 20.0}),
            _make_bid("BID_BALANCE", "RA_BALANCE", BidDirection.DOWN, {"1030Z": 20.0}),
        ],
        glsk={"RA1": {"GU1": 1.0}, "RA_BALANCE": {"GU_BALANCE": 1.0}},
        sensitivity_rd_n0_pruned={("BRANCH1", "GU1"): -10.0},
        generator_data={
            "GU1": {"target_p": 50.0, "max_p": 200.0, "min_p": 0.0, "name": "GU1"},
            "GU_BALANCE": {"target_p": 50.0, "max_p": 200.0, "min_p": 0.0, "name": "GU_BALANCE"},
        },
    )
    model = build_n0_milp_model(
        ae_list, "1030Z", lf_initial={"BRANCH1": {1: 1050.0}},
        penalty_cost_overload_n0=1000.0, rd_inputs=rd_inputs,
    )
    solver = pyo.SolverFactory("appsi_highs")
    solver.solve(model)

    rd_results = extract_rd_results(
        model, rd_list=rd_inputs.rd_list, bid_list=rd_inputs.bid_list,
        penalty_reference_rd_pra=0.0,
        ac_verification_status=AcVerificationStatus.CONVERGED,
        ac_verification_termination_reason="test fixture",
    )
    summary = extract_results_summary(
        model, objective_value=pyo.value(model.objective), rd_results=rd_results,
    )

    assert abs(summary["sum_rd_volume_upward_mw"] - summary["sum_rd_volume_downward_mw"]) < 0.01


def test_remaining_overload_count_reflects_unresolved_branches():
    """Given a branch that cannot be fully resolved, When results are
    exported, Then remaining_overload_count is >= 1."""
    ae_list = [_make_ae("BRANCH1", side=1, patl_ka=1.0)]
    rd_inputs = RdMilpInputs(
        rd_list=[_make_rd_unit("RA1", "GU1")],
        bid_list=[_make_bid("BID1", "RA1", BidDirection.UP, {"1030Z": 1.0})],  # tiny cap
        glsk={"RA1": {"GU1": 1.0}},
        sensitivity_rd_n0_pruned={("BRANCH1", "GU1"): -10.0},
        generator_data={"GU1": {"target_p": 50.0, "max_p": 200.0, "min_p": 0.0, "name": "GU1"}},
    )
    # 50 A overload needs 5 MW; bid only offers 1 MW -> unresolved.
    model = build_n0_milp_model(
        ae_list, "1030Z", lf_initial={"BRANCH1": {1: 1050.0}},
        penalty_cost_overload_n0=1000.0, rd_inputs=rd_inputs,
    )
    solver = pyo.SolverFactory("appsi_highs")
    solver.solve(model)

    summary = extract_results_summary(model, objective_value=pyo.value(model.objective))
    assert summary["remaining_overload_count"] >= 1


def test_extract_results_generating_units_empty_when_rd_inactive(tmp_path):
    """Given RD components were never added (PST-only or empty-GLSK
    guard), When generating unit results are extracted, Then it returns
    {} AND still writes a header-only CSV."""
    ae_list = [_make_ae("BRANCH1", side=1, patl_ka=1.0)]
    pst_inputs = PstMilpInputs(
        pst_list=[_make_pst("PST1")], pst_tap_bounds={"PST1": (-10, 10)},
        pst_group_equality_pairs=[], sensitivity_pst_n0_pruned={("BRANCH1", "PST1"): 5.0},
        pst_degrees_per_tap={"PST1": 1.5}, penalty_reference_pst_pra=10.0,
    )
    model = build_n0_milp_model(
        ae_list, "1030Z", lf_initial={"BRANCH1": {1: 500.0}},
        penalty_cost_overload_n0=1000.0, pst_inputs=pst_inputs,
    )

    output_path = tmp_path / "results_generating_units.csv"
    result = extract_results_generating_units(
        model, rd_list=[], generator_data={}, output_path=output_path,
        ac_verification_status=AcVerificationStatus.CONVERGED,
        ac_verification_termination_reason="test fixture",
    )

    assert result == {}
    assert output_path.exists()
    with open(output_path, encoding=TEXT_ENCODING) as f:
        header = f.readline().strip()
    assert "gu_mrid" in header


def test_extract_results_generating_units_attributes_cost_by_glsk_factor():
    """Given a bid whose RA has a 0.5/0.5 GLSK split across two generating
    units, When generating unit results are extracted, Then each unit's
    rd_cost_eur reflects its 50% share of the bid's total cost."""
    ae_list = [_make_ae("BRANCH1", side=1, patl_ka=1.0)]
    rd_inputs = RdMilpInputs(
        rd_list=[_make_rd_unit("RA1", "GU1"), _make_rd_unit("RA1", "GU2")],
        bid_list=[_make_bid("BID1", "RA1", BidDirection.UP, {"1030Z": 20.0}, price_eur_mw=10.0)],
        glsk={"RA1": {"GU1": 0.5, "GU2": 0.5}},
        sensitivity_rd_n0_pruned={("BRANCH1", "GU1"): -10.0, ("BRANCH1", "GU2"): -10.0},
        generator_data={
            "GU1": {"target_p": 50.0, "max_p": 200.0, "min_p": 0.0, "name": "GU1"},
            "GU2": {"target_p": 30.0, "max_p": 200.0, "min_p": 0.0, "name": "GU2"},
        },
    )
    model = build_n0_milp_model(
        ae_list, "1030Z", lf_initial={"BRANCH1": {1: 1050.0}},
        penalty_cost_overload_n0=1000.0, rd_inputs=rd_inputs,
    )
    solver = pyo.SolverFactory("appsi_highs")
    solver.solve(model)

    rd_results = extract_rd_results(
        model, rd_list=rd_inputs.rd_list, bid_list=rd_inputs.bid_list,
        penalty_reference_rd_pra=0.0,
        ac_verification_status=AcVerificationStatus.CONVERGED,
        ac_verification_termination_reason="test fixture",
    )
    gu_results = extract_results_generating_units(
        model, rd_list=rd_inputs.rd_list, generator_data=rd_inputs.generator_data,
        glsk=rd_inputs.glsk, rd_results=rd_results,
        ac_verification_status=AcVerificationStatus.CONVERGED,
        ac_verification_termination_reason="test fixture",
    )

    total_bid_cost = rd_results["BID1"]["rd_cost_eur"]
    assert abs(gu_results["GU1"]["rd_cost_eur"] - total_bid_cost * 0.5) < 1e-6
    assert abs(gu_results["GU2"]["rd_cost_eur"] - total_bid_cost * 0.5) < 1e-6
    assert abs(gu_results["GU1"]["result_production_mw"] - (50.0 + gu_results["GU1"]["rd_volume_net_mw"])) < 1e-6


# ===========================================================================
# RA count limits and RA groups
# ===========================================================================

def _make_ae_milp_builder_ra_limits(branch_mrid: str, side: int, patl_ka: float, timestamp: str = "1030Z") -> AssessedElement:
    return AssessedElement(
        mrid=f"AE_{branch_mrid}", name=f"AE {branch_mrid}", tso="TestTSO",
        ae_type=AEType.SECURED, branch_mrid=branch_mrid,
        secured_for_region=None, scanned_for_region=None, exclusion_reason=None,
        patl_ka={timestamp: patl_ka}, branch_side=side,
    )


def _make_pst_milp_builder_ra_limits(mrid: str, r0: int = 0) -> PST:
    return PST(
        mrid=mrid, name=mrid, tso="TestTSO", available=True, kind=RAKind.PREVENTIVE,
        penalty_factor=1.0, low_step=-10, high_step=10, r0=r0,
        operating_tap_min=-10, operating_tap_max=10, group_id=None,
    )


def _make_rd_unit_milp_builder_ra_limits(mrid: str, gu_mrid: str, tso: str = "TestTSO") -> RDUnit:
    return RDUnit(
        mrid=mrid, name=mrid, tso=tso, gu_mrid=gu_mrid, gu_name=gu_mrid,
        available=True, kind=RAKind.PREVENTIVE, initial_p=50.0, max_p=1000.0, min_p=0.0,
        raise_ramp_rate=None, lower_ramp_rate=None,
    )


def _make_bid_milp_builder_ra_limits(mrid: str, ra_mrid: str, direction: BidDirection, available_mw: dict, price_eur_mw: float = 0.0) -> PowerBid:
    return PowerBid(
        mrid=mrid, ra_mrid=ra_mrid, direction=direction, available_mw=available_mw,
        price_eur_mw=price_eur_mw, penalty_factor=0.0, lead_time_h=0.0,
        activation_cost_eur=None, min_energy_mwh=None, max_energy_mwh=None, step_size_mw=None,
    )


def test_pst_only_has_no_ra_count_components():
    """Given a PST-only workflow, When the model is built, Then no
    ra_activated / RA count components exist."""
    ae_list = [_make_ae_milp_builder_ra_limits("BRANCH1", side=1, patl_ka=1.0)]
    pst_inputs = PstMilpInputs(
        pst_list=[_make_pst_milp_builder_ra_limits("PST1")], pst_tap_bounds={"PST1": (-10, 10)},
        pst_group_equality_pairs=[], sensitivity_pst_n0_pruned={("BRANCH1", "PST1"): 5.0},
        pst_degrees_per_tap={"PST1": 1.5}, penalty_reference_pst_pra=10.0,
    )

    model = build_n0_milp_model(
        ae_list, "1030Z", lf_initial={"BRANCH1": {1: 500.0}},
        penalty_cost_overload_n0=1000.0, pst_inputs=pst_inputs,
    )

    assert not hasattr(model, "ra_activated")
    assert not hasattr(model, "ra_count_limit_per_timestamp")
    assert not hasattr(model, "ra_count_limit_per_timeframe")


def test_rd_empty_glsk_guard_has_no_ra_count_components():
    """RD inputs with the empty-GLSK guard firing: no ra_activated / RA count components (they
    need a built RD block)."""
    ae_list = [_make_ae_milp_builder_ra_limits("BRANCH1", side=1, patl_ka=1.0)]
    rd_inputs = RdMilpInputs(
        rd_list=[_make_rd_unit_milp_builder_ra_limits("RA1", "GU1")],
        bid_list=[_make_bid_milp_builder_ra_limits("BID1", "RA1", BidDirection.UP, {"1030Z": 20.0})],
        glsk={"RA1": {}},
        sensitivity_rd_n0_pruned={("BRANCH1", "GU1"): -10.0},
        generator_data={"GU1": {"target_p": 50.0, "max_p": 100.0, "min_p": 0.0, "name": "GU1"}},
        max_ra_count_per_timestamp_tso={"TestTSO": 1},
    )

    model = build_n0_milp_model(
        ae_list, "1030Z", lf_initial={"BRANCH1": {1: 500.0}},
        penalty_cost_overload_n0=1000.0, rd_inputs=rd_inputs,
    )

    assert not hasattr(model, "ra_activated")


def test_no_limits_defined_skips_count_constraints_entirely():
    """Given RD is active but neither max_ra_count_per_timestamp_tso nor
    max_ra_count_per_timeframe_tso is defined, When the model is built,
    Then ra_activated (and the big-M link) still exist, but neither count
    constraint does — 'skip constraint for any TSO without a defined limit'
    applied to the case of NO limits at all."""
    ae_list = [_make_ae_milp_builder_ra_limits("BRANCH1", side=1, patl_ka=1.0)]
    rd_inputs = RdMilpInputs(
        rd_list=[_make_rd_unit_milp_builder_ra_limits("RA1", "GU1")],
        bid_list=[_make_bid_milp_builder_ra_limits("BID1", "RA1", BidDirection.UP, {"1030Z": 20.0})],
        glsk={"RA1": {"GU1": 1.0}},
        sensitivity_rd_n0_pruned={("BRANCH1", "GU1"): -10.0},
        generator_data={"GU1": {"target_p": 50.0, "max_p": 100.0, "min_p": 0.0, "name": "GU1"}},
        # no max_ra_count_*_tso set at all
    )

    model = build_n0_milp_model(
        ae_list, "1030Z", lf_initial={"BRANCH1": {1: 500.0}},
        penalty_cost_overload_n0=1000.0, rd_inputs=rd_inputs,
    )

    assert hasattr(model, "ra_activated")
    assert hasattr(model, "ra_activation_big_m")
    assert not hasattr(model, "ra_count_limit_per_timestamp")
    assert not hasattr(model, "ra_count_limit_per_timeframe")


def test_hard_limit_caps_activated_ra_count():
    """max_ra_count_per_timestamp_tso=2 for a TSO with 4 equally cheap and effective RD RAs and
    ra_limit_constraint_hard=True: at most 2 RAs are activated in a real solve."""
    ae_list = [_make_ae_milp_builder_ra_limits("BRANCH1", side=1, patl_ka=1.0)]

    # 4 RD RAs, each on its own unit and equally able to relieve BRANCH1, plus a large
    # balancing partner so the balance constraint does not bind
    rd_list = [_make_rd_unit_milp_builder_ra_limits(f"RA{i}", f"GU{i}") for i in range(1, 5)]
    rd_list.append(_make_rd_unit_milp_builder_ra_limits("RA_BALANCE", "GU_BALANCE"))
    bid_list = [
        _make_bid_milp_builder_ra_limits(f"BID{i}", f"RA{i}", BidDirection.UP, {"1030Z": 100.0}) for i in range(1, 5)
    ]
    bid_list.append(_make_bid_milp_builder_ra_limits("BID_BALANCE", "RA_BALANCE", BidDirection.DOWN, {"1030Z": 400.0}))

    glsk = {f"RA{i}": {f"GU{i}": 1.0} for i in range(1, 5)}
    glsk["RA_BALANCE"] = {"GU_BALANCE": 1.0}

    sensitivity = {("BRANCH1", f"GU{i}"): -10.0 for i in range(1, 5)}
    # GU_BALANCE has no sensitivity entry: pure balancer

    generator_data = {f"GU{i}": {"target_p": 50.0, "max_p": 200.0, "min_p": 0.0, "name": f"GU{i}"} for i in range(1, 5)}
    generator_data["GU_BALANCE"] = {"target_p": 200.0, "max_p": 500.0, "min_p": 0.0, "name": "GU_BALANCE"}

    rd_inputs = RdMilpInputs(
        rd_list=rd_list, bid_list=bid_list, glsk=glsk,
        sensitivity_rd_n0_pruned=sensitivity, generator_data=generator_data,
        max_ra_count_per_timestamp_tso={"TestTSO": 2},
        ra_limit_constraint_hard=True,
    )

    # Overload large enough that activating all 4 units would be the
    # unconstrained optimum (more relief always helps, no cost to stop it).
    model = build_n0_milp_model(
        ae_list, "1030Z", lf_initial={"BRANCH1": {1: 1300.0}},
        penalty_cost_overload_n0=1000.0, rd_inputs=rd_inputs,
    )

    solver = pyo.SolverFactory("appsi_highs")
    result = solver.solve(model)
    assert str(result.solver.termination_condition) in ("optimal", "TerminationCondition.optimal")

    activated_count = sum(
        round(pyo.value(model.ra_activated[f"RA{i}"])) for i in range(1, 5)
    )
    assert activated_count <= 2


def test_soft_limit_allows_exceeding_with_penalty():
    """Given ra_limit_constraint_hard=False, When solved with a scenario
    where exceeding the limit is cheaper than respecting it (huge overload
    penalty vs small ra_limit_penalty), Then the solver DOES exceed the
    limit and ra_count_slack_per_timestamp reflects the overage."""
    ae_list = [_make_ae_milp_builder_ra_limits("BRANCH1", side=1, patl_ka=1.0)]
    rd_list = [_make_rd_unit_milp_builder_ra_limits(f"RA{i}", f"GU{i}") for i in range(1, 3)]
    rd_list.append(_make_rd_unit_milp_builder_ra_limits("RA_BALANCE", "GU_BALANCE"))
    # each bid capped at 20 MW, less than the 30 MW needed: one RA cannot clear the overload
    bid_list = [_make_bid_milp_builder_ra_limits(f"BID{i}", f"RA{i}", BidDirection.UP, {"1030Z": 20.0}) for i in range(1, 3)]
    bid_list.append(_make_bid_milp_builder_ra_limits("BID_BALANCE", "RA_BALANCE", BidDirection.DOWN, {"1030Z": 200.0}))

    glsk = {f"RA{i}": {f"GU{i}": 1.0} for i in range(1, 3)}
    glsk["RA_BALANCE"] = {"GU_BALANCE": 1.0}
    sensitivity = {("BRANCH1", f"GU{i}"): -10.0 for i in range(1, 3)}
    generator_data = {f"GU{i}": {"target_p": 50.0, "max_p": 200.0, "min_p": 0.0, "name": f"GU{i}"} for i in range(1, 3)}
    generator_data["GU_BALANCE"] = {"target_p": 100.0, "max_p": 300.0, "min_p": 0.0, "name": "GU_BALANCE"}

    rd_inputs = RdMilpInputs(
        rd_list=rd_list, bid_list=bid_list, glsk=glsk,
        sensitivity_rd_n0_pruned=sensitivity, generator_data=generator_data,
        max_ra_count_per_timestamp_tso={"TestTSO": 1},  # only 1 allowed, softly
        ra_limit_constraint_hard=False,
        ra_limit_penalty=1.0,  # cheap to exceed
    )

    # 30 MW needed to fully clear (300 A / 10 A per MW); each bid capped at
    # 20 MW, so a single RA leaves 100 A of overload_slack (cost 100,000
    # EUR at penalty_cost_overload_n0=1000) -- vastly more expensive than
    # activating a second RA (ra_limit_penalty=1.0 for the count overage).
    model = build_n0_milp_model(
        ae_list, "1030Z", lf_initial={"BRANCH1": {1: 1300.0}},
        penalty_cost_overload_n0=1000.0, rd_inputs=rd_inputs,
    )

    assert hasattr(model, "ra_count_slack_per_timestamp")

    solver = pyo.SolverFactory("appsi_highs")
    result = solver.solve(model)
    assert str(result.solver.termination_condition) in ("optimal", "TerminationCondition.optimal")

    activated_count = round(pyo.value(model.ra_activated["RA1"])) + round(pyo.value(model.ra_activated["RA2"]))
    slack = pyo.value(model.ra_count_slack_per_timestamp["TestTSO"])

    assert activated_count == 2  # limit of 1 exceeded
    assert slack >= 1.0 - 1e-6  # slack absorbs the overage


def test_ra_activation_linked_via_big_m():
    """Given a bid with zero dispatched volume, When solved, Then
    ra_activated for its RA is not forced to 1 (big-M link only forces
    activation upward when volume is non-zero, never the reverse)."""
    ae_list = [_make_ae_milp_builder_ra_limits("BRANCH1", side=1, patl_ka=1.0)]
    rd_inputs = RdMilpInputs(
        rd_list=[_make_rd_unit_milp_builder_ra_limits("RA1", "GU1"), _make_rd_unit_milp_builder_ra_limits("RA2", "GU2")],
        bid_list=[
            _make_bid_milp_builder_ra_limits("BID1", "RA1", BidDirection.UP, {"1030Z": 20.0}),
            _make_bid_milp_builder_ra_limits("BID2", "RA2", BidDirection.DOWN, {"1030Z": 20.0}),
        ],
        glsk={"RA1": {"GU1": 1.0}, "RA2": {"GU2": 1.0}},
        sensitivity_rd_n0_pruned={("BRANCH1", "GU1"): -10.0},
        generator_data={
            "GU1": {"target_p": 50.0, "max_p": 100.0, "min_p": 0.0, "name": "GU1"},
            "GU2": {"target_p": 50.0, "max_p": 100.0, "min_p": 0.0, "name": "GU2"},
        },
    )

    # No overload at all -- optimal dispatch is exactly 0 for both bids.
    model = build_n0_milp_model(
        ae_list, "1030Z", lf_initial={"BRANCH1": {1: 500.0}},
        penalty_cost_overload_n0=1000.0, rd_inputs=rd_inputs,
    )

    solver = pyo.SolverFactory("appsi_highs")
    result = solver.solve(model)
    assert str(result.solver.termination_condition) in ("optimal", "TerminationCondition.optimal")

    assert round(pyo.value(model.rd_volume_upward["BID1"])) == 0
    assert round(pyo.value(model.ra_activated["RA1"])) == 0


# ---------------------------------------------------------------------------
# extract_ra_count_results
# ---------------------------------------------------------------------------

def test_extract_ra_count_results_returns_empty_when_ra_activated_absent(tmp_path):
    """A model without ra_activated (PST-only, or no RD block): extract_ra_count_results returns
    {} and still writes a header-only CSV."""
    from post_milp.n0_results_export import extract_ra_count_results

    ae_list = [_make_ae_milp_builder_ra_limits("BRANCH1", side=1, patl_ka=1.0)]
    pst_inputs = PstMilpInputs(
        pst_list=[_make_pst_milp_builder_ra_limits("PST1")], pst_tap_bounds={"PST1": (-10, 10)},
        pst_group_equality_pairs=[], sensitivity_pst_n0_pruned={("BRANCH1", "PST1"): 5.0},
        pst_degrees_per_tap={"PST1": 1.5}, penalty_reference_pst_pra=10.0,
    )
    model = build_n0_milp_model(
        ae_list, "1030Z", lf_initial={"BRANCH1": {1: 500.0}},
        penalty_cost_overload_n0=1000.0, pst_inputs=pst_inputs,
    )

    output_path = tmp_path / "results_preventive_rd_ra_count.csv"
    result = extract_ra_count_results(
        model, rd_list=[], bid_list=[], timestamp="1030Z", output_path=output_path,
        ac_verification_status=AcVerificationStatus.CONVERGED,
        ac_verification_termination_reason="test fixture",
    )

    assert result == {}
    assert output_path.exists()
    with open(output_path, encoding=TEXT_ENCODING) as f:
        header = f.readline().strip()
    assert "tso" in header


def test_extract_ra_count_results_reports_hard_limit_correctly():
    """Given a solved model with a hard per-timestamp limit, When results
    are extracted, Then activated_ra_count respects the limit and
    slack_per_timestamp is exactly 0.0 (hard mode -- no slack variable
    exists, extraction reports 0.0 rather than None)."""
    from post_milp.n0_results_export import extract_ra_count_results

    ae_list = [_make_ae_milp_builder_ra_limits("BRANCH1", side=1, patl_ka=1.0)]
    rd_list = [_make_rd_unit_milp_builder_ra_limits(f"RA{i}", f"GU{i}") for i in range(1, 3)]
    rd_list.append(_make_rd_unit_milp_builder_ra_limits("RA_BALANCE", "GU_BALANCE"))
    bid_list = [_make_bid_milp_builder_ra_limits(f"BID{i}", f"RA{i}", BidDirection.UP, {"1030Z": 100.0}) for i in range(1, 3)]
    bid_list.append(_make_bid_milp_builder_ra_limits("BID_BALANCE", "RA_BALANCE", BidDirection.DOWN, {"1030Z": 200.0}))
    glsk = {f"RA{i}": {f"GU{i}": 1.0} for i in range(1, 3)}
    glsk["RA_BALANCE"] = {"GU_BALANCE": 1.0}
    sensitivity = {("BRANCH1", "GU1"): -10.0}  # only RA1 helps the branch
    generator_data = {f"GU{i}": {"target_p": 50.0, "max_p": 200.0, "min_p": 0.0, "name": f"GU{i}"} for i in range(1, 3)}
    generator_data["GU_BALANCE"] = {"target_p": 100.0, "max_p": 300.0, "min_p": 0.0, "name": "GU_BALANCE"}

    rd_inputs = RdMilpInputs(
        rd_list=rd_list, bid_list=bid_list, glsk=glsk,
        sensitivity_rd_n0_pruned=sensitivity, generator_data=generator_data,
        max_ra_count_per_timestamp_tso={"TestTSO": 1},
        ra_limit_constraint_hard=True,
    )
    model = build_n0_milp_model(
        ae_list, "1030Z", lf_initial={"BRANCH1": {1: 1050.0}},
        penalty_cost_overload_n0=1000.0, rd_inputs=rd_inputs,
    )
    solver = pyo.SolverFactory("appsi_highs")
    solver.solve(model)

    results = extract_ra_count_results(
        model, rd_list=rd_list, bid_list=bid_list,
        max_ra_count_per_timestamp_tso={"TestTSO": 1},
        timestamp="1030Z",
        ac_verification_status=AcVerificationStatus.CONVERGED,
        ac_verification_termination_reason="test fixture",
    )

    assert "TestTSO" in results
    assert results["TestTSO"]["activated_ra_count"] <= 1
    assert results["TestTSO"]["limit_per_timestamp"] == 1
    assert results["TestTSO"]["slack_per_timestamp"] == 0.0
    assert results["TestTSO"]["limit_per_timeframe"] is None
    assert results["TestTSO"]["slack_per_timeframe"] is None


# ---------------------------------------------------------------------------
# RA group volume limits
# ---------------------------------------------------------------------------

def test_no_ra_groups_defined_adds_no_group_constraints():
    """Given RD is active but ra_groups is None, When the model is built,
    Then no group volume constraint components exist."""
    ae_list = [_make_ae_milp_builder_ra_limits("BRANCH1", side=1, patl_ka=1.0)]
    rd_inputs = RdMilpInputs(
        rd_list=[_make_rd_unit_milp_builder_ra_limits("RA1", "GU1")],
        bid_list=[_make_bid_milp_builder_ra_limits("BID1", "RA1", BidDirection.UP, {"1030Z": 20.0})],
        glsk={"RA1": {"GU1": 1.0}},
        sensitivity_rd_n0_pruned={("BRANCH1", "GU1"): -10.0},
        generator_data={"GU1": {"target_p": 50.0, "max_p": 100.0, "min_p": 0.0, "name": "GU1"}},
    )

    model = build_n0_milp_model(
        ae_list, "1030Z", lf_initial={"BRANCH1": {1: 500.0}},
        penalty_cost_overload_n0=1000.0, rd_inputs=rd_inputs,
    )

    assert not hasattr(model, "ra_group_volume_upward_limit")
    assert not hasattr(model, "ra_group_volume_downward_limit")


def test_group_with_unresolved_limit_adds_no_constraint():
    """A restrictive group with max_regulating_up/down both None (the real Jotunheim shape):
    no group constraint, logged."""
    ae_list = [_make_ae_milp_builder_ra_limits("BRANCH1", side=1, patl_ka=1.0)]
    rd_inputs = RdMilpInputs(
        rd_list=[_make_rd_unit_milp_builder_ra_limits("RA1", "GU1")],
        bid_list=[_make_bid_milp_builder_ra_limits("BID1", "RA1", BidDirection.UP, {"1030Z": 20.0})],
        glsk={"RA1": {"GU1": 1.0}},
        sensitivity_rd_n0_pruned={("BRANCH1", "GU1"): -10.0},
        generator_data={"GU1": {"target_p": 50.0, "max_p": 100.0, "min_p": 0.0, "name": "GU1"}},
        ra_groups={
            "GROUP1": {"name": "GROUP1", "ra_mrids": ["RA1"], "max_regulating_up": None, "max_regulating_down": None},
        },
    )

    model = build_n0_milp_model(
        ae_list, "1030Z", lf_initial={"BRANCH1": {1: 500.0}},
        penalty_cost_overload_n0=1000.0, rd_inputs=rd_inputs,
    )

    assert not hasattr(model, "ra_group_volume_upward_limit")
    assert not hasattr(model, "ra_group_volume_downward_limit")


def test_group_upward_limit_caps_combined_dispatch():
    """A group with max_regulating_up=100 MW and two bids: rd_volume_upward[bid1] +
    rd_volume_upward[bid2] <= 100 MW in a real solve where more would be optimal."""
    ae_list = [_make_ae_milp_builder_ra_limits("BRANCH1", side=1, patl_ka=1.0)]
    rd_inputs = RdMilpInputs(
        rd_list=[
            _make_rd_unit_milp_builder_ra_limits("RA1", "GU1"), _make_rd_unit_milp_builder_ra_limits("RA2", "GU2"),
            _make_rd_unit_milp_builder_ra_limits("RA_BALANCE", "GU_BALANCE"),
        ],
        bid_list=[
            _make_bid_milp_builder_ra_limits("BID1", "RA1", BidDirection.UP, {"1030Z": 80.0}),
            _make_bid_milp_builder_ra_limits("BID2", "RA2", BidDirection.UP, {"1030Z": 80.0}),
            _make_bid_milp_builder_ra_limits("BID_BALANCE", "RA_BALANCE", BidDirection.DOWN, {"1030Z": 200.0}),
        ],
        glsk={"RA1": {"GU1": 1.0}, "RA2": {"GU2": 1.0}, "RA_BALANCE": {"GU_BALANCE": 1.0}},
        sensitivity_rd_n0_pruned={("BRANCH1", "GU1"): -10.0, ("BRANCH1", "GU2"): -10.0},
        generator_data={
            "GU1": {"target_p": 50.0, "max_p": 300.0, "min_p": 0.0, "name": "GU1"},
            "GU2": {"target_p": 50.0, "max_p": 300.0, "min_p": 0.0, "name": "GU2"},
            "GU_BALANCE": {"target_p": 200.0, "max_p": 500.0, "min_p": 0.0, "name": "GU_BALANCE"},
        },
        ra_groups={
            "GROUP1": {
                "name": "GROUP1", "ra_mrids": ["RA1", "RA2"],
                "max_regulating_up": 100.0, "max_regulating_down": None,
            },
        },
    )

    # 150 MW would clear the overload (1500 A / 10 A per MW); without the cap both bids would
    # reach 150 MW combined, with it the sum stays <= 100 MW
    model = build_n0_milp_model(
        ae_list, "1030Z", lf_initial={"BRANCH1": {1: 2500.0}},
        penalty_cost_overload_n0=1000.0, rd_inputs=rd_inputs,
    )

    assert hasattr(model, "ra_group_volume_upward_limit")

    solver = pyo.SolverFactory("appsi_highs")
    result = solver.solve(model)
    assert str(result.solver.termination_condition) in ("optimal", "TerminationCondition.optimal")

    combined_upward = pyo.value(model.rd_volume_upward["BID1"]) + pyo.value(model.rd_volume_upward["BID2"])
    assert combined_upward <= 100.0 + 1e-6


def test_group_with_no_member_bid_in_model_adds_no_constraint():
    """Given a restrictive group references an RA mRID that has no bid
    present in the model at all, When the model is built, Then no
    constraint is added for that group (nothing to sum)."""
    ae_list = [_make_ae_milp_builder_ra_limits("BRANCH1", side=1, patl_ka=1.0)]
    rd_inputs = RdMilpInputs(
        rd_list=[_make_rd_unit_milp_builder_ra_limits("RA1", "GU1")],
        bid_list=[_make_bid_milp_builder_ra_limits("BID1", "RA1", BidDirection.UP, {"1030Z": 20.0})],
        glsk={"RA1": {"GU1": 1.0}},
        sensitivity_rd_n0_pruned={("BRANCH1", "GU1"): -10.0},
        generator_data={"GU1": {"target_p": 50.0, "max_p": 100.0, "min_p": 0.0, "name": "GU1"}},
        ra_groups={
            "GROUP1": {
                "name": "GROUP1", "ra_mrids": ["RA_NOT_IN_MODEL"],
                "max_regulating_up": 50.0, "max_regulating_down": None,
            },
        },
    )

    model = build_n0_milp_model(
        ae_list, "1030Z", lf_initial={"BRANCH1": {1: 500.0}},
        penalty_cost_overload_n0=1000.0, rd_inputs=rd_inputs,
    )

    assert not hasattr(model, "ra_group_volume_upward_limit")


# ---------------------------------------------------------------------------
# extract_ra_group_results
# ---------------------------------------------------------------------------

def test_extract_ra_group_results_returns_empty_when_no_groups(tmp_path):
    """Given ra_groups is None/empty, When extract_ra_group_results is
    called with an output_path, Then it returns {} AND still writes a
    header-only CSV."""
    from post_milp.n0_results_export import extract_ra_group_results

    ae_list = [_make_ae_milp_builder_ra_limits("BRANCH1", side=1, patl_ka=1.0)]
    rd_inputs = RdMilpInputs(
        rd_list=[_make_rd_unit_milp_builder_ra_limits("RA1", "GU1")],
        bid_list=[_make_bid_milp_builder_ra_limits("BID1", "RA1", BidDirection.UP, {"1030Z": 20.0})],
        glsk={"RA1": {"GU1": 1.0}},
        sensitivity_rd_n0_pruned={("BRANCH1", "GU1"): -10.0},
        generator_data={"GU1": {"target_p": 50.0, "max_p": 100.0, "min_p": 0.0, "name": "GU1"}},
    )
    model = build_n0_milp_model(
        ae_list, "1030Z", lf_initial={"BRANCH1": {1: 500.0}},
        penalty_cost_overload_n0=1000.0, rd_inputs=rd_inputs,
    )

    output_path = tmp_path / "results_preventive_rd_ra_groups.csv"
    result = extract_ra_group_results(
        model, ra_groups=None, bid_list=rd_inputs.bid_list, timestamp="1030Z", output_path=output_path,
        ac_verification_status=AcVerificationStatus.CONVERGED,
        ac_verification_termination_reason="test fixture",
    )

    assert result == {}
    assert output_path.exists()
    with open(output_path, encoding=TEXT_ENCODING) as f:
        header = f.readline().strip()
    assert "group_mrid" in header


def test_extract_ra_group_results_reports_dispatch_vs_limit():
    """Given a solved model with a group volume limit, When results are
    extracted, Then total_volume_upward_mw reflects actual dispatch and
    max_volume_upward_mw reflects the configured limit."""
    from post_milp.n0_results_export import extract_ra_group_results

    ae_list = [_make_ae_milp_builder_ra_limits("BRANCH1", side=1, patl_ka=1.0)]
    rd_inputs = RdMilpInputs(
        rd_list=[_make_rd_unit_milp_builder_ra_limits("RA1", "GU1"), _make_rd_unit_milp_builder_ra_limits("RA_BALANCE", "GU_BALANCE")],
        bid_list=[
            _make_bid_milp_builder_ra_limits("BID1", "RA1", BidDirection.UP, {"1030Z": 50.0}),
            _make_bid_milp_builder_ra_limits("BID_BALANCE", "RA_BALANCE", BidDirection.DOWN, {"1030Z": 50.0}),
        ],
        glsk={"RA1": {"GU1": 1.0}, "RA_BALANCE": {"GU_BALANCE": 1.0}},
        sensitivity_rd_n0_pruned={("BRANCH1", "GU1"): -10.0},
        generator_data={
            "GU1": {"target_p": 50.0, "max_p": 200.0, "min_p": 0.0, "name": "GU1"},
            "GU_BALANCE": {"target_p": 100.0, "max_p": 300.0, "min_p": 0.0, "name": "GU_BALANCE"},
        },
        ra_groups={
            "GROUP1": {"name": "GROUP1", "ra_mrids": ["RA1"], "max_regulating_up": 30.0, "max_regulating_down": None},
        },
    )
    # Overload needs 50 MW, but group limit caps it at 30 MW.
    model = build_n0_milp_model(
        ae_list, "1030Z", lf_initial={"BRANCH1": {1: 1500.0}},
        penalty_cost_overload_n0=1000.0, rd_inputs=rd_inputs,
    )
    solver = pyo.SolverFactory("appsi_highs")
    solver.solve(model)

    results = extract_ra_group_results(
        model, ra_groups=rd_inputs.ra_groups, bid_list=rd_inputs.bid_list, timestamp="1030Z",
        ac_verification_status=AcVerificationStatus.CONVERGED,
        ac_verification_termination_reason="test fixture",
    )

    assert "GROUP1" in results
    assert results["GROUP1"]["total_volume_upward_mw"] <= 30.0 + 1e-6
    assert results["GROUP1"]["max_volume_upward_mw"] == 30.0
    assert results["GROUP1"]["max_volume_downward_mw"] is None


# ===========================================================================
# Scanned elements
# ===========================================================================

def _make_rd_unit_milp_builder_scanned_elements(mrid: str, gu_mrid: str) -> RDUnit:
    return RDUnit(
        mrid=mrid, name=mrid, tso="TestTSO", gu_mrid=gu_mrid, gu_name=gu_mrid,
        available=True, kind=RAKind.PREVENTIVE, initial_p=50.0, max_p=1000.0, min_p=0.0,
        raise_ramp_rate=None, lower_ramp_rate=None,
    )


def _make_bid_milp_builder_scanned_elements(mrid: str, ra_mrid: str, direction: BidDirection, available_mw: dict) -> PowerBid:
    return PowerBid(
        mrid=mrid, ra_mrid=ra_mrid, direction=direction, available_mw=available_mw,
        price_eur_mw=0.0, penalty_factor=0.0, lead_time_h=0.0,
        activation_cost_eur=None, min_energy_mwh=None, max_energy_mwh=None, step_size_mw=None,
    )


def test_no_scanned_branches_adds_no_scanned_constraint():
    """Given an AEFlatList with only a SECURED branch, When the model is
    built, Then no scanned_element_n0 constraint exists."""
    ae_list = [_make_ae_milp_builder_scanned_elements("BRANCH1", AEType.SECURED, side=1, patl_ka=1.0)]
    pst_inputs = PstMilpInputs(
        pst_list=[_make_pst_milp_builder_scanned_elements("PST1")], pst_tap_bounds={"PST1": (-10, 10)},
        pst_group_equality_pairs=[], sensitivity_pst_n0_pruned={("BRANCH1", "PST1"): 5.0},
        pst_degrees_per_tap={"PST1": 1.5}, penalty_reference_pst_pra=10.0,
    )

    model = build_n0_milp_model(
        ae_list, "1030Z", lf_initial={"BRANCH1": {1: 500.0}},
        penalty_cost_overload_n0=1000.0, pst_inputs=pst_inputs,
    )

    assert not hasattr(model, "scanned_element_n0")


def test_pst_only_scanned_constraint_has_only_pst_term():
    """PST-only workflow: the scanned constraint holds only pst_effect_on_branch (no RD term),
    checked via hasattr and by a solve where the scanned limit caps the PST short of fully
    relieving a secured overload."""
    ae_list = [
        _make_ae_milp_builder_scanned_elements("SECURED1", AEType.SECURED, side=1, patl_ka=1.0),
        _make_ae_milp_builder_scanned_elements("SCANNED1", AEType.SCANNED, side=1, patl_ka=1.2),
    ]
    pst_inputs = PstMilpInputs(
        pst_list=[_make_pst_milp_builder_scanned_elements("PST1")], pst_tap_bounds={"PST1": (-10, 10)},
        pst_group_equality_pairs=[],
        # Same tap direction relieves SECURED1 but WORSENS SCANNED1.
        sensitivity_pst_n0_pruned={("SECURED1", "PST1"): -10.0, ("SCANNED1", "PST1"): 70.0},
        pst_degrees_per_tap={"PST1": 1.0}, penalty_reference_pst_pra=1.0,
    )

    # SECURED1: 1050 A vs 1000 A PATL -> needs 5 taps (@ -10 A/tap) to fully relieve.
    # SCANNED1: 900 A vs 1.2 kA PATL -> effective_limit = max(1200, 900) = 1200 A
    # (real headroom, not clamped to initial loading here). At +70 A/tap,
    # only 4 taps keep it within 1200 A (900 + 4*70 = 1180); 5 taps would
    # reach 1250 > 1200 -> infeasible under the HARD scanned constraint.
    # The solver must therefore stop at 4 taps, leaving SECURED1 with 10 A
    # of unavoidable overload_slack_n0.
    model = build_n0_milp_model(
        ae_list, "1030Z",
        lf_initial={"SECURED1": {1: 1050.0}, "SCANNED1": {1: 900.0}},
        penalty_cost_overload_n0=1000.0, pst_inputs=pst_inputs,
    )

    assert hasattr(model, "scanned_element_n0")
    assert not hasattr(model, "rd_effect_on_branch")  # confirms no RD term possible at all

    solver = pyo.SolverFactory("appsi_highs")
    result = solver.solve(model)
    assert str(result.solver.termination_condition) in ("optimal", "TerminationCondition.optimal")

    tap_up = pyo.value(model.tap_change_upward["PST1"])
    tap_down = pyo.value(model.tap_change_downward["PST1"])
    net_tap = tap_up - tap_down

    assert net_tap <= 4.0 + 1e-6  # capped by SCANNED1's hard limit, not free to reach 5
    assert pyo.value(model.overload_slack_n0["SECURED1"]) >= 10.0 - 1e-6  # residual, unavoidable overload


def test_hard_constraint_acceptance_criterion_loading_never_exceeds_limit():
    """A scanned element with effective_limit_ka=1.1 and initial loading 0.9 kA as a HARD
    constraint: the linearised loading after optimisation stays <= 1.1 kA."""
    ae_list = [_make_ae_milp_builder_scanned_elements("SCANNED1", AEType.SCANNED, side=1, patl_ka=1.1)]
    rd_inputs = RdMilpInputs(
        rd_list=[_make_rd_unit_milp_builder_scanned_elements("RA1", "GU1"), _make_rd_unit_milp_builder_scanned_elements("RA_BALANCE", "GU_BALANCE")],
        bid_list=[
            _make_bid_milp_builder_scanned_elements("BID1", "RA1", BidDirection.DOWN, {"1030Z": 50.0}),
            _make_bid_milp_builder_scanned_elements("BID_BALANCE", "RA_BALANCE", BidDirection.UP, {"1030Z": 50.0}),
        ],
        glsk={"RA1": {"GU1": 1.0}, "RA_BALANCE": {"GU_BALANCE": 1.0}},
        # sensitivity sign chosen so that reducing GU1's output relieves SCANNED1
        sensitivity_rd_n0_pruned={("SCANNED1", "GU1"): 10.0},
        generator_data={
            "GU1": {"target_p": 100.0, "max_p": 200.0, "min_p": 0.0, "name": "GU1"},
            "GU_BALANCE": {"target_p": 50.0, "max_p": 300.0, "min_p": 0.0, "name": "GU_BALANCE"},
        },
    )

    # initial loading 900 A, effective_limit = max(patl 1.1 kA, initial 0.9 kA) = 1.1 kA; the
    # branch is within its limit without action, and must never exceed 1100 A whatever the
    # solver does with the RD units
    model = build_n0_milp_model(
        ae_list, "1030Z", lf_initial={"SCANNED1": {1: 900.0}},
        penalty_cost_overload_n0=1000.0, rd_inputs=rd_inputs,
        scanned_element_constraint_hard=True,
    )

    assert hasattr(model, "scanned_element_n0")
    assert not hasattr(model, "scanned_overload_slack")  # hard -> no slack variable at all

    solver = pyo.SolverFactory("appsi_highs")
    result = solver.solve(model)
    assert str(result.solver.termination_condition) in ("optimal", "TerminationCondition.optimal")

    net_injection = pyo.value(model.rd_net_injection_g["GU1"])
    loading_after_rao_a = 900.0 + 10.0 * net_injection  # same formula as the constraint itself
    assert loading_after_rao_a <= 1100.0 + 1e-6  # 1.1 kA = 1100 A


def test_soft_constraint_allows_exceeding_with_slack_and_penalty():
    """Given scanned_element_constraint_hard=False, When solved with a
    scenario forcing the limit to be exceeded, Then scanned_overload_slack
    absorbs the excess rather than the problem being infeasible."""
    ae_list = [_make_ae_milp_builder_scanned_elements("SCANNED1", AEType.SCANNED, side=1, patl_ka=1.0)]
    pst_inputs = PstMilpInputs(
        pst_list=[_make_pst_milp_builder_scanned_elements("PST1")], pst_tap_bounds={"PST1": (0, 0)},  # PST cannot move at all
        pst_group_equality_pairs=[],
        sensitivity_pst_n0_pruned={("SCANNED1", "PST1"): 0.0},
        pst_degrees_per_tap={"PST1": 1.0}, penalty_reference_pst_pra=1.0,
    )

    # 1200 A against a 1000 A PATL -> effective_limit = 1200 A, already AT the limit and the
    # PST fixed to 0; a nonzero sensitivity makes hard mode infeasible and soft mode feasible
    model = build_n0_milp_model(
        ae_list, "1030Z", lf_initial={"SCANNED1": {1: 1200.0}},
        penalty_cost_overload_n0=1000.0, pst_inputs=pst_inputs,
        scanned_element_constraint_hard=False,
        scanned_element_penalty_eur_per_ka=1.0,
    )

    assert hasattr(model, "scanned_overload_slack")

    solver = pyo.SolverFactory("appsi_highs")
    result = solver.solve(model)
    assert str(result.solver.termination_condition) in ("optimal", "TerminationCondition.optimal")

    slack = pyo.value(model.scanned_overload_slack["SCANNED1"])
    assert slack >= 0.0  # non-negative, well-defined (exactly 0 here since nothing forces it, but structurally present)


# ===========================================================================
# N-0 branches without usable data
# ===========================================================================

# ---------------------------------------------------------------------------
# an N-X pair with PATL <= 0 is excluded as on the N-0 side
# ---------------------------------------------------------------------------

def _nx_model_with_zero_patl_branch():
    import helpers as N
    from milp.milp_builder import NxMilpInputs, build_n0_milp_model
    ae_list = [N._make_ae_mb_nx("GOOD", patl_ka=1.0), N._make_ae_mb_nx("ZERO", patl_ka=0.0)]
    pst_inputs = N._make_pst_inputs(branch="GOOD")
    pst_inputs.sensitivity_pst_n0_pruned[("ZERO", "PST1")] = 5.0
    nx_inputs = NxMilpInputs(
        lf_nx={"CO1": {"GOOD": {1: 900.0}, "ZERO": {1: 50.0}},
               "CO2": {"GOOD": {1: 900.0}, "ZERO": {1: 60.0}}},
        sensitivity_pst_nx={"CO1": {("GOOD", "PST1"): -10.0, ("ZERO", "PST1"): -10.0},
                            "CO2": {("GOOD", "PST1"): -10.0, ("ZERO", "PST1"): -10.0}},
        sensitivity_rd_nx={}, penalty_cost_overload_nx_patl=500.0,
    )
    return build_n0_milp_model(
        ae_list, "1030Z", lf_initial={"GOOD": {1: 500.0}, "ZERO": {1: 40.0}},
        penalty_cost_overload_n0=1000.0, pst_inputs=pst_inputs, nx_inputs=nx_inputs,
    )


def test_a_branch_with_patl_zero_has_no_n0_constraint(caplog):
    with caplog.at_level(logging.WARNING):
        model = _nx_model_with_zero_patl_branch()
    assert "ZERO" not in set(model.branch_ids)


def test_an_n0_branch_with_a_nan_initial_current_is_excluded_with_a_warning(caplog):
    import helpers as N
    from milp.milp_builder import build_n0_milp_model
    ae_list = [N._make_ae_mb_nx("B1", patl_ka=1.0), N._make_ae_mb_nx("B2", patl_ka=1.0)]
    pst_inputs = N._make_pst_inputs(branch="B1")
    pst_inputs.sensitivity_pst_n0_pruned[("B2", "PST1")] = 5.0
    with caplog.at_level(logging.WARNING):
        model = build_n0_milp_model(
            ae_list, "1030Z", lf_initial={"B1": {1: 500.0}, "B2": {1: float("nan")}},
            penalty_cost_overload_n0=1000.0, pst_inputs=pst_inputs,
        )
    assert set(model.branch_ids) == {"B1"}
    assert any("B2" in r.message and "NaN" in r.message for r in caplog.records if r.levelno == logging.WARNING)


# ===========================================================================
# Solve with a scanned branch
# ===========================================================================

# ---------------------------------------------------------------------------
# solve_n0_milp_model with a SCANNED branch (as used by ac_convergence_loop.py)
# ---------------------------------------------------------------------------

def test_solving_a_model_with_a_scanned_branch_reports_slack_for_secured_branches_only():
    import helpers as T
    from milp.milp_builder import PstMilpInputs, build_n0_milp_model
    from milp.milp_solver import solve_n0_milp_model
    ae = [T._make_ae_mb_scanned("SEC", AEType.SECURED, 1, 1.0), T._make_ae_mb_scanned("SCAN", AEType.SCANNED, 1, 1.0)]
    pst = T._make_pst_mb_scanned("PST1")
    pst_inputs = PstMilpInputs(
        pst_list=[pst], pst_tap_bounds={"PST1": (-10, 10)}, pst_group_equality_pairs=[],
        sensitivity_pst_n0_pruned={("SEC", "PST1"): 5.0, ("SCAN", "PST1"): 5.0},
        pst_degrees_per_tap={"PST1": 1.5}, penalty_reference_pst_pra=10.0,
    )
    model = build_n0_milp_model(ae, "1030Z", {"SEC": {1: 500.0}, "SCAN": {1: 500.0}}, 1000.0, pst_inputs=pst_inputs)
    _, overload_slack = solve_n0_milp_model(model, [pst], "1030Z", 10.0)
    assert set(overload_slack) == {"SEC"}


# ===========================================================================
# N-0 branch with a NaN sensitivity
# ===========================================================================

@pytest.mark.parametrize("kind", ["pst", "rd"])
def test_an_n0_branch_with_a_nan_sensitivity_is_excluded_with_a_warning(kind, caplog):
    from data_model import AEType, BidDirection, PowerBid
    from helpers import _make_ae_mb_scanned, _make_pst_mb_scanned, _rd
    ae = [_make_ae_mb_scanned("B1", AEType.SECURED, 1, 1.0), _make_ae_mb_scanned("B2", AEType.SECURED, 1, 1.0)]
    lf = {"B1": {1: 500.0}, "B2": {1: 500.0}}
    pst_inputs = rd_inputs = None
    if kind == "pst":
        pst_inputs = PstMilpInputs(
            pst_list=[_make_pst_mb_scanned("PST1")], pst_tap_bounds={"PST1": (-5, 5)}, pst_group_equality_pairs=[],
            sensitivity_pst_n0_pruned={("B1", "PST1"): 5.0, ("B2", "PST1"): float("nan")},
            pst_degrees_per_tap={"PST1": 1.0}, penalty_reference_pst_pra=10.0,
        )
    else:
        bid = PowerBid(
            mrid="BID1", ra_mrid="RD1", direction=BidDirection.UP, available_mw={"1030Z": 10.0},
            price_eur_mw=1.0, penalty_factor=1.0, lead_time_h=0.0, activation_cost_eur=None,
            min_energy_mwh=None, max_energy_mwh=None, step_size_mw=None,
        )
        rd_inputs = RdMilpInputs(
            rd_list=[_rd(1)], bid_list=[bid], glsk={"RD1": {"GU1": 1.0}},
            sensitivity_rd_n0_pruned={("B1", "GU1"): 1.0, ("B2", "GU1"): float("nan")},
            generator_data={"GU1": {"target_p": 50.0, "max_p": 200.0, "min_p": 0.0}},
        )
    with caplog.at_level(logging.WARNING):
        model = build_n0_milp_model(ae, "1030Z", lf, 1000.0, pst_inputs=pst_inputs, rd_inputs=rd_inputs)
    assert set(model.branch_ids) == {"B1"}
    assert any("B2" in r.getMessage() and "NaN" in r.getMessage() and "sensitivit" in r.getMessage()
               for r in caplog.records if r.levelno == logging.WARNING)

# ===========================================================================
# HiGHS time limit and MIP gap (performance section of the config)
# ===========================================================================

def test_a_solve_stopped_at_the_time_limit_raises_not_optimal(monkeypatch):
    """A real solve of the synthetic curative model with a 1 ms limit stops at the limit."""
    from helpers import synthetic_curative_milp_inputs
    from milp import milp_solver
    inputs = synthetic_curative_milp_inputs()
    model = build_n0_milp_model(**inputs)
    monkeypatch.setattr(milp_solver, "SOLVER_TIME_LIMIT_SECONDS", 0.001)
    with pytest.raises(milp_solver.MilpNotOptimalError, match="maxTimeLimit"):
        milp_solver.solve_n0_milp_model(model, inputs["pst_inputs"].pst_list, "1030Z", 100.0)


def test_without_limits_the_same_model_solves_to_optimal():
    from helpers import synthetic_curative_milp_inputs
    from milp import milp_solver
    assert milp_solver.SOLVER_TIME_LIMIT_SECONDS is None and milp_solver.SOLVER_MIP_REL_GAP is None
    inputs = synthetic_curative_milp_inputs()
    model = build_n0_milp_model(**inputs)
    milp_solver.solve_n0_milp_model(model, inputs["pst_inputs"].pst_list, "1030Z", 100.0)
