"""tests/test_rao_single_pass.py - calculation_mode ac_single_pass (milp/single_pass.py) and the
workflow options ra_types / calculation_mode as run by run_pipeline.main().

Sections: the final check (fast), the single pass on the mock case (spies and outputs), the
non-convergent final load flow, ra_types x calculation_mode on both NCP inputs, the GUI.
"""

import collections
import csv
import sys
from types import SimpleNamespace

import pytest
import yaml

from data_model import AcVerificationStatus
from helpers import REPO_ROOT, _FIXTURES, _MOCK_NX_NCP_ZIP, run_pipeline_on_fixture_inputs
from milp import single_pass
from text_encoding import TEXT_ENCODING  # noqa: E402

GENERIC_NCP_ZIP = _FIXTURES / "NCP_sample_generic_2_4.zip"


# ===========================================================================
# The final check
# ===========================================================================

def test_summarize_overloads_counts_elements_branches_and_sums_per_kind():
    overloads = {
        ("n0", "b1"): 10.0, ("n0", "b2"): 0.0,
        ("nx_patl", "b1", "c1"): 5.0, ("nx_patl", "b1", "c2"): 7.0, ("nx_patl", "b3", "c1"): 0.0,
        ("nx_tatl", "b3", "c1"): 1e-9,
    }

    summary = single_pass.summarize_overloads(overloads)

    assert summary["final_check_n0_overloaded_elements"] == 1
    assert summary["final_check_n0_overloaded_branches"] == 1
    assert summary["final_check_n0_overload_a"] == 10.0
    assert summary["final_check_nx_patl_overloaded_elements"] == 2
    assert summary["final_check_nx_patl_overloaded_branches"] == 1
    assert summary["final_check_nx_patl_overload_a"] == 12.0
    assert summary["final_check_nx_tatl_overloaded_elements"] == 0
    assert summary["final_check_nx_tatl_overload_a"] == 0


def _fake_check_inputs(refreshed_lf_nx):
    calls = []
    backend = single_pass.CalculationBackend(
        name="fake", run_load_flow=lambda network: (True, "CONVERGED", None),
        compute_lf_nx=lambda network: calls.append(network) or refreshed_lf_nx,
    )
    state = SimpleNamespace(
        current_lf_n0={"b1": {1: 120.0}}, current_lf_nx={"c1": {"b1": {1: 90.0}}},
        last_curative_effect_ampere={},
    )
    model = SimpleNamespace(
        overload_monitoring={"n0": {"b1": (1, 100.0)}, "nx_patl": {("b1", "c1"): (1, 100.0)}, "nx_tatl": {}},
        nx_curative_effect_ampere=lambda branch, contingency: -30.0,
    )
    return backend, state, model, calls


def test_the_final_check_refreshes_the_n_x_load_flow_and_adds_the_curative_effect_to_the_patl_pairs():
    backend, state, model, calls = _fake_check_inputs({"c1": {"b1": {1: 140.0}}})

    result = single_pass.run_final_check("net", state, model, backend)

    assert calls == ["net"]
    assert state.current_lf_nx == {"c1": {"b1": {1: 140.0}}}
    assert result["final_check_n0_overload_a"] == 20.0
    assert result["final_check_nx_patl_overload_a"] == pytest.approx(10.0)  # 140 - 30 - 100
    assert result["final_check_nx_evaluated"] is True


def test_a_final_check_without_a_n_x_result_says_so_and_keeps_the_previous_n_x_state():
    backend, state, model, calls = _fake_check_inputs({})

    result = single_pass.run_final_check("net", state, model, backend)

    assert result["final_check_nx_evaluated"] is False
    assert state.current_lf_nx == {"c1": {"b1": {1: 90.0}}}


def test_the_final_check_of_the_original_network_does_not_run_a_security_analysis():
    backend, state, model, calls = _fake_check_inputs({"c1": {"b1": {1: 140.0}}})

    single_pass.run_final_check("net", state, model, backend, refresh_nx=False)

    assert calls == []


def test_the_final_check_covers_pairs_outside_the_model_without_adding_them():
    # b1/c1 is in the model; b2 (PATL and TATL), b3 (scanned) and b1/c2 are not
    backend, state, model, _ = _fake_check_inputs({
        "c1": {"b1": {1: 140.0}, "b2": {1: 260.0}, "b3": {2: 75.0}},
        "c2": {"b1": {1: 130.0}},
    })
    model.overload_monitoring["nx_tatl"] = {("b1", "c1"): (1, 300.0)}
    nx_limits = {
        "nx_patl": {"b1": (1, 100.0), "b2": (1, 200.0)},
        "nx_tatl": {"b1": (1, 300.0), "b2": (1, 250.0)},
        "nx_scanned": {"b3": (2, 50.0)},
    }
    monitoring_before = {kind: dict(pairs) for kind, pairs in model.overload_monitoring.items()}

    result = single_pass.run_final_check("net", state, model, backend, nx_limits=nx_limits)

    # PATL: b1/c1 with the curative effect (140 - 30 - 100), b2/c1 (260 - 200), b1/c2 outside the
    # model so without a curative effect (130 - 100)
    assert result["final_check_nx_patl_overloaded_elements"] == 3
    assert result["final_check_nx_patl_overloaded_branches"] == 2
    assert result["final_check_nx_patl_overload_a"] == pytest.approx(10.0 + 60.0 + 30.0)
    assert result["final_check_nx_tatl_overloaded_elements"] == 1  # b2/c1: 260 - 250
    assert result["final_check_nx_tatl_overload_a"] == pytest.approx(10.0)
    assert result["final_check_nx_scanned_overloaded_elements"] == 1  # b3/c1, side 2: 75 - 50
    assert result["final_check_nx_scanned_overload_a"] == pytest.approx(25.0)
    assert model.overload_monitoring == monitoring_before  # reported, not added


def test_the_final_check_adds_the_curative_effect_to_the_scanned_pairs_of_the_model():
    backend, state, model, _ = _fake_check_inputs({"c1": {"b3": {1: 75.0}}})
    model.nx_scanned_branch_contingency_pairs = [("b3", "c1")]

    result = single_pass.run_final_check(
        "net", state, model, backend, nx_limits={"nx_scanned": {"b3": (1, 50.0)}},
    )

    assert result["final_check_nx_scanned_overload_a"] == pytest.approx(0.0)  # 75 - 30 - 50 < 0


def test_without_n_x_the_final_check_says_the_n_x_state_was_not_evaluated():
    backend, state, model, _ = _fake_check_inputs({})
    backend.compute_lf_nx = None
    state.current_lf_nx = None

    result = single_pass.run_final_check("net", state, model, backend)

    assert result["final_check_nx_evaluated"] is False
    assert result["final_check_n0_overload_a"] == 20.0


def test_the_single_pass_termination_reason_maps_to_its_own_status():
    assert AcVerificationStatus.from_termination_reason(single_pass.SINGLE_PASS_REASON) is AcVerificationStatus.SINGLE_PASS
    assert AcVerificationStatus.CONVERGED.value == "CONVERGED"  # the existing values stay


# ===========================================================================
# Runs of main()
# ===========================================================================

def _csv_rows(path):
    with open(path, newline="", encoding=TEXT_ENCODING) as handle:
        return list(csv.DictReader(handle))


def _summary(output_dir):
    return {row["metric"]: row["value"] for row in _csv_rows(output_dir / "results_summary.csv")}


def spied_run(work_dir, ncp_zip, nx, ra_types, mode, extra_customize=None):
    """One main() run with spies on the calculation steps. Returns (output dir, counts, models,
    n-0 / N-X sensitivity calls with the type flags they were made with)."""
    counts = collections.Counter()
    models = []
    sensitivity_calls = collections.defaultdict(list)

    def customize(rp, monkeypatch):
        import milp.ac_convergence_loop as acl

        def wrap(obj, name, key, record=None):
            real = getattr(obj, name)

            def spy(*args, **kwargs):
                counts[key] += 1
                result = real(*args, **kwargs)
                if record is not None:
                    record(args, kwargs, result)
                return result
            monkeypatch.setattr(obj, name, spy)

        wrap(acl, "build_n0_milp_model", "build", lambda a, k, r: models.append(r))
        wrap(single_pass, "solve_n0_milp_model", "single_pass_solve")
        wrap(single_pass, "apply_solution_and_refresh", "single_pass_apply")
        wrap(single_pass, "_run_ac_loadflow", "single_pass_ac_load_flow")
        wrap(acl, "_run_ac_loadflow", "loop_ac_load_flow")
        wrap(acl, "_refresh_n0_sensitivities", "sensitivity_refresh")
        wrap(rp, "compute_lf_nx", "security_analysis")
        wrap(rp, "compute_sensitivities_nx", "nx_sensitivities",
             lambda a, k, r: sensitivity_calls["nx"].append((k["with_pst"], k["with_rd"])))
        wrap(rp.n0_sensitivity, "compute_sensitivity_pst_n0", "n0_pst_sensitivity")
        wrap(rp.n0_sensitivity, "compute_sensitivity_rd_n0", "n0_rd_sensitivity")
        wrap(rp.post_ra_congestion_check, "find_new_congested_pairs", "find_new_pairs")
        if extra_customize is not None:
            extra_customize(rp, monkeypatch)

    result = run_pipeline_on_fixture_inputs(
        work_dir, ncp_zip, nx, customize_pipeline=customize, ra_types=ra_types, calculation_mode=mode,
    )
    return result.output_dir, counts, models, sensitivity_calls


@pytest.fixture(scope="module")
def single_pass_run(tmp_path_factory):
    return spied_run(tmp_path_factory.mktemp("single_pass"), _MOCK_NX_NCP_ZIP, True, ("pst", "rd"), "ac_single_pass")


@pytest.fixture(scope="module")
def iterative_run(tmp_path_factory):
    return spied_run(tmp_path_factory.mktemp("iterative"), _MOCK_NX_NCP_ZIP, True, ("pst", "rd"), "ac_iterative")


def test_the_single_pass_does_one_build_one_solve_one_apply_one_load_flow_and_two_security_analyses(single_pass_run):
    _, counts, _, sensitivity_calls = single_pass_run

    assert counts["build"] == 1
    assert counts["single_pass_solve"] == 1
    assert counts["single_pass_apply"] == 1
    assert counts["single_pass_ac_load_flow"] == 1 and counts["loop_ac_load_flow"] == 0
    assert counts["security_analysis"] == 2  # the initial one and the final check
    assert counts["sensitivity_refresh"] == 0
    assert counts["nx_sensitivities"] == 1  # the initial computation only
    assert counts["find_new_pairs"] == 0


def test_the_iterative_mode_on_the_same_input_builds_more_than_once_and_the_single_pass_once(
    single_pass_run, iterative_run,
):
    assert iterative_run[1]["build"] > 1
    assert single_pass_run[1]["build"] == 1
    assert iterative_run[1]["find_new_pairs"] >= 1


def test_the_single_pass_model_equals_the_first_model_of_the_iterative_mode(single_pass_run, iterative_run):
    from helpers import milp_model_fingerprint

    # structure only (rows, variables, bounds): pypowsybl sensitivities differ in the last bits
    # between two runs of one process
    assert milp_model_fingerprint(single_pass_run[2][0], coefficients=False) == \
        milp_model_fingerprint(iterative_run[2][0], coefficients=False)


def test_caps_and_thresholds_of_unusual_values_have_no_effect(single_pass_run, tmp_path_factory):
    def unusual(rp, monkeypatch):
        monkeypatch.setattr(rp, "MAX_LINEARISATION_ITERATIONS", 1)
        monkeypatch.setattr(rp, "MAX_COMPLETENESS_ITERATIONS", 1)
        for name in ("MAX_CHANGE_RA_SUM_THRESHOLD", "MAX_CHANGE_RA", "MAX_CHANGE_OVERLOAD"):
            monkeypatch.setattr(rp, name, 1e9)

    other_dir, other_counts, _, _ = spied_run(
        tmp_path_factory.mktemp("single_pass_unusual"), _MOCK_NX_NCP_ZIP, True, ("pst", "rd"),
        "ac_single_pass", extra_customize=unusual,
    )

    assert other_counts["build"] == 1

    def same(left, right):
        # pypowsybl sensitivities differ in the last bits between two runs of one process (ASSUMPTIONS 16)
        assert left.keys() == right.keys()
        for key in left:
            try:
                assert float(left[key]) == pytest.approx(float(right[key]), rel=1e-6, abs=1e-6), key
            except ValueError:
                assert left[key] == right[key], key

    same(_summary(other_dir), _summary(single_pass_run[0]))
    for mine, theirs in zip(_csv_rows(other_dir / "results_pst.csv"), _csv_rows(single_pass_run[0] / "results_pst.csv")):
        same(mine, theirs)


def test_the_single_pass_output_shapes(single_pass_run):
    output_dir = single_pass_run[0]

    history = _csv_rows(output_dir / "results_iteration_history.csv")
    assert len(history) == 1
    for column in (
        "criterion_1_met", "criterion_3_met", "criterion_4_met", "converged_by", "converged", "overload_change_ampere",
        "cycle_match_iteration", "cycle_selected_iteration",
    ):
        assert history[0][column] == "n/a", column
    assert history[0]["solution_applied"] == "True"

    completeness = _csv_rows(output_dir / "results_completeness_iterations.csv")
    assert [row["completeness_iteration"] for row in completeness] == ["0"]
    assert completeness[0]["new_constraints_added"] == "0"

    summary = _summary(output_dir)
    assert summary["ac_verification_status"] == "SINGLE_PASS"
    assert summary["ac_verification_termination_reason"] == single_pass.SINGLE_PASS_REASON
    assert summary["ac_iteration_count"] == "1"
    assert summary["completeness_iteration_limit_reached"] == "False"
    assert summary["completeness_iterations"] == "0"
    assert summary["calculation_mode"] == "ac_single_pass"
    assert summary["ra_types"] == "pst+rd"
    for kind in ("n0", "nx_patl", "nx_tatl", "nx_scanned"):
        assert f"final_check_{kind}_overloaded_elements" in summary
        assert f"final_check_{kind}_overloaded_branches" in summary
        assert f"final_check_{kind}_overload_a" in summary
    assert summary["final_check_nx_evaluated"] == "True"

    for name in ("results_nx_loadings.csv", "results_nx_scanned_elements.csv", "results_pst.csv", "lf_post_n0.csv"):
        assert (output_dir / name).exists(), name
    assert {row["ac_verification_status"] for row in _csv_rows(output_dir / "results_pst.csv")} == {"SINGLE_PASS"}


def test_the_default_mode_summary_names_its_mode_and_ra_types(iterative_run):
    summary = _summary(iterative_run[0])

    assert summary["calculation_mode"] == "ac_iterative"
    assert summary["ra_types"] == "pst+rd"
    assert "final_check_n0_overload_a" not in summary


def test_a_non_convergent_final_load_flow_reports_the_original_network(tmp_path):
    def non_convergent(rp, monkeypatch):
        import milp.ac_convergence_loop as acl
        monkeypatch.setattr(single_pass, "_run_ac_loadflow", lambda *args, **kwargs: (False, "FAILED", None))
        monkeypatch.setattr(acl, "_apply_changes_incrementally", lambda *args, **kwargs: (False, "FAILED", 1))

    output_dir, counts, models, _ = spied_run(
        tmp_path, _MOCK_NX_NCP_ZIP, True, ("pst", "rd"), "ac_single_pass", extra_customize=non_convergent,
    )

    summary = _summary(output_dir)
    assert summary["ac_verification_status"] == "REVERTED_NON_CONVERGENT"
    assert summary["objective_value"] == ""
    assert getattr(models[0], "no_applied_solution", False) is True
    assert counts["security_analysis"] == 1  # no final-check security analysis: nothing was applied
    assert all(float(row["tap_change_result"]) == 0 for row in _csv_rows(output_dir / "results_pst.csv"))
    assert len(_csv_rows(output_dir / "results_iteration_history.csv")) == 1


def test_a_solve_that_is_not_optimal_reports_the_original_network(tmp_path):
    from milp.milp_solver import MilpNotOptimalError

    def not_optimal(rp, monkeypatch):
        def raise_not_optimal(*args, **kwargs):
            raise MilpNotOptimalError("infeasible (test)")
        monkeypatch.setattr(single_pass, "solve_n0_milp_model", raise_not_optimal)

    output_dir, counts, models, _ = spied_run(
        tmp_path, _MOCK_NX_NCP_ZIP, True, ("pst", "rd"), "ac_single_pass", extra_customize=not_optimal,
    )

    summary = _summary(output_dir)
    assert summary["ac_verification_status"] == "SOLVER_NON_OPTIMAL"
    assert summary["objective_value"] == ""
    assert counts["build"] == 1 and counts["single_pass_apply"] == 0
    assert counts["security_analysis"] == 1  # nothing applied: no final-check security analysis
    assert getattr(models[0], "no_applied_solution", False) is True
    assert all(float(row["tap_change_result"]) == 0 for row in _csv_rows(output_dir / "results_pst.csv"))
    history = _csv_rows(output_dir / "results_iteration_history.csv")
    assert len(history) == 1 and history[0]["solution_applied"] == "False"


def test_an_empty_generator_read_back_stops_before_the_solution_is_applied(tmp_path):
    def empty_read_back(rp, monkeypatch):
        import milp.ac_convergence_loop as acl
        monkeypatch.setattr(acl, "_extract_generator_target_p", lambda network: {})

    output_dir, counts, models, _ = spied_run(
        tmp_path, _MOCK_NX_NCP_ZIP, True, ("pst", "rd"), "ac_single_pass", extra_customize=empty_read_back,
    )

    summary = _summary(output_dir)
    assert summary["ac_verification_status"] == "REVERTED_NON_CONVERGENT"
    assert counts["single_pass_apply"] == 1
    assert counts["single_pass_ac_load_flow"] == 0  # stopped before anything was applied
    assert counts["security_analysis"] == 1
    assert getattr(models[0], "no_applied_solution", False) is True
    history = _csv_rows(output_dir / "results_iteration_history.csv")
    assert len(history) == 1 and history[0]["solution_applied"] == "False"


@pytest.mark.parametrize("ncp_name, nx", [("mock", False), ("generic", False), ("generic", True)])
def test_the_single_pass_with_n_x_off_and_on_the_generic_input(tmp_path, ncp_name, nx):
    ncp_zip = _MOCK_NX_NCP_ZIP if ncp_name == "mock" else GENERIC_NCP_ZIP

    output_dir, counts, _, _ = spied_run(tmp_path, ncp_zip, nx, ("pst", "rd"), "ac_single_pass")

    summary = _summary(output_dir)
    assert summary["ac_verification_status"] == "SINGLE_PASS"
    assert counts["build"] == 1 and counts["single_pass_solve"] == 1 and counts["single_pass_apply"] == 1
    assert counts["security_analysis"] == (2 if nx else 0)
    assert counts["sensitivity_refresh"] == 0 and counts["find_new_pairs"] == 0
    assert summary["final_check_nx_evaluated"] == str(nx)
    assert len(_csv_rows(output_dir / "results_iteration_history.csv")) == 1
    assert (output_dir / "results_completeness_iterations.csv").exists() is nx


def test_the_final_check_reports_a_pair_below_the_n_x_threshold_without_adding_it(tmp_path):
    """min_loading_threshold_pct_nx = 50 keeps the pairs below 50 % out of the model. One of them
    is made overloaded in the N-X load flow of the applied state: the final check reports it and
    the model stays as built."""
    built = []
    chosen = {}

    def threshold_and_overload(rp, monkeypatch):
        import milp.ac_convergence_loop as acl
        monkeypatch.setattr(rp, "MIN_LOADING_THRESHOLD_PCT_NX", 50.0)
        real_build = acl.build_n0_milp_model

        def recording_build(*args, **kwargs):
            model = real_build(*args, **kwargs)
            built.append(model)
            return model
        monkeypatch.setattr(acl, "build_n0_milp_model", recording_build)
        real_lf_nx = rp.compute_lf_nx

        def lf_nx_with_an_overload_outside_the_model(network, co_list, ae_list, timestamp, **kwargs):
            lf_nx, skipped = real_lf_nx(network, co_list, ae_list, timestamp, **kwargs)
            if not built:  # the initial N-X analysis
                return lf_nx, skipped
            in_model = set(built[0].nx_branch_contingency_pairs)
            patl = single_pass.nx_element_limits(ae_list, timestamp, None, None)["nx_patl"]
            for contingency_mrid in sorted(lf_nx):
                for branch_mrid in sorted(lf_nx[contingency_mrid]):
                    if branch_mrid in patl and (branch_mrid, contingency_mrid) not in in_model:
                        limit_ampere = patl[branch_mrid][1]
                        lf_nx[contingency_mrid][branch_mrid] = {1: 1.5 * limit_ampere, 2: 1.5 * limit_ampere}
                        chosen.update(pair=(branch_mrid, contingency_mrid), limit=limit_ampere)
                        return lf_nx, skipped
            return lf_nx, skipped
        monkeypatch.setattr(rp, "compute_lf_nx", lf_nx_with_an_overload_outside_the_model)

    output_dir, counts, models, _ = spied_run(
        tmp_path, _MOCK_NX_NCP_ZIP, True, ("pst", "rd"), "ac_single_pass", extra_customize=threshold_and_overload,
    )

    assert chosen, "the threshold left no secured pair out of the model"
    assert counts["build"] == 1
    assert chosen["pair"] not in set(models[0].nx_branch_contingency_pairs)  # not added
    assert chosen["pair"] not in models[0].overload_monitoring["nx_patl"]
    summary = _summary(output_dir)
    assert int(summary["final_check_nx_patl_overloaded_elements"]) >= 1
    assert float(summary["final_check_nx_patl_overload_a"]) >= 0.5 * chosen["limit"] - 1e-6


def test_two_consecutive_runs_in_different_modes_reset_the_module_level_run_settings(tmp_path_factory):
    from milp import milp_builder, milp_solver
    from pre_milp import lf_parameters

    def unusual_settings(rp, monkeypatch):
        monkeypatch.setattr(rp, "LF_THREAD_COUNT", 2)
        monkeypatch.setattr(rp, "DEBUG_LOG_MODE", True)
        monkeypatch.setattr(rp, "SOLVER_MIP_REL_GAP", 0.5)

    spied_run(
        tmp_path_factory.mktemp("first_run"), _MOCK_NX_NCP_ZIP, True, ("pst", "rd"), "ac_iterative",
        extra_customize=unusual_settings,
    )
    assert lf_parameters.LF_THREAD_COUNT == 2 and milp_builder.DEBUG_LOG_MODE is True
    assert milp_solver.SOLVER_MIP_REL_GAP == 0.5

    second_dir, _, _, _ = spied_run(
        tmp_path_factory.mktemp("second_run"), _MOCK_NX_NCP_ZIP, True, ("pst", "rd"), "ac_single_pass",
    )

    assert lf_parameters.LF_THREAD_COUNT == 1 and milp_builder.DEBUG_LOG_MODE is False
    assert milp_solver.SOLVER_MIP_REL_GAP is None
    assert _summary(second_dir)["ac_verification_status"] == "SINGLE_PASS"


# ===========================================================================
# ra_types x calculation_mode
# ===========================================================================

_PST_FILES = (
    "results_pst.csv", "results_tso_tap_limits.csv", "results_curative_pst.csv", "results_curative_pst_groups.csv",
    "pst_cra_availability.csv", "sensitivity_pst_n0.csv", "sensitivity_pst_nx.csv",
)
_RD_FILES = (
    "results_preventive_rd.csv", "results_preventive_rd_ra_count.csv", "results_preventive_rd_ra_groups.csv",
    "results_generating_units.csv", "results_lead_times.csv", "results_curative_rd.csv", "rd_cra_availability.csv",
    "sensitivity_rd_n0.csv", "sensitivity_rd_nx.csv", "glsk_resolved.csv",
)
_PST_SUMMARY_FIELDS = ("sum_pst_penalty_cost_eur", "sum_curative_pst_penalty_cost_eur")
_RD_SUMMARY_FIELDS = (
    "sum_rd_volume_upward_mw", "sum_rd_volume_downward_mw", "sum_rd_cost_eur", "sum_rd_penalty_cost_eur",
    "sum_curative_rd_cost_eur", "sum_ra_count_penalty_eur", "sum_startup_cost_eur", "sum_shutdown_cost_eur",
    "sum_bid_activation_cost_eur",
)
_PST_VARIABLES = ("tap_change_upward", "curative_pst_contingency_pairs")
_RD_VARIABLES = ("rd_volume_upward", "curative_bid_contingency_pairs")


@pytest.mark.parametrize("nx", [False, True], ids=["nx_off", "nx_on"])
@pytest.mark.parametrize("ncp_name", ["mock", "generic"])
@pytest.mark.parametrize("ra_types", [("pst",), ("rd",), ("pst", "rd")], ids=["pst", "rd", "pst+rd"])
def test_every_ra_type_set_runs_and_a_disabled_type_leaves_no_trace(tmp_path, ra_types, ncp_name, nx):
    ncp_zip = _MOCK_NX_NCP_ZIP if ncp_name == "mock" else GENERIC_NCP_ZIP

    output_dir, counts, models, sensitivity_calls = spied_run(tmp_path, ncp_zip, nx, ra_types, "ac_iterative")

    assert counts["build"] >= 1
    summary = _summary(output_dir)
    assert summary["ra_types"] == "+".join(ra_types)
    for disabled, files, variables, n0_count_key, nx_flag, summary_fields in (
        ("pst", _PST_FILES, _PST_VARIABLES, "n0_pst_sensitivity", 0, _PST_SUMMARY_FIELDS),
        ("rd", _RD_FILES, _RD_VARIABLES, "n0_rd_sensitivity", 1, _RD_SUMMARY_FIELDS),
    ):
        if disabled in ra_types:
            continue
        # the summary fields of a disabled type exist and are 0, they are not missing
        assert {name: float(summary[name]) for name in summary_fields} == {name: 0.0 for name in summary_fields}
        assert counts[n0_count_key] == 0
        assert all(call[nx_flag] is False for call in sensitivity_calls["nx"])
        assert [name for name in files if (output_dir / name).exists()] == []
        for model in models:
            assert [name for name in variables if hasattr(model, name)] == []


@pytest.mark.parametrize("mode", ["ac_iterative", "ac_single_pass"])
@pytest.mark.parametrize("ra_types", [("pst",), ("rd",), ("pst", "rd")], ids=["pst", "rd", "pst+rd"])
def test_all_six_combinations_of_ra_types_and_ac_mode_finish_on_the_mock_data(tmp_path, ra_types, mode):
    output_dir, counts, _, _ = spied_run(tmp_path, _MOCK_NX_NCP_ZIP, True, ra_types, mode)

    summary = _summary(output_dir)
    assert summary["calculation_mode"] == mode
    assert summary["ac_verification_status"] in {"CONVERGED", "MAX_ITERATIONS_REACHED", "CYCLIC_REPETITION", "SINGLE_PASS"}
    if mode == "ac_single_pass":
        assert counts["build"] == 1 and counts["find_new_pairs"] == 0


# ===========================================================================
# GUI
# ===========================================================================

def _gui_common():
    pytest.importorskip("streamlit")
    rao_pages = str(REPO_ROOT / "src" / "rao_pages")
    if rao_pages not in sys.path:
        sys.path.insert(0, rao_pages)
    import _gui_common
    return _gui_common


def _page(name):
    pytest.importorskip("streamlit")
    from streamlit.testing.v1 import AppTest
    return AppTest.from_file(str(REPO_ROOT / "src" / "rao_pages" / name), default_timeout=60)


def test_the_gui_results_section_reads_the_status_and_the_one_row_history_of_a_single_pass_run(single_pass_run):
    import pandas as pd

    gui = _gui_common()
    output_dir = single_pass_run[0]
    page = _page("1_Main.py")
    page.session_state["run_complete"] = True
    page.session_state["run_exit_code"] = 0
    page.session_state["tmpdir"] = output_dir.parent
    page.session_state["tier2_inventory"] = gui.read_tier2_inventory(output_dir)

    # the results section reads every result file (downloads and the zip), these two included
    page.run()

    assert not page.exception
    assert any("Results" in element.value for element in page.subheader)
    # status and history read as the page reads a result table (pandas)
    summary = pd.read_csv(output_dir / "results_summary.csv", encoding=TEXT_ENCODING).set_index("metric")["value"]
    assert summary["ac_verification_status"] == "SINGLE_PASS"
    # keep_default_na=False: pandas reads "n/a" as NaN by default
    history = pd.read_csv(output_dir / "results_iteration_history.csv", keep_default_na=False, encoding=TEXT_ENCODING)
    assert len(history) == 1 and history.loc[0, "converged_by"] == "n/a"


def test_the_calculation_mode_of_the_next_run_falls_back_to_the_saved_setting():
    gui = _gui_common()

    assert gui.selected_calculation_mode({}, {"calculation_mode": "ac_iterative"}) == "ac_iterative"
    chosen = {gui.CALCULATION_MODE_STATE_KEY: "ac_single_pass"}
    assert gui.selected_calculation_mode(chosen, {"calculation_mode": "ac_iterative"}) == "ac_single_pass"


_LOOP_ONLY_SETTINGS = (
    "max_change_ra_sum_threshold", "max_change_ra", "max_change_overload",
    "max_linearisation_iterations", "max_completeness_iterations",
)


def _disabled_by_label(page):
    return {element.label: element.disabled for element in page.number_input}


@pytest.mark.parametrize("mode", ["ac_single_pass", "ac_iterative", None])
def test_the_settings_page_greys_out_the_loop_settings_in_single_pass_also_after_an_edit(mode):
    gui = _gui_common()
    page = _page("3_RAO_Settings.py")
    if mode is not None:
        page.session_state[gui.CALCULATION_MODE_STATE_KEY] = mode  # what the Main page left behind
    page.run()
    # an edit on this page reruns it (the rerun after which a widget key of the Main page is gone)
    next(e for e in page.number_input if e.label == "min_loading_threshold_pct").set_value(1.0).run()

    assert not page.exception
    disabled = _disabled_by_label(page)
    single_pass = mode == "ac_single_pass"
    assert {name: disabled[name] for name in _LOOP_ONLY_SETTINGS} == {name: single_pass for name in _LOOP_ONLY_SETTINGS}
    assert disabled["incremental_ac_fallback_max_steps"] is False


def test_returning_to_the_main_page_keeps_the_chosen_calculation_mode():
    gui = _gui_common()
    page = _page("1_Main.py")
    # the selectbox's own state is gone after another page ran; the plain key is not
    page.session_state[gui.CALCULATION_MODE_STATE_KEY] = "ac_single_pass"
    page.run()

    assert page.selectbox(key="calculation_mode_select").value == "ac_single_pass"
    page.selectbox(key="calculation_mode_select").set_value("ac_iterative").run()
    assert page.session_state[gui.CALCULATION_MODE_STATE_KEY] == "ac_iterative"


def test_the_gui_temp_config_round_trip_keeps_ra_types_and_calculation_mode():
    import run_pipeline

    gui = _gui_common()
    rao_config = {section: dict(values) for section, values in gui.DEFAULT_RAO_CONFIG.items()}
    rao_config["workflow_toggles"]["ra_types"] = ["rd"]
    rao_config["workflow_toggles"]["calculation_mode"] = "ac_single_pass"

    tmpdir = gui.build_temp_run_dir(b"cgm", b"ncp", rao_config, gui.DEFAULT_LOAD_FLOW_CONFIG)
    try:
        path = tmpdir / "src" / "rao" / "config" / "rao_config.yaml"
        written = yaml.safe_load(path.read_text(encoding=TEXT_ENCODING))
        run_pipeline.validate_config_ranges(written, path)  # the pipeline accepts what the GUI wrote
    finally:
        gui.cleanup_temp_run_dir(tmpdir)

    assert written["workflow_toggles"]["ra_types"] == ["rd"]
    assert written["workflow_toggles"]["calculation_mode"] == "ac_single_pass"
    assert "enable_pst_remedial_actions" not in written["workflow_toggles"]


def test_settings_saved_before_ra_types_existed_are_migrated():
    gui = _gui_common()

    migrated = gui.migrate_saved_workflow_toggles(
        {"enable_pst_remedial_actions": False, "enable_rd_remedial_actions": True, "enable_nx_analysis": True},
    )

    assert migrated == {"ra_types": ["rd"], "enable_nx_analysis": True}
    assert gui.migrate_saved_workflow_toggles({"ra_types": ["pst"]}) == {"ra_types": ["pst"]}
