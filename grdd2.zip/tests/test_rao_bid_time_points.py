"""tests/test_rao_bid_time_points.py - bid time points are matched by date and time when a schedule has
points on several days (a schedule on one day is read by clock time, as before). Small hand-written files."""

import logging

import pytest

from pre_milp import ncp_parser
from text_encoding import TEXT_ENCODING

HEADER = ('<?xml version="1.0"?><rdf:RDF xmlns:rdf="http://www.w3.org/1999/02/22-rdf-syntax-ns#" '
          'xmlns:cim="https://cim.ucaiug.io/ns#" xmlns:nc="https://cim4.eu/ns/nc#">')
NC_NS = "https://cim4.eu/ns/nc#"


def _schedule(kind="none"):
    return ('<nc:PowerBidSchedule rdf:ID="_S1"><cim:IdentifiedObject.mRID>S1</cim:IdentifiedObject.mRID>'
            '<nc:PowerBidSchedule.PowerRemedialAction rdf:resource="#_RA1"/>'
            f'<nc:PowerBidSchedule.direction rdf:resource="{NC_NS}BidDirectionKind.up"/>'
            f'<nc:BaseTimeSeries.interpolationKind rdf:resource="{NC_NS}InterpolationKind.{kind}"/></nc:PowerBidSchedule>')


def _point(name, at_time, p, price):
    return (f'<nc:PowerBidScheduleTimePoint rdf:ID="_{name}"><nc:PowerBidScheduleTimePoint.atTime>{at_time}</nc:PowerBidScheduleTimePoint.atTime>'
            '<nc:PowerBidScheduleTimePoint.PowerBidSchedule rdf:resource="#_S1"/>'
            f'<nc:PowerBidScheduleTimePoint.p>{p}</nc:PowerBidScheduleTimePoint.p>'
            f'<nc:PowerBidScheduleTimePoint.price>{price}</nc:PowerBidScheduleTimePoint.price></nc:PowerBidScheduleTimePoint>')


def _bids(tmp_path, points, kind="none", timestamps=("1030Z",), run_date=None, price_timestamp=None):
    path = tmp_path / "X_SIS.xml"
    path.write_text(HEADER + _schedule(kind) + "".join(_point(f"T{i}", *point) for i, point in enumerate(points)) + "</rdf:RDF>",
                    encoding=TEXT_ENCODING)
    bids = ncp_parser.parse_power_bids(ncp_parser._load_graph(path), {"RA1"}, "X", list(timestamps), price_timestamp, run_date)
    assert len(bids) == 1
    return bids[0]


DAY1_100 = ("2024-02-22T10:30:00Z", 100, 7)
DAY2_5 = ("2024-02-23T10:30:00Z", 5, 99)


@pytest.mark.parametrize("points", [[DAY1_100, DAY2_5], [DAY2_5, DAY1_100]], ids=["run day first", "next day first"])
def test_rao_the_run_day_governs_not_the_next_day_at_the_same_clock_time(tmp_path, points):
    bid = _bids(tmp_path, points)
    assert bid.available_mw == {"1030Z": 100.0}
    assert bid.price_eur_mw == 7.0


def test_rao_a_given_run_date_selects_that_day(tmp_path):
    assert _bids(tmp_path, [DAY1_100, DAY2_5], run_date="2024-02-23").available_mw == {"1030Z": 5.0}
    assert _bids(tmp_path, [DAY1_100, DAY2_5], run_date="2024-02-22").available_mw == {"1030Z": 100.0}


def test_rao_a_schedule_on_one_day_is_still_read_by_clock_time(tmp_path):
    # the single day differs from the given run date: the old rule (clock time only) applies
    assert _bids(tmp_path, [DAY1_100], run_date="2030-01-01").available_mw == {"1030Z": 100.0}


def test_rao_several_days_without_a_point_at_the_run_time_follow_the_interpolation_kind(tmp_path, caplog):
    points = [("2024-02-22T09:30:00Z", 100, 7), ("2024-02-23T09:30:00Z", 5, 99)]
    with caplog.at_level(logging.WARNING, logger=ncp_parser.log.name):
        none = _bids(tmp_path, points, kind="none")
    assert none.available_mw == {"1030Z": 0.0}
    messages = [r.getMessage() for r in caplog.records]
    assert any("1 bid(s) with time points on several days have no time point at the run's date and time (1030Z)" in m for m in messages)
    assert any("1 bid(s) have time points on several days - read by date and time, run day 2024-02-22" in m for m in messages)
    assert _bids(tmp_path, points, kind="previous").available_mw == {"1030Z": 100.0}   # the run day's 09:30
    assert _bids(tmp_path, points, kind="next").available_mw == {"1030Z": 5.0}         # the next day's 09:30


def test_rao_linear_interpolation_runs_across_midnight(tmp_path):
    points = [("2024-02-22T22:00:00Z", 100, 10), ("2024-02-23T02:00:00Z", 20, 30)]
    bid = _bids(tmp_path, points, kind="linear", timestamps=("2300Z", "0000Z", "0100Z"), price_timestamp="0000Z")
    assert bid.available_mw == {"2300Z": pytest.approx(80.0), "0000Z": pytest.approx(60.0), "0100Z": pytest.approx(40.0)}
    assert bid.price_eur_mw == pytest.approx(20.0)


def test_rao_a_timestamp_after_midnight_reads_the_next_day(tmp_path):
    points = [("2024-02-22T23:30:00Z", 10, 1), ("2024-02-23T00:30:00Z", 30, 2), ("2024-02-22T00:30:00Z", 999, 3)]
    bid = _bids(tmp_path, points, timestamps=("2330Z", "0030Z"))
    assert bid.available_mw == {"2330Z": 10.0, "0030Z": 30.0}


def test_rao_day_numbers_of_iso_datetimes(tmp_path):
    assert ncp_parser._iso_day_number("T10:30:00Z") is None
    assert ncp_parser._iso_day_number("2024-02-23T10:30:00Z") - ncp_parser._iso_day_number("2024-02-22T10:30:00Z") == 1
