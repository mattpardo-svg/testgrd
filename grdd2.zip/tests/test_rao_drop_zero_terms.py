"""tests/test_rao_drop_zero_terms.py - with an N-X pruning threshold above 0 the N-X rows leave out the terms with a zero
or missing sensitivity (NxMilpInputs.drop_zero_*_terms); with the default threshold 0 the rows keep every term. The optimum
does not change."""

import csv
import math

import pyomo.environ as pyo
import pytest
from pyomo.core.expr.visitor import identify_variables

from data_model import AEType, AssessedElement, BidDirection, PowerBid, RAKind, RDUnit
from milp.milp_builder import NxMilpInputs, RdMilpInputs, build_n0_milp_model


def _bid(mrid, ra, mw=100.0, direction=BidDirection.UP):
    return PowerBid(mrid=mrid, ra_mrid=ra, direction=direction, available_mw={"1030Z": mw}, price_eur_mw=10.0,
                    penalty_factor=0.0, lead_time_h=0.0, activation_cost_eur=None, min_energy_mwh=None,
                    max_energy_mwh=None, step_size_mw=None)


def _model(drop):
    units = [RDUnit(mrid=f"RD{i}", name=f"RD{i}", tso="T", gu_mrid=f"GU{i}", gu_name=f"GU{i}", available=True,
                    kind=RAKind.PREVENTIVE, initial_p=50.0, max_p=200.0, min_p=0.0, raise_ramp_rate=None,
                    lower_ramp_rate=None) for i in (1, 2, 3)]
    rd_inputs = RdMilpInputs(
        rd_list=units, bid_list=[_bid("BID1", "RD1"), _bid("BID2", "RD2"), _bid("BID3", "RD3", direction=BidDirection.DOWN)],   # BID3 balances BID1
        glsk={f"RD{i}": {f"GU{i}": 1.0} for i in (1, 2, 3)}, sensitivity_rd_n0_pruned={},
        generator_data={f"GU{i}": {"target_p": 50.0, "max_p": 200.0, "min_p": 0.0} for i in (1, 2, 3)},
        penalty_reference_rd_pra=10.0,
    )
    # GU1 relieves the branch, GU2 has an exact zero, GU3 is missing (pruned)
    nx_inputs = NxMilpInputs(
        lf_nx={"CO1": {"B1": {1: 1100.0}}}, sensitivity_pst_nx={}, sensitivity_rd_nx={"CO1": {("B1", "GU1"): -2.0, ("B1", "GU2"): 0.0}},
        penalty_cost_overload_nx_patl=500.0, drop_zero_rd_terms=drop,
    )
    ae = AssessedElement(mrid="AE1", name="AE1", tso="T", ae_type=AEType.SECURED, branch_mrid="B1", secured_for_region=None,
                         scanned_for_region=None, exclusion_reason=None, patl_ka={"1030Z": 1.0})
    return build_n0_milp_model([ae], "1030Z", lf_initial={"B1": {1: 500.0}}, penalty_cost_overload_n0=1000.0,
                               rd_inputs=rd_inputs, nx_inputs=nx_inputs)


def _bids_in_row(model):
    return sorted({v.name for v in identify_variables(model.nx_patl_loading["B1", "CO1"].body)} & {f"rd_volume_upward[BID{i}]" for i in (1, 2, 3)}
                  | {v.name for v in identify_variables(model.nx_patl_loading["B1", "CO1"].body) if v.name.startswith("rd_volume")})


def test_rao_by_default_every_term_stays_in_the_row_even_with_a_zero_sensitivity():
    names = [n for n in _bids_in_row(_model(drop=False))]
    assert any("BID2" in n for n in names) and any("BID3" in n for n in names) and any("BID1" in n for n in names)


def test_rao_with_the_flag_only_the_terms_with_a_sensitivity_remain():
    names = _bids_in_row(_model(drop=True))
    assert names and all("BID1" in n for n in names)


def test_rao_the_optimum_is_the_same_with_and_without_the_zero_terms():
    results = []
    for drop in (False, True):
        model = _model(drop)
        assert str(pyo.SolverFactory("appsi_highs").solve(model).solver.termination_condition) == "optimal"
        results.append((pyo.value(model.objective), pyo.value(model.rd_volume_upward["BID1"])))
    assert results[0][0] > 0 and results[0][1] > 0                            # the overload is relieved through GU1
    assert math.isclose(results[0][0], results[1][0], rel_tol=1e-9) and math.isclose(results[0][1], results[1][1], rel_tol=1e-9, abs_tol=1e-9)


# --- the pipeline sets the flags from the thresholds ----------------------------------------------------------------

def _run(tmp_path, name, threshold, force_keep=False):
    from helpers import run_pipeline_on_fixture_inputs, _MOCK_NX_NCP_ZIP
    from milp import milp_builder
    seen = []

    def customize(rp, monkeypatch):
        monkeypatch.setattr(rp, "SENSITIVITY_THRESHOLD_PCT_PST_NX", threshold)
        monkeypatch.setattr(rp, "SENSITIVITY_THRESHOLD_PCT_RD_NX", threshold)
        original = milp_builder.NxMilpInputs

        def wrapper(**kwargs):
            seen.append((kwargs.get("drop_zero_pst_terms"), kwargs.get("drop_zero_rd_terms")))
            if force_keep:
                kwargs["drop_zero_pst_terms"] = kwargs["drop_zero_rd_terms"] = False
            return original(**kwargs)

        monkeypatch.setattr(rp, "NxMilpInputs", wrapper)

    run = run_pipeline_on_fixture_inputs(tmp_path / name, _MOCK_NX_NCP_ZIP, enable_nx_analysis=True,
                                         ra_types=("pst", "rd", "countertrade"), customize_pipeline=customize)
    summary = {row[0]: row[1] for row in csv.reader(open(run.output_dir / "results_summary.csv", encoding="utf-8")) if row}
    return seen, summary


def test_rao_the_pipeline_keeps_every_term_at_threshold_zero(tmp_path):
    seen, _ = _run(tmp_path, "zero", 0.0)
    assert seen and set(seen) == {(False, False)}


def test_rao_with_a_threshold_the_pipeline_drops_the_zero_terms_and_finds_the_same_optimum(tmp_path):
    seen, dropped = _run(tmp_path, "dropped", 0.02)
    assert seen and set(seen) == {(True, True)}
    _, kept = _run(tmp_path, "kept", 0.02, force_keep=True)
    assert dropped.keys() == kept.keys()
    for key in dropped:
        try:
            assert math.isclose(float(dropped[key]), float(kept[key]), rel_tol=1e-8, abs_tol=1e-6), key
        except ValueError:
            assert dropped[key] == kept[key], key
