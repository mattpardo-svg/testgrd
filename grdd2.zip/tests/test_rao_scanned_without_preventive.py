"""
test_rao_scanned_without_preventive.py — a hard N-0 scanned-element row in a run without any preventive remedial
action (Spec_Coverage 4b, DECISIONS 67): N-X on, curative RD only. No remedial action touches the N-0 scanned row, so
its left side is a constant; the model must build and the run must write its results (before 19 Oct 2026 Pyomo
stopped the build with InvalidConstraintError).

The NCP is a variant of NCP_mock_standard.zip built here (the mock data stays unchanged): every remedial
action of the RA files is curative, and the assessed element XNE_BO_Line_2 of Belgovia is a scanned element (a
ScannedForRegion and an exclusionReason instead of its SecuredForRegion).
"""
import zipfile

import pytest
from pyomo.core.expr.visitor import identify_variables

from helpers import _MOCK_NX_NCP_ZIP, run_pipeline_on_fixture_inputs

SCANNED_AE = "4b19ce42-6c5a-4070-884e-4c2889735c3f"          # XNE_BO_Line_2 in Belgovia_AE.xml
SCANNED_BRANCH = "b58bf21a-096a-4dae-9a01-3f03b60c24c7"      # its ConductingEquipment
EXCLUSION_REASON = "https://cim4.eu/ns/nc#SecuredExclusionReasonKind.systemOperator"


def _curative_only_ncp_with_a_scanned_element(dest):
    with zipfile.ZipFile(_MOCK_NX_NCP_ZIP) as source, zipfile.ZipFile(dest, "w") as out:
        for item in source.infolist():
            data = source.read(item.filename)
            if item.filename.endswith("_RA.xml"):
                data = data.replace(b"RemedialActionKind.preventive", b"RemedialActionKind.curative")
            elif item.filename == "Belgovia_AE.xml":
                text = data.decode("utf-8")
                start = text.index(f'rdf:ID="_{SCANNED_AE}"')
                end = text.index("</nc:AssessedElement>", start)
                element = text[start:end]
                assert element.count("AssessedElement.SecuredForRegion") == 1
                scanned = element.replace("AssessedElement.SecuredForRegion", "AssessedElement.ScannedForRegion").replace(
                    "<nc:AssessedElement.ScannedForRegion",
                    f'<nc:AssessedElement.exclusionReason rdf:resource="{EXCLUSION_REASON}"/>\n    '
                    "<nc:AssessedElement.ScannedForRegion",
                )
                data = (text[:start] + scanned + text[end:]).encode("utf-8")
            out.writestr(item, data)
    return dest


@pytest.fixture(scope="module")
def curative_only_run(tmp_path_factory):
    work = tmp_path_factory.mktemp("scanned_without_preventive")
    ncp = _curative_only_ncp_with_a_scanned_element(work / "ncp.zip")
    models = []

    def keep_models(rp, monkeypatch):
        build = rp.ac_convergence_loop.build_n0_milp_model

        def keeping_build(*args, **kwargs):
            models.append(build(*args, **kwargs))
            return models[-1]

        monkeypatch.setattr(rp.ac_convergence_loop, "build_n0_milp_model", keeping_build)
        assert rp.SCANNED_ELEMENT_CONSTRAINT_HARD is True

    run = run_pipeline_on_fixture_inputs(
        work / "run", ncp, enable_nx_analysis=True, ra_types=("rd",), calculation_mode="ac_single_pass",
        customize_pipeline=keep_models,
    )
    return run.output_dir, models


def test_a_hard_scanned_row_without_any_preventive_action_builds_and_the_run_writes_its_results(curative_only_run):
    output_dir, models = curative_only_run
    assert models, "no model was built"
    model = models[-1]
    # only curative RD acts: no preventive block of any type, curative RD variables exist
    assert not hasattr(model, "rd_volume_upward") and not hasattr(model, "tap_change_upward")
    assert not hasattr(model, "hvdc_change") and hasattr(model, "curative_rd_volume_upward")
    # the scanned branch is in the model with a hard N-0 row (no slack variable) that no remedial action touches: a
    # constant row, satisfied (the effective limit is at least the original loading): it holds no variable
    assert SCANNED_BRANCH in set(model.scanned_branch_ids) and not hasattr(model, "scanned_overload_slack")
    assert list(identify_variables(model.scanned_element_n0[SCANNED_BRANCH].body)) == []
    names = {p.name for p in output_dir.glob("*")}
    assert {"results_summary.csv", "results_nx_loadings.csv", "results_curative_rd.csv"} <= names
