"""parse_rd_units for the standard RedispatchRemedialAction (WP3): units from the shift key chain (bid route and
strategy route), bids on the RA, the old RotatingMachineAction form as a fallback with a deprecation warning."""
import logging

import pytest

from data_model import BidDirection, RAKind
from pre_milp import ncp_parser
from text_encoding import TEXT_ENCODING

HEADER = """<?xml version="1.0" encoding="UTF-8"?>
<rdf:RDF
    xmlns:rdf="http://www.w3.org/1999/02/22-rdf-syntax-ns#"
    xmlns:nc="https://cim4.eu/ns/nc#"
    xmlns:cim="https://cim.ucaiug.io/ns#">
"""
FOOTER = "</rdf:RDF>\n"
TIME = "2022-06-15T10:30:00Z"
KIND = "https://cim4.eu/ns/nc#RemedialActionKind."
DIRECTION = "https://cim4.eu/ns/nc#MarketRegulationDirectionKind."

CGM = {
    "G1": {"name": "Gen 1", "target_p": 50.0, "max_p": 100.0, "min_p": 10.0},
    "G2": {"name": "Gen 2", "target_p": 20.0, "max_p": 60.0, "min_p": 0.0},
}
MAP = {"GU-A": ["G1"], "GU-B": ["G2"]}


def _write(tmp_path, name, body):
    path = tmp_path / name
    path.write_text(HEADER + body + FOOTER, encoding=TEXT_ENCODING)
    return path


def _rd(ra="RA1", kind="preventive", available="true", penalty="1.5", cls="RedispatchRemedialAction", extra=""):
    return f"""
    <nc:{cls} rdf:ID="_{ra}">
      <cim:IdentifiedObject.mRID>{ra}</cim:IdentifiedObject.mRID>
      <cim:IdentifiedObject.name>Name {ra}</cim:IdentifiedObject.name>
      <nc:RemedialAction.normalAvailable>{available}</nc:RemedialAction.normalAvailable>
      <nc:RemedialAction.kind rdf:resource="{KIND}{kind}"/>
      <nc:RemedialAction.penaltyFactor>{penalty}</nc:RemedialAction.penaltyFactor>{extra}
    </nc:{cls}>"""


def _strategy(strategy, ra):
    return f"""
    <nc:PowerShiftKeyStrategy rdf:about="#_{strategy}">
      <nc:PowerShiftKeyStrategy.PowerRemedialAction rdf:resource="#_{ra}"/>
      <cim:IdentifiedObject.mRID>{strategy}</cim:IdentifiedObject.mRID>
    </nc:PowerShiftKeyStrategy>"""


def _bid(ra, bid=None, direction="up", p=10.0, price=25.0):
    bid = bid or f"PB-{ra}-{direction}"
    return f"""
    <nc:PowerBidSchedule rdf:ID="_{bid}">
      <cim:IdentifiedObject.mRID>{bid}</cim:IdentifiedObject.mRID>
      <nc:PowerBidSchedule.PowerRemedialAction rdf:resource="#_{ra}"/>
      <nc:PowerBidSchedule.direction rdf:resource="{DIRECTION}{direction}"/>
    </nc:PowerBidSchedule>
    <nc:PowerBidScheduleTimePoint rdf:ID="_{bid}-T">
      <nc:PowerBidScheduleTimePoint.atTime>{TIME}</nc:PowerBidScheduleTimePoint.atTime>
      <nc:PowerBidScheduleTimePoint.PowerBidSchedule rdf:resource="#_{bid}"/>
      <nc:PowerBidScheduleTimePoint.p>{p}</nc:PowerBidScheduleTimePoint.p>
      <nc:PowerBidScheduleTimePoint.price>{price}</nc:PowerBidScheduleTimePoint.price>
    </nc:PowerBidScheduleTimePoint>"""


def _by_bid(bid, key, dist=None):
    dist = dist or f"D-{bid}-{key}"
    return f"""
    <nc:PowerShiftKeyDistribution rdf:ID="_{dist}">
      <nc:PowerShiftKeyDistribution.PowerBidSchedule rdf:resource="#_{bid}"/>
      <nc:PowerShiftKeyDistribution.PowerShiftKeySchedule rdf:resource="#_{key}"/>
    </nc:PowerShiftKeyDistribution>"""


def _by_strategy(strategy, key):
    return f"""
    <nc:PowerShiftKeyDistribution rdf:ID="_D-{strategy}-{key}">
      <nc:PowerShiftKeyDistribution.PowerShiftKeyStrategy rdf:resource="#_{strategy}"/>
      <nc:PowerShiftKeyDistribution.PowerShiftKeySchedule rdf:resource="#_{key}"/>
    </nc:PowerShiftKeyDistribution>"""


def _key(key, unit, resource="GeneratingUnit"):
    return f"""
    <nc:PowerShiftKeySchedule rdf:ID="_{key}">
      <cim:IdentifiedObject.mRID>{key}</cim:IdentifiedObject.mRID>
      <nc:PowerShiftKeySchedule.{resource} rdf:resource="#_{unit}"/>
    </nc:PowerShiftKeySchedule>"""


def _parse(tmp_path, ra_body, sis_body, cgm=CGM, by_unit=MAP, name="Test", **kwargs):
    ra = _write(tmp_path, f"{name}_RA.xml", ra_body)
    sis = _write(tmp_path, f"{name}_SIS.xml", sis_body) if sis_body is not None else None
    return ncp_parser.parse_rd_units(ra, sis, "T", ["1030Z"], cgm, generators_by_unit=by_unit, **kwargs)


def _messages(caplog, *words):
    return [r.getMessage() for r in caplog.records if r.levelno >= logging.WARNING and all(w in r.getMessage() for w in words)]


# ---------------------------------------------------------------------------
# (a) the standard class with units from the shift key chain
# ---------------------------------------------------------------------------

def test_rao_a_redispatch_remedial_action_gets_its_units_from_the_bid_route(tmp_path):
    sis = _bid("RA1") + _by_bid("PB-RA1-up", "K1") + _key("K1", "GU-A") + _by_bid("PB-RA1-up", "K2", dist="D2") + _key("K2", "GU-B")
    units, _ = _parse(tmp_path, _rd(), sis)
    assert [(u.mrid, u.gu_mrid, u.gu_name, u.initial_p, u.max_p, u.min_p) for u in sorted(units, key=lambda u: u.gu_mrid)] == [
        ("RA1", "G1", "Gen 1", 50.0, 100.0, 10.0), ("RA1", "G2", "Gen 2", 20.0, 60.0, 0.0)]
    assert all(u.available and u.kind == RAKind.PREVENTIVE and u.penalty_factor == 1.5 and u.name == "Name RA1" for u in units)
    assert all(u.raise_ramp_rate is None and u.lower_ramp_rate is None for u in units)      # not in the profile


def test_rao_the_strategy_route_gives_the_units_of_an_ra_without_a_bid_key(tmp_path):
    sis = _bid("RA1") + _by_strategy("S1", "K1") + _key("K1", "GU-B")
    units, _ = _parse(tmp_path, _rd() + _strategy("S1", "RA1"), sis)
    assert [u.gu_mrid for u in units] == ["G2"]


def test_rao_the_bid_route_wins_over_the_strategy_route_for_the_units(tmp_path):
    sis = (_bid("RA1") + _by_bid("PB-RA1-up", "K1") + _key("K1", "GU-A")
           + _by_strategy("S1", "K2") + _key("K2", "GU-B"))
    units, _ = _parse(tmp_path, _rd() + _strategy("S1", "RA1"), sis)
    assert [u.gu_mrid for u in units] == ["G1"]


def test_rao_a_unit_in_both_bid_keys_is_one_unit(tmp_path):
    sis = (_bid("RA1", direction="up") + _bid("RA1", direction="down", p=-5.0)
           + _by_bid("PB-RA1-up", "K1") + _by_bid("PB-RA1-down", "K1", dist="D2") + _key("K1", "GU-A"))
    units, bids = _parse(tmp_path, _rd(), sis)
    assert [u.gu_mrid for u in units] == ["G1"] and len(bids) == 2


def test_rao_a_redispatch_ra_without_any_key_is_ignored_with_a_warning(tmp_path, caplog):
    with caplog.at_level(logging.WARNING):
        units, bids = _parse(tmp_path, _rd(), _bid("RA1"))
    assert units == [] and bids == []
    assert len(_messages(caplog, "IGNORED", "RA1", "shift key")) == 1


def test_rao_a_redispatch_ra_without_a_sis_file_is_ignored_with_a_warning(tmp_path, caplog):
    with caplog.at_level(logging.WARNING):
        units, _ = _parse(tmp_path, _rd(), None)
    assert units == [] and len(_messages(caplog, "IGNORED", "RA1")) == 1


def test_rao_a_redispatch_ra_with_units_is_not_reported_as_ignored(tmp_path, caplog):
    with caplog.at_level(logging.WARNING):
        _parse(tmp_path, _rd(), _bid("RA1") + _by_bid("PB-RA1-up", "K1") + _key("K1", "GU-A"))
    assert _messages(caplog, "IGNORED") == []


def test_rao_resources_that_are_not_generating_units_are_no_redispatch_units(tmp_path):
    sis = _bid("RA1") + _by_bid("PB-RA1-up", "K1") + _key("K1", "LOAD-1", resource="EnergyConsumer")
    units, _ = _parse(tmp_path, _rd(), sis)
    assert units == []


def test_rao_a_unit_with_several_generators_is_dropped_with_a_warning(tmp_path, caplog):
    sis = _bid("RA1") + _by_bid("PB-RA1-up", "K1") + _key("K1", "GU-A") + _by_bid("PB-RA1-up", "K2", dist="D2") + _key("K2", "GU-B")
    with caplog.at_level(logging.WARNING):
        units, _ = _parse(tmp_path, _rd(), sis, by_unit={"GU-A": ["G1", "G2"], "GU-B": ["G2"]})
    assert [u.gu_mrid for u in units] == ["G2"] and len(_messages(caplog, "GU-A", "2 generators")) == 1


def test_rao_a_generator_id_in_the_shift_key_is_the_old_form_with_one_deprecation_warning(tmp_path, caplog):
    sis = _bid("RA1") + _bid("RA2") + _by_bid("PB-RA1-up", "K1") + _key("K1", "G1") + _by_bid("PB-RA2-up", "K2") + _key("K2", "G2")
    with caplog.at_level(logging.WARNING):
        units, _ = _parse(tmp_path, _rd() + _rd("RA2"), sis)
    assert sorted((u.mrid, u.gu_mrid) for u in units) == [("RA1", "G1"), ("RA2", "G2")]
    assert len(_messages(caplog, "deprecated")) == 1


def test_rao_a_unit_that_is_not_in_the_cgm_is_skipped_with_a_warning(tmp_path, caplog):
    sis = _bid("RA1") + _by_bid("PB-RA1-up", "K1") + _key("K1", "GU-A")
    with caplog.at_level(logging.WARNING):
        units, _ = _parse(tmp_path, _rd(), sis, cgm={"G2": CGM["G2"]})
    assert units == [] and len(_messages(caplog, "G1", "not found in CGM")) == 1


def test_rao_the_curative_links_and_exclusions_of_a_redispatch_ra_are_read(tmp_path):
    ra = _rd(kind="curative", available="false") + """
    <nc:ContingencyWithRemedialAction rdf:ID="_L1">
      <nc:ContingencyWithRemedialAction.RemedialAction rdf:resource="#_RA1"/>
      <nc:ContingencyWithRemedialAction.Contingency rdf:resource="#_CO1"/>
      <nc:ContingencyWithRemedialAction.combinationConstraintKind rdf:resource="https://cim4.eu/ns/nc#ElementCombinationConstraintKind.included"/>
    </nc:ContingencyWithRemedialAction>
    <nc:ContingencyWithRemedialAction rdf:ID="_L2">
      <nc:ContingencyWithRemedialAction.RemedialAction rdf:resource="#_RA1"/>
      <nc:ContingencyWithRemedialAction.Contingency rdf:resource="#_CO2"/>
      <nc:ContingencyWithRemedialAction.combinationConstraintKind rdf:resource="https://cim4.eu/ns/nc#ElementCombinationConstraintKind.excluded"/>
    </nc:ContingencyWithRemedialAction>"""
    units, _ = _parse(tmp_path, ra, _bid("RA1") + _by_bid("PB-RA1-up", "K1") + _key("K1", "GU-A"))
    assert units[0].kind == RAKind.CURATIVE and not units[0].available
    assert units[0].linked_contingency_mrids == ["CO1"] and units[0].excluded_contingency_mrids == ["CO2"]


# ---------------------------------------------------------------------------
# (b) bids on the redispatch remedial action
# ---------------------------------------------------------------------------

def test_rao_the_bids_of_a_redispatch_ra_are_read_with_direction_and_size(tmp_path):
    sis = (_bid("RA1", direction="up", p=12.0, price=30.0) + _bid("RA1", direction="down", p=-7.0, price=4.0)
           + _by_bid("PB-RA1-up", "K1") + _key("K1", "GU-A"))
    _, bids = _parse(tmp_path, _rd(), sis, price_timestamp="1030Z")
    by_direction = {b.direction: b for b in bids}
    assert set(by_direction) == {BidDirection.UP, BidDirection.DOWN}
    assert by_direction[BidDirection.UP].ra_mrid == "RA1" and by_direction[BidDirection.UP].available_mw == {"1030Z": 12.0}
    assert by_direction[BidDirection.DOWN].available_mw == {"1030Z": 7.0} and by_direction[BidDirection.DOWN].price_eur_mw == 4.0


def test_rao_the_bids_of_a_redispatch_ra_without_units_are_not_read(tmp_path):
    sis = _bid("RA1") + _bid("RA2") + _by_bid("PB-RA2-up", "K1") + _key("K1", "GU-A")
    units, bids = _parse(tmp_path, _rd() + _rd("RA2"), sis)
    assert [u.mrid for u in units] == ["RA2"] and {b.ra_mrid for b in bids} == {"RA2"}


# ---------------------------------------------------------------------------
# (c) the old form: GridStateAlterationRemedialAction with RotatingMachineActions
# ---------------------------------------------------------------------------

def _old_rd(ra, machines, tso_file_extra=""):
    actions = "".join(f"""
    <nc:RotatingMachineAction rdf:ID="_{ra}-A{i}">
      <nc:GridStateAlteration.GridStateAlterationRemedialAction rdf:resource="#_{ra}"/>
      <nc:RotatingMachineAction.RotatingMachine rdf:resource="#_{machine}"/>
    </nc:RotatingMachineAction>""" for i, machine in enumerate(machines))
    return _rd(ra, cls="GridStateAlterationRemedialAction") + actions


def test_rao_the_old_rotating_machine_action_form_is_still_read_with_one_deprecation_warning(tmp_path, caplog):
    ra = _old_rd("RA1", ["G1", "G2"]) + _old_rd("RA2", ["G1"])
    with caplog.at_level(logging.WARNING):
        units, _ = _parse(tmp_path, ra, _bid("RA1"))
    assert sorted((u.mrid, u.gu_mrid) for u in units) == [("RA1", "G1"), ("RA1", "G2"), ("RA2", "G1")]
    messages = _messages(caplog, "RotatingMachineAction", "deprecated")
    assert len(messages) == 1 and "Test_RA.xml" in messages[0]


def test_rao_the_standard_form_gives_no_deprecation_warning(tmp_path, caplog):
    with caplog.at_level(logging.WARNING):
        _parse(tmp_path, _rd(), _bid("RA1") + _by_bid("PB-RA1-up", "K1") + _key("K1", "GU-A"))
    assert _messages(caplog, "RotatingMachineAction") == []


def test_rao_a_file_with_both_forms_reads_each_ra_by_its_own_form(tmp_path):
    ra = _rd("RA1") + _old_rd("RA2", ["G2"])
    sis = _bid("RA1") + _by_bid("PB-RA1-up", "K1") + _key("K1", "GU-A") + _bid("RA2")
    units, bids = _parse(tmp_path, ra, sis)
    assert sorted((u.mrid, u.gu_mrid) for u in units) == [("RA1", "G1"), ("RA2", "G2")]
    assert {b.ra_mrid for b in bids} == {"RA1", "RA2"}


def test_rao_without_a_generator_map_a_unit_id_that_is_a_cgm_key_is_used_as_it_is(tmp_path):
    sis = _bid("RA1") + _by_bid("PB-RA1-up", "K1") + _key("K1", "G1")
    units, _ = _parse(tmp_path, _rd(), sis, by_unit=None)
    assert [u.gu_mrid for u in units] == ["G1"]
