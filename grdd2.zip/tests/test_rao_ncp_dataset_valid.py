"""
test_rao_ncp_dataset_valid.py — the valid NCP test dataset (mock_data/ncp_dataset.py, docs/data/ncp_dataset_coverage.md
parts A and B): run_pipeline.main() on it with ra_types pst+rd+hvdc+countertrade and N-X analysis on, in
ac_iterative, ac_single_pass and dc. One test per coverage row: the dataset holds the element and the run reacts as
docs/data/ncp_data_requirements.md says (a log line of run_log.txt or a value of a result file). Every run has a per-TSO
RA-count limit of 1 for TSO-Galia (config, not NCP data), so that row is exercised too.
"""
import csv
import math
import zipfile

import pytest
from rdflib import Namespace, RDF

from mock_data import ct_mock
from mock_data import hvdc_mock
from mock_data import ncp_dataset as ds
from helpers import run_pipeline_on_fixture_inputs
from milp import milp_builder
from pre_milp import ncp_loader, ncp_parser

NC = Namespace(ds.ENUM)
RA_TYPES = ("pst", "rd", "hvdc", "countertrade")
MODES = ("ac_iterative", "ac_single_pass", "dc")
GALIA_RA_LIMIT = 1
BO_LINE_2 = "b58bf21a-096a-4dae-9a01-3f03b60c24c7"
BO_LINE_2_SHS_PATL_A = 1850.0          # Belgovia_SHS.xml of the base package: 2023-07-22T10:30:00Z (another date)
AAC, AAA1 = "2c9a0753-421a-489b-9761-9452f60b3157", "703f5b86-b6c6-4c47-8f6b-55d7d93838c9"
GA_TR2_1, GA_TR2_2 = "e8a7eaec-51d6-4571-b3d9-c36d52073c33", "2184f365-8cd5-4b5d-8a28-9d68603bb6a4"
BO_TR2_2 = "b94318f6-6d24-4f56-96b9-df2531ad6543"


@pytest.fixture(scope="module")
def dataset(tmp_path_factory):
    return ds.build_valid_ncp(tmp_path_factory.mktemp("ncp_dataset") / "valid.zip")


@pytest.fixture(scope="module")
def package(dataset):
    return ds.read_package(dataset)


@pytest.fixture(scope="module")
def files(dataset, tmp_path_factory):
    folder = tmp_path_factory.mktemp("ncp_dataset_files")
    with zipfile.ZipFile(dataset) as zf:
        zf.extractall(folder)
    return {path.name: path for path in folder.iterdir()}


_RUNS = {}


def _run(mode, dataset, tmp_path_factory):
    if mode not in _RUNS:
        def limit(rp, monkeypatch):
            monkeypatch.setattr(rp, "MAX_RA_COUNT_PER_TIMESTAMP_TSO", {"TSO-Galia": GALIA_RA_LIMIT})
        run = run_pipeline_on_fixture_inputs(
            tmp_path_factory.mktemp(f"ncp_dataset_{mode}"), dataset, enable_nx_analysis=True, ra_types=RA_TYPES,
            calculation_mode=mode, customize_pipeline=limit,
        )
        _RUNS[mode] = run.output_dir
    return _RUNS[mode]


@pytest.fixture(scope="module")
def ac(dataset, tmp_path_factory):
    return _run("ac_iterative", dataset, tmp_path_factory)


@pytest.fixture(scope="module", params=MODES)
def mode_run(request, dataset, tmp_path_factory):
    return request.param, _run(request.param, dataset, tmp_path_factory)


def _rows(output_dir, name):
    with open(output_dir / name, encoding="utf-8", newline="") as f:
        return list(csv.DictReader(f))


def _log(output_dir):
    return (output_dir / "run_log.txt").read_text(encoding="utf-8")


def _log_lines(output_dir, *parts):
    return [line for line in _log(output_dir).splitlines() if all(p in line for p in parts)]


def _patl_ka(output_dir, branch):
    return float(next(r for r in _rows(output_dir, "lf_basecase.csv") if r["branch_mrid"] == branch)["patl_ka"])


def _subject(package, file_name, mrid):
    graph = package[file_name]
    return next(s for s in graph.subjects() if str(s).endswith(f"#_{mrid}"))


def _ae_of_branch(package, file_name, branch):
    graph = package[file_name]
    return next(str(ae).rsplit("#_", 1)[-1] for ae in graph.subjects(RDF.type, NC.AssessedElement)
                if str(graph.value(ae, NC["AssessedElement.ConductingEquipment"]) or graph.value(ae, NC["AssessedElement.Line"])).endswith(branch))


def _tatl_branches(output_dir):
    return {r["branch_mrid"] for r in _rows(output_dir, "tatl_data.csv")}


def _scanned_branches(output_dir):
    return {r["branch_mrid"] for r in _rows(output_dir, "scanned_element_list.csv")}


# ---------------------------------------------------------------------------
# data rules
# ---------------------------------------------------------------------------

def test_the_generator_checks_the_data_rules(dataset, tmp_path):
    assert ds.check_data_rules(dataset) == []
    broken = {
        "bid_price_missing": f"{ds.VARIANT_BID} without direction, volume or price",
        "hvdc_group_of_three": "with 3 members",
        "patl_zero": "has PATL 0.0 <= 0",
        "reaction_time_unreadable_pst": f"curative RA {ds.CRA_PST_AAC} without a readable timeToImplement",
        "ct_zone_without_units": "fewer than two usable generators",
    }
    for case, text in broken.items():
        violations = ds.check_data_rules(ds.build_variant_ncp(tmp_path / f"{case}.zip", case))
        assert any(text in v for v in violations), (case, violations)


def test_the_tatl_is_at_least_the_patl_and_lasts(ac):
    patl = {r["branch_mrid"]: r["patl_ka"] for r in _rows(ac, "lf_basecase.csv")}
    rows = _rows(ac, "tatl_data.csv")
    assert rows
    for row in rows:
        assert float(row["tatl_limit_ka"]) >= float(patl[row["branch_mrid"]]) - 1e-12
        assert int(row["tatl_duration_seconds"]) > 0
    # the CGM TATL below the PATL is the CGM's own data: raised to the PATL and marked
    assert any(row["was_corrected"] == "True" for row in rows)


# ---------------------------------------------------------------------------
# assessed elements and PATL
# ---------------------------------------------------------------------------

def test_secured_and_scanned_without_a_reason_is_secured(package, ac):
    ae = _subject(package, "Espheim_AE.xml", ds.ae_mrid("secured+scanned"))
    graph = package["Espheim_AE.xml"]
    assert graph.value(ae, NC["AssessedElement.SecuredForRegion"]) and graph.value(ae, NC["AssessedElement.ScannedForRegion"])
    assert ds.EH_LINE1 in _tatl_branches(ac) and ds.EH_LINE1 not in _scanned_branches(ac)


@pytest.mark.parametrize("key, branch", [
    ("scanned+systemOperator", ds.LINE_EH_SD4), ("all three, capacityCalculationRegion", ds.TIE_EH_SD2),
])
def test_a_reason_with_a_scanned_region_is_scanned(package, ac, key, branch):
    graph = package["Espheim_AE.xml"]
    ae = _subject(package, "Espheim_AE.xml", ds.ae_mrid(key))
    assert graph.value(ae, NC["AssessedElement.exclusionReason"]) is not None
    assert branch in _scanned_branches(ac) and branch not in _tatl_branches(ac)


def test_a_reason_without_a_scanned_region_is_excluded(package, ac):
    graph = package["Espheim_AE.xml"]
    ae = _subject(package, "Espheim_AE.xml", ds.ae_mrid("secured+nonNative"))
    assert str(graph.value(ae, NC["AssessedElement.exclusionReason"])).endswith("nonNativeCapacityCalculationRegion")
    assert ds.TIE_EH_HVDC not in _tatl_branches(ac) | _scanned_branches(ac)
    assert _log_lines(ac, "TSO-Espheim: 10 AEs parsed (secured=7, scanned=2, excluded=1)")


def test_no_region_code_is_excluded_with_an_info_line(ac):
    assert _log_lines(ac, f"TSO-Galia: AE {ds.ae_mrid('no region code')} excluded - no secured or scanned region code")
    assert ds.TIE_GA_HVDC_BH not in _tatl_branches(ac) | _scanned_branches(ac)


def test_scanned_only_is_secured(ac):
    assert ds.TIE_GA_HVDC_NH in _tatl_branches(ac) and ds.TIE_GA_HVDC_NH not in _scanned_branches(ac)


def test_the_line_predicate_gives_the_branch(package, ac):
    graph = package["Svedala_AE.xml"]
    ae = _subject(package, "Svedala_AE.xml", ds.ae_mrid("Line predicate"))
    assert graph.value(ae, NC["AssessedElement.ConductingEquipment"]) is None and graph.value(ae, NC["AssessedElement.Line"])
    assert ds.TIE_SD_HVDC in _tatl_branches(ac)
    assert _patl_ka(ac, ds.TIE_SD_HVDC) == pytest.approx(ds.AE_PATL_A[ds.TIE_SD_HVDC] / 1000.0)


def test_the_patl_from_the_shs_file_wins(package, ac):
    ae = _ae_of_branch(package, "Belgovia_AE.xml", ct_mock.BRANCH_GA_BO4_BELGOVIA)
    assert _patl_ka(ac, ct_mock.BRANCH_GA_BO4_BELGOVIA) == pytest.approx(ct_mock.CT_HVDC_PATL_A / 1000.0)
    assert _log_lines(ac, f"AE {ae} ts=1030Z SHS PATL 0.100 kA differs >10% from CGM static 1.234 kA")


def test_the_patl_from_a_base_case_current_limit(ac):
    assert _patl_ka(ac, ds.EH_LINE1) == pytest.approx(ds.AE_PATL_A[ds.EH_LINE1] / 1000.0)


def test_the_cgm_patl_is_the_fallback_with_a_warning(ac):
    assert _patl_ka(ac, ds.SER_RLC) == pytest.approx(ds.SER_RLC_CGM_PATL_A / 1000.0)
    assert _log_lines(ac, f"AE {ds.ae_mrid('CGM PATL fallback')} ts=1030Z no PATL in NCP", "using CGM static PATL 0.500 kA")


def test_an_shs_time_point_of_another_date_matches_by_clock_time(package, ac):
    graph = package["Belgovia_SHS.xml"]
    dates = {str(graph.value(p, NC["CurrentLimitTimePoint.atTime"]))[:10] for p in graph.subjects(RDF.type, NC.CurrentLimitTimePoint)}
    assert "2023-07-22" in dates
    assert _patl_ka(ac, BO_LINE_2) == pytest.approx(BO_LINE_2_SHS_PATL_A / 1000.0)


# ---------------------------------------------------------------------------
# contingencies
# ---------------------------------------------------------------------------

EQUIPMENT_TYPE_CONTINGENCY = {
    "line": "b6b780cb-9fe5-4c45-989d-447a927c3874", "transformer": ds.CO_BO_TR2_1_OUT,
    "gen": ct_mock.CONTINGENCY_BELGOVIA_CO3, "load": "65582e87-5035-4465-8dd9-cb655224b29f",
    "switch": ds.CO_SWITCH, "shuntCompensator": "62eac668-82a1-4739-8cfc-de929b78ef7e",
    "staticVarCompensator": ds.CO_SVC, "busbar": ds.CO_BUSBAR,
}


@pytest.mark.parametrize("equipment_type", sorted(EQUIPMENT_TYPE_CONTINGENCY))
def test_every_mapped_equipment_type(ac, equipment_type):
    rows = [r for r in _rows(ac, "co_flat_list.csv") if r["contingency_mrid"] == EQUIPMENT_TYPE_CONTINGENCY[equipment_type]]
    assert rows and rows[0]["equipment_type"] == equipment_type


def test_unmappable_equipment_excludes_the_contingency(ac):
    assert _log_lines(ac, f"contingency {ds.CO_DC_LINE} equipment {ds.DC_LINE_EH_SD} not found in CGM")
    assert _log_lines(ac, f"contingency {ds.CO_DC_LINE} has no valid equipment after CGM check — excluded")
    assert ds.CO_DC_LINE not in {r["contingency_mrid"] for r in _rows(ac, "co_flat_list.csv")}


@pytest.mark.parametrize("contingency", [ds.CO_BUSBAR, ds.CO_NOT_STUDIED])
def test_a_contingency_that_is_not_must_study_is_parsed_and_not_studied(ac, contingency):
    rows = [r for r in _rows(ac, "co_flat_list.csv") if r["contingency_mrid"] == contingency]
    assert rows and all(r["must_study"] == "False" for r in rows)
    studied = {r["contingency_mrid"] for r in _rows(ac, "results_contingency_status.csv")}
    assert contingency not in studied and ct_mock.CONTINGENCY_BELGOVIA_CO3 in studied


def test_the_three_contingency_classes(ac):
    assert {r["contingency_type"] for r in _rows(ac, "co_flat_list.csv")} == {
        "OrdinaryContingency", "ExceptionalContingency", "OutOfRangeContingency"}


def test_curative_links_restrict_the_contingencies(ac):
    assert {r["contingency_mrid"] for r in _rows(ac, "results_curative_hvdc.csv")} == {hvdc_mock.CO_OVERLOAD_A}
    assert {r["contingency_mrid"] for r in _rows(ac, "results_curative_countertrade.csv")} == {ct_mock.CONTINGENCY_GA_BO5}


def test_an_outage_element_blocks_the_curative_pst_group(ac):
    assert _log_lines(ac, f"Curative PST group {ds.PST_GROUP_CRA}: member(s) ['{ds.BO_TR2_1}'] are outage element(s) "
                          f"of contingency {ds.CO_BO_TR2_1_OUT}", "blockedGroup")
    assert not [r for r in _rows(ac, "pst_cra_availability.csv")
                if r["contingency_mrid"] == ds.CO_BO_TR2_1_OUT and r["pst_mrid"] == ds.BO_TR2_1]


# ---------------------------------------------------------------------------
# PST
# ---------------------------------------------------------------------------

def test_a_preventive_pst_group_moves_its_members_together(ac):
    rows = {r["pst_mrid"]: r for r in _rows(ac, "results_pst.csv") if r["pst_name"] == "PRA_PST_BO_GROUP"}
    assert set(rows) == {ds.BO_TR2_1, BO_TR2_2}
    assert rows[ds.BO_TR2_1]["result_tap_position"] == rows[BO_TR2_2]["result_tap_position"]
    assert _log_lines(ac, f"PST group {ds.PST_GROUP_PRA} valid with 2 PSTs")


def test_a_curative_pst_group_has_one_delta_tap(ac):
    rows = [r for r in _rows(ac, "results_curative_pst_groups.csv") if r["group_id"] == ds.PST_GROUP_CRA]
    assert rows and all(set(r["pst_mrids"].split(";")) == {ds.BO_TR2_1, BO_TR2_2} for r in rows)


def test_a_curative_range_with_separate_up_and_down_bounds_the_curative_taps(ac):
    rows = [r for r in _rows(ac, "results_curative_pst.csv") if r["pst_mrid"] == AAC]
    assert rows and all((int(r["curative_tap_lower_bound"]), int(r["curative_tap_upper_bound"])) == (ds.AAC_RANGE_DOWN, ds.AAC_RANGE_UP) for r in rows)


def _tatl_seconds(output_dir):
    return {r["branch_mrid"]: int(r["tatl_duration_seconds"]) for r in _rows(output_dir, "tatl_data.csv")}


@pytest.mark.parametrize("pst, reaction_minutes, available", [(AAC, 1.0, True), (AAA1, 15.0, False)])
def test_fast_and_slow_curative_psts(ac, pst, reaction_minutes, available):
    durations = _tatl_seconds(ac)
    rows = [r for r in _rows(ac, "pst_cra_availability.csv") if r["pst_mrid"] == pst]
    assert rows
    for row in rows:
        expected = math.floor((durations[row["branch_mrid"]] / 60.0 - reaction_minutes) / 1.0)     # timePerStage PT1M
        assert int(row["max_curative_taps"]) == expected and (row["available"] == "True") is available


def test_a_missing_pst_penalty_factor_is_one_with_a_warning(ac):
    assert _log_lines(ac, f"PST remedial action {ds.PRA_PST_GA_TR2_2} has no RemedialAction.penaltyFactor - defaulted to 1.0")
    row = next(r for r in _rows(ac, "results_pst.csv") if r["pst_name"] == "PRA_PST_GA_TR2_2")
    assert float(row["pst_penalty_factor"]) == 1.0


def test_an_unavailable_curative_pst_has_no_curative_entry(package, ac):
    assert str(package["Galia_RA.xml"].value(_subject(package, "Galia_RA.xml", ds.CRA_PST_GA_TR2_2), NC["RemedialAction.normalAvailable"])) == "false"
    assert not [r for r in _rows(ac, "pst_cra_availability.csv") if r["pst_mrid"] == GA_TR2_2]
    assert [r for r in _rows(ac, "pst_cra_availability.csv") if r["pst_mrid"] == GA_TR2_1]


def test_a_pst_without_normal_available_is_not_used(package, ac):
    assert package["Galia_RA.xml"].value(_subject(package, "Galia_RA.xml", ds.PRA_PST_GA_TR2_1), NC["RemedialAction.normalAvailable"]) is None
    assert "PRA_PST_GA_TR2_1" not in {r["pst_name"] for r in _rows(ac, "results_pst.csv")}


# ---------------------------------------------------------------------------
# RD
# ---------------------------------------------------------------------------

def test_several_bids_of_one_ra(ac):
    bids = {r["bid_mrid"]: r for r in _rows(ac, "results_preventive_rd.csv") if r["ra_mrid"] == ds.PRA_RD_GA_G1_UP}
    assert {ds.GA_G1_SECOND_BID, ds.GA_G1_LEAD_TIME_BID} <= set(bids) and len(bids) == 3
    assert float(bids[ds.GA_G1_SECOND_BID]["price_eur_mw"]) == 60.0


def test_the_activation_cost_of_the_time_point_wins(files):
    bids = ncp_parser.parse_power_bids(ncp_parser._load_graph(files["Galia_SIS.xml"]), {ds.PRA_RD_GA_G1_UP}, "TSO-Galia", ["1030Z"])
    assert next(b for b in bids if b.mrid == ds.GA_G1_SECOND_BID).activation_cost_eur == 150.0


def test_a_lead_time_delays_the_bid(ac):
    import run_pipeline
    row = next(r for r in _rows(ac, "results_lead_times.csv") if r["bid_mrid"] == ds.GA_G1_LEAD_TIME_BID)
    timestamps = ncp_loader.build_timestamp_list(run_pipeline.START_HOUR, run_pipeline.N_TIMESTAMPS)
    assert float(row["bid_lead_time_hours"]) == 2.0
    assert row["earliest_usable_timestamp"] == milp_builder._compute_earliest_usable_timestamp(row["radp"], 2.0, timestamps)
    assert row["earliest_usable_timestamp"] != "1030Z"


def test_the_reservation_price_of_a_curative_bid(ac):
    rows = _rows(ac, "results_curative_rd.csv")
    assert {float(r["reservation_price_eur_mw"]) for r in rows if r["bid_mrid"] == ds.GA_G1_CURATIVE_RESERVE_BID} == {3.0}
    # a curative bid without a reservePrice reserves at its energy price
    other = [r for r in rows if r["ra_mrid"] == ds.CRA_RD_GA_G1_UP and r["bid_mrid"] != ds.GA_G1_CURATIVE_RESERVE_BID]
    assert other and all(r["reservation_price_eur_mw"] == r["price_eur_mw"] for r in other)


def test_a_glsk_over_several_units_drops_an_unconnected_one(ac):
    factors = {r["gu_mrid"]: float(r["participation_factor"]) for r in _rows(ac, "glsk_resolved.csv") if r["ra_mrid"] == ds.RD_MULTI_GLSK}
    connected = {unit: factor for unit, factor in ds.RD_MULTI_GLSK_FACTORS if unit != ds.KARNAN_G3}
    assert factors == pytest.approx({unit: factor / sum(connected.values()) for unit, factor in connected.items()})
    assert _log_lines(ac, f"RD RA {ds.RD_MULTI_GLSK}", "not connected, excluded from the redispatch and redistributed", ds.KARNAN_G3)


def test_a_restrictive_group_with_rd_members(ac):
    row = next(r for r in _rows(ac, "results_preventive_rd_ra_groups.csv") if r["group_mrid"] == ds.RD_GROUP["mrid"])
    assert (float(row["max_volume_upward_mw"]), float(row["max_volume_downward_mw"])) == (ds.RD_GROUP["max_up"], ds.RD_GROUP["max_down"])


def test_the_per_tso_ra_count_limit(ac):
    row = next(r for r in _rows(ac, "results_preventive_rd_ra_count.csv") if r["tso"] == "TSO-Galia")
    assert float(row["limit_per_timestamp"]) == GALIA_RA_LIMIT and float(row["activated_ra_count"]) <= GALIA_RA_LIMIT


def test_unit_costs_from_sis_and_er(files):
    to_generator = {ds.STORFORS_G1_UNIT: ds.STORFORS_G1, ds.STENFORSEN_G1_UNIT: ds.STENFORSEN_G1}
    costs = ncp_parser.parse_unit_costs(files["Svedala_SIS.xml"], files["Svedala_ER.xml"], "TSO-Svedala", "1030Z", to_generator)
    sis = dict(ds.SIS_UNIT_COSTS)[ds.STORFORS_G1_UNIT]
    assert (costs[ds.STORFORS_G1].startup_cost_eur, costs[ds.STORFORS_G1].shutdown_cost_eur) == (sis["warm_startup"], sis["shutdown"])
    _unit, startup, shutdown = ds.ER_UNITS[0]
    assert (costs[ds.STENFORSEN_G1].startup_cost_eur, costs[ds.STENFORSEN_G1].shutdown_cost_eur) == (startup, shutdown)


def test_the_er_file_is_read(ac):
    assert not _log_lines(ac, "TSO-Svedala: optional profile ER not found")
    assert _log_lines(ac, "TSO-Galia: optional profile ER not found")


def test_a_curative_rd_reaction_time_against_the_tatl(ac):
    durations = _tatl_seconds(ac)
    rows = [r for r in _rows(ac, "rd_cra_availability.csv") if r["ra_mrid"] == ds.CRA_RD_GA_G1_UP]
    assert rows and all(float(r["reaction_time_minutes"]) == 5.0 for r in rows)
    assert all((r["available"] == "True") is (5.0 <= durations.get(r["branch_mrid"], 600) / 60.0) for r in rows)


# ---------------------------------------------------------------------------
# HVDC
# ---------------------------------------------------------------------------

def _hvdc(output_dir):
    return {r["unit_mrid"]: r for r in _rows(output_dir, "results_hvdc.csv")}


def test_the_hvdc_pair_is_one_balanced_group(ac):
    rows = _hvdc(ac)
    assert set(rows) == set(ds.HVDC_PREVENTIVE) and len({r["group_mrid"] for r in rows.values()}) == 1
    assert sum(float(r["change_mw"]) for r in rows.values()) == pytest.approx(0.0, abs=1e-6)


def test_an_absolute_up_and_down_range(ac):
    row = _hvdc(ac)[ds.HVDC_PREVENTIVE[0]]
    assert (float(row["pmin_op_mw"]), float(row["pmax_op_mw"])) == (-450.0, 450.0)


def test_incremental_ranges_with_two_on_one_side(ac):
    row = _hvdc(ac)[ds.HVDC_PREVENTIVE[1]]
    assert float(row["pmin_op_mw"]) == pytest.approx(hvdc_mock.P0_SD_BO3 - 40.0)
    assert float(row["pmax_op_mw"]) == pytest.approx(hvdc_mock.P0_SD_BO3 + 60.0)


def test_a_set_point_outside_the_range_widens_it(ac):
    unit = ds.HVDC_CURATIVE[1]
    assert _log_lines(ac, f"HVDC unit {unit} (EquivalentInjection {hvdc_mock.EI_SD_BO3}): the CGM set point 1.559 MW is outside its range")
    rows = [r for r in _rows(ac, "results_curative_hvdc.csv") if r["unit_mrid"] == unit]
    assert rows and all(float(r["pmax_op_mw"]) == pytest.approx(hvdc_mock.P0_SD_BO3) for r in rows)


def test_hvdc_units_without_technical_limits_and_description(ac):
    for unit in ds.HVDC_PREVENTIVE:
        assert _log_lines(ac, f"HVDC unit {unit} (EquivalentInjection", "has no technical limits (minP/maxP)")
    assert _log_lines(ac, f"the description of EquivalentInjection {hvdc_mock.EI_SD_EH1}", 'does not start with "HVDC"')


# ---------------------------------------------------------------------------
# countertrade
# ---------------------------------------------------------------------------

def test_countertrade_in_two_zones_up_and_down(ac):
    rows = _rows(ac, "results_countertrade.csv")
    assert {(r["zone_name"], r["direction"]) for r in rows} == {
        (zone, direction) for zone in ("BZ-Belgovia", "BZ-Galia") for direction in ("up", "down")}


def test_countertrade_penalty_factors_zero_above_zero_and_missing(ac):
    by_ra = {r["ra_mrid"]: r for r in _rows(ac, "results_countertrade.csv")}
    assert float(by_ra[ds.CT_BO]["penalty_factor"]) == 0.0 and float(by_ra[ds.CT_BO]["penalty_cost_eur"]) == 0.0
    assert float(by_ra[ds.CT_GA]["penalty_factor"]) == ct_mock.CT_HVDC_CT_PENALTY
    curative_bo = ct_mock._uid("ra", "BO-cur")
    assert _log_lines(ac, f"countertrade RA {curative_bo} (CT Belgovia curative) has no RemedialAction.penaltyFactor - defaulted to 1.0")
    assert {float(r["penalty_factor"]) for r in _rows(ac, "results_curative_countertrade.csv") if r["ra_mrid"] == curative_bo} == {1.0}


def test_countertrade_weights_from_the_remaining_capacity(ac):
    rows = _rows(ac, "countertrade_glsk_resolved.csv")
    for (tso, direction), expected in ct_mock.EXPECTED_WEIGHTS.items():
        ra = ds.CT_BO if tso == "Belgovia" else ds.CT_GA
        weights = {r["gu_mrid"]: float(r["participation_factor"]) for r in rows if r["ra_mrid"] == ra and r["direction"] == direction}
        assert weights == pytest.approx(expected, abs=1e-6)
        assert {r["strategy"] for r in rows if r["ra_mrid"] == ra} == {ct_mock.STRATEGY}


def test_every_countertrade_zone_has_at_least_two_units(ac):
    assert _log_lines(ac, "(BZ-Belgovia): 2 candidate unit(s)") and _log_lines(ac, "(BZ-Galia): 3 candidate unit(s)")


# ---------------------------------------------------------------------------
# the three modes: every RA type acts, preventive (all modes) and curative (ac_iterative)
# ---------------------------------------------------------------------------

def test_every_ra_type_acts_in_each_mode(mode_run):
    mode, output_dir = mode_run
    summary = {r["metric"]: r["value"] for r in _rows(output_dir, "results_summary.csv")}
    assert summary["calculation_mode"] == mode and summary["ra_types"] == "pst+rd+hvdc+countertrade"
    assert float(summary["objective_residual_eur"]) == pytest.approx(0.0, abs=1e-6)
    assert any(float(r["tap_change_result"] or 0) != 0 for r in _rows(output_dir, "results_pst.csv"))
    assert any(abs(float(r["rd_volume_net_mw"] or 0)) > 0.1 for r in _rows(output_dir, "results_preventive_rd.csv"))
    assert all(abs(float(r["change_mw"])) > 0.1 for r in _rows(output_dir, "results_hvdc.csv"))
    assert sum(float(r["volume_mw"] or 0) for r in _rows(output_dir, "results_countertrade.csv")) > 1.0


def test_every_curative_ra_type_acts_in_ac_iterative(ac):
    assert any(abs(float(r["curative_delta_taps_net"] or 0)) > 0.1 for r in _rows(ac, "results_curative_pst.csv"))
    assert any(float(r["curative_volume_mw"] or 0) > 0.1 for r in _rows(ac, "results_curative_rd.csv"))
    assert any(abs(float(r["curative_change_mw"] or 0)) > 0.1 for r in _rows(ac, "results_curative_hvdc.csv"))
    assert any(float(r["curative_volume_mw"] or 0) > 0.1 for r in _rows(ac, "results_curative_countertrade.csv"))
