"""
test_rao_hvdc_pipeline.py — preventive HVDC RAs end to end on the mock (docs/specs/hvdc_ra_specs.md H5-H9,
H12, H13.3): run_pipeline.main() with ra_types containing hvdc, in the three calculation modes.
The mock pair Injection_SD_EH1 +x / Injection_SD_BO3 -x relieves TieLine_SD-EH1 (PATL lowered to 190 A).
"""
import csv
import re
import zipfile
from types import SimpleNamespace

import pyomo.environ as pyo
import pytest

from helpers import _MOCK_NX_NCP_ZIP, mock_generators_by_unit, run_pipeline_on_fixture_inputs
from mock_data.hvdc_mock import (
    CO_EI_OUT, CO_ISLAND_BO3, CO_OVERLOAD_A, CO_OVERLOAD_B, EI_SD_BO3, EI_SD_EH1, ISLAND_BO3_LINES, P0_SD_BO3, P0_SD_EH1,
    SVEDALA, XNE_BRANCH, build_hvdc_mock_ncp, contingency_xml, curative_groups, curative_ras, default_groups, default_ras, ra,
)
from post_milp import n0_results_export
from text_encoding import TEXT_ENCODING

PATL_A = 190.0
RD_REFERENCE = 100.0               # penalty_reference_hvdc_* default = the RD reference in rao_config.yaml
EI_OUTSIDE = "471d1e90-5fb2-45f7-ba23-9ea6cf67bcde"


@pytest.fixture(scope="module")
def runner(tmp_path_factory):
    """run(mode, nx, ..., ra_types) -> SimpleNamespace; every distinct run is made once per module."""
    cache: dict = {}

    def run(mode="ac_single_pass", nx=False, factors=(1.0, 1.0), patl=PATL_A, ra_types=("hvdc",), ras=None, groups=None,
            ncp=None, builds=False, fail_first_lf=False, fail_apply=False):
        """builds: record every model the loop builds (run.built); fail_first_lf: the first AC load flow after the
        solution was applied does not converge (the incremental fallback runs); fail_apply: no solution can be applied."""
        key = (mode, nx, tuple(factors), patl, tuple(ra_types), repr(ras), repr(groups), ncp, builds, fail_first_lf, fail_apply)
        if key in cache:
            return cache[key]
        work = tmp_path_factory.mktemp("hvdc_run")
        if ncp is None:
            used = ras if ras is not None else default_ras()
            if ras is None:
                used[0]["penalty"], used[1]["penalty"] = factors
            ncp_zip = build_hvdc_mock_ncp(work / "ncp.zip", ras=used, groups=groups if groups is not None else None, patl_a=patl)
        else:
            ncp_zip = ncp
        captured = {}

        def customize(rp, monkeypatch):
            original = rp.n0_results_export.extract_results_summary

            def capture(model, *args, **kwargs):
                captured["model"], captured["summary"] = model, original(model, *args, **kwargs)
                return captured["summary"]

            monkeypatch.setattr(rp.n0_results_export, "extract_results_summary", capture)
            captured["rp"] = rp
            if builds:
                import milp.ac_convergence_loop as loop
                captured["built"] = []
                original_build = loop.build_n0_milp_model

                def recording_build(*args, **kwargs):
                    model = original_build(*args, **kwargs)
                    captured["built"].append(model)
                    return model

                monkeypatch.setattr(loop, "build_n0_milp_model", recording_build)
            if fail_first_lf:
                import milp.ac_convergence_loop as loop
                original_lf = loop._run_ac_loadflow
                calls = {"n": 0}

                def failing_first(*args, **kwargs):
                    calls["n"] += 1
                    if calls["n"] == 1:
                        return False, "FAILED", None
                    return original_lf(*args, **kwargs)

                monkeypatch.setattr(loop, "_run_ac_loadflow", failing_first)
                monkeypatch.setattr(rp.single_pass, "_run_ac_loadflow", failing_first)
            if fail_apply:
                from milp.ac_convergence_loop import APPLY_LOAD_FLOW_FAILED, AppliedSolution
                for module in (rp.single_pass, rp.dc_pass, rp.ac_convergence_loop):
                    monkeypatch.setattr(module, "apply_solution_and_refresh",
                                        lambda **kwargs: AppliedSolution(kind=APPLY_LOAD_FLOW_FAILED, status_name="FAILED"))

        result = run_pipeline_on_fixture_inputs(
            work / "run", ncp_zip, enable_nx_analysis=nx, ra_types=ra_types, calculation_mode=mode, customize_pipeline=customize,
        )
        out = result.output_dir

        def read(name):
            with open(out / name, encoding=TEXT_ENCODING) as handle:
                return list(csv.DictReader(handle))

        namespace = SimpleNamespace(out=out, read=read, **captured)
        if "model" in captured:
            namespace.rows = n0_results_export.extract_hvdc_results(captured["model"], RD_REFERENCE)
            namespace.before = next(r for r in read("lf_basecase.csv") if r["branch_mrid"] == XNE_BRANCH)
            namespace.post = [r for r in read("lf_post_n0.csv") if r["branch_mrid"] == XNE_BRANCH][-1]    # the last iteration
        cache[key] = namespace
        return namespace

    return run


def _i_before(run):
    return float(run.before["i_ka"]) * 1000.0


def _i_after(run):
    return float(run.post["i_ka_after"]) * 1000.0


def _unit_rows(run):
    return sorted(run.rows.values(), key=lambda row: row["ei_mrid"] != EI_SD_EH1)      # g1 (Injection_SD_EH1) first


class TestPreventiveRelief:
    @pytest.mark.parametrize("mode, patl, tolerance_a", [
        ("ac_single_pass", PATL_A, 0.5),      # one linearisation: the AC check differs by the nonlinearity
        ("ac_iterative", PATL_A, 0.05),       # the loop refreshes the sensitivities until the AC state agrees
        ("dc", 165.0, 0.0),                   # the MILP works on DC currents (see the DC test below)
    ])
    def test_the_pair_relieves_the_xne_and_balances(self, runner, mode, patl, tolerance_a):
        run = runner(mode=mode, patl=patl)
        g1, g2 = _unit_rows(run)
        assert g1["ei_mrid"] == EI_SD_EH1 and g2["ei_mrid"] == EI_SD_BO3
        assert g1["change_mw"] > 1.0 and g2["change_mw"] < -1.0                      # up on g1, down on g2
        assert g1["change_mw"] + g2["change_mw"] == pytest.approx(0.0, abs=1e-6)     # dg1 + dg2 = 0
        for row in (g1, g2):
            assert row["pmin_op_mw"] - 1e-6 <= row["result_p_mw"] <= row["pmax_op_mw"] + 1e-6
        assert (g1["pmin_op_mw"], g1["pmax_op_mw"]) == (-450.0, 450.0)
        assert g2["pmin_op_mw"] == pytest.approx(P0_SD_BO3 - 40.0, abs=1e-3)          # the lower down range wins
        assert g2["pmax_op_mw"] == pytest.approx(P0_SD_BO3 + 60.0, abs=1e-3)
        assert g1["original_p_mw"] == pytest.approx(P0_SD_EH1, abs=1e-3)
        assert run.summary["ra_types"] == "hvdc"
        if mode != "dc":
            assert _i_before(run) > patl
            assert _i_after(run) <= patl + tolerance_a

    def test_the_milp_prediction_meets_the_limit_and_the_ac_check_confirms_it(self, runner):
        import pyomo.environ as pyo
        run = runner(mode="ac_single_pass")
        effect = float(pyo.value(run.model.hvdc_effect_on_branch[XNE_BRANCH]))
        assert effect == pytest.approx(-2.196 * _unit_rows(run)[0]["change_mw"] * 2.0 / 2.0, rel=0.08)
        prediction = float(run.post["i_ka_before"]) * 1000.0 + effect
        assert prediction == pytest.approx(PATL_A, abs=0.01)                      # the MILP leaves nothing unused
        assert _i_after(run) == pytest.approx(prediction, abs=0.5)                # the AC check agrees to the nonlinearity

    def test_the_iterative_loop_converges_below_the_limit(self, runner):
        run = runner(mode="ac_iterative")
        assert run.summary["ac_verification_status"] == "CONVERGED"
        assert run.summary["ac_iteration_count"] == 2
        assert _i_after(run) == pytest.approx(PATL_A, abs=0.05)

    def test_the_dc_mode_acts_on_dc_currents_and_the_final_ac_check_reports_the_difference(self, runner):
        run = runner(mode="dc", patl=165.0)
        # DC current 184.2 A is above 165 A: the pair removes 19.2 A in the model; the AC current is another quantity
        assert float(run.post["i_ka_before"]) * 1000.0 == pytest.approx(184.17, abs=0.05)
        effect = float(pyo.value(run.model.hvdc_effect_on_branch[XNE_BRANCH]))
        assert float(run.post["i_ka_before"]) * 1000.0 + effect == pytest.approx(165.0, abs=0.01)
        # lf_basecase and the "before" column are DC values in this mode; the AC state without any change (a DC run
        # that finds no DC overload) is the reference of the AC current after the change
        assert _i_after(run) < _i_after(runner(mode="dc", patl=PATL_A)) - 10.0
        assert run.summary["ac_verification_status"] == "SINGLE_PASS"

    def test_the_dc_mode_without_a_dc_overload_leaves_the_set_points(self, runner):
        run = runner(mode="dc", patl=PATL_A)             # DC current 184 A < 190 A
        assert all(row["change_mw"] == 0.0 for row in run.rows.values())

    def test_the_set_points_were_applied_to_the_network(self, runner):
        run = runner(mode="ac_single_pass")
        g1 = _unit_rows(run)[0]
        info = run.model.hvdc_info
        assert info and g1["result_p_mw"] == pytest.approx(g1["original_p_mw"] + g1["change_mw"])
        assert _i_after(run) < _i_before(run) - 15.0       # the AC load flow ran on the changed set points


class TestCostAndSummary:
    def test_cost_is_factor_times_reference_times_the_change_of_both_units(self, runner):
        run = runner(mode="ac_single_pass")
        g1, g2 = _unit_rows(run)
        for row in (g1, g2):
            assert row["penalty_cost_eur"] == pytest.approx(row["penalty_factor"] * RD_REFERENCE * abs(row["change_mw"]))
        total = g1["penalty_cost_eur"] + g2["penalty_cost_eur"]
        assert run.summary["sum_pra_penalty_cost_hvdc_eur"] == pytest.approx(total, rel=1e-9)
        assert run.summary["sum_hvdc_penalty_cost_eur"] == pytest.approx(total, rel=1e-9)
        assert run.summary["sum_cra_penalty_cost_hvdc_eur"] == 0.0

    @pytest.mark.parametrize("mode, patl", [("ac_single_pass", PATL_A), ("ac_iterative", PATL_A), ("dc", 165.0)])
    def test_the_objective_equals_the_sum_of_the_reported_terms(self, runner, mode, patl):
        run = runner(mode=mode, patl=patl)
        assert abs(float(run.summary["objective_residual_eur"])) < 1e-6
        assert float(run.summary["objective_value"]) == pytest.approx(float(run.summary["sum_hvdc_penalty_cost_eur"]), rel=1e-9)

    def test_the_summary_rows_exist_only_with_hvdc_in_ra_types(self, runner):
        without = runner(mode="ac_single_pass", ra_types=("rd",), ncp=_MOCK_NX_NCP_ZIP)
        assert "sum_hvdc_penalty_cost_eur" not in without.summary
        assert "sum_hvdc_penalty_cost_eur" in runner(mode="ac_single_pass").summary

    def test_a_factor_of_zero_is_free_and_uses_more_than_a_positive_factor(self, runner):
        free = runner(factors=(0.0, 0.0))
        priced = runner(factors=(1.0, 1.0))
        assert free.summary["sum_hvdc_penalty_cost_eur"] == 0.0
        assert float(free.summary["objective_value"]) == 0.0
        assert abs(_unit_rows(free)[0]["change_mw"]) > abs(_unit_rows(priced)[0]["change_mw"])
        assert _i_after(free) <= PATL_A

    def test_a_missing_penalty_factor_is_one_and_logged(self, runner):
        """The profile default is 1 (decision 97): the run costs what the same run with an explicit factor 1.0 costs."""
        run = runner(factors=(None, None))
        explicit = runner(factors=(1.0, 1.0))
        assert all(row["penalty_factor"] == 1.0 for row in run.rows.values())
        assert run.summary["sum_hvdc_penalty_cost_eur"] == pytest.approx(explicit.summary["sum_hvdc_penalty_cost_eur"], rel=1e-9)
        assert float(run.summary["sum_hvdc_penalty_cost_eur"]) > 0.0
        log_text = (run.out / "run_log.txt").read_text(encoding=TEXT_ENCODING)
        assert len(re.findall(r"HVDC remedial action \S+ has no RemedialAction.penaltyFactor - defaulted to 1.0", log_text)) == 2

    def test_a_high_factor_limits_the_use_and_leaves_the_overload(self, runner):
        run = runner(factors=(200.0, 200.0))
        assert all(row["change_mw"] == 0.0 for row in run.rows.values())
        assert run.summary["remaining_overload_count"] == 1
        assert run.summary["sum_hvdc_penalty_cost_eur"] == 0.0

    def test_each_unit_pays_its_own_factor(self, runner):
        run = runner(factors=(1.0, 50.0))
        g1, g2 = _unit_rows(run)
        assert g2["penalty_cost_eur"] == pytest.approx(50.0 * g1["penalty_cost_eur"], rel=1e-9)
        assert abs(float(run.summary["objective_residual_eur"])) < 1e-6


class TestOriginalNetworkReport:
    def test_a_solution_that_cannot_be_applied_reports_the_original_set_points_without_cost(self, tmp_path):
        """The AC load flow of the solution does not converge: nothing is applied, the files describe the original
        network (set points unchanged, no HVDC cost)."""
        from milp.ac_convergence_loop import APPLY_LOAD_FLOW_FAILED, AppliedSolution

        captured = {}

        def customize(rp, monkeypatch):
            monkeypatch.setattr(
                rp.single_pass, "apply_solution_and_refresh",
                lambda **kwargs: AppliedSolution(kind=APPLY_LOAD_FLOW_FAILED, status_name="FAILED"),
            )
            original = rp.n0_results_export.extract_results_summary

            def capture(model, *args, **kwargs):
                captured["model"], captured["summary"] = model, original(model, *args, **kwargs)
                return captured["summary"]

            monkeypatch.setattr(rp.n0_results_export, "extract_results_summary", capture)

        ncp = build_hvdc_mock_ncp(tmp_path / "ncp.zip", patl_a=PATL_A)
        run_pipeline_on_fixture_inputs(tmp_path / "run", ncp, enable_nx_analysis=False, ra_types=("hvdc",),
                                       calculation_mode="ac_single_pass", customize_pipeline=customize)
        rows = n0_results_export.extract_hvdc_results(captured["model"], RD_REFERENCE)
        assert len(rows) == 2
        assert all(row["change_mw"] == 0.0 and row["result_p_mw"] == row["original_p_mw"] for row in rows.values())
        assert captured["summary"]["sum_hvdc_penalty_cost_eur"] == 0.0
        assert captured["summary"]["ac_verification_status"] == "REVERTED_NON_CONVERGENT"


class TestWithOtherTypesAndNx:
    def test_hvdc_with_pst_and_rd_keeps_the_rd_balance_and_the_pair_balance(self, runner):
        run = runner(ra_types=("pst", "rd", "hvdc"))
        g1, g2 = _unit_rows(run)
        assert g1["change_mw"] + g2["change_mw"] == pytest.approx(0.0, abs=1e-6)
        rd_net = sum(
            float(r["rd_volume_net_mw"]) for r in run.read("results_generating_units.csv")
        ) if (run.out / "results_generating_units.csv").exists() else 0.0
        assert rd_net == pytest.approx(0.0, abs=1e-6)
        assert abs(float(run.summary["objective_residual_eur"])) < 1e-6
        assert run.summary["ra_types"] == "pst+rd+hvdc"

    def test_the_n_x_rows_carry_the_hvdc_units(self, runner):
        run = runner(nx=True)
        assert run.summary["ra_types"] == "hvdc"
        model = run.model
        assert len(model.nx_branch_contingency_pairs) > 0
        from pyomo.repn import generate_standard_repn
        with_hvdc = [
            pair for pair in model.nx_branch_contingency_pairs
            if any(v.name.startswith("hvdc") for v in generate_standard_repn(model.nx_patl_loading[pair].body, quadratic=False).linear_vars)
        ]
        assert with_hvdc, "no N-X PATL row contains an HVDC variable"
        assert abs(float(run.summary["objective_residual_eur"])) < 1e-6

    def test_the_iterative_loop_with_n_x_refreshes_the_hvdc_sensitivities_and_keeps_the_rows(self, runner):
        run = runner(mode="ac_iterative", nx=True)
        assert run.summary["ac_verification_status"] == "CONVERGED"
        from pyomo.repn import generate_standard_repn
        model = run.model            # built in the last iteration, after the refresh of the N-X sensitivities
        assert any(
            any(v.name.startswith("hvdc") for v in generate_standard_repn(model.nx_patl_loading[pair].body, quadratic=False).linear_vars)
            for pair in model.nx_branch_contingency_pairs
        )
        assert abs(float(run.summary["objective_residual_eur"])) < 1e-6
        assert _unit_rows(run)[0]["change_mw"] + _unit_rows(run)[1]["change_mw"] == pytest.approx(0.0, abs=1e-6)

    def test_hvdc_in_ra_types_without_an_hvdc_ra_is_a_log_line_and_a_graceful_exit(self, runner, tmp_path):
        run = runner(ra_types=("hvdc",), ncp=_MOCK_NX_NCP_ZIP)
        log_text = (run.out / "run_log.txt").read_text(encoding=TEXT_ENCODING)
        assert "no usable HVDC remedial action" in log_text
        assert "has anything to optimise" in log_text
        assert not (run.out / "results_summary.csv").exists()


def _mock_ras(**changes):
    ras = default_ras()
    ras[0].update(changes.get("first", {}))
    ras[1].update(changes.get("second", {}))
    return ras


class TestInvalidData:
    def test_a_unit_without_a_group_is_an_error(self, runner):
        with pytest.raises(ValueError, match="no balanced RA group"):
            runner(ras=_mock_ras(), groups=[])

    def test_a_group_with_three_units_is_an_error(self, runner):
        ras = default_ras() + [ra("11111111-0000-4000-8000-000000000003", "c875730a-5f7d-427a-869c-611" "28054fb60", ranges=[("upAndDown", "absolute", 5)])]
        with pytest.raises(ValueError, match="exactly two"):
            runner(ras=ras, groups=[("22222222-0000-4000-8000-000000000001", [r["mrid"] for r in ras])])

    def test_a_group_with_a_foreign_ra_is_an_error(self, runner):
        ras = default_ras()
        with pytest.raises(ValueError, match="not HVDC units"):
            runner(ras=ras, groups=[("22222222-0000-4000-8000-000000000001", [ras[0]["mrid"], ras[1]["mrid"], "no-such-ra"])])

    def test_a_group_mixing_preventive_and_curative_is_an_error(self, runner):
        with pytest.raises(ValueError, match="mixes preventive and curative"):
            runner(ras=_mock_ras(second={"kind": "curative"}))

    def test_a_unit_outside_the_solved_network_is_an_error_naming_it(self, runner):
        ras = default_ras()
        ras[1]["ei"] = EI_OUTSIDE
        with pytest.raises(ValueError, match=f"{ras[1]['mrid']}.*{EI_OUTSIDE}.*outside the solved main network"):
            runner(ras=ras)

    def test_a_unit_without_a_bound_on_a_side_is_an_error(self, runner):
        with pytest.raises(ValueError, match="has no upper bound"):
            runner(ras=_mock_ras(first={"ranges": []}))

    def test_an_ei_that_is_also_an_rd_unit_is_an_error(self, runner):
        with zipfile.ZipFile(_MOCK_NX_NCP_ZIP) as zf:
            text = zf.read(f"{SVEDALA}_SIS.xml").decode("utf-8")
        unit = re.search(r'PowerShiftKeySchedule.GeneratingUnit rdf:resource="#_([^"]+)"', text).group(1)
        machine = mock_generators_by_unit()[unit][0]
        ras = default_ras()
        ras[0]["ei"] = machine
        with pytest.raises(ValueError, match="also a generating unit of the GLSK of RD"):
            runner(ras=ras, ra_types=("rd", "hvdc"))


# ---------------------------------------------------------------------------
# curative (H6, H7.4, H8.2): PATL 300 A leaves the N-0 alone; two contingencies overload TieLine_SD-EH1 (323.5 / 323.1 A)
# ---------------------------------------------------------------------------

PATL_CURATIVE = 300.0


def _cur_run(runner, mode="ac_single_pass", builds=False, **curative_kwargs):
    cur = curative_ras(**curative_kwargs)
    return runner(mode=mode, nx=True, patl=PATL_CURATIVE, ras=cur, groups=curative_groups(cur), builds=builds)


def _cur_rows(run):
    return n0_results_export.extract_curative_hvdc_results(run.model, RD_REFERENCE)


def _slack(run, contingency):
    return float(pyo.value(run.model.nx_patl_overload_slack[XNE_BRANCH, contingency]))


class TestCurativeRelief:
    def test_the_pair_acts_in_its_linked_contingency_only_and_relieves_the_branch(self, runner):
        run = _cur_run(runner)
        rows = _cur_rows(run)
        assert {r["contingency_mrid"] for r in rows} == {CO_OVERLOAD_A} and len(rows) == 2
        up = next(r for r in rows if r["ei_mrid"] == EI_SD_EH1)
        down = next(r for r in rows if r["ei_mrid"] == EI_SD_BO3)
        assert up["curative_change_mw"] > 1.0 and up["curative_change_mw"] + down["curative_change_mw"] == pytest.approx(0.0, abs=1e-6)
        # the MILP prediction: the overload of contingency A is removed, the unlinked contingency B keeps its overload
        assert _slack(run, CO_OVERLOAD_A) == pytest.approx(0.0, abs=1e-4)
        assert _slack(run, CO_OVERLOAD_B) > 20.0
        assert run.model.nx_curative_effect_ampere(XNE_BRANCH, CO_OVERLOAD_A) < -20.0

    def test_the_term_is_only_in_the_rows_of_its_contingency(self, runner):
        run = _cur_run(runner)
        from pyomo.repn import generate_standard_repn
        for contingency, expected in ((CO_OVERLOAD_A, True), (CO_OVERLOAD_B, False)):
            names = {v.name for v in generate_standard_repn(run.model.nx_patl_loading[XNE_BRANCH, contingency].body, quadratic=False).linear_vars}
            assert any(n.startswith("hvdc_cur") for n in names) is expected
            assert all(contingency in n for n in names if n.startswith("hvdc_cur"))
        assert not hasattr(run.model, "nx_tatl_loading") or all(
            not v.name.startswith("hvdc_cur") for pair in run.model.nx_tatl_loading
            for v in generate_standard_repn(run.model.nx_tatl_loading[pair].body, quadratic=False).linear_vars)

    def test_the_cost_is_factor_times_reference_times_the_unit_change_summed_over_both_units(self, runner):
        run = _cur_run(runner)
        rows = _cur_rows(run)
        expected = sum(1.0 * RD_REFERENCE * r["max_curative_change_mw"] for r in rows)
        assert float(run.summary["sum_cra_penalty_cost_hvdc_eur"]) == pytest.approx(expected, rel=1e-6)
        assert float(run.summary["sum_pra_penalty_cost_hvdc_eur"]) == 0.0
        assert abs(float(run.summary["objective_residual_eur"])) < 1e-6

    def test_the_curative_actions_are_not_written_to_the_network(self, runner):
        run = _cur_run(runner)
        assert float(run.post["i_ka_after"]) == pytest.approx(float(run.post["i_ka_before"]), abs=1e-9)
        assert run.rows == {} or all(r["change_mw"] == 0.0 for r in run.rows.values())
        assert hasattr(run.model, "hvdc_cur_up") and not hasattr(run.model, "hvdc_change")

    def test_without_a_link_every_contingency_is_relieved_and_the_cost_is_the_maximum_not_the_sum(self, runner):
        linked = _cur_run(runner)
        every = _cur_run(runner, contingencies=())
        assert {r["contingency_mrid"] for r in _cur_rows(every)} >= {CO_OVERLOAD_A, CO_OVERLOAD_B}
        assert _slack(every, CO_OVERLOAD_A) == pytest.approx(0.0, abs=1e-4) and _slack(every, CO_OVERLOAD_B) == pytest.approx(0.0, abs=1e-4)
        for r in _cur_rows(every):
            assert r["max_curative_change_mw"] == pytest.approx(max(
                abs(x["curative_change_mw"]) for x in _cur_rows(every) if x["ei_mrid"] == r["ei_mrid"]), abs=1e-6)
        rows = _cur_rows(every)
        per_unit_max = {ei: max(abs(r["curative_change_mw"]) for r in rows if r["ei_mrid"] == ei) for ei in (EI_SD_EH1, EI_SD_BO3)}
        used = [r for r in rows if r["ei_mrid"] == EI_SD_EH1 and abs(r["curative_change_mw"]) > 1e-6]
        assert len(used) >= 2                                            # several contingencies use the unit ...
        assert float(every.summary["sum_cra_penalty_cost_hvdc_eur"]) == pytest.approx(RD_REFERENCE * sum(per_unit_max.values()), rel=1e-6)
        assert sum(abs(r["curative_change_mw"]) for r in used) > per_unit_max[EI_SD_EH1] + 1.0     # ... and the cost is not their sum
    def test_a_reaction_time_above_the_tatl_duration_removes_the_curative_action(self, runner):
        run = _cur_run(runner, time_to_implement="PT15M")              # the TATL duration of the mock branch is 10 min
        assert _cur_rows(run) == []
        assert _slack(run, CO_OVERLOAD_A) > 20.0

    def test_a_reaction_time_inside_the_tatl_duration_keeps_it(self, runner):
        assert len(_cur_rows(_cur_run(runner, time_to_implement="PT10M"))) == 2

    def test_a_curative_pair_with_a_unit_that_is_not_available_is_dropped_as_a_group(self, runner, tmp_path):
        cur = curative_ras()
        cur[1]["available"] = False
        run = runner(mode="ac_single_pass", nx=True, patl=PATL_CURATIVE, ras=cur, groups=curative_groups(cur))
        # both units dropped (the group is atomic): the model carries no HVDC variable at all
        assert not hasattr(run.model, "hvdc_cur_up") and not hasattr(run.model, "hvdc_change")
    def test_a_curative_ra_without_ranges_uses_the_preventive_ranges_of_the_unit(self, runner):
        pre, cur = default_ras(), curative_ras(own_ranges=False)
        run = runner(nx=True, patl=PATL_CURATIVE, ras=pre + cur, groups=default_groups(pre) + curative_groups(cur))
        for r in _cur_rows(run):
            lo, hi = (-450.0, 450.0) if r["ei_mrid"] == EI_SD_EH1 else (P0_SD_BO3 - 40.0, P0_SD_BO3 + 60.0)
            assert lo - 1e-6 <= r["p_after_curative_mw"] <= hi + 1e-6

    @pytest.mark.parametrize("mode", ["ac_iterative", "dc"])
    def test_the_other_modes_carry_the_curative_term(self, runner, mode):
        run = _cur_run(runner, mode=mode, contingencies=())
        assert len(_cur_rows(run)) >= 2
        assert abs(float(run.summary["objective_residual_eur"])) < 1e-6


class TestPreventiveAndCurativeTogether:
    def test_both_costs_are_reported_and_the_objective_is_their_sum(self, runner):
        pre, cur = default_ras(), curative_ras()
        run = runner(nx=True, patl=PATL_A, ras=pre + cur, groups=default_groups(pre) + curative_groups(cur))
        assert float(run.summary["sum_pra_penalty_cost_hvdc_eur"]) > 0.0
        assert float(run.summary["sum_cra_penalty_cost_hvdc_eur"]) >= 0.0
        assert float(run.summary["sum_hvdc_penalty_cost_eur"]) == pytest.approx(
            float(run.summary["sum_pra_penalty_cost_hvdc_eur"]) + float(run.summary["sum_cra_penalty_cost_hvdc_eur"]), rel=1e-9)
        assert abs(float(run.summary["objective_residual_eur"])) < 1e-6
        g1, g2 = _unit_rows(run)
        assert g1["change_mw"] + g2["change_mw"] == pytest.approx(0.0, abs=1e-6)
        assert _i_after(run) <= PATL_A + 0.5

# ---------------------------------------------------------------------------
# step 9: curative and mixed in all three calculation modes, fallback ramp, no solution applied
# ---------------------------------------------------------------------------

def _mixed(runner, mode, patl=PATL_CURATIVE, **options):
    """Preventive pair at factor 3, curative pair (no ranges of its own) at factor 1 on the same two EIs."""
    pre, cur = default_ras(), curative_ras(own_ranges=False)
    pre[0]["penalty"] = pre[1]["penalty"] = 3.0
    return runner(mode=mode, nx=True, patl=patl, ras=pre + cur, groups=default_groups(pre) + curative_groups(cur), **options)


def _patl_row_has_curative_variable(model, contingency=CO_OVERLOAD_A):
    from pyomo.repn import generate_standard_repn
    body = model.nx_patl_loading[XNE_BRANCH, contingency].body
    return any(v.name.startswith("hvdc_cur") for v in generate_standard_repn(body, quadratic=False).linear_vars)


class TestCurativeInTheIterativeLoop:
    def test_it_converges_and_relieves_the_linked_contingency(self, runner):
        run = _cur_run(runner, mode="ac_iterative", builds=True)
        assert run.summary["ac_verification_status"] == "CONVERGED"
        assert {r["contingency_mrid"] for r in _cur_rows(run)} == {CO_OVERLOAD_A}
        assert _slack(run, CO_OVERLOAD_A) == pytest.approx(0.0, abs=1e-4)
        assert abs(float(run.summary["objective_residual_eur"])) < 1e-6

    def test_every_model_of_the_loop_carries_the_curative_term_in_the_n_x_rows(self, runner):
        run = _cur_run(runner, mode="ac_iterative", builds=True)
        assert len(run.built) >= 1
        for model in run.built:
            assert _patl_row_has_curative_variable(model) and not _patl_row_has_curative_variable(model, CO_OVERLOAD_B)

    def test_the_n_x_sensitivities_are_refreshed_each_iteration_for_the_curative_units_too(self, runner):
        run = _cur_run(runner, mode="ac_iterative", builds=True)
        effects = [m.nx_curative_effect_ampere(XNE_BRANCH, CO_OVERLOAD_A) for m in run.built]
        assert all(-26.0 < e < -21.0 for e in effects)              # AC sensitivities, refreshed at the applied state

    def test_the_curative_effect_enters_the_iteration_history(self, runner):
        run = _cur_run(runner, mode="ac_iterative")
        history = run.read("results_iteration_history.csv")
        assert history and history[-1]["converged"].lower() == "true"
        assert history[-1]["criterion_4_met"].lower() == "true" or history[-1]["converged_by"]

    def test_the_curative_actions_never_reach_the_network(self, runner):
        run = _cur_run(runner, mode="ac_iterative")
        assert float(run.post["i_ka_after"]) == pytest.approx(float(run.post["i_ka_before"]), abs=1e-9)


class TestCurativeInTheDcMode:
    def test_the_dc_model_uses_dc_sensitivities_for_the_curative_units(self, runner):
        dc = _cur_run(runner, mode="dc")
        ac = _cur_run(runner, mode="ac_single_pass")
        dc_effect = dc.model.nx_curative_effect_ampere(XNE_BRANCH, CO_OVERLOAD_A)
        ac_effect = ac.model.nx_curative_effect_ampere(XNE_BRANCH, CO_OVERLOAD_A)
        assert dc_effect < -5.0 and dc_effect != pytest.approx(ac_effect, abs=0.5)
        assert _slack(dc, CO_OVERLOAD_A) == pytest.approx(0.0, abs=1e-4)

    def test_the_curative_rows_and_the_balance(self, runner):
        rows = _cur_rows(_cur_run(runner, mode="dc"))
        assert {r["contingency_mrid"] for r in rows} == {CO_OVERLOAD_A}
        assert sum(r["curative_change_mw"] for r in rows) == pytest.approx(0.0, abs=1e-9)

    def test_nothing_is_applied_in_the_dc_mode_for_curative_actions(self, runner):
        run = _cur_run(runner, mode="dc")
        assert run.rows == {} and not hasattr(run.model, "hvdc_change")           # no preventive set point exists to change


class TestMixedPreventiveAndCurativeInAllModes:
    @pytest.mark.parametrize("mode", ["ac_single_pass", "ac_iterative"])
    def test_both_blocks_are_used_and_the_costs_add_up(self, runner, mode):
        run = _mixed(runner, mode)
        g1, g2 = _unit_rows(run)
        assert g1["change_mw"] > 5.0 and g1["change_mw"] + g2["change_mw"] == pytest.approx(0.0, abs=1e-6)
        rows = _cur_rows(run)
        assert {r["contingency_mrid"] for r in rows} == {CO_OVERLOAD_A} and max(abs(r["curative_change_mw"]) for r in rows) > 0.01
        pra, cra = float(run.summary["sum_pra_penalty_cost_hvdc_eur"]), float(run.summary["sum_cra_penalty_cost_hvdc_eur"])
        assert pra == pytest.approx(sum(r["penalty_cost_eur"] for r in run.rows.values()), rel=1e-9) and cra > 0.0
        assert float(run.summary["sum_hvdc_penalty_cost_eur"]) == pytest.approx(pra + cra, rel=1e-9)
        assert abs(float(run.summary["objective_residual_eur"])) < 1e-6

    @pytest.mark.parametrize("mode", ["ac_single_pass", "ac_iterative"])
    def test_the_curative_bound_counts_the_preventive_change(self, runner, mode):
        run = _mixed(runner, mode)
        for r in _cur_rows(run):
            assert r["pmin_op_mw"] - 1e-6 <= r["p_after_curative_mw"] <= r["pmax_op_mw"] + 1e-6
            preventive = run.rows[r["unit_mrid"].replace("33333333", "11111111")]
            assert r["p_after_preventive_mw"] == pytest.approx(preventive["result_p_mw"], abs=1e-9)

    def test_the_dc_mode_with_both_blocks(self, runner):
        run = _mixed(runner, "dc")
        g1, g2 = _unit_rows(run)
        assert g1["change_mw"] > 1.0 and g1["change_mw"] + g2["change_mw"] == pytest.approx(0.0, abs=1e-6)
        assert abs(float(run.summary["objective_residual_eur"])) < 1e-6
        assert float(run.summary["sum_hvdc_penalty_cost_eur"]) == pytest.approx(
            float(run.summary["sum_pra_penalty_cost_hvdc_eur"]) + float(run.summary["sum_cra_penalty_cost_hvdc_eur"]), rel=1e-9)


class TestFallbackRampAndNoSolutionApplied:
    def test_the_incremental_fallback_carries_the_hvdc_set_points(self, runner):
        direct = runner(mode="ac_single_pass")
        ramp = runner(mode="ac_single_pass", fail_first_lf=True)
        log_text = (ramp.out / "run_log.txt").read_text(encoding=TEXT_ENCODING)
        assert "Incremental fallback converged" in log_text
        for row, reference in zip(_unit_rows(ramp), _unit_rows(direct)):
            assert row["result_p_mw"] == pytest.approx(reference["result_p_mw"], abs=1e-6)
        assert _i_after(ramp) == pytest.approx(_i_after(direct), abs=0.05)

    def test_the_failed_apply_with_curative_actions_reports_the_original_network(self, runner):
        cur = curative_ras()
        run = runner(mode="ac_single_pass", nx=True, patl=PATL_CURATIVE, ras=cur, groups=curative_groups(cur), fail_apply=True)
        assert run.summary["ac_verification_status"] == "REVERTED_NON_CONVERGENT"
        assert float(run.summary["sum_hvdc_penalty_cost_eur"]) == 0.0
        assert all(r["curative_change_mw"] == 0.0 and r["penalty_cost_eur"] == 0.0 for r in _cur_rows(run))

    @pytest.mark.parametrize("mode", ["ac_iterative"])
    def test_the_failed_apply_in_the_loop_with_both_blocks(self, runner, mode):
        run = _mixed(runner, mode, fail_apply=True)
        assert all(r["change_mw"] == 0.0 for r in run.rows.values())
        assert float(run.summary["sum_hvdc_penalty_cost_eur"]) == 0.0

# ---------------------------------------------------------------------------
# step 10: output files, registry, N-X exports
# ---------------------------------------------------------------------------

def _csv_rows(path):
    with open(path, encoding=TEXT_ENCODING, newline="") as handle:
        return list(csv.DictReader(handle))


class TestOutputFiles:
    def test_the_preventive_file_has_one_row_per_unit_with_a_tso_column_and_float_set_points(self, runner):
        run = runner(mode="ac_single_pass")
        rows = _csv_rows(run.out / "results_hvdc.csv")
        assert len(rows) == 2 and {r["tso"] for r in rows} == {"TSO-Svedala"}
        by_unit = {r["unit_mrid"]: r for r in rows}
        for unit, expected in run.rows.items():
            for column in ("original_p_mw", "result_p_mw", "change_mw", "penalty_cost_eur"):
                assert float(by_unit[unit][column]) == pytest.approx(float(expected[column]), abs=1e-9)
            assert "." in by_unit[unit]["result_p_mw"]
        assert {r["ac_verification_status"] for r in rows} == {run.summary["ac_verification_status"]}

    def test_a_preventive_only_run_writes_neither_the_curative_nor_the_availability_file(self, runner):
        run = runner(mode="ac_single_pass", nx=True)
        assert (run.out / "results_hvdc.csv").exists()
        assert not (run.out / "results_curative_hvdc.csv").exists() and not (run.out / "hvdc_cra_availability.csv").exists()

    def test_the_curative_files_match_the_model(self, runner):
        run = _cur_run(runner)
        rows = _csv_rows(run.out / "results_curative_hvdc.csv")
        assert len(rows) == 2 and {r["tso"] for r in rows} == {"TSO-Svedala"} and {r["contingency_mrid"] for r in rows} == {CO_OVERLOAD_A}
        expected = {(r["unit_mrid"], r["contingency_mrid"]): r for r in _cur_rows(run)}
        for row in rows:
            reference = expected[(row["unit_mrid"], row["contingency_mrid"])]
            assert float(row["curative_change_mw"]) == pytest.approx(reference["curative_change_mw"], abs=1e-9)
            assert float(row["penalty_cost_eur"]) == pytest.approx(reference["penalty_cost_eur"], abs=1e-9)
        assert _csv_rows(run.out / "results_hvdc.csv") == []                    # header only: no preventive unit

    def test_the_availability_file_lists_branches_and_contingencies_with_a_reason_column(self, runner):
        run = _cur_run(runner, contingencies=(CO_OVERLOAD_A, CO_OVERLOAD_B), time_to_implement="PT15M")
        rows = _csv_rows(run.out / "hvdc_cra_availability.csv")
        assert rows and {"tso", "scope", "reason", "available"} <= set(rows[0])
        assert {r["tso"] for r in rows} == {"TSO-Svedala"}
        assert {r["scope"] for r in rows} == {"branch", "contingency"}
        branch_rows = [r for r in rows if r["scope"] == "branch"]
        assert any(r["available"] == "False" and r["reason"] == "reaction time above the TATL duration" for r in branch_rows)
        assert {r["contingency_mrid"] for r in rows if r["scope"] == "contingency"} == {CO_OVERLOAD_A, CO_OVERLOAD_B}

    def test_an_available_group_has_empty_reasons(self, runner):
        rows = _csv_rows(_cur_run(runner).out / "hvdc_cra_availability.csv")
        assert rows and {r["reason"] for r in rows} == {""} and {r["available"] for r in rows} == {"True"}

    def test_without_hvdc_in_ra_types_no_hvdc_file_and_no_hvdc_summary_rows(self, runner):
        run = runner(mode="ac_single_pass", ra_types=("pst", "rd"), ncp=_MOCK_NX_NCP_ZIP)
        names = {p.name for p in run.out.iterdir()}
        assert not {"results_hvdc.csv", "results_curative_hvdc.csv", "hvdc_cra_availability.csv"} & names
        assert not any("hvdc" in r["metric"] for r in run.read("results_summary.csv"))
        # the inventory table has its HVDC column only with hvdc
        header = re.compile(r"TSO\s+AE-sec\s+AE-scn\s+AE-exc\s+CO\s+CO-must\s+PST\s+RD\s+Bids(\s+HVDC)?\s*$", re.MULTILINE)
        without = header.search((run.out / "run_log.txt").read_text(encoding=TEXT_ENCODING))
        with_hvdc = header.search((runner(mode="ac_single_pass").out / "run_log.txt").read_text(encoding=TEXT_ENCODING))
        assert without and without.group(1) is None
        assert with_hvdc and with_hvdc.group(1) is not None

    def test_the_new_files_are_registered(self):
        from output_file_registry import OUTPUT_FILE_REGISTRY
        assert {"results_hvdc.csv", "results_curative_hvdc.csv", "hvdc_cra_availability.csv"} <= set(OUTPUT_FILE_REGISTRY)


class TestSetPointOutsideItsRangeEndToEnd:
    """H3.4 on the mock: g1 (CGM set point 418.5 MW) has the range [-400, 400], its partner may move 5 MW only. The
    range is widened to [-400, 418.5] with a warning; with no overload the run is feasible and nothing moves."""

    @staticmethod
    def _ras(kind="preventive"):
        maker = default_ras if kind == "preventive" else curative_ras
        ras = maker() if kind == "preventive" else maker(contingencies=())
        ras[0]["ranges"] = [("upAndDown", "absolute", 400)]
        ras[1]["ranges"] = [("upAndDown", "incremental", 5)]
        return ras

    def test_preventive_without_an_overload_stays_at_the_cgm_set_point_at_no_cost(self, runner):
        run = runner(mode="ac_single_pass", patl=None, ras=self._ras())                 # the CGM limit: no overload
        g1, g2 = _unit_rows(run)
        assert (g1["pmin_op_mw"], g1["pmax_op_mw"]) == pytest.approx((-400.0, P0_SD_EH1), abs=1e-3)
        assert g1["change_mw"] == 0.0 and g2["change_mw"] == 0.0
        assert run.summary["sum_hvdc_penalty_cost_eur"] == 0.0
        log_text = (run.out / "run_log.txt").read_text(encoding=TEXT_ENCODING)
        assert re.search(rf"HVDC unit {g1['unit_mrid']} \(EquivalentInjection {EI_SD_EH1}\): the CGM set point 418\.468 MW is "
                         r"outside its range \[-400\.000, 400\.000\] MW - the range is widened to \[-400\.000, 418\.468\]", log_text)

    def test_curative_with_a_partner_that_cannot_absorb_stays_feasible_inside_the_widened_range(self, runner):
        """(The mock has N-X overloads at the CGM limits, so the pair does act in some contingencies; "no overload, no
        move" for curative units is test_rao_hvdc_milp.py TestSetPointOutsideItsRange.)"""
        cur = self._ras("curative")
        run = runner(mode="ac_single_pass", nx=True, patl=None, ras=cur, groups=curative_groups(cur))
        rows = _cur_rows(run)
        assert rows and all(r["pmax_op_mw"] == pytest.approx(P0_SD_EH1, abs=1e-3) for r in rows if r["ei_mrid"] == EI_SD_EH1)
        assert all(r["pmin_op_mw"] - 1e-6 <= r["p_after_curative_mw"] <= r["pmax_op_mw"] + 1e-6 for r in rows)
        assert all(abs(r["curative_change_mw"]) <= 5.0 + 1e-6 for r in rows)                # the partner's 5 MW
        assert float(run.summary["sum_cra_penalty_cost_hvdc_eur"]) == pytest.approx(
            sum(r["penalty_cost_eur"] for r in {r["unit_mrid"]: r for r in rows}.values()), abs=1e-9)
        assert run.summary["ac_verification_status"] == "SINGLE_PASS"                   # the model was feasible


class TestGuardsEndToEnd:
    """The pipeline passes the outage elements (H6.2, H11.1) and the initial N-X zero units (H8.2) to the model, and
    the loop refreshes the N-X HVDC sensitivities every iteration (H9.1); each checked on a run of main()."""

    @staticmethod
    def _run(tmp_path, mode, extra_co_xml, ras=None, groups=None, customize=None):
        cur = curative_ras(contingencies=()) if ras is None else ras
        ncp = build_hvdc_mock_ncp(tmp_path / "ncp.zip", ras=cur, groups=groups or curative_groups(cur), patl_a=PATL_CURATIVE,
                                  extra_co_xml=extra_co_xml)
        return run_pipeline_on_fixture_inputs(
            tmp_path / "run", ncp, enable_nx_analysis=True, ra_types=("hvdc",), calculation_mode=mode,
            customize_pipeline=customize,
        ).output_dir

    @staticmethod
    def _gate_rows(out, contingency):
        return {r["ei_mrid"]: r for r in _csv_rows(out / "hvdc_cra_availability.csv")
                if r["scope"] == "contingency" and r["contingency_mrid"] == contingency}

    def test_a_contingency_that_removes_the_ei_makes_the_group_unavailable_as_an_outage_element(self, tmp_path):
        out = self._run(tmp_path, "ac_single_pass", contingency_xml(CO_EI_OUT, [EI_SD_BO3], "CO_EI_SD_BO3"))
        rows = self._gate_rows(out, CO_EI_OUT)
        bo3, eh1 = rows[EI_SD_BO3], rows[EI_SD_EH1]
        # the gate's own reason, not the zero-sensitivity guard (which the builder only checks after the gate)
        assert (bo3["available"], bo3["reason"]) == ("False", "outage element")
        assert eh1["available"] == "False" and eh1["reason"] == f"group atomicity: partner {bo3['ra_mrid']}: outage element"
        assert CO_EI_OUT not in {r["contingency_mrid"] for r in _csv_rows(out / "results_curative_hvdc.csv")}
        assert all(r["available"] == "True" for r in self._gate_rows(out, CO_OVERLOAD_A).values())

    @pytest.mark.parametrize("mode", ["ac_single_pass", "dc"])
    def test_an_islanded_unit_makes_the_group_unavailable_in_that_contingency(self, tmp_path, mode):
        out = self._run(tmp_path, mode, contingency_xml(CO_ISLAND_BO3, ISLAND_BO3_LINES, "CO_ISLAND_SD_BO3"))
        rows = self._gate_rows(out, CO_ISLAND_BO3)
        bo3, eh1 = rows[EI_SD_BO3], rows[EI_SD_EH1]
        assert (bo3["available"], bo3["reason"]) == ("False", "zero sensitivity")
        assert eh1["reason"] == f"group atomicity: partner {bo3['ra_mrid']}: zero sensitivity"
        assert CO_ISLAND_BO3 not in {r["contingency_mrid"] for r in _csv_rows(out / "results_curative_hvdc.csv")}
        assert all(r["available"] == "True" for r in self._gate_rows(out, CO_OVERLOAD_A).values())

    def test_every_iteration_uses_the_n_x_hvdc_sensitivities_recomputed_at_its_state(self, tmp_path):
        """ac_iterative with a preventive pair that moves the operating point: the N-X HVDC set of the model of
        iteration k is the one recomputed (and pruned) at the state of iteration k, and it differs measurably from
        the initial set."""
        import copy

        seen, used = {"latest": None}, []

        def customize(rp, monkeypatch):
            original_prune = rp.prune_sensitivity_rd_nx

            def recording_prune(sensitivity, *args, **kwargs):
                result = original_prune(sensitivity, *args, **kwargs)
                if any(EI_SD_EH1 in key for per_contingency in sensitivity.values() for key in per_contingency):
                    seen["latest"] = copy.deepcopy(result)            # the HVDC set (the RD set has no EI key)
                return result

            monkeypatch.setattr(rp, "prune_sensitivity_rd_nx", recording_prune)
            import milp.ac_convergence_loop as loop
            original_build = loop.build_n0_milp_model

            def recording_build(*args, **kwargs):
                used.append((copy.deepcopy(kwargs["nx_inputs"].sensitivity_hvdc_nx), copy.deepcopy(seen["latest"])))
                return original_build(*args, **kwargs)

            monkeypatch.setattr(loop, "build_n0_milp_model", recording_build)

        pre, cur = default_ras(), curative_ras(own_ranges=False)
        pre[0]["penalty"] = pre[1]["penalty"] = 3.0
        self._run(tmp_path, "ac_iterative", "", ras=pre + cur, groups=default_groups(pre) + curative_groups(cur),
                  customize=customize)
        assert len(used) >= 2
        for in_model, recomputed in used:
            assert in_model == recomputed
        first, last = used[0][0], used[-1][0]
        common = [(c, key) for c in first for key in first[c] if key in last.get(c, {})]
        assert common and max(abs(first[c][key] - last[c][key]) for c, key in common) > 0.05      # about 0.19 A/MW


class TestSlackAndAnchor:
    def test_the_load_flows_do_not_move_the_ei_set_points_and_every_model_is_anchored_on_the_original(self, tmp_path):
        """ac_iterative, preventive pair (two solves): the distributed slack of the AC load flow leaves the EI target_p
        as written and the EI injects exactly its target_p (it takes no share of the slack); every model keeps the
        original P0 and the original limits, and charges the cumulative change against the original."""
        records, models = [], []

        def customize(rp, monkeypatch):
            import milp.ac_convergence_loop as loop
            original_lf, original_build = loop._run_ac_loadflow, loop.build_n0_milp_model

            def snapshot(network):
                generators = network.get_generators().loc[[EI_SD_EH1, EI_SD_BO3]]
                return {ei: (float(generators.loc[ei, "target_p"]), float(-generators.loc[ei, "p"])) for ei in generators.index}

            def recording_lf(network, *args, **kwargs):
                before = snapshot(network)
                result = original_lf(network, *args, **kwargs)
                records.append((before, snapshot(network)))
                return result

            def recording_build(*args, **kwargs):
                models.append(original_build(*args, **kwargs))
                return models[-1]

            monkeypatch.setattr(loop, "_run_ac_loadflow", recording_lf)
            monkeypatch.setattr(loop, "build_n0_milp_model", recording_build)

        ncp = build_hvdc_mock_ncp(tmp_path / "ncp.zip", patl_a=PATL_A)
        out = run_pipeline_on_fixture_inputs(tmp_path / "run", ncp, enable_nx_analysis=False, ra_types=("hvdc",),
                                             calculation_mode="ac_iterative", customize_pipeline=customize).output_dir
        assert len(records) >= 2 and len(models) >= 2
        for before, after in records:
            for ei, (target_after, injection_after) in after.items():
                assert target_after == before[ei][0]                                   # the load flow keeps the set point
                assert injection_after == pytest.approx(target_after, abs=1e-6)       # and the EI injects exactly it
        first, last = models[0].hvdc_info, models[-1].hvdc_info
        for unit in first:
            assert last[unit]["p_original_mw"] == first[unit]["p_original_mw"]
            assert (last[unit]["pmin_op_mw"], last[unit]["pmax_op_mw"]) == (first[unit]["pmin_op_mw"], first[unit]["pmax_op_mw"])
            assert last[unit]["p_current_mw"] != first[unit]["p_current_mw"]          # the second solve starts moved
            cumulative = last[unit]["p_current_mw"] + pyo.value(models[-1].hvdc_change[unit]) - last[unit]["p_original_mw"]
            assert pyo.value(models[-1].hvdc_cost_volume[unit]) == pytest.approx(abs(cumulative), abs=1e-6)
        rows = {r["unit_mrid"]: r for r in _csv_rows(out / "results_hvdc.csv")}
        for unit, row in rows.items():
            assert float(row["change_mw"]) == pytest.approx(float(row["result_p_mw"]) - float(row["original_p_mw"]), abs=1e-9)


class TestNxExports:
    def test_the_preventive_hvdc_term_is_in_the_predicted_loading_after_pra(self, runner):
        run = runner(mode="ac_single_pass", nx=True)
        rows = [r for r in run.read("results_nx_loadings.csv") if r["branch_mrid"] == XNE_BRANCH and r["contingency_mrid"] == CO_OVERLOAD_A]
        assert len(rows) == 1
        row = rows[0]
        effect = run.model.nx_hvdc_preventive_effect_ampere(XNE_BRANCH, CO_OVERLOAD_A)
        assert effect < -10.0
        patl = float(row["patl_ka"]) * 1000.0
        predicted = float(row["loading_pct_nx_post_pra_model"]) / 100.0 * patl
        assert predicted == pytest.approx(float(row["i_ka_nx_initial"]) * 1000.0 + effect, abs=1e-3)

    def test_the_curative_hvdc_term_is_in_the_predicted_loading_after_cra_and_only_there(self, runner):
        run = _cur_run(runner)
        rows = {r["contingency_mrid"]: r for r in run.read("results_nx_loadings.csv") if r["branch_mrid"] == XNE_BRANCH}
        a, b = rows[CO_OVERLOAD_A], rows[CO_OVERLOAD_B]
        patl = float(a["patl_ka"]) * 1000.0
        effect = run.model.nx_curative_effect_ampere(XNE_BRANCH, CO_OVERLOAD_A)
        assert effect < -20.0
        assert float(a["loading_pct_nx_post_pra"]) == pytest.approx(float(a["loading_pct_nx_initial"]), abs=0.5)    # no preventive action
        assert float(a["loading_pct_nx_post_pra_cra"]) == pytest.approx(
            float(a["loading_pct_nx_post_pra"]) + effect / patl * 100.0, abs=1e-6)
        assert float(a["loading_pct_nx_post_pra_cra"]) <= 100.0 + 0.1
        assert float(b["loading_pct_nx_post_pra_cra"]) == pytest.approx(float(b["loading_pct_nx_post_pra"]), abs=1e-9)
        assert float(b["loading_pct_nx_post_pra_cra"]) > 100.0

    def test_the_slack_columns_agree_with_the_model(self, runner):
        run = _cur_run(runner)
        rows = {r["contingency_mrid"]: r for r in run.read("results_nx_loadings.csv") if r["branch_mrid"] == XNE_BRANCH}
        assert float(rows[CO_OVERLOAD_A]["slack_patl"]) == pytest.approx(_slack(run, CO_OVERLOAD_A), abs=1e-9)
        assert float(rows[CO_OVERLOAD_B]["slack_patl"]) == pytest.approx(_slack(run, CO_OVERLOAD_B), abs=1e-9)


# ---------------------------------------------------------------------------
# step 11: ra_types combinations
# ---------------------------------------------------------------------------

class TestRaTypeCombinations:
    @pytest.mark.parametrize("types, label", [
        (("hvdc",), "hvdc"), (("pst", "hvdc"), "pst+hvdc"), (("rd", "hvdc"), "rd+hvdc"), (("pst", "rd", "hvdc"), "pst+rd+hvdc"),
    ])
    def test_hvdc_with_the_other_types(self, runner, types, label):
        run = runner(ra_types=types)
        assert run.summary["ra_types"] == label
        g1, g2 = _unit_rows(run)
        assert g1["change_mw"] + g2["change_mw"] == pytest.approx(0.0, abs=1e-6)
        if "pst" in types:
            # the PST relieves the branch at a lower price: the HVDC pair is available but may stay where it is
            assert abs(g1["change_mw"]) < 1e-6 or g1["change_mw"] > 1.0
        else:
            assert g1["change_mw"] > 1.0
        assert "sum_hvdc_penalty_cost_eur" in run.summary
        assert abs(float(run.summary["objective_residual_eur"])) < 1e-6
        assert (run.out / "results_hvdc.csv").exists()

    def test_without_hvdc_the_hvdc_rows_do_not_exist(self, runner):
        run = runner(ra_types=("pst", "rd"), ncp=_MOCK_NX_NCP_ZIP)
        assert run.summary["ra_types"] == "pst+rd" and "sum_hvdc_penalty_cost_eur" not in run.summary