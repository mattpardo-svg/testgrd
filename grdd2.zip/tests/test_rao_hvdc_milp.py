"""
test_rao_hvdc_milp.py — the preventive HVDC block of the MILP (docs/specs/hvdc_ra_specs.md H5, H7.3):
variables, bounds, the group balance (dg1 + dg2 = 0), the effect on every row type, the cost,
and that the units stay out of the RD balance. Synthetic models, no network.
"""
import logging

import pyomo.environ as pyo
import pytest
from pyomo.repn import generate_standard_repn

from data_model import AEType, AssessedElement, BidDirection, HvdcUnit, PowerBid, RAKind, RDUnit
from helpers import _solve
from milp.milp_builder import HvdcMilpInputs, NxMilpInputs, RdMilpInputs, build_n0_milp_model
from milp.post_ra_congestion_check import extract_hvdc_target_p_solution
from milp.ac_convergence_loop import describe_original_network
from post_milp.n0_results_export import extract_hvdc_results
from text_encoding import TEXT_ENCODING

TS = "1030Z"
REF = 10.0                 # EUR/MW


def _unit(mrid, ei, group="G1", factor=1.0, kind=RAKind.PREVENTIVE):
    return HvdcUnit(mrid=mrid, name=f"unit {mrid}", tso="TSO-A", ei_mrid=ei, available=True, kind=kind,
                    penalty_factor=factor, group_mrid=group)


def _ae(branch, patl_a, ae_type=AEType.SECURED):
    return AssessedElement(mrid=f"AE-{branch}", name=branch, tso="TSO-A", ae_type=ae_type, branch_mrid=branch,
                           secured_for_region=None, scanned_for_region=None, exclusion_reason=None,
                           patl_ka={TS: patl_a / 1000.0}, branch_side=1)


def _hvdc(units=None, s0=None, limits=None, p=(100.0, 50.0), original=None, factor=1.0, ref=REF):
    units = units or [_unit("U1", "E1", factor=factor), _unit("U2", "E2", factor=factor)]
    # B1 is relieved by U1 up / U2 down (S(U1) - S(U2) = -2 A/MW)
    s0 = {("B1", "E1"): -2.0, ("B1", "E2"): 0.0, ("B2", "E1"): 0.5, ("B2", "E2"): -0.5} if s0 is None else s0
    limits = limits or {"U1": (-500.0, 500.0), "U2": (-500.0, 500.0)}
    current = {"E1": p[0], "E2": p[1]}
    return HvdcMilpInputs(units=units, limits=limits, original_p_mw=dict(original or current), current_p_mw=current,
                          sensitivity_hvdc_n0=s0, penalty_reference_pra=ref, penalty_reference_cra=ref)


def _build(hvdc, i_b1=120.0, patl_b1=100.0, **kwargs):
    ae = [_ae("B1", patl_b1), _ae("B2", 1000.0)]
    lf = {"B1": {1: i_b1, 2: i_b1}, "B2": {1: 300.0, 2: 300.0}}
    return build_n0_milp_model(ae, TS, lf, 10000.0, hvdc_inputs=hvdc, **kwargs)


def _net(model, unit):
    return pyo.value(model.hvdc_change[unit])


def _variables(constraint):
    return {v.name for v in generate_standard_repn(constraint.body, quadratic=False).linear_vars}


class TestPreventiveBlock:
    def test_the_overload_is_relieved_by_the_pair_and_the_pair_balances(self):
        model = _solve(_build(_hvdc()))
        # 20 A to remove at -2 A/MW: 10 MW up on U1 and 10 MW down on U2
        assert _net(model, "U1") == pytest.approx(10.0, abs=1e-6)
        assert _net(model, "U2") == pytest.approx(-10.0, abs=1e-6)
        assert _net(model, "U1") + _net(model, "U2") == pytest.approx(0.0, abs=1e-9)
        assert pyo.value(model.overload_slack_n0["B1"]) == pytest.approx(0.0, abs=1e-6)

    def test_the_balance_is_a_hard_equality_per_group(self):
        model = _build(_hvdc())
        constraint = model.hvdc_group_balance["G1"]
        assert constraint.equality
        assert _variables(constraint) == {"hvdc_dp_up[U1]", "hvdc_dp_down[U1]", "hvdc_dp_up[U2]", "hvdc_dp_down[U2]"}
        assert pyo.value(constraint.upper) == 0.0

    def test_two_groups_are_balanced_separately(self):
        units = [_unit("U1", "E1", "G1"), _unit("U2", "E2", "G1"), _unit("U3", "E3", "G2"), _unit("U4", "E4", "G2")]
        hvdc = _hvdc(units=units, s0={("B1", "E1"): -2.0}, limits={u.mrid: (-500.0, 500.0) for u in units},
                     p=(100.0, 50.0))
        hvdc.current_p_mw.update(E3=10.0, E4=20.0)
        hvdc.original_p_mw.update(E3=10.0, E4=20.0)
        model = _build(hvdc)
        assert set(model.hvdc_group_balance) == {"G1", "G2"}
        assert _variables(model.hvdc_group_balance["G2"]) == {
            "hvdc_dp_up[U3]", "hvdc_dp_down[U3]", "hvdc_dp_up[U4]", "hvdc_dp_down[U4]"}

    def test_the_upper_bound_limits_the_change(self):
        # P0 100 + change <= 104: only 4 MW of the 10 MW needed
        hvdc = _hvdc(limits={"U1": (-500.0, 104.0), "U2": (-500.0, 500.0)})
        model = _solve(_build(hvdc))
        assert _net(model, "U1") == pytest.approx(4.0, abs=1e-6)
        assert _net(model, "U2") == pytest.approx(-4.0, abs=1e-6)
        assert pyo.value(model.overload_slack_n0["B1"]) == pytest.approx(12.0, abs=1e-5)

    def test_the_lower_bound_limits_the_partner_and_negative_limits_work(self):
        # U2 (P0 50) may go down to 47 only
        hvdc = _hvdc(limits={"U1": (-500.0, 500.0), "U2": (47.0, 500.0)})
        model = _solve(_build(hvdc))
        assert _net(model, "U2") == pytest.approx(-3.0, abs=1e-6)
        assert _net(model, "U1") == pytest.approx(3.0, abs=1e-6)
        negative = _solve(_build(_hvdc(limits={"U1": (-500.0, 500.0), "U2": (-55.0, 500.0)})))
        assert _net(negative, "U2") == pytest.approx(-10.0, abs=1e-6)       # a range reaching below zero is fine

    def test_bounds_are_on_the_set_point_of_the_operating_point(self):
        # the operating point is already 8 MW up from the original (P = 108); limits are anchored on the original
        hvdc = _hvdc(p=(108.0, 42.0), original={"E1": 100.0, "E2": 50.0}, limits={"U1": (90.0, 112.0), "U2": (30.0, 60.0)})
        model = _solve(_build(hvdc))
        assert _net(model, "U1") == pytest.approx(4.0, abs=1e-6)             # 112 - 108

    def test_units_are_continuous_without_binaries_or_on_off_variables(self):
        model = _build(_hvdc())
        assert all(not v.is_binary() and not v.is_integer() for v in model.component_data_objects(pyo.Var)
                   if v.name.startswith("hvdc"))
        assert not hasattr(model, "rd_unit_on")

    def test_a_model_with_only_hvdc_is_valid_and_none_of_everything_is_not(self):
        assert hasattr(_build(_hvdc()), "hvdc_change")
        with pytest.raises(ValueError, match="pst_inputs, rd_inputs, hvdc_inputs, or nx_inputs .*all four absent"):
            build_n0_milp_model([_ae("B1", 100.0)], TS, {"B1": {1: 1.0, 2: 1.0}}, 1.0)

    def test_a_curative_unit_gets_no_preventive_variables(self):
        units = [_unit("U1", "E1", kind=RAKind.CURATIVE), _unit("U2", "E2", kind=RAKind.CURATIVE)]
        hvdc = _hvdc(units=units)
        assert hvdc.preventive_units == []
        built = build_n0_milp_model([_ae("B1", 100.0)], TS, {"B1": {1: 120.0, 2: 120.0}}, 1.0, hvdc_inputs=hvdc,
                                    nx_inputs=NxMilpInputs(lf_nx={}, sensitivity_pst_nx={}, sensitivity_rd_nx={}))
        assert not hasattr(built, "hvdc_change")

    def test_a_nan_sensitivity_excludes_the_branch(self):
        s0 = {("B1", "E1"): float("nan"), ("B1", "E2"): 0.0}
        model = _build(_hvdc(s0=s0))
        assert "B1" not in set(model.secured_branch_ids)


class TestOutsideTheRdBalance:
    @staticmethod
    def _rd_inputs():
        rd = RDUnit(mrid="RA-RD", name="rd", tso="TSO-A", gu_mrid="G-RD", gu_name="g", available=True,
                    kind=RAKind.PREVENTIVE, initial_p=100.0, max_p=200.0, min_p=0.0, raise_ramp_rate=None,
                    lower_ramp_rate=None, penalty_factor=1.0)
        bids = [PowerBid(mrid=f"BID-{d.value}", ra_mrid="RA-RD", direction=d, available_mw={TS: 50.0}, price_eur_mw=1.0,
                         penalty_factor=1.0, lead_time_h=0.0, activation_cost_eur=None, min_energy_mwh=None,
                         max_energy_mwh=None, step_size_mw=None) for d in (BidDirection.UP, BidDirection.DOWN)]
        return RdMilpInputs(
            rd_list=[rd], bid_list=bids, glsk={"RA-RD": {"G-RD": 1.0}}, sensitivity_rd_n0_pruned={("B1", "G-RD"): 0.1},
            generator_data={"G-RD": {"target_p": 100.0, "max_p": 200.0, "min_p": 0.0, "name": "g"}},
            penalty_reference_rd_pra=1.0,
        )

    def test_the_rd_balance_does_not_contain_the_hvdc_variables(self):
        model = _build(_hvdc(), rd_inputs=self._rd_inputs())
        assert hasattr(model, "rd_balancing_n0")
        assert not any(name.startswith("hvdc") for name in _variables(model.rd_balancing_n0))

    def test_an_unpaired_net_change_is_impossible_but_the_rd_balance_is_still_free_of_it(self):
        model = _solve(_build(_hvdc(), rd_inputs=self._rd_inputs()))
        assert pyo.value(sum(model.rd_net_injection_g[g] for g in model.gu_ids)) == pytest.approx(0.0, abs=1e-9)
        assert _net(model, "U1") + _net(model, "U2") == pytest.approx(0.0, abs=1e-9)


class TestEffectOnEveryRowType:
    """The unit variables appear in the N-0 secured, N-0 scanned, N-X PATL, N-X TATL and N-X scanned rows."""

    @staticmethod
    def _model():
        ae = [_ae("B1", 100.0), _ae("B2", 1000.0), _ae("S1", 500.0, AEType.SCANNED)]
        lf = {"B1": {1: 120.0, 2: 120.0}, "B2": {1: 300.0, 2: 300.0}, "S1": {1: 400.0, 2: 400.0}}
        lf_nx = {"C1": {"B1": {1: 140.0, 2: 140.0}, "B2": {1: 300.0, 2: 300.0}, "S1": {1: 450.0, 2: 450.0}}}
        s0 = {("B1", "E1"): -2.0, ("S1", "E1"): -1.0}
        s_nx = {"C1": {("B1", "E1"): -3.0, ("B2", "E1"): 0.2, ("S1", "E1"): -1.5, ("S1", "E2"): 0.5}}
        nx = NxMilpInputs(
            lf_nx=lf_nx, sensitivity_pst_nx={}, sensitivity_rd_nx={}, sensitivity_hvdc_nx=s_nx,
            penalty_cost_overload_nx_patl=10000.0, penalty_cost_overload_nx_tatl=10000.0, penalty_cost_overload_nx_scanned=10000.0,
            tatl_data={"B1": {"tatl_limit_ampere": 130.0, "side": 1, "patl_limit_ampere": 100.0}},
        )
        return build_n0_milp_model(ae, TS, lf, 10000.0, hvdc_inputs=_hvdc(s0=s0), nx_inputs=nx)

    def test_n0_secured_row(self):
        assert "hvdc_dp_up[U1]" in _variables(self._model().xne_loading_n0["B1"])

    def test_n0_scanned_row(self):
        assert "hvdc_dp_up[U1]" in _variables(self._model().scanned_element_n0["S1"])

    def test_nx_patl_row_carries_the_nx_sensitivity(self):
        model = self._model()
        repn = generate_standard_repn(model.nx_patl_loading["B1", "C1"].body, quadratic=False)
        coefficients = {v.name: c for v, c in zip(repn.linear_vars, repn.linear_coefs)}
        assert coefficients["hvdc_dp_up[U1]"] == pytest.approx(-3.0)        # not the N-0 value -2.0
        assert coefficients["hvdc_dp_down[U1]"] == pytest.approx(3.0)

    def test_nx_tatl_row(self):
        assert "hvdc_dp_up[U1]" in _variables(self._model().nx_tatl_loading["B1", "C1"])

    def test_nx_scanned_row_has_both_units(self):
        names = _variables(self._model().nx_scanned_loading["S1", "C1"])
        assert {"hvdc_dp_up[U1]", "hvdc_dp_up[U2]"} <= names

    def test_a_unit_without_a_sensitivity_in_a_row_adds_nothing_there(self):
        names = _variables(self._model().nx_patl_loading["B2", "C1"])
        assert "hvdc_dp_up[U1]" in names and "hvdc_dp_up[U2]" not in names     # only (B2, E1) is given

    def test_the_effect_is_the_sensitivity_times_the_change(self):
        model = self._model()
        model.hvdc_dp_up["U1"].set_value(4.0)
        model.hvdc_dp_down["U1"].set_value(0.0)
        model.hvdc_dp_up["U2"].set_value(0.0)
        model.hvdc_dp_down["U2"].set_value(4.0)
        assert pyo.value(model.hvdc_effect_on_branch["B1"]) == pytest.approx(-8.0)


class TestCost:
    def test_the_objective_charges_both_units_factor_times_reference_times_the_change(self):
        model = _solve(_build(_hvdc(factor=1.0)))
        # 10 MW on each of the two units, 10 EUR/MW
        expected = 1.0 * REF * 10.0 + 1.0 * REF * 10.0
        assert pyo.value(model.objective_penalty_term_expressions["hvdc_pra_penalty_cost"]) == pytest.approx(expected, abs=1e-6)
        assert pyo.value(model.objective) == pytest.approx(expected, abs=1e-6)

    def test_each_unit_pays_its_own_factor(self):
        units = [_unit("U1", "E1", factor=1.0), _unit("U2", "E2", factor=3.0)]
        model = _solve(_build(_hvdc(units=units)))
        assert pyo.value(model.objective) == pytest.approx(REF * 10.0 * (1.0 + 3.0), abs=1e-6)

    def test_a_factor_of_zero_is_free(self):
        model = _solve(_build(_hvdc(factor=0.0)))
        assert pyo.value(model.objective) == pytest.approx(0.0, abs=1e-6)
        assert pyo.value(model.overload_slack_n0["B1"]) == pytest.approx(0.0, abs=1e-6)

    def test_a_high_factor_leaves_the_overload(self):
        # 2 units x 10 MW x REF 10 x factor 500 = 100000 EUR against 20 A x 10000 EUR/A = 200000: still relieved;
        # factor 2000 makes the use dearer than the overload
        relieved = _solve(_build(_hvdc(factor=500.0)))
        left = _solve(_build(_hvdc(factor=2000.0)))
        assert _net(relieved, "U1") == pytest.approx(10.0, abs=1e-5)
        assert _net(left, "U1") == pytest.approx(0.0, abs=1e-5)
        assert pyo.value(left.overload_slack_n0["B1"]) == pytest.approx(20.0, abs=1e-5)

    def test_the_penalty_is_charged_on_the_cumulative_change_against_the_original(self):
        # the operating point is 6 MW up from the original; going back (-6) costs nothing
        hvdc = _hvdc(p=(106.0, 44.0), original={"E1": 100.0, "E2": 50.0}, s0={("B1", "E1"): 2.0, ("B1", "E2"): 0.0})
        model = _solve(_build(hvdc, i_b1=100.0, patl_b1=100.0))
        # no overload: the cheapest is to return to the original set points
        assert pyo.value(model.objective) == pytest.approx(0.0, abs=1e-6)
        assert _net(model, "U1") == pytest.approx(-6.0, abs=1e-6)

    def test_the_penalty_grows_with_the_cumulative_change(self):
        hvdc = _hvdc(p=(106.0, 44.0), original={"E1": 100.0, "E2": 50.0})
        model = _solve(_build(hvdc, i_b1=140.0))             # more relief needed than the present 6 MW gives
        total = abs(_net(model, "U1") + 6.0) * 1.0 * REF + abs(_net(model, "U2") - 6.0) * REF
        assert pyo.value(model.objective) == pytest.approx(total, abs=1e-5)


class TestResultsAndWriteBack:
    def test_target_p_solution_is_the_operating_point_plus_the_change(self):
        model = _solve(_build(_hvdc(p=(100.0, 50.0))))
        solution = extract_hvdc_target_p_solution(model)
        assert solution == {"E1": pytest.approx(110.0, abs=1e-6), "E2": pytest.approx(40.0, abs=1e-6)}

    def test_a_model_without_hvdc_has_an_empty_solution(self):
        model = build_n0_milp_model([_ae("B1", 100.0)], TS, {"B1": {1: 1.0, 2: 1.0}}, 1.0,
                                    nx_inputs=NxMilpInputs(lf_nx={}, sensitivity_pst_nx={}, sensitivity_rd_nx={}))
        assert extract_hvdc_target_p_solution(model) == {}
        assert extract_hvdc_results(model, REF) == {}

    def test_result_rows_are_floats_against_the_original_with_the_penalty_of_the_change(self):
        model = _solve(_build(_hvdc(p=(106.0, 44.0), original={"E1": 100.0, "E2": 50.0}), i_b1=140.0))
        rows = extract_hvdc_results(model, REF)
        row = rows["U1"]
        assert isinstance(row["result_p_mw"], float) and isinstance(row["change_mw"], float)
        assert row["change_mw"] == pytest.approx(row["result_p_mw"] - 100.0)
        assert row["penalty_cost_eur"] == pytest.approx(abs(row["change_mw"]) * REF)
        assert rows["U1"]["change_mw"] + rows["U2"]["change_mw"] == pytest.approx(0.0, abs=1e-9)
        assert sum(r["penalty_cost_eur"] for r in rows.values()) == pytest.approx(pyo.value(model.objective), abs=1e-5)

    def test_describing_the_original_network_zeroes_the_change(self):
        model = _solve(_build(_hvdc()))
        describe_original_network(model)
        assert extract_hvdc_target_p_solution(model) == {"E1": 100.0, "E2": 50.0}
        assert all(row["change_mw"] == 0.0 for row in extract_hvdc_results(model, REF).values())


# ---------------------------------------------------------------------------
# curative (H6, H7.4)
# ---------------------------------------------------------------------------

def _cur_unit(mrid, ei, group="GC", linked=(), reaction=None, factor=1.0):
    return HvdcUnit(mrid=mrid, name=f"curative {mrid}", tso="TSO-A", ei_mrid=ei, available=True, kind=RAKind.CURATIVE,
                    penalty_factor=factor, reaction_time_minutes=reaction, linked_contingency_mrids=list(linked), group_mrid=group)


def _cur_hvdc(units=None, limits=None, p=(100.0, 50.0), outage=None, zero=None, ref=REF, with_preventive=False):
    cur = units or [_cur_unit("C1U", "E1"), _cur_unit("C2U", "E2")]
    all_units = list(cur) + ([_unit("U1", "E1"), _unit("U2", "E2")] if with_preventive else [])
    limits = dict(limits or {"C1U": (-500.0, 500.0), "C2U": (-500.0, 500.0), "U1": (-500.0, 500.0), "U2": (-500.0, 500.0)})
    for unit in all_units:
        limits.setdefault(unit.mrid, (-500.0, 500.0))
    return HvdcMilpInputs(
        units=all_units, limits=limits, original_p_mw={"E1": p[0], "E2": p[1]}, current_p_mw={"E1": p[0], "E2": p[1]},
        sensitivity_hvdc_n0={("B1", "E1"): -2.0}, penalty_reference_pra=ref, penalty_reference_cra=ref,
        outage_eis_by_contingency={c: frozenset(v) for c, v in (outage or {}).items()}, zero_units_nx=zero or {},
    )


def _nx(contingency_currents=None, sens=None, tatl_data=None, fallback=600):
    currents = contingency_currents or {"C1": 130.0, "C2": 130.0}
    s = sens or {c: {("B1", "E1"): -2.0, ("B1", "E2"): 0.0, ("B2", "E1"): 0.1} for c in currents}
    return NxMilpInputs(
        lf_nx={c: {"B1": {1: i, 2: i}, "B2": {1: 300.0, 2: 300.0}} for c, i in currents.items()},
        sensitivity_pst_nx={}, sensitivity_rd_nx={}, sensitivity_hvdc_nx=s, penalty_cost_overload_nx_patl=10000.0,
        penalty_cost_overload_nx_tatl=10000.0, tatl_data=tatl_data, tatl_fallback_duration_seconds=fallback,
    )


def _cur_build(hvdc, nx=None, i_b1=80.0, **kwargs):
    ae = [_ae("B1", 100.0), _ae("B2", 1000.0)]
    lf = {"B1": {1: i_b1, 2: i_b1}, "B2": {1: 300.0, 2: 300.0}}
    return build_n0_milp_model(ae, TS, lf, 10000.0, hvdc_inputs=hvdc, nx_inputs=nx or _nx(), **kwargs)


def _cur_net(model, unit, contingency):
    return pyo.value(model.hvdc_cur_up[unit, contingency]) - pyo.value(model.hvdc_cur_down[unit, contingency])


class TestCurativeBlock:
    def test_a_curative_only_model_has_no_preventive_block_and_relieves_every_contingency_without_a_link(self):
        model = _solve(_cur_build(_cur_hvdc()))
        assert not hasattr(model, "hvdc_change")                                   # no preventive variables
        assert set(model.hvdc_cur_pairs) == {("C1U", "C1"), ("C1U", "C2"), ("C2U", "C1"), ("C2U", "C2")}    # R2
        for contingency in ("C1", "C2"):
            assert _cur_net(model, "C1U", contingency) == pytest.approx(15.0, abs=1e-6)       # 30 A at 2 A/MW
            assert _cur_net(model, "C2U", contingency) == pytest.approx(-15.0, abs=1e-6)
            assert pyo.value(model.nx_patl_overload_slack["B1", contingency]) == pytest.approx(0.0, abs=1e-6)

    def test_a_linked_group_acts_only_in_its_contingency(self):
        units = [_cur_unit("C1U", "E1", linked=["C1"]), _cur_unit("C2U", "E2", linked=["C1"])]
        model = _solve(_cur_build(_cur_hvdc(units=units)))
        assert set(model.hvdc_cur_pairs) == {("C1U", "C1"), ("C2U", "C1")}
        assert pyo.value(model.nx_patl_overload_slack["B1", "C1"]) == pytest.approx(0.0, abs=1e-6)
        assert pyo.value(model.nx_patl_overload_slack["B1", "C2"]) == pytest.approx(30.0, abs=1e-6)

    def test_a_group_does_not_act_in_an_excluded_contingency(self):
        """combinationConstraintKind excluded (decision 95): no link and C2 excluded = every contingency but C2."""
        units = [_cur_unit("C1U", "E1"), _cur_unit("C2U", "E2")]
        for unit in units:
            unit.excluded_contingency_mrids = ["C2"]
        model = _solve(_cur_build(_cur_hvdc(units=units)))
        assert set(model.hvdc_cur_pairs) == {("C1U", "C1"), ("C2U", "C1")}
        assert pyo.value(model.nx_patl_overload_slack["B1", "C2"]) == pytest.approx(30.0, abs=1e-6)

    def test_the_variables_of_a_contingency_appear_only_in_the_rows_of_that_contingency(self):
        units = [_cur_unit("C1U", "E1"), _cur_unit("C2U", "E2")]
        model = _cur_build(_cur_hvdc(units=units))
        names_c1 = _variables(model.nx_patl_loading["B1", "C1"])
        assert "hvdc_cur_up[C1U,C1]" in names_c1 and not any(",C2]" in n for n in names_c1)
        names_c2 = _variables(model.nx_patl_loading["B1", "C2"])
        assert "hvdc_cur_up[C1U,C2]" in names_c2 and not any(",C1]" in n for n in names_c2)

    def test_the_curative_effect_is_not_in_the_tatl_row_but_the_preventive_one_is(self):
        tatl = {"B1": {"tatl_limit_ampere": 120.0, "tatl_duration_seconds": 600, "side": 1}}
        model = _cur_build(_cur_hvdc(with_preventive=True, units=None), nx=_nx(tatl_data=tatl))
        assert hasattr(model, "nx_tatl_loading")
        names = _variables(model.nx_tatl_loading["B1", "C1"])
        assert not any(n.startswith("hvdc_cur") for n in names)
        assert "hvdc_dp_up[U1]" in names                                            # the preventive term stays
        assert any(n.startswith("hvdc_cur_up") for n in _variables(model.nx_patl_loading["B1", "C1"]))

    def test_the_curative_effect_is_in_the_scanned_row(self):
        ae = [_ae("B1", 100.0), _ae("S1", 500.0, AEType.SCANNED)]
        lf = {"B1": {1: 80.0, 2: 80.0}, "S1": {1: 400.0, 2: 400.0}}
        nx = NxMilpInputs(
            lf_nx={"C1": {"B1": {1: 90.0, 2: 90.0}, "S1": {1: 520.0, 2: 520.0}}}, sensitivity_pst_nx={}, sensitivity_rd_nx={},
            sensitivity_hvdc_nx={"C1": {("S1", "E1"): -2.0}}, penalty_cost_overload_nx_scanned=10000.0,
        )
        hv = _cur_hvdc(with_preventive=True)       # a preventive unit keeps the N-0 scanned row non-trivial
        hv.sensitivity_hvdc_n0[("S1", "E1")] = -2.0
        model = build_n0_milp_model(ae, TS, lf, 10000.0, hvdc_inputs=hv, nx_inputs=nx)
        assert any(n.startswith("hvdc_cur_up") for n in _variables(model.nx_scanned_loading["S1", "C1"]))

    def test_the_balance_is_a_hard_equality_per_group_and_contingency(self):
        model = _cur_build(_cur_hvdc())
        assert set(model.hvdc_cur_balance) == {("GC", "C1"), ("GC", "C2")}
        constraint = model.hvdc_cur_balance["GC", "C1"]
        assert constraint.equality
        assert _variables(constraint) == {"hvdc_cur_up[C1U,C1]", "hvdc_cur_down[C1U,C1]", "hvdc_cur_up[C2U,C1]", "hvdc_cur_down[C2U,C1]"}

    def test_the_balance_holds_per_contingency_in_the_solution(self):
        model = _solve(_cur_build(_cur_hvdc(), nx=_nx({"C1": 130.0, "C2": 110.0})))
        for contingency in ("C1", "C2"):
            assert _cur_net(model, "C1U", contingency) + _cur_net(model, "C2U", contingency) == pytest.approx(0.0, abs=1e-9)
        assert _cur_net(model, "C1U", "C1") == pytest.approx(15.0, abs=1e-6)
        assert _cur_net(model, "C1U", "C2") == pytest.approx(5.0, abs=1e-6)

    def test_the_bound_is_exact_per_contingency_and_counts_the_preventive_change(self):
        # Pmax_op of the unit is 104; the preventive N-0 relief already needs +3 (60 A at... see sensitivity), so the
        # curative change may use what is left: P + preventive + curative <= 104
        units = [_cur_unit("C1U", "E1"), _cur_unit("C2U", "E2")]
        limits = {"C1U": (-500.0, 104.0), "C2U": (-500.0, 500.0), "U1": (-500.0, 104.0), "U2": (-500.0, 500.0)}
        hvdc = _cur_hvdc(units=units, limits=limits, with_preventive=True)
        model = _solve(_cur_build(hvdc, i_b1=106.0))          # N-0: 6 A over -> preventive +3 MW
        assert _net(model, "U1") == pytest.approx(3.0, abs=1e-6)
        assert _cur_net(model, "C1U", "C1") == pytest.approx(1.0, abs=1e-6)       # 104 - 100 - 3
        assert pyo.value(model.nx_patl_overload_slack["B1", "C1"]) == pytest.approx(22.0, abs=1e-5)

    def test_the_lower_bound_of_the_curative_unit_applies_too(self):
        units = [_cur_unit("C1U", "E1"), _cur_unit("C2U", "E2")]
        limits = {"C1U": (-500.0, 500.0), "C2U": (47.0, 500.0)}
        model = _solve(_cur_build(_cur_hvdc(units=units, limits=limits)))
        assert _cur_net(model, "C2U", "C1") == pytest.approx(-3.0, abs=1e-6)

    def test_the_curative_cost_is_the_maximum_over_contingencies_not_the_sum(self):
        model = _solve(_cur_build(_cur_hvdc(), nx=_nx({"C1": 130.0, "C2": 110.0})))
        # unit changes 15 MW in C1 and 5 MW in C2: the maximum 15 is paid by each of the two units
        assert pyo.value(model.hvdc_cur_max["C1U"]) == pytest.approx(15.0, abs=1e-6)
        expected = 2 * 1.0 * REF * 15.0
        assert pyo.value(model.objective_penalty_term_expressions["hvdc_cra_penalty_cost"]) == pytest.approx(expected, abs=1e-5)
        assert pyo.value(model.objective) == pytest.approx(expected, abs=1e-5)

    def test_each_curative_unit_pays_its_own_factor_and_a_factor_of_zero_is_free(self):
        units = [_cur_unit("C1U", "E1", factor=1.0), _cur_unit("C2U", "E2", factor=3.0)]
        model = _solve(_cur_build(_cur_hvdc(units=units)))
        assert pyo.value(model.objective) == pytest.approx(REF * 15.0 * 4.0, abs=1e-5)
        free = _solve(_cur_build(_cur_hvdc(units=[_cur_unit("C1U", "E1", factor=0.0), _cur_unit("C2U", "E2", factor=0.0)])))
        assert pyo.value(free.objective) == pytest.approx(0.0, abs=1e-6)

    def test_the_max_variable_is_lower_bounded_only_and_there_are_no_binaries(self):
        model = _cur_build(_cur_hvdc())
        assert all(not v.is_binary() and not v.is_integer() for v in model.component_data_objects(pyo.Var) if "hvdc" in v.name)
        # bounded below by every pair, not above: with the cost removed the solver may leave it anywhere >= the pair
        assert set(model.hvdc_cur_max_lower) == set(model.hvdc_cur_pairs)
        assert all(model.hvdc_cur_max[u].ub is None for u in model.hvdc_cur_unit_ids)

    def test_the_cost_uses_the_curative_reference(self):
        hvdc = _cur_hvdc()
        hvdc.penalty_reference_cra, hvdc.penalty_reference_pra = 7.0, 1000.0
        model = _solve(_cur_build(hvdc))
        assert pyo.value(model.objective) == pytest.approx(2 * 7.0 * 15.0, abs=1e-5)


class TestCurativeAvailability:
    def test_an_outage_ei_makes_the_whole_group_unavailable_in_that_contingency(self):
        model = _cur_build(_cur_hvdc(outage={"C1": {"E2"}}))
        assert set(model.hvdc_cur_pairs) == {("C1U", "C2"), ("C2U", "C2")}          # E2 is out in C1: both units fixed to 0

    def test_a_zero_sensitivity_unit_makes_the_group_unavailable_in_that_contingency(self):
        model = _cur_build(_cur_hvdc(zero={"C2": ["E1"]}))
        assert set(model.hvdc_cur_pairs) == {("C1U", "C1"), ("C2U", "C1")}

    def test_an_unavailable_group_leaves_the_overload(self):
        model = _solve(_cur_build(_cur_hvdc(outage={"C1": {"E1"}, "C2": {"E1"}})))
        assert not hasattr(model, "hvdc_cur_up")
        assert pyo.value(model.nx_patl_overload_slack["B1", "C1"]) == pytest.approx(30.0, abs=1e-6)

    def test_the_gate_looks_at_both_linked_contingency_lists(self):
        units = [_cur_unit("C1U", "E1", linked=["C1", "C2"]), _cur_unit("C2U", "E2", linked=["C1"])]
        assert set(_cur_build(_cur_hvdc(units=units)).hvdc_cur_pairs) == {("C1U", "C1"), ("C2U", "C1")}

    def test_reaction_time_above_the_tatl_duration_removes_the_group(self, caplog):
        units = [_cur_unit("C1U", "E1", reaction=15.0), _cur_unit("C2U", "E2", reaction=15.0)]
        with caplog.at_level(logging.INFO):
            model = _solve(_cur_build(_cur_hvdc(units=units)))                      # fallback duration 600 s = 10 min
        assert not hasattr(model, "hvdc_cur_up")
        assert pyo.value(model.nx_patl_overload_slack["B1", "C1"]) == pytest.approx(30.0, abs=1e-6)
        assert any("reaction time above the TATL duration" in r.message for r in caplog.records)

    def test_reaction_time_equal_to_the_duration_is_available(self):
        units = [_cur_unit("C1U", "E1", reaction=10.0), _cur_unit("C2U", "E2", reaction=10.0)]
        assert hasattr(_cur_build(_cur_hvdc(units=units)), "hvdc_cur_up")

    def test_a_longer_tatl_duration_on_one_branch_makes_the_term_appear_only_there(self):
        # B1 has the fallback 10 min, B2 30 min: a 15 min action acts on B2 only; the variables exist (one branch is enough)
        units = [_cur_unit("C1U", "E1", reaction=15.0), _cur_unit("C2U", "E2", reaction=15.0)]
        tatl = {"B2": {"tatl_limit_ampere": 1000.0, "tatl_duration_seconds": 1800, "side": 1}}
        model = _cur_build(_cur_hvdc(units=units), nx=_nx(tatl_data=tatl))
        assert hasattr(model, "hvdc_cur_up")
        assert not any(n.startswith("hvdc_cur") for n in _variables(model.nx_patl_loading["B1", "C1"]))
        assert any(n.startswith("hvdc_cur") for n in _variables(model.nx_patl_loading["B2", "C1"]))

    def test_the_pair_term_needs_both_units_available_on_the_branch(self):
        units = [_cur_unit("C1U", "E1", reaction=5.0), _cur_unit("C2U", "E2", reaction=15.0)]
        tatl = {"B2": {"tatl_limit_ampere": 1000.0, "tatl_duration_seconds": 1800, "side": 1}}
        model = _cur_build(_cur_hvdc(units=units), nx=_nx(tatl_data=tatl))
        assert not any(n.startswith("hvdc_cur") for n in _variables(model.nx_patl_loading["B1", "C1"]))   # C2U too slow on B1
        assert any(n.startswith("hvdc_cur") for n in _variables(model.nx_patl_loading["B2", "C1"]))

    def test_without_nx_inputs_the_curative_units_add_nothing(self):
        model = build_n0_milp_model([_ae("B1", 100.0)], TS, {"B1": {1: 80.0, 2: 80.0}}, 1.0, hvdc_inputs=_cur_hvdc(),
                                    nx_inputs=NxMilpInputs(lf_nx={}, sensitivity_pst_nx={}, sensitivity_rd_nx={}))
        assert not hasattr(model, "hvdc_cur_up")


class TestCurativeOutsideTheOtherBalances:
    def test_the_curative_rd_balance_of_every_contingency_does_not_contain_the_hvdc_variables(self):
        from helpers import synthetic_curative_milp_inputs

        kwargs = synthetic_curative_milp_inputs()
        contingencies = sorted(kwargs["nx_inputs"].lf_nx)
        branches = sorted({b for per_branch in kwargs["nx_inputs"].lf_nx.values() for b in per_branch})
        kwargs["nx_inputs"].sensitivity_hvdc_nx = {c: {(b, "E1"): 0.5 for b in branches} for c in contingencies}
        kwargs["hvdc_inputs"] = _cur_hvdc(units=[_cur_unit("C1U", "E1"), _cur_unit("C2U", "E2")])
        model = build_n0_milp_model(**kwargs)
        assert hasattr(model, "hvdc_cur_up") and len(model.curative_rd_balancing) > 0
        for contingency in model.curative_rd_balancing:
            assert not any("hvdc" in name for name in _variables(model.curative_rd_balancing[contingency]))

    def test_curative_actions_are_not_in_the_write_back(self):
        model = _solve(_cur_build(_cur_hvdc(with_preventive=True)))
        assert extract_hvdc_target_p_solution(model) == {"E1": pytest.approx(100.0, abs=1e-6), "E2": pytest.approx(50.0, abs=1e-6)}
        assert hasattr(model, "hvdc_cur_up")                                         # present in the model, never applied


class TestCurativeResults:
    def test_rows_per_pair_with_the_unit_maximum_and_cost(self):
        from post_milp.n0_results_export import extract_curative_hvdc_results

        model = _solve(_cur_build(_cur_hvdc(), nx=_nx({"C1": 130.0, "C2": 110.0})))
        rows = extract_curative_hvdc_results(model, REF)
        assert [(r["unit_mrid"], r["contingency_mrid"]) for r in rows] == sorted(model.hvdc_cur_pairs)
        first = next(r for r in rows if r["unit_mrid"] == "C1U" and r["contingency_mrid"] == "C1")
        assert first["curative_change_mw"] == pytest.approx(15.0, abs=1e-6)
        assert first["p_after_preventive_mw"] == 100.0 and first["p_after_curative_mw"] == pytest.approx(115.0, abs=1e-6)
        assert first["max_curative_change_mw"] == pytest.approx(15.0, abs=1e-6)
        assert first["penalty_cost_eur"] == pytest.approx(REF * 15.0, abs=1e-5)
        per_unit = {r["unit_mrid"]: r["penalty_cost_eur"] for r in rows}
        assert sum(per_unit.values()) == pytest.approx(pyo.value(model.objective), abs=1e-5)

    def test_the_reported_maximum_is_the_largest_actual_change_not_the_free_model_variable(self):
        from post_milp.n0_results_export import extract_curative_hvdc_results

        units = [_cur_unit("C1U", "E1", factor=0.0), _cur_unit("C2U", "E2", factor=0.0)]
        model = _solve(_cur_build(_cur_hvdc(units=units), nx=_nx({"C1": 130.0, "C2": 110.0})))
        for u in model.hvdc_cur_unit_ids:
            model.hvdc_cur_max[u].set_value(999.0)               # at factor 0 nothing pushes the variable down
        rows = extract_curative_hvdc_results(model, REF)
        for r in rows:
            actual = max(abs(x["curative_change_mw"]) for x in rows if x["unit_mrid"] == r["unit_mrid"])
            assert r["max_curative_change_mw"] == pytest.approx(actual, abs=1e-6) and actual < 900.0
        assert all(r["penalty_cost_eur"] == 0.0 for r in rows)

    def test_no_pairs_no_rows(self):
        from post_milp.n0_results_export import extract_curative_hvdc_results

        assert extract_curative_hvdc_results(_solve(_build(_hvdc())), REF) == []

    def test_describing_the_original_network_zeroes_the_curative_variables(self):
        model = _solve(_cur_build(_cur_hvdc()))
        describe_original_network(model)
        assert all(pyo.value(v) == 0 for v in model.hvdc_cur_up.values())

    def test_the_curative_effect_used_by_criterion_4_is_the_linearised_relief(self):
        model = _solve(_cur_build(_cur_hvdc()))
        assert model.nx_curative_effect_ampere("B1", "C1") == pytest.approx(-30.0, abs=1e-5)
        assert model.nx_curative_effect_ampere("B2", "C1") == pytest.approx(0.1 * 15.0, abs=1e-5)


class TestPreventiveAndCurativeTogether:
    def test_both_blocks_coexist_and_the_objective_is_the_sum_of_the_two_terms(self):
        hvdc = _cur_hvdc(with_preventive=True)
        model = _solve(_cur_build(hvdc, i_b1=120.0))
        pra = pyo.value(model.objective_penalty_term_expressions["hvdc_pra_penalty_cost"])
        cra = pyo.value(model.objective_penalty_term_expressions["hvdc_cra_penalty_cost"])
        assert pra > 0 and pyo.value(model.objective) == pytest.approx(pra + cra, abs=1e-5)
        assert _net(model, "U1") + _net(model, "U2") == pytest.approx(0.0, abs=1e-9)

    def test_two_curative_units_of_one_ei_share_the_bound(self):
        units = [_cur_unit("C1U", "E1", group="GA"), _cur_unit("C2U", "E2", group="GA"),
                 _cur_unit("C3U", "E1", group="GB"), _cur_unit("C4U", "E3", group="GB")]
        limits = {"C1U": (-500.0, 104.0), "C2U": (-500.0, 500.0), "C3U": (-500.0, 104.0), "C4U": (-500.0, 500.0)}
        hvdc = _cur_hvdc(units=units, limits=limits)
        hvdc.original_p_mw["E3"] = hvdc.current_p_mw["E3"] = 10.0
        model = _solve(_cur_build(hvdc, nx=_nx({"C1": 130.0})))
        total_e1 = _cur_net(model, "C1U", "C1") + _cur_net(model, "C3U", "C1")
        assert total_e1 <= 4.0 + 1e-6                                                # 104 - 100, not 4 per unit

class TestSetPointOutsideItsRange:
    """H3.4 in the model: the limits come from resolve_operating_limits, which widens a range that does not hold the CGM
    set point. Without an overload the units stay where they are at no cost, even when the partner could not absorb a
    move (with the unwidened range the hard bound would force a move or make the model infeasible)."""

    @staticmethod
    def _limits(unit, p0, *ranges):
        from data_model import HvdcRange
        from pre_milp import hvdc_units
        return hvdc_units.resolve_operating_limits(unit, p0, None, None, ranges=[HvdcRange(*r) for r in ranges])

    @pytest.mark.parametrize("first_range, expected", [
        ((("up", "absolute", 90.0), ("down", "absolute", -500.0)), (-500.0, 100.0)),       # P0 100 above Pmax_op 90
        ((("up", "absolute", 500.0), ("down", "absolute", 110.0)), (100.0, 500.0)),        # P0 100 below Pmin_op 110
    ])
    def test_preventive_no_overload_no_move_no_cost(self, first_range, expected):
        units = [_unit("U1", "E1"), _unit("U2", "E2")]
        limits = {"U1": self._limits(units[0], 100.0, *first_range),
                  "U2": self._limits(units[1], 50.0, ("upAndDown", "incremental", 5.0))}     # the partner may move 5 MW only
        assert limits["U1"] == expected
        model = _solve(_build(_hvdc(units=units, limits=limits), i_b1=80.0))                 # 80 A < PATL 100 A
        assert _net(model, "U1") == pytest.approx(0.0, abs=1e-9) and _net(model, "U2") == pytest.approx(0.0, abs=1e-9)
        assert pyo.value(model.objective) == pytest.approx(0.0, abs=1e-9)

    @pytest.mark.parametrize("first_range", [
        (("up", "absolute", 90.0), ("down", "absolute", -500.0)),
        (("up", "absolute", 500.0), ("down", "absolute", 110.0)),
    ])
    def test_curative_no_overload_no_move_no_cost(self, first_range):
        units = [_cur_unit("C1U", "E1"), _cur_unit("C2U", "E2")]
        limits = {"C1U": self._limits(units[0], 100.0, *first_range),
                  "C2U": self._limits(units[1], 50.0, ("upAndDown", "incremental", 5.0))}
        model = _solve(_cur_build(_cur_hvdc(units=units, limits=limits), nx=_nx({"C1": 80.0, "C2": 90.0})))
        assert hasattr(model, "hvdc_cur_up")
        assert all(abs(_cur_net(model, u, c)) < 1e-9 for u, c in model.hvdc_cur_pairs)
        assert pyo.value(model.objective) == pytest.approx(0.0, abs=1e-9)


class TestScannedRowWithoutAVariable:
    """A hard scanned N-0 row that no remedial action touches (curative-only HVDC) is a constant: it builds."""

    def _build(self, i_scanned):
        ae = [_ae("B1", 100.0), _ae("S1", 500.0, AEType.SCANNED)]
        lf = {"B1": {1: 80.0, 2: 80.0}, "S1": {1: i_scanned, 2: i_scanned}}
        nx = NxMilpInputs(
            lf_nx={"C1": {"B1": {1: 130.0, 2: 130.0}, "S1": {1: 100.0, 2: 100.0}}}, sensitivity_pst_nx={}, sensitivity_rd_nx={},
            sensitivity_hvdc_nx={"C1": {("B1", "E1"): -2.0}}, penalty_cost_overload_nx_scanned=10000.0,
            penalty_cost_overload_nx_patl=10000.0,
        )
        return build_n0_milp_model(ae, TS, lf, 10000.0, hvdc_inputs=_cur_hvdc(), nx_inputs=nx)

    def test_a_scanned_row_inside_its_limit_builds_and_solves(self):
        model = _solve(self._build(400.0))
        assert pyo.value(model.nx_patl_overload_slack["B1", "C1"]) == pytest.approx(0.0, abs=1e-6)

    def test_a_scanned_row_above_its_nominal_limit_builds_too(self):
        # the effective limit of a scanned element is at least its original loading, so the row stays satisfiable
        model = _solve(self._build(600.0))
        assert pyo.value(model.nx_patl_overload_slack["B1", "C1"]) == pytest.approx(0.0, abs=1e-6)

# ---------------------------------------------------------------------------
# hvdc_cra_availability.csv rows: the reason an RA is unavailable (H10)
# ---------------------------------------------------------------------------

def _rows(model, scope=None, unit=None, branch=None, contingency=None):
    return [
        r for r in model.hvdc_cra_availability_rows
        if (scope is None or r["scope"] == scope) and (unit is None or r["ra_mrid"] == unit)
        and (branch is None or r["branch_mrid"] == branch) and (contingency is None or r["contingency_mrid"] == contingency)
    ]


class TestAvailabilityRows:
    def test_an_available_group_has_rows_without_a_reason(self):
        model = _cur_build(_cur_hvdc())
        assert {r["reason"] for r in model.hvdc_cra_availability_rows} == {""}
        assert all(r["available"] for r in model.hvdc_cra_availability_rows)
        assert len(_rows(model, "branch")) == 2 * 2 and len(_rows(model, "contingency")) == 2 * 2       # units x (branches | contingencies)

    def test_every_row_carries_the_tso_group_and_ei(self):
        for row in _cur_build(_cur_hvdc()).hvdc_cra_availability_rows:
            assert row["tso"] == "TSO-A" and row["group_mrid"] == "GC" and row["ei_mrid"] in ("E1", "E2")

    def test_reaction_time_reason_on_the_branch_and_group_atomicity_for_the_partner(self):
        units = [_cur_unit("C1U", "E1", reaction=5.0), _cur_unit("C2U", "E2", reaction=15.0)]     # TATL of B1: 10 min
        model = _cur_build(_cur_hvdc(units=units))
        slow = _rows(model, "branch", "C2U", "B1")[0]
        assert slow["available"] is False and slow["reason"] == "reaction time above the TATL duration"
        assert slow["reaction_time_minutes"] == 15.0 and slow["tatl_duration_seconds"] == 600
        partner = _rows(model, "branch", "C1U", "B1")[0]
        assert partner["available"] is False
        assert partner["reason"] == "group atomicity: partner C2U has a reaction time above the TATL duration"

    def test_reaction_time_on_every_branch_gives_the_contingency_rows_the_same_reason(self):
        units = [_cur_unit("C1U", "E1", reaction=15.0), _cur_unit("C2U", "E2", reaction=15.0)]
        model = _cur_build(_cur_hvdc(units=units))
        assert {r["reason"] for r in _rows(model, "contingency")} == {"reaction time above the TATL duration on every branch"}
        assert not any(r["available"] for r in _rows(model, "contingency"))

    def test_outage_element_and_the_partner_by_group_atomicity(self):
        model = _cur_build(_cur_hvdc(outage={"C1": {"E2"}}))
        own = _rows(model, "contingency", "C2U", contingency="C1")[0]
        partner = _rows(model, "contingency", "C1U", contingency="C1")[0]
        assert (own["available"], own["reason"]) == (False, "outage element")
        assert (partner["available"], partner["reason"]) == (False, "group atomicity: partner C2U: outage element")
        assert all(r["available"] for r in _rows(model, "contingency", contingency="C2"))

    def test_zero_sensitivity_and_the_partner_by_group_atomicity(self):
        model = _cur_build(_cur_hvdc(zero={"C2": ["E1"]}))
        own = _rows(model, "contingency", "C1U", contingency="C2")[0]
        partner = _rows(model, "contingency", "C2U", contingency="C2")[0]
        assert (own["available"], own["reason"]) == (False, "zero sensitivity")
        assert partner["reason"] == "group atomicity: partner C1U: zero sensitivity"

    def test_contingencies_without_a_link_have_no_row(self):
        units = [_cur_unit("C1U", "E1", linked=["C1"]), _cur_unit("C2U", "E2", linked=["C1"])]
        model = _cur_build(_cur_hvdc(units=units))
        assert {r["contingency_mrid"] for r in _rows(model, "contingency")} == {"C1"}

    def test_a_unit_that_fails_both_rules_reports_the_first_reason_of_the_gate(self):
        model = _cur_build(_cur_hvdc(outage={"C1": {"E1"}}, zero={"C1": ["E1"]}))
        assert _rows(model, "contingency", "C1U", contingency="C1")[0]["reason"] == "outage element"

    def test_an_unavailable_group_still_has_its_rows_when_it_has_no_variables(self):
        model = _cur_build(_cur_hvdc(outage={"C1": {"E1"}, "C2": {"E1"}}))
        assert not hasattr(model, "hvdc_cur_up") and len(_rows(model, "contingency")) == 4

    def test_the_rows_match_the_pairs_of_the_model(self):
        model = _cur_build(_cur_hvdc(outage={"C1": {"E2"}}))
        available = {(r["ra_mrid"], r["contingency_mrid"]) for r in _rows(model, "contingency") if r["available"]}
        assert available == set(model.hvdc_cur_pairs)

    def test_no_curative_units_no_rows(self):
        model = _build(_hvdc())
        assert not hasattr(model, "hvdc_cra_availability_rows")


class TestCsvWriters:
    def test_the_availability_file_has_the_columns_and_floats(self, tmp_path):
        from post_milp import n0_results_export as export

        model = _cur_build(_cur_hvdc(units=[_cur_unit("C1U", "E1", reaction=5.0), _cur_unit("C2U", "E2", reaction=15.0)]))
        path = tmp_path / "hvdc_cra_availability.csv"
        export.write_hvdc_cra_availability_csv(model.hvdc_cra_availability_rows, path)
        text = path.read_bytes().decode(TEXT_ENCODING)
        assert text.count("\r\n") == text.count("\n")      # csv module: CRLF record terminators, one per line
        lines = text.splitlines()
        assert lines[0] == ",".join(export.HVDC_AVAILABILITY_COLUMNS) and "tso" in lines[0].split(",")
        assert any(",5.0," in line for line in lines[1:]) and any("group atomicity" in line for line in lines[1:])

    def test_the_result_files_have_a_tso_column_and_float_set_points(self, tmp_path):
        from post_milp import n0_results_export as export
        from post_milp.n0_results_export import AcVerificationStatus

        model = _solve(_cur_build(_cur_hvdc(with_preventive=True), i_b1=120.0))
        status = next(iter(AcVerificationStatus))
        export.write_hvdc_results_csv(export.extract_hvdc_results(model, REF), tmp_path / "p.csv", TS, status, "")
        export.write_curative_hvdc_results_csv(export.extract_curative_hvdc_results(model, REF), tmp_path / "c.csv", TS, status, "")
        import csv
        for name in ("p.csv", "c.csv"):
            with open(tmp_path / name, encoding=TEXT_ENCODING, newline="") as handle:
                rows = list(csv.DictReader(handle))
            assert rows and "tso" in rows[0] and rows[0]["tso"] == "TSO-A"
            for column in ("original_p_mw", "result_p_mw", "change_mw") if name == "p.csv" else ("p_after_curative_mw", "curative_change_mw"):
                assert "." in rows[0][column] or "e" in rows[0][column].lower()
                float(rows[0][column])

    def test_a_header_only_curative_file_without_pairs(self, tmp_path):
        from post_milp import n0_results_export as export
        from post_milp.n0_results_export import AcVerificationStatus

        export.write_curative_hvdc_results_csv([], tmp_path / "c.csv", TS, next(iter(AcVerificationStatus)), "")
        assert len((tmp_path / "c.csv").read_text(encoding=TEXT_ENCODING).splitlines()) == 1


# ---------------------------------------------------------------------------
# N-X exports and criterion 4 read the HVDC terms
# ---------------------------------------------------------------------------

class TestExportsAndCriterion4:
    def test_the_export_effect_has_the_preventive_term(self):
        from post_milp.nx_results_export import _linearised_pst_rd_effect

        model = _solve(_cur_build(_cur_hvdc(with_preventive=True), i_b1=120.0, nx=_nx({"C1": 100.0})))
        change = pyo.value(model.hvdc_change["U1"])
        assert change == pytest.approx(10.0, abs=1e-6)
        pra = _linearised_pst_rd_effect(model, "B1", "C1", {}, {}, {}, include_curative=False)
        assert pra == pytest.approx(-2.0 * change, abs=1e-6)
        assert model.nx_hvdc_preventive_effect_ampere("B1", "C1") == pytest.approx(pra, abs=1e-9)

    def test_the_export_effect_adds_the_curative_term_only_with_include_curative(self):
        from post_milp.nx_results_export import _linearised_pst_rd_effect

        model = _solve(_cur_build(_cur_hvdc(with_preventive=True)))
        pra = _linearised_pst_rd_effect(model, "B1", "C1", {}, {}, {}, include_curative=False)
        pra_cra = _linearised_pst_rd_effect(model, "B1", "C1", {}, {}, {}, include_curative=True)
        assert pra_cra - pra == pytest.approx(model.nx_curative_effect_ampere("B1", "C1"), abs=1e-9)
        assert pra_cra - pra == pytest.approx(-2.0 * _cur_net(model, "C1U", "C1"), abs=1e-6)

    def test_a_model_without_hvdc_has_no_hvdc_term(self):
        from post_milp.nx_results_export import _linearised_pst_rd_effect

        class Bare:
            pass

        assert _linearised_pst_rd_effect(Bare(), "B1", "C1", {}, {}, {}, include_curative=True) == 0.0

    def test_the_scanned_export_has_the_hvdc_terms(self, tmp_path):
        import csv
        from post_milp.nx_results_export import export_nx_scanned_elements_csv

        ae = [_ae("B1", 100.0), _ae("S1", 500.0, AEType.SCANNED)]
        lf = {"B1": {1: 80.0, 2: 80.0}, "S1": {1: 400.0, 2: 400.0}}
        lf_nx = {"C1": {"B1": {1: 130.0, 2: 130.0}, "S1": {1: 520.0, 2: 520.0}}}
        nx = NxMilpInputs(
            lf_nx=lf_nx, sensitivity_pst_nx={}, sensitivity_rd_nx={}, sensitivity_hvdc_nx={"C1": {("S1", "E1"): -2.0, ("B1", "E1"): -2.0}},
            penalty_cost_overload_nx_scanned=10000.0, penalty_cost_overload_nx_patl=10000.0,
        )
        hv = _cur_hvdc(with_preventive=True)
        hv.sensitivity_hvdc_n0[("S1", "E1")] = -2.0
        model = _solve(build_n0_milp_model(ae, TS, lf, 10000.0, hvdc_inputs=hv, nx_inputs=nx))
        path = tmp_path / "scanned.csv"
        export_nx_scanned_elements_csv(model, ae, [], lf_nx, {}, {}, {}, {"S1": 600.0, "B1": 100.0}, TS, path)
        with open(path, encoding=TEXT_ENCODING, newline="") as handle:
            rows = list(csv.DictReader(handle))
        assert len(rows) == 1
        expected = (520.0 + model.nx_hvdc_preventive_effect_ampere("S1", "C1") + model.nx_curative_effect_ampere("S1", "C1")) / 1000.0
        assert float(rows[0]["loading_after_model_ka"]) == pytest.approx(expected, abs=1e-9)

    def test_criterion_4_sees_the_curative_hvdc_effect(self):
        from milp.ac_convergence_loop import element_overloads_ampere

        units = [_cur_unit("C1U", "E1", linked=["C1"]), _cur_unit("C2U", "E2", linked=["C1"])]
        model = _solve(_cur_build(_cur_hvdc(units=units), nx=_nx({"C1": 130.0, "C2": 130.0})))
        monitoring = model.overload_monitoring
        effect = {pair: model.nx_curative_effect_ampere(*pair) for pair in monitoring["nx_patl"]}
        lf_nx = {c: {"B1": {1: 130.0, 2: 130.0}, "B2": {1: 300.0, 2: 300.0}} for c in ("C1", "C2")}
        lf_n0 = {"B1": {1: 80.0, 2: 80.0}, "B2": {1: 300.0, 2: 300.0}}
        overloads = element_overloads_ampere(monitoring, lf_n0, lf_nx, effect)
        assert overloads[("nx_patl", "B1", "C1")] == pytest.approx(0.0, abs=1e-6)          # relieved by the curative term
        assert overloads[("nx_patl", "B1", "C2")] == pytest.approx(30.0, abs=1e-6)         # not linked: untouched
        without = element_overloads_ampere(monitoring, lf_n0, lf_nx, {})
        assert without[("nx_patl", "B1", "C1")] == pytest.approx(30.0, abs=1e-6)