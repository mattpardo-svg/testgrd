"""tests/test_rao_frozen_imports.py — the frozen code interface: these modules and names
must stay importable under these module paths (the GUI, src/rao_pages, imports some of
them), and the entry point, data_model.py and the config files must stay where they are."""
import importlib
import sys
from pathlib import Path

import pytest

REPO_ROOT = Path(__file__).resolve().parents[1]
SRC_RAO = REPO_ROOT / "src" / "rao"
for _p in (SRC_RAO, REPO_ROOT):
    if str(_p) not in sys.path:
        sys.path.insert(0, str(_p))

FROZEN_NAMES = {
    # GUI (src/rao_pages/_gui_common.py)
    "pre_milp.ncp_loader": ["extract_ncp_zip", "classify_extracted_ncp_files"],
    "pre_milp.tso_name_resolver": ["build_tso_name_map"],
    # further frozen names
    "data_model": ["AcVerificationStatus", "AssessedElement", "PST", "PowerBid", "RDUnit", "RAKind"],
    "pre_milp.cgmes_loader": [
        "load_cgm", "run_initial_loadflow", "extract_equipment_dicts", "build_lf_initial",
        "build_cgm_static_patl", "build_branch_mrid_to_name", "build_equipment_mrid_to_type",
        "build_pst_degrees_per_tap",
    ],
    "pre_milp.ncp_parser": [
        "parse_assessed_elements", "parse_contingencies", "parse_psts", "parse_rd_units", "parse_ra_groups",
        "build_current_limit_side_map", "build_tap_changer_to_transformer_map", "build_pst_tap_bounds_curative",
    ],
    "pre_milp.glsk_resolver": ["resolve_glsk"],
    "pre_milp.n0_sensitivity": [
        "compute_sensitivity_pst_n0", "compute_sensitivity_rd_n0", "prune_sensitivity_by_threshold",
    ],
    "pre_milp.nx_security_analysis": ["compute_lf_nx", "compute_tatl_data", "_get_must_study_contingencies"],
    "pre_milp.nx_sensitivity": ["compute_sensitivity_pst_nx", "compute_sensitivity_rd_nx"],
    "pre_milp.cra_preprocessing": ["compute_pst_cra_availability"],
    "pre_milp.pst_bounds": ["build_pst_tap_bounds"],
    "pre_milp.pst_groups": ["build_pst_group_equality_pairs"],
    "milp.milp_builder": ["build_n0_milp_model", "PstMilpInputs", "RdMilpInputs", "NxMilpInputs"],
    "milp.post_ra_congestion_check": ["find_new_congested_pairs"],
    "post_milp.n0_results_export": [
        "extract_lead_time_results", "extract_ra_count_results", "extract_ra_group_results",
        "extract_rd_results", "extract_results_generating_units", "extract_results_summary",
    ],
    "post_milp.nx_results_export": ["export_nx_loadings_csv", "export_contingency_status_csv"],
}


@pytest.mark.parametrize("module_path", sorted(FROZEN_NAMES))
def test_frozen_module_exposes_the_frozen_names(module_path):
    module = importlib.import_module(module_path)
    missing = [name for name in FROZEN_NAMES[module_path] if not hasattr(module, name)]
    assert missing == [], f"{module_path} lost {missing}"


def test_entry_point_data_model_and_config_files_keep_their_paths():
    assert (SRC_RAO / "run_pipeline.py").is_file()
    assert (SRC_RAO / "data_model.py").is_file()  # run_pipeline._find_repo_root looks for this file
    for name in ("rao_config.yaml", "rao_config.default.yaml",
                 "load_flow_config.yaml", "load_flow_config.default.yaml"):
        assert (SRC_RAO / "config" / name).is_file(), name
