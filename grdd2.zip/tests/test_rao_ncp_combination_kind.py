"""ContingencyWithRemedialAction.combinationConstraintKind (decision 95): included keeps the link, excluded
removes the RA for that contingency, considered is warned about (OPEN-3) and still read as a link."""
import logging

import pytest

from data_model import RAKind, effective_linked_contingencies
from helpers import TATL, _RA_FOOTER, _RA_HEADER, _make_pst
from pre_milp import ct_units, ncp_parser
from pre_milp.cra_preprocessing import compute_pst_cra_availability
from text_encoding import TEXT_ENCODING

KIND = "https://cim4.eu/ns/nc#ElementCombinationConstraintKind."


def _link(link_id, ra, contingency, kind):
    kind_xml = f'<nc:ContingencyWithRemedialAction.combinationConstraintKind rdf:resource="{KIND}{kind}"/>' if kind else ""
    return f"""
    <nc:ContingencyWithRemedialAction rdf:ID="_{link_id}">
      <nc:ContingencyWithRemedialAction.RemedialAction rdf:resource="#_{ra}"/>
      <nc:ContingencyWithRemedialAction.Contingency rdf:resource="#_{contingency}"/>
      {kind_xml}
    </nc:ContingencyWithRemedialAction>"""


_COMMON = """
      <cim:IdentifiedObject.mRID>{mrid}</cim:IdentifiedObject.mRID>
      <nc:RemedialAction.normalAvailable>true</nc:RemedialAction.normalAvailable>
      <nc:RemedialAction.kind rdf:resource="https://cim4.eu/ns/nc#RemedialActionKind.curative"/>
      <nc:RemedialAction.penaltyFactor>1.0</nc:RemedialAction.penaltyFactor>
      <nc:RemedialAction.timeToImplement>PT1M</nc:RemedialAction.timeToImplement>"""

_RD = f"""
    <nc:GridStateAlterationRemedialAction rdf:ID="_RA1">{_COMMON.format(mrid="RA1")}
    </nc:GridStateAlterationRemedialAction>
    <nc:RotatingMachineAction rdf:ID="_ACT1">
      <nc:GridStateAlteration.GridStateAlterationRemedialAction rdf:resource="#_RA1"/>
      <nc:RotatingMachineAction.RotatingMachine rdf:resource="#_M1"/>
    </nc:RotatingMachineAction>"""

_HVDC = f"""
    <nc:GridStateAlterationRemedialAction rdf:ID="_RA1">{_COMMON.format(mrid="RA1")}
    </nc:GridStateAlterationRemedialAction>
    <nc:EquivalentInjectionAction rdf:ID="_ACT1">
      <nc:GridStateAlteration.GridStateAlterationRemedialAction rdf:resource="#_RA1"/>
      <nc:EquivalentInjectionAction.EquivalentInjection rdf:resource="#_EI1"/>
    </nc:EquivalentInjectionAction>"""

_PST = f"""
    <nc:GridStateAlterationRemedialAction rdf:ID="_RA1">{_COMMON.format(mrid="RA1")}
    </nc:GridStateAlterationRemedialAction>
    <nc:TapPositionAction rdf:ID="_ACT1">
      <nc:GridStateAlteration.GridStateAlterationRemedialAction rdf:resource="#_RA1"/>
      <nc:TapPositionAction.TapChanger rdf:resource="#_TC1"/>
      <nc:GridStateAlteration.timePerStage>PT1M</nc:GridStateAlteration.timePerStage>
    </nc:TapPositionAction>"""

_CT = f"""
    <nc:CountertradeRemedialAction rdf:ID="_RA1">{_COMMON.format(mrid="RA1")}
      <nc:PowerRemedialAction.BiddingZone rdf:resource="#_ZONE"/>
    </nc:CountertradeRemedialAction>"""


def _write(tmp_path, body):
    path = tmp_path / "T_RA.xml"
    path.write_text(_RA_HEADER + body + _RA_FOOTER, encoding=TEXT_ENCODING)
    return path


def _parse(kind_name, tmp_path, links):
    body = {"rd": _RD, "hvdc": _HVDC, "pst": _PST, "ct": _CT}[kind_name] + "".join(links)
    path = _write(tmp_path, body)
    if kind_name == "rd":
        units, _ = ncp_parser.parse_rd_units(path, None, "T", ["1030Z"], {"M1": {"name": "M1", "target_p": 10.0, "max_p": 100.0, "min_p": 0.0}})
        return units[0]
    if kind_name == "hvdc":
        return ncp_parser.parse_hvdc_units(path, "T")[0]
    if kind_name == "pst":
        return ncp_parser.parse_psts(path, "T", {"TR1": {"low_step": -10, "high_step": 10, "r0": 0}}, {"TC1": "TR1"})[0]
    return ct_units.parse_ct_remedial_actions(path, None, "T", ["1030Z"])[0][0]


def _warnings(caplog, *words):
    return [r.getMessage() for r in caplog.records if r.levelno >= logging.WARNING and all(w in r.getMessage() for w in words)]


ALL_TYPES = ["rd", "hvdc", "pst", "ct"]


@pytest.mark.parametrize("ra_type", ALL_TYPES)
def test_excluded_links_are_kept_apart_from_the_included_ones(tmp_path, caplog, ra_type):
    links = [_link("L1", "RA1", "C1", "included"), _link("L2", "RA1", "C2", "excluded")]
    with caplog.at_level(logging.WARNING):
        unit = _parse(ra_type, tmp_path, links)
    assert unit.linked_contingency_mrids == ["C1"] and unit.excluded_contingency_mrids == ["C2"]
    assert _warnings(caplog, "combinationConstraintKind") == []


@pytest.mark.parametrize("ra_type", ALL_TYPES)
def test_a_considered_link_is_read_as_a_link_and_warned_about(tmp_path, caplog, ra_type):
    with caplog.at_level(logging.WARNING):
        unit = _parse(ra_type, tmp_path, [_link("L1", "RA1", "C1", "considered")])
    assert unit.linked_contingency_mrids == ["C1"] and unit.excluded_contingency_mrids == []
    messages = _warnings(caplog, "considered")
    assert len(messages) == 1 and "as included" in messages[0] and "T_RA.xml" in messages[0]


@pytest.mark.parametrize("ra_type", ["rd", "pst"])
def test_a_link_without_a_kind_or_with_an_unknown_kind_is_included_with_a_warning(tmp_path, caplog, ra_type):
    links = [_link("L1", "RA1", "C1", None), _link("L2", "RA1", "C2", "sometimes")]
    with caplog.at_level(logging.WARNING):
        unit = _parse(ra_type, tmp_path, links)
    assert unit.linked_contingency_mrids == ["C1", "C2"] and unit.excluded_contingency_mrids == []
    assert len(_warnings(caplog, "combinationConstraintKind")) == 2          # one for the missing, one for the unknown kind


def test_the_kind_is_matched_by_its_last_word_in_any_namespace(tmp_path):
    link = _link("L1", "RA1", "C1", "excluded").replace(KIND, "https://example.org/other#Kind.")
    unit = _parse("rd", tmp_path, [link])
    assert unit.excluded_contingency_mrids == ["C1"] and unit.linked_contingency_mrids == []


def test_the_warning_is_given_once_per_file_for_all_parsers(tmp_path, caplog):
    path = _write(tmp_path, _RD + _link("L1", "RA1", "C1", "considered"))
    gens = {"M1": {"name": "M1", "target_p": 10.0, "max_p": 100.0, "min_p": 0.0}}
    with caplog.at_level(logging.WARNING):
        ncp_parser.parse_rd_units(path, None, "T", ["1030Z"], gens)
        ncp_parser.parse_rd_units(path, None, "T", ["1030Z"], gens)
    assert len(_warnings(caplog, "considered")) == 1


@pytest.mark.parametrize("linked, excluded, universe, expected", [
    ([], [], ["C1", "C2", "C3"], ["C1", "C2", "C3"]),             # no link: every contingency (as before)
    (["C2"], [], ["C1", "C2", "C3"], ["C2"]),                      # included only: those
    ([], ["C2"], ["C1", "C2", "C3"], ["C1", "C3"]),                # excluded only: all but those
    (["C1", "C2"], ["C2"], ["C1", "C2", "C3"], ["C1"]),            # both: included minus excluded
    (["C2"], ["C2"], ["C1", "C2", "C3"], []),                      # the only link is excluded: none
])
def test_effective_contingencies_of_a_remedial_action(linked, excluded, universe, expected):
    assert effective_linked_contingencies(linked, excluded, universe) == expected


def test_a_curative_pst_is_not_available_in_an_excluded_contingency():
    pst = _make_pst("P1", RAKind.CURATIVE)
    pst.reaction_time_minutes, pst.time_per_stage_minutes = 1.0, 1.0
    pst.linked_contingency_mrids, pst.excluded_contingency_mrids = ["CO1", "CO2"], ["CO2"]
    availability = compute_pst_cra_availability([pst], TATL)
    assert {co for (_p, _b, co) in availability} == {"CO1"}


def test_availability_schedules_and_disabled_assessed_elements_are_warned_about_and_not_read(tmp_path, caplog):
    """Decision 96: availability schedules of a remedial action and a disabled assessed element are not read;
    one warning per SIS file says so (WP9, the reader for a disabled element, needs an owner decision)."""
    body = """
    <nc:GenericAvailableSchedule rdf:ID="_AV1">
      <nc:GenericAvailableSchedule.RemedialAction rdf:resource="#_RA1"/>
    </nc:GenericAvailableSchedule>
    <nc:AvailabilityTimePoint rdf:ID="_AVP1">
      <nc:AvailabilityTimePoint.GenericAvailabilitySchedule rdf:resource="#_AV1"/>
      <nc:AvailabilityTimePoint.atTime>2022-06-15T10:30:00Z</nc:AvailabilityTimePoint.atTime>
      <nc:AvailabilityTimePoint.available>false</nc:AvailabilityTimePoint.available>
    </nc:AvailabilityTimePoint>
    <nc:AssessedElementTimePoint rdf:ID="_AE1">
      <nc:AssessedElementTimePoint.enabled>false</nc:AssessedElementTimePoint.enabled>
    </nc:AssessedElementTimePoint>
    <nc:AssessedElementTimePoint rdf:ID="_AE2">
      <nc:AssessedElementTimePoint.enabled>true</nc:AssessedElementTimePoint.enabled>
    </nc:AssessedElementTimePoint>"""
    path = tmp_path / "Sched_SIS.xml"
    path.write_text(_RA_HEADER + body + _RA_FOOTER, encoding=TEXT_ENCODING)
    with caplog.at_level(logging.WARNING):
        ncp_parser.warn_unsupported_sis_content(path, "T")
    availability = _warnings(caplog, "availability", "not read")
    disabled = _warnings(caplog, "enabled", "not read")
    assert len(availability) == 1 and "1 GenericAvailableSchedule" in availability[0] and "Sched_SIS.xml" in availability[0]
    assert len(disabled) == 1 and "1 AssessedElementTimePoint" in disabled[0] and "monitored" in disabled[0]
