"""
conftest.py — the pytest fixtures shared by every test file (the shared builders are in
helpers.py). Adds src/rao and the repo root to sys.path, so the flat imports
(data_model, pre_milp, milp, post_milp) work without installing the package.
"""
import sys
from pathlib import Path

import pytest

# Repo root is two levels up from this file (tests/conftest.py → repo root)
from helpers import REPO_ROOT, _FIXTURES, _MOCK_NX_CGM_ZIP, _MOCK_NX_NCP_ZIP, build_fixture_input_folder, run_pipeline_on_fixture_inputs  # noqa: E402
SRC_ROOT  = REPO_ROOT / "src" / "rao"

# Insert src/ at front so local modules take priority
if str(SRC_ROOT) not in sys.path:
    sys.path.insert(0, str(SRC_ROOT))

# REPO_ROOT on sys.path too, so "from src.X import ..." style imports also resolve
if str(REPO_ROOT) not in sys.path:
    sys.path.insert(0, str(REPO_ROOT))

# ---------------------------------------------------------------------------
# real_input_folder — an input/ folder (cgm.zip + ncp.zip) built from the fixture zips
# (helpers.build_fixture_input_folder), for tests that call run_pipeline.main() on the
# ReliCapGrid case (main() reads only input/).
# ---------------------------------------------------------------------------

@pytest.fixture
def real_input_folder(tmp_path):
    """A populated input/ folder (cgm.zip + ncp.zip) of the ReliCapGrid case, built from
    tests/fixtures, for tests that run run_pipeline.main()."""
    return build_fixture_input_folder(tmp_path / "input")

# ---------------------------------------------------------------------------
# mock_nx_pipeline_run — ONE real end-to-end pipeline run on the mock N-X
# case (tests/fixtures/CGM_package.zip + NCP_mock_standard.zip,
# N-X analysis ON), shared by every test that inspects the files the
# pipeline writes. Session-scoped because a run takes ~20 s.
#
# The run is instrumented, not changed: resolve_glsk is wrapped so tests can
# compare the file with what each TSO actually resolved.
# ---------------------------------------------------------------------------

import importlib  # noqa: E402
import logging  # noqa: E402
import shutil  # noqa: E402
from types import SimpleNamespace  # noqa: E402





@pytest.fixture(scope="session")
def mock_nx_pipeline_run(tmp_path_factory):
    return run_pipeline_on_fixture_inputs(
        tmp_path_factory.mktemp("mock_nx_run"), _MOCK_NX_NCP_ZIP, enable_nx_analysis=True,
    )
