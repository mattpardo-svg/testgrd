"""The countertrade RAs and bids that the shipped standard-form mock (P) carries (mock_data/countertrade_p.py): 8 RAs
(a preventive and a curative one per region), Espheim with a supply function of three bids per direction, the curative
RAs linked to every contingency of their region, standard form only; and what a run with countertrade does with them."""
import csv
import re
import zipfile

import pytest
from rdflib import Graph, Namespace, RDF

import helpers
from mock_data import countertrade_p, standard

NC = Namespace("https://cim4.eu/ns/nc#")
TSOS = ("Belgovia", "Espheim", "Galia", "Svedala")
CONTINGENCIES = {"Belgovia": 2, "Espheim": 5, "Galia": 1, "Svedala": 8}
EXPECTED_BIDS = {
    "Belgovia": [(100, 50)], "Espheim": [(100, 40), (100, 70), (100, 110)], "Galia": [(100, 50)], "Svedala": [(100, 60)],
}


def _graph(zip_path, name):
    graph = Graph()
    with zipfile.ZipFile(zip_path) as zf:
        graph.parse(data=zf.read(name), format="xml")
    return graph


def _name(graph, subject):
    return str(graph.value(subject, Namespace("https://cim.ucaiug.io/ns#")["IdentifiedObject.name"]))


def _ct_ras(zip_path, tso):
    graph = _graph(zip_path, f"{tso}_RA.xml")
    return graph, sorted(graph.subjects(RDF.type, NC.CountertradeRemedialAction), key=lambda s: _name(graph, s))


def test_rao_p_has_one_preventive_and_one_curative_countertrade_ra_per_region_and_the_base_has_none():
    total = 0
    for tso in TSOS:
        graph, ras = _ct_ras(helpers._MOCK_NX_NCP_ZIP, tso)
        kinds = sorted(str(graph.value(ra, NC["RemedialAction.kind"])).rsplit(".", 1)[-1] for ra in ras)
        assert kinds == ["curative", "preventive"], tso
        assert sorted(_name(graph, ra) for ra in ras) == [f"CRA_CT_{tso.upper()}", f"PRA_CT_{tso.upper()}"]
        assert _ct_ras(standard.base_zip(), tso)[1] == []
        total += len(ras)
    assert total == 8


def _bids(zip_path, tso, ra_name):
    graph = _graph(zip_path, f"{tso}_SIS.xml")
    ra = next(s for s in _graph(zip_path, f"{tso}_RA.xml").subjects(RDF.type, NC.CountertradeRemedialAction)
              if _name(_graph(zip_path, f"{tso}_RA.xml"), s) == ra_name)
    found = []
    for bid in graph.subjects(NC["PowerBidSchedule.PowerRemedialAction"], ra):
        direction = str(graph.value(bid, NC["PowerBidSchedule.direction"])).rsplit(".", 1)[-1]
        points = list(graph.subjects(NC["PowerBidScheduleTimePoint.PowerBidSchedule"], bid))
        assert len(points) == 1
        p = float(graph.value(points[0], NC["PowerBidScheduleTimePoint.p"]))
        price = float(graph.value(points[0], NC["PowerBidScheduleTimePoint.price"]))
        found.append((direction, p, price))
    return sorted(found, key=lambda item: (item[0], item[2]))


@pytest.mark.parametrize("tso", TSOS)
@pytest.mark.parametrize("prefix", ["PRA", "CRA"])
def test_rao_p_countertrade_bids_have_the_sizes_prices_and_signs_of_the_design(tso, prefix):
    """Espheim: 3 up and 3 down bids of 100 MW at 40 / 70 / 110 EUR/MW per RA; the others one up and one down bid;
    up p > 0, down p < 0."""
    found = _bids(helpers._MOCK_NX_NCP_ZIP, tso, f"{prefix}_CT_{tso.upper()}")
    expected = sorted([("up", float(v), float(c)) for v, c in EXPECTED_BIDS[tso]]
                      + [("down", -float(v), float(c)) for v, c in EXPECTED_BIDS[tso]], key=lambda item: (item[0], item[2]))
    assert found == expected
    assert len(found) == (6 if tso == "Espheim" else 2)


def test_rao_p_curative_countertrade_ras_are_linked_to_all_contingencies_of_their_region():
    for tso in TSOS:
        with zipfile.ZipFile(helpers._MOCK_NX_NCP_ZIP) as zf:
            region = countertrade_p.contingencies_of(zf.read(f"{tso}_CO.xml").decode("utf-8"))
        assert len(region) == CONTINGENCIES[tso]
        graph, ras = _ct_ras(helpers._MOCK_NX_NCP_ZIP, tso)
        for ra in ras:
            links = list(graph.subjects(NC["ContingencyWithRemedialAction.RemedialAction"], ra))
            curative = str(graph.value(ra, NC["RemedialAction.kind"])).endswith("curative")
            if not curative:
                assert links == []
                continue
            linked = sorted(str(graph.value(link, NC["ContingencyWithRemedialAction.Contingency"])).rsplit("#_", 1)[-1] for link in links)
            assert linked == sorted(region)
            assert all(str(graph.value(link, NC["ContingencyWithRemedialAction.combinationConstraintKind"])).endswith("included") for link in links)


def test_rao_p_countertrade_data_is_standard_form_only():
    """No old-form or non-standard attribute: no gLSKStrategy / powerShiftKey / method on RA or bid, no bid attribute outside
    the profile, the direction literal of MarketRegulationDirectionKind, interpolationKind on every bid, penaltyFactor and
    bidding zone on every RA."""
    with zipfile.ZipFile(helpers._MOCK_NX_NCP_ZIP) as zf:
        for tso in TSOS:
            for name in (f"{tso}_RA.xml", f"{tso}_SIS.xml"):
                text = zf.read(name).decode("utf-8")
                for old in ("gLSKStrategy", "powerShiftKey", "ShiftMethodKind", "minEnergyBid", "maxEnergyBid", "stepSizeCTRD", "BidDirectionKind"):
                    assert old not in text, (name, old)
    for tso in TSOS:
        graph, ras = _ct_ras(helpers._MOCK_NX_NCP_ZIP, tso)
        for ra in ras:
            assert graph.value(ra, NC["RemedialAction.penaltyFactor"]) is not None
            assert graph.value(ra, NC["PowerRemedialAction.BiddingZone"]) is not None
        sis = _graph(helpers._MOCK_NX_NCP_ZIP, f"{tso}_SIS.xml")
        ct_ra_ids = set(ras)
        for bid in sis.subjects(RDF.type, NC.PowerBidSchedule):
            if sis.value(bid, NC["PowerBidSchedule.PowerRemedialAction"]) in ct_ra_ids:
                assert "MarketRegulationDirectionKind" in str(sis.value(bid, NC["PowerBidSchedule.direction"]))
                assert sis.value(bid, NC["BaseTimeSeries.interpolationKind"]) is not None


# ---------------------------------------------------------------------------
# a run with countertrade on P
# ---------------------------------------------------------------------------

@pytest.fixture(scope="module")
def run(tmp_path_factory):
    work = tmp_path_factory.mktemp("p_countertrade")
    result = helpers.run_pipeline_on_fixture_inputs(
        work, helpers._MOCK_NX_NCP_ZIP, enable_nx_analysis=True, ra_types=("pst", "rd", "countertrade"), calculation_mode="ac_iterative")
    return result.output_dir


def _rows(out, name):
    with open(out / name, newline="", encoding="utf-8") as handle:
        return list(csv.DictReader(handle))


def test_rao_p_countertrade_preventive_bids_are_used_cheapest_first(run):
    """In a run with pst, rd and countertrade the Espheim preventive RA is used cheapest bid first: per direction a bid is used
    only when every cheaper bid is used up (down: the 40 EUR/MW bid is full, the 70 EUR/MW bid partly, the 110 EUR/MW bid not)."""
    rows = [r for r in _rows(run, "results_countertrade.csv") if r["tso"] == "TSO-Espheim"]
    assert len(rows) == 6
    used_anything = False
    for direction in ("up", "down"):
        bids = sorted((float(r["price_eur_mw"]), float(r["volume_mw"])) for r in rows if r["direction"] == direction)
        assert [price for price, _ in bids] == [40.0, 70.0, 110.0]
        for index, (_price, volume) in enumerate(bids):
            if volume > 1e-6:
                used_anything = True
                assert all(earlier == pytest.approx(100.0, abs=1e-6) for _p, earlier in bids[:index]), (direction, bids)
    assert used_anything
    down = sorted((float(r["price_eur_mw"]), float(r["volume_mw"])) for r in rows if r["direction"] == "down")
    assert down[0][1] == pytest.approx(100.0, abs=1e-6) and 1e-6 < down[1][1] < 100.0 - 1e-6 and down[2][1] == pytest.approx(0.0, abs=1e-6)


def test_rao_p_a_curative_countertrade_ra_is_activated(run):
    """The curative countertrade RAs are not only read: in this run at least one is used (Svedala down, up to the
    largest volume over its contingencies), it is balanced inside the contingency by the other curative bids acting there."""
    rows = _rows(run, "results_curative_countertrade.csv")
    assert len(rows) == 2 * 2 + 6 * 5 + 2 * 1 + 2 * 8      # bids x contingencies: Belgovia, Espheim, Galia, Svedala
    active = [r for r in rows if float(r["curative_volume_mw"]) > 1e-6]
    assert active
    assert {r["tso"] for r in active} >= {"TSO-Svedala"}


def test_rao_p_countertrade_run_log_has_no_deprecated_form_and_one_default_strategy_warning_per_ra(run):
    text = (run / "run_log.txt").read_text(encoding="utf-8", errors="replace")
    for word in ("deprecated", "sign of p disagrees", "no BaseTimeSeries.interpolationKind"):
        assert word not in text, word
    assert len(re.findall(r"countertrade RA \S+ \(\S+\) has no strategy", text)) == 8
    assert "no net movement" not in text
