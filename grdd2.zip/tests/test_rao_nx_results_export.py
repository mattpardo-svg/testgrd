"""tests/test_rao_nx_results_export.py - tests for nx_results_export.py.

Sections: the N-X loadings and contingency status files, the scanned-element results file, and the contingency status reasons.
"""

import csv
import sys
import pyomo.environ as pyo
import pytest
import pandas as pd

from pathlib import Path
from data_model import AEType, AssessedElement, Contingency, ContingencyType, PST, RAKind, RDUnit
from milp.milp_builder import NxMilpInputs, PstMilpInputs, build_n0_milp_model
from post_milp.nx_results_export import (
    export_nx_loadings_csv,
    export_contingency_status_csv,
    export_nx_scanned_elements_csv,
)
from helpers import (
    _make_ae_r39,
    _make_contingency_r39,
    _make_pst_inputs_r39,
    _solve,
    _make_ae_nx_filters as _make_ae,
    _make_contingency,
    _make_pst_nx_filters as _make_pst,
    _make_pst as _make_pst_of_kind,
)
from text_encoding import TEXT_ENCODING  # noqa: E402

REPO_SRC = Path(__file__).resolve().parents[1] / "src" / "rao"


class TestExportNxLoadingsCsv:
    def test_acceptance_criteria_overload_resolved_by_pra(self, tmp_path):
        """A contingency overload resolved by a PRA: loading_pct_nx_post_pra <= 100% for that
        branch/contingency and slack_patl == 0.0."""
        ae_list = [_make_ae_r39("BRANCH1", patl_ka=1.0)]
        co_list = [_make_contingency_r39("CO1", "Contingency One", ["eq-1"])]
        pst_inputs = _make_pst_inputs_r39(sensitivity_n0=0.0, degrees_per_tap=1.0)
        nx_inputs = NxMilpInputs(
            lf_nx={"CO1": {"BRANCH1": {1: 1050.0}}},  # 5% overload
            sensitivity_pst_nx={"CO1": {("BRANCH1", "PST1"): -10.0}},
            sensitivity_rd_nx={},
            penalty_cost_overload_nx_patl=1_000_000.0,
        )

        model = build_n0_milp_model(
            ae_list, "1030Z", lf_initial={"BRANCH1": {1: 500.0}},
            penalty_cost_overload_n0=1_000_000.0, pst_inputs=pst_inputs, nx_inputs=nx_inputs,
        )
        model = _solve(model)

        output_path = tmp_path / "results_nx_loadings.csv"
        export_nx_loadings_csv(
            model, ae_list, co_list,
            lf_nx_initial=nx_inputs.lf_nx,
            lf_initial={"BRANCH1": {1: 500.0}},
            sensitivity_pst_nx=nx_inputs.sensitivity_pst_nx,
            sensitivity_rd_nx={},
            pst_degrees_per_tap=pst_inputs.pst_degrees_per_tap,
            tatl_data={},
            timestamp="1030Z",
            output_path=output_path,
        )

        rows = list(csv.DictReader(output_path.open(encoding=TEXT_ENCODING)))
        assert len(rows) == 1
        row = rows[0]
        assert row["contingency_mrid"] == "CO1"
        assert row["contingency_name"] == "Contingency One"
        assert row["branch_mrid"] == "BRANCH1"
        assert float(row["loading_pct_nx_post_pra"]) <= 100.0 + 1e-6
        assert float(row["slack_patl"]) == pytest.approx(0.0, abs=1e-6)

    def test_columns_match_spec_exactly(self, tmp_path):
        ae_list = [_make_ae_r39("BRANCH1")]
        co_list = [_make_contingency_r39("CO1", "CO One", ["eq-1"])]
        nx_inputs = NxMilpInputs(
            lf_nx={"CO1": {"BRANCH1": {1: 500.0}}},
            sensitivity_pst_nx={}, sensitivity_rd_nx={},
            penalty_cost_overload_nx_patl=1000.0,
        )
        model = build_n0_milp_model(
            ae_list, "1030Z", lf_initial={"BRANCH1": {1: 500.0}},
            penalty_cost_overload_n0=1000.0,
            pst_inputs=_make_pst_inputs_r39(), nx_inputs=nx_inputs,
        )
        model = _solve(model)

        output_path = tmp_path / "results_nx_loadings.csv"
        export_nx_loadings_csv(
            model, ae_list, co_list,
            lf_nx_initial=nx_inputs.lf_nx, lf_initial={"BRANCH1": {1: 500.0}},
            sensitivity_pst_nx={}, sensitivity_rd_nx={},
            pst_degrees_per_tap={}, tatl_data={}, timestamp="1030Z", output_path=output_path,
        )

        header = output_path.read_text(encoding=TEXT_ENCODING).splitlines()[0].split(",")
        assert header == [
            "timestamp", "contingency_mrid", "contingency_name", "branch_mrid", "branch_name",
            "tso", "side", "i_ka_n0", "i_ka_nx_initial", "loading_pct_nx_initial",
            "loading_pct_nx_post_pra", "loading_pct_nx_post_pra_cra",
            "patl_ka", "tatl_ka", "slack_patl", "slack_tatl",
            "loading_pct_nx_post_pra_model", "loading_pct_nx_post_pra_model_diff_pct",
        ]

    def test_tatl_ka_populated_when_tatl_data_present(self, tmp_path):
        ae_list = [_make_ae_r39("BRANCH1")]
        co_list = [_make_contingency_r39("CO1", "CO One", ["eq-1"])]
        nx_inputs = NxMilpInputs(
            lf_nx={"CO1": {"BRANCH1": {1: 500.0}}},
            sensitivity_pst_nx={}, sensitivity_rd_nx={},
            penalty_cost_overload_nx_patl=1000.0,
            tatl_data={"BRANCH1": {"tatl_limit_ampere": 1200.0, "tatl_duration_seconds": 1200, "side": 1}},
        )
        model = build_n0_milp_model(
            ae_list, "1030Z", lf_initial={"BRANCH1": {1: 500.0}},
            penalty_cost_overload_n0=1000.0,
            pst_inputs=_make_pst_inputs_r39(), nx_inputs=nx_inputs,
        )
        model = _solve(model)

        output_path = tmp_path / "results_nx_loadings.csv"
        export_nx_loadings_csv(
            model, ae_list, co_list,
            lf_nx_initial=nx_inputs.lf_nx, lf_initial={"BRANCH1": {1: 500.0}},
            sensitivity_pst_nx={}, sensitivity_rd_nx={},
            pst_degrees_per_tap={}, tatl_data=nx_inputs.tatl_data,
            timestamp="1030Z", output_path=output_path,
        )

        rows = list(csv.DictReader(output_path.open(encoding=TEXT_ENCODING)))
        assert float(rows[0]["tatl_ka"]) == pytest.approx(1.2)
        assert float(rows[0]["slack_tatl"]) == pytest.approx(0.0, abs=1e-6)

    def test_missing_tatl_leaves_tatl_columns_blank(self, tmp_path):
        ae_list = [_make_ae_r39("BRANCH1")]
        co_list = [_make_contingency_r39("CO1", "CO One", ["eq-1"])]
        nx_inputs = NxMilpInputs(
            lf_nx={"CO1": {"BRANCH1": {1: 500.0}}},
            sensitivity_pst_nx={}, sensitivity_rd_nx={},
            penalty_cost_overload_nx_patl=1000.0,
        )
        model = build_n0_milp_model(
            ae_list, "1030Z", lf_initial={"BRANCH1": {1: 500.0}},
            penalty_cost_overload_n0=1000.0,
            pst_inputs=_make_pst_inputs_r39(), nx_inputs=nx_inputs,
        )
        model = _solve(model)

        output_path = tmp_path / "results_nx_loadings.csv"
        export_nx_loadings_csv(
            model, ae_list, co_list,
            lf_nx_initial=nx_inputs.lf_nx, lf_initial={"BRANCH1": {1: 500.0}},
            sensitivity_pst_nx={}, sensitivity_rd_nx={},
            pst_degrees_per_tap={}, tatl_data={}, timestamp="1030Z", output_path=output_path,
        )

        rows = list(csv.DictReader(output_path.open(encoding=TEXT_ENCODING)))
        assert rows[0]["tatl_ka"] == ""
        assert rows[0]["slack_tatl"] == ""


class TestExportContingencyStatusCsv:
    def test_converged_and_included_reflect_actual_model_state(self, tmp_path):
        ae_list = [_make_ae_r39("BRANCH1")]
        co_list = [
            _make_contingency_r39("CO1", "Converged and included", ["eq-1"]),
            _make_contingency_r39("CO2", "Skipped, non-convergent", ["eq-2"]),
        ]
        nx_inputs = NxMilpInputs(
            lf_nx={"CO1": {"BRANCH1": {1: 500.0}}},  # only CO1 usable
            sensitivity_pst_nx={}, sensitivity_rd_nx={},
            penalty_cost_overload_nx_patl=1000.0,
        )
        model = build_n0_milp_model(
            ae_list, "1030Z", lf_initial={"BRANCH1": {1: 500.0}},
            penalty_cost_overload_n0=1000.0,
            pst_inputs=_make_pst_inputs_r39(), nx_inputs=nx_inputs,
        )
        model = _solve(model)

        output_path = tmp_path / "results_contingency_status.csv"
        export_contingency_status_csv(
            co_list, "1030Z", lf_nx_initial=nx_inputs.lf_nx,
            skipped_contingencies={"CO2": "non-convergent (status=MAX_ITERATION_REACHED)"},
            model=model, output_path=output_path,
        )

        rows = {row["contingency_mrid"]: row for row in csv.DictReader(output_path.open(encoding=TEXT_ENCODING))}
        assert rows["CO1"]["converged"] == "True"
        assert rows["CO1"]["included_in_milp"] == "True"
        assert rows["CO1"]["skipped_reason"] == ""
        assert rows["CO2"]["converged"] == "False"
        assert rows["CO2"]["included_in_milp"] == "False"
        assert "non-convergent" in rows["CO2"]["skipped_reason"]

    def test_only_must_study_contingencies_at_this_timestamp_included(self, tmp_path):
        ae_list = [_make_ae_r39("BRANCH1")]
        co_list = [
            _make_contingency_r39("CO1", "must study", ["eq-1"], must_study=True),
            _make_contingency_r39("CO2", "not must study", ["eq-2"], must_study=False),
        ]
        nx_inputs = NxMilpInputs(
            lf_nx={"CO1": {"BRANCH1": {1: 500.0}}},
            sensitivity_pst_nx={}, sensitivity_rd_nx={},
            penalty_cost_overload_nx_patl=1000.0,
        )
        model = build_n0_milp_model(
            ae_list, "1030Z", lf_initial={"BRANCH1": {1: 500.0}},
            penalty_cost_overload_n0=1000.0,
            pst_inputs=_make_pst_inputs_r39(), nx_inputs=nx_inputs,
        )
        model = _solve(model)

        output_path = tmp_path / "results_contingency_status.csv"
        export_contingency_status_csv(
            co_list, "1030Z", lf_nx_initial=nx_inputs.lf_nx,
            skipped_contingencies={}, model=model, output_path=output_path,
        )

        rows = list(csv.DictReader(output_path.open(encoding=TEXT_ENCODING)))
        assert [r["contingency_mrid"] for r in rows] == ["CO1"]


REPO_SRC = Path(__file__).resolve().parents[1] / "src" / "rao"


def _make_ae_csvcols(mrid, branch_mrid, branch_side=1, patl_ka=1.0, ae_type=AEType.SECURED, tso="TSO"):
    return AssessedElement(
        mrid=mrid, name="a", tso=tso, ae_type=ae_type, branch_mrid=branch_mrid,
        secured_for_region=None, scanned_for_region=None, exclusion_reason=None,
        patl_ka={"1030Z": patl_ka}, branch_side=branch_side,
    )


def _make_contingency_csvcols(mrid, equipment_mrids, must_study=True, timestamp="1030Z"):
    return Contingency(
        mrid=mrid, name=f"CO {mrid}", tso="TSO",
        contingency_type=ContingencyType.ORDINARY,
        must_study={timestamp: must_study},
        equipment_mrids=equipment_mrids,
    )


# ---------------------------------------------------------------------------
# write_sensitivity_nx_csv — rename + ae_type column
# ---------------------------------------------------------------------------

class TestWriteSensitivityNxCsvColumns:
    def test_column_renamed_to_ampere_per_degree(self, tmp_path):
        from pre_milp.nx_sensitivity import write_sensitivity_nx_csv

        output_path = tmp_path / "sensitivity_pst_nx.csv"
        write_sensitivity_nx_csv({"CO1": {("B1", "PST1"): 5.0}}, {"B1": 1}, {}, output_path, "1030Z")
        header = output_path.read_text(encoding=TEXT_ENCODING).splitlines()[0].split(",")
        assert "di_ds_ampere_per_degree" in header
        assert "di_ds_ampere_per_tap" not in header

    def test_ae_type_column_present_and_populated(self, tmp_path):
        from pre_milp.nx_sensitivity import write_sensitivity_nx_csv

        output_path = tmp_path / "sensitivity_pst_nx.csv"
        write_sensitivity_nx_csv(
            {"CO1": {("B1", "PST1"): 5.0, ("B2", "PST1"): 3.0}}, {"B1": 1, "B2": 1}, {}, output_path, "1030Z",
            branch_ae_types={"B1": AEType.SECURED, "B2": AEType.SCANNED},
        )
        rows = {r["branch_mrid"]: r for r in csv.DictReader(output_path.open(encoding=TEXT_ENCODING))}
        assert rows["B1"]["ae_type"] == "secured"
        assert rows["B2"]["ae_type"] == "scanned"

    def test_ae_type_blank_when_not_provided_backward_compatible(self, tmp_path):
        """Existing callers (compute_sensitivity_pst_nx's own internal
        write without ae_type context, and any other caller not yet
        passing branch_ae_types) must not break."""
        from pre_milp.nx_sensitivity import write_sensitivity_nx_csv

        output_path = tmp_path / "sensitivity_pst_nx.csv"
        write_sensitivity_nx_csv({"CO1": {("B1", "PST1"): 5.0}}, {"B1": 1}, {}, output_path, "1030Z")
        rows = list(csv.DictReader(output_path.open(encoding=TEXT_ENCODING)))
        assert rows[0]["ae_type"] == ""


# ---------------------------------------------------------------------------
# write_sensitivity_rd_nx_csv — rename + branch_name/tso/ae_type columns
# ---------------------------------------------------------------------------

class TestWriteSensitivityRdNxCsvColumns:
    def test_column_renamed_to_dp_ampere_per_mw(self, tmp_path):
        from pre_milp.nx_sensitivity import write_sensitivity_rd_nx_csv

        output_path = tmp_path / "sensitivity_rd_nx.csv"
        write_sensitivity_rd_nx_csv({"CO1": {("B1", "GU1"): 0.3}}, {"B1": 1}, output_path, "1030Z")
        header = output_path.read_text(encoding=TEXT_ENCODING).splitlines()[0].split(",")
        assert "di_dp_ampere_per_mw" in header
        assert "di_da_ampere_per_mw" not in header

    def test_branch_name_tso_ae_type_columns_present_and_populated(self, tmp_path):
        from pre_milp.nx_sensitivity import write_sensitivity_rd_nx_csv

        output_path = tmp_path / "sensitivity_rd_nx.csv"
        write_sensitivity_rd_nx_csv(
            {"CO1": {("B1", "GU1"): 0.3}}, {"B1": 1}, output_path, "1030Z",
            branch_mrid_to_name={"B1": "Branch One"},
            branch_tso={"B1": "TSO-Belgovia"},
            branch_ae_types={"B1": AEType.SECURED},
        )
        rows = list(csv.DictReader(output_path.open(encoding=TEXT_ENCODING)))
        assert rows[0]["branch_name"] == "Branch One"
        assert rows[0]["tso"] == "TSO-Belgovia"
        assert rows[0]["ae_type"] == "secured"

    def test_columns_blank_when_optional_params_absent(self, tmp_path):
        from pre_milp.nx_sensitivity import write_sensitivity_rd_nx_csv

        output_path = tmp_path / "sensitivity_rd_nx.csv"
        write_sensitivity_rd_nx_csv({"CO1": {("B1", "GU1"): 0.3}}, {"B1": 1}, output_path, "1030Z")
        rows = list(csv.DictReader(output_path.open(encoding=TEXT_ENCODING)))
        assert rows[0]["branch_name"] == "B1"  # falls back to mrid, matching PST CSV's own convention
        assert rows[0]["tso"] == ""
        assert rows[0]["ae_type"] == ""


# ---------------------------------------------------------------------------
# write_lf_nx_csv — rename + ae_type + REAL (not perpetually blank) values
# ---------------------------------------------------------------------------

class TestWriteLfNxCsvColumnsAndValues:
    def test_column_renamed_to_limit_ka(self, tmp_path):
        from pre_milp.nx_security_analysis import write_lf_nx_csv

        output_path = tmp_path / "lf_nx_initial.csv"
        lf_nx = {"CO1": {"B1": {1: 500.0}}}
        write_lf_nx_csv(lf_nx, {"B1": 1}, {}, [_make_contingency_csvcols("CO1", ["eq1"])], output_path, "1030Z")
        header = output_path.read_text(encoding=TEXT_ENCODING).splitlines()[0].split(",")
        assert "limit_ka" in header
        assert "patl_ka" not in header

    def test_secured_branch_loading_pct_computed_against_patl(self, tmp_path):
        from pre_milp.nx_security_analysis import write_lf_nx_csv

        output_path = tmp_path / "lf_nx_initial.csv"
        lf_nx = {"CO1": {"B1": {1: 900.0}}}  # 900 A against 1000 A PATL -> 90%
        write_lf_nx_csv(
            lf_nx, {"B1": 1}, {"B1": "Branch One"}, [_make_contingency_csvcols("CO1", ["eq1"])],
            output_path, "1030Z",
            branch_ae_types={"B1": AEType.SECURED},
            limit_by_branch={"B1": 1000.0},
            branch_tso={"B1": "TSO-Belgovia"},
        )
        rows = list(csv.DictReader(output_path.open(encoding=TEXT_ENCODING)))
        assert rows[0]["ae_type"] == "secured"
        assert rows[0]["tso"] == "TSO-Belgovia"
        assert float(rows[0]["limit_ka"]) == pytest.approx(1.0)
        assert float(rows[0]["loading_pct"]) == pytest.approx(90.0)

    def test_scanned_branch_loading_pct_computed_against_effective_limit_not_patl(self, tmp_path):
        """A SCANNED branch's loading_pct is computed against its limit_by_branch entry (the
        effective limit), not its patl_ka."""
        from pre_milp.nx_security_analysis import write_lf_nx_csv

        output_path = tmp_path / "lf_nx_initial.csv"
        lf_nx = {"CO1": {"B1": {1: 900.0}}}  # 900 A
        # effective limit 2000 A differs from patl_ka (1000 A), so the two possible results
        # (90% vs 45%) tell which one was used
        write_lf_nx_csv(
            lf_nx, {"B1": 1}, {}, [_make_contingency_csvcols("CO1", ["eq1"])],
            output_path, "1030Z",
            branch_ae_types={"B1": AEType.SCANNED},
            limit_by_branch={"B1": 2000.0},  # effective_limit, NOT patl
            branch_tso={"B1": "TSO-Belgovia"},
        )
        rows = list(csv.DictReader(output_path.open(encoding=TEXT_ENCODING)))
        assert rows[0]["ae_type"] == "scanned"
        assert float(rows[0]["limit_ka"]) == pytest.approx(2.0)
        assert float(rows[0]["loading_pct"]) == pytest.approx(45.0)  # 900/2000, NOT 900/1000

    def test_columns_blank_when_optional_context_absent(self, tmp_path):
        """Without the optional context the columns stay blank."""
        from pre_milp.nx_security_analysis import write_lf_nx_csv

        output_path = tmp_path / "lf_nx_initial.csv"
        lf_nx = {"CO1": {"B1": {1: 500.0}}}
        write_lf_nx_csv(lf_nx, {"B1": 1}, {}, [_make_contingency_csvcols("CO1", ["eq1"])], output_path, "1030Z")
        rows = list(csv.DictReader(output_path.open(encoding=TEXT_ENCODING)))
        assert rows[0]["ae_type"] == ""
        assert rows[0]["loading_pct"] == ""
        assert rows[0]["limit_ka"] == ""
        assert rows[0]["tso"] == ""


# ---------------------------------------------------------------------------
# compute_lf_nx — the optional lf_initial enriches the CSV end-to-end
# ---------------------------------------------------------------------------


class DummySecurityAnalysisResult:
    def __init__(self, post_contingency_results, branch_results):
        self.post_contingency_results = post_contingency_results
        self.branch_results = branch_results


class DummyPostContingencyResult:
    def __init__(self, status_name):
        self.status = type("Status", (), {"name": status_name})()


class DummySecurityAnalysis:
    def __init__(self, post_contingency_results, branch_results):
        self._post_contingency_results = post_contingency_results
        self._branch_results = branch_results

    def add_single_element_contingency(self, *a, **k):
        pass

    def add_multiple_elements_contingency(self, *a, **k):
        pass

    def add_monitored_elements(self, *a, **k):
        pass

    def run_ac(self, network, parameters=None):
        return DummySecurityAnalysisResult(self._post_contingency_results, self._branch_results)


class DummySecurityModule:
    class Parameters:
        def __init__(self, load_flow_parameters=None, provider_parameters=None):
            self.load_flow_parameters = load_flow_parameters
            self.provider_parameters = provider_parameters

    def __init__(self, post_contingency_results, branch_results):
        self._post_contingency_results = post_contingency_results
        self._branch_results = branch_results

    def create_analysis(self):
        return DummySecurityAnalysis(self._post_contingency_results, self._branch_results)


class DummyLoadflowModule:
    """Minimal stand-in for pypowsybl.loadflow, reached by attribute access (as the code
    under test uses it)."""
    class Parameters:
        def __init__(self, **kwargs):
            for key, value in kwargs.items():
                setattr(self, key, value)


class DummyPypowsyblModule:
    def __init__(self, post_contingency_results, branch_results):
        self.security = DummySecurityModule(post_contingency_results, branch_results)
        self.loadflow = DummyLoadflowModule()


class DummyNetworkForBranchName:
    def get_lines(self):
        import pandas as pd
        return pd.DataFrame({"name": ["Branch One"]}, index=["B1"])

    def get_2_windings_transformers(self):
        import pandas as pd
        return pd.DataFrame({"name": []}, index=[])


def _branch_results_df(rows):
    if not rows:
        return pd.DataFrame(columns=["contingency_id", "branch_id", "i1", "i2"]).set_index(
            ["contingency_id", "branch_id"]
        )
    return pd.DataFrame(rows).set_index(["contingency_id", "branch_id"])


class TestComputeLfNxWithLfInitial:
    def test_lf_initial_none_keeps_current_blank_behaviour(self, monkeypatch, tmp_path):
        from pre_milp.nx_security_analysis import compute_lf_nx

        ae_list = [_make_ae_csvcols("ae1", "B1", branch_side=1, patl_ka=1.0)]
        co_list = [_make_contingency_csvcols("CO1", ["eq1"])]
        branch_results = _branch_results_df([
            {"contingency_id": "CO1", "branch_id": "B1", "i1": 900.0, "i2": 850.0},
        ])
        fake_pp = DummyPypowsyblModule({"CO1": DummyPostContingencyResult("CONVERGED")}, branch_results)
        monkeypatch.setitem(sys.modules, "pypowsybl", fake_pp)

        output_path = tmp_path / "lf_nx_initial.csv"
        compute_lf_nx(object(), co_list, ae_list, "1030Z", output_path=output_path)

        rows = list(csv.DictReader(output_path.open(encoding=TEXT_ENCODING)))
        assert rows[0]["ae_type"] == ""
        assert rows[0]["limit_ka"] == ""

    def test_lf_initial_provided_enriches_csv_with_real_values(self, monkeypatch, tmp_path):
        from pre_milp.nx_security_analysis import compute_lf_nx

        ae_list = [_make_ae_csvcols("ae1", "B1", branch_side=1, patl_ka=1.0)]
        co_list = [_make_contingency_csvcols("CO1", ["eq1"])]
        branch_results = _branch_results_df([
            {"contingency_id": "CO1", "branch_id": "B1", "i1": 900.0, "i2": 850.0},
        ])
        fake_pp = DummyPypowsyblModule({"CO1": DummyPostContingencyResult("CONVERGED")}, branch_results)
        monkeypatch.setitem(sys.modules, "pypowsybl", fake_pp)

        output_path = tmp_path / "lf_nx_initial.csv"
        network = DummyNetworkForBranchName()
        compute_lf_nx(
            network, co_list, ae_list, "1030Z",
            lf_initial={"B1": {1: 500.0}},
            output_path=output_path,
        )

        rows = list(csv.DictReader(output_path.open(encoding=TEXT_ENCODING)))
        assert rows[0]["ae_type"] == "secured"
        assert rows[0]["limit_ka"] != ""
        assert rows[0]["loading_pct"] != ""


# ===========================================================================
# Scanned-element results file
# ===========================================================================

REPO_ROOT = Path(__file__).resolve().parents[1]


EXPECTED_HEADER = [
    "timestamp", "contingency_mrid", "branch_mrid", "branch_name", "tso", "side",
    "effective_limit_ka", "loading_before_rao_ka", "loading_after_rao_ka", "slack_ka",
    "loading_after_model_ka",
]


LF_NX = {"CO1": {"B1": {1: 1050.0}}}


SENSITIVITY_PST_NX = {"CO1": {("B1", "PST1"): -10.0}}


DEGREES_PER_TAP = {"PST1": 1.0}


def _solved_scanned_model(max_up_taps: int):
    """B1 is a SCANNED branch with effective limit 1000 A (its N-0 current),
    carrying 1050 A under CO1; PST1 relieves 10 A per tap upward and may move
    at most max_up_taps taps up."""
    ae_list = [_make_ae("ae1", "B1", branch_side=1, patl_ka=1.0, ae_type=AEType.SCANNED)]
    pst_inputs = PstMilpInputs(
        pst_list=[_make_pst("PST1")], pst_tap_bounds={"PST1": (-10, max_up_taps)},
        pst_group_equality_pairs=[], sensitivity_pst_n0_pruned={("B1", "PST1"): 0.0},
        pst_degrees_per_tap=DEGREES_PER_TAP, penalty_reference_pst_pra=10.0,
    )
    nx_inputs = NxMilpInputs(
        lf_nx=LF_NX, sensitivity_pst_nx=SENSITIVITY_PST_NX, sensitivity_rd_nx={},
        penalty_cost_overload_nx_patl=1_000_000.0, penalty_cost_overload_nx_scanned=1_000_000.0,
    )
    model = build_n0_milp_model(
        ae_list, "1030Z", lf_initial={"B1": {1: 1000.0}},
        penalty_cost_overload_n0=1_000_000.0, pst_inputs=pst_inputs, nx_inputs=nx_inputs,
    )
    assert str(pyo.SolverFactory("appsi_highs").solve(model).solver.termination_condition) == "optimal"
    return model, ae_list


def _export(model, ae_list, output_path, lf_nx=None):
    export_nx_scanned_elements_csv(
        model, ae_list, [_make_contingency("CO1", ["X"])],
        lf_nx_initial=LF_NX if lf_nx is None else lf_nx,
        sensitivity_pst_nx=SENSITIVITY_PST_NX, sensitivity_rd_nx={},
        pst_degrees_per_tap=DEGREES_PER_TAP, branch_limits={"B1": 1000.0},
        timestamp="1030Z", output_path=output_path, branch_mrid_to_name={"B1": "Line One"},
    )
    with open(output_path, newline="", encoding=TEXT_ENCODING) as f:
        return list(csv.DictReader(f))


def test_row_lists_limit_loading_before_loading_after_and_zero_slack_when_the_overload_is_resolved(tmp_path):
    model, ae_list = _solved_scanned_model(max_up_taps=10)

    rows = _export(model, ae_list, tmp_path / "results_nx_scanned_elements.csv")

    assert len(rows) == 1
    row = rows[0]
    assert list(row.keys()) == EXPECTED_HEADER
    assert (row["timestamp"], row["contingency_mrid"], row["branch_mrid"]) == ("1030Z", "CO1", "B1")
    assert (row["branch_name"], row["tso"], row["side"]) == ("Line One", "TSO", "1")
    assert float(row["effective_limit_ka"]) == pytest.approx(1.0)
    assert float(row["loading_before_rao_ka"]) == pytest.approx(1.05)
    assert float(row["loading_after_rao_ka"]) == pytest.approx(1.0, abs=1e-9)  # 1050 A - 5 taps x 10 A
    assert float(row["slack_ka"]) == pytest.approx(0.0, abs=1e-9)


def test_unresolved_overload_shows_in_loading_after_and_slack(tmp_path):
    """Only 2 taps allowed: 1050 A - 20 A = 1030 A, 30 A above the 1000 A
    limit, so loading_after = 1.03 kA and slack_ka = 0.03 kA."""
    model, ae_list = _solved_scanned_model(max_up_taps=2)

    row = _export(model, ae_list, tmp_path / "results_nx_scanned_elements.csv")[0]

    assert float(row["loading_after_rao_ka"]) == pytest.approx(1.03, abs=1e-9)
    assert float(row["slack_ka"]) == pytest.approx(0.03, abs=1e-9)
    assert float(row["loading_after_rao_ka"]) - float(row["effective_limit_ka"]) == pytest.approx(
        float(row["slack_ka"]), abs=1e-9)


def test_loading_after_includes_the_curative_pst_effect(tmp_path):
    """A curative-only PST relieves B1 under CO1 (10 A per tap, 5 taps), so the
    loading after the RAO is 1.0 kA although no preventive action moves."""
    ae_list = [_make_ae("ae1", "B1", branch_side=1, patl_ka=1.0, ae_type=AEType.SCANNED)]
    curative_pst = _make_pst_of_kind("CPST", RAKind.CURATIVE, penalty_factor=1.0)
    pst_inputs = PstMilpInputs(
        pst_list=[_make_pst("PST1"), curative_pst], pst_tap_bounds={"PST1": (0, 0)},
        pst_group_equality_pairs=[], sensitivity_pst_n0_pruned={("B1", "PST1"): 0.0},
        pst_degrees_per_tap={"PST1": 1.0, "CPST": 1.0}, penalty_reference_pst_pra=10.0,
    )
    sensitivity = {"CO1": {("B1", "PST1"): 0.0, ("B1", "CPST"): -10.0}}
    nx_inputs = NxMilpInputs(
        lf_nx=LF_NX, sensitivity_pst_nx=sensitivity, sensitivity_rd_nx={},
        penalty_cost_overload_nx_patl=1_000_000.0, penalty_cost_overload_nx_scanned=1_000_000.0,
        pst_cra_availability={("CPST", "B1", "CO1"): {"max_curative_taps": 10, "available": True}},
        pst_tap_bounds_curative={"CPST": (-10, 10)},
    )
    model = build_n0_milp_model(
        ae_list, "1030Z", lf_initial={"B1": {1: 1000.0}},
        penalty_cost_overload_n0=1_000_000.0, pst_inputs=pst_inputs, nx_inputs=nx_inputs,
    )
    assert str(pyo.SolverFactory("appsi_highs").solve(model).solver.termination_condition) == "optimal"
    out = tmp_path / "results_nx_scanned_elements.csv"

    export_nx_scanned_elements_csv(
        model, ae_list, [_make_contingency("CO1", ["X"])], lf_nx_initial=LF_NX,
        sensitivity_pst_nx=sensitivity, sensitivity_rd_nx={},
        pst_degrees_per_tap={"PST1": 1.0, "CPST": 1.0}, branch_limits={"B1": 1000.0},
        timestamp="1030Z", output_path=out, branch_mrid_to_name={"B1": "Line One"},
    )

    with open(out, newline="", encoding=TEXT_ENCODING) as f:
        row = list(csv.DictReader(f))[0]
    assert float(row["loading_after_rao_ka"]) == pytest.approx(1.0, abs=1e-9)


def test_header_only_when_the_model_has_no_scanned_branch_contingency_pair(tmp_path):
    ae_list = [_make_ae("ae1", "B1", branch_side=1, patl_ka=1.0, ae_type=AEType.SECURED)]
    pst_inputs = PstMilpInputs(
        pst_list=[_make_pst("PST1")], pst_tap_bounds={"PST1": (-10, 10)},
        pst_group_equality_pairs=[], sensitivity_pst_n0_pruned={}, pst_degrees_per_tap=DEGREES_PER_TAP,
        penalty_reference_pst_pra=10.0,
    )
    nx_inputs = NxMilpInputs(
        lf_nx={"CO1": {"B1": {1: 900.0}}}, sensitivity_pst_nx=SENSITIVITY_PST_NX, sensitivity_rd_nx={},
        penalty_cost_overload_nx_patl=500.0,
    )
    model = build_n0_milp_model(
        ae_list, "1030Z", lf_initial={"B1": {1: 500.0}},
        penalty_cost_overload_n0=1000.0, pst_inputs=pst_inputs, nx_inputs=nx_inputs,
    )
    out = tmp_path / "results_nx_scanned_elements.csv"

    _export(model, ae_list, out, lf_nx={"CO1": {"B1": {1: 900.0}}})

    with open(out, newline="", encoding=TEXT_ENCODING) as f:
        assert list(csv.reader(f)) == [EXPECTED_HEADER]


def test_pair_without_an_initial_n_x_current_is_skipped(tmp_path):
    model, ae_list = _solved_scanned_model(max_up_taps=10)
    assert _export(model, ae_list, tmp_path / "results_nx_scanned_elements.csv", lf_nx={"CO1": {}}) == []


def test_pipeline_writes_the_file_with_the_documented_header(mock_nx_pipeline_run):
    """On the mock case no branch is scanned, so the file is header-only —
    but it is written, with exactly the documented columns."""
    path = mock_nx_pipeline_run.output_dir / "results_nx_scanned_elements.csv"
    with open(path, newline="", encoding=TEXT_ENCODING) as f:
        assert next(csv.reader(f)) == EXPECTED_HEADER


# ---------------------------------------------------------------------------
# column sources: original lf_nx / lf_nx_final / the build baseline of the final model
# ---------------------------------------------------------------------------

ORIGINAL_A = 1050.0       # lf_nx_initial: the original pre-RAO N-X flow


BUILD_BASELINE_A = 1045.0  # the N-X flow the final solve was built on


FINAL_A = 1020.0          # AC N-X flow at the final applied state


PREVENTIVE_TAPS, CURATIVE_TAPS = 2, 3


PASSED_PST_SENSITIVITY = -10.0     # sensitivities passed to the export (the original ones)


BUILD_PST_SENSITIVITY = -20.0      # sensitivities the final solve was built on


CURATIVE_SENSITIVITY = -10.0


def _manual_model(with_build_baseline: bool):
    """A built (not solved) model whose variables are set by hand: PST1 moves PREVENTIVE_TAPS up in the
    last solve, the curative PST CPST moves CURATIVE_TAPS up under CO1."""
    ae_list = [_make_ae("ae1", "B1", branch_side=1, patl_ka=1.0, ae_type=AEType.SCANNED)]
    curative_pst = _make_pst_of_kind("CPST", RAKind.CURATIVE, penalty_factor=1.0)
    degrees = {"PST1": 1.0, "CPST": 1.0}
    pst_inputs = PstMilpInputs(
        pst_list=[_make_pst("PST1"), curative_pst], pst_tap_bounds={"PST1": (-10, 10)},
        pst_group_equality_pairs=[], sensitivity_pst_n0_pruned={("B1", "PST1"): 0.0},
        pst_degrees_per_tap=degrees, penalty_reference_pst_pra=10.0,
    )
    build_sensitivity = {"CO1": {("B1", "PST1"): BUILD_PST_SENSITIVITY, ("B1", "CPST"): CURATIVE_SENSITIVITY}}
    nx_inputs = NxMilpInputs(
        lf_nx={"CO1": {"B1": {1: BUILD_BASELINE_A}}}, sensitivity_pst_nx=build_sensitivity, sensitivity_rd_nx={},
        penalty_cost_overload_nx_patl=1_000_000.0, penalty_cost_overload_nx_scanned=1_000_000.0,
        pst_cra_availability={("CPST", "B1", "CO1"): {"max_curative_taps": 10, "available": True}},
        pst_tap_bounds_curative={"CPST": (-10, 10)},
    )
    model = build_n0_milp_model(
        ae_list, "1030Z", lf_initial={"B1": {1: 1000.0}},
        penalty_cost_overload_n0=1_000_000.0, pst_inputs=pst_inputs, nx_inputs=nx_inputs,
    )
    model.tap_change_upward["PST1"].set_value(PREVENTIVE_TAPS)
    model.tap_change_downward["PST1"].set_value(0)
    model.curative_tap_change_upward["CPST", "CO1"].set_value(CURATIVE_TAPS)
    model.curative_tap_change_downward["CPST", "CO1"].set_value(0)
    model.nx_scanned_overload_slack["B1", "CO1"].set_value(0.0)
    if not with_build_baseline and hasattr(model, "nx_build_baseline"):
        del model.nx_build_baseline
    if with_build_baseline:
        model.nx_build_baseline = {
            "lf_nx": {"CO1": {"B1": {1: BUILD_BASELINE_A}}},
            "sensitivity_pst_nx": build_sensitivity, "sensitivity_rd_nx": {},
        }
    return model, ae_list, degrees


def _manual_row(tmp_path, with_build_baseline, lf_nx_final):
    model, ae_list, degrees = _manual_model(with_build_baseline)
    out = tmp_path / "results_nx_scanned_elements.csv"
    export_nx_scanned_elements_csv(
        model, ae_list, [_make_contingency("CO1", ["X"])],
        lf_nx_initial={"CO1": {"B1": {1: ORIGINAL_A}}},
        sensitivity_pst_nx={"CO1": {("B1", "PST1"): PASSED_PST_SENSITIVITY, ("B1", "CPST"): CURATIVE_SENSITIVITY}},
        sensitivity_rd_nx={}, pst_degrees_per_tap=degrees, branch_limits={"B1": 1000.0},
        timestamp="1030Z", output_path=out, branch_mrid_to_name={"B1": "Line One"},
        lf_nx_final=lf_nx_final,
    )
    with open(out, newline="", encoding=TEXT_ENCODING) as f:
        return list(csv.DictReader(f))[0]


BUILD_PREVENTIVE_A = BUILD_PST_SENSITIVITY * PREVENTIVE_TAPS       # -40 A


PASSED_PREVENTIVE_A = PASSED_PST_SENSITIVITY * PREVENTIVE_TAPS     # -20 A


CURATIVE_A = CURATIVE_SENSITIVITY * CURATIVE_TAPS                  # -30 A


class TestScannedExportColumnSources:
    def test_with_the_final_flow_after_is_the_final_flow_plus_the_curative_effect_only(self, tmp_path):
        row = _manual_row(tmp_path, True, {"CO1": {"B1": {1: FINAL_A}}})
        assert float(row["loading_before_rao_ka"]) == pytest.approx(ORIGINAL_A / 1000.0)
        assert float(row["loading_after_rao_ka"]) == pytest.approx((FINAL_A + CURATIVE_A) / 1000.0)

    def test_the_model_column_is_the_build_baseline_plus_the_full_linearised_effect(self, tmp_path):
        row = _manual_row(tmp_path, True, {"CO1": {"B1": {1: FINAL_A}}})
        assert float(row["loading_after_model_ka"]) == pytest.approx(
            (BUILD_BASELINE_A + BUILD_PREVENTIVE_A + CURATIVE_A) / 1000.0)

    def test_without_a_final_value_for_the_pair_after_falls_back_to_the_build_baseline_plus_full_effect(self, tmp_path):
        for lf_nx_final in (None, {}, {"CO1": {}}, {"OTHER": {"B1": {1: FINAL_A}}}):
            row = _manual_row(tmp_path, True, lf_nx_final)
            expected = (BUILD_BASELINE_A + BUILD_PREVENTIVE_A + CURATIVE_A) / 1000.0
            assert float(row["loading_after_rao_ka"]) == pytest.approx(expected), lf_nx_final
            assert float(row["loading_after_model_ka"]) == pytest.approx(expected), lf_nx_final
            assert float(row["loading_before_rao_ka"]) == pytest.approx(ORIGINAL_A / 1000.0)

    def test_without_a_build_baseline_the_original_flow_and_the_passed_sensitivities_are_used(self, tmp_path):
        row = _manual_row(tmp_path, False, None)
        expected = (ORIGINAL_A + PASSED_PREVENTIVE_A + CURATIVE_A) / 1000.0
        assert float(row["loading_after_rao_ka"]) == pytest.approx(expected)
        assert float(row["loading_after_model_ka"]) == pytest.approx(expected)

    def test_final_flow_without_a_build_baseline_still_gives_final_plus_curative(self, tmp_path):
        row = _manual_row(tmp_path, False, {"CO1": {"B1": {1: FINAL_A}}})
        assert float(row["loading_after_rao_ka"]) == pytest.approx((FINAL_A + CURATIVE_A) / 1000.0)
        assert float(row["loading_after_model_ka"]) == pytest.approx(
            (ORIGINAL_A + PASSED_PREVENTIVE_A + CURATIVE_A) / 1000.0)

    def test_the_final_flow_of_the_monitored_side_is_used(self, tmp_path):
        row = _manual_row(tmp_path, True, {"CO1": {"B1": {1: FINAL_A, 2: 5000.0}}})
        assert float(row["loading_after_rao_ka"]) == pytest.approx((FINAL_A + CURATIVE_A) / 1000.0)


# ===========================================================================
# Loading after RAO and contingency status reasons
# ===========================================================================

# ---------------------------------------------------------------------------
# the export uses the same curative pair gating as the builder
# ---------------------------------------------------------------------------

def test_export_loading_after_equals_the_model_value_for_a_pair_without_curative_availability(tmp_path):
    """CPST has a curative availability entry for (B1, CO1) only. It moves to relieve B1.
    B2 is scanned too, but the model's B2 constraint has no curative term, so the exported
    loading for B2 must equal the model value (no curative relief)."""
    import csv
    import pyomo.environ as pyo
    from data_model import RAKind
    from milp.milp_builder import NxMilpInputs, PstMilpInputs, build_n0_milp_model
    from post_milp.nx_results_export import export_nx_scanned_elements_csv
    from helpers import _make_ae_nx_filters as _make_ae, _make_contingency, _make_pst_nx_filters as _make_pst
    from helpers import _make_pst as _make_pst_of_kind

    ae_list = [_make_ae("ae1", "B1", branch_side=1, patl_ka=1.0, ae_type=AEType.SCANNED),
               _make_ae("ae2", "B2", branch_side=1, patl_ka=1.0, ae_type=AEType.SCANNED)]
    lf_nx = {"CO1": {"B1": {1: 1050.0}, "B2": {1: 1050.0}}}
    sensitivity = {"CO1": {("B1", "PST1"): 0.0, ("B2", "PST1"): 0.0,
                           ("B1", "CPST"): -10.0, ("B2", "CPST"): -10.0}}
    degrees = {"PST1": 1.0, "CPST": 1.0}
    pst_inputs = PstMilpInputs(
        pst_list=[_make_pst("PST1"), _make_pst_of_kind("CPST", RAKind.CURATIVE, penalty_factor=1.0)],
        pst_tap_bounds={"PST1": (0, 0)}, pst_group_equality_pairs=[],
        sensitivity_pst_n0_pruned={("B1", "PST1"): 0.0, ("B2", "PST1"): 0.0},
        pst_degrees_per_tap=degrees, penalty_reference_pst_pra=10.0,
    )
    nx_inputs = NxMilpInputs(
        lf_nx=lf_nx, sensitivity_pst_nx=sensitivity, sensitivity_rd_nx={},
        penalty_cost_overload_nx_patl=1_000_000.0, penalty_cost_overload_nx_scanned=1_000_000.0,
        pst_cra_availability={("CPST", "B1", "CO1"): {"max_curative_taps": 10, "available": True}},
        pst_tap_bounds_curative={"CPST": (-10, 10)},
    )
    model = build_n0_milp_model(
        ae_list, "1030Z", lf_initial={"B1": {1: 1000.0}, "B2": {1: 1000.0}},
        penalty_cost_overload_n0=1_000_000.0, pst_inputs=pst_inputs, nx_inputs=nx_inputs,
    )
    assert str(pyo.SolverFactory("appsi_highs").solve(model).solver.termination_condition) == "optimal"
    assert pyo.value(model.curative_tap_change_upward["CPST", "CO1"]) == pytest.approx(5.0)

    out = tmp_path / "results_nx_scanned_elements.csv"
    export_nx_scanned_elements_csv(
        model, ae_list, [_make_contingency("CO1", ["X"])], lf_nx_initial=lf_nx,
        sensitivity_pst_nx=sensitivity, sensitivity_rd_nx={}, pst_degrees_per_tap=degrees,
        branch_limits={"B1": 1000.0, "B2": 1000.0}, timestamp="1030Z", output_path=out,
        branch_mrid_to_name={},
    )
    rows = {r["branch_mrid"]: r for r in csv.DictReader(open(out, newline="", encoding=TEXT_ENCODING))}
    # B1: curative relief applies (1050 - 5 x 10 = 1000 A); B2: the model has no curative term
    assert float(rows["B1"]["loading_after_model_ka"]) == pytest.approx(1.0, abs=1e-9)
    assert float(rows["B2"]["loading_after_model_ka"]) == pytest.approx(1.05, abs=1e-9)
    assert float(rows["B2"]["loading_after_rao_ka"]) == pytest.approx(1.05, abs=1e-9)
    # the model's own value for B2: current + the model's RA effect (here zero), slack 50 A
    assert float(rows["B2"]["slack_ka"]) == pytest.approx(0.05, abs=1e-9)


def test_refresh_skips_are_merged_into_the_contingency_status_reasons(tmp_path):
    import csv
    from data_model import AEType
    import helpers as X
    from milp.milp_builder import NxMilpInputs, build_n0_milp_model
    from post_milp.nx_results_export import export_contingency_status_csv, merge_skipped_contingency_reasons
    co_list = [X._make_contingency_r39("CO1", "ok", ["eq-1"]),
               X._make_contingency_r39("CO2", "skipped initially", ["eq-2"]),
               X._make_contingency_r39("CO3", "lost at a refresh", ["eq-3"])]
    nx_inputs = NxMilpInputs(lf_nx={"CO1": {"BRANCH1": {1: 500.0}}, "CO3": {"BRANCH1": {1: 500.0}}},
                             sensitivity_pst_nx={}, sensitivity_rd_nx={}, penalty_cost_overload_nx_patl=1000.0)
    model = X._solve(build_n0_milp_model(
        [X._make_ae_r39("BRANCH1")], "1030Z", lf_initial={"BRANCH1": {1: 500.0}},
        penalty_cost_overload_n0=1000.0, pst_inputs=X._make_pst_inputs_r39(), nx_inputs=nx_inputs))
    merged = merge_skipped_contingency_reasons(
        {"CO2": "non-convergent (status=FAILED)"},
        [{"CO3": "likely network split"}, {"CO3": "other", "CO1": "non-convergent (status=FAILED)"}],
    )
    assert merged["CO2"] == "non-convergent (status=FAILED)"
    assert merged["CO3"] == "N-X refresh 1: likely network split"        # first reason kept
    assert merged["CO1"] == "N-X refresh 2: non-convergent (status=FAILED)"
    out = tmp_path / "results_contingency_status.csv"
    export_contingency_status_csv(co_list, "1030Z", lf_nx_initial=nx_inputs.lf_nx,
                                  skipped_contingencies=merged, model=model, output_path=out)
    rows = {r["contingency_mrid"]: r for r in csv.DictReader(open(out, newline="", encoding=TEXT_ENCODING))}
    assert rows["CO3"]["skipped_reason"] == "N-X refresh 1: likely network split"


def test_a_contingency_without_load_flow_and_without_a_recorded_reason_is_not_left_blank(tmp_path):
    import csv
    import helpers as X
    from milp.milp_builder import NxMilpInputs, build_n0_milp_model
    from post_milp.nx_results_export import export_contingency_status_csv
    co_list = [X._make_contingency_r39("CO1", "ok", ["eq-1"]), X._make_contingency_r39("CO2", "no reason", ["eq-2"])]
    nx_inputs = NxMilpInputs(lf_nx={"CO1": {"BRANCH1": {1: 500.0}}}, sensitivity_pst_nx={}, sensitivity_rd_nx={},
                             penalty_cost_overload_nx_patl=1000.0)
    model = X._solve(build_n0_milp_model(
        [X._make_ae_r39("BRANCH1")], "1030Z", lf_initial={"BRANCH1": {1: 500.0}},
        penalty_cost_overload_n0=1000.0, pst_inputs=X._make_pst_inputs_r39(), nx_inputs=nx_inputs))
    out = tmp_path / "s.csv"
    export_contingency_status_csv(co_list, "1030Z", lf_nx_initial=nx_inputs.lf_nx, skipped_contingencies={},
                                  model=model, output_path=out)
    rows = {r["contingency_mrid"]: r for r in csv.DictReader(open(out, newline="", encoding=TEXT_ENCODING))}
    assert rows["CO1"]["skipped_reason"] == ""
    assert rows["CO2"]["skipped_reason"] == "no load flow result (reason not recorded)"
