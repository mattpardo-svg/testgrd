"""tests/test_rao_eq_stream.py - the streamed reading of a CGM EQ file (eq_stream.StreamedEq) gives exactly the maps
that the rdflib graph gives (TapChanger -> PowerTransformer, CurrentLimit -> side, ControlAreaGeneratingUnit pairs), on
every EQ file of the fixture CGM and on hand-written variants; a file it cannot answer exactly is left to rdflib; a
generated file of 20 MB is read in a few MB."""

import logging
import time
import tracemalloc
from pathlib import Path

import pytest
from rdflib import RDF, URIRef

from pre_milp import cgmes_loader, ct_units, eq_stream, ncp_parser
from text_encoding import TEXT_ENCODING
from helpers import FIXTURE_CGM_ZIP

CIM = "http://iec.ch/TC57/CIM100#"
CIM_OTHER = "https://cim.ucaiug.io/ns#"


@pytest.fixture(scope="module")
def eq_files(tmp_path_factory):
    folder = tmp_path_factory.mktemp("cgm_eq")
    cgmes_loader.extract_cgm_zip(FIXTURE_CGM_ZIP, folder)
    files = sorted(folder.glob("*_EQ_*.xml"))
    assert files
    return files


def _maps(graph, path):
    return (
        ncp_parser.build_tap_changer_to_transformer_map(path, graph=graph),
        ncp_parser.build_current_limit_side_map(path, graph=graph),
        sorted(ct_units._control_area_unit_rows(graph)),
    )


def test_rao_every_eq_file_of_the_fixture_gives_the_same_maps_streamed_and_with_rdflib(eq_files):
    total = 0
    for path in eq_files:
        streamed = eq_stream.stream_eq(path)
        assert streamed is not None, f"{path.name} falls back to rdflib"
        from_rdflib = _maps(ncp_parser._load_graph(path, cache=False), path)
        from_stream = _maps(streamed, path)
        assert from_stream == from_rdflib, path.name
        total += sum(len(m) for m in from_stream)
    assert total > 100                      # the comparison is not an empty one


def test_rao_the_streamed_subjects_are_those_of_rdflib(eq_files):
    path = max(eq_files, key=lambda p: p.stat().st_size)
    streamed, graph = eq_stream.stream_eq(path), ncp_parser._load_graph(path, cache=False)
    for local in sorted(eq_stream.LISTED_CLASSES):
        for namespace in eq_stream.CIM_NAMESPACES:
            term = URIRef(namespace + local)
            assert sorted(ncp_parser._frag(str(s)) for s in streamed.subjects(RDF.type, term)) == \
                   sorted(ncp_parser._frag(str(s)) for s in graph.subjects(RDF.type, term)), (local, namespace)


def test_rao_the_stream_is_much_faster_than_rdflib(eq_files):
    path = max(eq_files, key=lambda p: p.stat().st_size)
    start = time.perf_counter()
    eq_stream.stream_eq(path)
    streamed_seconds = time.perf_counter() - start
    start = time.perf_counter()
    ncp_parser._load_graph(path, cache=False)
    rdflib_seconds = time.perf_counter() - start
    print(f"{path.name} ({path.stat().st_size / 1e6:.1f} MB): stream {streamed_seconds:.2f} s, rdflib {rdflib_seconds:.2f} s")
    assert streamed_seconds * 3 < rdflib_seconds


# ---------------------------------------------------------------------------
# hand-written files
# ---------------------------------------------------------------------------

def _eq(tmp_path, body, namespace=CIM, name="X_EQ_1.xml"):
    path = tmp_path / name
    path.write_text(
        f'<?xml version="1.0" encoding="UTF-8"?><rdf:RDF xmlns:rdf="http://www.w3.org/1999/02/22-rdf-syntax-ns#" '
        f'xmlns:cim="{namespace}">{body}</rdf:RDF>', encoding=TEXT_ENCODING)
    return path


CHAIN = """
<cim:PhaseTapChangerAsymmetrical rdf:ID="_tc1"><cim:IdentifiedObject.mRID>TC-1</cim:IdentifiedObject.mRID>
  <cim:TapChanger.TransformerEnd rdf:resource="#_end1"/></cim:PhaseTapChangerAsymmetrical>
<cim:PhaseTapChangerTabular rdf:ID="_tc2"><cim:PhaseTapChanger.TransformerEnd rdf:resource="#_end2"/></cim:PhaseTapChangerTabular>
<cim:PowerTransformerEnd rdf:ID="_end1"><cim:PowerTransformerEnd.PowerTransformer rdf:resource="#_pt1"/></cim:PowerTransformerEnd>
<cim:PowerTransformerEnd rdf:ID="_end2"><cim:PowerTransformerEnd.PowerTransformer rdf:resource="#_pt2"/></cim:PowerTransformerEnd>
<cim:PowerTransformer rdf:ID="_pt1"><cim:IdentifiedObject.mRID>PT-ONE</cim:IdentifiedObject.mRID></cim:PowerTransformer>
<cim:PowerTransformer rdf:ID="_pt2"/>
<cim:CurrentLimit rdf:ID="_cl1"><cim:OperationalLimit.OperationalLimitSet rdf:resource="#_ols1"/></cim:CurrentLimit>
<cim:CurrentLimit rdf:ID="_cl2"><cim:IdentifiedObject.mRID>CL-2</cim:IdentifiedObject.mRID>
  <cim:OperationalLimit.OperationalLimitSet rdf:resource="#_ols2"/></cim:CurrentLimit>
<cim:CurrentLimit rdf:ID="_cl3"><cim:OperationalLimit.OperationalLimitSet rdf:resource="#_ols3"/></cim:CurrentLimit>
<cim:CurrentLimit rdf:ID="_cl4"/>
<cim:OperationalLimitSet rdf:ID="_ols1"><cim:OperationalLimitSet.Terminal rdf:resource="#_t1"/></cim:OperationalLimitSet>
<cim:OperationalLimitSet rdf:ID="_ols2"><cim:OperationalLimitSet.Terminal rdf:resource="#_t2"/></cim:OperationalLimitSet>
<cim:OperationalLimitSet rdf:ID="_ols3"><cim:OperationalLimitSet.Terminal rdf:resource="#_t3"/></cim:OperationalLimitSet>
<cim:Terminal rdf:ID="_t1"><cim:ACDCTerminal.sequenceNumber>1</cim:ACDCTerminal.sequenceNumber></cim:Terminal>
<cim:Terminal rdf:ID="_t2"><cim:ACDCTerminal.sequenceNumber>2</cim:ACDCTerminal.sequenceNumber></cim:Terminal>
<cim:Terminal rdf:ID="_t3"><cim:ACDCTerminal.sequenceNumber>7</cim:ACDCTerminal.sequenceNumber></cim:Terminal>
<cim:ControlAreaGeneratingUnit rdf:ID="_c1"><cim:ControlAreaGeneratingUnit.ControlArea rdf:resource="#_ca1"/>
  <cim:ControlAreaGeneratingUnit.GeneratingUnit rdf:resource="#_gu1"/></cim:ControlAreaGeneratingUnit>
<cim:ControlAreaGeneratingUnit rdf:ID="_c2"><cim:ControlAreaGeneratingUnit.ControlArea rdf:resource="#_ca1"/></cim:ControlAreaGeneratingUnit>
"""


@pytest.mark.parametrize("namespace", [CIM, CIM_OTHER])
def test_rao_a_hand_written_file_gives_the_same_maps_in_both_namespaces(tmp_path, namespace, caplog):
    path = _eq(tmp_path, CHAIN, namespace)
    streamed = eq_stream.stream_eq(path)
    assert streamed is not None
    with caplog.at_level(logging.WARNING, logger=ncp_parser.log.name):
        from_stream = _maps(streamed, path)
    stream_warnings = sorted(r.getMessage() for r in caplog.records)
    caplog.clear()
    with caplog.at_level(logging.WARNING, logger=ncp_parser.log.name):
        from_rdflib = _maps(ncp_parser._load_graph(path, cache=False), path)
    assert from_stream == from_rdflib
    assert sorted(r.getMessage() for r in caplog.records) == stream_warnings          # the same log lines
    tap_changers, sides, rows = from_stream
    assert tap_changers == {"TC-1": "PT-ONE", "tc2": "pt2"}
    assert sides == {"cl1": 1, "CL-2": 2}                                             # the side 7 is warned about and skipped
    assert rows == [("ca1", "gu1")]


def test_rao_the_first_value_wins_and_an_about_element_adds_to_its_subject(tmp_path):
    path = _eq(tmp_path, """
        <cim:CurrentLimit rdf:ID="_cl1"><cim:OperationalLimit.OperationalLimitSet rdf:resource="#_ols1"/></cim:CurrentLimit>
        <cim:OperationalLimitSet rdf:ID="_ols1"><cim:OperationalLimitSet.Terminal rdf:resource="#_t1"/></cim:OperationalLimitSet>
        <cim:Terminal rdf:ID="_t1"><cim:ACDCTerminal.sequenceNumber>2</cim:ACDCTerminal.sequenceNumber></cim:Terminal>
        <cim:Terminal rdf:about="#_t1"><cim:ACDCTerminal.sequenceNumber>1</cim:ACDCTerminal.sequenceNumber></cim:Terminal>
    """)
    assert _maps(eq_stream.stream_eq(path), path) == _maps(ncp_parser._load_graph(path, cache=False), path)


@pytest.mark.parametrize("body", [
    # a held subject without an id
    '<cim:CurrentLimit><cim:OperationalLimit.OperationalLimitSet rdf:resource="#_x"/></cim:CurrentLimit>',
    # a reference that is not a local id
    '<cim:CurrentLimit rdf:ID="_a"><cim:OperationalLimit.OperationalLimitSet rdf:resource="http://other/file.xml#_x"/></cim:CurrentLimit>',
    # a reference with a nested node
    '<cim:CurrentLimit rdf:ID="_a"><cim:OperationalLimit.OperationalLimitSet><cim:OperationalLimitSet rdf:ID="_y"/></cim:OperationalLimit.OperationalLimitSet></cim:CurrentLimit>',
    # a literal that is a resource
    '<cim:Terminal rdf:ID="_t"><cim:ACDCTerminal.sequenceNumber rdf:resource="#_x"/></cim:Terminal>',
    # a property with a parseType
    '<cim:Terminal rdf:ID="_t"><cim:ACDCTerminal.sequenceNumber rdf:parseType="Literal">1</cim:ACDCTerminal.sequenceNumber></cim:Terminal>',
])
def test_rao_a_file_the_stream_cannot_answer_exactly_is_left_to_rdflib(tmp_path, body):
    path = _eq(tmp_path, body)
    assert eq_stream.stream_eq(path) is None
    assert not isinstance(ncp_parser.load_eq_graph(path), eq_stream.StreamedEq)


def test_rao_a_file_that_is_not_xml_is_left_to_rdflib(tmp_path):
    path = tmp_path / "X_EQ_1.xml"
    path.write_text("not xml", encoding=TEXT_ENCODING)
    assert eq_stream.stream_eq(path) is None


def test_rao_the_stream_refuses_a_question_it_does_not_hold(tmp_path):
    streamed = eq_stream.stream_eq(_eq(tmp_path, CHAIN))
    with pytest.raises(ValueError):
        streamed.subjects(RDF.type, URIRef(CIM + "Terminal"))
    with pytest.raises(ValueError):
        streamed.value(URIRef("#_t1"), URIRef(CIM + "Terminal.ConductingEquipment"))
    assert streamed.value(URIRef("#nobody"), URIRef(CIM + "IdentifiedObject.mRID")) is None


def test_rao_load_eq_graph_streams_a_plain_file_and_the_fixture_run_uses_it(eq_files):
    assert isinstance(ncp_parser.load_eq_graph(eq_files[0]), eq_stream.StreamedEq)


def test_rao_a_generated_file_of_30_mb_is_read_in_a_few_mb(tmp_path):
    count = 40000
    parts = []
    for i in range(count):
        parts.append(
            f'<cim:CurrentLimit rdf:ID="_cl{i}"><cim:CurrentLimit.normalValue>1000</cim:CurrentLimit.normalValue>'
            f'<cim:IdentifiedObject.mRID>cl{i}</cim:IdentifiedObject.mRID><cim:IdentifiedObject.name>patl for {i}</cim:IdentifiedObject.name>'
            f'<cim:OperationalLimit.OperationalLimitSet rdf:resource="#_ols{i}"/></cim:CurrentLimit>'
            f'<cim:OperationalLimitSet rdf:ID="_ols{i}"><cim:IdentifiedObject.mRID>ols{i}</cim:IdentifiedObject.mRID>'
            f'<cim:OperationalLimitSet.Terminal rdf:resource="#_t{i}"/></cim:OperationalLimitSet>'
            f'<cim:Terminal rdf:ID="_t{i}"><cim:ACDCTerminal.sequenceNumber>{1 + i % 2}</cim:ACDCTerminal.sequenceNumber>'
            f'<cim:IdentifiedObject.name>{"x" * 150}</cim:IdentifiedObject.name></cim:Terminal>')
    path = _eq(tmp_path, "".join(parts))
    size_mb = path.stat().st_size / 1e6
    tracemalloc.start()
    start = time.perf_counter()
    streamed = eq_stream.stream_eq(path)
    sides = ncp_parser.build_current_limit_side_map(path, graph=streamed)
    seconds = time.perf_counter() - start
    peak_mb = tracemalloc.get_traced_memory()[1] / 1e6
    tracemalloc.stop()
    print(f"generated EQ file {size_mb:.1f} MB: {seconds:.1f} s, peak {peak_mb:.0f} MB")
    assert len(sides) == count and sides["cl3"] == 2
    assert size_mb > 15 and peak_mb < 60 and seconds < 60
