"""resolve_glsk in the standard form (WP4): CIM GeneratingUnit ids mapped to generators, both unit routes (bid and
strategy), resources that are not generating units dropped with a warning, participation factors normalised
with a warning, optional atTime and interpolationKind of the shift key schedule."""
import logging
from pathlib import Path

import pytest

from data_model import RAKind, RDUnit
from pre_milp import glsk_resolver
from text_encoding import TEXT_ENCODING

HEADER = """<?xml version="1.0" encoding="UTF-8"?>
<rdf:RDF
    xmlns:rdf="http://www.w3.org/1999/02/22-rdf-syntax-ns#"
    xmlns:nc="https://cim4.eu/ns/nc#"
    xmlns:cim="https://cim.ucaiug.io/ns#">
"""
FOOTER = "</rdf:RDF>\n"
TIME = "2022-06-15T10:30:00Z"
INTERPOLATION = "https://cim4.eu/ns/nc#TimeSeriesInterpolationKind."


def _unit(ra="RA1"):
    return RDUnit(mrid=ra, name=ra, tso="T", gu_mrid="G", gu_name="G", available=True, kind=RAKind.PREVENTIVE,
                  initial_p=0.0, max_p=100.0, min_p=0.0, raise_ramp_rate=None, lower_ramp_rate=None)


def _write(tmp_path, name, body):
    path = tmp_path / name
    path.write_text(HEADER + body + FOOTER, encoding=TEXT_ENCODING)
    return path


def _bid_route(ra, psks, dist=None):
    dist = dist or f"D-{ra}-{psks}"
    bid = "" if dist.startswith("D2") or dist.startswith("D3") else f"""
    <nc:PowerBidSchedule rdf:ID="_PB-{ra}">
      <cim:IdentifiedObject.mRID>PB-{ra}</cim:IdentifiedObject.mRID>
      <nc:PowerBidSchedule.PowerRemedialAction rdf:resource="#_{ra}"/>
    </nc:PowerBidSchedule>"""
    return bid + f"""
    <nc:PowerShiftKeyDistribution rdf:ID="_{dist}">
      <nc:PowerShiftKeyDistribution.PowerBidSchedule rdf:resource="#_PB-{ra}"/>
      <nc:PowerShiftKeyDistribution.PowerShiftKeySchedule rdf:resource="#_{psks}"/>
    </nc:PowerShiftKeyDistribution>"""


def _strategy_route(strategy, psks, dist=None):
    dist = dist or f"D-{strategy}-{psks}"
    return f"""
    <nc:PowerShiftKeyDistribution rdf:ID="_{dist}">
      <nc:PowerShiftKeyDistribution.PowerShiftKeyStrategy rdf:resource="#_{strategy}"/>
      <nc:PowerShiftKeyDistribution.PowerShiftKeySchedule rdf:resource="#_{psks}"/>
    </nc:PowerShiftKeyDistribution>"""


def _key(psks, unit, factor=1.0, resource="GeneratingUnit", at=TIME, interpolation=None):
    kind = f'<nc:BaseTimeSeries.interpolationKind rdf:resource="{INTERPOLATION}{interpolation}"/>' if interpolation else ""
    points = factor if isinstance(factor, list) else [(at, factor)]
    point_xml = "".join(f"""
    <nc:ParticipationFactorTimePoint rdf:ID="_{psks}-P{i}">
      {f'<nc:ParticipationFactorTimePoint.atTime>{when}</nc:ParticipationFactorTimePoint.atTime>' if when else ''}
      <nc:ParticipationFactorTimePoint.participationFactor>{value}</nc:ParticipationFactorTimePoint.participationFactor>
      <nc:ParticipationFactorTimePoint.PowerShiftKeySchedule rdf:resource="#_{psks}"/>
    </nc:ParticipationFactorTimePoint>""" for i, (when, value) in enumerate(points))
    return f"""
    <nc:PowerShiftKeySchedule rdf:ID="_{psks}">
      <cim:IdentifiedObject.mRID>{psks}</cim:IdentifiedObject.mRID>
      <nc:PowerShiftKeySchedule.{resource} rdf:resource="#_{unit}"/>
      {kind}
    </nc:PowerShiftKeySchedule>{point_xml}"""


def _strategy(strategy, ra):
    return f"""
    <nc:PowerShiftKeyStrategy rdf:about="#_{strategy}">
      <nc:PowerShiftKeyStrategy.PowerRemedialAction rdf:resource="#_{ra}"/>
      <cim:IdentifiedObject.mRID>{strategy}</cim:IdentifiedObject.mRID>
    </nc:PowerShiftKeyStrategy>"""


def _resolve(tmp_path, sis_body, caplog=None, ra_body=None, units=None, timestamp="1030Z", valid=("G1", "G2"), by_unit=None, name="Test"):
    sis = _write(tmp_path, f"{name}_SIS.xml", sis_body)
    ra = _write(tmp_path, f"{name}_RA.xml", ra_body) if ra_body is not None else None
    kwargs = dict(generators_by_unit=by_unit, ra_path=ra)

    def call():
        return glsk_resolver.resolve_glsk(sis, units or [_unit()], "T", set(valid), timestamp, **kwargs)

    if caplog is None:
        return call()
    with caplog.at_level(logging.WARNING):
        return call()


def _warnings(caplog, *words):
    return [r.getMessage() for r in caplog.records if r.levelno >= logging.WARNING and all(w in r.getMessage() for w in words)]


MAP = {"GU-A": ["G1"], "GU-B": ["G2"]}


def test_a_generating_unit_id_is_mapped_to_its_generator(tmp_path, caplog):
    result = _resolve(tmp_path, _bid_route("RA1", "K1") + _key("K1", "GU-A"), caplog, by_unit=MAP)
    assert result == {"RA1": {"G1": 1.0}}
    assert _warnings(caplog, "deprecated") == []


def test_a_generator_id_in_the_shift_key_is_the_old_form_with_one_deprecation_warning(tmp_path, caplog):
    body = _bid_route("RA1", "K1") + _key("K1", "G1") + _bid_route("RA2", "K2") + _key("K2", "G2")
    result = _resolve(tmp_path, body, caplog, units=[_unit("RA1"), _unit("RA2")], by_unit=MAP)
    assert result == {"RA1": {"G1": 1.0}, "RA2": {"G2": 1.0}}
    messages = _warnings(caplog, "deprecated")
    assert len(messages) == 1 and "Test_SIS.xml" in messages[0]


def test_a_unit_with_several_generators_is_dropped_with_a_warning(tmp_path, caplog):
    result = _resolve(tmp_path, _bid_route("RA1", "K1") + _key("K1", "GU-A"), caplog, by_unit={"GU-A": ["G1", "G2"]})
    assert result == {"RA1": {}}
    assert len(_warnings(caplog, "GU-A", "2 generators")) == 1


def test_the_strategy_route_resolves_an_ra_without_a_bid_route(tmp_path, caplog):
    sis = _strategy_route("S1", "K1") + _key("K1", "GU-A")
    result = _resolve(tmp_path, sis, caplog, ra_body=_strategy("S1", "RA1"), by_unit=MAP)
    assert result == {"RA1": {"G1": 1.0}}


def test_the_bid_route_wins_over_the_strategy_route(tmp_path):
    sis = _bid_route("RA1", "K1") + _key("K1", "GU-A") + _strategy_route("S1", "K2") + _key("K2", "GU-B")
    assert _resolve(tmp_path, sis, ra_body=_strategy("S1", "RA1"), by_unit=MAP) == {"RA1": {"G1": 1.0}}


def test_the_strategy_route_is_the_fallback_when_the_bid_route_has_no_key(tmp_path):
    sis = _bid_route("RA1", "K-MISSING") + _strategy_route("S1", "K2") + _key("K2", "GU-B")
    assert _resolve(tmp_path, sis, ra_body=_strategy("S1", "RA1"), by_unit=MAP) == {"RA1": {"G2": 1.0}}


def test_a_strategy_route_without_the_ra_file_gives_an_empty_glsk(tmp_path, caplog):
    sis = _strategy_route("S1", "K1") + _key("K1", "GU-A")
    assert _resolve(tmp_path, sis, caplog, by_unit=MAP) == {"RA1": {}}


def test_resources_that_are_not_generating_units_are_dropped_with_a_counting_warning(tmp_path, caplog):
    sis = (_bid_route("RA1", "K1") + _key("K1", "GU-A", 0.5)
           + _bid_route("RA1", "K2", dist="D2") + _key("K2", "LOAD-1", 0.3, resource="EnergyConsumer")
           + _bid_route("RA1", "K3", dist="D3") + _key("K3", "PE-1", 0.2, resource="PowerElectronicsUnit"))
    result = _resolve(tmp_path, sis, caplog, by_unit=MAP)
    assert result == {"RA1": {"G1": 1.0}}
    messages = _warnings(caplog, "RA1", "not a GeneratingUnit")
    assert len(messages) == 1 and "2 " in messages[0] and "EnergyConsumer" in messages[0] and "PowerElectronicsUnit" in messages[0]


def test_participation_factors_are_normalised_and_a_sum_other_than_one_is_warned_about(tmp_path, caplog):
    sis = (_bid_route("RA1", "K1") + _key("K1", "GU-A", 0.3) + _bid_route("RA1", "K2", dist="D2") + _key("K2", "GU-B", 0.3))
    result = _resolve(tmp_path, sis, caplog, by_unit=MAP)
    assert result == {"RA1": {"G1": 0.5, "G2": 0.5}}
    messages = _warnings(caplog, "RA1", "participation factors")
    assert len(messages) == 1 and "0.6" in messages[0] and "normalised" in messages[0]


def test_participation_factors_that_sum_to_one_give_no_warning(tmp_path, caplog):
    sis = (_bid_route("RA1", "K1") + _key("K1", "GU-A", 0.25) + _bid_route("RA1", "K2", dist="D2") + _key("K2", "GU-B", 0.75))
    assert _resolve(tmp_path, sis, caplog, by_unit=MAP) == {"RA1": {"G1": 0.25, "G2": 0.75}}
    assert _warnings(caplog, "participation factors") == []


def test_a_participation_factor_without_a_time_is_valid_at_every_timestamp(tmp_path):
    sis = _bid_route("RA1", "K1") + _key("K1", "GU-A", [(None, 0.4)])
    assert _resolve(tmp_path, sis, by_unit=MAP, timestamp="1230Z") == {"RA1": {"G1": 1.0}}


TWO_FACTORS = [("2022-06-15T10:30:00Z", 0.2), ("2022-06-15T11:30:00Z", 0.6)]


@pytest.mark.parametrize("kind, expected_share_of_a", [("previous", 0.2 / 0.6), ("next", 0.6 / 1.0), ("linear", 0.4 / 0.8)])
def test_the_interpolation_kind_of_the_shift_key_gives_the_factor_between_time_points(tmp_path, kind, expected_share_of_a):
    """Key A has factors at 1030Z and 1130Z, key B a constant 0.4; the timestamp 1100Z lies between."""
    sis = (_bid_route("RA1", "KA") + _key("KA", "GU-A", TWO_FACTORS, interpolation=kind)
           + _bid_route("RA1", "KB", dist="D2") + _key("KB", "GU-B", [(None, 0.4)], interpolation=kind))
    result = _resolve(tmp_path, sis, by_unit=MAP, timestamp="1100Z")
    assert result["RA1"]["G1"] == pytest.approx(expected_share_of_a)
    assert result["RA1"]["G1"] + result["RA1"]["G2"] == pytest.approx(1.0)


def test_without_interpolation_a_factor_between_time_points_is_missing(tmp_path, caplog):
    sis = (_bid_route("RA1", "KA") + _key("KA", "GU-A", TWO_FACTORS, interpolation="none")
           + _bid_route("RA1", "KB", dist="D2") + _key("KB", "GU-B", [(None, 0.4)]))
    result = _resolve(tmp_path, sis, caplog, by_unit=MAP, timestamp="1100Z")
    assert result == {"RA1": {"G2": 1.0}}


def test_shift_keys_without_interpolation_kind_use_none_with_one_warning(tmp_path, caplog):
    sis = (_bid_route("RA1", "KA") + _key("KA", "GU-A", 0.5) + _bid_route("RA1", "KB", dist="D2") + _key("KB", "GU-B", 0.5))
    _resolve(tmp_path, sis, caplog, by_unit=MAP)
    messages = _warnings(caplog, "interpolationKind")
    assert len(messages) == 1 and "2 PowerShiftKeySchedule" in messages[0] and "none" in messages[0]
