"""tests/test_rao_run_time.py - the run time comes from the CGM: when the NCP files have time points on the CGM's date,
the run takes that date and hour and every time-point reader (bids, PATL, participation factors, unit costs, group
limits) uses the points of that date and time; otherwise each reader falls back and the existing data behaves as
before. Data from mock_data/multiday.py (values that depend on the day)."""

import csv
import datetime
import logging
import math

import pytest

from data_model import RAKind, RDUnit
from pre_milp import glsk_resolver, ncp_parser, run_time
from mock_data import multiday

DAY16 = datetime.date(2022, 6, 16).toordinal()
RUN = run_time.RunTime(day=DAY16, minute=23 * 60 + 30)


@pytest.fixture()
def files(tmp_path):
    return multiday.write_series_files(tmp_path)


@pytest.fixture()
def at_run_time():
    with run_time.run_time_scope():
        run_time.set_run_time(RUN)
        yield


def _warnings(caplog, *words):
    return [r.getMessage() for r in caplog.records if r.levelno >= logging.WARNING and all(w in r.getMessage() for w in words)]


# --- choosing the run time ------------------------------------------------------------------------------

def _minutes(day, hour, minute):
    return day * 1440 + hour * 60 + minute


def test_rao_the_cgm_time_is_the_run_time_when_it_is_inside_a_series_of_the_ncp():
    cgm = datetime.datetime(2022, 6, 16, 23, 30, tzinfo=datetime.timezone.utc)
    spans = [(_minutes(DAY16 - 1, 10, 30), _minutes(DAY16 - 1, 10, 30)), (_minutes(DAY16 - 1, 0, 30), _minutes(DAY16 + 1, 0, 30))]
    chosen, why = run_time.choose_run_time(cgm, spans)
    assert chosen == RUN and "2022-06-16T23:30Z" in why
    assert run_time.choose_run_time(cgm, [(_minutes(DAY16, 23, 30), _minutes(DAY16, 23, 30))])[0] == RUN      # a single point at that time


@pytest.mark.parametrize("cgm, spans, reason", [
    (None, [(0, 10)], "no scenario time"),
    (datetime.datetime(2022, 6, 16, 23, 30, tzinfo=datetime.timezone.utc), [], "no dated time-point series"),
    (datetime.datetime(2022, 6, 16, 23, 30, tzinfo=datetime.timezone.utc),
     [(_minutes(DAY16 - 1, 22, 30), _minutes(DAY16, 0, 30)), (_minutes(DAY16 + 400, 0, 0), _minutes(DAY16 + 400, 23, 45))], "inside no time-point series"),
])
def test_rao_outside_every_series_there_is_no_run_time_and_the_reason_is_named(cgm, spans, reason):
    chosen, why = run_time.choose_run_time(cgm, spans)
    assert chosen is None and reason in why


def test_rao_the_series_of_the_ncp_files_are_found_by_schedule(files):
    spans = run_time.ncp_series_spans(files.values())
    first, last = _minutes(DAY16 - 1, 0, 30), _minutes(DAY16 + 1, 23, 30)
    assert spans and all(span == (first, last) for span in spans)
    assert len(spans) == 6              # bids, two participation keys, unit costs, group limits, PATL


def _sis_with_one_bid_point(tmp_path, at_time):
    path = tmp_path / "X_SIS.xml"
    path.write_text(multiday.HEADER + (
        '<nc:PowerBidSchedule rdf:ID="_S1"><nc:PowerBidSchedule.PowerRemedialAction rdf:resource="#_RA1"/></nc:PowerBidSchedule>'
        f'<nc:PowerBidScheduleTimePoint rdf:ID="_P1"><nc:PowerBidScheduleTimePoint.atTime>{at_time}</nc:PowerBidScheduleTimePoint.atTime>'
        '<nc:PowerBidScheduleTimePoint.PowerBidSchedule rdf:resource="#_S1"/><nc:PowerBidScheduleTimePoint.p>10</nc:PowerBidScheduleTimePoint.p>'
        "</nc:PowerBidScheduleTimePoint>") + multiday.FOOTER, encoding="utf-8")
    return path


def test_rao_a_series_of_one_point_exactly_at_the_cgm_date_and_hour_gives_the_run_time(tmp_path):
    """The span test is inclusive (DECISIONS 138): one point at the CGM's date and hour is a series that contains it."""
    cgm = datetime.datetime(2022, 6, 16, 23, 30, tzinfo=datetime.timezone.utc)
    spans = run_time.ncp_series_spans([_sis_with_one_bid_point(tmp_path, "2022-06-16T23:30:00Z")])
    assert len(spans) == 1 and spans[0][0] == spans[0][1]
    assert run_time.choose_run_time(cgm, spans)[0] == RUN


@pytest.mark.parametrize("at_time", ["2022-06-16T22:30:00Z", "2022-06-16T23:45:00Z", "2022-06-15T23:30:00Z"])
def test_rao_a_single_point_at_another_hour_or_day_does_not(tmp_path, at_time):
    cgm = datetime.datetime(2022, 6, 16, 23, 30, tzinfo=datetime.timezone.utc)
    chosen, why = run_time.choose_run_time(cgm, run_time.ncp_series_spans([_sis_with_one_bid_point(tmp_path, at_time)]))
    assert chosen is None and "inside no time-point series" in why


# --- every reader ---------------------------------------------------------------------------------------

def test_rao_bids_read_the_run_date_and_the_next_day_after_midnight(files, at_run_time):
    graph = ncp_parser._load_graph(files["SIS"])
    bids = ncp_parser.parse_power_bids(graph, {"RA1"}, "X", ["2330Z", "0030Z"])
    assert bids[0].available_mw == {"2330Z": multiday.bid_mw(1, False), "0030Z": multiday.bid_mw(2, True)}


def test_rao_patl_reads_the_run_date_and_the_next_day_after_midnight(files, at_run_time):
    elements = ncp_parser.parse_assessed_elements(files["AE"], files["SHS"], "X", ["2330Z", "0030Z"], {})
    assert elements[0].patl_ka == {"2330Z": multiday.patl_ampere(1, False) / 1000, "0030Z": multiday.patl_ampere(2, True) / 1000}


def test_rao_participation_factors_read_the_run_date(files, at_run_time):
    unit = RDUnit(mrid="RA1", name="RA1", tso="X", gu_mrid="G", gu_name="G", available=True, kind=RAKind.PREVENTIVE,
                  initial_p=0.0, max_p=100.0, min_p=0.0, raise_ramp_rate=None, lower_ramp_rate=None)
    result = glsk_resolver.resolve_glsk(files["SIS"], [unit], "X", {"GU-A", "GU-B"}, "2330Z")
    f = multiday.key_factor(1)
    assert result["RA1"] == pytest.approx({"GU-A": f / (f + 1), "GU-B": 1 / (f + 1)})


def test_rao_unit_costs_read_the_run_date(files, at_run_time):
    costs = ncp_parser.parse_unit_costs(files["SIS"], None, "X", "2330Z")
    assert costs["GU-A"].startup_cost_eur == multiday.startup_cost(1)


def test_rao_group_limits_read_the_run_date(files, at_run_time):
    groups = ncp_parser.parse_ra_groups(files["RA"], files["SIS"], "X", "2330Z")
    assert groups["G1"]["max_regulating_up"] == multiday.group_limit(1)


def test_rao_another_run_date_reads_another_day(files):
    with run_time.run_time_scope():
        run_time.set_run_time(run_time.RunTime(day=DAY16 + 1, minute=23 * 60 + 30))
        assert ncp_parser.parse_unit_costs(files["SIS"], None, "X", "2330Z")["GU-A"].startup_cost_eur == multiday.startup_cost(2)
        assert ncp_parser.parse_ra_groups(files["RA"], files["SIS"], "X", "2330Z")["G1"]["max_regulating_up"] == multiday.group_limit(2)


def test_rao_a_run_date_without_points_reads_nothing_not_another_day(files):
    with run_time.run_time_scope():
        run_time.set_run_time(run_time.RunTime(day=DAY16 + 30, minute=23 * 60 + 30))
        assert ncp_parser.parse_unit_costs(files["SIS"], None, "X", "2330Z") == {}
        assert ncp_parser.parse_ra_groups(files["RA"], files["SIS"], "X", "2330Z")["G1"]["max_regulating_up"] is None


# --- the fallback ---------------------------------------------------------------------------------------

def test_rao_without_a_run_time_the_other_readers_match_by_clock_time_and_a_multi_day_series_is_warned_about(files, caplog):
    with caplog.at_level(logging.WARNING):
        costs = ncp_parser.parse_unit_costs(files["SIS"], None, "X", "2330Z")
        groups = ncp_parser.parse_ra_groups(files["RA"], files["SIS"], "X", "2330Z")
        patl = ncp_parser.parse_assessed_elements(files["AE"], files["SHS"], "X", ["2330Z"], {})
    # the old behaviour: one point of the three days wins (which one is not defined), nothing is read from "another" day
    assert costs["GU-A"].startup_cost_eur in {multiday.startup_cost(i) for i in range(3)}
    assert groups["G1"]["max_regulating_up"] in {multiday.group_limit(i) for i in range(3)}
    assert patl[0].patl_ka["2330Z"] in {multiday.patl_ampere(i, False) / 1000 for i in range(3)}
    fallback = _warnings(caplog, "fallback", "matched by clock time only")
    assert len(fallback) == 3 and any("unit costs" in m for m in fallback) and any("PATL" in m for m in fallback)


def test_rao_without_a_run_time_a_bid_on_several_days_uses_its_earliest_day_with_a_warning(files, caplog):
    graph = ncp_parser._load_graph(files["SIS"])
    with caplog.at_level(logging.WARNING):
        bids = ncp_parser.parse_power_bids(graph, {"RA1"}, "X", ["2330Z"])
    assert bids[0].available_mw == {"2330Z": multiday.bid_mw(0, False)}
    assert _warnings(caplog, "time points on several days", "2022-06-15")


def test_rao_without_a_run_time_a_series_on_one_day_is_read_by_clock_time_as_before(tmp_path, caplog):
    path = tmp_path / "X_SIS.xml"
    path.write_text(multiday.HEADER + '<nc:UnitCostSchedule rdf:ID="_US1"><nc:UnitCostSchedule.GeneratingUnit rdf:resource="#_GU-A"/></nc:UnitCostSchedule>'
                    '<nc:UnitCostTimePoint rdf:ID="_UC"><nc:UnitCostTimePoint.atTime>2031-01-01T23:30:00Z</nc:UnitCostTimePoint.atTime>'
                    '<nc:UnitCostTimePoint.UnitCostSchedule rdf:resource="#_US1"/><nc:UnitCostTimePoint.startupCost>5</nc:UnitCostTimePoint.startupCost>'
                    "</nc:UnitCostTimePoint>" + multiday.FOOTER, encoding="utf-8")
    with caplog.at_level(logging.WARNING):
        assert ncp_parser.parse_unit_costs(path, None, "X", "2330Z")["GU-A"].startup_cost_eur == 5.0
    assert _warnings(caplog, "fallback") == []


# --- the whole pipeline ---------------------------------------------------------------------------------

def _summary(output_dir):
    return {row[0]: row[1] for row in csv.reader(open(output_dir / "results_summary.csv", encoding="utf-8")) if row}


def _log(output_dir):
    return (output_dir / "run_log.txt").read_text(encoding="utf-8", errors="replace")


def test_rao_the_mock_keeps_its_start_hour_and_logs_the_fallback(tmp_path):
    from helpers import run_pipeline_on_fixture_inputs, _MOCK_NX_NCP_ZIP
    run = run_pipeline_on_fixture_inputs(tmp_path, _MOCK_NX_NCP_ZIP, enable_nx_analysis=False)
    log = _log(run.output_dir)
    assert "Run time: the CGM scenario time 2022-06-16T23:30Z is inside no time-point series of the NCP files" in log
    assert "the start hour 1030Z of the pipeline is kept" in log


def test_rao_ncp_data_on_the_date_and_hour_of_the_cgm_gives_the_same_result_as_the_mock(tmp_path):
    """The mock NCP moved by 37 hours lies on the CGM's date and hour (2022-06-16T23:30Z): the run takes the CGM time
    (start hour 2330Z, every point read by date and time) and finds the same optimum as the mock at 10:30."""
    from helpers import run_pipeline_on_fixture_inputs, _MOCK_NX_NCP_ZIP
    shifted = tmp_path / "shifted.zip"
    assert multiday.shift_time_points(_MOCK_NX_NCP_ZIP, shifted, 37) > 100
    plain = run_pipeline_on_fixture_inputs(tmp_path / "plain", _MOCK_NX_NCP_ZIP, enable_nx_analysis=True)
    moved = run_pipeline_on_fixture_inputs(tmp_path / "moved", shifted, enable_nx_analysis=True)
    assert "Run time from the CGM: the CGM scenario time 2022-06-16T23:30Z - start hour 2330Z" in _log(moved.output_dir)
    a, b = _summary(plain.output_dir), _summary(moved.output_dir)
    assert a.keys() == b.keys()
    for key in a:
        try:
            assert math.isclose(float(a[key]), float(b[key]), rel_tol=1e-9, abs_tol=1e-6), key
        except ValueError:
            assert a[key] == b[key], key
