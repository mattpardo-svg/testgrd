"""tests/test_rao_ncp_parser.py - unit tests for ncp_parser.py: the parsers and helpers,
ignored power remedial actions, the assessed-element classification and exclusion rules,
the RD unit Pmax/Pmin default, and curative tap bounds of the ReliCapGrid case. The
ReliCapGrid files come from the fixture zips (helpers.fixture_instance_root).
"""

import csv
import sys
import tempfile
import pytest
import logging
import zipfile

from pathlib import Path
from pre_milp.ncp_parser import _frag, _iso_to_hhmmz, _parse_iso_duration_hours
from pre_milp import ncp_parser
from data_model import AEType, Contingency, ContingencyType, PST, RAKind, AssessedElement
from helpers import FIXTURE_CGM_ZIP, _RA_FOOTER, _RA_HEADER, _write_penalty_factor_ra, fixture_instance_root
from text_encoding import TEXT_ENCODING  # noqa: E402

REPO_SRC = Path(__file__).resolve().parents[1] / "src" / "rao"


# ---------------------------------------------------------------------------
# Helper function tests (no data required)
# ---------------------------------------------------------------------------

class TestFrag:
    def test_hash_fragment(self):
        assert _frag("#_a9dba80c-9dfb") == "a9dba80c-9dfb"

    def test_uri_fragment(self):
        assert _frag("https://cim.ucaiug.io/ns#ControlArea") == "ControlArea"

    def test_path_fragment(self):
        assert _frag("https://example.com/ns/SomeThing") == "SomeThing"

    def test_strips_leading_underscore(self):
        assert _frag("#_abc-123") == "abc-123"

    def test_no_underscore_unchanged(self):
        assert _frag("#abc-123") == "abc-123"

    def test_enum_fragment(self):
        result = _frag("https://cim4.eu/ns/nc#RemedialActionKind.curative")
        assert result == "RemedialActionKind.curative"


class TestIsoToHhmmz:
    def test_basic_conversion(self):
        assert _iso_to_hhmmz("2023-07-22T10:30:00Z") == "1030Z"

    def test_midnight(self):
        assert _iso_to_hhmmz("2023-07-22T00:00:00Z") == "0000Z"

    def test_end_of_day(self):
        assert _iso_to_hhmmz("2023-07-22T23:30:00Z") == "2330Z"

    def test_invalid_returns_none(self):
        assert _iso_to_hhmmz("not-a-datetime") is None

    def test_empty_returns_none(self):
        assert _iso_to_hhmmz("") is None

    def test_different_date_same_time(self):
        # Only time portion matters
        assert _iso_to_hhmmz("2024-02-22T17:30:00Z") == "1730Z"


class TestParseIsoDurationHours:
    def test_thirty_minutes(self):
        assert _parse_iso_duration_hours("P0Y0M0DT0H30M0S") == 0.5

    def test_one_hour(self):
        assert _parse_iso_duration_hours("P0Y0M0DT1H0M0S") == 1.0

    def test_zero(self):
        assert _parse_iso_duration_hours("P0Y0M0DT0H0M0S") == 0.0

    def test_ninety_minutes(self):
        assert _parse_iso_duration_hours("P0Y0M0DT1H30M0S") == 1.5

    def test_invalid_returns_zero(self):
        assert _parse_iso_duration_hours("not-a-duration") == 0.0

    def test_seconds_only(self):
        # 7200 seconds = 2 hours
        result = _parse_iso_duration_hours("P0Y0M0DT0H0M7200S")
        assert abs(result - 2.0) < 1e-9

    def test_a_day_part_counts(self):
        # R9 rule 9: P1D (no time part) and P1DT2H were read as 0 before
        assert _parse_iso_duration_hours("P1D") == 24.0
        assert _parse_iso_duration_hours("P1DT2H") == 26.0


# ---------------------------------------------------------------------------
# Live parse tests
# ---------------------------------------------------------------------------

DATA_ROOT    = fixture_instance_root()


BELGOVIA_NCP = DATA_ROOT / "Belgovia" / "NetworkCode" / "cimxml"


TS           = ["1030Z", "1130Z", "1230Z", "1330Z"]


class TestParseAssessedElementsLive:
    @pytest.fixture
    def ae_list(self):
        from pre_milp.ncp_parser import parse_assessed_elements
        return parse_assessed_elements(
            BELGOVIA_NCP / "Belgovia_AE.xml",
            BELGOVIA_NCP / "Belgovia_SHS.xml",
            "TSO-Belgovia", TS, {},
        )

    def test_returns_seven_aes(self, ae_list):
        assert len(ae_list) == 7

    def test_four_secured_one_scanned_two_excluded_for_no_region_code(self, ae_list):
        """Two of the seven Belgovia AEs have no region code and no exclusionReason: EXCLUDED.
        AEs with only a ScannedForRegion code and no exclusionReason stay SECURED."""
        assert sum(1 for a in ae_list if a.ae_type == AEType.SECURED) == 4
        assert sum(1 for a in ae_list if a.ae_type == AEType.SCANNED) == 1
        excluded = [a for a in ae_list if a.ae_type == AEType.EXCLUDED]
        assert len(excluded) == 2
        assert all(a.exclusion_reason == "no secured or scanned region code" for a in excluded)

    def test_all_have_branch_mrid(self, ae_list):
        for ae in ae_list:
            assert ae.branch_mrid is not None

    def test_all_have_patl_for_all_timestamps(self, ae_list):
        for ae in ae_list:
            for ts in TS:
                assert ts in ae.patl_ka
                assert ae.patl_ka[ts] >= 0.0

    def test_tso_label_correct(self, ae_list):
        for ae in ae_list:
            assert ae.tso == "TSO-Belgovia"


class TestParseContingenciesLive:
    def test_empty_with_no_cgm_equipment(self):
        from pre_milp.ncp_parser import parse_contingencies
        cos = parse_contingencies(
            BELGOVIA_NCP / "Belgovia_CO.xml",
            "TSO-Belgovia", TS, {},
        )
        # All equipment fails the equipment-type check when the mapping is empty
        assert len(cos) == 0

    def test_returns_contingencies_with_valid_equipment(self):
        from pre_milp.ncp_parser import parse_contingencies
        # the equipment mRIDs of the CO file with their CoMo types (the mapping is type-aware)
        known_equipment = {
            "550ebe0d-f2b2-48c1-991f-cebea43a21aa": "gen",
            "d9622e7f-5bf0-4e7e-b766-b8596c6fe4ae": "line",
            "ed0c5d75-4a54-43c8-b782-b20d7431630b": "line",
            "cb459405-cc14-4215-a45c-416789205904": "load",
        }
        cos = parse_contingencies(
            BELGOVIA_NCP / "Belgovia_CO.xml",
            "TSO-Belgovia", TS, known_equipment,
        )
        assert len(cos) > 0
        for co in cos:
            assert len(co.equipment_mrids) > 0
            assert all(ts in co.must_study for ts in TS)
            assert len(co.equipment_types) == len(co.equipment_mrids)

    def test_belgovia_co3_gen_equipment_type_correctly_resolved(self):
        """Belgovia CO3 trips BO-G2 (a SynchronousMachine): included with
        equipment_types == ['gen']."""
        from pre_milp.ncp_parser import parse_contingencies

        known_equipment = {"550ebe0d-f2b2-48c1-991f-cebea43a21aa": "gen"}
        cos = parse_contingencies(
            BELGOVIA_NCP / "Belgovia_CO.xml",
            "TSO-Belgovia", TS, known_equipment,
        )
        co3 = next((c for c in cos if c.mrid == "37997e71-cb7d-4a8c-baa6-2a1594956da9"), None)
        assert co3 is not None, "CO3 must no longer be silently excluded"
        assert co3.equipment_mrids == ["550ebe0d-f2b2-48c1-991f-cebea43a21aa"]
        assert co3.equipment_types == ["gen"]

    def test_svedala_out_of_range_busbar_contingency_parsed(self):
        """Svedala CO e8e8300b (nc:OutOfRangeContingency, two BusbarSections,
        normalMustStudy=true) is parsed as a must-study contingency (the structured flag is
        trusted over the free-text description)."""
        from pre_milp.ncp_parser import parse_contingencies
        from data_model import ContingencyType

        svedala_co_path = DATA_ROOT / "Svedala" / "NetworkCode" / "cimxml" / "Svedala_CO.xml"
        known_equipment = {
            "e456243c-a5a7-a90a-da42-fa2c0444419e": "busbar",
            "d0bd1e6a-3b97-bacd-03b5-b94365e9b947": "busbar",
        }
        cos = parse_contingencies(svedala_co_path, "TSO-Svedala", TS, known_equipment)
        co = next((c for c in cos if c.mrid == "e8e8300b-e3b1-41ba-81af-406f6e5b4a55"), None)
        assert co is not None, "CO e8e8300b must be parsed — OutOfRangeContingency scanning confirmed working"
        assert co.contingency_type == ContingencyType.OUT_OF_RANGE
        assert set(co.equipment_mrids) == {
            "e456243c-a5a7-a90a-da42-fa2c0444419e", "d0bd1e6a-3b97-bacd-03b5-b94365e9b947",
        }
        assert all(t == "busbar" for t in co.equipment_types)
        assert all(co.must_study.values()), "normalMustStudy=true must be trusted at face value"


class TestParsePSTsLive:
    def test_empty_with_no_cgm_tapchangers(self):
        from pre_milp.ncp_parser import parse_psts
        psts = parse_psts(BELGOVIA_NCP / "Belgovia_RA.xml", "TSO-Belgovia", {}, {})
        assert len(psts) == 0

    def test_returns_pst_with_known_tapchanger(self):
        """Espheim has the dataset's PhaseTapChanger-backed PST RA (TapChanger f6e8823f-...
        -> PowerTransformer 703f5b86-b6c6-4c47-8f6b-55d7d93838c9); Belgovia's only
        TapPositionAction is on a RatioTapChanger (not a PST).
        """
        from pre_milp.ncp_parser import parse_psts, build_tap_changer_to_transformer_map

        espheim_eq_path = DATA_ROOT / "Espheim" / "Grid" / "cimxml" / "20220615T2230Z__Espheim_EQ_1.xml"
        espheim_ra_path = DATA_ROOT / "Espheim" / "NetworkCode" / "cimxml" / "Espheim_RA.xml"
        tap_changer_to_transformer = build_tap_changer_to_transformer_map(espheim_eq_path)

        known_tc = {
            "703f5b86-b6c6-4c47-8f6b-55d7d93838c9": {
                "low_step": -17, "high_step": 17, "r0": 0,
            }
        }
        psts = parse_psts(espheim_ra_path, "TSO-Espheim", known_tc, tap_changer_to_transformer)
        assert len(psts) > 0
        for pst in psts:
            assert pst.low_step <= pst.r0 <= pst.high_step
            assert pst.tso == "TSO-Espheim"


class TestParseRDUnitsLive:
    def test_empty_with_no_cgm_generating_units(self):
        from pre_milp.ncp_parser import parse_rd_units
        rds, bids = parse_rd_units(
            BELGOVIA_NCP / "Belgovia_RA.xml",
            BELGOVIA_NCP / "Belgovia_SIS.xml",
            "TSO-Belgovia", TS, {},
        )
        assert len(rds) == 0
        assert len(bids) == 0

    def test_returns_rd_with_known_generating_unit(self):
        from pre_milp.ncp_parser import parse_rd_units
        known_gu = {
            "550ebe0d-f2b2-48c1-991f-cebea43a21aa": {
                "name": "Generator1", "initial_p": 100.0,
                "max_p": 200.0, "min_p": 0.0,
                "raise_ramp_rate": None, "lower_ramp_rate": None,
            },
            "3a3b27be-b18b-4385-b557-6735d733baf0": {
                "name": "Generator2", "initial_p": 50.0,
                "max_p": 150.0, "min_p": 0.0,
                "raise_ramp_rate": None, "lower_ramp_rate": None,
            },
        }
        rds, bids = parse_rd_units(
            BELGOVIA_NCP / "Belgovia_RA.xml",
            BELGOVIA_NCP / "Belgovia_SIS.xml",
            "TSO-Belgovia", TS, known_gu,
        )
        assert len(rds) > 0
        for rd in rds:
            assert rd.tso == "TSO-Belgovia"
            assert rd.gu_mrid in known_gu


class TestWriteCoFlatListCsv:
    def test_one_row_per_contingency_per_timestamp(self, tmp_path):
        from pre_milp.ncp_parser import write_co_flat_list_csv

        co_list = [
            Contingency(
                mrid="co-1", name="CO1", tso="TSO-Belgovia",
                contingency_type=ContingencyType.ORDINARY,
                must_study={"1030Z": True, "1130Z": False},
                equipment_mrids=["eq-1"], equipment_types=["line"],
            ),
        ]
        output_path = tmp_path / "co_flat_list.csv"
        write_co_flat_list_csv(co_list, output_path)

        rows = list(csv.DictReader(output_path.open(encoding=TEXT_ENCODING)))
        assert len(rows) == 2
        by_ts = {r["timestamp"]: r for r in rows}
        assert by_ts["1030Z"]["must_study"] == "True"
        assert by_ts["1130Z"]["must_study"] == "False"
        for r in rows:
            assert r["contingency_mrid"] == "co-1"
            assert r["contingency_type"] == "OrdinaryContingency"
            assert r["equipment_mrids"] == "eq-1"
            assert r["equipment_type"] == "line"

    def test_multi_equipment_contingency_joins_with_semicolon(self, tmp_path):
        from pre_milp.ncp_parser import write_co_flat_list_csv

        co_list = [
            Contingency(
                mrid="co-1", name="CO1", tso="TSO-Svedala",
                contingency_type=ContingencyType.OUT_OF_RANGE,
                must_study={"1030Z": True},
                equipment_mrids=["eq-1", "eq-2"], equipment_types=["busbar", "busbar"],
            ),
        ]
        output_path = tmp_path / "co_flat_list.csv"
        write_co_flat_list_csv(co_list, output_path)

        rows = list(csv.DictReader(output_path.open(encoding=TEXT_ENCODING)))
        assert len(rows) == 1
        assert rows[0]["equipment_mrids"] == "eq-1;eq-2"
        assert rows[0]["equipment_type"] == "busbar;busbar"
        assert rows[0]["contingency_type"] == "OutOfRangeContingency"

    def test_empty_list_writes_header_only(self, tmp_path):
        from pre_milp.ncp_parser import write_co_flat_list_csv

        output_path = tmp_path / "co_flat_list.csv"
        write_co_flat_list_csv([], output_path)
        rows = list(csv.DictReader(output_path.open(encoding=TEXT_ENCODING)))
        assert rows == []


# ---------------------------------------------------------------------------
# parse_assessed_elements — PATL falls through to the CGM value with a warning (synthetic:
# needs an AE with neither an SHS entry nor a BaseCaseCurrentLimit)
# ---------------------------------------------------------------------------

_SYNTHETIC_AE_NO_NCP_PATL_TEMPLATE = """<?xml version="1.0" encoding="UTF-8"?>
<rdf:RDF
    xmlns:rdf="http://www.w3.org/1999/02/22-rdf-syntax-ns#"
    xmlns:nc="https://cim4.eu/ns/nc#"
    xmlns:cim="https://cim.ucaiug.io/ns#">
  <nc:AssessedElement rdf:ID="_ae-no-ncp-patl">
    <cim:IdentifiedObject.mRID>ae-no-ncp-patl</cim:IdentifiedObject.mRID>
    <cim:IdentifiedObject.name>AE_NO_NCP_PATL</cim:IdentifiedObject.name>
    <nc:AssessedElement.ConductingEquipment rdf:resource="#_branch-1"/>
    <nc:AssessedElement.SecuredForRegion rdf:resource="#_region-1"/>
  </nc:AssessedElement>
</rdf:RDF>
"""


class TestParseAssessedElementsPatlFallbackWarning:
    def test_falls_through_to_cgm_static_with_warning(self, tmp_path, caplog):
        """An AE with neither an SHS entry nor a BaseCaseCurrentLimit falls through to the CGM
        static value, with a warning."""
        from pre_milp.ncp_parser import parse_assessed_elements
        import logging

        ae_path = tmp_path / "Test_AE.xml"
        ae_path.write_text(_SYNTHETIC_AE_NO_NCP_PATL_TEMPLATE, encoding=TEXT_ENCODING)

        cgm_static_patl = {"branch-1": {1: 1000.0}}  # 1000 A = 1.0 kA

        with caplog.at_level(logging.WARNING):
            ae_list = parse_assessed_elements(
                ae_path, None, "TestTSO", ["1030Z"], cgm_static_patl,
            )

        assert len(ae_list) == 1
        assert ae_list[0].patl_ka["1030Z"] == 1.0

        warnings = [r.message for r in caplog.records if r.levelno == logging.WARNING]
        assert any(
            "no PATL in NCP" in w or "using CGM static" in w
            for w in warnings
        ), f"expected a fallback-visibility warning, got: {warnings}"

    def test_no_warning_when_ncp_patl_present(self, tmp_path, caplog):
        """Given an AE WITH a resolvable NCP PATL source (BaseCaseCurrentLimit
        this time), When PATL is resolved, Then NO fallback warning is
        logged — the warning must be specific to the fallback case, not
        fired unconditionally."""
        from pre_milp.ncp_parser import parse_assessed_elements
        import logging

        body = """<?xml version="1.0" encoding="UTF-8"?>
<rdf:RDF
    xmlns:rdf="http://www.w3.org/1999/02/22-rdf-syntax-ns#"
    xmlns:nc="https://cim4.eu/ns/nc#"
    xmlns:cim="https://cim.ucaiug.io/ns#">
  <nc:AssessedElement rdf:ID="_ae-with-ncp-patl">
    <cim:IdentifiedObject.mRID>ae-with-ncp-patl</cim:IdentifiedObject.mRID>
    <cim:IdentifiedObject.name>AE_WITH_NCP_PATL</cim:IdentifiedObject.name>
    <nc:AssessedElement.ConductingEquipment rdf:resource="#_branch-1"/>
    <nc:AssessedElement.SecuredForRegion rdf:resource="#_region-1"/>
    <nc:AssessedElement.OperationalLimit rdf:resource="#_ol-1"/>
  </nc:AssessedElement>
  <cim:BaseCaseCurrentLimit rdf:ID="_ol-1">
    <nc:BaseCaseCurrentLimit.normalValue>500</nc:BaseCaseCurrentLimit.normalValue>
    <cim:IdentifiedObject.mRID>ol-1</cim:IdentifiedObject.mRID>
  </cim:BaseCaseCurrentLimit>
</rdf:RDF>
"""
        ae_path = tmp_path / "Test_AE.xml"
        ae_path.write_text(body, encoding=TEXT_ENCODING)

        cgm_static_patl = {"branch-1": {1: 9999.0}}  # deliberately different — must NOT be used

        with caplog.at_level(logging.WARNING):
            ae_list = parse_assessed_elements(
                ae_path, None, "TestTSO", ["1030Z"], cgm_static_patl,
            )

        assert ae_list[0].patl_ka["1030Z"] == 0.5  # 500A from BaseCaseCurrentLimit, NOT 9.999 from CGM
        warnings = [r.message for r in caplog.records if r.levelno == logging.WARNING]
        assert not any("no PATL in NCP" in w or "using CGM static" in w for w in warnings)


# ---------------------------------------------------------------------------
# parse_psts — curative fields (reaction_time_minutes, time_per_stage_minutes,
# linked_contingency_mrids, linked_xne_mrids) on real data
# ---------------------------------------------------------------------------

class TestParsePstsCurativeFieldsLive:
    def test_real_curative_pst_has_linked_contingency_from_live_data(self):
        """The Espheim curative PST (TapChanger f6e8823f-d431-6fc7-37cf-b7a0d80035dd ->
        PowerTransformer 703f5b86-b6c6-4c47-8f6b-55d7d93838c9) has linked_contingency_mrids
        == [8cdec4c6-10c3-40c1-9eeb-7f6ae8d9b3fe] (ContingencyWithRemedialAction)."""
        from pre_milp.ncp_parser import build_tap_changer_to_transformer_map, parse_psts

        eq_path = DATA_ROOT / "Espheim" / "Grid" / "cimxml" / "20220615T2230Z__Espheim_EQ_1.xml"
        ra_path = DATA_ROOT / "Espheim" / "NetworkCode" / "cimxml" / "Espheim_RA.xml"
        tap_changer_to_transformer = build_tap_changer_to_transformer_map(eq_path)

        known_tc = {"703f5b86-b6c6-4c47-8f6b-55d7d93838c9": {"low_step": -17, "high_step": 17, "r0": 0}}
        psts = parse_psts(ra_path, "TSO-Espheim", known_tc, tap_changer_to_transformer)

        assert len(psts) == 1
        assert psts[0].linked_contingency_mrids == ["8cdec4c6-10c3-40c1-9eeb-7f6ae8d9b3fe"]

    def test_real_curative_pst_has_no_reaction_time_or_time_per_stage(self):
        """The dataset's curative PST has neither RemedialAction.timeToImplement nor
        GridStateAlteration.timePerStage."""
        from pre_milp.ncp_parser import build_tap_changer_to_transformer_map, parse_psts

        eq_path = DATA_ROOT / "Espheim" / "Grid" / "cimxml" / "20220615T2230Z__Espheim_EQ_1.xml"
        ra_path = DATA_ROOT / "Espheim" / "NetworkCode" / "cimxml" / "Espheim_RA.xml"
        tap_changer_to_transformer = build_tap_changer_to_transformer_map(eq_path)

        known_tc = {"703f5b86-b6c6-4c47-8f6b-55d7d93838c9": {"low_step": -17, "high_step": 17, "r0": 0}}
        psts = parse_psts(ra_path, "TSO-Espheim", known_tc, tap_changer_to_transformer)

        assert psts[0].reaction_time_minutes is None
        assert psts[0].time_per_stage_minutes is None

    def test_linked_xne_mrids_empty_without_ae_path(self):
        """Without ae_path, linked_xne_mrids is [] for every PST (not an error)."""
        from pre_milp.ncp_parser import build_tap_changer_to_transformer_map, parse_psts

        eq_path = DATA_ROOT / "Espheim" / "Grid" / "cimxml" / "20220615T2230Z__Espheim_EQ_1.xml"
        ra_path = DATA_ROOT / "Espheim" / "NetworkCode" / "cimxml" / "Espheim_RA.xml"
        tap_changer_to_transformer = build_tap_changer_to_transformer_map(eq_path)

        known_tc = {"703f5b86-b6c6-4c47-8f6b-55d7d93838c9": {"low_step": -17, "high_step": 17, "r0": 0}}
        psts = parse_psts(ra_path, "TSO-Espheim", known_tc, tap_changer_to_transformer)

        assert psts[0].linked_xne_mrids == []

    def test_linked_xne_mrids_resolved_when_ae_path_provided(self):
        """With ae_path, linked_xne_mrids is read from {TSO}_AE.xml
        (AssessedElementWithRemedialAction; Belgovia has such entries). Checks the plumbing,
        not a specific non-empty result."""
        from pre_milp.ncp_parser import build_tap_changer_to_transformer_map, parse_psts

        eq_path = DATA_ROOT / "Belgovia" / "Grid" / "cimxml"
        eq_candidates = list(eq_path.glob("*_EQ_*.xml"))
        assert eq_candidates, "Expected at least one Belgovia EQ file"
        tap_changer_to_transformer = build_tap_changer_to_transformer_map(eq_candidates[0])

        ra_path = DATA_ROOT / "Belgovia" / "NetworkCode" / "cimxml" / "Belgovia_RA.xml"
        ae_path = DATA_ROOT / "Belgovia" / "NetworkCode" / "cimxml" / "Belgovia_AE.xml"

        # no exception: the ae_path plumbing works on real data
        psts = parse_psts(ra_path, "TSO-Belgovia", {}, tap_changer_to_transformer, ae_path=ae_path)
        assert isinstance(psts, list)


# ---------------------------------------------------------------------------
# parse_psts — a preventive and a curative PST RA on the SAME TapChanger (synthetic: the
# real dataset has no such transformer)
# ---------------------------------------------------------------------------

FIXTURES_ROOT = Path(__file__).resolve().parent / "fixtures"


class TestParsePstsCrossGsaraTapChangerLeakage:
    def test_preventive_time_per_stage_not_leaked_from_curative_sibling_on_shared_tapchanger(self):
        """A preventive GSARA (no timePerStage) and a curative GSARA (timePerStage=PT1M) on the
        same TapChanger: the preventive PST's time_per_stage_minutes is None, not PT1M (each
        GSARA's own TapPositionAction is used)."""
        from pre_milp.ncp_parser import parse_psts

        ra_path = FIXTURES_ROOT / "ra_shared_tapchanger_preventive_and_curative.xml"
        tap_changer_to_transformer = {"shared-tc": "shared-transformer"}
        cgm_tap_changers = {"shared-transformer": {"low_step": -10, "high_step": 10, "r0": 0}}

        psts = parse_psts(ra_path, "TSO-Test", cgm_tap_changers, tap_changer_to_transformer)

        assert len(psts) == 2
        preventive = next(p for p in psts if p.kind == RAKind.PREVENTIVE)
        curative = next(p for p in psts if p.kind == RAKind.CURATIVE)

        assert preventive.time_per_stage_minutes is None, (
            "preventive PST's own TapPositionAction has no timePerStage set — "
            "must not inherit the curative sibling's PT1M value via the "
            "TapChanger-mRID-keyed lookup"
        )
        assert curative.time_per_stage_minutes == 1.0
        assert curative.reaction_time_minutes == 15.0


def _write_ra_groups_xml(tmp_path: Path, name: str, body: str) -> Path:
    path = tmp_path / name
    path.write_text(_RA_HEADER + body + _RA_FOOTER, encoding=TEXT_ENCODING)
    return path


def test_parse_ra_groups_full_chain_restrictive(tmp_path):
    """Given a RemedialActionGroup with a restrictive-kind
    RemedialActionDependency linking two RAs, and a matching SIS-side
    timepoint with maxRegulatingUp/Down for this timestamp, When
    parse_ra_groups runs, Then the group is returned with both RA mRIDs
    and the resolved limits."""
    ra_body = """
    <nc:RemedialActionGroup rdf:ID="_GROUP1">
      <cim:IdentifiedObject.mRID>GROUP1</cim:IdentifiedObject.mRID>
      <cim:IdentifiedObject.name>Test Group</cim:IdentifiedObject.name>
    </nc:RemedialActionGroup>
    <nc:RemedialActionDependency rdf:ID="_DEP1">
      <nc:RemedialActionDependency.kind rdf:resource="https://cim4.eu/ns/nc#RemedialActionDependencyKind.restrictive"/>
      <nc:RemedialActionDependency.RemedialActionGroup rdf:resource="#_GROUP1"/>
      <nc:RemedialActionDependency.RemedialAction rdf:resource="#_RA1"/>
    </nc:RemedialActionDependency>
    <nc:RemedialActionDependency rdf:ID="_DEP2">
      <nc:RemedialActionDependency.kind rdf:resource="https://cim4.eu/ns/nc#RemedialActionDependencyKind.restrictive"/>
      <nc:RemedialActionDependency.RemedialActionGroup rdf:resource="#_GROUP1"/>
      <nc:RemedialActionDependency.RemedialAction rdf:resource="#_RA2"/>
    </nc:RemedialActionDependency>
    """
    sis_body = """
    <nc:RemedialActionGroupTimePoint rdf:ID="_TP1">
      <nc:RemedialActionGroupTimePoint.RemedialActionGroup rdf:resource="#_GROUP1"/>
      <nc:RemedialActionGroupTimePoint.atTime>2022-06-15T10:30:00Z</nc:RemedialActionGroupTimePoint.atTime>
      <nc:RemedialActionGroup.maxRegulatingUp>100.0</nc:RemedialActionGroup.maxRegulatingUp>
      <nc:RemedialActionGroup.maxRegulatingDown>50.0</nc:RemedialActionGroup.maxRegulatingDown>
    </nc:RemedialActionGroupTimePoint>
    """
    ra_path = _write_ra_groups_xml(tmp_path, "Test_RA.xml", ra_body)
    sis_path = _write_ra_groups_xml(tmp_path, "Test_SIS.xml", sis_body)

    result = ncp_parser.parse_ra_groups(ra_path, sis_path, "TestTSO", "1030Z")

    assert "GROUP1" in result
    assert result["GROUP1"]["ra_mrids"] == ["RA1", "RA2"]
    assert result["GROUP1"]["max_regulating_up"] == 100.0
    assert result["GROUP1"]["max_regulating_down"] == 50.0


_GROUP_RA_BODY = """
    <nc:RemedialActionGroup rdf:ID="_GROUP1">
      <cim:IdentifiedObject.mRID>GROUP1</cim:IdentifiedObject.mRID>
    </nc:RemedialActionGroup>
    <nc:RemedialActionDependency rdf:ID="_DEP1">
      <nc:RemedialActionDependency.kind rdf:resource="https://cim4.eu/ns/nc#RemedialActionDependencyKind.restrictive"/>
      <nc:RemedialActionDependency.DependingRemedialActionGroup rdf:resource="#_GROUP1"/>
      <nc:RemedialActionDependency.RemedialAction rdf:resource="#_RA1"/>
    </nc:RemedialActionDependency>
    """


def _standard_group_limits(group="GROUP1", schedule="SCH1", at_time="2022-06-15T10:30:00Z", up="100.0", down="50.0", point="TP1"):
    return f"""
    <nc:RemedialActionGroupSchedule rdf:ID="_{schedule}">
      <nc:RemedialActionGroupSchedule.RemedialActionGroup rdf:resource="#_{group}"/>
      <nc:BaseTimeSeries.interpolationKind rdf:resource="https://cim4.eu/ns/nc#TimeSeriesInterpolationKind.none"/>
    </nc:RemedialActionGroupSchedule>
    <nc:RemedialActionGroupTimePoint rdf:ID="_{point}">
      <nc:RemedialActionGroupTimePoint.RemedialActionGroupSchedule rdf:resource="#_{schedule}"/>
      <nc:RemedialActionGroupTimePoint.atTime>{at_time}</nc:RemedialActionGroupTimePoint.atTime>
      <nc:RemedialActionGroupTimePoint.maxRegulatingUp>{up}</nc:RemedialActionGroupTimePoint.maxRegulatingUp>
      <nc:RemedialActionGroupTimePoint.maxRegulatingDown>{down}</nc:RemedialActionGroupTimePoint.maxRegulatingDown>
    </nc:RemedialActionGroupTimePoint>
    """


_OLD_GROUP_LIMITS = """
    <nc:RemedialActionGroupTimePoint rdf:ID="_TPOLD">
      <nc:RemedialActionGroupTimePoint.RemedialActionGroup rdf:resource="#_GROUP1"/>
      <nc:RemedialActionGroupTimePoint.atTime>2022-06-15T10:30:00Z</nc:RemedialActionGroupTimePoint.atTime>
      <nc:RemedialActionGroup.maxRegulatingUp>7.0</nc:RemedialActionGroup.maxRegulatingUp>
      <nc:RemedialActionGroup.maxRegulatingDown>3.0</nc:RemedialActionGroup.maxRegulatingDown>
    </nc:RemedialActionGroupTimePoint>
    """


def _group_warnings(caplog, word):
    return [r.getMessage() for r in caplog.records if r.levelno >= logging.WARNING and word in r.getMessage()]


def test_parse_ra_groups_standard_limit_chain(tmp_path, caplog):
    """The SIS limits are read through RemedialActionGroupSchedule and RemedialActionGroupTimePoint
    (maxRegulatingUp/Down declared by the time point); no deprecation warning."""
    ra_path = _write_ra_groups_xml(tmp_path, "Test_RA.xml", _GROUP_RA_BODY)
    sis_path = _write_ra_groups_xml(tmp_path, "Test_SIS.xml", _standard_group_limits())
    with caplog.at_level(logging.WARNING):
        result = ncp_parser.parse_ra_groups(ra_path, sis_path, "TestTSO", "1030Z")
    assert result["GROUP1"]["max_regulating_up"] == 100.0
    assert result["GROUP1"]["max_regulating_down"] == 50.0
    assert _group_warnings(caplog, "deprecated") == []


def test_parse_ra_groups_standard_chain_ignores_other_times_and_groups(tmp_path):
    ra_path = _write_ra_groups_xml(tmp_path, "Test_RA.xml", _GROUP_RA_BODY)
    body = (_standard_group_limits(at_time="2022-06-15T11:30:00Z", up="1.0", down="1.0")
            + _standard_group_limits(group="OTHER", schedule="SCH2", up="2.0", down="2.0", point="TP2"))
    sis_path = _write_ra_groups_xml(tmp_path, "Test_SIS.xml", body)
    result = ncp_parser.parse_ra_groups(ra_path, sis_path, "TestTSO", "1030Z")
    assert result["GROUP1"]["max_regulating_up"] is None and result["GROUP1"]["max_regulating_down"] is None


def test_parse_ra_groups_old_limit_form_is_a_fallback_with_a_deprecation_warning(tmp_path, caplog):
    """The non-standard form (time point linked to the group directly, limits declared by
    RemedialActionGroup) is still read; one deprecation warning per file."""
    ra_path = _write_ra_groups_xml(tmp_path, "Test_RA.xml", _GROUP_RA_BODY)
    sis_path = _write_ra_groups_xml(tmp_path, "Test_SIS.xml", _OLD_GROUP_LIMITS)
    with caplog.at_level(logging.WARNING):
        first = ncp_parser.parse_ra_groups(ra_path, sis_path, "TestTSO", "1030Z")
        ncp_parser.parse_ra_groups(ra_path, sis_path, "TestTSO", "1030Z")
    assert first["GROUP1"]["max_regulating_up"] == 7.0 and first["GROUP1"]["max_regulating_down"] == 3.0
    assert len(_group_warnings(caplog, "deprecated")) == 1
    assert "Test_SIS.xml" in _group_warnings(caplog, "deprecated")[0]


def test_parse_ra_groups_standard_form_wins_over_the_old_form(tmp_path, caplog):
    ra_path = _write_ra_groups_xml(tmp_path, "Test_RA.xml", _GROUP_RA_BODY)
    sis_path = _write_ra_groups_xml(tmp_path, "Test_SIS.xml", _standard_group_limits() + _OLD_GROUP_LIMITS)
    with caplog.at_level(logging.WARNING):
        result = ncp_parser.parse_ra_groups(ra_path, sis_path, "TestTSO", "1030Z")
    assert result["GROUP1"]["max_regulating_up"] == 100.0 and result["GROUP1"]["max_regulating_down"] == 50.0
    assert _group_warnings(caplog, "both")


def test_per_remedial_action_volume_caps_are_warned_about_and_not_read(tmp_path, caplog):
    """PowerRemedialActionSchedule / PowerRemedialActionTimePoint (maxRegulatingUp/Down of one RA) are not
    read (decision 96): one warning per SIS file with the counts; nothing for a file without them."""
    body = """
    <nc:PowerRemedialActionSchedule rdf:ID="_PS1">
      <nc:PowerRemedialActionSchedule.PowerRemedialAction rdf:resource="#_RA1"/>
    </nc:PowerRemedialActionSchedule>
    <nc:PowerRemedialActionTimePoint rdf:ID="_PT1">
      <nc:PowerRemedialActionTimePoint.PowerRemedialActionSchedule rdf:resource="#_PS1"/>
      <nc:PowerRemedialActionTimePoint.atTime>2022-06-15T10:30:00Z</nc:PowerRemedialActionTimePoint.atTime>
      <nc:PowerRemedialActionTimePoint.maxRegulatingUp>40</nc:PowerRemedialActionTimePoint.maxRegulatingUp>
    </nc:PowerRemedialActionTimePoint>
    """
    capped = _write_ra_groups_xml(tmp_path, "Capped_SIS.xml", body)
    plain = _write_ra_groups_xml(tmp_path, "Plain_SIS.xml", "")
    with caplog.at_level(logging.WARNING):
        ncp_parser.warn_unsupported_sis_content(plain, "TestTSO")
        assert [r for r in caplog.records if r.levelno >= logging.WARNING] == []
        ncp_parser.warn_unsupported_sis_content(capped, "TestTSO")
    messages = [r.getMessage() for r in caplog.records if r.levelno >= logging.WARNING]
    assert len(messages) == 1 and "Capped_SIS.xml" in messages[0] and "not read" in messages[0]
    assert "1 PowerRemedialActionSchedule" in messages[0] and "1 PowerRemedialActionTimePoint" in messages[0]


def test_parse_ra_groups_skips_non_restrictive_dependency(tmp_path):
    """Given a RemedialActionDependency with kind=balanced (not
    restrictive), When parse_ra_groups runs, Then that group is entirely
    excluded -- per spec, 'skip groups without restrictive dependency'."""
    ra_body = """
    <nc:RemedialActionGroup rdf:ID="_GROUP1">
      <cim:IdentifiedObject.mRID>GROUP1</cim:IdentifiedObject.mRID>
    </nc:RemedialActionGroup>
    <nc:RemedialActionDependency rdf:ID="_DEP1">
      <nc:RemedialActionDependency.kind rdf:resource="https://cim4.eu/ns/nc#RemedialActionDependencyKind.balanced"/>
      <nc:RemedialActionDependency.RemedialActionGroup rdf:resource="#_GROUP1"/>
      <nc:RemedialActionDependency.RemedialAction rdf:resource="#_RA1"/>
    </nc:RemedialActionDependency>
    """
    ra_path = _write_ra_groups_xml(tmp_path, "Test_RA.xml", ra_body)

    result = ncp_parser.parse_ra_groups(ra_path, None, "TestTSO", "1030Z")

    assert result == {}


def test_parse_ra_groups_no_groups_at_all_returns_empty(tmp_path):
    """Given an RA file with no RemedialActionGroup content at all, When
    parse_ra_groups runs, Then it returns {} without raising."""
    ra_body = "<!-- nothing relevant here -->"
    ra_path = _write_ra_groups_xml(tmp_path, "Test_RA.xml", ra_body)

    result = ncp_parser.parse_ra_groups(ra_path, None, "TestTSO", "1030Z")

    assert result == {}


def test_parse_ra_groups_restrictive_membership_but_no_sis_file(tmp_path):
    """Given a restrictive group exists in the RA file but sis_path is
    None (no SIS file for this TSO), When parse_ra_groups runs, Then the
    group is still returned with both limits as None -- not silently
    dropped."""
    ra_body = """
    <nc:RemedialActionGroup rdf:ID="_GROUP1">
      <cim:IdentifiedObject.mRID>GROUP1</cim:IdentifiedObject.mRID>
    </nc:RemedialActionGroup>
    <nc:RemedialActionDependency rdf:ID="_DEP1">
      <nc:RemedialActionDependency.kind rdf:resource="https://cim4.eu/ns/nc#RemedialActionDependencyKind.restrictive"/>
      <nc:RemedialActionDependency.RemedialActionGroup rdf:resource="#_GROUP1"/>
      <nc:RemedialActionDependency.RemedialAction rdf:resource="#_RA1"/>
    </nc:RemedialActionDependency>
    """
    ra_path = _write_ra_groups_xml(tmp_path, "Test_RA.xml", ra_body)

    result = ncp_parser.parse_ra_groups(ra_path, None, "TestTSO", "1030Z")

    assert result == {"GROUP1": {"name": "GROUP1", "ra_mrids": ["RA1"], "max_regulating_up": None, "max_regulating_down": None}}


def test_parse_ra_groups_real_belgovia_data_returns_empty():
    """The real Belgovia_RA.xml and Belgovia_SIS.xml contain no RemedialActionGroup:
    parse_ra_groups returns {}.
    """
    belgovia_ra = DATA_ROOT / "Belgovia" / "NetworkCode" / "cimxml" / "Belgovia_RA.xml"
    belgovia_sis = DATA_ROOT / "Belgovia" / "NetworkCode" / "cimxml" / "Belgovia_SIS.xml"

    result = ncp_parser.parse_ra_groups(belgovia_ra, belgovia_sis, "TSO-Belgovia", "1030Z")

    assert result == {}


# ---------------------------------------------------------------------------
# RA-level RemedialAction.penaltyFactor (not PowerBidSchedule.penaltyFactor, which is
# bid-level and parsed into PowerBid.penalty_factor)
# ---------------------------------------------------------------------------



def test_rd_unit_penalty_factor_parsed_from_ra_level_field(tmp_path):
    """Given a RedispatchRemedialAction with an explicit
    RemedialAction.penaltyFactor, When parse_rd_units runs, Then the
    resulting RDUnit(s) carry that RA-level value, not a bid-level one."""
    body = """
    <nc:GridStateAlterationRemedialAction rdf:ID="_RA1">
      <cim:IdentifiedObject.mRID>RA1</cim:IdentifiedObject.mRID>
      <cim:IdentifiedObject.name>Test RD RA</cim:IdentifiedObject.name>
      <nc:RemedialAction.normalAvailable>true</nc:RemedialAction.normalAvailable>
      <nc:RemedialAction.kind rdf:resource="https://cim4.eu/ns/nc#RemedialActionKind.preventive"/>
      <nc:RemedialAction.penaltyFactor>0.75</nc:RemedialAction.penaltyFactor>
    </nc:GridStateAlterationRemedialAction>
    <nc:RotatingMachineAction rdf:ID="_RMA1">
      <nc:GridStateAlteration.GridStateAlterationRemedialAction rdf:resource="#_RA1"/>
      <nc:RotatingMachineAction.RotatingMachine rdf:resource="#_GU1"/>
    </nc:RotatingMachineAction>
    """
    ra_path = _write_penalty_factor_ra(tmp_path, body)
    cgm_generating_units = {"GU1": {"name": "GU1", "target_p": 50.0, "max_p": 100.0, "min_p": 0.0}}

    rd_units, bids = ncp_parser.parse_rd_units(
        ra_path, None, "TestTSO", ["1030Z"], cgm_generating_units,
    )

    assert len(rd_units) == 1
    assert rd_units[0].penalty_factor == 0.75


def test_rd_unit_penalty_factor_defaults_to_one_when_absent(tmp_path):
    """Given a RedispatchRemedialAction with NO RemedialAction.penaltyFactor,
    When parse_rd_units runs, Then the resulting RDUnit defaults to 1.0,
    per the CIM spec's own stated default."""
    body = """
    <nc:GridStateAlterationRemedialAction rdf:ID="_RA1">
      <cim:IdentifiedObject.mRID>RA1</cim:IdentifiedObject.mRID>
      <cim:IdentifiedObject.name>Test RD RA</cim:IdentifiedObject.name>
      <nc:RemedialAction.normalAvailable>true</nc:RemedialAction.normalAvailable>
      <nc:RemedialAction.kind rdf:resource="https://cim4.eu/ns/nc#RemedialActionKind.preventive"/>
    </nc:GridStateAlterationRemedialAction>
    <nc:RotatingMachineAction rdf:ID="_RMA1">
      <nc:GridStateAlteration.GridStateAlterationRemedialAction rdf:resource="#_RA1"/>
      <nc:RotatingMachineAction.RotatingMachine rdf:resource="#_GU1"/>
    </nc:RotatingMachineAction>
    """
    ra_path = _write_penalty_factor_ra(tmp_path, body)
    cgm_generating_units = {"GU1": {"name": "GU1", "target_p": 50.0, "max_p": 100.0, "min_p": 0.0}}

    rd_units, bids = ncp_parser.parse_rd_units(
        ra_path, None, "TestTSO", ["1030Z"], cgm_generating_units,
    )

    assert len(rd_units) == 1
    assert rd_units[0].penalty_factor == 1.0


@pytest.mark.parametrize("time_to_implement_xml, expected_minutes", [
    ("<nc:RemedialAction.timeToImplement>PT15M</nc:RemedialAction.timeToImplement>", 15.0),
    ("", None),  # not given: None (the MILP treats it as 0, always available)
])
def test_rd_unit_reaction_time_parsed_from_time_to_implement(tmp_path, time_to_implement_xml, expected_minutes):
    """CORNET-613: RemedialAction.timeToImplement of an RD RA becomes RDUnit.reaction_time_minutes."""
    body = f"""
    <nc:GridStateAlterationRemedialAction rdf:ID="_RA1">
      <cim:IdentifiedObject.mRID>RA1</cim:IdentifiedObject.mRID>
      <cim:IdentifiedObject.name>Test RD RA</cim:IdentifiedObject.name>
      <nc:RemedialAction.normalAvailable>true</nc:RemedialAction.normalAvailable>
      <nc:RemedialAction.kind rdf:resource="https://cim4.eu/ns/nc#RemedialActionKind.curative"/>
      {time_to_implement_xml}
    </nc:GridStateAlterationRemedialAction>
    <nc:RotatingMachineAction rdf:ID="_RMA1">
      <nc:GridStateAlteration.GridStateAlterationRemedialAction rdf:resource="#_RA1"/>
      <nc:RotatingMachineAction.RotatingMachine rdf:resource="#_GU1"/>
    </nc:RotatingMachineAction>
    """
    ra_path = _write_penalty_factor_ra(tmp_path, body)
    cgm_generating_units = {"GU1": {"name": "GU1", "target_p": 50.0, "max_p": 100.0, "min_p": 0.0}}

    rd_units, _bids = ncp_parser.parse_rd_units(ra_path, None, "TestTSO", ["1030Z"], cgm_generating_units)

    assert len(rd_units) == 1
    assert rd_units[0].reaction_time_minutes == expected_minutes


def test_rd_unit_penalty_factor_shared_across_multiple_generating_units(tmp_path):
    """Given one RA with two RotatingMachineActions (two generating units),
    When parse_rd_units runs, Then BOTH resulting RDUnits carry the same
    RA-level penalty_factor — it is an RA property, not per-unit."""
    body = """
    <nc:GridStateAlterationRemedialAction rdf:ID="_RA1">
      <cim:IdentifiedObject.mRID>RA1</cim:IdentifiedObject.mRID>
      <cim:IdentifiedObject.name>Test RD RA</cim:IdentifiedObject.name>
      <nc:RemedialAction.normalAvailable>true</nc:RemedialAction.normalAvailable>
      <nc:RemedialAction.kind rdf:resource="https://cim4.eu/ns/nc#RemedialActionKind.preventive"/>
      <nc:RemedialAction.penaltyFactor>0.5</nc:RemedialAction.penaltyFactor>
    </nc:GridStateAlterationRemedialAction>
    <nc:RotatingMachineAction rdf:ID="_RMA1">
      <nc:GridStateAlteration.GridStateAlterationRemedialAction rdf:resource="#_RA1"/>
      <nc:RotatingMachineAction.RotatingMachine rdf:resource="#_GU1"/>
    </nc:RotatingMachineAction>
    <nc:RotatingMachineAction rdf:ID="_RMA2">
      <nc:GridStateAlteration.GridStateAlterationRemedialAction rdf:resource="#_RA1"/>
      <nc:RotatingMachineAction.RotatingMachine rdf:resource="#_GU2"/>
    </nc:RotatingMachineAction>
    """
    ra_path = _write_penalty_factor_ra(tmp_path, body)
    cgm_generating_units = {
        "GU1": {"name": "GU1", "target_p": 50.0, "max_p": 100.0, "min_p": 0.0},
        "GU2": {"name": "GU2", "target_p": 50.0, "max_p": 100.0, "min_p": 0.0},
    }

    rd_units, bids = ncp_parser.parse_rd_units(
        ra_path, None, "TestTSO", ["1030Z"], cgm_generating_units,
    )

    assert len(rd_units) == 2
    assert all(rd.penalty_factor == 0.5 for rd in rd_units)


# ---------------------------------------------------------------------------
# parse_rd_units — curative fields on real data
# ---------------------------------------------------------------------------


class TestParseRdUnitsCurativeFieldsLive:
    def test_no_curative_rd_ra_exists_anywhere_in_this_dataset(self):
        """Every RD unit of the dataset is PREVENTIVE: there is no curative RD RA."""
        from pathlib import Path as P
        from pre_milp import cgmes_loader, tso_name_resolver, ncp_loader, ncp_parser

        org_cd_path = DATA_ROOT / "commonData" / "NetworkCode" / "cimxml" / "Org-NineRealms_CD.xml"
        network = cgmes_loader.load_cgm(cgm_zip_override=FIXTURE_CGM_ZIP)
        _, _, generating_unit_dict = cgmes_loader.extract_equipment_dicts(network)
        tso_name_map = tso_name_resolver.build_tso_name_map(org_cd_path)
        ncp_files = ncp_loader.build_ncp_files(DATA_ROOT, tso_name_map)
        timestamp_list = ncp_loader.build_timestamp_list("1030Z", 4)

        all_rd_units = []
        for tso, profiles in sorted(ncp_files.items()):
            if "RA" not in profiles:
                continue
            rds, _bids = ncp_parser.parse_rd_units(
                profiles["RA"], profiles.get("SIS"), tso, timestamp_list, generating_unit_dict,
            )
            all_rd_units.extend(rds)

        assert len(all_rd_units) > 0, "Expected at least the known 2 real preventive RD units"
        assert all(rd.kind == RAKind.PREVENTIVE for rd in all_rd_units)

    def test_real_preventive_rd_unit_has_no_linked_contingency(self):
        """The Belgovia RD RA is preventive: linked_contingency_mrids is empty
        (ContingencyWithRemedialAction references only PST RAs in this dataset)."""
        from pre_milp.ncp_parser import parse_rd_units
        from pre_milp import cgmes_loader, tso_name_resolver, ncp_loader

        org_cd_path = DATA_ROOT / "commonData" / "NetworkCode" / "cimxml" / "Org-NineRealms_CD.xml"
        network = cgmes_loader.load_cgm(cgm_zip_override=FIXTURE_CGM_ZIP)
        _, _, generating_unit_dict = cgmes_loader.extract_equipment_dicts(network)
        tso_name_map = tso_name_resolver.build_tso_name_map(org_cd_path)
        ncp_files = ncp_loader.build_ncp_files(DATA_ROOT, tso_name_map)

        rds, _bids = parse_rd_units(
            ncp_files["TSO-Belgovia"]["RA"], ncp_files["TSO-Belgovia"].get("SIS"),
            "TSO-Belgovia", ["1030Z", "1130Z", "1230Z", "1330Z"], generating_unit_dict,
        )
        assert len(rds) > 0
        assert all(rd.linked_contingency_mrids == [] for rd in rds)


# ===========================================================================
# Ignored power remedial actions
# ===========================================================================

HEADER = ('<?xml version="1.0"?><rdf:RDF xmlns:rdf="http://www.w3.org/1999/02/22-rdf-syntax-ns#" '
          'xmlns:cim="https://cim.ucaiug.io/ns#" xmlns:nc="https://cim4.eu/ns/nc#">')


RA_XML = HEADER + """
<nc:RedispatchRemedialAction rdf:ID="_RD-WITH-BID"><cim:IdentifiedObject.mRID>RD-WITH-BID</cim:IdentifiedObject.mRID><cim:IdentifiedObject.name>RD one</cim:IdentifiedObject.name></nc:RedispatchRemedialAction>
<nc:RedispatchRemedialAction rdf:ID="_RD-NO-BID"><cim:IdentifiedObject.mRID>RD-NO-BID</cim:IdentifiedObject.mRID><cim:IdentifiedObject.name>RD two</cim:IdentifiedObject.name></nc:RedispatchRemedialAction>
<nc:CountertradeRemedialAction rdf:ID="_CT-1"><cim:IdentifiedObject.mRID>CT-1</cim:IdentifiedObject.mRID><cim:IdentifiedObject.name>CT one</cim:IdentifiedObject.name></nc:CountertradeRemedialAction>
</rdf:RDF>"""


def _schedule(mrid, ra):
    return (f'<nc:PowerBidSchedule rdf:ID="_{mrid}"><cim:IdentifiedObject.mRID>{mrid}</cim:IdentifiedObject.mRID>'
            f'<nc:PowerBidSchedule.PowerRemedialAction rdf:resource="#_{ra}"/></nc:PowerBidSchedule>')


def _time_point(mrid, schedule):
    return (f'<nc:PowerBidScheduleTimePoint rdf:ID="_{mrid}">'
            f'<nc:PowerBidScheduleTimePoint.atTime>2024-02-22T17:30:00Z</nc:PowerBidScheduleTimePoint.atTime>'
            f'<nc:PowerBidScheduleTimePoint.PowerBidSchedule rdf:resource="#_{schedule}"/>'
            f'<nc:PowerBidScheduleTimePoint.p>-10</nc:PowerBidScheduleTimePoint.p>'
            f'<nc:PowerBidScheduleTimePoint.price>5</nc:PowerBidScheduleTimePoint.price></nc:PowerBidScheduleTimePoint>')


SIS_XML = HEADER + (
    _schedule("S1", "RD-WITH-BID") + _time_point("T1", "S1") + _time_point("T2", "S1")
    + _schedule("S2", "CT-1") + _schedule("S3", "CT-1") + _time_point("T3", "S2")
    + "</rdf:RDF>"
)


@pytest.fixture()
def files(tmp_path):
    (tmp_path / "X_RA.xml").write_text(RA_XML, encoding=TEXT_ENCODING)
    (tmp_path / "X_SIS.xml").write_text(SIS_XML, encoding=TEXT_ENCODING)
    return tmp_path / "X_RA.xml", tmp_path / "X_SIS.xml"


def test_each_ignored_ra_is_listed_with_its_bid_count(files, caplog):
    ra_path, sis_path = files
    with caplog.at_level(logging.WARNING, logger=ncp_parser.log.name):
        units, bids = ncp_parser.parse_rd_units(ra_path, sis_path, "X", ["1730Z"], {})
    assert units == [] and bids == []   # parsing result unchanged: still ignored
    by_mrid = {r.getMessage().split()[2]: r.getMessage() for r in caplog.records if "IGNORED" in r.getMessage()}
    assert set(by_mrid) == {"RD-WITH-BID", "RD-NO-BID", "CT-1"}
    assert "nc:RedispatchRemedialAction RD-WITH-BID" in by_mrid["RD-WITH-BID"]
    assert "1 PowerBidSchedule(s) with 2 time point(s)" in by_mrid["RD-WITH-BID"]
    assert "0 PowerBidSchedule(s) with 0 time point(s)" in by_mrid["RD-NO-BID"]
    assert "nc:CountertradeRemedialAction CT-1" in by_mrid["CT-1"]
    assert "2 PowerBidSchedule(s) with 1 time point(s)" in by_mrid["CT-1"]


def test_warning_function_returns_the_same_facts(files):
    ra_path, sis_path = files
    result = ncp_parser.warn_unsupported_power_remedial_actions(
        ncp_parser._load_graph(ra_path), ncp_parser._load_graph(sis_path), "X",
    )
    assert {(r["class_name"], r["mrid"], r["bid_schedule_count"], r["time_point_count"]) for r in result} == {
        ("RedispatchRemedialAction", "RD-WITH-BID", 1, 2),
        ("RedispatchRemedialAction", "RD-NO-BID", 0, 0),
        ("CountertradeRemedialAction", "CT-1", 2, 1),
    }


def test_no_sis_file_still_warns_with_zero_bids(files, caplog):
    ra_path, _ = files
    with caplog.at_level(logging.WARNING, logger=ncp_parser.log.name):
        ncp_parser.parse_rd_units(ra_path, None, "X", ["1730Z"], {})
    assert sum("IGNORED" in r.getMessage() for r in caplog.records) == 3


def test_no_warning_when_there_is_no_such_ra(tmp_path, caplog):
    (tmp_path / "Y_RA.xml").write_text(HEADER + "</rdf:RDF>", encoding=TEXT_ENCODING)
    with caplog.at_level(logging.WARNING, logger=ncp_parser.log.name):
        ncp_parser.parse_rd_units(tmp_path / "Y_RA.xml", None, "Y", ["1730Z"], {})
    assert not any("IGNORED" in r.getMessage() for r in caplog.records)


GENERIC_ZIP = Path(__file__).parent / "fixtures" / "NCP_sample_generic_2_4.zip"


@pytest.mark.skipif(not GENERIC_ZIP.exists(), reason="NCP_sample_generic_2_4.zip fixture not present")
def test_generic_dataset_reports_the_known_belgovia_ras(tmp_path):
    with zipfile.ZipFile(GENERIC_ZIP) as z:
        z.extract("Belgovia_RA.xml", tmp_path)
        z.extract("Belgovia_SIS.xml", tmp_path)
    result = ncp_parser.warn_unsupported_power_remedial_actions(
        ncp_parser._load_graph(tmp_path / "Belgovia_RA.xml"), ncp_parser._load_graph(tmp_path / "Belgovia_SIS.xml"), "Belgovia",
    )
    got = {r["mrid"][:8]: (r["class_name"], r["bid_schedule_count"], r["time_point_count"]) for r in result}
    assert got == {
        "fa73cfee": ("RedispatchRemedialAction", 1, 1),
        "9d72d12a": ("RedispatchRemedialAction", 0, 0),
        "30f6377d": ("CountertradeRemedialAction", 3, 0),
    }


# ===========================================================================
# Assessed-element classification and invalid exclusionReason
# ===========================================================================

# ---------------------------------------------------------------------------
# assessed-element classification and invalid exclusionReason
# ---------------------------------------------------------------------------

def _ae_xml(secured=False, scanned=False, exclusion=None):
    extra = ""
    if secured:
        extra += '<nc:AssessedElement.SecuredForRegion rdf:resource="#_region-1"/>\n'
    if scanned:
        extra += '<nc:AssessedElement.ScannedForRegion rdf:resource="#_region-1"/>\n'
    if exclusion:
        extra += f'<nc:AssessedElement.exclusionReason rdf:resource="#{exclusion}"/>\n'
    return f"""<?xml version="1.0" encoding="UTF-8"?>
<rdf:RDF
    xmlns:rdf="http://www.w3.org/1999/02/22-rdf-syntax-ns#"
    xmlns:nc="https://cim4.eu/ns/nc#"
    xmlns:cim="https://cim.ucaiug.io/ns#">
  <nc:AssessedElement rdf:ID="_ae-1">
    <cim:IdentifiedObject.mRID>ae-1</cim:IdentifiedObject.mRID>
    <cim:IdentifiedObject.name>AE_1</cim:IdentifiedObject.name>
    <nc:AssessedElement.ConductingEquipment rdf:resource="#_branch-1"/>
    {extra}
  </nc:AssessedElement>
</rdf:RDF>
"""


def _parse_ae(tmp_path, **kw):
    from pre_milp.ncp_parser import parse_assessed_elements
    p = tmp_path / "T_AE.xml"
    p.write_text(_ae_xml(**kw), encoding=TEXT_ENCODING)
    return parse_assessed_elements(p, None, "TestTSO", ["1030Z"], {"branch-1": {1: 1000.0}})


def test_ae_with_neither_region_code_nor_exclusion_is_excluded_and_logged(tmp_path, caplog):
    with caplog.at_level(logging.INFO):
        aes = _parse_ae(tmp_path)
    assert len(aes) == 1
    assert aes[0].ae_type == AEType.EXCLUDED
    assert aes[0].exclusion_reason == "no secured or scanned region code"
    assert any("no secured or scanned region code" in r.message for r in caplog.records)


def test_ae_with_both_region_codes_and_no_exclusion_stays_secured(tmp_path, caplog):
    aes = _parse_ae(tmp_path, secured=True, scanned=True)
    assert aes[0].ae_type == AEType.SECURED
    # a scanned-only AE without exclusion reason also stays SECURED (debug log only)
    with caplog.at_level(logging.DEBUG):
        scanned_only = _parse_ae(tmp_path, scanned=True)
    assert scanned_only[0].ae_type == AEType.SECURED
    assert any(r.levelno == logging.DEBUG and "defaulting to SECURED" in r.message for r in caplog.records)


def test_ae_with_invalid_exclusion_reason_cancels_the_parse(tmp_path, caplog):
    with caplog.at_level(logging.CRITICAL):
        with pytest.raises(ValueError, match="invalid exclusionReason"):
            _parse_ae(tmp_path, secured=True, exclusion="SecuredExclusionReasonKind.bogus")
    assert any(r.levelno == logging.CRITICAL for r in caplog.records)


# ===========================================================================
# Scanned assessed elements on the real dataset
# ===========================================================================

REPO_ROOT = Path(__file__).resolve().parents[1]


DATA_ROOT_nx_filters_and_scanned_elements = DATA_ROOT


def test_real_dataset_has_zero_scanned_aes_confirmed_live():
    """The real dataset has no SCANNED AE in any of the 4 NCP TSOs (so the N-X scanned
    constraint is empty there)."""
    from pre_milp import cgmes_loader, tso_name_resolver, ncp_loader, ncp_parser

    org_cd_path = DATA_ROOT_nx_filters_and_scanned_elements / "commonData" / "NetworkCode" / "cimxml" / "Org-NineRealms_CD.xml"
    network = cgmes_loader.load_cgm(cgm_zip_override=FIXTURE_CGM_ZIP)
    branch_mrid_to_name = cgmes_loader.build_branch_mrid_to_name(network)
    cgm_static_patl = cgmes_loader.build_cgm_static_patl(network)
    tso_name_map = tso_name_resolver.build_tso_name_map(org_cd_path)
    ncp_files = ncp_loader.build_ncp_files(DATA_ROOT_nx_filters_and_scanned_elements, tso_name_map)
    timestamp_list = ncp_loader.build_timestamp_list("1030Z", 4)

    ae_flat_list = []
    for tso, profiles in sorted(ncp_files.items()):
        country = tso.removeprefix("TSO-")
        eq_candidates = list((DATA_ROOT_nx_filters_and_scanned_elements / country / "Grid" / "cimxml").glob("*_EQ_*.xml"))
        current_limit_side = (
            ncp_parser.build_current_limit_side_map(eq_candidates[0]) if eq_candidates else {}
        )
        ae_flat_list.extend(ncp_parser.parse_assessed_elements(
            profiles["AE"], profiles.get("SHS"), tso, timestamp_list, cgm_static_patl,
            cgm_branch_mrids=set(branch_mrid_to_name.keys()), current_limit_side=current_limit_side,
        ))

    scanned_count = sum(1 for ae in ae_flat_list if ae.ae_type == AEType.SCANNED)
    assert scanned_count == 0


# ===========================================================================
# RD Pmax/Pmin default
# ===========================================================================

# ---------------------------------------------------------------------------
# RD Pmax/Pmin default 0.0 is logged once per unit
# ---------------------------------------------------------------------------

def _parse_rd_with_gu(tmp_path, gu_data):
    import helpers as P
    body = """
    <nc:GridStateAlterationRemedialAction rdf:ID="_RA1">
      <cim:IdentifiedObject.mRID>RA1</cim:IdentifiedObject.mRID>
      <cim:IdentifiedObject.name>Test RD RA</cim:IdentifiedObject.name>
      <nc:RemedialAction.normalAvailable>true</nc:RemedialAction.normalAvailable>
      <nc:RemedialAction.kind rdf:resource="https://cim4.eu/ns/nc#RemedialActionKind.preventive"/>
    </nc:GridStateAlterationRemedialAction>
    <nc:RotatingMachineAction rdf:ID="_RMA1">
      <nc:GridStateAlteration.GridStateAlterationRemedialAction rdf:resource="#_RA1"/>
      <nc:RotatingMachineAction.RotatingMachine rdf:resource="#_GU1"/>
    </nc:RotatingMachineAction>
    """
    ra_path = P._write_penalty_factor_ra(tmp_path, body)
    from pre_milp import ncp_parser
    return ncp_parser.parse_rd_units(ra_path, None, "TestTSO", ["1030Z"], {"GU1": gu_data})


def test_a_unit_without_pmax_and_pmin_gets_zero_and_one_warning_naming_it(tmp_path, caplog):
    with caplog.at_level(logging.WARNING):
        rd_units, _ = _parse_rd_with_gu(tmp_path, {"name": "Gen One", "target_p": 50.0})
    assert (rd_units[0].max_p, rd_units[0].min_p) == (0.0, 0.0)
    warnings = [r.message for r in caplog.records
                if r.levelno == logging.WARNING and "GU1" in r.message and "Gen One" in r.message]
    assert len(warnings) == 1
    assert "max_p" in warnings[0] and "min_p" in warnings[0]


def test_a_unit_with_pmax_and_pmin_gets_no_such_warning(tmp_path, caplog):
    with caplog.at_level(logging.WARNING):
        _parse_rd_with_gu(tmp_path, {"name": "Gen One", "target_p": 50.0, "max_p": 100.0, "min_p": 0.0})
    assert not any("GU1" in r.message for r in caplog.records if r.levelno == logging.WARNING)


# ===========================================================================
# Curative tap bounds on the real dataset
# ===========================================================================

DATA_ROOT_milp_builder_pst = DATA_ROOT


# ---------------------------------------------------------------------------
# build_pst_tap_bounds_curative — live data
# ---------------------------------------------------------------------------

class TestBuildPstTapBoundsCurativeLive:
    def test_real_curative_pst_has_no_resolvable_curative_bounds(self):
        """The dataset's curative PST (Espheim RA1) has no StaticPropertyRange entries."""
        from pre_milp.ncp_parser import build_tap_changer_to_transformer_map, build_pst_tap_bounds_curative

        eq_path = DATA_ROOT_milp_builder_pst / "Espheim" / "Grid" / "cimxml" / "20220615T2230Z__Espheim_EQ_1.xml"
        ra_path = DATA_ROOT_milp_builder_pst / "Espheim" / "NetworkCode" / "cimxml" / "Espheim_RA.xml"
        tap_changer_to_transformer = build_tap_changer_to_transformer_map(eq_path)

        result = build_pst_tap_bounds_curative(ra_path, tap_changer_to_transformer)

        assert result == {}

    def test_does_not_crash_on_a_file_with_non_pst_static_property_ranges(self):
        """Belgovia_RA.xml has StaticPropertyRanges, none on a PST's TapPositionAction
        (EquivalentInjectionAction/LoadAction): no crash and no PST entry."""
        from pre_milp.ncp_parser import build_tap_changer_to_transformer_map, build_pst_tap_bounds_curative

        eq_candidates = list((DATA_ROOT_milp_builder_pst / "Belgovia" / "Grid" / "cimxml").glob("*_EQ_*.xml"))
        assert eq_candidates
        tap_changer_to_transformer = build_tap_changer_to_transformer_map(eq_candidates[0])
        ra_path = DATA_ROOT_milp_builder_pst / "Belgovia" / "NetworkCode" / "cimxml" / "Belgovia_RA.xml"

        result = build_pst_tap_bounds_curative(ra_path, tap_changer_to_transformer)

        assert result == {}


# ===========================================================================
# Defaults with a warning: PST penalty factor, bid price
# ===========================================================================

_PST_RA_WITHOUT_PENALTY = """
    <nc:GridStateAlterationRemedialAction rdf:ID="_RA_PST">
      <cim:IdentifiedObject.mRID>RA_PST</cim:IdentifiedObject.mRID>
      <cim:IdentifiedObject.name>PST RA</cim:IdentifiedObject.name>
      <nc:RemedialAction.normalAvailable>true</nc:RemedialAction.normalAvailable>
      <nc:RemedialAction.kind rdf:resource="https://cim4.eu/ns/nc#RemedialActionKind.preventive"/>
    </nc:GridStateAlterationRemedialAction>
    <nc:TapPositionAction rdf:ID="_TPA1">
      <nc:GridStateAlteration.GridStateAlterationRemedialAction rdf:resource="#_RA_PST"/>
      <nc:TapPositionAction.TapChanger rdf:resource="#_TC1"/>
    </nc:TapPositionAction>
    """


def test_a_pst_remedial_action_without_penalty_factor_gets_one_with_a_warning(tmp_path, caplog):
    ra_path = _write_penalty_factor_ra(tmp_path, _PST_RA_WITHOUT_PENALTY)
    with caplog.at_level(logging.WARNING):
        psts = ncp_parser.parse_psts(ra_path, "TSO", {"T1": {"low_tap": -5, "high_tap": 5, "tap": 0}}, {"TC1": "T1"})
    assert psts[0].penalty_factor == 1.0
    assert any("RA_PST" in r.getMessage() and "penaltyFactor" in r.getMessage()
               for r in caplog.records if r.levelno == logging.WARNING)


_RD_RA = """
    <nc:GridStateAlterationRemedialAction rdf:ID="_RA1">
      <cim:IdentifiedObject.mRID>RA1</cim:IdentifiedObject.mRID>
      <nc:RemedialAction.normalAvailable>true</nc:RemedialAction.normalAvailable>
      <nc:RemedialAction.kind rdf:resource="https://cim4.eu/ns/nc#RemedialActionKind.preventive"/>
      <nc:RemedialAction.penaltyFactor>1.0</nc:RemedialAction.penaltyFactor>
    </nc:GridStateAlterationRemedialAction>
    <nc:RotatingMachineAction rdf:ID="_RMA1">
      <nc:GridStateAlteration.GridStateAlterationRemedialAction rdf:resource="#_RA1"/>
      <nc:RotatingMachineAction.RotatingMachine rdf:resource="#_GU1"/>
    </nc:RotatingMachineAction>
    """


def _bid_with_prices(tmp_path, prices_by_time):
    """One UP bid of RA1 with a time point per (atTime, price); price None leaves it out."""
    points = "".join(
        f"""
    <nc:PowerBidScheduleTimePoint rdf:ID="_TP{i}">
      <nc:PowerBidScheduleTimePoint.PowerBidSchedule rdf:resource="#_PBS1"/>
      <nc:PowerBidScheduleTimePoint.atTime>{at_time}</nc:PowerBidScheduleTimePoint.atTime>
      <nc:PowerBidScheduleTimePoint.p>10</nc:PowerBidScheduleTimePoint.p>
      {"" if price is None else f"<nc:PowerBidScheduleTimePoint.price>{price}</nc:PowerBidScheduleTimePoint.price>"}
    </nc:PowerBidScheduleTimePoint>"""
        for i, (at_time, price) in enumerate(prices_by_time)
    )
    sis = f"""
    <nc:PowerBidSchedule rdf:ID="_PBS1">
      <cim:IdentifiedObject.mRID>PBS1</cim:IdentifiedObject.mRID>
      <nc:PowerBidSchedule.PowerRemedialAction rdf:resource="#_RA1"/>
      <nc:PowerBidSchedule.direction rdf:resource="https://cim4.eu/ns/nc#BidDirectionKind.up"/>
    </nc:PowerBidSchedule>{points}
    """
    sis_path = tmp_path / "Test_SIS.xml"
    sis_path.write_text(_RA_HEADER + sis + _RA_FOOTER, encoding=TEXT_ENCODING)
    ra_path = _write_penalty_factor_ra(tmp_path, _RD_RA)
    _, bids = ncp_parser.parse_rd_units(
        ra_path, sis_path, "TSO", ["1030Z", "1130Z"],
        {"GU1": {"name": "GU1", "target_p": 50.0, "max_p": 100.0, "min_p": 0.0}},
    )
    return bids[0]


def test_the_bid_price_is_the_price_of_the_run_timestamp(tmp_path):
    bid = _bid_with_prices(tmp_path, [("2023-07-22T10:30:00Z", 25), ("2023-07-22T11:30:00Z", 40)])
    assert bid.price_eur_mw == 25.0


@pytest.mark.parametrize("points", [
    [("2023-07-22T10:30:00Z", -5), ("2023-07-22T11:30:00Z", 40)],    # negative at the run timestamp
    [("2023-07-22T11:30:00Z", 40)],                                    # no time point at the run timestamp
    [("2023-07-22T10:30:00Z", None), ("2023-07-22T11:30:00Z", 40)],  # time point without a price
])
def test_a_negative_or_missing_price_of_the_run_timestamp_is_zero_with_a_warning(tmp_path, caplog, points):
    with caplog.at_level(logging.WARNING):
        bid = _bid_with_prices(tmp_path, points)
    assert bid.price_eur_mw == 0.0
    assert any("PBS1" in r.getMessage() and "price" in r.getMessage()
               for r in caplog.records if r.levelno == logging.WARNING)


def _bid_from_sis(tmp_path, schedule_extra="", point_extra=""):
    sis = f"""
    <nc:PowerBidSchedule rdf:ID="_PBS1">
      <cim:IdentifiedObject.mRID>PBS1</cim:IdentifiedObject.mRID>
      <nc:PowerBidSchedule.PowerRemedialAction rdf:resource="#_RA1"/>
      <nc:PowerBidSchedule.direction rdf:resource="https://cim4.eu/ns/nc#BidDirectionKind.up"/>
      {schedule_extra}
    </nc:PowerBidSchedule>
    <nc:PowerBidScheduleTimePoint rdf:ID="_TP1">
      <nc:PowerBidScheduleTimePoint.PowerBidSchedule rdf:resource="#_PBS1"/>
      <nc:PowerBidScheduleTimePoint.atTime>2023-07-22T10:30:00Z</nc:PowerBidScheduleTimePoint.atTime>
      <nc:PowerBidScheduleTimePoint.p>10</nc:PowerBidScheduleTimePoint.p>
      <nc:PowerBidScheduleTimePoint.price>25</nc:PowerBidScheduleTimePoint.price>
      {point_extra}
    </nc:PowerBidScheduleTimePoint>
    """
    sis_path = tmp_path / "Test_SIS.xml"
    sis_path.write_text(_RA_HEADER + sis + _RA_FOOTER, encoding=TEXT_ENCODING)
    _, bids = ncp_parser.parse_rd_units(
        _write_penalty_factor_ra(tmp_path, _RD_RA), sis_path, "TSO", ["1030Z"],
        {"GU1": {"name": "GU1", "target_p": 50.0, "max_p": 100.0, "min_p": 0.0}},
    )
    return bids[0]


def test_the_time_point_activation_cost_overrides_the_schedule_one_and_the_reserve_price_is_read(tmp_path):
    """O1: PowerBidScheduleTimePoint.activationCost overrides PowerBidSchedule.activationCost;
    PowerBidScheduleTimePoint.reservePrice is the curative reservation price."""
    bid = _bid_from_sis(
        tmp_path,
        schedule_extra="<nc:PowerBidSchedule.activationCost>100</nc:PowerBidSchedule.activationCost>",
        point_extra="<nc:PowerBidScheduleTimePoint.activationCost>250</nc:PowerBidScheduleTimePoint.activationCost>"
                    "<nc:PowerBidScheduleTimePoint.reservePrice>7.5</nc:PowerBidScheduleTimePoint.reservePrice>",
    )
    assert bid.activation_cost_eur == 250.0 and bid.reserve_price_eur_mw == 7.5


def test_a_negative_reserve_price_gives_a_warning_and_is_used_as_zero(tmp_path, caplog):
    """O1 rule 4 [review]: a negative reservePrice is handled like a negative energy price."""
    with caplog.at_level(logging.WARNING):
        bid = _bid_from_sis(
            tmp_path,
            point_extra="<nc:PowerBidScheduleTimePoint.reservePrice>-4</nc:PowerBidScheduleTimePoint.reservePrice>",
        )
    assert bid.reserve_price_eur_mw == 0.0
    assert any("PBS1" in r.getMessage() and "negative reservePrice" in r.getMessage()
               for r in caplog.records if r.levelno == logging.WARNING)


def _rd_reaction_time(tmp_path, time_to_implement):
    """reaction_time_minutes of RA1 with the given RemedialAction.timeToImplement (None: absent)."""
    element = ("" if time_to_implement is None else
               f"<nc:RemedialAction.timeToImplement>{time_to_implement}</nc:RemedialAction.timeToImplement>")
    body = _RD_RA.replace("<nc:RemedialAction.penaltyFactor>", element + "<nc:RemedialAction.penaltyFactor>")
    rd_units, _ = ncp_parser.parse_rd_units(
        _write_penalty_factor_ra(tmp_path, body), None, "TSO", ["1030Z"],
        {"GU1": {"name": "GU1", "target_p": 50.0, "max_p": 100.0, "min_p": 0.0}},
    )
    return rd_units[0].reaction_time_minutes


@pytest.mark.parametrize("time_to_implement, minutes", [
    ("PT15M", 15.0), ("P1D", 1440.0), ("P1DT2H", 1560.0), ("P0Y0M0DT0H10M0S", 10.0),
])
def test_rd_time_to_implement_is_read_in_minutes_including_days(tmp_path, caplog, time_to_implement, minutes):
    """R9 rules 1 and 9 [review]: ISO-8601 durations with a day part are read; no warning."""
    with caplog.at_level(logging.WARNING):
        assert _rd_reaction_time(tmp_path, time_to_implement) == pytest.approx(minutes)
    assert not any("timeToImplement" in r.getMessage() for r in caplog.records)


@pytest.mark.parametrize("time_to_implement", ["fifteen minutes", "PT", "P1M"])
def test_an_unreadable_rd_time_to_implement_is_zero_with_a_warning(tmp_path, caplog, time_to_implement):
    """R9 rule 9 [review]: a value that cannot be read (a month has no fixed length) counts as
    0 (available everywhere) and writes a warning naming the RA."""
    with caplog.at_level(logging.WARNING):
        assert _rd_reaction_time(tmp_path, time_to_implement) == 0.0
    assert any("RA1" in r.getMessage() and "unreadable" in r.getMessage() and "timeToImplement" in r.getMessage()
               for r in caplog.records if r.levelno == logging.WARNING)


def test_a_missing_rd_time_to_implement_is_none_without_a_warning(tmp_path, caplog):
    """R9 rule 5: absent = reaction time 0 (None), no warning."""
    with caplog.at_level(logging.WARNING):
        assert _rd_reaction_time(tmp_path, None) is None
    assert not any("timeToImplement" in r.getMessage() for r in caplog.records)


@pytest.mark.parametrize("lead_time, hours", [("PT2H", 2.0), ("P1D", 24.0), ("P1DT2H", 26.0)])
def test_a_bid_lead_time_with_a_day_part_is_read_in_hours(tmp_path, lead_time, hours):
    """R9 note [review]: the day part of the shared duration parser also applies to
    PowerBidSchedule.leadTime (P1D = 24 h; it used to be read as 0 h)."""
    bid = _bid_from_sis(tmp_path, schedule_extra=f"<nc:PowerBidSchedule.leadTime>{lead_time}</nc:PowerBidSchedule.leadTime>")
    assert bid.lead_time_h == pytest.approx(hours)


def test_without_time_point_values_the_schedule_activation_cost_stays_and_no_reserve_price(tmp_path):
    bid = _bid_from_sis(tmp_path, schedule_extra="<nc:PowerBidSchedule.activationCost>100</nc:PowerBidSchedule.activationCost>")
    assert bid.activation_cost_eur == 100.0 and bid.reserve_price_eur_mw is None


@pytest.mark.parametrize("currency, warns", [("USD", True), ("EUR", False)])
def test_a_bid_currency_other_than_eur_gives_a_warning(tmp_path, caplog, currency, warns):
    """O1: all costs are taken as EUR; another currency is warned about (no conversion)."""
    with caplog.at_level(logging.WARNING):
        _bid_from_sis(tmp_path, schedule_extra=(
            f'<nc:PowerBidSchedule.currency rdf:resource="https://cim.ucaiug.io/ns#Currency.{currency}"/>'
        ))
    assert any("not EUR" in r.getMessage() for r in caplog.records) is warns


def test_a_missing_penalty_factor_gives_one_with_a_log_line(tmp_path, caplog):
    """O1 rule 5: a missing RemedialAction.penaltyFactor is 1.0, logged as a default."""
    body = _RD_RA.replace("<nc:RemedialAction.penaltyFactor>1.0</nc:RemedialAction.penaltyFactor>", "")
    with caplog.at_level(logging.WARNING):
        rd_units, _ = ncp_parser.parse_rd_units(
            _write_penalty_factor_ra(tmp_path, body), None, "TSO", ["1030Z"],
            {"GU1": {"name": "GU1", "target_p": 50.0, "max_p": 100.0, "min_p": 0.0}},
        )
    assert rd_units[0].penalty_factor == 1.0
    assert any("penaltyFactor" in r.getMessage() and "1.0" in r.getMessage() for r in caplog.records)


# ---- generating unit start-up / shut-down costs (F2 rules 4, 5) -------------

def _unit_cost_files(tmp_path, sis_points="", er_body=""):
    sis = f"""
    <nc:UnitCostSchedule rdf:ID="_UCS1">
      <nc:UnitCostSchedule.GeneratingUnit rdf:resource="#_GEN_UNIT_1"/>
      <nc:UnitCostSchedule.currency rdf:resource="https://cim.ucaiug.io/ns#Currency.EUR"/>
    </nc:UnitCostSchedule>
    <nc:UnitCostTimePoint rdf:ID="_UCT1">
      <nc:UnitCostTimePoint.UnitCostSchedule rdf:resource="#_UCS1"/>
      <nc:UnitCostTimePoint.atTime>2023-07-22T10:30:00Z</nc:UnitCostTimePoint.atTime>
      {sis_points}
    </nc:UnitCostTimePoint>
    <nc:UnitCostTimePoint rdf:ID="_UCT2">
      <nc:UnitCostTimePoint.UnitCostSchedule rdf:resource="#_UCS1"/>
      <nc:UnitCostTimePoint.atTime>2023-07-22T11:30:00Z</nc:UnitCostTimePoint.atTime>
      <nc:UnitCostTimePoint.warmStartupCost>999</nc:UnitCostTimePoint.warmStartupCost>
    </nc:UnitCostTimePoint>
    """
    sis_path, er_path = tmp_path / "T_SIS.xml", tmp_path / "T_ER.xml"
    sis_path.write_text(_RA_HEADER + sis + _RA_FOOTER, encoding=TEXT_ENCODING)
    er_path.write_text(_RA_HEADER + er_body + _RA_FOOTER, encoding=TEXT_ENCODING)
    return sis_path, er_path


_ER_UNIT = """
    <cim:GeneratingUnit rdf:about="#_GEN_UNIT_1">
      <nc:GeneratingUnit.normalWarmStartupCost>3000</nc:GeneratingUnit.normalWarmStartupCost>
      <nc:GeneratingUnit.normalShutdownCost>400</nc:GeneratingUnit.normalShutdownCost>
    </cim:GeneratingUnit>
"""


@pytest.mark.parametrize("sis_points, expected_startup, expected_shutdown", [
    ("<nc:UnitCostTimePoint.warmStartupCost>1000</nc:UnitCostTimePoint.warmStartupCost>"
     "<nc:UnitCostTimePoint.startupCost>2000</nc:UnitCostTimePoint.startupCost>"
     "<nc:UnitCostTimePoint.shutdownCost>100</nc:UnitCostTimePoint.shutdownCost>", 1000.0, 100.0),
    ("<nc:UnitCostTimePoint.startupCost>2000</nc:UnitCostTimePoint.startupCost>", 2000.0, 400.0),
    ("", 3000.0, 400.0),     # ER fallback for both
])
def test_unit_costs_follow_the_agreed_source_priority(tmp_path, sis_points, expected_startup, expected_shutdown):
    """F2 rule 4: warmStartupCost, startupCost (SIS, run time point), normalWarmStartupCost
    (ER); rule 5: shutdownCost (SIS), normalShutdownCost (ER). Keyed by the generator id."""
    sis_path, er_path = _unit_cost_files(tmp_path, sis_points, _ER_UNIT)
    costs = ncp_parser.parse_unit_costs(sis_path, er_path, "T", "1030Z", {"GEN_UNIT_1": "SM_1"})
    assert costs["SM_1"].startup_cost_eur == expected_startup
    assert costs["SM_1"].shutdown_cost_eur == expected_shutdown


def test_a_unit_without_any_cost_gets_none_and_no_er_file_is_fine(tmp_path):
    sis_path, _ = _unit_cost_files(tmp_path)
    costs = ncp_parser.parse_unit_costs(sis_path, None, "T", "1030Z")
    assert costs["GEN_UNIT_1"].startup_cost_eur is None and costs["GEN_UNIT_1"].shutdown_cost_eur is None


def test_a_negative_start_up_cost_is_fatal(tmp_path):
    """BUC 14#103 4855: a negative startupCost cancels the RAO."""
    sis_path, _ = _unit_cost_files(tmp_path, "<nc:UnitCostTimePoint.warmStartupCost>-5</nc:UnitCostTimePoint.warmStartupCost>")
    with pytest.raises(ValueError, match="negative start-up cost"):
        ncp_parser.parse_unit_costs(sis_path, None, "T", "1030Z")


def test_a_unit_cost_currency_other_than_eur_gives_a_warning(tmp_path, caplog):
    sis_path, _ = _unit_cost_files(tmp_path, "<nc:UnitCostTimePoint.startupCost>10</nc:UnitCostTimePoint.startupCost>")
    sis_path.write_text(sis_path.read_text(encoding=TEXT_ENCODING).replace("Currency.EUR", "Currency.SEK"), encoding=TEXT_ENCODING)
    with caplog.at_level(logging.WARNING):
        ncp_parser.parse_unit_costs(sis_path, None, "T", "1030Z")
    assert any("SEK" in r.getMessage() and "not EUR" in r.getMessage() for r in caplog.records)

# ===========================================================================
# EQ file parsed once for both maps
# ===========================================================================

def _fixture_eq_files():
    return sorted(DATA_ROOT.glob("*/Grid/cimxml/*_EQ_*.xml"))


@pytest.mark.parametrize("eq_path", _fixture_eq_files(), ids=lambda p: p.name)
def test_both_eq_maps_from_one_parsed_graph_equal_the_maps_from_separate_parses(eq_path):
    graph = ncp_parser.load_eq_graph(eq_path)
    assert ncp_parser.build_tap_changer_to_transformer_map(eq_path, graph=graph) == (
        ncp_parser.build_tap_changer_to_transformer_map(eq_path)
    )
    assert ncp_parser.build_current_limit_side_map(eq_path, graph=graph) == (
        ncp_parser.build_current_limit_side_map(eq_path)
    )


class _StopAfterParsing(Exception):
    pass


def test_the_pipeline_parses_each_eq_file_once(tmp_path):
    """Every EQ file of the fixture run is read exactly once (both maps share the result)."""
    from helpers import run_pipeline_on_fixture_inputs, FIXTURE_NCP_GENERIC_ZIP

    parsed: list[str] = []

    def customize(rp, monkeypatch):
        real_load = rp.ncp_parser._load_graph

        def counting_load(path, **kwargs):
            parsed.append(Path(path).name)
            return real_load(path, **kwargs)

        def stop(*args, **kwargs):
            raise _StopAfterParsing()

        real_stream = rp.ncp_parser.stream_eq

        def counting_stream(path):
            parsed.append(Path(path).name)
            return real_stream(path)

        monkeypatch.setattr(rp.ncp_parser, "_load_graph", counting_load)
        monkeypatch.setattr(rp.ncp_parser, "stream_eq", counting_stream)     # the EQ files are streamed, not parsed
        monkeypatch.setattr(rp.cgmes_loader, "write_lf_basecase_csv", stop)

    with pytest.raises(_StopAfterParsing):
        run_pipeline_on_fixture_inputs(tmp_path, FIXTURE_NCP_GENERIC_ZIP, enable_nx_analysis=False,
                                       customize_pipeline=customize)
    eq_parses = [name for name in parsed if "_EQ_" in name]
    assert eq_parses, "the fixture run parses EQ files"
    assert len(eq_parses) == len(set(eq_parses))


# ---------------------------------------------------------------------------
# power bids in the standard form (WP2): direction, sign cross-check, interpolation, unsupported attributes
# ---------------------------------------------------------------------------

_BID_TS = ["1030Z", "1130Z"]


def _bid_xml(direction="up", points=(("2022-06-15T10:30:00Z", 50, 95),), interpolation="none", extra="", mrid="PB1", ra="RA1",
             point_extra=""):
    direction_xml = (f'<nc:PowerBidSchedule.direction rdf:resource="https://cim4.eu/ns/nc#MarketRegulationDirectionKind.{direction}"/>'
                     if direction else "")
    interpolation_xml = (f'<nc:BaseTimeSeries.interpolationKind rdf:resource="https://cim4.eu/ns/nc#TimeSeriesInterpolationKind.{interpolation}"/>'
                         if interpolation else "")
    body = f"""
    <nc:PowerBidSchedule rdf:ID="_{mrid}">
      <cim:IdentifiedObject.mRID>{mrid}</cim:IdentifiedObject.mRID>
      <nc:PowerBidSchedule.PowerRemedialAction rdf:resource="#_{ra}"/>
      {direction_xml}{interpolation_xml}{extra}
    </nc:PowerBidSchedule>"""
    for i, (at, p, price) in enumerate(points):
        body += f"""
    <nc:PowerBidScheduleTimePoint rdf:ID="_{mrid}-TP{i}">
      <nc:PowerBidScheduleTimePoint.PowerBidSchedule rdf:resource="#_{mrid}"/>
      <nc:PowerBidScheduleTimePoint.atTime>{at}</nc:PowerBidScheduleTimePoint.atTime>
      <nc:PowerBidScheduleTimePoint.p>{p}</nc:PowerBidScheduleTimePoint.p>
      <nc:PowerBidScheduleTimePoint.price>{price}</nc:PowerBidScheduleTimePoint.price>{point_extra}
    </nc:PowerBidScheduleTimePoint>"""
    return body


def _parse_bids(tmp_path, body, caplog=None, ras=("RA1",)):
    path = _write_ra_groups_xml(tmp_path, "Bids_SIS.xml", body)
    graph = ncp_parser._load_graph(path)
    if caplog is None:
        return ncp_parser.parse_power_bids(graph, set(ras), "TestTSO", _BID_TS)
    with caplog.at_level(logging.WARNING):
        return ncp_parser.parse_power_bids(graph, set(ras), "TestTSO", _BID_TS)


def _warnings(caplog, *words):
    return [r.getMessage() for r in caplog.records if r.levelno >= logging.WARNING and all(w in r.getMessage() for w in words)]


@pytest.mark.parametrize("literal, expected", [("up", "UP"), ("down", "DOWN")])
def test_bid_direction_is_the_literal_and_the_size_is_the_magnitude(tmp_path, caplog, literal, expected):
    sign = 1 if literal == "up" else -1
    bids = _parse_bids(tmp_path, _bid_xml(literal, points=(("2022-06-15T10:30:00Z", 50 * sign, 95),)), caplog)
    assert [(b.direction.name, b.available_mw["1030Z"]) for b in bids] == [(expected, 50.0)]
    assert _warnings(caplog, "sign") == []


def test_bid_direction_matches_by_the_last_word_of_any_namespace(tmp_path):
    body = _bid_xml("up").replace("MarketRegulationDirectionKind.up", "BidDirectionKind.up")
    assert [b.direction.name for b in _parse_bids(tmp_path, body)] == ["UP"]


def test_a_bid_without_direction_is_skipped_with_a_warning_and_never_inferred_from_p(tmp_path, caplog):
    body = _bid_xml(None, points=(("2022-06-15T10:30:00Z", -50, 95),), mrid="PB-NODIR") + _bid_xml("up", mrid="PB-OK")
    bids = _parse_bids(tmp_path, body, caplog)
    assert [b.mrid for b in bids] == ["PB-OK"]
    messages = _warnings(caplog, "PB-NODIR", "no direction")
    assert len(messages) == 1 and "skipped" in messages[0]


@pytest.mark.parametrize("literal", ["upAndDown", "stable"])
def test_a_bid_direction_other_than_up_or_down_is_skipped_with_a_warning(tmp_path, caplog, literal):
    assert _parse_bids(tmp_path, _bid_xml(literal, mrid="PB-X"), caplog) == []
    assert len(_warnings(caplog, "PB-X", literal, "skipped")) == 1


@pytest.mark.parametrize("literal, p, warns", [("up", 50, False), ("up", -50, True), ("down", -50, False), ("down", 50, True), ("up", 0, False)])
def test_the_sign_of_p_is_only_a_cross_check(tmp_path, caplog, literal, p, warns):
    bids = _parse_bids(tmp_path, _bid_xml(literal, points=(("2022-06-15T10:30:00Z", p, 95),), mrid="PB-S"), caplog)
    assert bids[0].available_mw["1030Z"] == abs(p) and bids[0].direction.name == literal.upper()
    assert len(_warnings(caplog, "PB-S", "sign")) == (1 if warns else 0)


_TWO_POINTS = (("2022-06-15T10:30:00Z", 40, 10), ("2022-06-15T11:30:00Z", 80, 30))


@pytest.mark.parametrize("kind, at_1030, at_1130", [("none", 40.0, 80.0), ("previous", 40.0, 80.0), ("next", 40.0, 80.0), ("linear", 40.0, 80.0)])
def test_interpolation_keeps_the_values_at_exact_time_points(tmp_path, kind, at_1030, at_1130):
    bid = _parse_bids(tmp_path, _bid_xml("up", points=_TWO_POINTS, interpolation=kind))[0]
    assert (bid.available_mw["1030Z"], bid.available_mw["1130Z"]) == (at_1030, at_1130)


@pytest.mark.parametrize("kind, expected, price", [("none", 0.0, 0.0), ("previous", 40.0, 10.0), ("next", 80.0, 30.0), ("linear", 60.0, 20.0)])
def test_interpolation_kind_decides_the_value_between_time_points(tmp_path, caplog, kind, expected, price):
    """Run timestamp 1100Z lies between the points 1030Z and 1130Z."""
    path = _write_ra_groups_xml(tmp_path, "Bids_SIS.xml", _bid_xml("up", points=_TWO_POINTS, interpolation=kind))
    with caplog.at_level(logging.WARNING):
        bids = ncp_parser.parse_power_bids(ncp_parser._load_graph(path), {"RA1"}, "TestTSO", ["1100Z"])
    assert bids[0].available_mw["1100Z"] == expected and bids[0].price_eur_mw == price


def test_a_bid_without_interpolation_kind_uses_none_with_one_warning(tmp_path, caplog):
    body = _bid_xml("up", interpolation=None, mrid="PB1") + _bid_xml("down", interpolation=None, mrid="PB2", points=(("2022-06-15T10:30:00Z", -5, 1),))
    bids = _parse_bids(tmp_path, body, caplog)
    assert len(bids) == 2
    messages = _warnings(caplog, "interpolationKind")
    assert len(messages) == 1 and "2 bid" in messages[0] and "none" in messages[0]


def test_an_unknown_interpolation_kind_is_none_with_a_warning(tmp_path, caplog):
    bids = _parse_bids(tmp_path, _bid_xml("up", interpolation="cubic", mrid="PB-C"), caplog)
    assert bids[0].available_mw["1030Z"] == 50.0 and len(_warnings(caplog, "PB-C", "cubic")) == 1


def test_bid_attributes_that_are_not_read_are_named_in_one_warning_per_bid(tmp_path, caplog):
    extra = ("<nc:PowerBidSchedule.isFixed>true</nc:PowerBidSchedule.isFixed>"
             "<nc:PowerBidSchedule.totalMinimumEnergy>10</nc:PowerBidSchedule.totalMinimumEnergy>"
             "<nc:PowerBidSchedule.totalMaximumEnergy>90</nc:PowerBidSchedule.totalMaximumEnergy>")
    point_extra = ("<nc:PowerBidScheduleTimePoint.minimumActivationP>5</nc:PowerBidScheduleTimePoint.minimumActivationP>"
                   "<nc:PowerBidScheduleTimePoint.stepIncrementP>5</nc:PowerBidScheduleTimePoint.stepIncrementP>")
    bids = _parse_bids(tmp_path, _bid_xml("up", extra=extra, point_extra=point_extra, mrid="PB-U"), caplog)
    assert len(bids) == 1
    messages = _warnings(caplog, "PB-U", "not read")
    assert len(messages) == 1
    for name in ("isFixed", "totalMinimumEnergy", "totalMaximumEnergy", "minimumActivationP", "stepIncrementP"):
        assert name in messages[0]


def test_is_fixed_false_is_not_warned_about(tmp_path, caplog):
    _parse_bids(tmp_path, _bid_xml("up", extra="<nc:PowerBidSchedule.isFixed>false</nc:PowerBidSchedule.isFixed>", mrid="PB-F"), caplog)
    assert _warnings(caplog, "PB-F") == []


def test_non_standard_bid_attributes_are_still_read_with_one_deprecation_warning(tmp_path, caplog):
    extra = ("<nc:PowerBidSchedule.penaltyFactor>2.0</nc:PowerBidSchedule.penaltyFactor>"
             "<nc:PowerBidSchedule.minEnergyBid>1</nc:PowerBidSchedule.minEnergyBid>")
    bids = _parse_bids(tmp_path, _bid_xml("up", extra=extra, mrid="PB-N") + _bid_xml("down", extra=extra, mrid="PB-M", points=(("2022-06-15T10:30:00Z", -5, 1),)), caplog)
    assert [b.penalty_factor for b in bids] == [2.0, 2.0] and bids[0].min_energy_mwh == 1.0
    messages = _warnings(caplog, "deprecated")
    assert len(messages) == 1 and "2 bid" in messages[0] and "penaltyFactor" in messages[0]


def test_bid_dependencies_are_warned_about_and_not_read(tmp_path, caplog):
    body = """
    <nc:PowerBidDependency rdf:ID="_D1">
      <nc:PeerTemporalDependency.constraintKind rdf:resource="https://cim4.eu/ns/nc#DependencyConstraintKind.exclusive"/>
      <nc:PowerBidDependency.DependeePowerBidSchedule rdf:resource="#_PB1"/>
      <nc:PowerBidDependency.DependentPowerBidSchedule rdf:resource="#_PB2"/>
    </nc:PowerBidDependency>"""
    path = _write_ra_groups_xml(tmp_path, "Dep_SIS.xml", body)
    with caplog.at_level(logging.WARNING):
        ncp_parser.warn_unsupported_sis_content(path, "TestTSO")
    messages = _warnings(caplog, "PowerBidDependency")
    assert len(messages) == 1 and "Dep_SIS.xml" in messages[0] and "not read" in messages[0] and "1 " in messages[0]
