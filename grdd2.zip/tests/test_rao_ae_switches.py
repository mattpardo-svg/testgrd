"""tests/test_rao_ae_switches.py - the NCP switches of the assessed elements are applied (an absent switch means
enabled): normalEnabled / the time-dependent enabled (not monitored), inBaseCase (not in the N state), the links to
contingencies (monitored only after / not after them), isCombinableWithContingency=false (only the included links);
isCombinableWithRemedialAction and the links to remedial actions are still only warned about (OPEN-33). Parser level (hand
written files), MILP level (the constraint is absent, the result differs) and pipeline level (mock_data variants)."""

import logging

import pytest
import pyomo.environ as pyo

from data_model import AEType, AssessedElement
from milp.milp_builder import NxMilpInputs, build_n0_milp_model
from pre_milp import ncp_parser, run_time
from mock_data import ae_switch_variants
from text_encoding import TEXT_ENCODING

HEADER = ('<?xml version="1.0"?><rdf:RDF xmlns:rdf="http://www.w3.org/1999/02/22-rdf-syntax-ns#" '
          'xmlns:cim="https://cim.ucaiug.io/ns#" xmlns:nc="https://cim4.eu/ns/nc#">')
NC_NS = "https://cim4.eu/ns/nc#"
TS = ["1730Z"]


def _ae(name, **properties):
    body = "".join(f"<nc:AssessedElement.{key}>{value}</nc:AssessedElement.{key}>" for key, value in properties.items())
    return (f'<nc:AssessedElement rdf:ID="_{name}"><cim:IdentifiedObject.mRID>{name}</cim:IdentifiedObject.mRID>'
            f'<nc:AssessedElement.ConductingEquipment rdf:resource="#_BR-{name}"/>'
            f'<nc:AssessedElement.SecuredForRegion rdf:resource="#_REGION"/>{body}</nc:AssessedElement>')


def _link(element, contingency, kind="included", enabled=None):
    flag = f"<nc:AssessedElementWithContingency.normalEnabled>{enabled}</nc:AssessedElementWithContingency.normalEnabled>" if enabled else ""
    kind_xml = f'<nc:AssessedElementWithContingency.combinationConstraintKind rdf:resource="{NC_NS}ElementCombinationConstraintKind.{kind}"/>' if kind else ""
    return (f'<nc:AssessedElementWithContingency rdf:ID="_L-{element}-{contingency}">'
            f'<nc:AssessedElementWithContingency.AssessedElement rdf:resource="#_{element}"/>'
            f'<nc:AssessedElementWithContingency.Contingency rdf:resource="#_{contingency}"/>{kind_xml}{flag}</nc:AssessedElementWithContingency>')


def _schedule(element, points, kind="none"):
    xml = (f'<nc:AssessedElementSchedule rdf:ID="_S-{element}"><nc:AssessedElementSchedule.AssessedElement rdf:resource="#_{element}"/>'
           f'<nc:BaseTimeSeries.interpolationKind rdf:resource="{NC_NS}TimeSeriesInterpolationKind.{kind}"/></nc:AssessedElementSchedule>')
    for n, (when, enabled) in enumerate(points):
        xml += (f'<nc:AssessedElementTimePoint rdf:ID="_P-{element}-{n}"><nc:AssessedElementTimePoint.AssessedElementSchedule rdf:resource="#_S-{element}"/>'
                f"<nc:AssessedElementTimePoint.atTime>{when}</nc:AssessedElementTimePoint.atTime>"
                f"<nc:AssessedElementTimePoint.enabled>{enabled}</nc:AssessedElementTimePoint.enabled></nc:AssessedElementTimePoint>")
    return xml


def _parse(tmp_path, ae_body, sis_body=None, caplog=None):
    ae = tmp_path / "X_AE.xml"
    ae.write_text(HEADER + ae_body + "</rdf:RDF>", encoding=TEXT_ENCODING)
    sis = None
    if sis_body is not None:
        sis = tmp_path / "X_SIS.xml"
        sis.write_text(HEADER + sis_body + "</rdf:RDF>", encoding=TEXT_ENCODING)
    if caplog is None:
        return {a.mrid: a for a in ncp_parser.parse_assessed_elements(ae, None, "X", TS, {"BR-A": {1: 1000.0}}, sis_path=sis)}
    with caplog.at_level(logging.INFO, logger=ncp_parser.log.name):
        return {a.mrid: a for a in ncp_parser.parse_assessed_elements(ae, None, "X", TS, {"BR-A": {1: 1000.0}}, sis_path=sis)}


def _messages(caplog, *words):
    return [r.getMessage() for r in caplog.records if all(w in r.getMessage() for w in words)]


# --- parser: what is read -------------------------------------------------------------------------------

def test_rao_an_element_without_switches_is_monitored_everywhere(tmp_path):
    a = _parse(tmp_path, _ae("A"))["A"]
    assert a.ae_type != AEType.EXCLUDED and a.in_base_case and a.included_contingencies is None
    assert a.excluded_contingencies == () and a.switch_notes == ()


def test_rao_normal_enabled_false_takes_the_element_out_with_its_reason(tmp_path):
    a = _parse(tmp_path, _ae("A", normalEnabled="false"))["A"]
    assert a.ae_type == AEType.EXCLUDED and a.exclusion_reason == "disabled by the NCP"
    assert a.switch_notes == ("AssessedElement.normalEnabled=false",)


def test_rao_enabled_true_switches_stay_unchanged(tmp_path):
    a = _parse(tmp_path, _ae("A", normalEnabled="true", inBaseCase="true", isCombinableWithContingency="true"))["A"]
    assert a.ae_type != AEType.EXCLUDED and a.in_base_case and a.switch_notes == ()


def test_rao_in_base_case_false_is_kept_for_the_contingency_states(tmp_path):
    a = _parse(tmp_path, _ae("A", inBaseCase="false"))["A"]
    assert a.ae_type != AEType.EXCLUDED and not a.in_base_case
    assert a.switch_notes == ("inBaseCase=false (monitored after contingencies only)",)


def test_rao_links_restrict_the_element_to_or_away_from_contingencies(tmp_path):
    parsed = _parse(tmp_path, _ae("A") + _ae("B") + _ae("C") + _link("A", "CO1") + _link("A", "CO2", "included")
                    + _link("B", "CO3", "excluded") + _link("C", "CO1", "included", enabled="false"))
    assert parsed["A"].included_contingencies == ("CO1", "CO2") and parsed["A"].excluded_contingencies == ()
    assert parsed["B"].included_contingencies is None and parsed["B"].excluded_contingencies == ("CO3",)
    assert parsed["C"].included_contingencies is None and parsed["C"].switch_notes == ()       # a disabled link is ignored


def test_rao_a_link_with_a_missing_or_unknown_kind_is_treated_as_absent_with_a_warning(tmp_path, caplog):
    parsed = _parse(tmp_path, _ae("A") + _link("A", "CO1", kind=None) + _link("A", "CO2", kind="whatever")
                    + _ae("B") + _link("B", "CO1", kind=None) + _link("B", "CO2", "included"), caplog=caplog)
    assert parsed["A"].included_contingencies is None and parsed["A"].excluded_contingencies == ()
    assert parsed["B"].included_contingencies == ("CO2",)
    assert len(_messages(caplog, "3 AssessedElementWithContingency link(s) with a missing or unknown combinationConstraintKind",
                         "treated as absent")) == 1
    assert not _messages(caplog, "read as included")


@pytest.mark.parametrize("combinable", ["true", "false"])
def test_rao_a_link_with_normal_enabled_false_is_ignored_as_if_absent(tmp_path, combinable):
    """Pinned (DECISIONS 143): a disabled link counts for nothing, whatever the kind and isCombinableWithContingency."""
    parsed = _parse(tmp_path, _ae("A", isCombinableWithContingency=combinable) + _link("A", "CO1", "included", enabled="false")
                    + _link("A", "CO2", "excluded", enabled="false"))
    expected = None if combinable == "true" else ()
    assert parsed["A"].included_contingencies == expected and parsed["A"].excluded_contingencies == ()


def _ae_with_base_case_limit(name, **properties):
    body = "".join(f"<nc:AssessedElement.{key}>{value}</nc:AssessedElement.{key}>" for key, value in properties.items())
    return (f'<nc:AssessedElement rdf:ID="_{name}"><cim:IdentifiedObject.mRID>{name}</cim:IdentifiedObject.mRID>'
            f'<nc:AssessedElement.ConductingEquipment rdf:resource="#_BR-{name}"/>'
            f'<nc:AssessedElement.SecuredForRegion rdf:resource="#_REGION"/>'
            f'<nc:AssessedElement.OperationalLimit rdf:resource="#_OL-{name}"/>{body}</nc:AssessedElement>'
            f'<nc:BaseCaseCurrentLimit rdf:ID="_OL-{name}"><nc:BaseCaseCurrentLimit.normalValue>900</nc:BaseCaseCurrentLimit.normalValue></nc:BaseCaseCurrentLimit>')


def test_rao_in_base_case_false_with_a_base_case_current_limit_is_scanned_in_the_base_case_with_a_warning(tmp_path, caplog):
    parsed = _parse(tmp_path, _ae_with_base_case_limit("A", inBaseCase="false") + _ae_with_base_case_limit("B", inBaseCase="true")
                    + _ae_with_base_case_limit("C", inBaseCase="false") + _ae("D", inBaseCase="false"), caplog=caplog)
    for name in "AC":
        assert parsed[name].in_base_case and parsed[name].ae_type != AEType.EXCLUDED
        assert parsed[name].switch_notes == ("inBaseCase=false with a BaseCaseCurrentLimit (not allowed): scanned in the base case",)
    assert parsed["B"].in_base_case and parsed["B"].switch_notes == ()
    assert not parsed["D"].in_base_case                                         # no BaseCaseCurrentLimit: inBaseCase=false stays
    assert len(_messages(caplog, "2 AssessedElement(s) with a BaseCaseCurrentLimit and inBaseCase=false", "scanned in the base case")) == 1


def test_rao_a_considered_link_is_not_allowed_and_is_treated_as_absent(tmp_path, caplog):
    parsed = _parse(tmp_path, _ae("A") + _link("A", "CO1", "considered") + _link("A", "CO2", "considered")
                    + _ae("B") + _link("B", "CO1", "considered") + _link("B", "CO2", "included"), caplog=caplog)
    assert parsed["A"].included_contingencies is None and parsed["A"].excluded_contingencies == ()
    assert parsed["A"].switch_notes == ()
    assert parsed["B"].included_contingencies == ("CO2",)
    assert len(_messages(caplog, "3 AssessedElementWithContingency link(s)", "considered", "treated as absent")) == 1


def test_rao_is_combinable_with_contingency_false_keeps_only_the_included_links(tmp_path, caplog):
    parsed = _parse(tmp_path, _ae("A", isCombinableWithContingency="false") + _link("A", "CO1") + _link("A", "CO2", "excluded")
                    + _ae("B", isCombinableWithContingency="false")
                    + _ae("C", isCombinableWithContingency="false") + _link("C", "CO1", "considered")
                    + _ae("D", isCombinableWithContingency="false") + _link("D", "CO1", "included", enabled="false")
                    + _ae("E", isCombinableWithContingency="true") + _ae("F", isCombinableWithContingency="false", inBaseCase="false"),
                    caplog=caplog)
    assert parsed["A"].included_contingencies == ("CO1",) and parsed["A"].excluded_contingencies == ("CO2",)
    for name in "BCD":                                      # no usable included link: assessed after no contingency
        assert parsed[name].included_contingencies == () and parsed[name].in_base_case
    assert parsed["E"].included_contingencies is None and parsed["E"].switch_notes == ()
    assert parsed["F"].included_contingencies == () and not parsed["F"].in_base_case
    assert parsed["B"].switch_notes == ("isCombinableWithContingency=false (monitored only after the 0 contingency(ies) with an included link [])",)
    assert not _messages(caplog, "isCombinableWithContingency=false", "NOT applied")


def test_rao_every_switched_element_is_logged_and_counted(tmp_path, caplog):
    _parse(tmp_path, _ae("A", normalEnabled="false") + _ae("B", inBaseCase="false") + _ae("C"), caplog=caplog)
    assert len(_messages(caplog, "assessed element A", "normalEnabled=false")) == 1
    assert len(_messages(caplog, "assessed element B", "inBaseCase=false")) == 1
    summary = _messages(caplog, "2 assessed element(s) switched off or restricted by NCP switches: A, B")
    assert len(summary) == 1 and not _messages(caplog, "assessed element C")


def test_rao_is_combinable_with_remedial_action_remains_a_warning_only(tmp_path, caplog):
    parsed = _parse(tmp_path, _ae("A", isCombinableWithRemedialAction="false"), caplog=caplog)
    assert parsed["A"].ae_type != AEType.EXCLUDED and parsed["A"].switch_notes == ()
    assert len(_messages(caplog, "isCombinableWithRemedialAction=false", "NOT applied", "OPEN-33", "effect of every remedial action", "NOT removed")) == 1


# --- parser: the time-dependent enabled flag ----------------------------------------------------------------

def test_rao_a_time_point_at_the_run_hour_switches_the_element_off(tmp_path):
    sis = _schedule("A", [("2022-06-15T17:30:00Z", "false")])
    a = _parse(tmp_path, _ae("A"), sis)["A"]
    assert a.ae_type == AEType.EXCLUDED and a.switch_notes == ("AssessedElementTimePoint.enabled=false at the run time",)


def test_rao_a_time_point_overrides_normal_enabled_in_both_directions(tmp_path):
    off = _parse(tmp_path, _ae("A", normalEnabled="true"), _schedule("A", [("2022-06-15T17:30:00Z", "false")]))["A"]
    on = _parse(tmp_path, _ae("A", normalEnabled="false"), _schedule("A", [("2022-06-15T17:30:00Z", "true")]))["A"]
    assert off.ae_type == AEType.EXCLUDED and on.ae_type != AEType.EXCLUDED
    assert on.switch_notes == ("AssessedElement.normalEnabled=false", "AssessedElementTimePoint.enabled=true at the run time")


@pytest.mark.parametrize("kind, expected_off", [("none", False), ("previous", True), ("linear", True), ("next", False)])
def test_rao_between_time_points_the_interpolation_kind_decides(tmp_path, kind, expected_off):
    sis = _schedule("A", [("2022-06-15T16:30:00Z", "false"), ("2022-06-15T18:30:00Z", "true")], kind=kind)
    assert (_parse(tmp_path, _ae("A"), sis)["A"].ae_type == AEType.EXCLUDED) is expected_off


def test_rao_the_time_point_of_the_run_date_is_used_when_the_run_has_one(tmp_path):
    day = lambda d: __import__("datetime").date(2022, 6, d).toordinal()
    sis = _schedule("A", [("2022-06-15T17:30:00Z", "true"), ("2022-06-16T17:30:00Z", "false"), ("2022-06-17T17:30:00Z", "true")])
    for run_day, expected_off in ((15, False), (16, True), (17, False)):
        with run_time.run_time_scope():
            run_time.set_run_time(run_time.RunTime(day=day(run_day), minute=17 * 60 + 30))
            assert (_parse(tmp_path, _ae("A"), sis)["A"].ae_type == AEType.EXCLUDED) is expected_off


# --- MILP: the constraint is absent / restricted --------------------------------------------------------------

def _element(branch, **fields):
    return AssessedElement(
        mrid=f"AE-{branch}", name=branch, tso="T", ae_type=fields.pop("ae_type", AEType.SECURED), branch_mrid=branch,
        secured_for_region=None, scanned_for_region=None, exclusion_reason=None, patl_ka={"1030Z": 1.0}, **fields,
    )


def _model(elements, contingencies=("CO1", "CO2"), currents=(1200.0, 1200.0)):
    nx_inputs = NxMilpInputs(
        lf_nx={c: {e.branch_mrid: {1: i} for e in elements} for c, i in zip(contingencies, currents)},
        sensitivity_pst_nx={}, sensitivity_rd_nx={}, penalty_cost_overload_nx_patl=500.0,
    )
    return build_n0_milp_model(
        elements, "1030Z", lf_initial={e.branch_mrid: {1: 1200.0} for e in elements},
        penalty_cost_overload_n0=1000.0, nx_inputs=nx_inputs,
    )


def _objective(model):
    assert str(pyo.SolverFactory("appsi_highs").solve(model).solver.termination_condition) == "optimal"
    return pyo.value(model.objective)


def test_rao_without_switches_the_branch_has_an_n0_row_and_a_pair_for_every_contingency():
    model = _model([_element("B1")])
    assert list(model.secured_branch_ids) == ["B1"]
    assert sorted(model.nx_branch_contingency_pairs) == [("B1", "CO1"), ("B1", "CO2")]


def test_rao_not_in_the_base_case_means_no_n0_row_but_the_contingency_pairs_stay():
    model = _model([_element("B1", in_base_case=False), _element("B2")])
    assert list(model.secured_branch_ids) == ["B2"] and "B1" not in list(model.branch_ids)
    assert ("B1", "CO1") in list(model.nx_branch_contingency_pairs)
    assert _objective(model) < _objective(_model([_element("B1"), _element("B2")]))        # the N-0 overload of B1 is not paid


def test_rao_a_disabled_element_has_no_n0_row_and_no_pair():
    model = _model([_element("B1", ae_type=AEType.EXCLUDED), _element("B2")])
    assert list(model.secured_branch_ids) == ["B2"]
    assert sorted(model.nx_branch_contingency_pairs) == [("B2", "CO1"), ("B2", "CO2")]


def test_rao_an_included_link_restricts_the_pairs_to_the_linked_contingency():
    model = _model([_element("B1", included_contingencies=("CO1",)), _element("B2")])
    assert sorted(model.nx_branch_contingency_pairs) == [("B1", "CO1"), ("B2", "CO1"), ("B2", "CO2")]
    assert list(model.secured_branch_ids) == ["B1", "B2"]                                  # the N state is not restricted


def test_rao_an_excluded_link_takes_the_contingency_out():
    model = _model([_element("B1", excluded_contingencies=("CO2",))])
    assert sorted(model.nx_branch_contingency_pairs) == [("B1", "CO1")]
    free = _objective(_model([_element("B1")], currents=(1200.0, 1200.0)))
    assert _objective(model) < free                                                         # the CO2 overload is not paid


def test_rao_not_combinable_with_contingencies_leaves_the_n_state_and_only_the_included_pairs():
    """isCombinableWithContingency=false as the parser gives it: included_contingencies is a tuple, empty without links."""
    none = _model([_element("B1", included_contingencies=()), _element("B2")])
    assert list(none.secured_branch_ids) == ["B1", "B2"]                                   # the N state is not restricted
    assert sorted(none.nx_branch_contingency_pairs) == [("B2", "CO1"), ("B2", "CO2")]
    one = _model([_element("B1", included_contingencies=("CO2",)), _element("B2")])
    assert sorted(one.nx_branch_contingency_pairs) == [("B1", "CO2"), ("B2", "CO1"), ("B2", "CO2")]
    assert _objective(none) < _objective(_model([_element("B1"), _element("B2")]))        # the overloads of B1 are not paid
    both = _model([_element("B1", included_contingencies=(), in_base_case=False)])
    assert list(both.branch_ids) == [] and sorted(both.nx_branch_contingency_pairs) == []   # assessed nowhere


def test_rao_a_branch_with_two_elements_is_monitored_when_one_of_them_is():
    model = _model([_element("B1", included_contingencies=("CO1",)), _element("B1", included_contingencies=("CO2",))])
    assert sorted(model.nx_branch_contingency_pairs) == [("B1", "CO1"), ("B1", "CO2")]
    model = _model([_element("B1", in_base_case=False), _element("B1")])
    assert list(model.secured_branch_ids) == ["B1"]


# --- pipeline: variants of the mock --------------------------------------------------------------------------

BELGOVIA_AE = "4b19ce42-6c5a-4070-884e-4c2889735c3f"
BELGOVIA_BRANCH = "b58bf21a-096a-4dae-9a01-3f03b60c24c7"
BELGOVIA_CONTINGENCIES = ("37997e71-cb7d-4a8c-baa6-2a1594956da9", "65582e87-5035-4465-8dd9-cb655224b29f")


def _run(tmp_path, name, **variant):
    from helpers import run_pipeline_on_fixture_inputs, _MOCK_NX_NCP_ZIP
    zip_path = ae_switch_variants.build_ae_switch_variant(_MOCK_NX_NCP_ZIP, tmp_path / f"{name}.zip", "Belgovia", BELGOVIA_AE, **variant) if variant else _MOCK_NX_NCP_ZIP
    return run_pipeline_on_fixture_inputs(tmp_path / name, zip_path, enable_nx_analysis=True)


def _branches_in(run, file_name):
    return (run.output_dir / file_name).read_text(encoding="utf-8").count(BELGOVIA_BRANCH)


def test_rao_pipeline_a_disabled_mock_element_is_not_monitored(tmp_path):
    plain = _run(tmp_path, "plain")
    off = _run(tmp_path, "off", properties={"normalEnabled": "false"})
    assert _branches_in(plain, "tatl_data.csv") >= 1 and _branches_in(off, "tatl_data.csv") == 0
    assert _branches_in(plain, "results_nx_loadings.csv") > 0 and _branches_in(off, "results_nx_loadings.csv") == 0   # not reported either
    log = (off.output_dir / "run_log.txt").read_text(encoding="utf-8", errors="replace")
    assert f"1 assessed element(s) switched off or restricted by NCP switches: {BELGOVIA_AE}" in log


def test_rao_pipeline_a_time_point_at_the_run_hour_does_the_same(tmp_path):
    off = _run(tmp_path, "scheduled", schedule=("2022-06-15T10:30:00Z", False))
    assert _branches_in(off, "tatl_data.csv") == 0
    assert "AssessedElementTimePoint.enabled=false at the run time" in (off.output_dir / "run_log.txt").read_text(encoding="utf-8", errors="replace")


def _pairs_in_nx_loadings(run, contingency=None):
    """Rows of the Belgovia branch (after the contingency) that still have an N-X constraint: the file lists every pair,
    slack_patl is blank where no constraint was built."""
    import csv
    with (run.output_dir / "results_nx_loadings.csv").open(encoding="utf-8", newline="") as handle:
        return sum(1 for row in csv.DictReader(handle) if row["branch_mrid"] == BELGOVIA_BRANCH
                   and row["slack_patl"] != "" and (contingency is None or row["contingency_mrid"] == contingency))


def test_rao_pipeline_not_combinable_with_contingencies_leaves_only_the_included_pairs(tmp_path):
    plain = _run(tmp_path, "plain")
    first, second = BELGOVIA_CONTINGENCIES
    assert _pairs_in_nx_loadings(plain, first) > 0 and _pairs_in_nx_loadings(plain, second) > 0
    one = _run(tmp_path, "notcomb_one", properties={"isCombinableWithContingency": "false"}, links=[(first, "included")])
    assert _pairs_in_nx_loadings(one, first) == _pairs_in_nx_loadings(plain, first)
    assert _pairs_in_nx_loadings(one, second) == 0
    assert _branches_in(one, "tatl_data.csv") >= 1                                       # still in the N state (inBaseCase absent)
    none = _run(tmp_path, "notcomb_none", properties={"isCombinableWithContingency": "false"})
    assert _pairs_in_nx_loadings(none) == 0 and _branches_in(none, "tatl_data.csv") >= 1
    log = (none.output_dir / "run_log.txt").read_text(encoding="utf-8", errors="replace")
    assert "isCombinableWithContingency=false (monitored only after the 0 contingency(ies) with an included link" in log
    assert "NOT applied" not in "".join(line for line in log.splitlines(True) if "isCombinableWithContingency" in line)


def test_rao_pipeline_a_considered_link_changes_nothing_and_an_excluded_one_beats_a_not_combinable_element(tmp_path):
    first, second = BELGOVIA_CONTINGENCIES
    plain = _run(tmp_path, "plain")
    considered = _run(tmp_path, "considered", links=[(first, "considered")])
    assert _pairs_in_nx_loadings(considered, first) == _pairs_in_nx_loadings(plain, first)
    assert _pairs_in_nx_loadings(considered, second) == _pairs_in_nx_loadings(plain, second)
    log = (considered.output_dir / "run_log.txt").read_text(encoding="utf-8", errors="replace")
    assert "1 AssessedElementWithContingency link(s) with combinationConstraintKind considered" in log
    both = _run(tmp_path, "excl_beats", properties={"isCombinableWithContingency": "false"},
                links=[(first, "included"), (first, "excluded")])
    assert _pairs_in_nx_loadings(both) == 0


def test_rao_pipeline_links_and_in_base_case_are_logged_and_applied(tmp_path):
    """The mock's Belgovia element has a BaseCaseCurrentLimit, for which the standard requires inBaseCase=true: the
    element is scanned in the base case (warning), the links still apply."""
    variant = _run(tmp_path, "links", properties={"inBaseCase": "false"},
                   links=[(BELGOVIA_CONTINGENCIES[0], "included")])
    log = (variant.output_dir / "run_log.txt").read_text(encoding="utf-8", errors="replace")
    assert ("inBaseCase=false with a BaseCaseCurrentLimit (not allowed): scanned in the base case; "
            "monitored only after the 1 linked contingency(ies)") in log
    assert "1 AssessedElement(s) with a BaseCaseCurrentLimit and inBaseCase=false" in log
    assert _branches_in(variant, "tatl_data.csv") >= 1                                  # still monitored in the N state
    assert _pairs_in_nx_loadings(variant, BELGOVIA_CONTINGENCIES[1]) == 0
    assert variant.output_dir.joinpath("results_summary.csv").exists()
