"""
test_rao_hvdc_parser.py — HVDC remedial actions without a network (docs/specs/hvdc_ra_specs.md H2-H4):
ncp_parser.parse_hvdc_units / parse_balanced_ra_groups and pre_milp/hvdc_units.py (structure
checks, operating limits from the RangeConstraints).
"""
import logging
import zipfile
from pathlib import Path

import pytest

from helpers import _RA_FOOTER, _RA_HEADER, FIXTURE_NCP_GENERIC_ZIP
from text_encoding import TEXT_ENCODING

from data_model import HvdcGroup, HvdcRange, HvdcUnit, RAKind
from pre_milp import hvdc_units, ncp_parser


def _write(tmp_path: Path, body: str, name: str = "Test_RA.xml") -> Path:
    path = tmp_path / name
    path.write_text(_RA_HEADER + body + _RA_FOOTER, encoding=TEXT_ENCODING)
    return path


def _ra(mrid, ei, kind="preventive", available="true", penalty=None, time_to_implement=None, action_id=None,
        link_ra=True):
    """A GSARA with one EquivalentInjectionAction on EI `ei`."""
    action_id = action_id or f"ACT_{mrid}"
    penalty_xml = f"<nc:RemedialAction.penaltyFactor>{penalty}</nc:RemedialAction.penaltyFactor>" if penalty is not None else ""
    time_xml = (f"<nc:RemedialAction.timeToImplement>{time_to_implement}</nc:RemedialAction.timeToImplement>"
                if time_to_implement else "")
    link_xml = f'<nc:GridStateAlteration.GridStateAlterationRemedialAction rdf:resource="#_{mrid}"/>' if link_ra else ""
    return f"""
    <nc:GridStateAlterationRemedialAction rdf:ID="_{mrid}">
      <cim:IdentifiedObject.mRID>{mrid}</cim:IdentifiedObject.mRID>
      <cim:IdentifiedObject.name>RA {mrid}</cim:IdentifiedObject.name>
      <nc:RemedialAction.normalAvailable>{available}</nc:RemedialAction.normalAvailable>
      <nc:RemedialAction.kind rdf:resource="https://cim4.eu/ns/nc#RemedialActionKind.{kind}"/>
      {penalty_xml}{time_xml}
    </nc:GridStateAlterationRemedialAction>
    <nc:EquivalentInjectionAction rdf:ID="_{action_id}">
      {link_xml}
      <nc:EquivalentInjectionAction.EquivalentInjection rdf:resource="#_{ei}"/>
      <nc:GridStateAlteration.PropertyReference rdf:resource="https://energy.referencedata.eu/PropertyReference/EquivalentInjection.p"/>
    </nc:EquivalentInjectionAction>"""


def _range(rid, action_id, direction, kind, value, prop="EquivalentInjection.p"):
    return f"""
    <nc:StaticPropertyRange rdf:ID="_{rid}">
      <nc:RangeConstraint.GridStateAlteration rdf:resource="#_{action_id}"/>
      <nc:RangeConstraint.direction rdf:resource="nc:RelativeDirectionKind.{direction}"/>
      <nc:RangeConstraint.valueKind rdf:resource="nc:ValueOffsetKind.{kind}"/>
      <nc:StaticPropertyRange.PropertyReference rdf:resource="https://energy.referencedata.eu/PropertyReference/{prop}"/>
      <nc:RangeConstraint.normalValue>{value}</nc:RangeConstraint.normalValue>
    </nc:StaticPropertyRange>"""


def _dependency(dep_id, group, ra, kind="balanced", predicate="RemedialActionGroup"):
    return f"""
    <nc:RemedialActionDependency rdf:ID="_{dep_id}">
      <nc:RemedialActionDependency.kind rdf:resource="https://cim4.eu/ns/nc#RemedialActionDependencyKind.{kind}"/>
      <nc:RemedialActionDependency.{predicate} rdf:resource="#_{group}"/>
      <nc:RemedialActionDependency.RemedialAction rdf:resource="#_{ra}"/>
    </nc:RemedialActionDependency>"""


def _group(group, name="Link"):
    return f"""
    <nc:RemedialActionGroup rdf:ID="_{group}">
      <cim:IdentifiedObject.mRID>{group}</cim:IdentifiedObject.mRID>
      <cim:IdentifiedObject.name>{name}</cim:IdentifiedObject.name>
    </nc:RemedialActionGroup>"""


# ---------------------------------------------------------------------------
# parse_hvdc_units
# ---------------------------------------------------------------------------

class TestParseHvdcUnits:
    def test_unit_fields_come_from_the_ra_and_its_action(self, tmp_path):
        body = _ra("RA1", "EI1", kind="curative", penalty=2.5, time_to_implement="PT15M") + """
        <nc:ContingencyWithRemedialAction rdf:ID="_L1">
          <nc:ContingencyWithRemedialAction.RemedialAction rdf:resource="#_RA1"/>
          <nc:ContingencyWithRemedialAction.Contingency rdf:resource="#_CO1"/>
        </nc:ContingencyWithRemedialAction>"""
        units = ncp_parser.parse_hvdc_units(_write(tmp_path, body), "TSO-X")
        assert len(units) == 1
        unit = units[0]
        assert (unit.mrid, unit.ei_mrid, unit.tso, unit.available) == ("RA1", "EI1", "TSO-X", True)
        assert unit.kind == RAKind.CURATIVE
        assert unit.penalty_factor == 2.5
        assert unit.reaction_time_minutes == 15.0
        assert unit.linked_contingency_mrids == ["CO1"]
        assert unit.ranges == [] and unit.group_mrid is None

    def test_missing_penalty_factor_is_one_and_logged(self, tmp_path, caplog):
        """The profile default is 1 (decision 97); before, a missing factor made the unit non-costly."""
        with caplog.at_level(logging.WARNING):
            units = ncp_parser.parse_hvdc_units(_write(tmp_path, _ra("RA1", "EI1")), "TSO-X")
        assert units[0].penalty_factor == 1.0
        assert any("penaltyFactor" in r.message and "RA1" in r.message and "1.0" in r.message for r in caplog.records)

    def test_unavailable_ra_is_parsed_with_available_false(self, tmp_path):
        units = ncp_parser.parse_hvdc_units(_write(tmp_path, _ra("RA1", "EI1", available="false")), "TSO-X")
        assert units[0].available is False

    def test_ei_action_without_ra_link_is_a_scheme_action_and_ignored(self, tmp_path):
        assert ncp_parser.parse_hvdc_units(_write(tmp_path, _ra("RA1", "EI1", link_ra=False)), "TSO-X") == []

    def test_two_ei_actions_in_one_ra_are_an_error(self, tmp_path):
        body = _ra("RA1", "EI1") + """
        <nc:EquivalentInjectionAction rdf:ID="_ACT2">
          <nc:GridStateAlteration.GridStateAlterationRemedialAction rdf:resource="#_RA1"/>
          <nc:EquivalentInjectionAction.EquivalentInjection rdf:resource="#_EI2"/>
        </nc:EquivalentInjectionAction>"""
        with pytest.raises(ValueError, match="RA1.*2 EquivalentInjectionActions"):
            ncp_parser.parse_hvdc_units(_write(tmp_path, body), "TSO-X")

    def test_units_are_sorted_by_mrid(self, tmp_path):
        body = _ra("RB", "EI2") + _ra("RA", "EI1")
        assert [u.mrid for u in ncp_parser.parse_hvdc_units(_write(tmp_path, body), "TSO-X")] == ["RA", "RB"]

    def test_ranges_keep_direction_and_value_kind(self, tmp_path):
        body = (_ra("RA1", "EI1")
                + _range("R1", "ACT_RA1", "up", "absolute", 500)
                + _range("R2", "ACT_RA1", "down", "incremental", 40)
                + _range("R3", "ACT_RA1", "upAndDown", "absolute", 450))
        ranges = ncp_parser.parse_hvdc_units(_write(tmp_path, body), "TSO-X")[0].ranges
        assert sorted((r.direction, r.value_kind, r.value) for r in ranges) == [
            ("down", "incremental", 40.0), ("up", "absolute", 500.0), ("upAndDown", "absolute", 450.0),
        ]

    def test_up_and_down_is_not_read_as_up(self, tmp_path):
        """The PST range reader tests 'up' in the direction text; the HVDC reader compares the token."""
        body = _ra("RA1", "EI1") + _range("R1", "ACT_RA1", "upAndDown", "incremental", 30)
        assert ncp_parser.parse_hvdc_units(_write(tmp_path, body), "TSO-X")[0].ranges[0].direction == "upAndDown"

    def test_fixed_setpoint_range_and_foreign_property_ranges_are_ignored(self, tmp_path, caplog):
        body = (_ra("RA1", "EI1")
                + _range("R1", "ACT_RA1", "none", "absolute", 10)
                + _range("R2", "ACT_RA1", "up", "absolute", 99, prop="RotatingMachine.p")
                + _range("R3", "ACT_RA1", "up", "absolute", 77))
        with caplog.at_level(logging.WARNING):
            ranges = ncp_parser.parse_hvdc_units(_write(tmp_path, body), "TSO-X")[0].ranges
        assert [(r.direction, r.value) for r in ranges] == [("up", 77.0)]
        assert any("direction none" in r.message for r in caplog.records)

    def test_range_of_another_action_is_not_attached(self, tmp_path):
        body = _ra("RA1", "EI1") + _ra("RA2", "EI2") + _range("R1", "ACT_RA2", "up", "absolute", 5)
        units = {u.mrid: u for u in ncp_parser.parse_hvdc_units(_write(tmp_path, body), "TSO-X")}
        assert units["RA1"].ranges == [] and len(units["RA2"].ranges) == 1

    def test_pst_and_rd_ras_are_not_hvdc_units(self, tmp_path):
        body = """
        <nc:GridStateAlterationRemedialAction rdf:ID="_PST1"><cim:IdentifiedObject.mRID>PST1</cim:IdentifiedObject.mRID>
        </nc:GridStateAlterationRemedialAction>
        <nc:TapPositionAction rdf:ID="_TPA1">
          <nc:GridStateAlteration.GridStateAlterationRemedialAction rdf:resource="#_PST1"/>
          <nc:TapPositionAction.TapChanger rdf:resource="#_TC1"/>
        </nc:TapPositionAction>"""
        assert ncp_parser.parse_hvdc_units(_write(tmp_path, body), "TSO-X") == []

    def test_generic_fixture_has_no_hvdc_ras_and_gives_no_range_warning(self, tmp_path, caplog):
        """The EquivalentInjectionActions of NCP_sample_generic_2_4 belong to remedial action schemes (no RA link): no unit, and no
        warning about their ranges (direction none), which are not HVDC ranges."""
        with zipfile.ZipFile(FIXTURE_NCP_GENERIC_ZIP) as zf:
            for name in zf.namelist():
                if name.endswith("_RA.xml"):
                    path = tmp_path / name.rsplit("/", 1)[-1]
                    path.write_bytes(zf.read(name))
                    with caplog.at_level(logging.WARNING):
                        assert ncp_parser.parse_hvdc_units(path, "TSO-X") == []
                    assert ncp_parser.parse_balanced_ra_groups(path, "TSO-X") == []
        assert not [r.message for r in caplog.records if r.levelno >= logging.WARNING]

    def test_a_range_of_a_scheme_action_is_not_warned_about(self, tmp_path, caplog):
        body = (_ra("RA1", "EI1", link_ra=False) + _range("R1", "ACT_RA1", "none", "absolute", 10)
                + _range("R2", "ACT_RA1", "sideways", "absolute", 10))
        with caplog.at_level(logging.WARNING):
            assert ncp_parser.parse_hvdc_units(_write(tmp_path, body), "TSO-X") == []
        assert not [r for r in caplog.records if "StaticPropertyRange" in r.message]


# ---------------------------------------------------------------------------
# parse_balanced_ra_groups and the predicate fix of parse_ra_groups
# ---------------------------------------------------------------------------

class TestBalancedGroups:
    @pytest.mark.parametrize("predicate", ["RemedialActionGroup", "DependingRemedialActionGroup"])
    def test_balanced_group_with_either_predicate(self, tmp_path, predicate):
        body = _group("G1", "Link 1") + _dependency("D1", "G1", "RA1", predicate=predicate) + _dependency(
            "D2", "G1", "RA2", predicate=predicate)
        groups = ncp_parser.parse_balanced_ra_groups(_write(tmp_path, body), "TSO-X")
        assert groups == [HvdcGroup(mrid="G1", name="Link 1", tso="TSO-X", ra_mrids=["RA1", "RA2"])]

    def test_other_kinds_are_not_balanced_groups(self, tmp_path):
        body = (_group("G1") + _dependency("D1", "G1", "RA1", kind="restrictive")
                + _dependency("D2", "G1", "RA2", kind="exclusive"))
        assert ncp_parser.parse_balanced_ra_groups(_write(tmp_path, body), "TSO-X") == []

    def test_dependency_without_group_is_skipped_with_a_warning(self, tmp_path, caplog):
        body = """
        <nc:RemedialActionDependency rdf:ID="_D1">
          <nc:RemedialActionDependency.kind rdf:resource="https://cim4.eu/ns/nc#RemedialActionDependencyKind.balanced"/>
          <nc:RemedialActionDependency.RemedialAction rdf:resource="#_RA1"/>
        </nc:RemedialActionDependency>"""
        with caplog.at_level(logging.WARNING):
            assert ncp_parser.parse_balanced_ra_groups(_write(tmp_path, body), "TSO-X") == []
        assert any("balanced" in r.message for r in caplog.records)

    def test_restrictive_group_found_with_the_depending_predicate(self, tmp_path):
        """The predicate fix: the unmodified NCP_sample_generic_2_4 fixture names it DependingRemedialActionGroup."""
        body = (_group("G1") + _dependency("D1", "G1", "RA1", kind="restrictive", predicate="DependingRemedialActionGroup")
                + _dependency("D2", "G1", "RA2", kind="restrictive", predicate="DependingRemedialActionGroup"))
        result = ncp_parser.parse_ra_groups(_write(tmp_path, body), None, "TSO-X", "1030Z")
        assert result["G1"]["ra_mrids"] == ["RA1", "RA2"]

    def test_restrictive_group_still_found_with_the_old_predicate(self, tmp_path):
        body = _group("G1") + _dependency("D1", "G1", "RA1", kind="restrictive")
        assert ncp_parser.parse_ra_groups(_write(tmp_path, body), None, "TSO-X", "1030Z")["G1"]["ra_mrids"] == ["RA1"]

    def test_balanced_group_is_still_not_a_restrictive_group(self, tmp_path):
        body = _group("G1") + _dependency("D1", "G1", "RA1", predicate="DependingRemedialActionGroup")
        assert ncp_parser.parse_ra_groups(_write(tmp_path, body), None, "TSO-X", "1030Z") == {}


# ---------------------------------------------------------------------------
# validate_hvdc_structure
# ---------------------------------------------------------------------------

def _unit(mrid, ei=None, kind=RAKind.PREVENTIVE, available=True, tso="TSO-X", ranges=None):
    return HvdcUnit(mrid=mrid, name=f"unit {mrid}", tso=tso, ei_mrid=ei or f"EI-{mrid}", available=available,
                    kind=kind, penalty_factor=0.0, ranges=ranges or [])


def _grp(mrid, *ras, tso="TSO-X"):
    return HvdcGroup(mrid=mrid, name=f"group {mrid}", tso=tso, ra_mrids=list(ras))


class TestValidateStructure:
    def test_a_valid_pair_gets_its_group_mrid(self):
        units, groups = hvdc_units.validate_hvdc_structure([_unit("A"), _unit("B")], [_grp("G", "A", "B")])
        assert [(u.mrid, u.group_mrid) for u in units] == [("A", "G"), ("B", "G")]
        assert [g.mrid for g in groups] == ["G"]

    def test_group_with_a_foreign_ra_is_an_error(self):
        with pytest.raises(ValueError, match="G.*not HVDC units"):
            hvdc_units.validate_hvdc_structure([_unit("A"), _unit("B")], [_grp("G", "A", "B", "PST9")])

    def test_group_with_one_or_three_units_is_an_error(self):
        with pytest.raises(ValueError, match="exactly two"):
            hvdc_units.validate_hvdc_structure([_unit("A")], [_grp("G", "A")])
        with pytest.raises(ValueError, match="exactly two"):
            hvdc_units.validate_hvdc_structure([_unit("A"), _unit("B"), _unit("C")], [_grp("G", "A", "B", "C")])

    def test_unit_without_a_group_is_an_error(self):
        with pytest.raises(ValueError, match="C.*no balanced RA group"):
            hvdc_units.validate_hvdc_structure([_unit("A"), _unit("B"), _unit("C")], [_grp("G", "A", "B")])

    def test_mixed_kinds_in_a_group_are_an_error(self):
        with pytest.raises(ValueError, match="mixes preventive and curative"):
            hvdc_units.validate_hvdc_structure([_unit("A"), _unit("B", kind=RAKind.CURATIVE)], [_grp("G", "A", "B")])

    def test_same_ei_twice_in_a_group_is_an_error(self):
        with pytest.raises(ValueError, match="same EquivalentInjection"):
            hvdc_units.validate_hvdc_structure([_unit("A", ei="E"), _unit("B", ei="E")], [_grp("G", "A", "B")])

    def test_two_preventive_units_on_one_ei_are_an_error(self):
        with pytest.raises(ValueError, match="EI-X.*2 preventive HVDC remedial actions"):
            hvdc_units.validate_hvdc_structure(
                [_unit("A", ei="EI-X"), _unit("B"), _unit("C", ei="EI-X"), _unit("D")], [_grp("G1", "A", "B"), _grp("G2", "C", "D")])

    def test_a_preventive_and_a_curative_unit_on_one_ei_are_allowed(self):
        units, _ = hvdc_units.validate_hvdc_structure(
            [_unit("A", ei="EI-X"), _unit("B"), _unit("C", ei="EI-X", kind=RAKind.CURATIVE), _unit("D", kind=RAKind.CURATIVE)],
            [_grp("G1", "A", "B"), _grp("G2", "C", "D")])
        assert len(units) == 4

    def test_unit_in_two_groups_is_an_error(self):
        with pytest.raises(ValueError, match="two balanced groups"):
            hvdc_units.validate_hvdc_structure(
                [_unit("A"), _unit("B"), _unit("C")], [_grp("G1", "A", "B"), _grp("G2", "A", "C")])

    def test_a_unit_in_a_dropped_group_and_in_another_group_is_an_error(self):
        """The two-groups check runs over all groups before a group is dropped for an unavailable unit: A is in G1 (its
        partner B is unavailable, so G1 is dropped) and in G2."""
        with pytest.raises(ValueError, match="A is in two balanced groups"):
            hvdc_units.validate_hvdc_structure(
                [_unit("A"), _unit("B", available=False), _unit("C")], [_grp("G1", "A", "B"), _grp("G2", "A", "C")])

    def test_a_balanced_group_without_any_hvdc_unit_is_skipped(self, caplog):
        """A balanced group of two RD remedial actions is not an HVDC group: logged and skipped, no error."""
        with caplog.at_level(logging.INFO):
            units, groups = hvdc_units.validate_hvdc_structure([], [_grp("G-RD", "RD-1", "RD-2")])
        assert units == [] and groups == []
        assert any("G-RD" in r.message and "no HVDC unit" in r.message for r in caplog.records)
        units, groups = hvdc_units.validate_hvdc_structure(
            [_unit("A"), _unit("B")], [_grp("G", "A", "B"), _grp("G-RD", "RD-1", "RD-2")])
        assert [g.mrid for g in groups] == ["G"] and {u.group_mrid for u in units} == {"G"}

    def test_ra_defined_twice_is_an_error(self):
        with pytest.raises(ValueError, match="defined twice"):
            hvdc_units.validate_hvdc_structure([_unit("A"), _unit("A", tso="TSO-Y")], [])

    def test_group_with_an_unavailable_unit_is_dropped_with_both_units(self, caplog):
        with caplog.at_level(logging.INFO):
            units, groups = hvdc_units.validate_hvdc_structure(
                [_unit("A"), _unit("B", available=False)], [_grp("G", "A", "B")])
        assert units == [] and groups == []
        assert any("atomic" in r.message for r in caplog.records)

    def test_unavailable_unit_without_a_group_is_dropped_not_an_error(self):
        units, groups = hvdc_units.validate_hvdc_structure([_unit("A", available=False)], [])
        assert units == [] and groups == []

    def test_groups_of_the_same_mrid_in_two_tso_files_are_merged(self):
        units, groups = hvdc_units.validate_hvdc_structure(
            [_unit("A", tso="TSO-X"), _unit("B", tso="TSO-Y")], [_grp("G", "A", tso="TSO-X"), _grp("G", "B", tso="TSO-Y")])
        assert [g.ra_mrids for g in groups] == [["A", "B"]] and {u.group_mrid for u in units} == {"G"}

    def test_input_units_are_not_mutated(self):
        original = [_unit("A"), _unit("B")]
        hvdc_units.validate_hvdc_structure(original, [_grp("G", "A", "B")])
        assert all(u.group_mrid is None for u in original)


class TestUnitInRdGlsk:
    def test_ei_in_an_rd_glsk_is_an_error(self):
        with pytest.raises(ValueError, match="EI-A.*RD remedial action"):
            hvdc_units.validate_units_not_in_rd_glsk([_unit("A")], {"RD1": {"EI-A": 0.5, "G2": 0.5}})

    def test_disjoint_units_pass(self):
        hvdc_units.validate_units_not_in_rd_glsk([_unit("A")], {"RD1": {"G1": 1.0}})


# ---------------------------------------------------------------------------
# resolve_operating_limits
# ---------------------------------------------------------------------------

def _limits(ranges, p0=100.0, tech_min=None, tech_max=None):
    return hvdc_units.resolve_operating_limits(_unit("A", ranges=ranges), p0, tech_min, tech_max)


def _r(direction, kind, value):
    return HvdcRange(direction, kind, value)


class TestOperatingLimits:
    def test_absolute_up_and_down_are_literal(self):
        assert _limits([_r("up", "absolute", 300), _r("down", "absolute", -50)]) == (-50.0, 300.0)

    def test_incremental_up_adds_and_down_subtracts_a_magnitude(self):
        assert _limits([_r("up", "incremental", 30), _r("down", "incremental", 20)], p0=100.0) == (80.0, 130.0)

    def test_up_and_down_absolute_is_symmetric_around_zero(self):
        assert _limits([_r("upAndDown", "absolute", 450)]) == (-450.0, 450.0)

    def test_up_and_down_incremental_is_symmetric_around_p0(self):
        assert _limits([_r("upAndDown", "incremental", 25)], p0=100.0) == (75.0, 125.0)

    def test_the_most_restrictive_range_wins_per_side(self):
        ranges = [_r("up", "absolute", 300), _r("up", "incremental", 30), _r("up", "absolute", 200),
                  _r("down", "absolute", -50), _r("down", "incremental", 20)]
        assert _limits(ranges, p0=100.0) == (80.0, 130.0)

    def test_technical_limits_cap_the_ranges(self):
        assert _limits([_r("up", "absolute", 300), _r("down", "absolute", -50)], tech_min=0.0, tech_max=250.0) == (0.0, 250.0)

    def test_technical_limits_alone_bound_the_unit(self):
        assert _limits([], tech_min=-100.0, tech_max=100.0) == (-100.0, 100.0)

    def test_pypowsybl_unbounded_limits_count_as_none(self):
        assert _limits([_r("up", "absolute", 300), _r("down", "absolute", -50)], tech_min=-1.797e308, tech_max=1.797e308) == (-50.0, 300.0)

    def test_no_technical_limits_log_a_warning(self, caplog):
        with caplog.at_level(logging.WARNING):
            _limits([_r("upAndDown", "absolute", 10)])
        assert any("no technical limits" in r.message for r in caplog.records)

    def test_unit_without_any_bound_on_a_side_is_an_error(self):
        with pytest.raises(ValueError, match="lower bound"):
            _limits([_r("up", "absolute", 300)])
        with pytest.raises(ValueError, match="upper bound"):
            _limits([_r("down", "absolute", 0)])
        with pytest.raises(ValueError, match="A.*upper bound"):
            _limits([])

    def test_negative_incremental_value_is_an_error(self):
        with pytest.raises(ValueError, match="negative value"):
            _limits([_r("up", "incremental", -5), _r("down", "incremental", 5)])

    def test_empty_interval_is_an_error(self):
        with pytest.raises(ValueError, match="above upper limit"):
            _limits([_r("up", "absolute", 10), _r("down", "absolute", 20)])

    def test_p0_is_the_original_setpoint_argument(self):
        assert _limits([_r("upAndDown", "incremental", 10)], p0=0.0) == (-10.0, 10.0)

    def test_the_most_restrictive_absolute_down_range_is_the_highest_value(self):
        assert _limits([_r("up", "absolute", 300), _r("down", "absolute", -50), _r("down", "absolute", 20)]) == (20.0, 300.0)


class TestSetPointOutsideItsRange:
    """H3.4: a CGM set point outside the resolved range widens the range to include it, with a warning."""

    def test_p0_above_the_upper_limit_raises_the_upper_limit_to_p0(self, caplog):
        with caplog.at_level(logging.WARNING):
            assert _limits([_r("up", "absolute", 90), _r("down", "absolute", -50)], p0=100.0) == (-50.0, 100.0)
        message = next(r.message for r in caplog.records if "H3.4" in r.message)
        assert "A" in message and "EI-A" in message and "[-50.000, 90.000]" in message and "[-50.000, 100.000]" in message

    def test_p0_below_the_lower_limit_lowers_the_lower_limit_to_p0(self, caplog):
        with caplog.at_level(logging.WARNING):
            assert _limits([_r("upAndDown", "absolute", 30)], p0=-40.0) == (-40.0, 30.0)
        assert any("H3.4" in r.message and "[-30.000, 30.000]" in r.message for r in caplog.records)

    def test_a_technical_limit_below_p0_is_widened_too(self):
        assert _limits([_r("upAndDown", "absolute", 500)], p0=100.0, tech_min=0.0, tech_max=80.0) == (0.0, 100.0)

    def test_p0_inside_the_range_changes_nothing_and_logs_nothing(self, caplog):
        with caplog.at_level(logging.WARNING):
            assert _limits([_r("up", "absolute", 300), _r("down", "absolute", -50)], tech_min=-60.0, tech_max=400.0) == (-50.0, 300.0)
        assert not [r for r in caplog.records if "H3.4" in r.message]

    def test_an_empty_range_is_still_an_error_and_not_widened(self):
        with pytest.raises(ValueError, match="above upper limit"):
            _limits([_r("up", "absolute", 10), _r("down", "absolute", 20)], p0=15.0)
