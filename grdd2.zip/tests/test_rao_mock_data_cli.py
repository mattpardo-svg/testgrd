"""The command line of mock_data (python -m mock_data): the standard-form mock equals the shipped one, check passes,
install-input writes into a temporary input folder and refuses to overwrite another cgm*/ncp* zip."""
import shutil

import pytest

from mock_data import cli, paths


def test_rao_mock_data_standard_command_writes_the_shipped_standard_mock(tmp_path):
    out = tmp_path / "standard.zip"
    assert cli.main(["standard", "--out", str(out)]) == 0
    assert out.read_bytes() == paths.STANDARD_ZIP.read_bytes()


def test_rao_mock_data_check_command_passes_on_the_shipped_fixtures(capsys):
    assert cli.main(["check"]) == 0
    printed = capsys.readouterr().out
    assert "standard = converter(legacy): yes" in printed
    assert paths.CGM_ZIP.name in printed and paths.LEGACY_ZIP.name in printed


def test_rao_mock_data_install_input_writes_one_cgm_and_one_ncp_zip_and_refuses_another(tmp_path):
    folder = tmp_path / "input"
    assert cli.main(["install-input", "--input-dir", str(folder)]) == 0
    assert sorted(p.name for p in folder.glob("*.zip")) == sorted([paths.CGM_ZIP.name, paths.STANDARD_ZIP.name])
    assert (folder / paths.STANDARD_ZIP.name).read_bytes() == paths.STANDARD_ZIP.read_bytes()
    # a second run changes nothing
    assert cli.main(["install-input", "--input-dir", str(folder)]) == 0

    other = tmp_path / "other"
    other.mkdir()
    shutil.copyfile(paths.LEGACY_ZIP, other / "NCP_something_else.zip")
    assert cli.main(["install-input", "--input-dir", str(other)]) == 1
    assert sorted(p.name for p in other.glob("*.zip")) == ["NCP_something_else.zip"]      # nothing was written
    with pytest.raises(ValueError):
        cli.install_input(other)
