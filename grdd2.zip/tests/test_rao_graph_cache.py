"""tests/test_rao_graph_cache.py - one run reads each NCP and each CGM EQ file once (ncp_parser.graph_cache), the
cache lives only inside the block, and a changed file is read again."""

import collections
import os
from pathlib import Path

import pytest
from rdflib import Graph

from pre_milp import ncp_parser
from text_encoding import TEXT_ENCODING
from helpers import _MOCK_NX_NCP_ZIP, run_pipeline_on_fixture_inputs

HEADER = ('<?xml version="1.0"?><rdf:RDF xmlns:rdf="http://www.w3.org/1999/02/22-rdf-syntax-ns#" '
          'xmlns:nc="https://cim4.eu/ns/nc#">')


def _file(tmp_path, body="", name="X_RA.xml"):
    path = tmp_path / name
    path.write_text(HEADER + body + "</rdf:RDF>", encoding=TEXT_ENCODING)
    return path


def test_rao_inside_the_block_a_file_is_parsed_once_and_outside_every_time(tmp_path):
    path = _file(tmp_path)
    assert ncp_parser._load_graph(path) is not ncp_parser._load_graph(path)
    with ncp_parser.graph_cache():
        first = ncp_parser._load_graph(path)
        assert ncp_parser._load_graph(path) is first
        assert ncp_parser._load_graph(path, cache=False) is not first
    assert ncp_parser._load_graph(path) is not first                      # the block kept nothing


def test_rao_a_changed_file_is_read_again_inside_the_block(tmp_path):
    path = _file(tmp_path, '<nc:AssessedElement rdf:ID="_A"/>')
    with ncp_parser.graph_cache():
        before = ncp_parser._load_graph(path)
        _file(tmp_path, '<nc:AssessedElement rdf:ID="_A"/><nc:AssessedElement rdf:ID="_B"/>')
        after = ncp_parser._load_graph(path)
    assert after is not before and len(after) > len(before)


def test_rao_nested_blocks_and_a_failing_block_leave_no_cache_behind(tmp_path):
    path = _file(tmp_path)
    with pytest.raises(RuntimeError):
        with ncp_parser.graph_cache():
            outer = ncp_parser._load_graph(path)
            with ncp_parser.graph_cache():
                assert ncp_parser._load_graph(path) is not outer           # a nested block has its own cache
            assert ncp_parser._load_graph(path) is outer
            raise RuntimeError
    assert ncp_parser.run_cached("probe", path, lambda: object()) is not ncp_parser.run_cached("probe", path, lambda: object())


@pytest.mark.parametrize("ra_types", [("pst", "rd"), ("pst", "rd", "countertrade")])
def test_rao_a_run_parses_each_input_file_once(tmp_path, ra_types):
    parsed = collections.Counter()
    original = Graph.parse
    from pre_milp import eq_stream
    original_stream = eq_stream.stream_eq

    def counting_parse(self, source=None, *args, **kwargs):
        parsed[str(source)] += 1
        return original(self, source, *args, **kwargs)

    def counting_stream(path):
        parsed[str(path)] += 1                       # the EQ files are streamed, not parsed by rdflib
        return original_stream(path)

    def customize(rp, monkeypatch):
        monkeypatch.setattr(Graph, "parse", counting_parse)
        monkeypatch.setattr(rp.ncp_parser, "stream_eq", counting_stream)

    run_pipeline_on_fixture_inputs(
        tmp_path, _MOCK_NX_NCP_ZIP, enable_nx_analysis=False, ra_types=ra_types, customize_pipeline=customize,
    )
    ncp_and_eq = {Path(name).name: count for name, count in parsed.items() if name.endswith(".xml")}
    assert ncp_and_eq, "the run parsed no file"
    twice = {name: count for name, count in ncp_and_eq.items() if count > 1}
    assert twice == {}, f"parsed more than once: {twice}"
    assert any(name.endswith("_RA.xml") for name in ncp_and_eq) and any("_EQ_" in name for name in ncp_and_eq)
