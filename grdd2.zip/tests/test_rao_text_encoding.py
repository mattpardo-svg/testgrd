"""tests/test_rao_text_encoding.py - the one text-encoding rule (DECISIONS 59): UTF-8 without BOM,
named explicitly at every call site (src/rao/text_encoding.TEXT_ENCODING).

1. A scan of src/ for text-file calls without an explicit encoding (open, Path.open/read_text/
   write_text, pandas read_csv/to_csv, logging file handlers, text-mode subprocess pipes).
2. The RAO code (src/rao, src/rao_pages) names the encoding only through the shared constant.
3. A pipeline run on names with accents and a non-Latin character: every written file decodes as
   strict UTF-8, has no BOM, and the names are intact.
"""

import ast
import re
import shutil
import zipfile
from pathlib import Path

import pytest

import run_pipeline
from helpers import REPO_ROOT, _MOCK_NX_CGM_ZIP, _MOCK_NX_NCP_ZIP, run_pipeline_on_fixture_inputs
from text_encoding import TEXT_ENCODING  # noqa: E402

SRC = REPO_ROOT / "src"
RAO_DIRS = (SRC / "rao", SRC / "rao_pages")

# calls that read or write a text file, by the called name
_TEXT_FILE_CALLS = {"open", "read_text", "write_text", "read_csv", "to_csv",
                    "FileHandler", "RotatingFileHandler", "TimedRotatingFileHandler"}
_TEXT_PIPE_CALLS = {"Popen", "run", "check_output"}   # only with text=True / universal_newlines=True

# (file relative to src, called name): why the call has no encoding argument. Keep it short.
ALLOWED_WITHOUT_ENCODING = {
    ("app.py", "open"): "PIL Image.open of a PNG logo (binary)",
    # platform modules outside the RAO app: PowerFactory exports, their encoding is set by
    # PowerFactory (not verified here); reading them as UTF-8 could break the PF pages
    ("core/pf/security_analysis_subprocess.py", "read_csv"): "PowerFactory export, external encoding",
    ("core/pf/sensitivity_analysis_subprocess.py", "read_csv"): "PowerFactory export, external encoding",
    # platform layer outside the RAO app (src/core is imported by the RAO GUI, not the other way
    # round) and not runnable here (PowerFactory): left unchanged, an open decision (DECISIONS 59)
    ("core/logger.py", "RotatingFileHandler"): "platform log file, outside the RAO app",
    ("core/pf/cgm_request.py", "run"): "PowerFactory request pipe, not runnable here",
    ("core/pf/loadflow_request.py", "run"): "PowerFactory request pipe, not runnable here",
    ("core/pf/model_exists_request.py", "run"): "PowerFactory request pipe, not runnable here",
    ("core/pf/models_in_db_request.py", "run"): "PowerFactory request pipe, not runnable here",
    ("core/pf/security_analysis_request.py", "run"): "PowerFactory request pipe, not runnable here",
    ("core/pf/sensitivity_analysis_request.py", "run"): "PowerFactory request pipe, not runnable here",
}


def _called_name(call: ast.Call):
    func = call.func
    if isinstance(func, ast.Name):
        return func.id
    if isinstance(func, ast.Attribute):
        return func.attr
    return None


def _is_binary_mode(call: ast.Call) -> bool:
    mode = call.args[1] if _called_name(call) == "open" and isinstance(call.func, ast.Name) and len(call.args) > 1 else None
    for keyword in call.keywords:
        if keyword.arg == "mode":
            mode = keyword.value
    return isinstance(mode, ast.Constant) and isinstance(mode.value, str) and "b" in mode.value


def _is_text_pipe(call: ast.Call) -> bool:
    return any(
        keyword.arg in ("text", "universal_newlines") and isinstance(keyword.value, ast.Constant) and keyword.value.value
        for keyword in call.keywords
    )


def _python_files(*roots):
    for root in roots:
        for path in sorted(root.rglob("*.py")):
            if "__pycache__" not in path.parts:
                yield path


def test_every_text_file_call_in_src_names_its_encoding():
    missing = []
    for path in _python_files(SRC):
        tree = ast.parse(path.read_text(encoding=TEXT_ENCODING))
        relative = path.relative_to(SRC).as_posix()
        for node in ast.walk(tree):
            if not isinstance(node, ast.Call):
                continue
            name = _called_name(node)
            if name in _TEXT_FILE_CALLS:
                if _is_binary_mode(node):
                    continue
            elif name in _TEXT_PIPE_CALLS:
                if not _is_text_pipe(node):
                    continue
            else:
                continue
            if any(keyword.arg == "encoding" for keyword in node.keywords):
                continue
            if (relative, name) in ALLOWED_WITHOUT_ENCODING:
                continue
            missing.append(f"src/{relative}:{node.lineno} {name}()")
    assert missing == [], "text-file calls without an explicit encoding:\n" + "\n".join(missing)


def test_the_rao_code_names_the_encoding_only_through_the_shared_constant():
    literals = []
    for path in _python_files(*RAO_DIRS):
        if path.name == "text_encoding.py":
            continue
        for node in ast.walk(ast.parse(path.read_text(encoding=TEXT_ENCODING))):
            if isinstance(node, ast.keyword) and node.arg == "encoding" and isinstance(node.value, ast.Constant):
                literals.append(f"{path.relative_to(SRC).as_posix()}:{node.value.lineno} encoding={node.value.value!r}")
    assert literals == [], "use TEXT_ENCODING instead of a literal:\n" + "\n".join(literals)


def test_the_shared_encoding_is_utf8_without_bom():
    assert TEXT_ENCODING == "utf-8"
    assert "x".encode(TEXT_ENCODING) == b"x"  # no BOM, unlike utf-8-sig


def test_the_config_files_and_the_rao_sources_are_utf8_without_bom():
    for path in [*_python_files(*RAO_DIRS), *(SRC / "rao" / "config").glob("*.yaml")]:
        data = path.read_bytes()
        assert not data.startswith(b"\xef\xbb\xbf"), path
        data.decode(TEXT_ENCODING)  # strict


def test_a_config_file_that_is_not_utf8_stops_with_a_message_naming_the_file(tmp_path):
    path = tmp_path / "rao_config.yaml"
    path.write_bytes("# Kommentar mit Umlaut: ä\nworkflow_toggles: {}\n".encode("cp1252"))

    with pytest.raises(ValueError, match=r"rao_config\.yaml is not valid UTF-8 .*Save the file as UTF-8"):
        run_pipeline._load_yaml_config(path)


# ---------------------------------------------------------------------------
# Round trip: names with accents and a non-Latin character through a pipeline run
# ---------------------------------------------------------------------------

NAME_SUFFIX = " é ü ø å Ж 線"   # é ü ø å, Cyrillic Zhe, CJK "line"
_LINE_BLOCK = re.compile(r"(<cim:ACLineSegment rdf:(?:ID|about)=\"[^\"]+\">)(.*?)(</cim:ACLineSegment>)", re.S)
_NAME = re.compile(r"(<cim:IdentifiedObject\.name>)(.*?)(</cim:IdentifiedObject\.name>)", re.S)


def _cgm_with_renamed_lines(target: Path) -> list[str]:
    """A copy of the fixture CGM whose AC line names end with NAME_SUFFIX; returns the new names."""
    renamed: list[str] = []

    def rename_line(block):
        def add_suffix(name):
            renamed.append(name.group(2) + NAME_SUFFIX)
            return name.group(1) + name.group(2) + NAME_SUFFIX + name.group(3)
        return block.group(1) + _NAME.sub(add_suffix, block.group(2), count=1) + block.group(3)

    with zipfile.ZipFile(_MOCK_NX_CGM_ZIP) as source, zipfile.ZipFile(target, "w", zipfile.ZIP_DEFLATED) as copy:
        for info in source.infolist():
            data = source.read(info.filename)
            if "_EQ_" in info.filename and info.filename.endswith(".xml"):
                data = _LINE_BLOCK.sub(rename_line, data.decode("utf-8")).encode("utf-8")  # the XML declares UTF-8
            copy.writestr(info, data)
    return renamed


@pytest.fixture(scope="module")
def accented_run(tmp_path_factory):
    work = tmp_path_factory.mktemp("accented")
    cgm = work / "cgm_accented.zip"
    renamed = _cgm_with_renamed_lines(cgm)

    def use_renamed_cgm(rp, monkeypatch):
        real_load = rp.cgmes_loader.load_cgm
        monkeypatch.setattr(rp.cgmes_loader, "load_cgm", lambda cgm_zip_override: real_load(cgm_zip_override=cgm))

    result = run_pipeline_on_fixture_inputs(work, _MOCK_NX_NCP_ZIP, True, customize_pipeline=use_renamed_cgm)
    return result.output_dir, renamed


def test_every_written_file_is_strict_utf8_without_bom_and_keeps_the_names(accented_run):
    output_dir, renamed = accented_run

    assert len(renamed) > 10
    written = sorted(p for p in output_dir.iterdir() if p.is_file())
    assert {"lf_basecase.csv", "results_summary.csv", "run_log.txt"} <= {p.name for p in written}
    texts = {}
    for path in written:
        data = path.read_bytes()
        assert not data.startswith(b"\xef\xbb\xbf"), f"{path.name} starts with a BOM"
        texts[path.name] = data.decode(TEXT_ENCODING)  # strict: raises on any non-UTF-8 byte

    basecase = texts["lf_basecase.csv"]
    assert all(name in basecase for name in renamed)          # every renamed line, intact
    assert "HÄLLAN_G1_TRAFO" in basecase                  # a name with an accent of the fixture itself
    # the names also reach the per-branch result files of the monitored lines
    names_in_results = [n for n in renamed if n in texts.get("results_nx_loadings.csv", "") + texts.get("lf_post_n0.csv", "")]
    assert names_in_results


def test_the_gui_reads_the_pipeline_console_output_as_utf8(monkeypatch, tmp_path):
    """The GUI pipes the pipeline's console output: both sides use TEXT_ENCODING. The test removes
    the encoding variables of the calling shell, as on a plain Windows setup (cp1252 pipes)."""
    pytest.importorskip("streamlit")
    monkeypatch.delenv("PYTHONIOENCODING", raising=False)
    monkeypatch.delenv("PYTHONUTF8", raising=False)
    import sys
    rao_pages = str(REPO_ROOT / "src" / "rao_pages")
    if rao_pages not in sys.path:
        sys.path.insert(0, rao_pages)
    import _gui_common

    script = tmp_path / "src" / "rao" / "run_pipeline.py"
    script.parent.mkdir(parents=True)
    script.write_text("import logging\nlogging.basicConfig()\nprint('Ligne" + NAME_SUFFIX + "')\n"
                      "logging.getLogger('x').warning('HÄLLAN → ok')\n", encoding=TEXT_ENCODING)

    lines = list(_gui_common.run_pipeline_subprocess(tmp_path))

    assert _gui_common.TEXT_ENCODING == TEXT_ENCODING
    assert "Ligne" + NAME_SUFFIX in lines
    assert any("HÄLLAN → ok" in line for line in lines)
    assert lines[-1] == "__RAO_GUI_PROCESS_EXIT_CODE__:0"
