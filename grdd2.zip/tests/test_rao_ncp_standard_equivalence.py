"""
Equivalence harness for mock_data/convert_ncp_to_standard.py (the converter from the old mock form of the
NCP files to the standard form of the ENTSO-E profiles).

Per section the old zip and the converted zip are parsed with the CURRENT parser and the objects compared.
A section whose standard-form reader does not exist yet is a strict xfail; the work package that adds the
reader removes the marker. Sections the parser reads in standard form already (HVDC, dependency predicate,
bid literals) must pass today.

Fields not compared, with the reason: RDUnit.raise_ramp_rate / lower_ramp_rate (the standard
RotatingMachineAction has no ramp attributes; the MILP does not use them).
"""
import csv
import dataclasses
import re
import sys
import zipfile
from pathlib import Path

import pytest
from rdflib import Graph, RDF, Namespace

from mock_data import ct_mock, standard
from mock_data import hvdc_mock
from helpers import _MOCK_NX_CGM_ZIP, _MOCK_NX_NCP_LEGACY_ZIP, _MOCK_NX_NCP_ZIP, REPO_ROOT

from mock_data import convert_ncp_to_standard as conv  # noqa: E402

NC = Namespace("https://cim4.eu/ns/nc#")
CIM = Namespace("https://cim.ucaiug.io/ns#")
TS = ["1030Z"]
RD_TSOS = ["Belgovia", "Espheim", "Galia", "Svedala"]
SECTION_BY_NAME = {name: name for name in conv.SECTIONS}


def _extract(zip_path, dest):
    dest.mkdir(parents=True, exist_ok=True)
    with zipfile.ZipFile(zip_path) as z:
        z.extractall(dest)
    return dest


def _convert(source_zip, dest_zip, sections=conv.SECTIONS, **option_values):
    options = conv.Options(sections=tuple(sections), **option_values)
    entries = conv.convert_zip(source_zip, dest_zip, _MOCK_NX_CGM_ZIP, options)
    return _extract(dest_zip, dest_zip.with_suffix("")), entries


def _graph(path):
    g = Graph()
    g.parse(str(path), format="xml", publicID="urn:ncp")
    return g


def _frag(uri):
    return str(uri).rsplit("#", 1)[-1].lstrip("_")


@pytest.fixture(scope="module")
def work(tmp_path_factory):
    return tmp_path_factory.mktemp("ncp_standard")


@pytest.fixture(scope="module")
def old_p(work):
    return _extract(_MOCK_NX_NCP_LEGACY_ZIP, work / "old_p")


def _converted_p(work, name, sections, **option_values):
    return _convert(_MOCK_NX_NCP_LEGACY_ZIP, work / f"{name}.zip", sections, **option_values)


@pytest.fixture(scope="module")
def p_all(work):
    return _converted_p(work, "p_all", conv.SECTIONS)


# ---------------------------------------------------------------------------
# snapshots with the current parser
# ---------------------------------------------------------------------------

def _machines(directory):
    ids = set()
    for tso in RD_TSOS:
        ids.update(re.findall(r'RotatingMachine rdf:resource="#_?([^"]+)"', (directory / f"{tso}_RA.xml").read_text(encoding="utf-8")))
    return ids


def _rd_snapshot(directory, machines):
    from pre_milp import ncp_parser

    units, bids = [], []
    gens = {m: {"name": m, "target_p": 10.0, "max_p": 100.0, "min_p": 0.0} for m in machines}
    for tso in RD_TSOS:
        u, b = ncp_parser.parse_rd_units(directory / f"{tso}_RA.xml", directory / f"{tso}_SIS.xml", f"TSO-{tso}", TS, gens,
            generators_by_unit=_generators_by_unit())
        units += [dataclasses.replace(x, raise_ramp_rate=None, lower_ramp_rate=None) for x in u]
        bids += b
    return sorted(units, key=lambda x: (x.mrid, x.gu_mrid)), sorted(bids, key=lambda x: x.mrid)


def _bid_snapshot(directory, ra_mrids_by_tso):
    from pre_milp import ncp_parser

    bids = []
    for tso, ra_mrids in ra_mrids_by_tso.items():
        bids += ncp_parser.parse_power_bids(_graph(directory / f"{tso}_SIS.xml"), set(ra_mrids), f"TSO-{tso}", TS)
    return sorted(bids, key=lambda x: x.mrid)


def _generators_by_unit():
    """{GeneratingUnit mRID: [machine ids]} of the CGM, as the pipeline reads it from the network."""
    machine_to_unit = conv.generating_unit_by_machine(conv._read_zip(_MOCK_NX_CGM_ZIP))[0]
    result = {}
    for machine, unit in machine_to_unit.items():
        result.setdefault(unit, []).append(machine)
    return result


def _glsk_snapshot(directory, rd_units, machines):
    from pre_milp import glsk_resolver

    result = {}
    by_unit = _generators_by_unit()
    for tso in RD_TSOS:
        own = [u for u in rd_units if u.tso == f"TSO-{tso}"]
        result[tso] = glsk_resolver.resolve_glsk(
            directory / f"{tso}_SIS.xml", own, f"TSO-{tso}", set(machines), "1030Z",
            generators_by_unit=by_unit, ra_path=directory / f"{tso}_RA.xml",
        )
    return result


# ---------------------------------------------------------------------------
# a structural check of the standard form (profile rules of RA 2.5 and SIS 2.5)
# ---------------------------------------------------------------------------

POWER_RA = {"RedispatchRemedialAction", "CountertradeRemedialAction"}
PSKS_RESOURCES = ("GeneratingUnit", "PowerElectronicsUnit", "HydroPump", "EnergyConsumer", "EnergySource", "EquivalentInjection",
                  "ExternalNetworkInjection", "DCEquivalentInjection", "DCPole", "EnergyBlockOrder", "EnergyResourceGroupCapacity",
                  "ScheduleResource", "SchedulingArea")


def _local(uri):
    return str(uri).rsplit("#", 1)[-1]


def standard_form_violations(directory, generating_units):
    """Rules of the profiles that the converter promises; an empty list for standard-form data."""
    found = []
    for ra_path in sorted(directory.glob("*_RA.xml")):
        tso = ra_path.name.removesuffix("_RA.xml")
        ra, sis_path = _graph(ra_path), directory / f"{tso}_SIS.xml"
        class_of = {_frag(s): _local(o) for s, _, o in ra.triples((None, RDF.type, None))}
        for subject, cls in class_of.items():
            if cls == "RotatingMachineAction":
                found.append(f"{tso}: RotatingMachineAction {subject}")
        for s, p, o in ra:
            if _local(p) in ("CountertradeRemedialAction.gLSKStrategy", "CountertradeRemedialAction.powerShiftKey",
                             "CountertradeRemedialAction.method", "RemedialActionDependency.RemedialActionGroup"):
                found.append(f"{tso}: {_local(p)}")
            if _local(p).endswith("PowerShiftKeyStrategy") and class_of.get(_frag(s), "").endswith("RemedialAction"):
                found.append(f"{tso}: a strategy reference on the RA {s}")
        for strategy in [s for s in ra.subjects(RDF.type, NC.PowerShiftKeyStrategy)]:
            target = ra.value(strategy, NC["PowerShiftKeyStrategy.PowerRemedialAction"])
            if target is None or class_of.get(_frag(target)) not in POWER_RA:
                found.append(f"{tso}: strategy {strategy} does not point at a power remedial action")
        if not sis_path.exists():
            continue
        sis = _graph(sis_path)
        for pbs in sis.subjects(RDF.type, NC.PowerBidSchedule):
            target = sis.value(pbs, NC["PowerBidSchedule.PowerRemedialAction"])
            if target is not None and class_of.get(_frag(target)) not in POWER_RA:
                found.append(f"{tso}: bid {_frag(pbs)} points at {class_of.get(_frag(target))}")
            direction = sis.value(pbs, NC["PowerBidSchedule.direction"])
            if direction is not None and "MarketRegulationDirectionKind" not in str(direction):
                found.append(f"{tso}: direction literal {direction}")
            if sis.value(pbs, NC["BaseTimeSeries.interpolationKind"]) is None:
                found.append(f"{tso}: bid without interpolationKind")
        for psks in sis.subjects(RDF.type, NC.PowerShiftKeySchedule):
            resources = [(p, o) for p, o in sis.predicate_objects(psks) if _local(p).startswith("PowerShiftKeySchedule.")
                         and _local(p).split(".")[1] in PSKS_RESOURCES]
            if len(resources) != 1:
                found.append(f"{tso}: key {psks} has {len(resources)} resources")
            for p, o in resources:
                if _local(p) == "PowerShiftKeySchedule.GeneratingUnit" and _frag(o) not in generating_units:
                    found.append(f"{tso}: key {psks} names {_frag(o)}, not a GeneratingUnit")
            if sis.value(psks, NC["BaseTimeSeries.interpolationKind"]) is None:
                found.append(f"{tso}: key without interpolationKind")
        for dist in sis.subjects(RDF.type, NC.PowerShiftKeyDistribution):
            ends = [sis.value(dist, NC["PowerShiftKeyDistribution.PowerBidSchedule"]),
                    sis.value(dist, NC["PowerShiftKeyDistribution.PowerShiftKeyStrategy"])]
            if sum(e is not None for e in ends) != 1:
                found.append(f"{tso}: distribution {dist} needs exactly one of bid and strategy")
        for point in sis.subjects(RDF.type, NC.RemedialActionGroupTimePoint):
            if sis.value(point, NC["RemedialActionGroupTimePoint.RemedialActionGroupSchedule"]) is None:
                found.append(f"{tso}: group time point {point} has no schedule")
            if sis.value(point, NC["RemedialActionGroupTimePoint.RemedialActionGroup"]) is not None:
                found.append(f"{tso}: group time point {point} links the group directly")
            for limit in ("maxRegulatingUp", "maxRegulatingDown"):
                if sis.value(point, NC[f"RemedialActionGroup.{limit}"]) is not None:
                    found.append(f"{tso}: {limit} declared by RemedialActionGroup")
        for p in sis.subjects(NC["PowerBidSchedule.gLSKStrategy"], None):
            found.append(f"{tso}: PowerBidSchedule.gLSKStrategy")
    return found


@pytest.fixture(scope="module")
def generating_units():
    return conv.generating_unit_by_machine(conv._read_zip(_MOCK_NX_CGM_ZIP))[1]


# ---------------------------------------------------------------------------
# converter behaviour (must pass today)
# ---------------------------------------------------------------------------

def test_rao_old_p_is_not_standard_form(old_p, generating_units):
    violations = standard_form_violations(old_p, generating_units)
    assert any("RotatingMachineAction" in v for v in violations)
    assert any("direction literal" in v for v in violations)
    assert any("not a GeneratingUnit" in v for v in violations)


def test_rao_converted_p_is_standard_form(p_all, generating_units):
    directory, entries = p_all
    assert standard_form_violations(directory, generating_units) == []
    assert {e["section"] for e in entries} == {"bids", "redispatch", "glsk", "other"}


def test_rao_converter_is_deterministic(work):
    first = conv.convert_zip(_MOCK_NX_NCP_LEGACY_ZIP, work / "det1.zip", _MOCK_NX_CGM_ZIP)
    second = conv.convert_zip(_MOCK_NX_NCP_LEGACY_ZIP, work / "det2.zip", _MOCK_NX_CGM_ZIP)
    assert (work / "det1.zip").read_bytes() == (work / "det2.zip").read_bytes()
    assert first == second


def test_rao_converting_a_converted_zip_changes_nothing(work, p_all):
    again = work / "again.zip"
    entries = conv.convert_zip(work / "p_all.zip", again, _MOCK_NX_CGM_ZIP)
    assert entries == [e for e in entries if e["action"] in ("kept non-standard attribute", "no bidding zone")]
    assert again.read_bytes() == (work / "p_all.zip").read_bytes()


STANDARD_RA = """<?xml version="1.0" encoding="UTF-8"?>
<rdf:RDF xmlns:rdf="http://www.w3.org/1999/02/22-rdf-syntax-ns#" xmlns:nc="https://cim4.eu/ns/nc#" xmlns:cim="https://cim.ucaiug.io/ns#" xmlns:dcat="http://www.w3.org/ns/dcat#" xmlns:dcterms="http://purl.org/dc/terms/">
  <dcat:Dataset rdf:about="urn:uuid:00000000-0000-4000-8000-000000000001">
    <dcterms:conformsTo rdf:resource="https://ap.cim4.eu/RemedialAction/2.5"/>
  </dcat:Dataset>
  <nc:RedispatchRemedialAction rdf:ID="_a1000000-0000-4000-8000-000000000001">
    <nc:PowerRemedialAction.BiddingZone rdf:resource="#_b1000000-0000-4000-8000-000000000001"/>
    <cim:IdentifiedObject.mRID>a1000000-0000-4000-8000-000000000001</cim:IdentifiedObject.mRID>
    <nc:RemedialAction.kind rdf:resource="https://cim4.eu/ns/nc#RemedialActionKind.preventive"/>
    <nc:RemedialAction.normalAvailable>true</nc:RemedialAction.normalAvailable>
  </nc:RedispatchRemedialAction>
  <nc:PowerShiftKeyStrategy rdf:about="#_c1000000-0000-4000-8000-000000000001">
    <nc:PowerShiftKeyStrategy.PowerRemedialAction rdf:resource="#_a1000000-0000-4000-8000-000000000001"/>
    <cim:IdentifiedObject.mRID>c1000000-0000-4000-8000-000000000001</cim:IdentifiedObject.mRID>
  </nc:PowerShiftKeyStrategy>
  <nc:RemedialActionGroup rdf:ID="_d1000000-0000-4000-8000-000000000001">
    <cim:IdentifiedObject.mRID>d1000000-0000-4000-8000-000000000001</cim:IdentifiedObject.mRID>
  </nc:RemedialActionGroup>
  <nc:RemedialActionDependency rdf:ID="_e1000000-0000-4000-8000-000000000001">
    <nc:RemedialActionDependency.kind rdf:resource="https://cim4.eu/ns/nc#RemedialActionDependencyKind.restrictive"/>
    <nc:RemedialActionDependency.DependingRemedialActionGroup rdf:resource="#_d1000000-0000-4000-8000-000000000001"/>
    <nc:RemedialActionDependency.RemedialAction rdf:resource="#_a1000000-0000-4000-8000-000000000001"/>
  </nc:RemedialActionDependency>
</rdf:RDF>
"""

STANDARD_SIS = """<?xml version="1.0" encoding="UTF-8"?>
<rdf:RDF xmlns:rdf="http://www.w3.org/1999/02/22-rdf-syntax-ns#" xmlns:nc="https://cim4.eu/ns/nc#" xmlns:cim="https://cim.ucaiug.io/ns#" xmlns:dcat="http://www.w3.org/ns/dcat#" xmlns:dcterms="http://purl.org/dc/terms/">
  <dcat:Dataset rdf:about="urn:uuid:00000000-0000-4000-8000-000000000002">
    <dcterms:conformsTo rdf:resource="https://ap.cim4.eu/StateInstructionSchedule/2.5"/>
  </dcat:Dataset>
  <nc:PowerBidSchedule rdf:ID="_f1000000-0000-4000-8000-000000000001">
    <cim:IdentifiedObject.mRID>f1000000-0000-4000-8000-000000000001</cim:IdentifiedObject.mRID>
    <nc:PowerBidSchedule.PowerRemedialAction rdf:resource="#_a1000000-0000-4000-8000-000000000001"/>
    <nc:PowerBidSchedule.direction rdf:resource="https://cim4.eu/ns/nc#MarketRegulationDirectionKind.up"/>
    <nc:BaseTimeSeries.interpolationKind rdf:resource="https://cim4.eu/ns/nc#TimeSeriesInterpolationKind.previous"/>
  </nc:PowerBidSchedule>
  <nc:PowerShiftKeySchedule rdf:ID="_f2000000-0000-4000-8000-000000000001">
    <nc:PowerShiftKeySchedule.GeneratingUnit rdf:resource="#_g1000000-0000-4000-8000-000000000001"/>
    <cim:IdentifiedObject.mRID>f2000000-0000-4000-8000-000000000001</cim:IdentifiedObject.mRID>
    <nc:BaseTimeSeries.interpolationKind rdf:resource="https://cim4.eu/ns/nc#TimeSeriesInterpolationKind.none"/>
  </nc:PowerShiftKeySchedule>
  <nc:RemedialActionGroupSchedule rdf:ID="_f3000000-0000-4000-8000-000000000001">
    <nc:RemedialActionGroupSchedule.RemedialActionGroup rdf:resource="#_d1000000-0000-4000-8000-000000000001"/>
    <nc:BaseTimeSeries.interpolationKind rdf:resource="https://cim4.eu/ns/nc#TimeSeriesInterpolationKind.none"/>
  </nc:RemedialActionGroupSchedule>
  <nc:RemedialActionGroupTimePoint rdf:ID="_f4000000-0000-4000-8000-000000000001">
    <nc:RemedialActionGroupTimePoint.RemedialActionGroupSchedule rdf:resource="#_f3000000-0000-4000-8000-000000000001"/>
    <nc:RemedialActionGroupTimePoint.atTime>2022-06-15T10:30:00Z</nc:RemedialActionGroupTimePoint.atTime>
    <nc:RemedialActionGroupTimePoint.maxRegulatingUp>100</nc:RemedialActionGroupTimePoint.maxRegulatingUp>
  </nc:RemedialActionGroupTimePoint>
</rdf:RDF>
"""


def test_rao_converting_standard_form_files_changes_nothing():
    cgm = {"x_EQ_1.xml": b'<cim:ThermalGeneratingUnit rdf:ID="_g1000000-0000-4000-8000-000000000001"></cim:ThermalGeneratingUnit>'}
    files = {"T_RA.xml": STANDARD_RA.encode(), "T_SIS.xml": STANDARD_SIS.encode()}
    converted, entries = conv.convert_files(files, cgm)
    assert converted == files
    assert entries == []


def test_rao_pst_remedial_actions_are_not_touched(old_p, p_all):
    def triples(directory):
        result = set()
        for path in sorted(directory.glob("*_RA.xml")):
            g = _graph(path)
            pst = {s for s in g.subjects(RDF.type, NC.TapPositionAction)}
            pst_ra = {g.value(s, NC["GridStateAlteration.GridStateAlterationRemedialAction"]) for s in pst}
            for subject in pst | pst_ra:
                result |= {(path.name, str(subject), str(p), str(o)) for p, o in g.predicate_objects(subject)}
        return result

    assert triples(old_p) == triples(p_all[0])
    assert len(triples(old_p)) > 0


def test_rao_conversion_log_is_written_as_csv(work, p_all):
    log_path = work / "log.csv"
    conv.write_log(p_all[1], log_path)
    rows = list(csv.DictReader(log_path.open(encoding="utf-8")))
    assert len(rows) == len(p_all[1]) > 0
    assert set(rows[0]) == {"file", "section", "action", "element", "detail"}


def test_rao_redispatch_conversion_logs_the_dropped_ramp_rates(p_all):
    dropped = [e for e in p_all[1] if e["action"] == "removed RotatingMachineAction"]
    assert dropped and all("raiseRampRate" in e["detail"] for e in dropped)


def test_rao_both_unit_routes_are_produced_for_every_redispatch_ra(p_all):
    directory = p_all[0]
    for tso in RD_TSOS:
        ra, sis = _graph(directory / f"{tso}_RA.xml"), _graph(directory / f"{tso}_SIS.xml")
        for rd in ra.subjects(RDF.type, NC.RedispatchRemedialAction):
            bids = {b for b in sis.subjects(NC["PowerBidSchedule.PowerRemedialAction"], rd)}
            strategies = {s for s in ra.subjects(NC["PowerShiftKeyStrategy.PowerRemedialAction"], rd)}
            via_bid = {sis.value(d, NC["PowerShiftKeyDistribution.PowerShiftKeySchedule"])
                       for b in bids for d in sis.subjects(NC["PowerShiftKeyDistribution.PowerBidSchedule"], b)}
            via_strategy = {sis.value(d, NC["PowerShiftKeyDistribution.PowerShiftKeySchedule"])
                            for s in strategies for d in sis.subjects(NC["PowerShiftKeyDistribution.PowerShiftKeyStrategy"], s)}
            assert len(strategies) == 1 and via_bid and via_strategy
            units = lambda keys: {sis.value(k, NC["PowerShiftKeySchedule.GeneratingUnit"]) for k in keys}  # noqa: E731
            assert units(via_bid) == units(via_strategy)
            assert not set(ra.objects(rd, None)) & strategies          # no strategy reference on the RA


def test_rao_routes_option_selects_the_unit_routes(work):
    only_bid, _ = _converted_p(work, "routes_bid", ("redispatch",), routes="bid")
    assert not list(_graph(only_bid / "Espheim_RA.xml").subjects(RDF.type, NC.PowerShiftKeyStrategy))
    both, _ = _converted_p(work, "routes_both", ("redispatch",), routes="both")
    assert list(_graph(both / "Espheim_RA.xml").subjects(RDF.type, NC.PowerShiftKeyStrategy))


def test_rao_each_section_can_be_switched_off(work, old_p):
    for section in conv.SECTIONS:
        others = tuple(s for s in conv.SECTIONS if s != section)
        directory, entries = _converted_p(work, f"without_{section}", others)
        assert section not in {e["section"] for e in entries}


# ---------------------------------------------------------------------------
# section: bids - must pass today
# ---------------------------------------------------------------------------

def test_rao_bids_section_keeps_the_parsed_bids(work, old_p):
    machines = _machines(old_p)
    units, bids = _rd_snapshot(old_p, machines)
    assert len(bids) == 32 and len(units) == 32               # the old snapshot is not empty
    ra_by_tso = {t: {u.mrid for u in units if u.tso == f"TSO-{t}"} for t in RD_TSOS}
    converted, entries = _converted_p(work, "bids_only", ("bids",))
    assert _bid_snapshot(converted, ra_by_tso) == _bid_snapshot(old_p, ra_by_tso) == bids
    assert any(e["action"] == "direction literal" for e in entries)


def test_rao_bids_section_with_non_standard_attributes_dropped_differs_only_in_the_bid_penalty(work, old_p):
    machines = _machines(old_p)
    units, _ = _rd_snapshot(old_p, machines)
    ra_by_tso = {t: {u.mrid for u in units if u.tso == f"TSO-{t}"} for t in RD_TSOS}
    converted, _ = _converted_p(work, "bids_dropped", ("bids",), drop_nonstandard_bid_attributes=True)
    old_bids = _bid_snapshot(old_p, ra_by_tso)
    new_bids = _bid_snapshot(converted, ra_by_tso)
    assert [dataclasses.replace(b, penalty_factor=0.0) for b in old_bids] == new_bids
    assert all(b.penalty_factor == 1.0 for b in old_bids) and all(b.penalty_factor == 0.0 for b in new_bids)


def _first_up_bid(directory):
    sis = _graph(directory / "Espheim_SIS.xml")
    for pbs in sorted(sis.subjects(RDF.type, NC.PowerBidSchedule), key=str):
        if str(sis.value(pbs, NC["PowerBidSchedule.direction"])).endswith(".up"):
            return _frag(pbs), _frag(sis.value(pbs, NC["PowerBidSchedule.PowerRemedialAction"]))
    raise AssertionError("no up bid")


def test_rao_the_converter_can_remove_the_direction_of_one_bid(work, old_p):
    bid_id, ra_id = _first_up_bid(old_p)
    converted, entries = _converted_p(work, "no_direction", ("bids",), strip_direction_of=(bid_id,))
    sis = _graph(converted / "Espheim_SIS.xml")
    stripped = [s for s in sis.subjects(RDF.type, NC.PowerBidSchedule) if _frag(s) == bid_id][0]
    assert sis.value(stripped, NC["PowerBidSchedule.direction"]) is None
    assert any("removed direction" in e["action"] and e["element"] == bid_id for e in entries)


def test_rao_a_bid_without_direction_is_skipped(work, old_p):
    bid_id, ra_id = _first_up_bid(old_p)
    converted, _ = _converted_p(work, "no_direction_2", ("bids",), strip_direction_of=(bid_id,))
    assert bid_id not in {b.mrid for b in _bid_snapshot(converted, {"Espheim": {ra_id}})}


# ---------------------------------------------------------------------------
# section: redispatch and glsk
# ---------------------------------------------------------------------------

def test_rao_redispatch_units_and_bids_are_equal(work, old_p):
    machines = _machines(old_p)
    converted, _ = _converted_p(work, "rd_glsk", ("redispatch", "glsk", "bids"))
    assert _rd_snapshot(converted, machines) == _rd_snapshot(old_p, machines)


def test_rao_glsk_is_equal(work, old_p):
    machines = _machines(old_p)
    units, _ = _rd_snapshot(old_p, machines)
    old_glsk = _glsk_snapshot(old_p, units, machines)
    assert sum(len(f) for t in old_glsk.values() for f in t.values()) == 32      # the old GLSK is not empty
    converted, _ = _converted_p(work, "glsk_only", ("glsk",))
    assert _glsk_snapshot(converted, units, machines) == old_glsk


def test_rao_glsk_section_keeps_every_factor(work, old_p):
    """The participation factors and times are not changed by the conversion (only the unit id is)."""
    converted, _ = _converted_p(work, "glsk_factors", ("glsk",))
    for tso in RD_TSOS:
        old, new = _graph(old_p / f"{tso}_SIS.xml"), _graph(converted / f"{tso}_SIS.xml")
        def factors(g):
            return sorted((str(g.value(p, NC["ParticipationFactorTimePoint.PowerShiftKeySchedule"])),
                           str(g.value(p, NC["ParticipationFactorTimePoint.atTime"])),
                           str(g.value(p, NC["ParticipationFactorTimePoint.participationFactor"])))
                          for p in g.subjects(RDF.type, NC.ParticipationFactorTimePoint))
        assert factors(old) == factors(new) and factors(old)


# ---------------------------------------------------------------------------
# section: groups (countertrade mock builds the groups)
# ---------------------------------------------------------------------------

@pytest.fixture(scope="module")
def ct_group_zip(work):
    ras = ct_mock.default_ras()
    return ct_mock.build_ct_mock_ncp(work / "ct_group.zip", ras=ras, groups=[ct_mock.group("g1", ras[:1], max_up=100.0, max_down=80.0)])


def _group_snapshot(directory):
    from pre_milp import ncp_parser

    return ncp_parser.parse_ra_groups(directory / "Belgovia_RA.xml", directory / "Belgovia_SIS.xml", "TSO-Belgovia", "1030Z")


def test_rao_group_dependency_predicate_conversion_keeps_the_groups(work, ct_group_zip):
    old = _extract(ct_group_zip, work / "ct_group_old")
    assert list(_group_snapshot(old).values())[0]["max_regulating_up"] == 100.0         # the old snapshot has its limits
    converted, entries = _convert(ct_group_zip, work / "ct_group_alias_only.zip", ("groups",), group_limit_chain=False)
    assert any(e["action"] == "renamed predicate" for e in entries)
    graph = _graph(converted / "Belgovia_RA.xml")
    assert list(graph.subjects(NC["RemedialActionDependency.DependingRemedialActionGroup"], None))
    assert not list(graph.subjects(NC["RemedialActionDependency.RemedialActionGroup"], None))
    assert _group_snapshot(converted) == _group_snapshot(old)


def test_rao_group_limits_are_equal(work, ct_group_zip):
    old = _extract(ct_group_zip, work / "ct_group_old2")
    converted, _ = _convert(ct_group_zip, work / "ct_group_chain.zip", ("groups",))
    assert _group_snapshot(converted) == _group_snapshot(old)


# ---------------------------------------------------------------------------
# section: countertrade
# ---------------------------------------------------------------------------

def _ct_snapshot(directory):
    from pre_milp import ct_units

    ras, bids = ct_units.parse_ct_remedial_actions(directory / "Belgovia_RA.xml", directory / "Belgovia_SIS.xml", "TSO-Belgovia", TS)
    ras2, bids2 = ct_units.parse_ct_remedial_actions(directory / "Galia_RA.xml", directory / "Galia_SIS.xml", "TSO-Galia", TS)
    return sorted(ras + ras2, key=lambda r: r.mrid), sorted(bids + bids2, key=lambda b: b.mrid)


@pytest.fixture(scope="module")
def ct_zip(work):
    return ct_mock.build_ct_mock_ncp(work / "ct.zip")


def test_rao_countertrade_section_removes_the_old_strategy_attributes(work, ct_zip):
    old = _extract(ct_zip, work / "ct_old")
    old_ras, old_bids = _ct_snapshot(old)
    assert len(old_ras) == 2 and len(old_bids) == 4                                      # the old snapshot is not empty
    converted, entries = _convert(ct_zip, work / "ct_std.zip", ("countertrade",))
    assert sum(e["action"] == "removed attribute" for e in entries) >= 2
    for tso in ("Belgovia", "Galia"):
        g = _graph(converted / f"{tso}_RA.xml")
        assert not list(g.subjects(NC["CountertradeRemedialAction.gLSKStrategy"], None))
        assert list(g.subjects(RDF.type, NC.CountertradeRemedialAction))


def test_rao_countertrade_ras_and_bids_are_equal(work, ct_zip):
    old = _extract(ct_zip, work / "ct_old2")
    converted, _ = _convert(ct_zip, work / "ct_std2.zip", ("countertrade",))
    assert _ct_snapshot(converted) == _ct_snapshot(old)


# ---------------------------------------------------------------------------
# HVDC: already standard, must pass today (decision 20: unaffected by the shift key rules)
# ---------------------------------------------------------------------------

def _hvdc_snapshot(directory):
    from pre_milp import ncp_parser

    ra = directory / "Svedala_RA.xml"
    return ncp_parser.parse_hvdc_units(ra, "TSO-Svedala"), ncp_parser.parse_balanced_ra_groups(ra, "TSO-Svedala")


@pytest.mark.parametrize("variant", ["preventive", "preventive_and_curative"])
def test_rao_hvdc_parsing_is_unchanged_by_every_section(work, variant):
    ras = hvdc_mock.default_ras() + (hvdc_mock.curative_ras() if variant != "preventive" else [])
    groups = hvdc_mock.default_groups(ras)
    if variant != "preventive":
        groups = groups + hvdc_mock.curative_groups(hvdc_mock.curative_ras())
    zip_path = hvdc_mock.build_hvdc_mock_ncp(work / f"hvdc_{variant}.zip", ras=ras, groups=groups)
    old = _extract(zip_path, work / f"hvdc_{variant}_old")
    old_units, old_groups = _hvdc_snapshot(old)
    assert len(old_units) == len(ras) and old_groups                                       # the old snapshot is not empty
    converted, _ = _convert(zip_path, work / f"hvdc_{variant}_std.zip")
    assert _hvdc_snapshot(converted) == (old_units, old_groups)


def test_rao_hvdc_with_countertrade_is_unchanged_by_every_section(work):
    zip_path = ct_mock.build_ct_and_hvdc_mock_ncp(work / "ch.zip")
    old = _extract(zip_path, work / "ch_old")
    converted, _ = _convert(zip_path, work / "ch_std.zip")
    assert _hvdc_snapshot(converted) == _hvdc_snapshot(old)
    assert _hvdc_snapshot(old)[0]


# ---------------------------------------------------------------------------
# AssessedElementSchedule / AssessedElementTimePoint
# ---------------------------------------------------------------------------

def _first_assessed_element(directory, with_sis=False):
    from pre_milp import ncp_parser

    aes = ncp_parser.parse_assessed_elements(
        directory / "Belgovia_AE.xml", directory / "Belgovia_SHS.xml", "TSO-Belgovia", TS, {},
        sis_path=directory / "Belgovia_SIS.xml" if with_sis else None,
    )
    return aes


@pytest.mark.parametrize("enabled", [True, False])
def test_rao_assessed_element_schedule_is_added_and_not_read_without_the_sis_file(work, old_p, enabled):
    ae_id = _first_assessed_element(old_p)[0].mrid
    converted, entries = _converted_p(work, f"ae_{enabled}", ("other",), ae_schedules=(("Belgovia", ae_id, enabled),))
    sis = _graph(converted / "Belgovia_SIS.xml")
    points = list(sis.subjects(RDF.type, NC.AssessedElementTimePoint))
    assert len(points) == 1 and str(sis.value(points[0], NC["AssessedElementTimePoint.enabled"])).lower() == str(enabled).lower()
    schedule = sis.value(points[0], NC["AssessedElementTimePoint.AssessedElementSchedule"])
    assert _frag(sis.value(schedule, NC["AssessedElementSchedule.AssessedElement"])) == ae_id
    assert [dataclasses.asdict(a) for a in _first_assessed_element(converted)] == [dataclasses.asdict(a) for a in _first_assessed_element(old_p)]


def test_rao_a_disabled_assessed_element_is_not_monitored(work, old_p):
    from data_model import AEType

    ae_id = _first_assessed_element(old_p)[0].mrid
    converted, _ = _converted_p(work, "ae_disabled_reader", ("other",), ae_schedules=(("Belgovia", ae_id, False),))
    # the schedule is in the SIS file; the mock's time point is at the mock's own time, which the pipeline run uses
    aes = {a.mrid: a for a in _first_assessed_element(converted, with_sis=True)}
    assert ae_id not in aes or aes[ae_id].ae_type == AEType.EXCLUDED


def test_rao_the_pipeline_resolves_the_same_glsk_from_generating_unit_ids(work, p_all):
    """A run on the mock with CIM GeneratingUnit ids in its shift keys (glsk section only) writes the same
    glsk_resolved.csv as the run on the old form."""
    from helpers import run_pipeline_on_fixture_inputs

    converted_zip = work / "glsk_only_run.zip"
    conv.convert_zip(_MOCK_NX_NCP_LEGACY_ZIP, converted_zip, _MOCK_NX_CGM_ZIP, conv.Options(sections=("glsk",)))
    old = run_pipeline_on_fixture_inputs(work / "run_old", _MOCK_NX_NCP_LEGACY_ZIP, enable_nx_analysis=False, ra_types=("rd",))
    new = run_pipeline_on_fixture_inputs(work / "run_new", converted_zip, enable_nx_analysis=False, ra_types=("rd",))
    old_text = (old.output_dir / "glsk_resolved.csv").read_text(encoding="utf-8")
    assert old_text.count("\n") > 10
    assert (new.output_dir / "glsk_resolved.csv").read_text(encoding="utf-8") == old_text
def test_rao_the_pipeline_gives_the_same_rd_results_for_redispatch_remedial_actions(work):
    """A run on the mock with the redispatch, glsk and bids sections (RedispatchRemedialAction, units from the shift
    keys) writes the same RD result files as the run on the old form."""
    from helpers import run_pipeline_on_fixture_inputs

    converted_zip = work / "rd_run.zip"
    conv.convert_zip(_MOCK_NX_NCP_LEGACY_ZIP, converted_zip, _MOCK_NX_CGM_ZIP, conv.Options(sections=("redispatch", "glsk", "bids")))
    old = run_pipeline_on_fixture_inputs(work / "rd_run_old", _MOCK_NX_NCP_LEGACY_ZIP, enable_nx_analysis=False, ra_types=("rd",))
    new = run_pipeline_on_fixture_inputs(work / "rd_run_new", converted_zip, enable_nx_analysis=False, ra_types=("rd",))
    names = sorted(p.name for p in old.output_dir.glob("*.csv") if not p.name.startswith("run_log"))
    assert "glsk_resolved.csv" in names and len(names) > 5
    different = [n for n in names if n.startswith(("results", "glsk", "rd", "bids")) and "iteration_history" not in n and      # wall-clock seconds columns
                 
                 (old.output_dir / n).read_bytes() != (new.output_dir / n).read_bytes()]
    assert different == []


# ---------------------------------------------------------------------------
# bid signs (decision 24): down bids p < 0, up bids p > 0, same |p|
# ---------------------------------------------------------------------------

def _bid_points(directory):
    """[(direction word, p text)] of every bid time point of the four RD TSOs, sorted."""
    result = []
    for tso in RD_TSOS:
        sis = _graph(directory / f"{tso}_SIS.xml")
        for point in sis.subjects(RDF.type, NC.PowerBidScheduleTimePoint):
            bid = sis.value(point, NC["PowerBidScheduleTimePoint.PowerBidSchedule"])
            direction = str(sis.value(bid, NC["PowerBidSchedule.direction"])).rsplit(".", 1)[-1]
            result.append((_frag(bid), direction, str(sis.value(point, NC["PowerBidScheduleTimePoint.p"]))))
    return sorted(result)


def test_rao_the_old_mock_has_down_bids_with_a_positive_p(old_p):
    assert any(d == "down" and not p.startswith("-") for _, d, p in _bid_points(old_p))


def test_rao_the_bids_section_gives_down_bids_a_negative_p_and_up_bids_a_positive_p(work, old_p):
    converted, entries = _converted_p(work, "bid_signs", ("bids",))
    old, new = _bid_points(old_p), _bid_points(converted)
    assert len(old) == len(new) > 10
    for (bid, direction, p_old), (bid2, direction2, p_new) in zip(old, new):
        assert (bid, direction) == (bid2, direction2) and abs(float(p_old)) == abs(float(p_new))
        assert (float(p_new) < 0) if direction == "down" else (float(p_new) > 0)
    assert any(e["action"] == "bid sign" for e in entries)


def test_rao_the_bid_sign_correction_can_be_switched_off(work, old_p):
    converted, entries = _converted_p(work, "bid_signs_off", ("bids",), correct_bid_signs=False)
    assert _bid_points(converted) == _bid_points(old_p) and not any(e["action"] == "bid sign" for e in entries)


def test_rao_the_converted_mock_gives_no_bid_sign_warning(work, old_p, caplog):
    import logging

    machines = _machines(old_p)
    with caplog.at_level(logging.WARNING):
        _rd_snapshot(old_p, machines)
    assert any("sign of p disagrees" in r.getMessage() for r in caplog.records)
    converted, _ = _converted_p(work, "bid_signs_warning", ("bids",))
    caplog.clear()
    with caplog.at_level(logging.WARNING):
        _rd_snapshot(converted, machines)
    assert not any("sign of p disagrees" in r.getMessage() for r in caplog.records)


def test_rao_the_shipped_mock_is_the_generated_standard_mock(work):
    """NCP_mock_standard.zip is what mock_data.standard generates: the legacy mock converted with every section,
    the non-standard bid attributes dropped and the bid signs corrected, plus the countertrade RAs and bids of the four
    regions (regenerate it with `python -m mock_data standard` when the converter or the countertrade data change)."""
    regenerated = standard.build_standard(work / "regenerated.zip")
    assert regenerated.read_bytes() == _MOCK_NX_NCP_ZIP.read_bytes()


def test_rao_the_base_of_the_builders_is_the_converted_legacy_mock_without_countertrade(work):
    """The base that the countertrade, HVDC, dataset and shared-bid builders start from is the plain conversion of the
    legacy mock; it is the shipped mock as it was before the countertrade RAs were added (SHA-256 fixed)."""
    import hashlib
    converted = work / "converted.zip"
    conv.convert_zip(_MOCK_NX_NCP_LEGACY_ZIP, converted, _MOCK_NX_CGM_ZIP, conv.Options(drop_nonstandard_bid_attributes=True))
    assert standard.build_base(work / "base.zip").read_bytes() == converted.read_bytes()
    assert hashlib.sha256(converted.read_bytes()).hexdigest() == "c48ceb778870e1bc0443571eea88679bcb332326313635ac1dfc963ac59121e5"


def test_rao_the_shipped_mock_is_standard_form_and_gives_no_deprecation_or_sign_warning(work, caplog, generating_units):
    import logging

    shipped = _extract(_MOCK_NX_NCP_ZIP, work / "shipped_p")
    assert standard_form_violations(shipped, generating_units) == []
    machines = _machines(_extract(_MOCK_NX_NCP_LEGACY_ZIP, work / "legacy_p"))
    with caplog.at_level(logging.WARNING):
        units, bids = _rd_snapshot(shipped, machines)
    assert len(units) == 32 and len(bids) == 32
    assert [r.getMessage() for r in caplog.records if any(w in r.getMessage() for w in ("deprecated", "sign of p", "not in the profile"))] == []