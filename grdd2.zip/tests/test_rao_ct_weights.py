"""
test_rao_ct_weights.py — countertrade participation factors (docs/specs/countertrade_ra_specs.md C3):
pre_milp/ct_weights.py on hand-computed examples, and the whole chain (zone -> units -> weights) on
the real CGM for Belgovia and Galia.
"""
import logging
import zipfile

import pytest

from data_model import BidDirection, CtZoneUnit
from helpers import FIXTURE_CGM_ZIP, FIXTURE_NCP_GENERIC_ZIP
from pre_milp import ct_units, ct_weights
from pre_milp.ct_weights import compute_ct_weights

UP, DOWN = BidDirection.UP, BidDirection.DOWN
UNBOUNDED = 1.797693e308


def _unit(gu, prod, pmin, pmax, connected=True):
    return CtZoneUnit(gu_mrid=gu, unit_mrid=f"U-{gu}", name=gu, prod=prod, pmin=pmin, pmax=pmax, connected=connected)


# the 5-unit example of the plan (MW, generation sign)
A = _unit("A", 100.0, 20.0, 200.0)                 # room up 100, room down 80
B = _unit("B", 150.0, 50.0, 150.0)                 # at Pmax: no room up, room down 100
C = _unit("C", 40.0, 40.0, 120.0)                  # at Pmin: room up 80, no room down
D = _unit("D", 0.0, 30.0, 100.0)                   # off (PROD 0, Pmin > 0)
E = _unit("E", 80.0, -UNBOUNDED, UNBOUNDED)        # unbounded limits (an equivalent injection)
FIVE = [A, B, C, D, E]


def test_t1_up_weights_of_the_five_unit_example():
    result = compute_ct_weights(FIVE, UP)
    # room: A 200-100 = 100, C 120-40 = 80; B has none, D is off, E is unbounded; total 180
    assert result.pf == pytest.approx({"A": 100 / 180, "C": 80 / 180}, abs=1e-12)
    assert result.excluded == {
        "B": ct_weights.REASON_AT_PMAX, "D": ct_weights.REASON_OFF, "E": ct_weights.REASON_NO_LIMITS,
    }
    assert sum(result.pf.values()) == pytest.approx(1.0)


def test_t1b_up_weights_equal_the_normalisation_after_exclusion_of_the_spec():
    # raw factors over the connected, bounded units A, B, C, D: room 100, 0, 80, 100 (D counted as if on);
    # excluding D (raw 100/280) and renormalising PF_g / (1 - sum of the excluded PF) gives the same factors
    raw = {"A": 100 / 280, "B": 0 / 280, "C": 80 / 280, "D": 100 / 280}
    excluded = raw["D"]
    expected = {g: raw[g] / (1 - excluded) for g in ("A", "C")}
    assert compute_ct_weights(FIVE, UP).pf == pytest.approx(expected, abs=1e-12)
    assert expected["A"] == pytest.approx(0.5556, abs=1e-4) and expected["C"] == pytest.approx(0.4444, abs=1e-4)


def test_t2_down_weights_of_the_five_unit_example():
    result = compute_ct_weights(FIVE, DOWN)
    # room down: A 100-20 = 80, B 150-50 = 100; C is at Pmin; total 180
    assert result.pf == pytest.approx({"A": 80 / 180, "B": 100 / 180}, abs=1e-12)
    assert result.excluded == {
        "C": ct_weights.REASON_AT_PMIN, "D": ct_weights.REASON_OFF, "E": ct_weights.REASON_NO_LIMITS,
    }
    assert result.pf["A"] == pytest.approx(0.4444, abs=1e-4) and result.pf["B"] == pytest.approx(0.5556, abs=1e-4)


def test_t3_no_unit_left_gives_empty_weights_and_one_warning(caplog):
    with caplog.at_level(logging.WARNING, logger=ct_weights.log.name):
        up = compute_ct_weights([B, D], UP, label="countertrade RA X")
    assert up.pf == {}
    warnings = [r.getMessage() for r in caplog.records if r.levelno == logging.WARNING]
    assert len(warnings) == 1 and "countertrade RA X" in warnings[0] and "fixed to 0" in warnings[0]


def test_no_log_line_without_a_label(caplog):
    with caplog.at_level(logging.INFO, logger=ct_weights.log.name):
        compute_ct_weights([B, D], UP)
    assert caplog.records == []


def test_t4_a_negative_pmin_counts_with_its_negative_part():
    # BO-G1 of the CGM: PROD 52.8181, Pmin -100, Pmax 200: room down 52.8181 + 100
    result = compute_ct_weights([_unit("G1", 52.8181, -100.0, 200.0), _unit("G2", 78.9071, 50.0, 200.0)], DOWN)
    assert result.pf == pytest.approx({"G1": 152.8181 / 181.7252, "G2": 28.9071 / 181.7252}, abs=1e-12)


def test_t5_two_calls_give_the_same_weights_and_the_order_of_the_units_does_not_matter():
    assert compute_ct_weights(FIVE, UP).pf == compute_ct_weights(list(reversed(FIVE)), UP).pf


def test_t6_a_unit_above_its_pmax_is_excluded_in_both_directions():
    over = _unit("O", 130.0, 20.0, 120.0)
    for direction in (UP, DOWN):
        result = compute_ct_weights([A, over], direction)
        assert result.excluded["O"] == ct_weights.REASON_ABOVE_PMAX
        assert result.pf == {"A": 1.0}


def test_t6b_a_unit_between_zero_and_pmin_has_pmin_set_to_its_prod():
    # PROD 10 with Pmin 25 (F2 rule 11): no room down, room up 60 - 10 = 50
    f = _unit("F", 10.0, 25.0, 60.0)
    assert compute_ct_weights([A, f], DOWN).excluded["F"] == ct_weights.REASON_AT_PMIN
    assert compute_ct_weights([A, f], UP).pf == pytest.approx({"A": 100 / 150, "F": 50 / 150}, abs=1e-12)


def test_a_unit_with_prod_zero_and_pmin_not_above_zero_is_on_and_takes_part():
    zero = _unit("Z", 0.0, 0.0, 50.0)
    up = compute_ct_weights([A, zero], UP)
    down = compute_ct_weights([A, zero], DOWN)
    assert up.pf == pytest.approx({"A": 100 / 150, "Z": 50 / 150}, abs=1e-12)
    assert "Z" in down.excluded and down.excluded["Z"] == ct_weights.REASON_AT_PMIN   # room down 0 - 0


def test_a_prod_of_a_tiny_magnitude_counts_as_zero():
    tiny = _unit("T", 1e-9, 30.0, 100.0)
    assert compute_ct_weights([A, tiny], UP).excluded["T"] == ct_weights.REASON_OFF


def test_an_unconnected_unit_and_a_unit_with_a_nan_limit_are_excluded():
    gone = _unit("N", 50.0, 0.0, 100.0, connected=False)
    nan_limit = _unit("M", 50.0, 0.0, float("nan"))
    result = compute_ct_weights([A, gone, nan_limit], UP)
    assert result.excluded == {"N": ct_weights.REASON_NOT_CONNECTED, "M": ct_weights.REASON_NO_LIMITS}
    assert result.pf == {"A": 1.0}


@pytest.mark.parametrize("pmin, pmax", [(-UNBOUNDED, 200.0), (20.0, UNBOUNDED), (float("nan"), 200.0)])
def test_a_unit_with_one_unbounded_or_nan_limit_is_excluded_in_both_directions(pmin, pmax):
    one_sided = _unit("H", 100.0, pmin, pmax)
    for direction in (UP, DOWN):
        result = compute_ct_weights([A, one_sided], direction)
        assert result.excluded["H"] == ct_weights.REASON_NO_LIMITS and result.pf == {"A": 1.0}


@pytest.mark.parametrize("pmin, pmax", [(-UNBOUNDED, 200.0), (20.0, UNBOUNDED)])
def test_a_generator_with_one_unbounded_limit_is_no_candidate_unit_of_its_zone(pmin, pmax, caplog):
    from data_model import CtRa, RAKind
    from pre_milp.ct_units import CtGenerator, CtZone
    generators = {
        gu: CtGenerator(gu, f"U-{gu}", gu, "SynchronousMachine", 100.0, low, high, True, True)
        for gu, low, high in (("G1", 0.0, 200.0), ("G2", pmin, pmax))
    }
    zone = CtZone("Z", "BZ-Z", ["CA"])
    ra = CtRa(mrid="CT", name="CT", tso="T", zone_mrid="Z", available=True, kind=RAKind.PREVENTIVE, penalty_factor=1.0,
              strategy=ct_units.STRATEGY_REMAINING_CAPACITY)
    with caplog.at_level(logging.INFO, logger=ct_units.log.name):
        kept, units_by_zone = ct_units.resolve_zone_units([ra], {"Z": zone}, {"CA": {"U-G1", "U-G2"}}, generators)
    assert [u.gu_mrid for u in units_by_zone["Z"]] == ["G1"] and len(kept) == 1
    assert any("1 limits unbounded" in r.getMessage() for r in caplog.records)


def test_an_ra_whose_zone_cannot_move_in_either_direction_is_dropped(caplog):
    from data_model import CtRa, PowerBid, RAKind
    ra = CtRa(mrid="CT", name="CT", tso="T", zone_mrid="Z", available=True, kind=RAKind.PREVENTIVE, penalty_factor=1.0,
              strategy=ct_units.STRATEGY_REMAINING_CAPACITY)
    bids = [
        PowerBid(mrid=f"B-{d.value}", ra_mrid="CT", direction=d, available_mw={"1030Z": 50.0}, price_eur_mw=1.0,
                 penalty_factor=0.0, lead_time_h=0.0, activation_cost_eur=None, min_energy_mwh=None, max_energy_mwh=None,
                 step_size_mw=None)
        for d in (UP, DOWN)
    ]
    off = _unit("D", 0.0, 30.0, 100.0)            # the only unit of the zone is off: no room in either direction
    weights = ct_units.resolve_ct_weights([ra], {"Z": [off]}, bids)
    with caplog.at_level(logging.WARNING, logger=ct_units.log.name):
        rd_units, kept_bids, participation = ct_units.build_ct_milp_data([ra], bids, {"Z": [off]}, weights)
    assert rd_units == [] and kept_bids == [] and participation == {}
    assert any("DROPPED - no unit of its zone can move in either direction" in r.getMessage() for r in caplog.records)


def test_the_weights_are_non_negative_and_sum_to_one():
    for direction in (UP, DOWN):
        pf = compute_ct_weights(FIVE, direction).pf
        assert all(value >= 0.0 for value in pf.values()) and sum(pf.values()) == pytest.approx(1.0)


# ---------------------------------------------------------------------------
# T7: the real CGM (Belgovia and Galia), by hand from the CGM set points and limits
# ---------------------------------------------------------------------------

BELGOVIA_ZONE = "87fb9f56-fd86-446f-b35d-c0abba19925f"
GALIA_ZONE = "4d4166a4-c0dc-4c77-9b67-a04a7e68ddf2"
BO_G1, BO_G2 = "3a3b27be-b18b-4385-b557-6735d733baf0", "550ebe0d-f2b2-48c1-991f-cebea43a21aa"
GA_G1, GA_G2, GA_G3 = (
    "9c3b8f97-7972-477d-9dc8-87365cc0ad0e", "2844585c-0d35-488d-a449-685bcd57afbf", "1dc9afba-23b5-41a0-8540-b479ed8baf4b",
)

# Belgovia: BO-G1 PROD 52.8181 [-100, 200], BO-G2 PROD 78.9071 [50, 200]
#   up:   room 147.1819 and 121.0929, total 268.2748;  down: room 152.8181 and 28.9071, total 181.7252
# Galia: GA-G1 PROD 705.637 [300, 1000], GA-G2 and GA-G3 PROD 180 [130, 225]
#   up:   room 294.363, 45, 45, total 384.363;  down: room 405.637, 50, 50, total 505.637
EXPECTED = {
    (BELGOVIA_ZONE, UP): {BO_G1: 147.1819 / 268.2748, BO_G2: 121.0929 / 268.2748},
    (BELGOVIA_ZONE, DOWN): {BO_G1: 152.8181 / 181.7252, BO_G2: 28.9071 / 181.7252},
    (GALIA_ZONE, UP): {GA_G1: 294.363 / 384.363, GA_G2: 45 / 384.363, GA_G3: 45 / 384.363},
    (GALIA_ZONE, DOWN): {GA_G1: 405.637 / 505.637, GA_G2: 50 / 505.637, GA_G3: 50 / 505.637},
}


@pytest.fixture(scope="module")
def real_cgm_zones(tmp_path_factory):
    """(zones, area units, generator table) of the real CGM fixture and the Organisation profile."""
    import pypowsybl as pp

    work = tmp_path_factory.mktemp("ct_real_cgm")
    with zipfile.ZipFile(FIXTURE_CGM_ZIP) as archive:
        archive.extractall(work / "cgm")
    with zipfile.ZipFile(FIXTURE_NCP_GENERIC_ZIP) as archive:
        archive.extract("Org-NineRealms_CD.xml", work)
    network = pp.network.load(
        str(FIXTURE_CGM_ZIP),
        parameters={"iidm.import.cgmes.source-for-iidm-id": "mRID", "iidm.import.cgmes.cgm-with-subnetworks": "false"},
    )
    zones = ct_units.parse_bidding_zones(work / "Org-NineRealms_CD.xml")
    return zones, ct_units.read_control_area_units(work / "cgm"), ct_units.read_generator_table(network)


def _ra(zone_mrid):
    from data_model import CtRa, RAKind
    return CtRa(
        mrid=f"CT-{zone_mrid[:4]}", name="CT", tso="TSO", zone_mrid=zone_mrid, available=True, kind=RAKind.PREVENTIVE,
        penalty_factor=1.0, strategy=ct_units.STRATEGY_REMAINING_CAPACITY,
    )


def test_t7_the_weights_of_belgovia_and_galia_from_the_real_cgm(real_cgm_zones):
    zones, area_units, generators = real_cgm_zones
    ras = [_ra(BELGOVIA_ZONE), _ra(GALIA_ZONE)]
    kept, units_by_zone = ct_units.resolve_zone_units(ras, zones, area_units, generators)
    assert [ra.zone_name for ra in kept] == ["BZ-Belgovia", "BZ-Galia"]
    assert {u.gu_mrid for u in units_by_zone[BELGOVIA_ZONE]} == {BO_G1, BO_G2}
    assert {u.gu_mrid for u in units_by_zone[GALIA_ZONE]} == {GA_G1, GA_G2, GA_G3}

    weights = ct_units.resolve_ct_weights(kept, units_by_zone)
    for ra in kept:
        for direction in (UP, DOWN):
            assert weights[(ra.mrid, direction)].pf == pytest.approx(EXPECTED[(ra.zone_mrid, direction)], abs=1e-6)
    assert EXPECTED[(BELGOVIA_ZONE, UP)][BO_G1] == pytest.approx(0.54863, abs=1e-5)
    assert EXPECTED[(GALIA_ZONE, DOWN)][GA_G1] == pytest.approx(0.80223, abs=1e-5)
