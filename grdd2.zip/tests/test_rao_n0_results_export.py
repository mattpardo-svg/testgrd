"""tests/test_rao_n0_results_export.py - tests for n0_results_export.py (result files of the preventive and curative solve).

Sections: results summary, RA count, curative RD, generating units, curative PST, files written by the mock pipeline run, lead times, the AC verification status columns, and the iteration and completeness files.
"""

import csv
import pyomo.environ as pyo
import pytest
import sys

from data_model import AcVerificationStatus, BidDirection, RAKind, AEType, AssessedElement, PowerBid, RDUnit
from milp.milp_builder import NxMilpInputs, PstMilpInputs, RdMilpInputs, build_n0_milp_model
from post_milp.n0_results_export import (
    extract_curative_rd_results,
    extract_rd_results,
    extract_results_summary,
    write_results_summary_csv,
    RA_ACTIVATION_NET_VOLUME_TOLERANCE_MW,
    extract_ra_count_results,
    write_curative_rd_results_csv,
    extract_results_generating_units,
    write_results_generating_units_csv,
    extract_curative_pst_group_results,
    extract_curative_pst_delta_results,
    extract_curative_pst_results,
    write_curative_pst_delta_results_csv,
    write_pst_results_csv,
    extract_lead_time_results,
    write_results_rd_csv,
    write_results_ra_count_csv,
    write_results_ra_groups_csv,
    write_results_lead_times_csv,
    write_completeness_iterations_csv,
)
from helpers import (
    _make_ae,
    _make_pst,
    REFERENCE_PST,
    REFERENCE_RD,
    _all_terms_scenario,
    BIDS,
    PENALTY_FACTOR,
    REFERENCE,
    _bid_rd_cost as _bid_curative_rd_results,
    _solved_model,
    _unit,
    _make_ae_mb_results as _make_ae_generating_units_results,
    _make_bid,
    _make_rd_unit,
    GROUP,
    _solve_group_model,
    _three_psts,
)
from pathlib import Path
from post_milp import n0_results_export
from text_encoding import TEXT_ENCODING  # noqa: E402

# ===========================================================================
# Results summary
# ===========================================================================

def _summary(model, pst_inputs, rd_inputs, **kwargs):
    rd_results = extract_rd_results(
        model, rd_inputs.rd_list, rd_inputs.bid_list, REFERENCE_RD,
        AcVerificationStatus.CONVERGED, "stable",
    )
    curative_rows = extract_curative_rd_results(model, rd_inputs.rd_list, rd_inputs.bid_list, REFERENCE_RD)
    return extract_results_summary(
        model, objective_value=pyo.value(model.objective), pst_list=pst_inputs.pst_list,
        penalty_reference_pst_pra=REFERENCE_PST, rd_results=rd_results,
        curative_rd_results=curative_rows, **kwargs,
    )


def test_every_component_is_non_zero_and_they_add_up_to_the_objective():
    model, pst_inputs, rd_inputs = _all_terms_scenario()
    summary = _summary(model, pst_inputs, rd_inputs)
    components = [
        "sum_pst_penalty_cost_eur", "sum_curative_pst_penalty_cost_eur", "sum_rd_cost_eur",
        "sum_curative_rd_cost_eur", "sum_ra_count_penalty_eur",
        "sum_overload_slack_penalty_n0_eur", "sum_overload_slack_penalty_nx_patl_eur",
    ]
    for name in components:
        assert summary[name] > 1e-6, name              # scenario really exercises every term
    total = sum(summary[name] for name in components) + sum(
        summary[name] for name in (
            "sum_overload_slack_penalty_n0_scanned_eur", "sum_overload_slack_penalty_nx_tatl_eur",
            "sum_overload_slack_penalty_nx_scanned_eur",
        )
    )
    assert total == pytest.approx(summary["objective_value"], abs=1e-6)
    assert summary["objective_residual_eur"] == pytest.approx(0.0, abs=1e-6)


def test_rd_penalty_is_not_added_a_second_time():
    """sum_rd_penalty_cost_eur is part of sum_rd_cost_eur: adding it would break the identity."""
    model, pst_inputs, rd_inputs = _all_terms_scenario()
    summary = _summary(model, pst_inputs, rd_inputs)
    assert summary["sum_rd_penalty_cost_eur"] > 0.0
    assert summary["objective_residual_eur"] == pytest.approx(0.0, abs=1e-6)


def test_residual_detects_a_missing_component():
    """Without the curative RD rows the identity must visibly fail (residual = that cost)."""
    model, pst_inputs, rd_inputs = _all_terms_scenario()
    rd_results = extract_rd_results(
        model, rd_inputs.rd_list, rd_inputs.bid_list, REFERENCE_RD, AcVerificationStatus.CONVERGED, "stable",
    )
    without = extract_results_summary(
        model, objective_value=pyo.value(model.objective), pst_list=pst_inputs.pst_list,
        penalty_reference_pst_pra=REFERENCE_PST, rd_results=rd_results,
    )
    full = _summary(model, pst_inputs, rd_inputs)
    assert without["objective_residual_eur"] == pytest.approx(full["sum_curative_rd_cost_eur"], abs=1e-6)
    assert full["sum_curative_rd_cost_eur"] > 0.0


def test_duplicate_preventive_ras_on_one_transformer_are_costed_once():
    model, pst_inputs, rd_inputs = _all_terms_scenario()
    reference = _summary(model, pst_inputs, rd_inputs)["sum_pst_penalty_cost_eur"]
    duplicate = _make_pst("P1", RAKind.PREVENTIVE)
    pst_inputs.pst_list.append(duplicate)
    assert _summary(model, pst_inputs, rd_inputs)["sum_pst_penalty_cost_eur"] == pytest.approx(reference)


def test_pst_only_summary_has_zero_not_absent_rd_and_slack_metrics():
    pst = _make_pst("P1", RAKind.PREVENTIVE)
    pst_inputs = PstMilpInputs(
        pst_list=[pst], pst_tap_bounds={"P1": (-10, 10)}, pst_group_equality_pairs=[],
        sensitivity_pst_n0_pruned={("B1", "P1"): -10.0}, pst_degrees_per_tap={"P1": 1.0},
        penalty_reference_pst_pra=REFERENCE_PST,
    )
    model = build_n0_milp_model(
        [_make_ae("B1")], "1030Z", lf_initial={"B1": {1: 1050.0}},
        penalty_cost_overload_n0=1000.0, pst_inputs=pst_inputs,
    )
    pyo.SolverFactory("appsi_highs").solve(model)
    summary = extract_results_summary(
        model, objective_value=pyo.value(model.objective), pst_list=[pst], penalty_reference_pst_pra=REFERENCE_PST,
    )
    assert summary["sum_curative_rd_cost_eur"] == 0.0 and summary["sum_ra_count_penalty_eur"] == 0.0
    assert summary["sum_overload_slack_penalty_nx_patl_eur"] == 0.0
    assert summary["objective_residual_eur"] == pytest.approx(0.0, abs=1e-6)


def test_status_rows_and_metric_value_format(tmp_path):
    model, pst_inputs, rd_inputs = _all_terms_scenario()
    path = tmp_path / "results_summary.csv"
    summary = _summary(
        model, pst_inputs, rd_inputs, output_path=path,
        ac_verification_status=AcVerificationStatus.CONVERGED, ac_verification_termination_reason="stable",
    )
    with open(path, newline="", encoding=TEXT_ENCODING) as f:
        rows = list(csv.reader(f))
    assert rows[0] == ["metric", "value"]
    written = dict(rows[1:])
    assert written["ac_verification_status"] == AcVerificationStatus.CONVERGED.value
    assert written["ac_verification_termination_reason"] == "stable"
    assert float(written["objective_residual_eur"]) == pytest.approx(0.0, abs=1e-6)
    assert list(summary)[:7] == [
        "sum_rd_volume_upward_mw", "sum_rd_volume_downward_mw", "sum_rd_cost_eur", "sum_rd_penalty_cost_eur",
        "sum_pst_penalty_cost_eur", "objective_value", "remaining_overload_count",
    ]


# ===========================================================================
# RA count
# ===========================================================================

REPO_SRC = Path(__file__).resolve().parents[1] / "src" / "rao"


TIMESTAMP = "1030Z"


CONVERGED = AcVerificationStatus.CONVERGED


def _ae(branch_mrid: str) -> AssessedElement:
    return AssessedElement(
        mrid=f"AE_{branch_mrid}", name=branch_mrid, tso="TSO_A", ae_type=AEType.SECURED,
        branch_mrid=branch_mrid, secured_for_region=None, scanned_for_region=None,
        exclusion_reason=None, patl_ka={TIMESTAMP: 1.0}, branch_side=1,
    )


def _rd_unit(mrid: str, gu_mrid: str, tso: str) -> RDUnit:
    return RDUnit(
        mrid=mrid, name=mrid, tso=tso, gu_mrid=gu_mrid, gu_name=gu_mrid,
        available=True, kind=RAKind.PREVENTIVE, initial_p=50.0, max_p=1000.0, min_p=0.0,
        raise_ramp_rate=None, lower_ramp_rate=None,
    )


def _bid(mrid: str, ra_mrid: str, direction: BidDirection) -> PowerBid:
    return PowerBid(
        mrid=mrid, ra_mrid=ra_mrid, direction=direction, available_mw={TIMESTAMP: 20.0},
        price_eur_mw=1.0, penalty_factor=0.0, lead_time_h=0.0,
        activation_cost_eur=None, min_energy_mwh=None, max_energy_mwh=None, step_size_mw=None,
    )


def _solved_model_without_dispatch():
    """Two TSOs: TSO_A owns RA1 (UP) and RA2 (DOWN), TSO_B owns RA3 (UP).
    The branch is not overloaded, so the optimiser dispatches nothing."""
    rd_list = [_rd_unit("RA1", "GU1", "TSO_A"), _rd_unit("RA2", "GU2", "TSO_A"), _rd_unit("RA3", "GU3", "TSO_B")]
    bid_list = [
        _bid("BID1", "RA1", BidDirection.UP),
        _bid("BID2", "RA2", BidDirection.DOWN),
        _bid("BID3", "RA3", BidDirection.UP),
    ]
    rd_inputs = RdMilpInputs(
        rd_list=rd_list, bid_list=bid_list,
        glsk={"RA1": {"GU1": 1.0}, "RA2": {"GU2": 1.0}, "RA3": {"GU3": 1.0}},
        sensitivity_rd_n0_pruned={("BRANCH1", "GU1"): -10.0},
        generator_data={
            f"GU{i}": {"target_p": 50.0, "max_p": 100.0, "min_p": 0.0, "name": f"GU{i}"} for i in (1, 2, 3)
        },
    )
    model = build_n0_milp_model(
        [_ae("BRANCH1")], TIMESTAMP, lf_initial={"BRANCH1": {1: 500.0}},
        penalty_cost_overload_n0=1000.0, rd_inputs=rd_inputs,
    )
    pyo.SolverFactory("appsi_highs").solve(model)
    return model, rd_list, bid_list


def _force_all_binaries_to_one(model) -> None:
    for ra_mrid in model.ra_mrids:
        model.ra_activated[ra_mrid].value = 1


def _extract(model, rd_list, bid_list, output_path=None):
    return extract_ra_count_results(
        model, rd_list=rd_list, bid_list=bid_list,
        ac_verification_status=CONVERGED, ac_verification_termination_reason="test fixture",
        timestamp=TIMESTAMP, output_path=output_path,
    )


def test_binary_one_with_zero_volume_gives_count_zero_and_raw_column_shows_one():
    """Given every ra_activated binary left at 1 while no volume is
    dispatched, When the RA counts are extracted, Then activated_ra_count
    is 0 for every TSO and the raw binary column still shows the model's 1s."""
    model, rd_list, bid_list = _solved_model_without_dispatch()
    _force_all_binaries_to_one(model)

    results = _extract(model, rd_list, bid_list)

    assert results["TSO_A"]["activated_ra_count"] == 0
    assert results["TSO_B"]["activated_ra_count"] == 0
    assert results["TSO_A"]["ra_activated_model_binary"] == 2
    assert results["TSO_B"]["ra_activated_model_binary"] == 1


def test_count_follows_net_volume_for_upward_and_downward_bids():
    """Given an upward volume on RA1 and a downward volume on RA2 (TSO_A)
    and nothing on TSO_B, When extracted, Then TSO_A counts 2 and TSO_B
    counts 0 even though all three binaries are 1."""
    model, rd_list, bid_list = _solved_model_without_dispatch()
    _force_all_binaries_to_one(model)
    model.rd_volume_upward["BID1"].value = 7.0
    model.rd_volume_downward["BID2"].value = 3.0

    results = _extract(model, rd_list, bid_list)

    assert results["TSO_A"]["activated_ra_count"] == 2
    assert results["TSO_B"]["activated_ra_count"] == 0
    assert results["TSO_B"]["ra_activated_model_binary"] == 1


def test_count_per_tso_is_consistent_with_preventive_rd_rows():
    """Given a mixed dispatch, When both extractors run on the same model,
    Then for every TSO the activated_ra_count equals the number of distinct
    RAs having a non-zero rd_volume_net_mw in the preventive RD results."""
    model, rd_list, bid_list = _solved_model_without_dispatch()
    _force_all_binaries_to_one(model)
    model.rd_volume_upward["BID3"].value = 4.0
    model.rd_volume_downward["BID2"].value = 3.0

    counts = _extract(model, rd_list, bid_list)
    rd_rows = extract_rd_results(
        model, rd_list=rd_list, bid_list=bid_list, penalty_reference_rd_pra=0.0,
        ac_verification_status=CONVERGED, ac_verification_termination_reason="test fixture",
    )

    for tso, row in counts.items():
        active_ras_in_rd_rows = {
            r["ra_mrid"] for r in rd_rows.values()
            if r["tso"] == tso and abs(r["rd_volume_net_mw"]) > RA_ACTIVATION_NET_VOLUME_TOLERANCE_MW
        }
        assert row["activated_ra_count"] == len(active_ras_in_rd_rows), tso
    assert counts["TSO_A"]["activated_ra_count"] == 1
    assert counts["TSO_B"]["activated_ra_count"] == 1


def test_tolerance_constant_is_one_micro_mw_and_decides_the_boundary():
    """The named tolerance is 1e-6 MW: a net volume of 5e-7 MW is not an
    activation, 2e-6 MW is."""
    assert RA_ACTIVATION_NET_VOLUME_TOLERANCE_MW == 1e-6

    model, rd_list, bid_list = _solved_model_without_dispatch()
    _force_all_binaries_to_one(model)
    model.rd_volume_upward["BID1"].value = 5e-7
    model.rd_volume_upward["BID3"].value = 2e-6

    results = _extract(model, rd_list, bid_list)

    assert results["TSO_A"]["activated_ra_count"] == 0
    assert results["TSO_B"]["activated_ra_count"] == 1


def test_written_csv_has_derived_count_and_raw_binary_columns(tmp_path):
    """Given binaries at 1 and no volume, When the CSV is written, Then it
    holds activated_ra_count = 0 and ra_activated_model_binary = the raw sum."""
    model, rd_list, bid_list = _solved_model_without_dispatch()
    _force_all_binaries_to_one(model)
    output_path = tmp_path / "results_preventive_rd_ra_count.csv"

    _extract(model, rd_list, bid_list, output_path=output_path)

    with open(output_path, newline="", encoding=TEXT_ENCODING) as f:
        rows = {row["tso"]: row for row in csv.DictReader(f)}
    assert float(rows["TSO_A"]["activated_ra_count"]) == 0.0
    assert float(rows["TSO_A"]["ra_activated_model_binary"]) == 2.0
    assert float(rows["TSO_B"]["activated_ra_count"]) == 0.0
    assert float(rows["TSO_B"]["ra_activated_model_binary"]) == 1.0


def test_net_volume_at_the_edge_of_the_tolerance_decides_the_count():
    """Given net volumes 1 % below and 1 % above the named tolerance, When
    the RA counts are extracted, Then only the one above counts as an
    activation (the extractor reads the named constant, not a copy of it)."""
    model, rd_list, bid_list = _solved_model_without_dispatch()
    _force_all_binaries_to_one(model)
    model.rd_volume_upward["BID1"].value = RA_ACTIVATION_NET_VOLUME_TOLERANCE_MW * 0.99
    model.rd_volume_upward["BID3"].value = RA_ACTIVATION_NET_VOLUME_TOLERANCE_MW * 1.01

    results = _extract(model, rd_list, bid_list)

    assert results["TSO_A"]["activated_ra_count"] == 0
    assert results["TSO_B"]["activated_ra_count"] == 1


# ===========================================================================
# Curative RD results
# ===========================================================================

NEED = {b[0]: {"CO1": b[3], "CO2": b[4]} for b in BIDS}


PRICE = {b[0]: b[2] for b in BIDS}


DIRECTION = {b[0]: b[1] for b in BIDS}


def _lists():
    rd_list = [_unit(f"RD_{b[0].removeprefix('BID_')}", "GU") for b in BIDS]
    bid_list = [_bid_curative_rd_results(b[0], f"RD_{b[0].removeprefix('BID_')}", b[1], b[2]) for b in BIDS]
    return rd_list, bid_list


def _rows(per_tso=None):
    model = _solved_model(per_tso)
    rd_list, bid_list = _lists()
    rows = extract_curative_rd_results(model, rd_list, bid_list, REFERENCE, per_tso)
    return model, rows


def test_one_row_per_bid_and_contingency_with_own_direction_volume():
    _model, rows = _rows()
    assert len(rows) == 8
    assert sorted((r["bid_mrid"], r["contingency_mrid"]) for r in rows) == sorted(
        (b, co) for b in NEED for co in ("CO1", "CO2"))
    for r in rows:
        need = NEED[r["bid_mrid"]][r["contingency_mrid"]]
        maximum = max(NEED[r["bid_mrid"]].values())
        assert r["direction"] == DIRECTION[r["bid_mrid"]].value
        assert r["curative_volume_mw"] >= need - 1e-6          # must clear its own contingency
        assert r["curative_volume_mw"] <= maximum + 1e-6       # never above the per-bid max
        assert r["max_curative_volume_mw"] == pytest.approx(maximum, abs=1e-6)
        if need == maximum:                                     # the binding contingency is exact
            assert r["curative_volume_mw"] == pytest.approx(need, abs=1e-6)


def test_inactive_direction_volume_is_not_reported():
    """curative_volume_mw is the variable of the bid's OWN direction: a DOWN bid
    must not report its (zero) upward variable."""
    _model, rows = _rows()
    for r in rows:
        assert r["curative_volume_mw"] > 0.0 or NEED[r["bid_mrid"]][r["contingency_mrid"]] == 0.0


def test_price_and_penalty_cost_per_mw_columns():
    _model, rows = _rows()
    for r in rows:
        assert r["price_eur_mw"] == PRICE[r["bid_mrid"]]
        assert r["penalty_cost_eur_per_mw"] == pytest.approx(PENALTY_FACTOR * REFERENCE)
        assert r["tso"] == "TestTSO" and r["ra_mrid"] == f"RD_{r['bid_mrid'].removeprefix('BID_')}"


def test_per_tso_override_is_used_for_penalty_and_cost():
    _model, rows = _rows({"TestTSO": 3.0})
    assert {r["penalty_cost_eur_per_mw"] for r in rows} == {3.0}
    first = {r["bid_mrid"]: r for r in rows if r["curative_cost_eur"] != 0.0}
    for bid, r in first.items():
        assert r["curative_cost_eur"] == pytest.approx((3.0 + PRICE[bid]) * max(NEED[bid].values()), abs=1e-6)


def test_cost_is_on_the_first_row_of_each_bid_and_sums_to_the_objective():
    model, rows = _rows()
    for bid in NEED:
        bid_rows = sorted((r for r in rows if r["bid_mrid"] == bid), key=lambda r: r["contingency_mrid"])
        assert bid_rows[0]["curative_cost_eur"] == pytest.approx(
            (PENALTY_FACTOR * REFERENCE + PRICE[bid]) * max(NEED[bid].values()), abs=1e-6)
        assert all(r["curative_cost_eur"] == 0.0 for r in bid_rows[1:])
    assert sum(r["curative_cost_eur"] for r in rows) == pytest.approx(pyo.value(model.objective), abs=1e-6)


def test_extractor_returns_empty_without_curative_rd_in_the_model():
    assert extract_curative_rd_results(object(), [], [], REFERENCE) == []


def test_csv_columns_status_and_values(tmp_path):
    _model, rows = _rows()
    path = tmp_path / "results_curative_rd.csv"
    write_curative_rd_results_csv(rows, path, "1030Z", AcVerificationStatus.CONVERGED, "stable")
    with open(path, newline="", encoding=TEXT_ENCODING) as f:
        written = list(csv.DictReader(f))
    assert list(written[0]) == [
        "bid_mrid", "ra_mrid", "tso", "contingency_mrid", "direction", "curative_volume_mw",
        "max_curative_volume_mw", "price_eur_mw", "reservation_price_eur_mw", "penalty_cost_eur_per_mw",
        "curative_cost_eur", "timestamp", "ac_verification_status", "ac_verification_termination_reason",
    ]
    assert len(written) == 8
    assert {r["ac_verification_status"] for r in written} == {AcVerificationStatus.CONVERGED.value}
    assert sum(float(r["curative_cost_eur"]) for r in written) == pytest.approx(1330.0, abs=1e-6)


def test_csv_is_header_only_without_curative_bids(tmp_path):
    path = tmp_path / "results_curative_rd.csv"
    write_curative_rd_results_csv(
        extract_curative_rd_results(object(), [], [], REFERENCE), path, "1030Z",
        AcVerificationStatus.CONVERGED, "stable",
    )
    lines = path.read_text(encoding=TEXT_ENCODING).strip().splitlines()
    assert len(lines) == 1 and lines[0].startswith("bid_mrid,ra_mrid,tso,contingency_mrid,direction")


# ===========================================================================
# Generating units results
# ===========================================================================

REPO_ROOT = Path(__file__).resolve().parents[1]


TOLERANCE_MW = 1e-6


EXPECTED_HEADER = [
    "gu_mrid", "gu_name", "tso", "initial_production_mw", "rd_volume_net_mw", "result_production_mw",
    "rd_cost_eur", "rd_penalty_cost_eur", "timestamp",
    "ac_verification_status", "ac_verification_termination_reason",
]


def _gu(target_p: float, name: str) -> dict:
    return {"target_p": target_p, "max_p": 500.0, "min_p": 0.0, "name": name}


def _solved_three_ra_model(target_p_by_gu=None):
    """RA1 (UP bid) -> GU1 alone; RA2 (DOWN bid) -> GU2 (25 %) and GU3 (75 %).
    BRANCH1 is overloaded by 50 A and RA1 relieves it, RA2 absorbs the
    balance (Σ net injection = 0), so both bids carry volume."""
    target_p_by_gu = target_p_by_gu or {"GU1": 50.0, "GU2": 60.0, "GU3": 70.0}
    rd_list = [_make_rd_unit("RA1", "GU1"), _make_rd_unit("RA2", "GU2"), _make_rd_unit("RA2", "GU3")]
    bid_list = [
        _make_bid("BID1", "RA1", BidDirection.UP, {"1030Z": 100.0}, price_eur_mw=10.0),
        _make_bid("BID2", "RA2", BidDirection.DOWN, {"1030Z": 100.0}, price_eur_mw=5.0),
    ]
    rd_inputs = RdMilpInputs(
        rd_list=rd_list, bid_list=bid_list,
        glsk={"RA1": {"GU1": 1.0}, "RA2": {"GU2": 0.25, "GU3": 0.75}},
        sensitivity_rd_n0_pruned={("BRANCH1", "GU1"): -10.0},
        generator_data={gu: _gu(p, gu) for gu, p in target_p_by_gu.items()},
    )
    model = build_n0_milp_model(
        [_make_ae_generating_units_results("BRANCH1", side=1, patl_ka=1.0)], "1030Z", lf_initial={"BRANCH1": {1: 1050.0}},
        penalty_cost_overload_n0=1000.0, rd_inputs=rd_inputs,
    )
    assert str(pyo.SolverFactory("appsi_highs").solve(model).solver.termination_condition) == "optimal"
    return model, rd_inputs


def _rd_results(model, rd_inputs):
    return extract_rd_results(
        model, rd_list=rd_inputs.rd_list, bid_list=rd_inputs.bid_list, penalty_reference_rd_pra=0.0,
        ac_verification_status=CONVERGED, ac_verification_termination_reason="test",
    )


def _extract_generating_units_results(model, rd_inputs, output_path=None, generator_data=None):
    return extract_results_generating_units(
        model, rd_list=rd_inputs.rd_list, generator_data=generator_data, glsk=rd_inputs.glsk,
        rd_results=_rd_results(model, rd_inputs),
        ac_verification_status=CONVERGED, ac_verification_termination_reason="test",
        timestamp="1030Z", output_path=output_path,
    )


# ---------------------------------------------------------------------------
# baseline travels with the model
# ---------------------------------------------------------------------------

def test_builder_records_the_baseline_target_p_the_model_was_built_on():
    model, _ = _solved_three_ra_model()
    assert model.rd_baseline_target_p_mw == {"GU1": 50.0, "GU2": 60.0, "GU3": 70.0}


def test_extractor_reports_the_models_own_baseline_when_no_generator_data_is_given():
    """The AC loop rebuilds the model on a REFRESHED target_p after each
    applied iteration, so initial_production_mw must be the baseline of the
    model that is being reported, not the original CGM value."""
    refreshed = {"GU1": 90.0, "GU2": 60.0, "GU3": 70.0}
    model, rd_inputs = _solved_three_ra_model(target_p_by_gu=refreshed)

    results = _extract_generating_units_results(model, rd_inputs)

    assert results["GU1"]["initial_production_mw"] == 90.0
    assert results["GU1"]["result_production_mw"] == pytest.approx(90.0 + results["GU1"]["rd_volume_net_mw"])


# ---------------------------------------------------------------------------
# columns
# ---------------------------------------------------------------------------

def test_written_csv_has_timestamp_and_ac_status_columns(tmp_path):
    model, rd_inputs = _solved_three_ra_model()
    out = tmp_path / "results_generating_units.csv"

    _extract_generating_units_results(model, rd_inputs, output_path=out)

    with open(out, newline="", encoding=TEXT_ENCODING) as f:
        rows = list(csv.DictReader(f))
    assert list(rows[0].keys()) == EXPECTED_HEADER
    assert {r["ac_verification_status"] for r in rows} == {CONVERGED.value}
    assert {r["timestamp"] for r in rows} == {"1030Z"}


def test_ac_status_parameters_are_required(tmp_path):
    with pytest.raises(TypeError):
        write_results_generating_units_csv({}, tmp_path / "x.csv")
    with pytest.raises(TypeError):
        extract_results_generating_units(object(), rd_list=[])


# ---------------------------------------------------------------------------
# conservation
# ---------------------------------------------------------------------------

def test_per_ra_sum_over_its_units_equals_the_net_volume_of_its_bids_when_units_are_not_shared():
    model, rd_inputs = _solved_three_ra_model()
    gu_results = _extract_generating_units_results(model, rd_inputs)
    rd_results = _rd_results(model, rd_inputs)

    bid_net_by_ra: dict[str, float] = {}
    for bid_result in rd_results.values():
        bid_net_by_ra[bid_result["ra_mrid"]] = bid_net_by_ra.get(bid_result["ra_mrid"], 0.0) + bid_result["rd_volume_net_mw"]
    assert abs(bid_net_by_ra["RA1"]) > 1.0 and abs(bid_net_by_ra["RA2"]) > 1.0  # both bids carry volume

    for ra_mrid, participation in rd_inputs.glsk.items():
        unit_sum = sum(gu_results[gu]["rd_volume_net_mw"] for gu in participation)
        assert unit_sum == pytest.approx(bid_net_by_ra[ra_mrid], abs=TOLERANCE_MW), ra_mrid
    # and the attribution of cost keeps the total
    assert sum(g["rd_cost_eur"] for g in gu_results.values()) == pytest.approx(
        sum(b["rd_cost_eur"] for b in rd_results.values()), abs=TOLERANCE_MW)


# ---------------------------------------------------------------------------
# pipeline level (shared mock N-X run)
# ---------------------------------------------------------------------------

def _rows_generating_units_results(path: Path) -> list[dict]:
    with open(path, newline="", encoding=TEXT_ENCODING) as f:
        return list(csv.DictReader(f))


def test_pipeline_writes_results_generating_units_and_it_conserves_the_bid_volumes(mock_nx_pipeline_run):
    output_dir = mock_nx_pipeline_run.output_dir
    gu_rows = _rows_generating_units_results(output_dir / "results_generating_units.csv")
    bid_rows = _rows_generating_units_results(output_dir / "results_preventive_rd.csv")
    glsk_rows = _rows_generating_units_results(output_dir / "glsk_resolved.csv")
    summary = {r["metric"]: float(r["value"]) for r in _rows_generating_units_results(output_dir / "results_summary.csv") if r["value"].replace(".", "", 1).replace("-", "", 1).replace("e", "", 1).isdigit()}

    assert gu_rows, "the mock case has generating units with GLSK participation"
    assert list(gu_rows[0].keys()) == EXPECTED_HEADER
    net_by_gu = {r["gu_mrid"]: float(r["rd_volume_net_mw"]) for r in gu_rows}
    for r in gu_rows:
        assert float(r["result_production_mw"]) == pytest.approx(
            float(r["initial_production_mw"]) + float(r["rd_volume_net_mw"]), abs=TOLERANCE_MW)

    # RA -> units from glsk_resolved.csv, RA -> net volume from results_preventive_rd.csv. On
    # the mock case every unit is shared by several RAs, so the per-RA split is not
    # recoverable: compare per connected group (RAs sharing a unit are in one group).
    units_of_ra: dict[str, dict[str, float]] = {}
    for r in glsk_rows:
        if r["gu_mrid"]:
            units_of_ra.setdefault(r["ra_mrid"], {})[r["gu_mrid"]] = float(r["participation_factor"])
    net_of_ra: dict[str, float] = {}
    for r in bid_rows:
        net_of_ra[r["ra_mrid"]] = net_of_ra.get(r["ra_mrid"], 0.0) + float(r["rd_volume_net_mw"])

    group_of: dict[str, str] = {}

    def find(node: str) -> str:
        while group_of.setdefault(node, node) != node:
            group_of[node] = group_of[group_of[node]]
            node = group_of[node]
        return node

    for ra_mrid in net_of_ra:
        for gu in units_of_ra.get(ra_mrid, {}):
            group_of[find("RA:" + ra_mrid)] = find("GU:" + gu)
    ras_in_group: dict[str, list[str]] = {}
    units_in_group: dict[str, set[str]] = {}
    for ra_mrid in net_of_ra:
        if not units_of_ra.get(ra_mrid):
            continue
        root = find("RA:" + ra_mrid)
        ras_in_group.setdefault(root, []).append(ra_mrid)
        units_in_group.setdefault(root, set()).update(units_of_ra[ra_mrid])

    assert len(ras_in_group) >= 2
    moving_groups = 0
    for root, ras in ras_in_group.items():
        bid_net = sum(net_of_ra[ra] for ra in ras)
        unit_net = sum(net_by_gu[gu] for gu in units_in_group[root])
        assert unit_net == pytest.approx(bid_net, abs=TOLERANCE_MW), ras
        moving_groups += abs(bid_net) > 1.0
    assert moving_groups >= 2, "the check must include groups that actually move"

    # whatever the sharing: the volumes of all bids and of all units add up to the same (balanced) total
    assert sum(net_by_gu.values()) == pytest.approx(sum(net_of_ra.values()), abs=TOLERANCE_MW)
    assert sum(float(r["rd_cost_eur"]) for r in gu_rows) == pytest.approx(summary["sum_rd_cost_eur"], abs=1e-6)


# ===========================================================================
# Curative PST results
# ===========================================================================

PENALTY_REFERENCE = 10.0


EXPECTED_HEADER_curative_pst_results_file = [
    "tso", "pst_mrid", "contingency_mrid", "timestamp",
    "curative_delta_taps_up", "curative_delta_taps_down", "curative_delta_taps_net",
    "curative_tap_lower_bound", "curative_tap_upper_bound", "available", "penalty_cost_eur",
    "ac_verification_status", "ac_verification_termination_reason",
]


def _solve_two_psts_two_contingencies(penalty_factor=3.0):
    """CO1: 1050 A on a 1000 A branch, UP_PST relieves 10 A per tap upward, so
    it must move UP 5 taps. CO2: same overload but the sensitivity of DOWN_PST
    has the opposite sign, so it must move DOWN 5 taps. Both PSTs are
    available in both contingencies (UP_PST has no effect in CO2 and DOWN_PST
    none in CO1, so they stay at 0 there)."""
    psts = [
        _make_pst("UP_PST", RAKind.CURATIVE, penalty_factor=penalty_factor),
        _make_pst("DOWN_PST", RAKind.CURATIVE, penalty_factor=penalty_factor),
    ]
    bounds = {"UP_PST": (-7, 9), "DOWN_PST": (-8, 6)}
    pst_inputs = PstMilpInputs(
        pst_list=psts, pst_tap_bounds={}, pst_group_equality_pairs=[], sensitivity_pst_n0_pruned={},
        pst_degrees_per_tap={"UP_PST": 1.0, "DOWN_PST": 1.0}, penalty_reference_pst_pra=PENALTY_REFERENCE,
    )
    availability = {
        (pst, "BRANCH1", co): {"max_curative_taps": 10, "available": True}
        for pst in ("UP_PST", "DOWN_PST") for co in ("CO1", "CO2")
    }
    nx_inputs = NxMilpInputs(
        lf_nx={co: {"BRANCH1": {1: 1050.0}} for co in ("CO1", "CO2")},
        sensitivity_pst_nx={
            "CO1": {("BRANCH1", "UP_PST"): -10.0, ("BRANCH1", "DOWN_PST"): 0.0},
            "CO2": {("BRANCH1", "UP_PST"): 0.0, ("BRANCH1", "DOWN_PST"): 10.0},
        },
        sensitivity_rd_nx={}, penalty_cost_overload_nx_patl=1000.0,
        pst_cra_availability=availability, pst_tap_bounds_curative=bounds,
    )
    model = build_n0_milp_model(
        [_make_ae("BRANCH1")], "1030Z", lf_initial={"BRANCH1": {1: 500.0}},
        penalty_cost_overload_n0=1000.0, pst_inputs=pst_inputs, nx_inputs=nx_inputs,
    )
    assert str(pyo.SolverFactory("appsi_highs").solve(model).solver.termination_condition) == "optimal"
    return model, psts, nx_inputs


def _extract_curative_pst_results_file(model, psts, nx_inputs):
    return extract_curative_pst_delta_results(
        model, psts, nx_inputs.pst_tap_bounds_curative, nx_inputs.pst_cra_availability, PENALTY_REFERENCE,
    )


def test_one_row_per_available_pair_with_deltas_bounds_flag_and_penalty():
    model, psts, nx_inputs = _solve_two_psts_two_contingencies()

    rows = _extract_curative_pst_results_file(model, psts, nx_inputs)

    by_pair = {(r["pst_mrid"], r["contingency_mrid"]): r for r in rows}
    assert sorted(by_pair) == [("DOWN_PST", "CO1"), ("DOWN_PST", "CO2"), ("UP_PST", "CO1"), ("UP_PST", "CO2")]
    up_co1 = by_pair[("UP_PST", "CO1")]
    assert (up_co1["curative_delta_taps_up"], up_co1["curative_delta_taps_down"]) == pytest.approx((5.0, 0.0))
    assert up_co1["curative_delta_taps_net"] == pytest.approx(5.0)
    assert (up_co1["curative_tap_lower_bound"], up_co1["curative_tap_upper_bound"]) == (-7, 9)
    assert up_co1["available"] is True
    assert up_co1["tso"] == "TestTSO"
    assert up_co1["penalty_cost_eur"] == pytest.approx(3.0 * PENALTY_REFERENCE * 5.0)
    down_co2 = by_pair[("DOWN_PST", "CO2")]
    assert (down_co2["curative_delta_taps_up"], down_co2["curative_delta_taps_down"]) == pytest.approx((0.0, 5.0))
    assert down_co2["curative_delta_taps_net"] == pytest.approx(-5.0)
    assert (down_co2["curative_tap_lower_bound"], down_co2["curative_tap_upper_bound"]) == (-8, 6)
    for pair in (("UP_PST", "CO2"), ("DOWN_PST", "CO1")):
        assert by_pair[pair]["curative_delta_taps_net"] == pytest.approx(0.0)
        assert by_pair[pair]["penalty_cost_eur"] == pytest.approx(0.0)


def test_available_flag_is_read_from_the_availability_map():
    """Every pair that has variables is available, so the flag is True; it is
    taken from pst_cra_availability (not hard-coded) and blank without a map."""
    model, psts, nx_inputs = _solve_two_psts_two_contingencies()
    flagged_off = dict(nx_inputs.pst_cra_availability)
    flagged_off[("UP_PST", "BRANCH1", "CO1")] = {"max_curative_taps": 10, "available": False}

    rows = extract_curative_pst_delta_results(
        model, psts, nx_inputs.pst_tap_bounds_curative, flagged_off, PENALTY_REFERENCE,
    )
    by_pair = {(r["pst_mrid"], r["contingency_mrid"]): r["available"] for r in rows}
    assert by_pair[("UP_PST", "CO1")] is False
    assert by_pair[("UP_PST", "CO2")] is True

    no_map = extract_curative_pst_delta_results(
        model, psts, nx_inputs.pst_tap_bounds_curative, None, PENALTY_REFERENCE,
    )
    assert all(r["available"] is None for r in no_map)


def test_row_count_equals_number_of_available_pst_contingency_pairs():
    model, psts, nx_inputs = _solve_two_psts_two_contingencies()
    available_pairs = {
        (pst, co) for (pst, _xne, co), entry in nx_inputs.pst_cra_availability.items() if entry["available"]
    }
    assert len(_extract_curative_pst_results_file(model, psts, nx_inputs)) == len(available_pairs) == 4


def test_penalty_sum_equals_results_pst_curative_cost_and_summary_metric():
    """The per-row penalties add up to the curative_penalty_cost_eur column
    of results_pst.csv (same figures, computed by the existing per-PST
    extractor) and to sum_curative_pst_penalty_cost_eur of results_summary."""
    model, psts, nx_inputs = _solve_two_psts_two_contingencies()

    rows = _extract_curative_pst_results_file(model, psts, nx_inputs)
    per_pst = extract_curative_pst_results(model, psts, PENALTY_REFERENCE)
    summary = extract_results_summary(
        model, objective_value=pyo.value(model.objective), pst_list=psts,
        penalty_reference_pst_pra=PENALTY_REFERENCE,
    )

    row_sum = sum(r["penalty_cost_eur"] for r in rows)
    assert row_sum == pytest.approx(sum(v["curative_penalty_cost_eur"] for v in per_pst.values()))
    assert row_sum == pytest.approx(summary["sum_curative_pst_penalty_cost_eur"])
    assert row_sum == pytest.approx(2 * 3.0 * PENALTY_REFERENCE * 5.0)
    for pst_mrid, totals in per_pst.items():
        assert sum(r["penalty_cost_eur"] for r in rows if r["pst_mrid"] == pst_mrid) == pytest.approx(
            totals["curative_penalty_cost_eur"]
        )


def test_net_equals_up_minus_down_for_every_row():
    model, psts, nx_inputs = _solve_two_psts_two_contingencies()
    rows = _extract_curative_pst_results_file(model, psts, nx_inputs)
    assert len(rows) == 4
    for r in rows:
        assert r["curative_delta_taps_net"] == pytest.approx(r["curative_delta_taps_up"] - r["curative_delta_taps_down"])


def test_rows_of_a_curative_pst_group_agree_with_results_curative_pst_groups():
    """Per group and contingency every member has the same net curative delta in
    results_curative_pst.csv, equal to group_delta_tap of results_curative_pst_groups.csv."""
    model, triples = _solve_group_model({"G1": -10.0, "G2": 0.0, "G3": 0.0})
    psts = _three_psts()
    bounds = {m: (-10, 10) for m in ("G1", "G2", "G3")}
    availability = {(m, "B1", "CO1"): {"max_curative_taps": 10, "available": True} for m in ("G1", "G2", "G3")}

    rows = extract_curative_pst_delta_results(model, psts, bounds, availability, PENALTY_REFERENCE)
    group_rows = extract_curative_pst_group_results(model, triples, psts)

    assert len(group_rows) == 1
    group_delta = group_rows[(GROUP, "CO1")]["group_delta_tap"]
    member_nets = {r["pst_mrid"]: r["curative_delta_taps_net"] for r in rows if r["contingency_mrid"] == "CO1"}
    assert sorted(member_nets) == group_rows[(GROUP, "CO1")]["pst_mrids"]
    assert group_delta == pytest.approx(5.0)
    for pst_mrid, net in member_nets.items():
        assert net == pytest.approx(group_delta), pst_mrid


def test_empty_when_the_model_has_no_curative_pairs(tmp_path):
    assert extract_curative_pst_delta_results(object(), [], {}, {}, PENALTY_REFERENCE) == []
    out = tmp_path / "results_curative_pst.csv"
    write_curative_pst_delta_results_csv([], out, "1030Z", CONVERGED, "test")
    with open(out, newline="", encoding=TEXT_ENCODING) as f:
        assert list(csv.reader(f)) == [EXPECTED_HEADER_curative_pst_results_file]


def test_written_csv_has_the_documented_columns_and_values(tmp_path):
    model, psts, nx_inputs = _solve_two_psts_two_contingencies()
    out = tmp_path / "results_curative_pst.csv"

    write_curative_pst_delta_results_csv(_extract_curative_pst_results_file(model, psts, nx_inputs), out, "1030Z", CONVERGED, "test")

    with open(out, newline="", encoding=TEXT_ENCODING) as f:
        rows = list(csv.DictReader(f))
    assert list(rows[0].keys()) == EXPECTED_HEADER_curative_pst_results_file
    first = next(r for r in rows if (r["pst_mrid"], r["contingency_mrid"]) == ("UP_PST", "CO1"))
    assert float(first["curative_delta_taps_net"]) == pytest.approx(5.0)
    assert first["available"] == "True"
    assert first["timestamp"] == "1030Z"
    assert first["ac_verification_status"] == CONVERGED.value


# ---------------------------------------------------------------------------
# pipeline level (shared mock N-X run)
# ---------------------------------------------------------------------------

def _rows_curative_pst_results_file(path: Path) -> list[dict]:
    with open(path, newline="", encoding=TEXT_ENCODING) as f:
        return list(csv.DictReader(f))


def test_pipeline_writes_results_curative_pst_consistent_with_the_other_files(mock_nx_pipeline_run):
    output_dir = mock_nx_pipeline_run.output_dir
    rows = _rows_curative_pst_results_file(output_dir / "results_curative_pst.csv")
    results_pst_rows = _rows_curative_pst_results_file(output_dir / "results_pst.csv")
    summary = {r["metric"]: r["value"] for r in _rows_curative_pst_results_file(output_dir / "results_summary.csv")}
    availability_rows = _rows_curative_pst_results_file(output_dir / "pst_cra_availability.csv")

    assert rows, "the mock case has curative PSTs"
    assert list(rows[0].keys()) == EXPECTED_HEADER_curative_pst_results_file
    row_sum = sum(float(r["penalty_cost_eur"]) for r in rows)
    assert row_sum == pytest.approx(float(summary["sum_curative_pst_penalty_cost_eur"]), abs=1e-6)
    assert row_sum == pytest.approx(
        sum(float(r["curative_penalty_cost_eur"]) for r in results_pst_rows), abs=1e-6,
    )
    available_pairs = {
        (r["pst_mrid"], r["contingency_mrid"]) for r in availability_rows if r["available"] == "True"
    }
    assert {(r["pst_mrid"], r["contingency_mrid"]) for r in rows} == available_pairs
    assert len(rows) == len(available_pairs)
    for r in rows:
        assert float(r["curative_delta_taps_net"]) == pytest.approx(
            float(r["curative_delta_taps_up"]) - float(r["curative_delta_taps_down"]), abs=1e-9)
        assert float(r["curative_tap_lower_bound"]) <= float(r["curative_tap_upper_bound"])
        assert r["available"] == "True"
    tap_totals = {}
    for r in rows:
        tap_totals[r["pst_mrid"]] = tap_totals.get(r["pst_mrid"], 0.0) + float(r["curative_delta_taps_up"]) + float(r["curative_delta_taps_down"])
    for r in results_pst_rows:
        assert tap_totals.get(r["pst_mrid"], 0.0) == pytest.approx(float(r["curative_tap_change_total"]), abs=1e-6)


# ===========================================================================
# Files written by the mock pipeline run
# ===========================================================================

def _read_rows(path: Path) -> list[dict]:
    with open(path, newline="", encoding=TEXT_ENCODING) as f:
        return list(csv.DictReader(f))


# ---------------------------------------------------------------------------
# glsk_resolved.csv holds ALL RAs of ALL TSOs
# ---------------------------------------------------------------------------

def test_glsk_resolved_csv_holds_every_resolved_ra_of_every_tso(mock_nx_pipeline_run):
    """GLSK is resolved per TSO; glsk_resolved.csv lists every RA that any TSO resolved,
    each row with its TSO."""
    per_tso_results = mock_nx_pipeline_run.records.glsk_results_per_tso
    resolved_ra_mrids = {ra for result in per_tso_results for ra in result}
    assert len(per_tso_results) >= 2, "test needs several TSOs to be meaningful"
    assert len(resolved_ra_mrids) == sum(len(r) for r in per_tso_results)

    rows = _read_rows(mock_nx_pipeline_run.output_dir / "glsk_resolved.csv")

    assert {row["ra_mrid"] for row in rows} == resolved_ra_mrids
    assert all(row["tso"] for row in rows)
    assert len({row["tso"] for row in rows}) == len(per_tso_results)


# ---------------------------------------------------------------------------
# lf_post_n0.csv holds EVERY AC iteration, the final one identifiable
# ---------------------------------------------------------------------------

def _summary_metrics(output_dir: Path) -> dict[str, str]:
    return {row["metric"]: row["value"] for row in _read_rows(output_dir / "results_summary.csv")}


def test_lf_post_n0_holds_every_ac_iteration_up_to_the_summary_iteration_count(mock_nx_pipeline_run):
    """Given an AC loop that ran N iterations, When the pipeline finishes,
    Then lf_post_n0.csv has an ac_iteration column covering 1..N, and the
    maximum equals the ac_iteration_count metric in results_summary.csv."""
    output_dir = mock_nx_pipeline_run.output_dir
    rows = _read_rows(output_dir / "lf_post_n0.csv")
    iteration_count = int(float(_summary_metrics(output_dir)["ac_iteration_count"]))

    iterations_in_file = {int(row["ac_iteration"]) for row in rows}

    assert iteration_count >= 2, "mock case is expected to need more than one AC iteration"
    assert iterations_in_file == set(range(1, iteration_count + 1))
    assert max(iterations_in_file) == iteration_count


def test_lf_post_n0_every_iteration_lists_the_same_branches(mock_nx_pipeline_run):
    rows = _read_rows(mock_nx_pipeline_run.output_dir / "lf_post_n0.csv")
    branches_per_iteration: dict[str, set[str]] = {}
    for row in rows:
        branches_per_iteration.setdefault(row["ac_iteration"], set()).add(row["branch_mrid"])

    branch_sets = list(branches_per_iteration.values())
    assert len(branch_sets) >= 2
    assert all(branch_set == branch_sets[0] for branch_set in branch_sets)
    assert len(rows) == sum(len(s) for s in branch_sets)  # no duplicate rows within an iteration


def test_lf_post_n0_iterations_chain_and_every_solution_is_applied(mock_nx_pipeline_run):
    """The 'before' currents of iteration k+1 are the 'after' currents of
    iteration k. The loop applies every solution before it checks convergence,
    so the converging (last) iteration is applied too and its 'after' currents
    are the load flow of the final state. Only a load-flow failure leaves a
    solution unapplied (covered in the loop tests)."""
    rows = _read_rows(mock_nx_pipeline_run.output_dir / "lf_post_n0.csv")
    by_iteration: dict[int, dict[str, dict]] = {}
    for row in rows:
        by_iteration.setdefault(int(row["ac_iteration"]), {})[row["branch_mrid"]] = row
    last_iteration = max(by_iteration)

    for iteration in sorted(by_iteration):
        if iteration == 1:
            continue
        for branch_mrid, row in by_iteration[iteration].items():
            previous_after = float(by_iteration[iteration - 1][branch_mrid]["i_ka_after"])
            assert float(row["i_ka_before"]) == previous_after

    flags = {
        iteration: {row["solution_applied_to_network"] for row in branch_rows.values()}
        for iteration, branch_rows in by_iteration.items()
    }
    assert all(len(flag_values) == 1 for flag_values in flags.values())  # one flag per iteration
    assert all(flag_values == {"true"} for flag_values in flags.values())
    assert any(
        float(row["i_ka_after"]) != float(row["i_ka_before"]) for row in by_iteration[last_iteration].values()
    ), "the last (converging) iteration must show the applied change, not after == before"


# ===========================================================================
# Lead times
# ===========================================================================

def _rows_output_renames(path: Path) -> list[dict]:
    with open(path, newline="", encoding=TEXT_ENCODING) as f:
        return list(csv.DictReader(f))


# ---------------------------------------------------------------------------
# results_lead_times.csv phase column
# ---------------------------------------------------------------------------

def test_lead_times_csv_separates_preventive_and_curative_rows(mock_nx_pipeline_run):
    output_dir = mock_nx_pipeline_run.output_dir
    lead_time_rows = _rows_output_renames(output_dir / "results_lead_times.csv")
    preventive_rd_rows = _rows_output_renames(output_dir / "results_preventive_rd.csv")

    assert {row["phase"] for row in lead_time_rows} == {"preventive", "curative"}
    preventive_ras = {row["ra_mrid"] for row in preventive_rd_rows}
    for row in lead_time_rows:
        expected = "preventive" if row["ra_mrid"] in preventive_ras else "curative"
        assert row["phase"] == expected, row["bid_mrid"]
    assert sum(1 for row in lead_time_rows if row["phase"] == "preventive") == len(preventive_rd_rows)


def _rd_unit_output_renames(mrid: str, kind: RAKind) -> RDUnit:
    return RDUnit(
        mrid=mrid, name=mrid, tso="T", gu_mrid="G", gu_name="G", available=True, kind=kind,
        initial_p=0.0, max_p=1.0, min_p=0.0, raise_ramp_rate=None, lower_ramp_rate=None,
    )


def _bid_output_renames(mrid: str, ra_mrid: str) -> PowerBid:
    return PowerBid(
        mrid=mrid, ra_mrid=ra_mrid, direction=BidDirection.UP, available_mw={"1030Z": 1.0},
        price_eur_mw=1.0, penalty_factor=0.0, lead_time_h=0.0,
        activation_cost_eur=None, min_energy_mwh=None, max_energy_mwh=None, step_size_mw=None,
    )


def test_extract_lead_time_results_reports_phase_from_the_ra_kind(tmp_path):
    output_path = tmp_path / "results_lead_times.csv"
    results = extract_lead_time_results(
        bid_list=[_bid_output_renames("B1", "RA_P"), _bid_output_renames("B2", "RA_C")],
        timestamp_list=["1030Z"],
        ac_verification_status=AcVerificationStatus.CONVERGED,
        ac_verification_termination_reason="test",
        raart=None,
        timestamp="1030Z",
        output_path=output_path,
        rd_list=[_rd_unit_output_renames("RA_P", RAKind.PREVENTIVE), _rd_unit_output_renames("RA_C", RAKind.CURATIVE)],
    )

    assert results["B1"]["phase"] == "preventive"
    assert results["B2"]["phase"] == "curative"
    assert {row["bid_mrid"]: row["phase"] for row in _rows_output_renames(output_path)} == {
        "B1": "preventive", "B2": "curative",
    }


# ===========================================================================
# AC verification status columns of the result writers
# ===========================================================================

ALL_STATUSES = [
    (AcVerificationStatus.CONVERGED, "remedial action movement and congestion levels stabilized between iterations"),
    (AcVerificationStatus.REVERTED_NON_CONVERGENT, "load flow non-convergent"),
    (AcVerificationStatus.REVERTED_TO_LAST_CONVERGED_STATE,
     "load flow non-convergent - reverted to last converged state"),
    (AcVerificationStatus.MAX_ITERATIONS_REACHED, "max iterations reached"),
    (AcVerificationStatus.CYCLIC_REPETITION, "cyclic repetition of results"),
]


class TestWritePstResultsCsvAcStatus:
    @pytest.mark.parametrize("status,reason", ALL_STATUSES)
    def test_status_and_reason_both_written(self, tmp_path, status, reason):
        pst_results = {
            "pst-1": {
                "pst_name": "p1", "tso": "TSO-A", "current_tap_position": 0,
                "tap_change_result": 5.0, "result_tap_position": 5.0,
                "pst_penalty_factor": 1.0, "penalty_reference_pst_pra": 100.0,
                "effective_penalty_cost_per_tap_eur": 100.0, "penalty_cost_eur": 500.0,
            },
        }
        output_path = tmp_path / "results_pst.csv"
        write_pst_results_csv(
            pst_results, output_path, "1030Z",
            ac_verification_status=status, ac_verification_termination_reason=reason,
        )
        lines = output_path.read_text(encoding=TEXT_ENCODING).splitlines()
        assert "ac_verification_status" in lines[0]
        assert "ac_verification_termination_reason" in lines[0]
        assert status.value in lines[1]
        assert reason in lines[1]

    def test_parameter_is_required_not_optional(self, tmp_path):
        with pytest.raises(TypeError):
            write_pst_results_csv({}, tmp_path / "x.csv", "1030Z")


class TestWriteResultsRdCsvAcStatus:
    @pytest.mark.parametrize("status,reason", ALL_STATUSES)
    def test_status_and_reason_both_written(self, tmp_path, status, reason):
        rd_results = {
            "bid-1": {
                "ra_mrid": "ra-1", "tso": "TSO-A", "rd_volume_net_mw": 10.0,
                "price_eur_mw": 50.0, "rd_penalty_factor": 1.0,
                "penalty_cost_eur": 100.0, "rd_cost_eur": 600.0,
            },
        }
        output_path = tmp_path / "results_preventive_rd.csv"
        write_results_rd_csv(
            rd_results, output_path, "1030Z",
            ac_verification_status=status, ac_verification_termination_reason=reason,
        )
        lines = output_path.read_text(encoding=TEXT_ENCODING).splitlines()
        assert "ac_verification_status" in lines[0]
        assert status.value in lines[1]
        assert reason in lines[1]

    def test_parameter_is_required_not_optional(self, tmp_path):
        with pytest.raises(TypeError):
            write_results_rd_csv({}, tmp_path / "x.csv", "1030Z")


class TestWriteResultsRaCountCsvAcStatus:
    @pytest.mark.parametrize("status,reason", ALL_STATUSES)
    def test_status_and_reason_both_written(self, tmp_path, status, reason):
        ra_count_results = {
            "TSO-A": {
                "activated_ra_count": 2.0, "limit_per_timestamp": None,
                "slack_per_timestamp": None, "limit_per_timeframe": None,
                "slack_per_timeframe": None, "ra_activated_model_binary": 3.0,
            },
        }
        output_path = tmp_path / "results_preventive_rd_ra_count.csv"
        write_results_ra_count_csv(
            ra_count_results, output_path, "1030Z",
            ac_verification_status=status, ac_verification_termination_reason=reason,
        )
        lines = output_path.read_text(encoding=TEXT_ENCODING).splitlines()
        assert "ac_verification_status" in lines[0]
        assert status.value in lines[1]

    def test_parameter_is_required_not_optional(self, tmp_path):
        with pytest.raises(TypeError):
            write_results_ra_count_csv({}, tmp_path / "x.csv", "1030Z")


class TestWriteResultsRaGroupsCsvAcStatus:
    @pytest.mark.parametrize("status,reason", ALL_STATUSES)
    def test_status_and_reason_both_written(self, tmp_path, status, reason):
        ra_group_results = {
            "group-1": {
                "total_volume_upward_mw": 15.0, "max_volume_upward_mw": 40.0,
                "total_volume_downward_mw": 0.0, "max_volume_downward_mw": 20.0,
            },
        }
        output_path = tmp_path / "results_preventive_rd_ra_groups.csv"
        write_results_ra_groups_csv(
            ra_group_results, output_path, "1030Z",
            ac_verification_status=status, ac_verification_termination_reason=reason,
        )
        lines = output_path.read_text(encoding=TEXT_ENCODING).splitlines()
        assert "ac_verification_status" in lines[0]
        assert status.value in lines[1]

    def test_parameter_is_required_not_optional(self, tmp_path):
        with pytest.raises(TypeError):
            write_results_ra_groups_csv({}, tmp_path / "x.csv", "1030Z")


class TestWriteResultsLeadTimesCsvAcStatus:
    @pytest.mark.parametrize("status,reason", ALL_STATUSES)
    def test_status_and_reason_both_written(self, tmp_path, status, reason):
        lead_time_results = {
            "bid-1": {
                "ra_mrid": "ra-1", "bid_lead_time_hours": 2.0,
                "radp": 3, "earliest_usable_timestamp": "1130Z",
            },
        }
        output_path = tmp_path / "results_lead_times.csv"
        write_results_lead_times_csv(
            lead_time_results, output_path, "1030Z",
            ac_verification_status=status, ac_verification_termination_reason=reason,
        )
        lines = output_path.read_text(encoding=TEXT_ENCODING).splitlines()
        assert "ac_verification_status" in lines[0]
        assert status.value in lines[1]

    def test_parameter_is_required_not_optional(self, tmp_path):
        with pytest.raises(TypeError):
            write_results_lead_times_csv({}, tmp_path / "x.csv", "1030Z")


class TestRevertedRunIsHonestlyFlagged:
    """A REVERTED_NON_CONVERGENT run's CSV marks the failure while keeping the proposed
    (never applied) values for diagnostics."""

    def test_reverted_run_keeps_proposed_values_but_flags_them(self, tmp_path):
        pst_results = {
            "pst-1": {
                "pst_name": "p1", "tso": "TSO-A", "current_tap_position": 6,
                "tap_change_result": -26.0, "result_tap_position": -20.0,
                "pst_penalty_factor": 1.0, "penalty_reference_pst_pra": 100.0,
                "effective_penalty_cost_per_tap_eur": 100.0, "penalty_cost_eur": 2600.0,
            },
        }
        output_path = tmp_path / "results_pst.csv"
        write_pst_results_csv(
            pst_results, output_path, "1030Z",
            ac_verification_status=AcVerificationStatus.REVERTED_NON_CONVERGENT,
            ac_verification_termination_reason="load flow non-convergent",
        )
        lines = output_path.read_text(encoding=TEXT_ENCODING).splitlines()
        # Proposed values preserved (diagnostic value kept, per the
        # explicit design decision — NOT zeroed out).
        assert "-26.0" in lines[1]
        assert "-20.0" in lines[1]
        # But unmistakably flagged as never actually applied.
        assert "REVERTED_NON_CONVERGENT" in lines[1]


# ===========================================================================
# Cyclic repetition status
# ===========================================================================

CYCLIC_REASON = "cyclic repetition of results"


# ================================================================ (f) status mapping and outputs
class TestCyclicRepetitionStatus:
    def test_the_termination_reason_maps_to_its_own_status(self):
        assert AcVerificationStatus["CYCLIC_REPETITION"] is AcVerificationStatus.from_termination_reason(CYCLIC_REASON)

    def test_an_unknown_reason_is_still_rejected(self):
        with pytest.raises(ValueError):
            AcVerificationStatus.from_termination_reason("cyclic repetition")

    @pytest.mark.parametrize("writer_name", [
        "write_pst_results_csv", "write_results_rd_csv", "write_results_ra_count_csv",
        "write_results_ra_groups_csv", "write_results_lead_times_csv",
    ])
    def test_status_and_reason_are_written_by_every_result_writer(self, tmp_path, writer_name):
        from post_milp import n0_results_export as export
        status = AcVerificationStatus["CYCLIC_REPETITION"]
        payloads = {
            "write_pst_results_csv": {"pst-1": {
                "pst_name": "p1", "tso": "T", "current_tap_position": 0, "original_tap_position": 0,
                "tap_change_result": 5.0, "result_tap_position": 5.0, "pst_penalty_factor": 1.0,
                "penalty_reference_pst_pra": 100.0, "effective_penalty_cost_per_tap_eur": 100.0,
                "penalty_cost_eur": 500.0,
            }},
            "write_results_rd_csv": {"bid-1": {
                "ra_mrid": "ra-1", "tso": "T", "rd_volume_net_mw": 10.0, "price_eur_mw": 50.0,
                "rd_penalty_factor": 1.0, "penalty_cost_eur": 100.0, "rd_cost_eur": 600.0,
            }},
            "write_results_ra_count_csv": {"T": {
                "activated_ra_count": 2.0, "limit_per_timestamp": None, "slack_per_timestamp": None,
                "limit_per_timeframe": None, "slack_per_timeframe": None, "ra_activated_model_binary": 3.0,
            }},
            "write_results_ra_groups_csv": {"g": {
                "total_volume_upward_mw": 15.0, "max_volume_upward_mw": 40.0,
                "total_volume_downward_mw": 0.0, "max_volume_downward_mw": 20.0,
            }},
            "write_results_lead_times_csv": {"bid-1": {
                "ra_mrid": "ra-1", "bid_lead_time_hours": 2.0, "radp": 3, "earliest_usable_timestamp": "1130Z",
            }},
        }
        path = tmp_path / "out.csv"
        getattr(export, writer_name)(
            payloads[writer_name], path, "1030Z",
            ac_verification_status=status, ac_verification_termination_reason=CYCLIC_REASON,
        )
        lines = path.read_text(encoding=TEXT_ENCODING).splitlines()
        header, row = lines[0].split(","), lines[1].split(",")
        assert row[header.index("ac_verification_status")] == "CYCLIC_REPETITION"
        assert row[header.index("ac_verification_termination_reason")] == CYCLIC_REASON


# ===========================================================================
# Completeness iterations file
# ===========================================================================

# ---------------------------------------------------------------------------
# write_completeness_iterations_csv
# ---------------------------------------------------------------------------

def test_write_completeness_iterations_csv(tmp_path):
    iteration_log = [
        {"completeness_iteration": 0, "new_constraints_added": 0, "total_nx_constraints": 10},
        {"completeness_iteration": 1, "new_constraints_added": 2, "total_nx_constraints": 12},
    ]
    output_path = tmp_path / "results_completeness_iterations.csv"
    write_completeness_iterations_csv(iteration_log, output_path)
    lines = output_path.read_text(encoding=TEXT_ENCODING).splitlines()
    assert lines[0] == "completeness_iteration,new_constraints_added,total_nx_constraints"
    assert lines[1] == "0,0,10"
    assert lines[2] == "1,2,12"


# ===========================================================================
# Completeness limit flag and iteration history column
# ===========================================================================

@pytest.mark.parametrize("flag, expected", [(True, "True"), (False, "False")])
def test_results_summary_carries_the_completeness_limit_flag_as_last_metric(tmp_path, flag, expected):
    import csv
    import pyomo.environ as pyo
    import helpers as R
    from post_milp.n0_results_export import extract_results_summary
    model, pst_inputs, rd_inputs = R._all_terms_scenario()
    out = tmp_path / "results_summary.csv"
    extract_results_summary(
        model, objective_value=pyo.value(model.objective), pst_list=pst_inputs.pst_list,
        penalty_reference_pst_pra=R.REFERENCE_PST, output_path=out, completeness_limit_reached=flag,
    )
    rows = list(csv.reader(open(out, newline="", encoding=TEXT_ENCODING)))
    assert rows[-1] == ["completeness_iteration_limit_reached", expected]


def test_summary_without_the_flag_argument_has_no_such_row(tmp_path):
    import csv
    import pyomo.environ as pyo
    import helpers as R
    from post_milp.n0_results_export import extract_results_summary
    model, pst_inputs, rd_inputs = R._all_terms_scenario()
    out = tmp_path / "results_summary.csv"
    extract_results_summary(model, objective_value=pyo.value(model.objective), pst_list=pst_inputs.pst_list,
                            penalty_reference_pst_pra=R.REFERENCE_PST, output_path=out)
    assert "completeness_iteration_limit_reached" not in [r[0] for r in csv.reader(open(out, newline="", encoding=TEXT_ENCODING))]


def test_the_iteration_history_file_has_the_lost_contingencies_column(tmp_path):
    import csv
    from post_milp.n0_results_export import ITERATION_HISTORY_COLUMNS, write_iteration_history_csv
    assert "nx_contingencies_lost_at_refresh" in ITERATION_HISTORY_COLUMNS
    out = tmp_path / "h.csv"
    write_iteration_history_csv([{"solve_index": 1, "nx_contingencies_lost_at_refresh": 2}], out)
    assert list(csv.DictReader(open(out, newline="", encoding=TEXT_ENCODING)))[0]["nx_contingencies_lost_at_refresh"] == "2"


# ===========================================================================
# Remaining overload count with a scanned branch in the model
# ===========================================================================

def test_remaining_overload_count_counts_secured_branches_only_when_a_scanned_branch_is_modelled():
    import pyomo.environ as pyo
    from data_model import AEType
    from helpers import _make_ae_mb_scanned, _make_pst_mb_scanned
    from milp.milp_builder import PstMilpInputs, build_n0_milp_model
    from milp.milp_solver import solve_n0_milp_model
    ae = [_make_ae_mb_scanned("SEC", AEType.SECURED, 1, 1.0), _make_ae_mb_scanned("SCAN", AEType.SCANNED, 1, 1.0)]
    pst = _make_pst_mb_scanned("PST1")
    pst_inputs = PstMilpInputs(
        pst_list=[pst], pst_tap_bounds={"PST1": (0, 0)}, pst_group_equality_pairs=[],
        sensitivity_pst_n0_pruned={("SEC", "PST1"): 5.0, ("SCAN", "PST1"): 5.0},
        pst_degrees_per_tap={"PST1": 1.5}, penalty_reference_pst_pra=10.0,
    )
    # SEC: 1200 A against 1000 A, no tap headroom -> overloaded; SCAN is in branch_ids too
    model = build_n0_milp_model(ae, "1030Z", {"SEC": {1: 1200.0}, "SCAN": {1: 500.0}}, 1000.0, pst_inputs=pst_inputs)
    assert "SCAN" in set(model.branch_ids)
    solve_n0_milp_model(model, [pst], "1030Z", 10.0)
    summary = n0_results_export.extract_results_summary(
        model, objective_value=float(pyo.value(model.objective)), pst_list=[pst], penalty_reference_pst_pra=10.0,
    )
    assert summary["remaining_overload_count"] == 1
