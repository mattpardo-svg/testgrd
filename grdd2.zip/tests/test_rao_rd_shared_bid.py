"""Shared-bid redispatch: redispatch RAs whose key has several generating units with participation factors.

Most tests here are CHARACTERISATION tests: they record what the current code does (findings in
docs/archive/ncp_alignment_progress.md), they do not assert an intended behaviour. The data and the sections:
(0) scope of the redispatch balance (preventive: whole network; curative: per contingency, any TSO),
(1) parser and glsk_resolver on the use-case variants of mock_data/ncp_dataset.py (build_shared_bid_ncp),
(2) the MILP on small synthetic models with the real generators and limits of the cases,
(3) the data warning "no net movement possible" (glsk_resolver.warn_curative_no_net_movement),
(4) full pipeline runs (pst+rd, ac_iterative, N-X on) of the variants.

Variants (on the standard-form mock P, the RD RAs of the generators involved removed; up p>0, down p<0):
  A  Espheim, preventive, bid route, Breed SM 0.6 / Philo SM 0.4, bids 100 MW at 90 EUR/MW
  A_strategy  the same with the strategy route
  B_preventive  Galia, preventive, strategy route, GA-G1 0.5 / GA-G2 0.3 / GA-G3 0.2, bids 150 MW at 60 EUR/MW
  C_preventive  as B_preventive with bids of 200 MW (GA-G2 reaches Pmax at 45 MW, i.e. at a total of 150 MW)
  D_espheim  Espheim, the four generators at four substations: two preventive downs with 3 and 2 units (bid route) and
     two curative downs with 3 and 2 units (strategy route, linked to the 5 Espheim contingencies), the curative ups of
     CabinCrk and Claytor of P kept as balance partners. (The Svedala version of D, units at one substation, stays below
     as a model-level example only: test_rao_shared_bid_d_*.)
"""
import csv
import logging
import re
import zipfile

import pyomo.environ as pyo
import pytest

import helpers
from mock_data import ncp_dataset
from data_model import AEType, AssessedElement, BidDirection, PowerBid, RAKind, RDUnit
from milp.milp_builder import NxMilpInputs, RdMilpInputs, build_n0_milp_model
from pre_milp import glsk_resolver, ncp_parser

TIME = "1030Z"
BREED, PHILO = "045868c0-c766-11e1-8775-005056c00008", "04859346-c766-11e1-8775-005056c00008"
GA_G1, GA_G2, GA_G3 = (
    "9c3b8f97-7972-477d-9dc8-87365cc0ad0e", "2844585c-0d35-488d-a449-685bcd57afbf", "1dc9afba-23b5-41a0-8540-b479ed8baf4b")
CABINCRK, CLAYTOR = "045868c1-c766-11e1-8775-005056c00008", "046bf0c4-c766-11e1-8775-005056c00008"
SV_G1, SV_G2, SV_G3, SV_G4 = (
    "4e0971d4-db4c-441d-a9f2-c88d4c04f60b", "5584a48f-9ca2-4727-a32d-19a2147d2a0a",
    "2a35657f-a1a8-45dc-911e-e71535b35d87", "a768e8a2-14b3-45a0-919c-86156a1c66c2")
# network generators of the CGM: generator id -> (target P, Pmin, Pmax) in MW
LIMITS = {
    BREED: (419.412, 300.0, 600.0), PHILO: (190.083, 100.0, 400.0),
    GA_G1: (705.637, 300.0, 1000.0), GA_G2: (180.0, 130.0, 225.0), GA_G3: (180.0, 130.0, 225.0),
    SV_G1: (492.812, 0.0, 1350.0), SV_G2: (687.31, 0.0, 1350.0), SV_G3: (172.161, 0.0, 715.0), SV_G4: (172.161, 0.0, 715.0),
    CABINCRK: (444.458, 300.0, 600.0), CLAYTOR: (37.2711, 0.0, 160.0),
}
UNIT_DATA = {g: {"name": g, "target_p": p, "min_p": lo, "max_p": hi, "connected": True} for g, (p, lo, hi) in LIMITS.items()}
FACTORS_A = {BREED: 0.6, PHILO: 0.4}
FACTORS_GALIA = {GA_G1: 0.5, GA_G2: 0.3, GA_G3: 0.2}
# the factors of the new RAs of the cases, by RA name
FACTORS_BY_RA = {
    "PRA_RD_ES_SHARED3_DOWN": {BREED: 0.5, PHILO: 0.3, CLAYTOR: 0.2},
    "PRA_RD_ES_SHARED2_DOWN": {BREED: 0.6, PHILO: 0.4},
    "CRA_RD_ES_SHARED3_DOWN": {BREED: 0.5, PHILO: 0.3, CLAYTOR: 0.2},
    "CRA_RD_ES_SHARED2_DOWN": {BREED: 0.6, PHILO: 0.4},
}
for _name in ("PRA_RD_ES_BREED_PHILO_UP", "PRA_RD_ES_BREED_PHILO_DOWN"):
    FACTORS_BY_RA[_name] = FACTORS_A
for _name in ("PRA_RD_GA_G123_UP", "PRA_RD_GA_G123_DOWN"):
    FACTORS_BY_RA[_name] = FACTORS_GALIA
PAIR_CASES = ["A", "A_strategy", "B_preventive", "C_preventive"]
PENALTY_REFERENCE = 100.0            # penalty_reference_rd_pra of config/rao_config.yaml
FORBIDDEN_IN_THE_LOG = ("deprecated", "sign of p disagrees", "IGNORED", "no BaseTimeSeries.interpolationKind",
                        "GLSK is empty", "no net movement")


def _approx(value):
    return pytest.approx(value, abs=1e-6)


# ---------------------------------------------------------------------------
# (1) parser and glsk_resolver
# ---------------------------------------------------------------------------

@pytest.fixture(scope="module")
def zips(tmp_path_factory):
    folder = tmp_path_factory.mktemp("shared_bid_zips")
    return {case: ncp_dataset.build_shared_bid_ncp(folder / f"{case}.zip", case) for case in ncp_dataset.SHARED_BID_CASES}


def _unit_map():
    """{CIM GeneratingUnit: [network generator]} of the five generators of the cases."""
    wanted = set(LIMITS)
    return {unit: gens for unit, gens in helpers.mock_generators_by_unit().items() if wanted & set(gens)}


def _parse(zip_path, case, tmp_path, factor_edit=None):
    """(rd_list, bid_list, glsk) of the TSO file of the case, read by parse_rd_units and resolve_glsk."""
    tso = ncp_dataset.SHARED_BID_CASES[case]["tso"]
    with zipfile.ZipFile(zip_path) as zf:
        ra = tmp_path / f"{tso}_RA.xml"
        sis = tmp_path / f"{tso}_SIS.xml"
        ra.write_bytes(zf.read(f"{tso}_RA.xml"))
        text = zf.read(f"{tso}_SIS.xml").decode("utf-8")
        for old, new in (factor_edit or {}).items():
            assert old in text
            text = text.replace(old, new)
        sis.write_text(text, encoding="utf-8")
    by_unit = _unit_map()
    rd_list, bid_list = ncp_parser.parse_rd_units(
        ra, sis, tso, [TIME], UNIT_DATA, price_timestamp=TIME, generators_by_unit=by_unit)
    pair_mrids = {item["mrid"] for item in ncp_dataset.shared_bid_ras(case)}
    rd_list = [rd for rd in rd_list if str(rd.mrid) in pair_mrids]
    glsk = glsk_resolver.resolve_glsk(
        sis, rd_list, tso, set(UNIT_DATA), TIME, generators_by_unit=by_unit, ra_path=ra)
    return rd_list, [b for b in bid_list if str(b.ra_mrid) in pair_mrids], glsk


@pytest.mark.parametrize("case", PAIR_CASES + ["D_espheim"])
def test_rao_shared_bid_each_ra_has_one_bid_with_the_size_price_and_direction_of_the_variant(zips, tmp_path, case):
    """Characterisation: parse_rd_units reads every new RA with one RDUnit per unit of its key and one bid; the size is
    |p|, up p>0 and down p<0."""
    rd_list, bid_list, _glsk = _parse(zips[case], case, tmp_path, None)
    for ra in ncp_dataset.shared_bid_ras(case):
        units = [rd for rd in rd_list if str(rd.mrid) == ra["mrid"]]
        assert {rd.gu_mrid for rd in units} == set(FACTORS_BY_RA[ra["name"]])
        assert all(rd.kind == (RAKind.PREVENTIVE if ra["kind"] == "preventive" else RAKind.CURATIVE) for rd in units)
        bids = [b for b in bid_list if str(b.ra_mrid) == ra["mrid"]]
        assert len(bids) == 1
        assert bids[0].direction == (BidDirection.UP if ra["direction"] == "up" else BidDirection.DOWN)
        assert bids[0].available_mw[TIME] == ra["volume"] and bids[0].price_eur_mw == ra["price"]


@pytest.mark.parametrize("case", PAIR_CASES + ["D_espheim"])
def test_rao_shared_bid_glsk_gives_the_factors_of_the_variant_per_ra(zips, tmp_path, case):
    """Characterisation: resolve_glsk gives every new RA exactly the factors of the variant (sum 1), whether the keys
    come from the bid route or the strategy route."""
    _rd, _bids, glsk = _parse(zips[case], case, tmp_path, None)
    for ra in ncp_dataset.shared_bid_ras(case):
        assert glsk[ra["mrid"]] == pytest.approx(FACTORS_BY_RA[ra["name"]], abs=1e-12)
        assert sum(glsk[ra["mrid"]].values()) == pytest.approx(1.0, abs=1e-12)


def test_rao_shared_bid_the_bid_route_and_the_strategy_route_resolve_to_the_same_shares(zips, tmp_path):
    """The A pair by the bid route and by the strategy route: the same RAs, the same generators, the same shares."""
    (tmp_path / "bid").mkdir()
    (tmp_path / "strategy").mkdir()
    _r1, _b1, by_bid = _parse(zips["A"], "A", tmp_path / "bid", None)
    _r2, _b2, by_strategy = _parse(zips["A_strategy"], "A_strategy", tmp_path / "strategy", None)
    assert by_bid == by_strategy


def test_rao_shared_bid_weights_that_do_not_sum_to_one_are_normalised_with_a_warning(zips, tmp_path, caplog):
    """Characterisation: raw factors 3 and 2 are relative weights; resolve_glsk normalises them to 0.6 / 0.4 and warns
    that their sum is not 1 (the MILP itself does not normalise, see the MILP section)."""
    edit = {"<nc:ParticipationFactorTimePoint.participationFactor>0.6<": "<nc:ParticipationFactorTimePoint.participationFactor>3<",
            "<nc:ParticipationFactorTimePoint.participationFactor>0.4<": "<nc:ParticipationFactorTimePoint.participationFactor>2<"}
    with caplog.at_level(logging.WARNING):
        _rd, _bids, glsk = _parse(zips["A"], "A", tmp_path, edit)
    for factors in glsk.values():
        assert factors == pytest.approx(FACTORS_A, abs=1e-12)
    assert any("sum to 5" in r.getMessage() and "not 1" in r.getMessage() for r in caplog.records)


# ---------------------------------------------------------------------------
# (2) the MILP on small synthetic models: real generators and limits, one overloaded branch
# ---------------------------------------------------------------------------

def _ae(patl_ka=1.0):
    return AssessedElement(
        mrid="AE_BRANCH1", name="AE", tso="TestTSO", ae_type=AEType.SECURED, branch_mrid="BRANCH1",
        secured_for_region=None, scanned_for_region=None, exclusion_reason=None,
        patl_ka={TIME: patl_ka}, branch_side=1)


def _unit(ra, gu, kind, link=(), factor=1.0, limits=LIMITS):
    p, lo, hi = limits[gu] if gu in limits else (500.0, 0.0, 2000.0)
    return RDUnit(mrid=ra, name=ra, tso="TestTSO", gu_mrid=gu, gu_name=gu, available=True, kind=kind,
                  initial_p=p, max_p=hi, min_p=lo, raise_ramp_rate=None, lower_ramp_rate=None,
                  penalty_factor=factor, linked_contingency_mrids=list(link))


def _bid(mrid, ra, direction, mw, price):
    return PowerBid(mrid=mrid, ra_mrid=ra, direction=direction, available_mw={TIME: mw}, price_eur_mw=price,
                    penalty_factor=0.0, lead_time_h=0.0, activation_cost_eur=None, min_energy_mwh=None,
                    max_energy_mwh=None, step_size_mw=None)


UP, DOWN = BidDirection.UP, BidDirection.DOWN
HEADROOM_SYMMETRIC = {"X1": (400.0, 300.0, 500.0), "X2": (400.0, 300.0, 500.0)}


def _shared_model(direction, bid_mw, weights, limits=None, overload_a=300.0, price=60.0, curative=False,
                  partner=True, pair=False):
    """One shared bid (BID_SH, `direction`, bid_mw, price) of RA_SH on the units of `weights` ({unit: factor}) with
    `limits` ({unit: (target, Pmin, Pmax)}, default LIMITS), BRANCH1 (PATL 1000 A) loaded 1000 + overload_a A, every
    unit relieving it by 1 A/MW up (down: increases it, so a down bid relieves a branch loaded the other way: the
    sign of the sensitivity follows the direction). A free balance partner in the opposite direction on GU_BAL.
    curative: the RA is curative under CO1 (loading in N-X, none in N-0), else preventive. pair: both the up and the
    down RA with the same key, no partner (the lone pair)."""
    lim = {**LIMITS, **(limits or {})}
    kind = RAKind.CURATIVE if curative else RAKind.PREVENTIVE
    link = ["CO1"] if curative else []
    units = list(weights)
    rd_list = [_unit("RA_SH", units[0], kind, link, 1.0, lim)]
    rd_list += [_unit(f"RA_{u}", u, kind, link, 1.0, lim) for u in units[1:]]
    bids = [_bid("BID_SH", "RA_SH", direction, bid_mw, price)]
    glsk = {"RA_SH": dict(weights), **{f"RA_{u}": {u: 1.0} for u in units[1:]}}
    if pair:
        other = DOWN if direction == UP else UP
        rd_list.append(_unit("RA_SH2", units[0], kind, link, 1.0, lim))
        bids.append(_bid("BID_SH2", "RA_SH2", other, bid_mw, price))
        glsk["RA_SH2"] = dict(weights)
    elif partner:
        other = DOWN if direction == UP else UP
        rd_list.append(_unit("RD_PARTNER", "GU_BAL", kind, link, 0.0, lim))
        bids.append(_bid("BID_PARTNER", "RD_PARTNER", other, 2000.0, 0.0))
        glsk["RD_PARTNER"] = {"GU_BAL": 1.0}
    sensitivity = -1.0 if direction == UP else 1.0
    data = {u: {"target_p": lim[u][0], "min_p": lim[u][1], "max_p": lim[u][2], "connected": True} for u in units}
    data["GU_BAL"] = {"target_p": 500.0, "min_p": 0.0, "max_p": 2000.0, "connected": True}
    rd_inputs = RdMilpInputs(
        rd_list=rd_list, bid_list=bids, glsk=glsk,
        sensitivity_rd_n0_pruned={} if curative else {("BRANCH1", u): sensitivity for u in units},
        generator_data=data, penalty_reference_rd_pra=PENALTY_REFERENCE)
    nx_inputs = None
    n0_load = 1000.0 + overload_a
    if curative:
        n0_load = 500.0
        nx_inputs = NxMilpInputs(
            lf_nx={"CO1": {"BRANCH1": {1: 1000.0 + overload_a}}}, sensitivity_pst_nx={},
            sensitivity_rd_nx={"CO1": {("BRANCH1", u): sensitivity for u in units}},
            penalty_cost_overload_nx_patl=1000.0)
    model = build_n0_milp_model(
        [_ae()], TIME, lf_initial={"BRANCH1": {1: n0_load}}, penalty_cost_overload_n0=1000.0,
        rd_inputs=rd_inputs, nx_inputs=nx_inputs)
    assert str(pyo.SolverFactory("appsi_highs").solve(model).solver.termination_condition) == "optimal"
    return model


def _preventive_result(model, direction, weights):
    volume = pyo.value(model.rd_volume_upward["BID_SH"] if direction == UP else model.rd_volume_downward["BID_SH"])
    return volume, {u: pyo.value(model.rd_net_injection_g[u]) for u in weights}


@pytest.mark.parametrize("direction, bid_mw, total", [
    (UP, 150.0, 150.0),       # GA-G2: 0.3 x 150 = 45 MW = its up headroom exactly
    (UP, 200.0, 150.0),       # the bid is larger than GA-G2 allows: 45 / 0.3 = 150 MW
    (DOWN, 150.0, 150.0),     # GA-G2 down headroom is 50 MW: 0.3 x 150 = 45
    (DOWN, 200.0, 50.0 / 0.3),  # GA-G2 down headroom 50 MW / 0.3 = 166.67 MW
])
def test_rao_shared_bid_milp_moves_each_unit_by_its_factor_and_stops_at_the_first_unit_limit(direction, bid_mw, total):
    """Characterisation, accepted behaviour for the limit rows (DECISIONS 119): the preventive MILP moves every unit by exactly
    factor x volume (a hard row Pmin <= P + factor x volume <= Pmax per unit); when one unit reaches its limit the total
    volume stops there (the bid is not used up and the share is NOT passed to the other units of the key)."""
    model = _shared_model(direction, bid_mw, FACTORS_GALIA)
    volume, moves = _preventive_result(model, direction, FACTORS_GALIA)
    assert volume == _approx(total)
    sign = 1.0 if direction == UP else -1.0
    for unit, factor in FACTORS_GALIA.items():
        assert moves[unit] == _approx(sign * factor * volume)
    assert sum(moves.values()) == _approx(sign * volume)
    target, lo, hi = LIMITS[GA_G2]
    if volume < bid_mw - 1e-6:       # limited by the unit limit, not by the bid
        assert target + moves[GA_G2] == _approx(hi if direction == UP else lo)


def test_rao_shared_bid_milp_up_and_down_are_symmetric_for_symmetric_limits():
    """With the same headroom up and down, the up and the down shared bid move the same absolute volumes per unit."""
    weights = {"X1": 0.6, "X2": 0.4}
    results = {}
    for direction in (UP, DOWN):
        model = _shared_model(direction, 300.0, weights, limits=HEADROOM_SYMMETRIC)
        results[direction] = _preventive_result(model, direction, weights)
    assert results[UP][0] == _approx(results[DOWN][0])
    for unit in weights:
        assert results[UP][1][unit] == _approx(-results[DOWN][1][unit])
    assert results[UP][1]["X1"] == _approx(0.6 * results[UP][0]) and results[UP][1]["X2"] == _approx(0.4 * results[UP][0])


def test_rao_shared_bid_milp_cost_is_penalty_plus_price_per_mw_of_the_total_volume():
    """Characterisation of the cost: (penalty factor x penalty_reference_rd_pra + price) x TOTAL bid volume, not a price
    per generator: 100 A over, 1 A/MW, volume 100 MW, (1.0 x 100 + 60) x 100 = 16000 EUR (the partner is free)."""
    model = _shared_model(UP, 150.0, FACTORS_GALIA, overload_a=100.0)
    volume, moves = _preventive_result(model, UP, FACTORS_GALIA)
    assert volume == _approx(100.0)
    assert pyo.value(model.objective) == pytest.approx((1.0 * PENALTY_REFERENCE + 60.0) * 100.0, abs=1e-6)
    # each unit carries factor x the same price per MW: the unit shares of the cost add up to the total
    assert sum((PENALTY_REFERENCE + 60.0) * abs(m) for m in moves.values()) == pytest.approx(16000.0, abs=1e-6)


def test_rao_shared_bid_milp_does_not_normalise_factors_that_do_not_sum_to_one():
    """Characterisation: milp_builder only checks factor >= 0. Raw weights 3 and 2 (resolve_glsk would have normalised
    them) move the units by 3 x and 2 x the volume. The pipeline always goes through resolve_glsk, so this is a
    precondition of the MILP, not a defect."""
    weights = {GA_G1: 3.0, GA_G2: 2.0}
    model = _shared_model(UP, 100.0, weights, overload_a=40.0)
    volume, moves = _preventive_result(model, UP, weights)
    assert moves[GA_G1] == _approx(3.0 * volume) and moves[GA_G2] == _approx(2.0 * volume)


@pytest.mark.parametrize("direction, bid_mw, total", [(UP, 150.0, 150.0), (UP, 200.0, 150.0), (DOWN, 200.0, 50.0 / 0.3)])
def test_rao_shared_bid_milp_curative_with_a_partner_has_the_same_split_and_limit(direction, bid_mw, total):
    """Characterisation, accepted behaviour for the limit rows (DECISIONS 119): a curative shared bid with a balance partner under
    the contingency moves the units by factor x the maximum volume and stops at the first unit limit, as the
    preventive one (per-unit Pmin/Pmax rows on the maxima, CORNET-4614)."""
    model = _shared_model(direction, bid_mw, FACTORS_GALIA, curative=True)
    if direction == UP:
        volume = pyo.value(model.curative_rd_volume_upward["BID_SH", "CO1"])
        maximum = pyo.value(model.max_curative_rd_volume_upward["BID_SH"])
    else:
        volume = pyo.value(model.curative_rd_volume_downward["BID_SH", "CO1"])
        maximum = pyo.value(model.max_curative_rd_volume_downward["BID_SH"])
    assert volume == _approx(total) and maximum == _approx(total)
    sign = 1.0 if direction == UP else -1.0
    for unit, factor in FACTORS_GALIA.items():
        assert pyo.value(model.curative_rd_net_injection_g[unit, "CO1"]) == _approx(sign * factor * total)


def test_rao_shared_bid_milp_a_lone_curative_pair_on_the_same_key_cannot_move():
    """Characterisation (CORNET-574, the curative balance of one contingency sums to 0): the up and the down RA of the
    pair (the dropped curative variants B and C) share one key, so their volumes must be equal and cancel on every unit; with an overload to relieve the
    pair still moves nothing and the overload stays. A curative shared bid needs a partner on other units."""
    model = _shared_model(UP, 150.0, FACTORS_GALIA, curative=True, pair=True)
    for unit in FACTORS_GALIA:
        assert pyo.value(model.curative_rd_net_injection_g[unit, "CO1"]) == _approx(0.0)
    assert pyo.value(model.nx_patl_overload_slack["BRANCH1", "CO1"]) == _approx(300.0)


# ---------------------------------------------------------------------------
# (3) full pipeline runs
# ---------------------------------------------------------------------------

RUN_CASES = ["A", "A_strategy", "B_preventive", "C_preventive", "D_espheim"]


@pytest.fixture(scope="module")
def runs(tmp_path_factory):
    """{case: output directory} of one run per variant (pst+rd, ac_iterative, N-X on)."""
    result = {"P": helpers.run_pipeline_on_fixture_inputs(
        tmp_path_factory.mktemp("shared_P") / "run", helpers._MOCK_NX_NCP_ZIP, enable_nx_analysis=True,
        ra_types=("pst", "rd"), calculation_mode="ac_iterative").output_dir}
    for case in RUN_CASES:
        work = tmp_path_factory.mktemp(f"shared_{case}")
        ncp = ncp_dataset.build_shared_bid_ncp(work / "ncp.zip", case)
        result[case] = helpers.run_pipeline_on_fixture_inputs(
            work / "run", ncp, enable_nx_analysis=True, ra_types=("pst", "rd"), calculation_mode="ac_iterative").output_dir
    return result


def _rows(output_dir, name):
    with open(output_dir / name, newline="", encoding="utf-8") as handle:
        return list(csv.DictReader(handle))


def _ra_row(output_dir, case, direction):
    mrid = ncp_dataset.shared_bid_ra_pair(case)[direction]["mrid"]
    rows = [r for r in _rows(output_dir, "results_preventive_rd.csv") if r["ra_mrid"] == mrid]
    assert len(rows) == 1
    return rows[0]


def _unit_rows(output_dir):
    return {r["gu_mrid"]: r for r in _rows(output_dir, "results_generating_units.csv")}


@pytest.mark.parametrize("case", RUN_CASES)
def test_rao_shared_bid_glsk_resolved_csv_shows_the_factors_of_the_variant(runs, case):
    """glsk_resolved.csv lists, for every new RA, exactly the generators and factors of the variant (sum 1)."""
    rows = _rows(runs[case], "glsk_resolved.csv")
    for item in ncp_dataset.shared_bid_ras(case):
        shares = {r["gu_mrid"]: float(r["participation_factor"]) for r in rows if r["ra_mrid"] == item["mrid"]}
        assert shares == pytest.approx(FACTORS_BY_RA[item["name"]], abs=1e-12)
        assert sum(shares.values()) == pytest.approx(1.0, abs=1e-12)


@pytest.mark.parametrize("case", ["P"] + RUN_CASES)
def test_rao_shared_bid_runs_log_no_warning_about_the_ncp_form(runs, case):
    """The run logs of P and the variants have no deprecated-form, sign, ignored-RA, missing-interpolation, empty-GLSK
    or "no net movement" line."""
    lines = (runs[case] / "run_log.txt").read_text(encoding="utf-8", errors="replace").splitlines()
    # P carries 8 countertrade RAs; with ra_types pst+rd each is reported once as not used (the variants are built on
    # the base without countertrade)
    countertrade = [line for line in lines if "nc:CountertradeRemedialAction" in line and "IGNORED" in line]
    assert len(countertrade) == (8 if case == "P" else 0)
    assert all("countertrade is not in ra_types" in line and "shift key" not in line for line in countertrade)
    text = "\n".join(line for line in lines if line not in countertrade)
    for word in FORBIDDEN_IN_THE_LOG:
        assert word not in text, word


def test_rao_shared_bid_a_down_ra_is_activated_and_each_generator_moves_its_factor_of_the_total(runs):
    """A (bid route, preventive): the down RA is used up to its bid (-100 MW): Breed -60, Philo -40; cost
    (1.0 x 100 + 90) x 100 = 19000 EUR in total (penalty 10000 + price 9000), shared 60 / 40 over the units; the RD moves
    of all units add up to 0 (balance)."""
    out = runs["A"]
    down, up = _ra_row(out, "A", "down"), _ra_row(out, "A", "up")
    assert float(down["rd_volume_net_mw"]) == _approx(-100.0) and float(up["rd_volume_net_mw"]) == _approx(0.0)
    assert float(down["rd_cost_eur"]) == _approx((1.0 * PENALTY_REFERENCE + 90.0) * 100.0)
    assert float(down["penalty_cost_eur"]) == _approx(1.0 * PENALTY_REFERENCE * 100.0)
    units = _unit_rows(out)
    assert float(units[BREED]["rd_volume_net_mw"]) == _approx(-60.0) and float(units[PHILO]["rd_volume_net_mw"]) == _approx(-40.0)
    assert float(units[BREED]["rd_cost_eur"]) == _approx(190.0 * 60.0) and float(units[PHILO]["rd_cost_eur"]) == _approx(190.0 * 40.0)
    assert float(units[BREED]["result_production_mw"]) == _approx(419.412 - 60.0)
    assert sum(float(r["rd_volume_net_mw"]) for r in units.values()) == _approx(0.0)


def test_rao_shared_bid_a_by_the_strategy_route_gives_identical_results(runs):
    """A and A_strategy differ only in the route to the keys: the RD results of the RAs, the generating units and the
    summary agree."""
    for name, key in (("results_preventive_rd.csv", "ra_mrid"), ("results_generating_units.csv", "gu_mrid")):
        left = {r[key]: r for r in _rows(runs["A"], name)}
        right = {r[key]: r for r in _rows(runs["A_strategy"], name)}
        assert left.keys() == right.keys()
        for k in left:
            for column in ("rd_volume_net_mw", "rd_cost_eur", "price_eur_mw", "rd_penalty_cost_eur", "penalty_cost_eur",
                           "initial_production_mw", "result_production_mw"):
                if column in left[k]:
                    assert float(left[k][column]) == pytest.approx(float(right[k][column]), abs=1e-6), (name, k, column)
    summary = {r["metric"]: r["value"] for r in _rows(runs["A"], "results_summary.csv")}
    summary_s = {r["metric"]: r["value"] for r in _rows(runs["A_strategy"], "results_summary.csv")}
    assert float(summary["sum_rd_cost_eur"]) == pytest.approx(float(summary_s["sum_rd_cost_eur"]), abs=1e-6)
    assert float(summary["objective_value"]) == pytest.approx(float(summary_s["objective_value"]), abs=1e-3)


def test_rao_shared_bid_b_preventive_up_ra_is_used_up_to_its_bid_with_the_third_unit_on_its_limit(runs):
    """B_preventive: the up RA is used up to its bid, 150 MW: GA-G1 +75, GA-G2 +45 (exactly its up headroom, Pmax 225),
    GA-G3 +30; cost (100 + 60) x 150 = 24000 EUR (penalty 15000), shared 0.5 / 0.3 / 0.2 over the units."""
    out = runs["B_preventive"]
    up = _ra_row(out, "B_preventive", "up")
    assert float(up["rd_volume_net_mw"]) == _approx(150.0)
    assert float(up["rd_cost_eur"]) == _approx((PENALTY_REFERENCE + 60.0) * 150.0)
    assert float(up["penalty_cost_eur"]) == _approx(PENALTY_REFERENCE * 150.0)
    units = _unit_rows(out)
    for gen, move in ((GA_G1, 75.0), (GA_G2, 45.0), (GA_G3, 30.0)):
        assert float(units[gen]["rd_volume_net_mw"]) == _approx(move)
        assert float(units[gen]["rd_cost_eur"]) == _approx(160.0 * move)
    assert float(units[GA_G2]["result_production_mw"]) == _approx(225.0)
    assert sum(float(r["rd_volume_net_mw"]) for r in units.values()) == _approx(0.0)


def test_rao_shared_bid_c_preventive_stops_at_the_first_unit_limit_and_leaves_the_rest_of_the_bid_unused(runs):
    """Case C as a preventive RA, accepted behaviour (DECISIONS 119): bids of 200 MW, GA-G2 reaches Pmax 225 at +45 MW, i.e. at a
    total of 150 MW. The code uses 150 MW (75 / 45 / 30), the other 50 MW of the bid stay unused and are not moved to
    the other units; the result equals that of the 150 MW bid."""
    out = runs["C_preventive"]
    up = _ra_row(out, "C_preventive", "up")
    assert float(up["rd_volume_net_mw"]) == _approx(150.0)
    assert float(up["rd_volume_net_mw"]) < ncp_dataset.shared_bid_ra_pair("C_preventive")["up"]["volume"]
    units = _unit_rows(out)
    for gen, move in ((GA_G1, 75.0), (GA_G2, 45.0), (GA_G3, 30.0)):
        assert float(units[gen]["rd_volume_net_mw"]) == _approx(move)
    assert float(units[GA_G2]["result_production_mw"]) == _approx(225.0)
    b = _ra_row(runs["B_preventive"], "B_preventive", "up")
    assert float(up["rd_cost_eur"]) == _approx(float(b["rd_cost_eur"]))


# ---------------------------------------------------------------------------
# (0) scope of the redispatch balance (characterisation, round 2): small models with several TSOs
# ---------------------------------------------------------------------------

def _network(ras, sens, *, n0_load=1000.0, nx=None):
    """A small model with one overloaded branch BRANCH1 (PATL 1000 A). ras: dicts name, tso, kind ("preventive" /
    "curative"), links (curative: contingencies, [] = acts in all), excluded, direction (UP / DOWN), mw, price,
    weights {unit: factor}. sens: {unit: A/MW on BRANCH1 for an upward move} (N-0, and in every contingency of nx).
    n0_load: A in N-0. nx: {contingency: A on BRANCH1} or None. Penalty factor 1.0 and reference 100 as in the config."""
    rd_list, bids, glsk, units = [], [], {}, {}
    for ra in ras:
        weights = ra["weights"]
        first = next(iter(weights))
        kind = RAKind.CURATIVE if ra["kind"] == "curative" else RAKind.PREVENTIVE
        unit = _unit(ra["name"], first, kind, ra.get("links", ()), ra.get("penalty", 1.0))
        unit.tso = ra["tso"]
        unit.excluded_contingency_mrids = list(ra.get("excluded", ()))
        rd_list.append(unit)
        bids.append(_bid(f"BID_{ra['name']}", ra["name"], ra["direction"], ra["mw"], ra["price"]))
        glsk[ra["name"]] = dict(weights)
        for gu in weights:
            units[gu] = LIMITS[gu] if gu in LIMITS else (500.0, 0.0, 2000.0)
    for gu in list(units):
        if not any(r.gu_mrid == gu for r in rd_list):
            dummy = _unit(f"DUMMY_{gu}", gu, rd_list[0].kind, rd_list[0].linked_contingency_mrids, 0.0)
            rd_list.append(dummy)
            glsk[dummy.mrid] = {gu: 1.0}
    rd_inputs = RdMilpInputs(
        rd_list=rd_list, bid_list=bids, glsk=glsk,
        sensitivity_rd_n0_pruned={} if nx else {("BRANCH1", u): s for u, s in sens.items()},
        generator_data={u: {"target_p": p, "min_p": lo, "max_p": hi, "connected": True} for u, (p, lo, hi) in units.items()},
        penalty_reference_rd_pra=PENALTY_REFERENCE)
    nx_inputs = None
    if nx:
        n0_load = 500.0
        nx_inputs = NxMilpInputs(
            lf_nx={c: {"BRANCH1": {1: load}} for c, load in nx.items()}, sensitivity_pst_nx={},
            sensitivity_rd_nx={c: {("BRANCH1", u): s for u, s in sens.items()} for c in nx},
            penalty_cost_overload_nx_patl=1000.0)
    model = build_n0_milp_model(
        [_ae()], TIME, lf_initial={"BRANCH1": {1: n0_load}}, penalty_cost_overload_n0=1000.0,
        rd_inputs=rd_inputs, nx_inputs=nx_inputs)
    assert str(pyo.SolverFactory("appsi_highs").solve(model).solver.termination_condition) == "optimal"
    return model


def _ra(name, tso, kind, direction, mw, weights, price=40.0, links=(), excluded=()):
    return dict(name=name, tso=tso, kind=kind, direction=direction, mw=mw, price=price, weights=weights,
                links=list(links), excluded=list(excluded))


def test_rao_balance_scope_preventive_is_one_row_over_the_whole_network_not_per_tso():
    """Characterisation (step 0): the preventive RD balance is ONE hard row, sum over ALL generating units of the model
    of the preventive moves = 0 (rd_balancing_n0). It has no TSO and no bidding zone: an up bid of TSO T1 is balanced
    by a down bid of TSO T2 (T1 has no down bid at all), and the row holds variables of both bids."""
    from pyomo.core.expr.visitor import identify_variables
    model = _network(
        [_ra("RA_UP", "T1", "preventive", UP, 200.0, {"U1": 1.0}), _ra("RA_DN", "T2", "preventive", DOWN, 200.0, {"U2": 1.0}, price=0.0)],
        {"U1": -1.0, "U2": 0.0}, n0_load=1050.0)
    assert pyo.value(model.rd_volume_upward["BID_RA_UP"]) == _approx(50.0)
    assert pyo.value(model.rd_volume_downward["BID_RA_DN"]) == _approx(50.0)
    names = {v.name for v in identify_variables(model.rd_balancing_n0.body)}
    assert {"rd_volume_upward[BID_RA_UP]", "rd_volume_downward[BID_RA_DN]"} <= names


def test_rao_balance_scope_curative_is_per_contingency_over_the_rd_ras_of_any_tso():
    """Characterisation (step 0): the curative balance is one hard row per contingency over every curative RD RA acting
    there, whatever its TSO: a Svedala down bid linked to CO1 is balanced by an up bid of another TSO linked to CO1."""
    model = _network(
        [_ra("RA_DN", "Svedala", "curative", DOWN, 200.0, {"S1": 1.0}, links=["CO1"]),
         _ra("RA_UP", "Galia", "curative", UP, 200.0, {"G1": 1.0}, links=["CO1"])],
        {"S1": 1.0, "G1": 0.0}, nx={"CO1": 1050.0})
    assert sorted(model.curative_rd_balancing.keys()) == ["CO1"]
    assert pyo.value(model.curative_rd_volume_downward["BID_RA_DN", "CO1"]) == _approx(50.0)
    assert pyo.value(model.curative_rd_volume_upward["BID_RA_UP", "CO1"]) == _approx(50.0)


def test_rao_balance_scope_a_curative_ra_without_a_link_acts_in_every_contingency():
    """Characterisation (step 0): an RA with no contingency link acts in every contingency of the N-X results (here CO1 and
    CO2) and balances the linked down RA in both."""
    model = _network(
        [_ra("RA_DN", "Svedala", "curative", DOWN, 200.0, {"S1": 1.0}, links=["CO1", "CO2"]),
         _ra("RA_UP", "Galia", "curative", UP, 200.0, {"G1": 1.0})],
        {"S1": 1.0, "G1": 0.0}, nx={"CO1": 1050.0, "CO2": 1030.0})
    assert sorted(model.curative_rd_balancing.keys()) == ["CO1", "CO2"]
    for co, mw in (("CO1", 50.0), ("CO2", 30.0)):
        assert pyo.value(model.curative_rd_volume_downward["BID_RA_DN", co]) == _approx(mw)
        assert pyo.value(model.curative_rd_volume_upward["BID_RA_UP", co]) == _approx(mw)


def test_rao_balance_scope_a_curative_ra_linked_to_another_contingency_does_not_balance():
    """Characterisation (step 0): the up RA is linked to CO2 only, so it does not balance the down RA of CO1: under CO1
    nothing moves and the overload stays."""
    model = _network(
        [_ra("RA_DN", "Svedala", "curative", DOWN, 200.0, {"S1": 1.0}, links=["CO1"]),
         _ra("RA_UP", "Galia", "curative", UP, 200.0, {"G1": 1.0}, links=["CO2"])],
        {"S1": 1.0, "G1": 0.0}, nx={"CO1": 1050.0, "CO2": 900.0})
    assert pyo.value(model.curative_rd_volume_downward["BID_RA_DN", "CO1"]) == _approx(0.0)
    assert pyo.value(model.nx_patl_overload_slack["BRANCH1", "CO1"]) == _approx(50.0)


# ---------------------------------------------------------------------------
# case D on small models: the real Svedala generators, factors, prices and links
# ---------------------------------------------------------------------------

def test_rao_shared_bid_d_preventive_ups_move_each_unit_by_its_factor_of_each_bid_and_cost_the_sum():
    """D, preventive: SHARED3_UP (150 MW, 40) on G1 0.5 / G2 0.3 / G3 0.2 and SHARED2_UP (100 MW, 45) on G3 0.6 / G4 0.4,
    all four units relieving the branch by 1 A/MW, 250 A over: both bids are used up. G3 is in both bids and moves the
    sum (0.2 x 150 + 0.6 x 100 = 90). Cost (100 + 40) x 150 + (100 + 45) x 100 = 35500. The balance is a down move
    of another unit (here GU_BAL, a free partner)."""
    model = _network(
        [_ra("PRA_UP3", "Svedala", "preventive", UP, 150.0, {SV_G1: 0.5, SV_G2: 0.3, SV_G3: 0.2}, price=40.0),
         _ra("PRA_UP2", "Svedala", "preventive", UP, 100.0, {SV_G3: 0.6, SV_G4: 0.4}, price=45.0),
         dict(_ra("PRA_DN", "Other", "preventive", DOWN, 2000.0, {"GU_BAL": 1.0}, price=0.0), penalty=0.0)],
        {SV_G1: -1.0, SV_G2: -1.0, SV_G3: -1.0, SV_G4: -1.0, "GU_BAL": 0.0}, n0_load=1250.0)
    assert pyo.value(model.rd_volume_upward["BID_PRA_UP3"]) == _approx(150.0)
    assert pyo.value(model.rd_volume_upward["BID_PRA_UP2"]) == _approx(100.0)
    moves = {u: pyo.value(model.rd_net_injection_g[u]) for u in (SV_G1, SV_G2, SV_G3, SV_G4, "GU_BAL")}
    assert moves[SV_G1] == _approx(75.0) and moves[SV_G2] == _approx(45.0)
    assert moves[SV_G3] == _approx(90.0) and moves[SV_G4] == _approx(40.0)
    assert moves["GU_BAL"] == _approx(-250.0)
    assert pyo.value(model.objective) == pytest.approx(35500.0, abs=1e-5)


def test_rao_shared_bid_d_curative_downs_are_balanced_by_the_kept_curative_ups():
    """D, curative under CO1 / CO2: the kept single-unit ups of G1 and G2 (600 MW, 40) balance the shared downs
    SHARED3_DOWN (G1 0.4 / G2 0.4 / G3 0.2) and SHARED2_DOWN (G3 0.5 / G4 0.5). A 40 A overload under CO1, relieved by
    G3 and G4 only (1 A/MW): SHARED2_DOWN is the cheaper way (40 MW, G3 -20, G4 -20) and the ups together move +40."""
    links = ["CO1", "CO2"]
    model = _network(
        [_ra("CRA_UP_G1", "Svedala", "curative", UP, 600.0, {SV_G1: 1.0}, links=links),
         _ra("CRA_UP_G2", "Svedala", "curative", UP, 600.0, {SV_G2: 1.0}, links=links),
         _ra("CRA_DN3", "Svedala", "curative", DOWN, 150.0, {SV_G1: 0.4, SV_G2: 0.4, SV_G3: 0.2}, links=links),
         _ra("CRA_DN2", "Svedala", "curative", DOWN, 100.0, {SV_G3: 0.5, SV_G4: 0.5}, price=45.0, links=links)],
        {SV_G1: 0.0, SV_G2: 0.0, SV_G3: 1.0, SV_G4: 1.0}, nx={"CO1": 1040.0, "CO2": 1000.0})
    down2 = pyo.value(model.curative_rd_volume_downward["BID_CRA_DN2", "CO1"])
    down3 = pyo.value(model.curative_rd_volume_downward["BID_CRA_DN3", "CO1"])
    ups = pyo.value(model.curative_rd_volume_upward["BID_CRA_UP_G1", "CO1"]) + pyo.value(model.curative_rd_volume_upward["BID_CRA_UP_G2", "CO1"])
    assert down2 == _approx(40.0) and down3 == _approx(0.0) and ups == _approx(40.0)
    assert pyo.value(model.curative_rd_net_injection_g[SV_G3, "CO1"]) == _approx(-20.0)
    assert pyo.value(model.curative_rd_net_injection_g[SV_G4, "CO1"]) == _approx(-20.0)
    assert sum(pyo.value(model.curative_rd_net_injection_g[u, "CO1"]) for u in (SV_G1, SV_G2, SV_G3, SV_G4)) == _approx(0.0)
    assert pyo.value(model.nx_patl_overload_slack["BRANCH1", "CO1"]) == _approx(0.0)


# ---------------------------------------------------------------------------
# (3) the data warning "no net movement possible" (glsk_resolver.warn_curative_no_net_movement)
# ---------------------------------------------------------------------------

def _curative_ra(name, direction, weights, links=(), excluded=(), tso="T", kind=RAKind.CURATIVE, mw=100.0):
    unit = _unit(name, next(iter(weights)), kind, links, 1.0)
    unit.tso = tso
    unit.excluded_contingency_mrids = list(excluded)
    return unit, _bid(f"BID_{name}", name, direction, mw, 10.0), dict(weights)


def _check(ras, contingencies=("CO1", "CO2")):
    from types import SimpleNamespace
    rd_list = [r[0] for r in ras]
    bid_list = [r[1] for r in ras]
    glsk = {r[0].mrid: r[2] for r in ras}
    cos = [SimpleNamespace(mrid=c, name=f"name of {c}", tso="T") for c in contingencies]
    return glsk_resolver.warn_curative_no_net_movement(rd_list, bid_list, glsk, cos, TIME)


def test_rao_no_net_movement_warns_for_a_sole_up_and_down_pair_on_the_same_key(caplog):
    """Data warning: the only up and the only down curative RA of a contingency have the same normalised key, so the
    balance forces equal volumes that cancel on every unit. One warning per contingency, naming it and the RAs."""
    ras = [_curative_ra("RA_UP", UP, {"X1": 0.6, "X2": 0.4}, ["CO1"]), _curative_ra("RA_DN", DOWN, {"X2": 0.4, "X1": 0.6}, ["CO1"])]
    with caplog.at_level(logging.WARNING):
        found = _check(ras)
    assert [f["contingency"] for f in found] == ["CO1"]
    messages = [r.getMessage() for r in caplog.records if "no net movement" in r.getMessage()]
    assert len(messages) == 1
    assert "CO1" in messages[0] and "name of CO1" in messages[0] and "RA_UP" in messages[0] and "RA_DN" in messages[0]
    assert "same key" in messages[0]


def test_rao_no_net_movement_does_not_warn_when_the_keys_differ():
    ras = [_curative_ra("RA_UP", UP, {"X1": 1.0}, ["CO1"]), _curative_ra("RA_DN", DOWN, {"X2": 1.0}, ["CO1"])]
    assert _check(ras) == []


def test_rao_no_net_movement_does_not_warn_when_a_partner_of_another_tso_has_another_key():
    """The balance is over every curative RD RA acting in the contingency, whatever its TSO."""
    ras = [_curative_ra("RA_UP", UP, {"X1": 0.5, "X2": 0.5}, ["CO1"], tso="T1"),
           _curative_ra("RA_DN", DOWN, {"X1": 0.5, "X2": 0.5}, ["CO1"], tso="T1"),
           _curative_ra("RA_DN_OTHER", DOWN, {"Y1": 1.0}, ["CO1"], tso="T2")]
    assert _check(ras) == []


@pytest.mark.parametrize("direction, word", [(UP, "only up"), (DOWN, "only down")])
def test_rao_no_net_movement_warns_when_only_one_direction_acts(direction, word, caplog):
    ras = [_curative_ra("RA_1", direction, {"X1": 1.0}, ["CO1"]), _curative_ra("RA_2", direction, {"X2": 1.0}, ["CO1"])]
    with caplog.at_level(logging.WARNING):
        found = _check(ras)
    assert [f["contingency"] for f in found] == ["CO1"] and word in found[0]["reason"]
    assert any(word in r.getMessage() for r in caplog.records)


def test_rao_no_net_movement_an_ra_without_a_link_acts_in_every_contingency_and_exclusions_count():
    """An unlinked pair on one key is a problem in every contingency; when the down RA excludes CO2 only the up RA acts
    there, which is the one-direction case."""
    ras = [_curative_ra("RA_UP", UP, {"X1": 1.0}), _curative_ra("RA_DN", DOWN, {"X1": 1.0}, excluded=["CO2"])]
    found = {f["contingency"]: f["reason"] for f in _check(ras)}
    assert sorted(found) == ["CO1", "CO2"]
    assert "same key" in found["CO1"] and "only up" in found["CO2"]


def test_rao_no_net_movement_ignores_preventive_ras_and_ras_without_a_key():
    pair = [_curative_ra("RA_UP", UP, {"X1": 1.0}, kind=RAKind.PREVENTIVE), _curative_ra("RA_DN", DOWN, {"X1": 1.0}, kind=RAKind.PREVENTIVE)]
    assert _check(pair) == []
    # an RA without a key moves nothing, so the other direction alone is the one-direction case
    keyless = _curative_ra("RA_UP", UP, {"X1": 1.0}, ["CO1"])
    other = _curative_ra("RA_DN", DOWN, {"X1": 1.0}, ["CO1"])
    other = (other[0], other[1], {})
    assert [f["contingency"] for f in _check([keyless, other])] == ["CO1"]


def test_rao_no_net_movement_one_warning_per_contingency_not_per_ra(caplog):
    ras = [_curative_ra("RA_UP", UP, {"X1": 1.0}), _curative_ra("RA_DN", DOWN, {"X1": 1.0})]
    with caplog.at_level(logging.WARNING):
        found = _check(ras)
    assert len(found) == 2
    assert len([r for r in caplog.records if "no net movement" in r.getMessage()]) == 2


SPLIT_P = "PRA_RD_ES_SHARED3_DOWN", "PRA_RD_ES_SHARED2_DOWN"
KEPT_CURATIVE_UPS = {"88835dad-c29e-55ec-94d8-d1bfd0923d75", "dffebacc-af23-5704-980c-0db6e5c97f8c"}   # CRA_RD_ES_CABINCRK_UP / CLAYTOR_UP of P


def test_rao_shared_bid_d_espheim_preventive_downs_move_each_unit_by_its_factors_and_cost_the_formula(runs):
    """D_espheim, full run: both preventive downs are used up to their bids (-60 and -40 MW). Breed, Philo and Claytor move
    -54 / -34 / -12 MW = 0.5 x 60 + 0.6 x 40, 0.3 x 60 + 0.4 x 40, 0.2 x 60 (Breed and Philo are in both bids). Cost of each RA
    (penalty factor 1.0 x 100 + price) x its volume; the cost of a unit is its share of both. The preventive downs are balanced
    by the preventive ups of the other TSOs (no Espheim up RA moves), all RD moves add up to 0."""
    out = runs["D_espheim"]
    ras = {r["name"]: r for r in ncp_dataset.shared_bid_ras("D_espheim")}
    rows = {r["ra_mrid"]: r for r in _rows(out, "results_preventive_rd.csv")}
    d3, d2 = rows[ras["PRA_RD_ES_SHARED3_DOWN"]["mrid"]], rows[ras["PRA_RD_ES_SHARED2_DOWN"]["mrid"]]
    assert float(d3["rd_volume_net_mw"]) == _approx(-60.0) and float(d2["rd_volume_net_mw"]) == _approx(-40.0)
    assert float(d3["rd_cost_eur"]) == _approx((PENALTY_REFERENCE + 85.0) * 60.0)
    assert float(d2["rd_cost_eur"]) == _approx((PENALTY_REFERENCE + 90.0) * 40.0)
    units = _unit_rows(out)
    for gen, move in ((BREED, -54.0), (PHILO, -34.0), (CLAYTOR, -12.0), (CABINCRK, 0.0)):
        assert float(units[gen]["rd_volume_net_mw"]) == _approx(move)
    assert float(units[BREED]["rd_cost_eur"]) == _approx(185.0 * 30.0 + 190.0 * 24.0)
    assert float(units[PHILO]["rd_cost_eur"]) == _approx(185.0 * 18.0 + 190.0 * 16.0)
    assert float(units[CLAYTOR]["rd_cost_eur"]) == _approx(185.0 * 12.0)
    others = [r for r in rows.values() if r["tso"] != "TSO-Espheim" and float(r["rd_volume_net_mw"]) > 1e-6]
    assert others and sum(float(r["rd_volume_net_mw"]) for r in others) > 0
    assert not [r for r in rows.values() if r["tso"] == "TSO-Espheim" and float(r["rd_volume_net_mw"]) > 1e-6]
    assert sum(float(r["rd_volume_net_mw"]) for r in units.values()) == _approx(0.0)


def test_rao_shared_bid_d_espheim_curative_downs_are_balanced_by_the_kept_curative_ups_of_p(runs):
    """D_espheim, full run: both curative downs (3 and 2 units, strategy route) are activated; CRA_RD_ES_SHARED2_DOWN up to its
    bid (40 MW). In every contingency they are balanced by the curative ups of CabinCrk and Claytor kept from P (different keys):
    the volumes of the downs add up to the volumes of the two ups. Cost per RA: (penalty reference 100 + the reservation price,
    here the energy price) x the largest volume over the contingencies."""
    out = runs["D_espheim"]
    ras = {r["name"]: r for r in ncp_dataset.shared_bid_ras("D_espheim")}
    down_bids = {ras[n]["bid"]: ras[n] for n in ("CRA_RD_ES_SHARED3_DOWN", "CRA_RD_ES_SHARED2_DOWN")}
    rows = _rows(out, "results_curative_rd.csv")
    by_co = {}
    for r in rows:
        if r["bid_mrid"] in down_bids:
            by_co.setdefault(r["contingency_mrid"], {"down": 0.0, "up": 0.0})["down"] += float(r["curative_volume_mw"])
        elif r["ra_mrid"] in KEPT_CURATIVE_UPS:
            by_co.setdefault(r["contingency_mrid"], {"down": 0.0, "up": 0.0})["up"] += float(r["curative_volume_mw"])
    assert any(v["down"] > 1.0 for v in by_co.values())
    for co, v in by_co.items():
        assert v["down"] == _approx(v["up"]), co
    for bid, ra in down_bids.items():
        mine = [r for r in rows if r["bid_mrid"] == bid]
        maximum = max(float(r["max_curative_volume_mw"]) for r in mine)
        assert maximum > 1.0, ra["name"]
        # the cost of a bid is written once (on its first contingency row), 0 on the others
        assert sum(float(r["curative_cost_eur"]) for r in mine) == _approx((PENALTY_REFERENCE + ra["price"]) * maximum)
    shared2 = max(float(r["max_curative_volume_mw"]) for r in rows if r["bid_mrid"] == ras["CRA_RD_ES_SHARED2_DOWN"]["bid"])
    assert shared2 == _approx(40.0)
