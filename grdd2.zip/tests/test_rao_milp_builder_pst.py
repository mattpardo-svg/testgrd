"""tests/test_rao_milp_builder_pst.py - tests for the PST blocks of milp_builder.py.

Sections: preventive and curative PST blocks, tap limit per TSO, curative PST penalty, PST kinds, empty tap range.
"""

import pytest
import sys
import pyomo.environ as pyo
import csv
import logging

from data_model import (
    PST,
    RAKind,
    AEType,
    AssessedElement,
    BidDirection,
    PowerBid,
    RDUnit,
    AcVerificationStatus,
)
from pre_milp.pst_bounds import build_pst_tap_bounds
from pre_milp.pst_groups import build_pst_group_equality_pairs
from pathlib import Path
from milp.milp_builder import (
    PstMilpInputs,
    build_n0_milp_model,
    NxMilpInputs,
    RdMilpInputs,
    validate_max_taps_per_tso,
    _get_effective_penalty_costs,
)
from pre_milp.cra_preprocessing import compute_pst_cra_availability, write_pst_cra_availability_csv
from helpers import _make_ae, _make_pst
from post_milp.n0_results_export import (
    extract_curative_pst_results,
    extract_results_summary,
    write_pst_results_csv,
    extract_tso_tap_limit_results,
    write_tso_tap_limit_results_csv,
)
from milp.milp_solver import solve_n0_milp_model
from text_encoding import TEXT_ENCODING  # noqa: E402

REPO_SRC = Path(__file__).resolve().parents[1] / "src" / "rao"


def _make_ae_r110(branch_mrid: str, side: int, patl_ka: float, timestamp: str = "1030Z") -> AssessedElement:
    return AssessedElement(
        mrid=f"AE_{branch_mrid}", name=f"AE {branch_mrid}", tso="TestTSO",
        ae_type=AEType.SECURED, branch_mrid=branch_mrid,
        secured_for_region=None, scanned_for_region=None, exclusion_reason=None,
        patl_ka={timestamp: patl_ka}, branch_side=side,
    )


def _make_pst_r110(mrid: str, tso: str, r0: int = 0) -> PST:
    return PST(
        mrid=mrid, name=mrid, tso=tso, available=True, kind=RAKind.PREVENTIVE,
        penalty_factor=1.0, low_step=-50, high_step=50, r0=r0,
        operating_tap_min=-50, operating_tap_max=50, group_id=None,
    )


def _solve(model):
    result = pyo.SolverFactory("appsi_highs").solve(model)
    assert str(result.solver.termination_condition) in ("optimal", "TerminationCondition.optimal"), (
        f"Expected an optimal solve, got: {result.solver.termination_condition}"
    )
    return model


def test_constraint_blocks_a_combined_move_exceeding_the_per_tso_limit():
    """One TSO with two PSTs strongly and cheaply sensitive to a severely overloaded branch and
    a low max_taps_per_tso: the combined tap movement of that TSO never exceeds the limit,
    although a larger combined move would be cheapest.
    """
    ae_list = [_make_ae_r110("BRANCH1", side=1, patl_ka=1.0)]
    pst_inputs = PstMilpInputs(
        pst_list=[_make_pst_r110("PST1", "TSO-A"), _make_pst_r110("PST2", "TSO-A")],
        pst_tap_bounds={"PST1": (-50, 50), "PST2": (-50, 50)},
        pst_group_equality_pairs=[],
        sensitivity_pst_n0_pruned={("BRANCH1", "PST1"): -20.0, ("BRANCH1", "PST2"): -20.0},
        pst_degrees_per_tap={"PST1": 1.0, "PST2": 1.0},
        penalty_reference_pst_pra=1.0,
        max_taps_per_tso=6,
    )
    # BRANCH1 at 2000 A against a 1000 A PATL: a large move on both PSTs would be cheapest
    # without the per-TSO limit
    model = build_n0_milp_model(
        ae_list, "1030Z", lf_initial={"BRANCH1": {1: 2000.0}},
        penalty_cost_overload_n0=1_000_000.0, pst_inputs=pst_inputs,
    )
    _solve(model)

    total_movement = sum(
        pyo.value(model.tap_change_upward[pst_mrid]) + pyo.value(model.tap_change_downward[pst_mrid])
        for pst_mrid in ["PST1", "PST2"]
    )
    assert total_movement <= 6 + 1e-6, (
        f"the per-TSO tap limit should cap combined TSO-A movement at 6, got {total_movement}"
    )


def test_constraint_sums_upward_and_downward_movement_together():
    """Two PSTs of one TSO, one moving up and one down: the constraint sums both directions
    (up + down per PST), not the net movement, so opposite moves cannot cancel out.
    """
    ae_list = [
        _make_ae_r110("BRANCH_UP", side=1, patl_ka=1.0),
        _make_ae_r110("BRANCH_DOWN", side=1, patl_ka=1.0),
    ]
    pst_inputs = PstMilpInputs(
        pst_list=[_make_pst_r110("PST1", "TSO-A"), _make_pst_r110("PST2", "TSO-A")],
        pst_tap_bounds={"PST1": (-50, 50), "PST2": (-50, 50)},
        pst_group_equality_pairs=[],
        sensitivity_pst_n0_pruned={
            ("BRANCH_UP", "PST1"): -20.0, ("BRANCH_UP", "PST2"): 0.0,
            ("BRANCH_DOWN", "PST1"): 0.0, ("BRANCH_DOWN", "PST2"): 20.0,
        },
        pst_degrees_per_tap={"PST1": 1.0, "PST2": 1.0},
        penalty_reference_pst_pra=1.0,
        max_taps_per_tso=6,
    )
    model = build_n0_milp_model(
        ae_list, "1030Z",
        lf_initial={"BRANCH_UP": {1: 2000.0}, "BRANCH_DOWN": {1: 2000.0}},
        penalty_cost_overload_n0=1_000_000.0, pst_inputs=pst_inputs,
    )
    _solve(model)

    total_movement = (
        pyo.value(model.tap_change_upward["PST1"]) + pyo.value(model.tap_change_downward["PST1"])
        + pyo.value(model.tap_change_upward["PST2"]) + pyo.value(model.tap_change_downward["PST2"])
    )
    assert total_movement <= 6 + 1e-6, (
        f"Opposite-direction moves on different PSTs must still sum toward the same "
        f"per-TSO limit, got {total_movement}"
    )


def test_vacuous_not_skipped_for_a_tso_with_no_available_preventive_psts():
    """Only one of two TSOs has an available preventive PST: a constraint exists for that TSO
    only, no error and no entry for a TSO absent from pst_list.
    """
    ae_list = [_make_ae_r110("BRANCH1", side=1, patl_ka=1.0)]
    pst_inputs = PstMilpInputs(
        pst_list=[_make_pst_r110("PST1", "TSO-A")],
        pst_tap_bounds={"PST1": (-50, 50)},
        pst_group_equality_pairs=[],
        sensitivity_pst_n0_pruned={("BRANCH1", "PST1"): -5.0},
        pst_degrees_per_tap={"PST1": 1.0},
        penalty_reference_pst_pra=1.0,
        max_taps_per_tso=6,
    )
    model = build_n0_milp_model(
        ae_list, "1030Z", lf_initial={"BRANCH1": {1: 500.0}},
        penalty_cost_overload_n0=1000.0, pst_inputs=pst_inputs,
    )
    _solve(model)

    tso_ids = list(model.tso_ids_for_tap_change_limit)
    assert tso_ids == ["TSO-A"], (
        f"Only TSO-A has any PST in pst_list — expected exactly one constrained TSO, got {tso_ids}"
    )
    assert "TSO-B" not in tso_ids  # never referenced anywhere — confirms no spurious entry


def test_default_max_taps_per_tso_is_six():
    """PstMilpInputs without max_taps_per_tso defaults to 6."""
    pst_inputs = PstMilpInputs(
        pst_list=[_make_pst_r110("PST1", "TSO-A")],
        pst_tap_bounds={"PST1": (-50, 50)},
        pst_group_equality_pairs=[],
        sensitivity_pst_n0_pruned={},
        pst_degrees_per_tap={"PST1": 1.0},
        penalty_reference_pst_pra=1.0,
    )
    assert pst_inputs.max_taps_per_tso == 6


def test_unconstrained_solution_would_have_exceeded_the_limit():
    """Fixture check: without the per-TSO limit the scenario of
    test_constraint_blocks_a_combined_move_exceeding_the_per_tso_limit would move more, so
    that test does not pass trivially.
    """
    ae_list = [_make_ae_r110("BRANCH1", side=1, patl_ka=1.0)]
    pst_inputs = PstMilpInputs(
        pst_list=[_make_pst_r110("PST1", "TSO-A"), _make_pst_r110("PST2", "TSO-A")],
        pst_tap_bounds={"PST1": (-50, 50), "PST2": (-50, 50)},
        pst_group_equality_pairs=[],
        sensitivity_pst_n0_pruned={("BRANCH1", "PST1"): -20.0, ("BRANCH1", "PST2"): -20.0},
        pst_degrees_per_tap={"PST1": 1.0, "PST2": 1.0},
        penalty_reference_pst_pra=1.0,
        max_taps_per_tso=10_000,  # effectively unconstrained
    )
    model = build_n0_milp_model(
        ae_list, "1030Z", lf_initial={"BRANCH1": {1: 2000.0}},
        penalty_cost_overload_n0=1_000_000.0, pst_inputs=pst_inputs,
    )
    _solve(model)

    total_movement = sum(
        pyo.value(model.tap_change_upward[pst_mrid]) + pyo.value(model.tap_change_downward[pst_mrid])
        for pst_mrid in ["PST1", "PST2"]
    )
    assert total_movement > 6, (
        f"Fixture sanity check failed — expected the unconstrained optimum to exceed 6 "
        f"(so the per-TSO tap limit test above binds, not a no-op), "
        f"got {total_movement}"
    )


REPO_SRC = Path(__file__).resolve().parents[1] / "src" / "rao"


REPO_ROOT = Path(__file__).resolve().parents[1]


def _make_ae_r35(branch_mrid: str, side: int = 1, patl_ka: float = 1.0,
             ae_type=AEType.SECURED, timestamp: str = "1030Z") -> AssessedElement:
    return AssessedElement(
        mrid=f"AE_{branch_mrid}", name=f"AE {branch_mrid}", tso="TestTSO",
        ae_type=ae_type, branch_mrid=branch_mrid,
        secured_for_region=None, scanned_for_region=None, exclusion_reason=None,
        patl_ka={timestamp: patl_ka}, branch_side=side,
    )


def _make_pst_r35(mrid: str, r0: int = 0, linked_xne_mrids=None, kind=RAKind.PREVENTIVE) -> PST:
    return PST(
        mrid=mrid, name=mrid, tso="TestTSO", available=True, kind=kind,
        penalty_factor=1.0, low_step=-10, high_step=10, r0=r0,
        operating_tap_min=-10, operating_tap_max=10, group_id=None,
        linked_xne_mrids=linked_xne_mrids or [],
    )


def _make_dual_ra_pst_list_r35(pst_mrid: str, r0: int = 0, linked_xne_mrids=None) -> list[PST]:
    """A transformer with a preventive and a curative RA is two PST objects with one mRID;
    the curative RA carries the XNE linkage, the preventive one does not."""
    return [
        _make_pst_r35(pst_mrid, r0=r0, kind=RAKind.PREVENTIVE),
        _make_pst_r35(pst_mrid, r0=r0, linked_xne_mrids=linked_xne_mrids, kind=RAKind.CURATIVE),
    ]


def _make_pst_inputs_r35(pst_mrid="PST1", r0=0, sensitivity_n0=0.0, degrees_per_tap=1.0,
                      branch="BRANCH1", linked_xne_mrids=None):
    return PstMilpInputs(
        pst_list=_make_dual_ra_pst_list_r35(pst_mrid, r0=r0, linked_xne_mrids=linked_xne_mrids),
        pst_tap_bounds={pst_mrid: (-10, 10)},
        pst_group_equality_pairs=[],
        sensitivity_pst_n0_pruned={(branch, pst_mrid): sensitivity_n0},
        pst_degrees_per_tap={pst_mrid: degrees_per_tap},
        penalty_reference_pst_pra=10.0,
    )


# ---------------------------------------------------------------------------
# Curative PST MILP block — synthetic
# ---------------------------------------------------------------------------

def test_no_pst_cra_availability_adds_no_curative_components():
    """Without pst_cra_availability there are no curative PST components."""
    ae_list = [_make_ae_r35("BRANCH1")]
    pst_inputs = _make_pst_inputs_r35()
    nx_inputs = NxMilpInputs(
        lf_nx={"CO1": {"BRANCH1": {1: 900.0}}},
        sensitivity_pst_nx={"CO1": {("BRANCH1", "PST1"): -10.0}},
        sensitivity_rd_nx={},
        penalty_cost_overload_nx_patl=500.0,
    )

    model = build_n0_milp_model(
        ae_list, "1030Z", lf_initial={"BRANCH1": {1: 500.0}},
        penalty_cost_overload_n0=1000.0, pst_inputs=pst_inputs, nx_inputs=nx_inputs,
    )

    assert not hasattr(model, "curative_tap_change_upward")
    assert not hasattr(model, "curative_tap_change_downward")
    assert not hasattr(model, "curative_pst_contingency_pairs")


def test_only_available_entries_get_curative_variables():
    """Given pst_cra_availability has one available=True and one
    available=False entry, When the model is built, Then only the
    available=True (pst, contingency) pair gets curative variables."""
    ae_list = [_make_ae_r35("BRANCH1")]
    pst_inputs = _make_pst_inputs_r35()
    nx_inputs = NxMilpInputs(
        lf_nx={"CO1": {"BRANCH1": {1: 900.0}}, "CO2": {"BRANCH1": {1: 900.0}}},
        sensitivity_pst_nx={
            "CO1": {("BRANCH1", "PST1"): -10.0},
            "CO2": {("BRANCH1", "PST1"): -10.0},
        },
        sensitivity_rd_nx={},
        penalty_cost_overload_nx_patl=500.0,
        pst_cra_availability={
            ("PST1", "BRANCH1", "CO1"): {"max_curative_taps": 3, "available": True},
            ("PST1", "BRANCH1", "CO2"): {"max_curative_taps": 0, "available": False},
        },
    )

    model = build_n0_milp_model(
        ae_list, "1030Z", lf_initial={"BRANCH1": {1: 500.0}},
        penalty_cost_overload_n0=1000.0, pst_inputs=pst_inputs, nx_inputs=nx_inputs,
    )

    pairs = list(model.curative_pst_contingency_pairs)
    assert pairs == [("PST1", "CO1")]


def test_magnitude_constraint_uses_tightest_xne_across_shared_variable():
    """ONE curative variable pair for (PST1, CO1), available for TWO XNEs with different
    max_curative_taps: two magnitude constraints on the same variables, the tighter binds
    (checked by solving)."""
    ae_list = [_make_ae_r35("BRANCH1", patl_ka=1.0), _make_ae_r35("BRANCH2", patl_ka=1.0)]
    pst_inputs = PstMilpInputs(
        pst_list=_make_dual_ra_pst_list_r35("PST1"),
        pst_tap_bounds={"PST1": (-10, 10)},
        pst_group_equality_pairs=[],
        sensitivity_pst_n0_pruned={("BRANCH1", "PST1"): 0.0, ("BRANCH2", "PST1"): 0.0},
        pst_degrees_per_tap={"PST1": 1.0},
        penalty_reference_pst_pra=10.0,
    )
    nx_inputs = NxMilpInputs(
        lf_nx={"CO1": {"BRANCH1": {1: 1100.0}, "BRANCH2": {1: 500.0}}},
        sensitivity_pst_nx={"CO1": {("BRANCH1", "PST1"): -10.0, ("BRANCH2", "PST1"): -10.0}},
        sensitivity_rd_nx={},
        penalty_cost_overload_nx_patl=1_000_000.0,
        pst_cra_availability={
            ("PST1", "BRANCH1", "CO1"): {"max_curative_taps": 10, "available": True},
            ("PST1", "BRANCH2", "CO1"): {"max_curative_taps": 2, "available": True},  # tighter
        },
    )

    model = build_n0_milp_model(
        ae_list, "1030Z", lf_initial={"BRANCH1": {1: 500.0}, "BRANCH2": {1: 500.0}},
        penalty_cost_overload_n0=1_000_000.0, pst_inputs=pst_inputs, nx_inputs=nx_inputs,
    )

    # Both magnitude constraints exist, sharing the same variable pair:
    assert ("PST1", "BRANCH1", "CO1") in list(model.curative_tap_magnitude_triples)
    assert ("PST1", "BRANCH2", "CO1") in list(model.curative_tap_magnitude_triples)

    solver = pyo.SolverFactory("appsi_highs")
    result = solver.solve(model)
    assert str(result.solver.termination_condition) == "optimal"

    net_curative_change = (
        pyo.value(model.curative_tap_change_upward["PST1", "CO1"])
        - pyo.value(model.curative_tap_change_downward["PST1", "CO1"])
    )
    # BRANCH1 needs 10 taps upward (1100A overload / 10A per tap*degree) to
    # clear fully, but BRANCH2's tighter max_curative_taps=2 caps it at 2.
    assert abs(net_curative_change) <= 2.0 + 1e-6


def test_curative_tap_bounds_combine_preventive_and_curative():
    """Given a curative_tap_min/max tighter than the preventive tap
    bounds, When the model is built and solved with a strong incentive to
    move the tap far, Then the COMBINED preventive+curative tap position
    still respects curative_tap_min/max, not just the preventive bounds."""
    ae_list = [_make_ae_r35("BRANCH1", patl_ka=1.0)]
    pst_inputs = _make_pst_inputs_r35(sensitivity_n0=0.0, degrees_per_tap=1.0)
    nx_inputs = NxMilpInputs(
        lf_nx={"CO1": {"BRANCH1": {1: 2000.0}}},  # huge overload, wants many taps
        sensitivity_pst_nx={"CO1": {("BRANCH1", "PST1"): -10.0}},
        sensitivity_rd_nx={},
        penalty_cost_overload_nx_patl=1_000_000.0,
        pst_cra_availability={
            ("PST1", "BRANCH1", "CO1"): {"max_curative_taps": 100, "available": True},
        },
        pst_tap_bounds_curative={"PST1": (-3, 3)},  # tight curative range
    )

    model = build_n0_milp_model(
        ae_list, "1030Z", lf_initial={"BRANCH1": {1: 500.0}},
        penalty_cost_overload_n0=1_000_000.0, pst_inputs=pst_inputs, nx_inputs=nx_inputs,
    )

    solver = pyo.SolverFactory("appsi_highs")
    result = solver.solve(model)
    assert str(result.solver.termination_condition) == "optimal"

    combined_tap = (
        0  # r0
        + pyo.value(model.tap_change_upward["PST1"]) - pyo.value(model.tap_change_downward["PST1"])
        + pyo.value(model.curative_tap_change_upward["PST1", "CO1"])
        - pyo.value(model.curative_tap_change_downward["PST1", "CO1"])
    )
    assert -3.0 - 1e-6 <= combined_tap <= 3.0 + 1e-6


def _solve_fractional_curative_need(pst_taping_discrete: bool):
    """One PST, one contingency with an overload of 55 A and 10 A per tap: the loading is relieved exactly by 5.5 taps."""
    assessed_elements = [_make_ae_r35("BRANCH1", patl_ka=1.0)]
    pst_inputs = _make_pst_inputs_r35(sensitivity_n0=0.0, degrees_per_tap=1.0)
    pst_inputs.pst_taping_discrete = pst_taping_discrete
    nx_inputs = NxMilpInputs(
        lf_nx={"CO1": {"BRANCH1": {1: 1055.0}}},
        sensitivity_pst_nx={"CO1": {("BRANCH1", "PST1"): -10.0}},
        sensitivity_rd_nx={},
        penalty_cost_overload_nx_patl=1_000_000.0,
        pst_cra_availability={("PST1", "BRANCH1", "CO1"): {"max_curative_taps": 20, "available": True}},
        pst_tap_bounds_curative={"PST1": (-20, 20)},
    )
    model = build_n0_milp_model(
        assessed_elements, "1030Z", lf_initial={"BRANCH1": {1: 500.0}},
        penalty_cost_overload_n0=1_000_000.0, pst_inputs=pst_inputs, nx_inputs=nx_inputs,
    )
    result = pyo.SolverFactory("appsi_highs").solve(model)
    assert str(result.solver.termination_condition) == "optimal"
    return model


def test_rao_curative_pst_taps_are_whole_numbers_when_taps_are_discrete():
    """Given a need of 5.5 taps and pst_taping_discrete = True, When the model is solved, Then the
    curative tap change is a whole number of taps (like the preventive one)."""
    model = _solve_fractional_curative_need(pst_taping_discrete=True)
    for variable in (model.curative_tap_change_upward["PST1", "CO1"], model.curative_tap_change_downward["PST1", "CO1"]):
        value = pyo.value(variable)
        assert abs(value - round(value)) < 1e-6, f"curative tap change {value} is not a whole number"


def test_rao_curative_pst_taps_stay_continuous_when_taps_are_not_discrete():
    """Given the same need and pst_taping_discrete = False, Then the curative tap change may be a fraction (5.5 taps)."""
    model = _solve_fractional_curative_need(pst_taping_discrete=False)
    total_taps = (
        pyo.value(model.tap_change_upward["PST1"]) - pyo.value(model.tap_change_downward["PST1"])
        + pyo.value(model.curative_tap_change_upward["PST1", "CO1"]) - pyo.value(model.curative_tap_change_downward["PST1", "CO1"])
    )
    assert total_taps == pytest.approx(5.5, abs=1e-6)


def test_missing_curative_bounds_entry_skips_constraint_not_crash():
    """Given a PST with curative variables but NO entry in
    pst_tap_bounds_curative at all, When the model is built, Then no
    exception is raised — the tap-bounds constraint for that (pst,
    contingency) pair is simply skipped (logged), matching the module's
    'partial data must not crash the build' philosophy."""
    ae_list = [_make_ae_r35("BRANCH1", patl_ka=1.0)]
    pst_inputs = _make_pst_inputs_r35()
    nx_inputs = NxMilpInputs(
        lf_nx={"CO1": {"BRANCH1": {1: 900.0}}},
        sensitivity_pst_nx={"CO1": {("BRANCH1", "PST1"): -10.0}},
        sensitivity_rd_nx={},
        penalty_cost_overload_nx_patl=500.0,
        pst_cra_availability={
            ("PST1", "BRANCH1", "CO1"): {"max_curative_taps": 3, "available": True},
        },
        pst_tap_bounds_curative={},
    )

    model = build_n0_milp_model(
        ae_list, "1030Z", lf_initial={"BRANCH1": {1: 500.0}},
        penalty_cost_overload_n0=1000.0, pst_inputs=pst_inputs, nx_inputs=nx_inputs,
    )

    assert hasattr(model, "curative_tap_bounds")


def _make_pst_inputs_with_n0_cost_r35(pst_mrid="PST1", branch="BRANCH1", linked_xne_mrids=None):
    """Preventive tap movement that helps N-X (up, N-X sensitivity -10) hurts N-0 (+10, N-0 at
    its PATL), so any preventive move costs an N-0 overload: the N-X overload must be
    resolved by the CURATIVE variable (the preventive one acts in every contingency)."""
    return PstMilpInputs(
        pst_list=_make_dual_ra_pst_list_r35(pst_mrid, linked_xne_mrids=linked_xne_mrids),
        pst_tap_bounds={pst_mrid: (-10, 10)},
        pst_group_equality_pairs=[],
        sensitivity_pst_n0_pruned={(branch, pst_mrid): 10.0},
        pst_degrees_per_tap={pst_mrid: 1.0},
        penalty_reference_pst_pra=10.0,
    )


def test_activate_cra_xne_linkage_false_includes_term_regardless_of_linked_xne():
    """Given activate_cra_xne_linkage=False (the default) and a PST whose
    linked_xne_mrids does NOT include BRANCH1, When the N-X constraint is
    built, Then the curative term is STILL included for BRANCH1 (default
    behaviour ignores linked_xne_mrids entirely)."""
    ae_list = [_make_ae_r35("BRANCH1", patl_ka=1.0)]
    pst_inputs = _make_pst_inputs_with_n0_cost_r35(linked_xne_mrids=["OTHER_BRANCH"])
    nx_inputs = NxMilpInputs(
        lf_nx={"CO1": {"BRANCH1": {1: 1050.0}}},
        sensitivity_pst_nx={"CO1": {("BRANCH1", "PST1"): -10.0}},
        sensitivity_rd_nx={},
        penalty_cost_overload_nx_patl=1_000_000.0,
        pst_cra_availability={
            ("PST1", "BRANCH1", "CO1"): {"max_curative_taps": 10, "available": True},
        },
        pst_tap_bounds_curative={"PST1": (-10, 10)},
        activate_cra_xne_linkage=False,
    )

    model = build_n0_milp_model(
        ae_list, "1030Z", lf_initial={"BRANCH1": {1: 1000.0}},  # exactly at N-0 PATL
        penalty_cost_overload_n0=1_000_000.0, pst_inputs=pst_inputs, nx_inputs=nx_inputs,
    )

    solver = pyo.SolverFactory("appsi_highs")
    result = solver.solve(model)
    assert str(result.solver.termination_condition) == "optimal"
    assert pyo.value(model.overload_slack_n0["BRANCH1"]) == pytest.approx(0.0, abs=1e-6)
    # The curative variable resolves the overload despite BRANCH1 not
    # being in linked_xne_mrids, since linkage is off:
    net_curative_change = (
        pyo.value(model.curative_tap_change_upward["PST1", "CO1"])
        - pyo.value(model.curative_tap_change_downward["PST1", "CO1"])
    )
    # only the slack is penalised: any value in [5, 10] that clears the overload is optimal;
    # it must clear it and stay within the magnitude bound
    assert 5.0 - 1e-6 <= net_curative_change <= 10.0 + 1e-6


def test_activate_cra_xne_linkage_true_excludes_unlinked_xne():
    """Given activate_cra_xne_linkage=True and a PST whose linked_xne_mrids
    does NOT include BRANCH1, When the N-X constraint is built, Then the
    curative term is EXCLUDED for BRANCH1 — the overload can only be
    absorbed by nx_patl_overload_slack, not the curative PST, even though
    pst_cra_availability marked it available=True."""
    ae_list = [_make_ae_r35("BRANCH1", patl_ka=1.0)]
    pst_inputs = _make_pst_inputs_with_n0_cost_r35(linked_xne_mrids=["OTHER_BRANCH"])
    nx_inputs = NxMilpInputs(
        lf_nx={"CO1": {"BRANCH1": {1: 1050.0}}},
        sensitivity_pst_nx={"CO1": {("BRANCH1", "PST1"): -10.0}},
        sensitivity_rd_nx={},
        penalty_cost_overload_nx_patl=1_000_000.0,
        pst_cra_availability={
            ("PST1", "BRANCH1", "CO1"): {"max_curative_taps": 10, "available": True},
        },
        pst_tap_bounds_curative={"PST1": (-10, 10)},
        activate_cra_xne_linkage=True,
    )

    model = build_n0_milp_model(
        ae_list, "1030Z", lf_initial={"BRANCH1": {1: 1000.0}},
        penalty_cost_overload_n0=1_000_000.0, pst_inputs=pst_inputs, nx_inputs=nx_inputs,
    )

    solver = pyo.SolverFactory("appsi_highs")
    result = solver.solve(model)
    assert str(result.solver.termination_condition) == "optimal"

    net_curative_change = (
        pyo.value(model.curative_tap_change_upward["PST1", "CO1"])
        - pyo.value(model.curative_tap_change_downward["PST1", "CO1"])
    )
    # the variable exists per (pst, contingency), but its effect on BRANCH1 is excluded: the
    # overload goes to the slack (a preventive move would cause an N-0 overload)
    assert net_curative_change == pytest.approx(0.0, abs=1e-6)
    assert pyo.value(model.nx_patl_overload_slack["BRANCH1", "CO1"]) == pytest.approx(50.0, abs=1e-6)


def test_acceptance_criteria_curative_pst_linked_to_one_contingency_only():
    """A curative PST linked to CO1 only (no availability entry for CO2): the curative tap
    change appears only in CO1's N-X constraint (no variable for (PST1, CO2)) and
    |up - down| <= max_curative_taps."""
    ae_list = [_make_ae_r35("BRANCH1", patl_ka=1.0)]
    pst_inputs = _make_pst_inputs_with_n0_cost_r35()
    nx_inputs = NxMilpInputs(
        lf_nx={
            "CO1": {"BRANCH1": {1: 1050.0}},  # overloaded — curative PST should help
            "CO2": {"BRANCH1": {1: 1050.0}},  # ALSO overloaded, but PST not linked here
        },
        sensitivity_pst_nx={
            "CO1": {("BRANCH1", "PST1"): -10.0},
            "CO2": {("BRANCH1", "PST1"): -10.0},
        },
        sensitivity_rd_nx={},
        penalty_cost_overload_nx_patl=1_000_000.0,
        pst_cra_availability={
            ("PST1", "BRANCH1", "CO1"): {"max_curative_taps": 5, "available": True},
            # No entry at all for CO2 -> PST1 is not curative-available under CO2.
        },
        pst_tap_bounds_curative={"PST1": (-10, 10)},
    )

    model = build_n0_milp_model(
        ae_list, "1030Z", lf_initial={"BRANCH1": {1: 1000.0}},
        penalty_cost_overload_n0=10_000_000.0, pst_inputs=pst_inputs, nx_inputs=nx_inputs,
    )

    # The curative variable pair exists ONLY for (PST1, CO1), not (PST1, CO2):
    assert ("PST1", "CO1") in list(model.curative_pst_contingency_pairs)
    assert ("PST1", "CO2") not in list(model.curative_pst_contingency_pairs)

    solver = pyo.SolverFactory("appsi_highs")
    result = solver.solve(model)
    assert str(result.solver.termination_condition) == "optimal"

    net_curative_change = (
        pyo.value(model.curative_tap_change_upward["PST1", "CO1"])
        - pyo.value(model.curative_tap_change_downward["PST1", "CO1"])
    )
    assert abs(net_curative_change) <= 5.0 + 1e-6
    # CO2's overload has no curative help available, and preventive
    # movement is ruled out (an N-0 overload costs ten times more than the CO2 overload) -> absorbed by slack.
    # (The N-0 penalty is ten times the N-X penalty because the old setup relied on a tie between the two overloads;
    # with whole curative taps the solver picked the other tie vertex.)
    assert pyo.value(model.nx_patl_overload_slack["BRANCH1", "CO2"]) > 0.0


REPO_ROOT = Path(__file__).resolve().parents[1]


SRC_ROOT = REPO_ROOT / "src" / "rao"


# ===========================================================================
# Curative PST penalty
# ===========================================================================

PENALTY_REFERENCE = 10.0


TAPS_NEEDED = 5  # 1050 A vs PATL 1000 A, -10 A per tap


def _solve_curative_scenario(
    penalty_factor=1.0,
    contingencies=("CO1",),
    per_tso_override=None,
    extra_preventive_penalty_factor=None,
):
    """N-0 is fine (500 A). In every contingency BRANCH1 carries 1050 A (PATL
    1000 A) and the curative PST relieves 10 A per tap, so exactly 5 curative
    taps per contingency are needed (an overload slack costs 1000 EUR/A)."""
    psts = [_make_pst("CUR_PST", RAKind.CURATIVE, penalty_factor=penalty_factor)]
    if extra_preventive_penalty_factor is not None:
        psts.append(_make_pst("CUR_PST", RAKind.PREVENTIVE, penalty_factor=extra_preventive_penalty_factor))
    pst_inputs = PstMilpInputs(
        pst_list=psts,
        pst_tap_bounds={"CUR_PST": (0, 0)} if extra_preventive_penalty_factor is not None else {},
        pst_group_equality_pairs=[],
        sensitivity_pst_n0_pruned={},
        pst_degrees_per_tap={"CUR_PST": 1.0},
        penalty_reference_pst_pra=PENALTY_REFERENCE,
        penalty_reference_pst_pra_per_tso=per_tso_override,
    )
    nx_inputs = NxMilpInputs(
        lf_nx={co: {"BRANCH1": {1: 1050.0}} for co in contingencies},
        sensitivity_pst_nx={co: {("BRANCH1", "CUR_PST"): -10.0} for co in contingencies},
        sensitivity_rd_nx={},
        penalty_cost_overload_nx_patl=1000.0,
        pst_cra_availability={
            ("CUR_PST", "BRANCH1", co): {"max_curative_taps": 10, "available": True}
            for co in contingencies
        },
        pst_tap_bounds_curative={"CUR_PST": (-10, 10)},
    )
    model = build_n0_milp_model(
        [_make_ae("BRANCH1")], "1030Z", lf_initial={"BRANCH1": {1: 500.0}},
        penalty_cost_overload_n0=1000.0, pst_inputs=pst_inputs, nx_inputs=nx_inputs,
    )
    result = pyo.SolverFactory("appsi_highs").solve(model)
    assert str(result.solver.termination_condition) == "optimal"
    return model


def _total_curative_taps(model):
    return sum(
        pyo.value(model.curative_tap_change_upward[pair]) + pyo.value(model.curative_tap_change_downward[pair])
        for pair in model.curative_pst_contingency_pairs
    )


def test_curative_taps_are_charged_in_the_objective():
    """Curative taps are charged in the objective (not free)."""
    model = _solve_curative_scenario(penalty_factor=1.0)
    assert _total_curative_taps(model) == pytest.approx(TAPS_NEEDED, abs=1e-6)
    assert pyo.value(model.objective) == pytest.approx(1.0 * PENALTY_REFERENCE * TAPS_NEEDED, abs=1e-6)


def test_curative_cost_scales_with_the_curative_ra_penalty_factor():
    model = _solve_curative_scenario(penalty_factor=3.0)
    assert pyo.value(model.objective) == pytest.approx(3.0 * PENALTY_REFERENCE * TAPS_NEEDED, abs=1e-6)


def test_penalty_factor_zero_gives_zero_curative_cost():
    model = _solve_curative_scenario(penalty_factor=0.0)
    assert pyo.value(model.nx_patl_overload_slack["BRANCH1", "CO1"]) == pytest.approx(0.0, abs=1e-6)
    assert pyo.value(model.objective) == pytest.approx(0.0, abs=1e-9)


def test_per_tso_override_is_used_for_curative_cost():
    """The per-TSO override sets the curative cost (objective 150)."""
    model = _solve_curative_scenario(penalty_factor=1.0, per_tso_override={"TestTSO": 30.0})
    assert pyo.value(model.objective) == pytest.approx(1.0 * 30.0 * TAPS_NEEDED, abs=1e-6)


def test_two_contingencies_give_the_sum_not_the_max():
    """The curative cost sums over contingencies: 5 taps in each of two contingencies = 10
    taps charged (100); a max would give 50."""
    model = _solve_curative_scenario(penalty_factor=1.0, contingencies=("CO1", "CO2"))
    assert _total_curative_taps(model) == pytest.approx(2 * TAPS_NEEDED, abs=1e-6)
    assert pyo.value(model.objective) == pytest.approx(PENALTY_REFERENCE * 2 * TAPS_NEEDED, abs=1e-6)


def test_curative_cost_uses_curative_ra_penalty_not_preventive_ra_penalty():
    """Transformer with a preventive RA (PF 2) and a curative RA (PF 5): the
    curative taps are charged with 5. The preventive tap range is pinned to
    (0, 0) so the cheaper preventive RA cannot take over the relief."""
    model = _solve_curative_scenario(penalty_factor=5.0, extra_preventive_penalty_factor=2.0)
    assert pyo.value(model.objective) == pytest.approx(5.0 * PENALTY_REFERENCE * TAPS_NEEDED, abs=1e-6)


LEGACY_PST_CSV_HEADER = [
    "pst_mrid", "pst_name", "tso", "original_tap_position", "tap_change_result",
    "result_tap_position", "pst_penalty_factor", "penalty_reference_pst_pra",
    "effective_penalty_cost_per_tap_eur", "penalty_cost_eur", "timestamp",
    "ac_verification_status", "ac_verification_termination_reason",
]


def test_extract_curative_pst_results_sums_taps_and_cost_over_contingencies():
    model = _solve_curative_scenario(penalty_factor=3.0, contingencies=("CO1", "CO2"))
    psts = [_make_pst("CUR_PST", RAKind.CURATIVE, penalty_factor=3.0)]
    results = extract_curative_pst_results(model, psts, PENALTY_REFERENCE)
    row = results["CUR_PST"]
    assert row["curative_tap_change_total"] == pytest.approx(2 * TAPS_NEEDED, abs=1e-6)
    assert row["curative_penalty_cost_eur"] == pytest.approx(3.0 * PENALTY_REFERENCE * 2 * TAPS_NEEDED, abs=1e-6)


def test_extract_curative_pst_results_empty_without_curative_pairs():
    assert extract_curative_pst_results(object(), [], PENALTY_REFERENCE) == {}


def _read_csv(path):
    with open(path, newline="", encoding=TEXT_ENCODING) as f:
        return list(csv.reader(f))


def test_pst_results_csv_appends_curative_columns_and_keeps_the_column_order(tmp_path):
    model = _solve_curative_scenario(penalty_factor=1.0)
    psts = [_make_pst("CUR_PST", RAKind.CURATIVE, penalty_factor=1.0)]
    curative = extract_curative_pst_results(model, psts, PENALTY_REFERENCE)
    out = tmp_path / "results_pst.csv"
    write_pst_results_csv(
        {}, out, "1030Z", AcVerificationStatus.NOT_APPLICABLE, "n/a", curative_pst_results=curative,
    )
    rows = _read_csv(out)
    assert rows[0][: len(LEGACY_PST_CSV_HEADER)] == LEGACY_PST_CSV_HEADER
    assert rows[0][len(LEGACY_PST_CSV_HEADER):] == [
        "curative_tap_change_total", "curative_penalty_cost_eur",
        "last_solve_start_tap_position", "last_solve_tap_change",
    ]
    # curative-only transformer: one row, preventive columns neutral, curative columns filled
    assert len(rows) == 2
    assert rows[1][0] == "CUR_PST"
    assert float(rows[1][4]) == 0.0  # tap_change_result (preventive)
    assert float(rows[1][-4]) == pytest.approx(TAPS_NEEDED, abs=1e-6)
    assert float(rows[1][-3]) == pytest.approx(PENALTY_REFERENCE * TAPS_NEEDED, abs=1e-6)


def test_pst_results_csv_without_curative_argument_writes_zero_curative_columns(tmp_path):
    out = tmp_path / "results_pst.csv"
    preventive_row = {
        "pst_name": "P", "tso": "T", "current_tap_position": 0, "tap_change_result": 1.0,
        "result_tap_position": 1.0, "pst_penalty_factor": 1.0, "penalty_reference_pst_pra": 10.0,
        "effective_penalty_cost_per_tap_eur": 10.0, "penalty_cost_eur": 10.0,
    }
    write_pst_results_csv({"P1": preventive_row}, out, "1030Z", AcVerificationStatus.NOT_APPLICABLE, "n/a")
    rows = _read_csv(out)
    assert rows[1][:-4] == ["P1", "P", "T", "0", "1.0", "1.0", "1.0", "10.0", "10.0", "10.0", "1030Z",
                            AcVerificationStatus.NOT_APPLICABLE.value, "n/a"]
    assert rows[1][-4:-2] == ["0.0", "0.0"]
    # without a loop-supplied last-solve record the diagnostics repeat the cumulative values
    assert rows[1][-2:] == ["0", "1.0"]


def test_results_summary_reports_curative_pst_penalty_after_the_original_metrics():
    model = _solve_curative_scenario(penalty_factor=1.0)
    psts = [_make_pst("CUR_PST", RAKind.CURATIVE, penalty_factor=1.0)]
    summary = extract_results_summary(
        model, objective_value=pyo.value(model.objective), pst_list=psts,
        penalty_reference_pst_pra=PENALTY_REFERENCE,
    )
    # original metrics keep their order; the curative PST penalty follows them (the
    # results-summary completion appends further metrics after it)
    assert list(summary)[7] == "sum_curative_pst_penalty_cost_eur"
    assert summary["sum_curative_pst_penalty_cost_eur"] == pytest.approx(PENALTY_REFERENCE * TAPS_NEEDED, abs=1e-6)
    # existing preventive metric is untouched by curative taps
    assert summary["sum_pst_penalty_cost_eur"] == 0.0


# ===========================================================================
# Preventive tap limit per TSO
# ===========================================================================

PENALTY_REFERENCE_preventive_tap_limit = 1.0


def _solve_preventive_tap_limit(model):
    result = pyo.SolverFactory("appsi_highs").solve(model)
    assert str(result.solver.termination_condition) == "optimal"
    return model


def _n0_model(pst_list, sens, limit=6, overrides=None, loading=1100.0):
    """N-0 overload of (loading - 1000) A on BRANCH1 (PATL 1 kA)."""
    mrids = sorted({str(p.mrid) for p in pst_list})
    pst_inputs = PstMilpInputs(
        pst_list=pst_list,
        pst_tap_bounds={m: (-10, 10) for m in mrids},
        pst_group_equality_pairs=[],
        sensitivity_pst_n0_pruned={("BRANCH1", m): s for m, s in sens.items()},
        pst_degrees_per_tap={m: 1.0 for m in mrids},
        penalty_reference_pst_pra=PENALTY_REFERENCE_preventive_tap_limit,
        max_taps_per_tso=limit,
        max_taps_per_tso_overrides=overrides,
    )
    return build_n0_milp_model(
        [_make_ae("BRANCH1")], "1030Z", lf_initial={"BRANCH1": {1: loading}},
        penalty_cost_overload_n0=1_000_000.0, pst_inputs=pst_inputs,
    )


def _taps(model, mrid):
    return pyo.value(model.tap_change_upward[mrid]) + pyo.value(model.tap_change_downward[mrid])


# ---- 1) duplicates ----------------------------------------------------------

def test_two_preventive_ras_on_one_transformer_count_once_in_the_branch_effect():
    """Two preventive RAs on one transformer count once in pst_effect_on_branch (10 taps
    clear the 100 A)."""
    duplicates = [_make_pst("P", RAKind.PREVENTIVE), _make_pst("P", RAKind.PREVENTIVE)]
    model = _solve_preventive_tap_limit(_n0_model(duplicates, {"P": -10.0}, limit=100))
    assert _taps(model, "P") == pytest.approx(10.0, abs=1e-6)


def test_two_preventive_ras_on_one_transformer_count_once_in_the_tso_tap_limit():
    """Two preventive RAs on one transformer count once in the per-TSO cap (the transformer can
    move the full 6 taps)."""
    duplicates = [_make_pst("P", RAKind.PREVENTIVE), _make_pst("P", RAKind.PREVENTIVE)]
    model = _solve_preventive_tap_limit(_n0_model(duplicates, {"P": -10.0}, limit=6))
    assert _taps(model, "P") == pytest.approx(6.0, abs=1e-6)


# ---- 2) unavailable PSTs ----------------------------------------------------

def test_unavailable_preventive_pst_gets_no_variables_and_does_not_count():
    """An unavailable preventive PST gets no tap variables and takes no part in the cap or
    the objective."""
    available = _make_pst("P_OK", RAKind.PREVENTIVE)
    unavailable = _make_pst("P_OFF", RAKind.PREVENTIVE)
    unavailable.available = False
    model = _solve_preventive_tap_limit(_n0_model([available, unavailable], {"P_OK": -10.0, "P_OFF": -10.0}, limit=6))
    assert list(model.pst_ids) == ["P_OK"]
    assert _taps(model, "P_OK") == pytest.approx(6.0, abs=1e-6)   # alone, up to the TSO limit


def test_tso_with_only_unavailable_preventive_psts_has_no_tap_limit_row():
    """A TSO with only unavailable preventive PSTs gets no tap-limit row."""
    other = _make_pst("P_OK", RAKind.PREVENTIVE, tso="TSO_B")
    off = _make_pst("P_OFF", RAKind.PREVENTIVE, tso="TSO_A")
    off.available = False
    model = _n0_model([other, off], {"P_OK": -10.0, "P_OFF": -10.0})
    assert list(model.tso_ids_for_tap_change_limit) == ["TSO_B"]


def _curative_scenario(curative_available: bool):
    pre = _make_pst("PRE", RAKind.PREVENTIVE)
    cur = _make_pst("CUR", RAKind.CURATIVE)
    cur.available = curative_available
    cur.linked_contingency_mrids = ["CO1"]
    cur.linked_xne_mrids = []
    pst_inputs = PstMilpInputs(
        pst_list=[pre, cur], pst_tap_bounds={"PRE": (-10, 10)}, pst_group_equality_pairs=[],
        sensitivity_pst_n0_pruned={("BRANCH1", "PRE"): 0.0},
        pst_degrees_per_tap={"PRE": 1.0, "CUR": 1.0}, penalty_reference_pst_pra=PENALTY_REFERENCE_preventive_tap_limit,
    )
    nx_inputs = NxMilpInputs(
        lf_nx={"CO1": {"BRANCH1": {1: 1050.0}}},
        sensitivity_pst_nx={"CO1": {("BRANCH1", "PRE"): 0.0, ("BRANCH1", "CUR"): -10.0}},
        sensitivity_rd_nx={}, penalty_cost_overload_nx_patl=1000.0,
        # availability entry says "available" - as if it came from stale/foreign data
        pst_cra_availability={("CUR", "BRANCH1", "CO1"): {"max_curative_taps": 10, "available": True}},
        pst_tap_bounds_curative={"CUR": (-10, 10)},
    )
    return build_n0_milp_model(
        [_make_ae("BRANCH1")], "1030Z", lf_initial={"BRANCH1": {1: 500.0}},
        penalty_cost_overload_n0=1000.0, pst_inputs=pst_inputs, nx_inputs=nx_inputs,
    )


def test_available_curative_pst_relieves_the_nx_overload_control_case():
    model = _solve_preventive_tap_limit(_curative_scenario(curative_available=True))
    assert pyo.value(model.nx_patl_overload_slack["BRANCH1", "CO1"]) == pytest.approx(0.0, abs=1e-6)


def test_unavailable_curative_pst_gets_no_variables_and_cannot_relieve():
    """An unavailable curative PST (PST.available False) gets no curative variables, even
    when pst_cra_availability marks the pair available."""
    model = _solve_preventive_tap_limit(_curative_scenario(curative_available=False))
    assert not hasattr(model, "curative_pst_contingency_pairs")
    assert pyo.value(model.nx_patl_overload_slack["BRANCH1", "CO1"]) == pytest.approx(50.0, abs=1e-6)


# ---- 3) per-TSO override ----------------------------------------------------

def _two_tso_psts():
    return [_make_pst("A1", RAKind.PREVENTIVE, tso="TSO_A"), _make_pst("B1", RAKind.PREVENTIVE, tso="TSO_B")]


def test_per_tso_override_limits_only_that_tso():
    """The per-TSO override limits only its own TSO."""
    # 100 A overload, each PST -10 A/tap. A1 capped at 2 -> 2 taps; B1 takes the rest (global 6)
    model = _solve_preventive_tap_limit(_n0_model(_two_tso_psts(), {"A1": -10.0, "B1": -10.0}, limit=6, overrides={"TSO_A": 2}))
    assert _taps(model, "A1") <= 2 + 1e-6
    assert _taps(model, "B1") <= 6 + 1e-6
    assert _taps(model, "A1") + _taps(model, "B1") == pytest.approx(8.0, abs=1e-6)  # 2 + 6 (cap-limited)
    assert model.tso_tap_limit_values == {"TSO_A": 2, "TSO_B": 6}


def test_without_override_every_tso_uses_the_global_limit():
    model = _n0_model(_two_tso_psts(), {"A1": -10.0, "B1": -10.0}, limit=5)
    assert model.tso_tap_limit_values == {"TSO_A": 5, "TSO_B": 5}


@pytest.mark.parametrize("bad", [-1, 2.5, "6", True, None])
def test_invalid_tap_limit_values_are_rejected(bad):
    """Invalid tap-limit values are rejected."""
    with pytest.raises(ValueError):
        validate_max_taps_per_tso(bad)
    with pytest.raises(ValueError):
        _n0_model(_two_tso_psts(), {"A1": -10.0, "B1": -10.0}, overrides={"TSO_A": bad})


# ---- 4) results file --------------------------------------------------------

def test_tso_tap_limit_rows_report_total_limit_remaining_and_binding():
    """The TSO tap-limit rows report total, limit, remaining and binding."""
    psts = _two_tso_psts()
    model = _solve_preventive_tap_limit(_n0_model(psts, {"A1": -10.0, "B1": -10.0}, limit=6, overrides={"TSO_A": 2}))
    rows = {r["tso"]: r for r in extract_tso_tap_limit_results(model, psts)}
    assert rows["TSO_A"] == {"tso": "TSO_A", "tap_total": pytest.approx(2.0), "max_taps_per_tso": 2.0,
                             "remaining": pytest.approx(0.0), "binding": True}
    assert rows["TSO_B"]["tap_total"] == pytest.approx(6.0) and rows["TSO_B"]["binding"] is True


def test_non_binding_tso_is_reported_as_not_binding():
    psts = [_make_pst("A1", RAKind.PREVENTIVE, tso="TSO_A")]
    model = _solve_preventive_tap_limit(_n0_model(psts, {"A1": -10.0}, limit=50, loading=1020.0))  # 20 A -> 2 taps
    (row,) = extract_tso_tap_limit_results(model, psts)
    assert (row["tap_total"], row["max_taps_per_tso"], row["remaining"], row["binding"]) == (
        pytest.approx(2.0), 50.0, pytest.approx(48.0), False)


def test_duplicate_transformer_is_counted_once_in_the_reported_total():
    duplicates = [_make_pst("P", RAKind.PREVENTIVE), _make_pst("P", RAKind.PREVENTIVE)]
    model = _solve_preventive_tap_limit(_n0_model(duplicates, {"P": -10.0}, limit=6))
    (row,) = extract_tso_tap_limit_results(model, duplicates)
    assert row["tap_total"] == pytest.approx(6.0)


def test_tap_limit_csv_columns_and_status(tmp_path):
    psts = _two_tso_psts()
    model = _solve_preventive_tap_limit(_n0_model(psts, {"A1": -10.0, "B1": -10.0}, limit=6, overrides={"TSO_A": 2}))
    path = tmp_path / "results_tso_tap_limits.csv"
    write_tso_tap_limit_results_csv(
        extract_tso_tap_limit_results(model, psts), path, "1030Z", AcVerificationStatus.CONVERGED, "stable",
    )
    rows = list(csv.DictReader(path.open(encoding=TEXT_ENCODING)))
    assert list(rows[0]) == ["tso", "tap_total", "max_taps_per_tso", "remaining", "binding",
                             "timestamp", "ac_verification_status", "ac_verification_termination_reason"]
    assert [r["tso"] for r in rows] == ["TSO_A", "TSO_B"]
    assert rows[0]["binding"] == "true" and rows[0]["ac_verification_status"] == AcVerificationStatus.CONVERGED.value


def test_tap_limit_csv_is_header_only_without_preventive_psts(tmp_path):
    curative_only = [_make_pst("C1", RAKind.CURATIVE)]
    path = tmp_path / "results_tso_tap_limits.csv"
    write_tso_tap_limit_results_csv(
        extract_tso_tap_limit_results(object(), curative_only), path, "1030Z", AcVerificationStatus.CONVERGED, "x",
    )
    lines = path.read_text(encoding=TEXT_ENCODING).strip().splitlines()
    assert len(lines) == 1 and lines[0].startswith("tso,tap_total,max_taps_per_tso,remaining,binding")


# ===========================================================================
# Preventive and curative PST of one transformer
# ===========================================================================

# ---------------------------------------------------------------------------
# 0.1 — reproduction: a curative-only PST must NOT be movable preventively
# ---------------------------------------------------------------------------

def _build_curative_only_pst_scenario():
    """One preventive PST (PRE_PST, no N-X effect) and one PST that has ONLY
    a curative RA (CUR_ONLY_PST, the only PST that can relieve the N-X
    overload). Both are passed in pst_list, exactly as run_pipeline.py does
    today (pst_list = every parsed PST, no kind filter)."""
    pre = _make_pst("PRE_PST", RAKind.PREVENTIVE)
    cur = _make_pst("CUR_ONLY_PST", RAKind.CURATIVE)
    pst_inputs = PstMilpInputs(
        pst_list=[pre, cur],
        pst_tap_bounds={"PRE_PST": (-10, 10), "CUR_ONLY_PST": (-10, 10)},
        pst_group_equality_pairs=[],
        # N-0 sensitivity is preventive-only in the pipeline (n0_sensitivity)
        sensitivity_pst_n0_pruned={("BRANCH1", "PRE_PST"): 0.0},
        pst_degrees_per_tap={"PRE_PST": 1.0, "CUR_ONLY_PST": 1.0},
        penalty_reference_pst_pra=10.0,
    )
    nx_inputs = NxMilpInputs(
        lf_nx={"CO1": {"BRANCH1": {1: 1050.0}}},
        # N-X sensitivity covers BOTH kinds (nx_sensitivity)
        sensitivity_pst_nx={"CO1": {("BRANCH1", "PRE_PST"): 0.0, ("BRANCH1", "CUR_ONLY_PST"): -10.0}},
        sensitivity_rd_nx={},
        penalty_cost_overload_nx_patl=1000.0,
    )
    model = build_n0_milp_model(
        [_make_ae("BRANCH1")], "1030Z", lf_initial={"BRANCH1": {1: 500.0}},
        penalty_cost_overload_n0=1000.0, pst_inputs=pst_inputs, nx_inputs=nx_inputs,
    )
    return model


def test_curative_only_pst_gets_no_preventive_tap_variables():
    """A curative-only PST (CUR_ONLY_PST) gets no preventive tap variables (not in
    model.pst_ids)."""
    model = _build_curative_only_pst_scenario()
    assert "PRE_PST" in list(model.pst_ids)
    assert "CUR_ONLY_PST" not in list(model.pst_ids)


def test_curative_only_pst_cannot_relieve_nx_overload_preventively():
    """The only PST with an N-X effect is curative-only: no preventive action can clear the
    N-X overload, so the overload slack stays at 50 A."""
    model = _build_curative_only_pst_scenario()
    result = pyo.SolverFactory("appsi_highs").solve(model)
    assert str(result.solver.termination_condition) == "optimal"

    preventive_ids = set(model.pst_ids)
    moved_preventively = [
        p for p in preventive_ids
        if abs(pyo.value(model.tap_change_upward[p]) - pyo.value(model.tap_change_downward[p])) > 1e-6
    ]
    assert "CUR_ONLY_PST" not in moved_preventively
    assert pyo.value(model.nx_patl_overload_slack["BRANCH1", "CO1"]) == pytest.approx(50.0, abs=1e-6)


DUAL_RA_PREVENTIVE_PENALTY_FACTOR = 2.0


DUAL_RA_CURATIVE_PENALTY_FACTOR = 5.0


def _dual_ra_pst_list(curative_first: bool = False):
    preventive = _make_pst("DUAL_PST", RAKind.PREVENTIVE, penalty_factor=DUAL_RA_PREVENTIVE_PENALTY_FACTOR)
    curative = _make_pst("DUAL_PST", RAKind.CURATIVE, penalty_factor=DUAL_RA_CURATIVE_PENALTY_FACTOR)
    return [curative, preventive] if curative_first else [preventive, curative]


def _build_dual_ra_n0_model(curative_first: bool):
    """N-0 overload of 100 A on BRANCH1 (1100 A vs 1000 A PATL), relieved only
    by DUAL_PST's PREVENTIVE taps at -10 A per tap -> exactly 10 taps."""
    pst_list = _dual_ra_pst_list(curative_first)
    pst_inputs = PstMilpInputs(
        pst_list=pst_list,
        pst_tap_bounds={"DUAL_PST": (-10, 10)},
        pst_group_equality_pairs=[],
        sensitivity_pst_n0_pruned={("BRANCH1", "DUAL_PST"): -10.0},
        pst_degrees_per_tap={"DUAL_PST": 1.0},
        penalty_reference_pst_pra=PENALTY_REFERENCE,
        max_taps_per_tso=100,
    )
    model = build_n0_milp_model(
        [_make_ae("BRANCH1")], "1030Z", lf_initial={"BRANCH1": {1: 1100.0}},
        penalty_cost_overload_n0=1_000_000.0, pst_inputs=pst_inputs,
    )
    return model, pst_list


@pytest.mark.parametrize("curative_first", [False, True])
def test_dual_ra_transformer_keeps_separate_penalties_per_kind(curative_first):
    """A transformer with both kinds keeps a separate penalty per kind (no dependence on
    list order)."""
    pst_list = _dual_ra_pst_list(curative_first)
    pst_inputs = PstMilpInputs(
        pst_list=pst_list, pst_tap_bounds={}, pst_group_equality_pairs=[],
        sensitivity_pst_n0_pruned={}, pst_degrees_per_tap={},
        penalty_reference_pst_pra=PENALTY_REFERENCE,
    )
    preventive = _get_effective_penalty_costs(pst_inputs.preventive_pst_list, PENALTY_REFERENCE)
    curative = _get_effective_penalty_costs(pst_inputs.curative_pst_list, PENALTY_REFERENCE)
    assert preventive == {"DUAL_PST": 20.0}
    assert curative == {"DUAL_PST": 50.0}


@pytest.mark.parametrize("curative_first", [False, True])
def test_preventive_objective_uses_preventive_penalty_factor_only(curative_first):
    """The preventive objective uses the preventive penalty factor only (200, not 500)."""
    model, _ = _build_dual_ra_n0_model(curative_first)
    result = pyo.SolverFactory("appsi_highs").solve(model)
    assert str(result.solver.termination_condition) == "optimal"
    assert pyo.value(model.tap_change_upward["DUAL_PST"]) == pytest.approx(10.0, abs=1e-6)
    assert pyo.value(model.objective) == pytest.approx(10 * 2.0 * PENALTY_REFERENCE, abs=1e-6)


@pytest.mark.parametrize("curative_first", [False, True])
def test_pst_results_row_uses_the_preventive_ra(curative_first):
    """The PST result row carries the preventive RA's name and penalty_factor."""
    model, pst_list = _build_dual_ra_n0_model(curative_first)
    pst_results, _ = solve_n0_milp_model(
        milp_model=model, pst_list=pst_list, timestamp="1030Z",
        penalty_reference_pst_pra=PENALTY_REFERENCE,
    )
    row = pst_results["DUAL_PST"]
    assert row["pst_penalty_factor"] == DUAL_RA_PREVENTIVE_PENALTY_FACTOR
    assert row["pst_name"].endswith("-preventive")
    assert row["penalty_cost_eur"] == pytest.approx(200.0, abs=1e-6)


@pytest.mark.parametrize("curative_first", [False, True])
def test_results_summary_does_not_double_count_dual_ra_transformer(curative_first):
    """extract_results_summary costs the preventive taps of a transformer with both kinds
    once (200, not 200 + 500)."""
    model, pst_list = _build_dual_ra_n0_model(curative_first)
    pyo.SolverFactory("appsi_highs").solve(model)
    summary = extract_results_summary(
        model, objective_value=pyo.value(model.objective),
        pst_list=pst_list, penalty_reference_pst_pra=PENALTY_REFERENCE,
    )
    assert summary["sum_pst_penalty_cost_eur"] == pytest.approx(200.0, abs=1e-6)


# ---------------------------------------------------------------------------
# 0.4 — the curative PST block must exist with ZERO preventive PSTs
# ---------------------------------------------------------------------------

def _build_curative_only_model():
    cur = _make_pst("CUR_ONLY_PST", RAKind.CURATIVE)
    pst_inputs = PstMilpInputs(
        pst_list=[cur],
        pst_tap_bounds={},
        pst_group_equality_pairs=[],
        sensitivity_pst_n0_pruned={},
        pst_degrees_per_tap={"CUR_ONLY_PST": 1.0},
        penalty_reference_pst_pra=PENALTY_REFERENCE,
    )
    nx_inputs = NxMilpInputs(
        lf_nx={"CO1": {"BRANCH1": {1: 1050.0}}},
        sensitivity_pst_nx={"CO1": {("BRANCH1", "CUR_ONLY_PST"): -10.0}},
        sensitivity_rd_nx={},
        penalty_cost_overload_nx_patl=1000.0,
        pst_cra_availability={("CUR_ONLY_PST", "BRANCH1", "CO1"): {"max_curative_taps": 10, "available": True}},
        pst_tap_bounds_curative={"CUR_ONLY_PST": (-10, 10)},
    )
    model = build_n0_milp_model(
        [_make_ae("BRANCH1")], "1030Z", lf_initial={"BRANCH1": {1: 500.0}},
        penalty_cost_overload_n0=1000.0, pst_inputs=pst_inputs, nx_inputs=nx_inputs,
    )
    return model, pst_inputs


def test_curative_block_exists_without_any_preventive_pst():
    """The curative block is built without any preventive PST (and CUR_ONLY_PST gets no
    preventive variables)."""
    model, _ = _build_curative_only_model()
    assert not hasattr(model, "tap_change_upward")
    assert not hasattr(model, "pst_ids")
    assert ("CUR_ONLY_PST", "CO1") in list(model.curative_pst_contingency_pairs)


def test_curative_only_pst_resolves_nx_overload_via_curative_taps():
    """The N-X curative effect does not need the preventive block."""
    model, _ = _build_curative_only_model()
    result = pyo.SolverFactory("appsi_highs").solve(model)
    assert str(result.solver.termination_condition) == "optimal"
    net = (
        pyo.value(model.curative_tap_change_upward["CUR_ONLY_PST", "CO1"])
        - pyo.value(model.curative_tap_change_downward["CUR_ONLY_PST", "CO1"])
    )
    # net >= 5 taps clears the overload
    assert net >= 5.0 - 1e-6
    assert pyo.value(model.nx_patl_overload_slack["BRANCH1", "CO1"]) == pytest.approx(0.0, abs=1e-6)


def test_solver_and_summary_handle_curative_only_pst_inputs():
    """solve_n0_milp_model / extract_results_summary do not touch preventive variables that
    do not exist."""
    model, pst_inputs = _build_curative_only_model()
    pst_results, overload_slack = solve_n0_milp_model(
        milp_model=model, pst_list=pst_inputs.pst_list, timestamp="1030Z",
        penalty_reference_pst_pra=PENALTY_REFERENCE,
    )
    assert pst_results == {}
    summary = extract_results_summary(
        model, objective_value=pyo.value(model.objective),
        pst_list=pst_inputs.pst_list, penalty_reference_pst_pra=PENALTY_REFERENCE,
    )
    assert summary["sum_pst_penalty_cost_eur"] == 0.0


# ===========================================================================
# PST with an empty tap range
# ===========================================================================

# ---------------------------------------------------------------------------
# PST excluded for an empty tap range
# ---------------------------------------------------------------------------

def _pst_inputs_with_empty_range_pst(pairs=()):
    from milp.milp_builder import PstMilpInputs
    from pre_milp.pst_bounds import build_pst_tap_bounds
    import helpers as T
    good = T._make_pst_mb_scanned("PST_OK")
    bad = T._make_pst_mb_scanned("PST_BAD")
    bad.low_step_relative = 5
    bad.high_step_relative = 2          # effective min 5 > effective max 2
    bounds = build_pst_tap_bounds([good, bad])
    assert "PST_BAD" not in bounds and "PST_OK" in bounds
    return PstMilpInputs(
        pst_list=[good, bad], pst_tap_bounds=bounds, pst_group_equality_pairs=list(pairs),
        sensitivity_pst_n0_pruned={("SEC", "PST_OK"): 5.0, ("SEC", "PST_BAD"): 5.0},
        pst_degrees_per_tap={"PST_OK": 1.5, "PST_BAD": 1.5}, penalty_reference_pst_pra=10.0,
    ), good, bad


def _build_with(pst_inputs):
    from milp.milp_builder import build_n0_milp_model
    import helpers as T
    ae = [T._make_ae_mb_scanned("SEC", AEType.SECURED, 1, 1.0)]
    # 1100 A against a 1000 A limit -> overloaded, the OK PST must move
    return build_n0_milp_model(ae, "1030Z", {"SEC": {1: 1100.0}}, 1000.0, pst_inputs=pst_inputs)


def test_a_pst_with_an_empty_tap_range_builds_and_solves_without_that_pst(caplog):
    from milp.milp_solver import solve_n0_milp_model
    pst_inputs, good, bad = _pst_inputs_with_empty_range_pst()
    with caplog.at_level(logging.WARNING):
        model = _build_with(pst_inputs)
    assert set(model.pst_ids) == {"PST_OK"}
    pst_results, _ = solve_n0_milp_model(model, pst_inputs.pst_list, "1030Z", 10.0)
    assert "PST_BAD" not in pst_results or pst_results["PST_BAD"]["tap_change_result"] == 0


def test_a_group_pair_naming_the_dropped_pst_is_dropped_with_a_warning(caplog):
    pst_inputs, good, bad = _pst_inputs_with_empty_range_pst(pairs=[("PST_OK", "PST_BAD")])
    with caplog.at_level(logging.WARNING):
        model = _build_with(pst_inputs)
    assert len(list(model.pst_group_pairs)) == 0
    assert any("PST_BAD" in r.message and "group" in r.message.lower() for r in caplog.records
               if r.levelno == logging.WARNING)
