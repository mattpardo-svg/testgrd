"""tests/test_rao_sensitivity_table.py - the numpy-backed N-X sensitivity table gives the same keys, values, order and
filter results as the {(branch, variable): value} dict it replaces, and a synthetic pan-European-sized set fits a
memory and time budget (generated data, no real data)."""

import logging
import math
import time
import tracemalloc

import numpy as np
import pandas as pd
import pytest

from pre_milp import nx_sensitivity
from pre_milp.sensitivity_table import SensitivityTable, copy_of, table_from_matrices


def _matrix(branches, variables, rng, nan_at=None, zero_fraction=0.0):
    values = rng.normal(size=(len(variables), len(branches)))
    values[rng.random(values.shape) < zero_fraction] = 0.0
    if nan_at is not None:
        values[nan_at] = math.nan
    return pd.DataFrame(values, index=variables, columns=branches)


def _two_side_blocks(rng, branches1=("b1", "b2", "b3"), branches2=("b4", "b5"), variables=("v1", "v2", "v3", "v4")):
    frames = [_matrix(list(branches1), list(variables), rng, nan_at=(1, 2)), _matrix(list(branches2), list(variables), rng)]
    blocks = [([str(b) for b in f.columns], [str(v) for v in f.index], f.to_numpy()) for f in frames]
    return frames, blocks


def _reference_dict(frames):
    entries = {}
    for frame in frames:
        entries.update(nx_sensitivity._matrix_entries(frame, "C1", "test", "variable"))
    return entries


def test_rao_the_table_has_the_keys_values_and_order_of_the_dict():
    frames, blocks = _two_side_blocks(np.random.default_rng(1))
    table, expected = table_from_matrices(blocks), _reference_dict(frames)
    assert list(table) == list(expected)
    assert len(table) == len(expected)
    for key, value in expected.items():
        got = table[key]
        assert (math.isnan(got) and math.isnan(value)) or got == value
        assert key in table and table.get(key, object()) is not None
    assert list(table.items())[:3] == list(expected.items())[:3]
    assert [v for v in table.values() if v == v] == [v for v in expected.values() if v == v]
    assert ("b9", "v1") not in table and table.get(("b9", "v1"), 0.0) == 0.0 and table.get(("b1", "v9")) is None
    with pytest.raises(KeyError):
        table[("b9", "v1")]


def test_rao_the_table_is_equal_to_the_dict_it_replaces():
    frames, blocks = _two_side_blocks(np.random.default_rng(2))
    frames[0].iloc[1, 2] = 1.5            # no NaN, so that dict equality can hold
    blocks[0] = ([str(b) for b in frames[0].columns], [str(v) for v in frames[0].index], frames[0].to_numpy())
    assert table_from_matrices(blocks) == _reference_dict(frames)
    assert _reference_dict(frames) == table_from_matrices(blocks)


def test_rao_inconsistent_blocks_are_not_a_table():
    rng = np.random.default_rng(3)
    _, blocks = _two_side_blocks(rng)
    assert table_from_matrices([blocks[0], ([*blocks[1][0]], ["v1", "v2", "v3", "other"], blocks[1][2])]) is None   # variables differ
    assert table_from_matrices([blocks[0], (["b1", "b5"], blocks[1][1], blocks[1][2][:, :2])]) is None             # b1 on both sides
    assert table_from_matrices([(["b1", "b1"], blocks[0][1], blocks[0][2][:, :2])]) is None                        # duplicated branch
    assert table_from_matrices([(blocks[0][0], ["v1", "v1", "v3", "v4"], blocks[0][2])]) is None                   # duplicated variable


def test_rao_a_duplicate_label_still_gives_the_dict_with_the_first_value_and_the_warning(caplog):
    frame = pd.DataFrame([[1.0, 2.0], [3.0, 4.0]], index=["v1", "v1"], columns=["b1", "b2"])

    class Result:
        @staticmethod
        def get_sensitivity_matrix(matrix_id, contingency):
            return frame

    with caplog.at_level(logging.WARNING, logger=nx_sensitivity.log.name):
        got = nx_sensitivity._contingency_sensitivities(Result, "C1", {1: "m"}, "f", "variable", {}, {}, None)
    assert isinstance(got, dict) and got == {("b1", "v1"): 1.0, ("b2", "v1"): 2.0}
    # one warning per cell and duplicated row, as before: 2 branches x 2 rows
    assert len([r for r in caplog.records if "returned 2 value(s)" in r.getMessage()]) == 4


def test_rao_the_counting_of_duplicates_is_linear_and_unchanged(caplog):
    # many variables and branches: the old list.count version was quadratic
    variables = [f"v{i}" for i in range(400)]
    branches = [f"b{i}" for i in range(400)]
    frame = pd.DataFrame(np.arange(160000, dtype=float).reshape(400, 400), index=variables, columns=branches)
    start = time.perf_counter()
    entries = nx_sensitivity._matrix_entries(frame, "C1", "f", "variable")
    assert time.perf_counter() - start < 5.0
    assert len(entries) == 160000 and entries[("b3", "v2")] == frame.loc["v2", "b3"]


def _limits_and_currents(rng, branches, contingencies):
    limits = {b: float(rng.uniform(100, 1000)) for b in branches}
    limits["b2"] = 0.0                      # unusable limit
    del limits["b5"]                        # no limit at all
    lf_nx = {c: {b: {1: float(rng.uniform(0, 1500))} for b in branches if b != "b3"} for c in contingencies}
    lf_nx["C1"]["b4"] = {2: 700.0}          # only the other side: used with a warning
    return limits, lf_nx


@pytest.mark.parametrize("min_loading", [0.0, 40.0, 90.0])
def test_rao_filter_1_gives_the_same_entries_for_the_table_and_the_dict(min_loading):
    rng = np.random.default_rng(4)
    frames, blocks = _two_side_blocks(rng)
    table, reference = table_from_matrices(blocks), _reference_dict(frames)
    sides = {"b1": 1, "b2": 1, "b3": 1, "b4": 1, "b5": 1}
    limits, lf_nx = _limits_and_currents(rng, list(sides), ["C1"])
    got = nx_sensitivity._apply_loading_threshold_filter_nx({"C1": table}, lf_nx, sides, limits, min_loading)["C1"]
    expected = nx_sensitivity._apply_loading_threshold_filter_nx({"C1": reference}, lf_nx, sides, limits, min_loading)["C1"]
    assert isinstance(got, SensitivityTable)
    assert list(got) == list(expected)
    assert [(k, v) for k, v in got.items() if v == v] == [(k, v) for k, v in expected.items() if v == v]
    assert len(got) == len(expected)


@pytest.mark.parametrize("threshold_pct", [0.0, 0.2, 1.0, 5.0])
def test_rao_filter_2_gives_the_same_entries_for_the_table_and_the_dict(threshold_pct):
    rng = np.random.default_rng(5)
    frames, blocks = _two_side_blocks(rng)
    table, reference = table_from_matrices(blocks), _reference_dict(frames)
    limits = {"b1": 100.0, "b2": 0.0, "b3": 400.0, "b4": 250.0}          # b2 unusable, b5 without a limit
    got = nx_sensitivity.prune_sensitivity_rd_nx({"C1": table}, limits, threshold_pct)["C1"]
    expected = nx_sensitivity.prune_sensitivity_rd_nx({"C1": reference}, limits, threshold_pct)["C1"]
    assert list(got) == list(expected)
    assert [(k, v) for k, v in got.items() if v == v] == [(k, v) for k, v in expected.items() if v == v]
    assert nx_sensitivity.prune_sensitivity_pst_nx({"C1": table}, limits, threshold_pct)["C1"].keys() == expected.keys()


def test_rao_filter_2_keeps_an_entry_equal_to_the_threshold_and_a_nan():
    base = np.array([[0.5, 0.25, math.nan, 0.2499999999999999]])
    table = table_from_matrices([(["b1"], ["v1", "v2", "v3", "v4"], base.T.copy())])
    got = nx_sensitivity.prune_sensitivity_rd_nx({"C": table}, {"b1": 100.0}, 0.25)["C"]    # threshold 0.25 A
    assert list(got) == [("b1", "v1"), ("b1", "v2"), ("b1", "v3")]
    dict_got = nx_sensitivity.prune_sensitivity_rd_nx({"C": dict(table.items())}, {"b1": 100.0}, 0.25)["C"]
    assert list(dict_got) == list(got)


def test_rao_filter_2_with_threshold_zero_returns_the_same_table_and_without_a_limit_drops_the_branch():
    frames, blocks = _two_side_blocks(np.random.default_rng(6))
    table = table_from_matrices(blocks)
    limits = {b: 100.0 for b in ("b1", "b2", "b3", "b4")}
    kept = nx_sensitivity.prune_sensitivity_pst_nx({"C": table}, limits, 0.0)["C"]
    assert {branch for branch, _ in kept} == {"b1", "b2", "b3", "b4"}        # b5 has no limit
    full = nx_sensitivity.prune_sensitivity_pst_nx({"C": table}, {**limits, "b5": 100.0}, 0.0)["C"]
    assert full is table


def test_rao_all_zero_and_nan_branches_follow_the_definitions_of_the_dict_checks():
    zeros = table_from_matrices([(["b1", "b2"], ["v1", "v2"], np.zeros((2, 2)))])
    assert zeros.all_zero() and bool(zeros) and SensitivityTable((), (), np.zeros((0, 0))).all_zero()
    with_nan = table_from_matrices([(["b1", "b2"], ["v1", "v2"], np.array([[0.0, 0.0], [0.0, math.nan]]))])
    assert not with_nan.all_zero() and with_nan.nan_branches() == {"b2"}
    pruned = nx_sensitivity.prune_sensitivity_rd_nx({"C": with_nan}, {"b1": 1.0, "b2": 1.0}, 1.0)["C"]
    assert pruned.nan_branches() == {"b2"} and len(pruned) == 1               # only the NaN entry survives a threshold


def test_rao_copy_of_keeps_a_table_and_copies_a_dict():
    table = table_from_matrices([(["b1"], ["v1"], np.ones((1, 1)))])
    assert copy_of(table) is table
    source = {("b1", "v1"): 1.0}
    copied = copy_of(source)
    assert copied == source and copied is not source


def test_rao_a_table_cannot_be_changed():
    table = table_from_matrices([(["b1"], ["v1"], np.ones((1, 1)))])
    with pytest.raises(TypeError):
        table[("b1", "v1")] = 2.0


def test_rao_a_synthetic_pan_european_sized_set_fits_the_budget():
    """2000 branches x 300 contingencies x 30 variables = 18 million entries: as dicts about 3 GB, as tables 144 MB.
    Generated, no real data. Budget: peak Python/numpy memory 450 MB, 60 s for build, both filters, the NaN check, the
    zero check and 100000 lookups."""
    rng = np.random.default_rng(7)
    branches = [f"branch{i}" for i in range(2000)]
    variables = [f"unit{i}" for i in range(30)]
    contingencies = [f"C{i}" for i in range(300)]
    limits = {b: 500.0 for b in branches}
    sides = {b: 1 for b in branches}
    lf_nx = {c: {b: {1: 400.0} for b in branches} for c in contingencies}
    tracemalloc.start()
    start = time.perf_counter()
    tables = {}
    for contingency in contingencies:
        values = rng.normal(scale=0.05, size=(len(variables), len(branches)))
        values[3, 17] = math.nan
        tables[contingency] = table_from_matrices([(branches[:1000], variables, values[:, :1000]),
                                                   (branches[1000:], variables, values[:, 1000:])])
    filtered = nx_sensitivity._apply_loading_threshold_filter_nx(tables, lf_nx, sides, limits, 50.0)
    pruned = nx_sensitivity.prune_sensitivity_rd_nx(filtered, limits, 0.01)      # 0.05 A: a share of the entries survives
    nan_count = sum(len(t.nan_branches()) for t in pruned.values())
    zero_count = sum(t.all_zero() for t in pruned.values())
    lookups = sum(pruned["C7"].get((branches[i % 2000], variables[i % 30]), 0.0) != 0.0 for i in range(100000))
    seconds = time.perf_counter() - start
    peak_mb = tracemalloc.get_traced_memory()[1] / 1e6
    tracemalloc.stop()
    print(f"synthetic set: {seconds:.1f} s, peak {peak_mb:.0f} MB, entries kept {sum(len(t) for t in pruned.values())}")
    assert len(tables) == 300 and nan_count == 300 and zero_count == 0 and lookups > 0
    assert 0 < len(pruned["C0"]) < 2000 * 30
    assert peak_mb < 450 and seconds < 60
