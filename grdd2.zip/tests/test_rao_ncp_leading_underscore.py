"""
test_rao_ncp_leading_underscore.py — a leading "_" in the ids and references of the NCP files is ignored.

Some NCP exports write the ids with a leading "_" (rdf:ID="_x", rdf:resource="#_x") and the same id without it in
IdentifiedObject.mRID, or the other way round; the CGM and our other NCP files use ids without it. The parser removes
the first "_" of every id and reference it reads (ncp_parser.ncp_id / _frag, the one place), so the forms below parse
to the same objects and give the same MILP input. No fixture is added: the variants are built in the test from the
shipped standard P and from the HVDC mock.
"""
import csv
import re
import zipfile
from pathlib import Path

import pytest

from helpers import (
    _RA_FOOTER, _RA_HEADER, _MOCK_NX_NCP_ZIP, milp_model_fingerprint_by_family, run_pipeline_on_fixture_inputs,
)
from mock_data.hvdc_mock import EI_SD_BO3, EI_SD_EH1, SVEDALA, build_hvdc_mock_ncp
from pre_milp import hvdc_units, ncp_parser
from text_encoding import TEXT_ENCODING

_RDF_ID = re.compile(r'(rdf:ID=")([^"]*)(")')
_RDF_ABOUT = re.compile(r'(rdf:about="#)([^"]*)(")')
_RDF_RESOURCE = re.compile(r'(rdf:resource="#)([^"]*)(")')
_MRID_LITERAL = re.compile(r"(<[A-Za-z0-9_.:]*mRID>)([^<]*)(</)")


def _form(text: str, how: str) -> str:
    if how == "with":
        return text if text.startswith("_") else "_" + text
    if how == "without":
        return text[1:] if text.startswith("_") else text
    return text


def rewrite_ids(source_zip: Path, dest_zip: Path, ids: str, refs: str, literals: str) -> Path:
    """Copy of an NCP zip with the id of every object (rdf:ID, rdf:about="#..."), every reference
    (rdf:resource="#...") and every IdentifiedObject.mRID literal written with ("with"), without ("without") or as it is
    ("keep") a leading "_". Only "#" references are changed (urn: and http: values are not ids)."""
    with zipfile.ZipFile(source_zip) as source, zipfile.ZipFile(dest_zip, "w") as out:
        for item in source.infolist():
            data = source.read(item.filename)
            if item.filename.endswith(".xml"):
                text = data.decode("utf-8")
                if ids == "without":   # an rdf:ID cannot start with a digit (NCName): the same id as rdf:about="#..."
                    text = _RDF_ID.sub(lambda m: 'rdf:about="#' + _form(m.group(2), ids) + m.group(3), text)
                text = _RDF_ID.sub(lambda m: m.group(1) + _form(m.group(2), ids) + m.group(3), text)
                text = _RDF_ABOUT.sub(lambda m: m.group(1) + _form(m.group(2), ids) + m.group(3), text)
                text = _RDF_RESOURCE.sub(lambda m: m.group(1) + _form(m.group(2), refs) + m.group(3), text)
                text = _MRID_LITERAL.sub(lambda m: m.group(1) + _form(m.group(2), literals) + m.group(3), text)
                data = text.encode("utf-8")
            out.writestr(item.filename, data)
    return dest_zip


# (ids, refs, literals): the id and the reference written differently is the mixed case
VARIANTS = {
    "mrid_literals_with_underscore": ("keep", "keep", "with"),
    "everything_without_underscore": ("without", "without", "without"),
    "ids_without_refs_with": ("without", "with", "with"),
    "ids_with_refs_without": ("with", "without", "without"),
}


# ---------------------------------------------------------------------------
# (d) the helper itself: what is removed, what is not
# ---------------------------------------------------------------------------

class TestNcpId:
    @pytest.mark.parametrize("text, expected", [
        ("#_adcbb277-4ef5-22b8-4957-2cc29d68dc6a", "adcbb277-4ef5-22b8-4957-2cc29d68dc6a"),
        ("#adcbb277-4ef5-22b8-4957-2cc29d68dc6a", "adcbb277-4ef5-22b8-4957-2cc29d68dc6a"),
        ("_adcbb277-4ef5-22b8-4957-2cc29d68dc6a", "adcbb277-4ef5-22b8-4957-2cc29d68dc6a"),
        ("urn:uuid:adcbb277-4ef5-22b8-4957-2cc29d68dc6a", "adcbb277-4ef5-22b8-4957-2cc29d68dc6a"),
        ("urn:uuid:_adcbb277-4ef5-22b8-4957-2cc29d68dc6a", "adcbb277-4ef5-22b8-4957-2cc29d68dc6a"),
        ("urn:test#_RA_1", "RA_1"),
    ])
    def test_the_leading_underscore_and_the_wrapper_are_removed(self, text, expected):
        assert ncp_parser.ncp_id(text) == expected
        assert ncp_parser._frag(text) == expected

    @pytest.mark.parametrize("text", ["RA1", "#RA1", "RA_1", "#RA_1_x", "a_b_c", "#abc_"])
    def test_an_id_without_a_leading_underscore_is_unchanged(self, text):
        assert ncp_parser.ncp_id(text) == text.lstrip("#")
        assert ncp_parser._frag(text) == text.lstrip("#")

    def test_only_one_underscore_is_removed(self):
        assert ncp_parser.ncp_id("__x") == "_x"
        assert ncp_parser._frag("#__x") == "_x"


# ---------------------------------------------------------------------------
# (a) the shipped standard P: the same parsed objects and the same MILP input
# ---------------------------------------------------------------------------

_RECORDED = (
    ("ncp_parser", "parse_assessed_elements"), ("ncp_parser", "parse_contingencies"), ("ncp_parser", "parse_psts"),
    ("ncp_parser", "parse_rd_units"), ("ncp_parser", "parse_unit_costs"), ("ncp_parser", "parse_ra_groups"),
    ("ct_units", "parse_ct_remedial_actions"), ("ct_units", "parse_bidding_zones"),
    ("ncp_parser", "parse_hvdc_units"), ("ncp_parser", "parse_balanced_ra_groups"),
)


def _run_recorded(work: Path, ncp_zip: Path, ra_types, mode="ac_single_pass"):
    """One pipeline run; returns ({reader name: [return value per call]}, [MILP fingerprints], output dir)."""
    records: dict = {}
    models: list = []

    def customize(rp, monkeypatch):
        for module_name, function_name in _RECORDED:
            owner = getattr(rp, module_name)
            original = getattr(owner, function_name)

            def wrapper(*args, _original=original, _name=function_name, **kwargs):
                value = _original(*args, **kwargs)
                records.setdefault(_name, []).append(value)
                return value

            monkeypatch.setattr(owner, function_name, wrapper)
        import milp.ac_convergence_loop as loop
        for owner in (loop, rp.single_pass, rp.dc_pass):
            original_build = getattr(owner, "build_n0_milp_model", None)
            if original_build is None:
                continue

            def recording_build(*args, _original=original_build, **kwargs):
                model = _original(*args, **kwargs)
                models.append(model)
                return model

            monkeypatch.setattr(owner, "build_n0_milp_model", recording_build)

    result = run_pipeline_on_fixture_inputs(
        work, ncp_zip, enable_nx_analysis=True, ra_types=ra_types, calculation_mode=mode, customize_pipeline=customize,
    )
    records["glsk"] = result.records.glsk_results_per_tso
    fingerprints = [milp_model_fingerprint_by_family(m) for m in models]
    return records, fingerprints, result.output_dir


@pytest.fixture(scope="module")
def reference_run(tmp_path_factory):
    work = tmp_path_factory.mktemp("underscore_reference")
    return _run_recorded(work / "run", _MOCK_NX_NCP_ZIP, ("pst", "rd", "countertrade"))


class TestShippedPWithLeadingUnderscores:
    @pytest.mark.parametrize("variant", sorted(VARIANTS))
    def test_the_parsed_objects_and_the_milp_input_are_the_same(self, variant, reference_run, tmp_path):
        ids, refs, literals = VARIANTS[variant]
        zip_path = rewrite_ids(_MOCK_NX_NCP_ZIP, tmp_path / "ncp.zip", ids, refs, literals)
        expected_records, expected_fingerprints, expected_out = reference_run
        records, fingerprints, out = _run_recorded(tmp_path / "run", zip_path, ("pst", "rd", "countertrade"))
        assert set(records) == set(expected_records)
        for name in sorted(expected_records):
            assert records[name] == expected_records[name], f"{name} differs for {variant}"
        assert fingerprints == expected_fingerprints
        assert len(fingerprints) > 0
        for name in ("results_pst.csv", "results_summary.csv"):
            assert (out / name).read_bytes() == (expected_out / name).read_bytes(), name

    def test_the_variants_really_differ_from_the_shipped_files(self, tmp_path):
        with zipfile.ZipFile(_MOCK_NX_NCP_ZIP) as original:
            shipped = original.read("Espheim_RA.xml").decode("utf-8")
        for variant in ("mrid_literals_with_underscore", "everything_without_underscore"):
            ids, refs, literals = VARIANTS[variant]
            with zipfile.ZipFile(rewrite_ids(_MOCK_NX_NCP_ZIP, tmp_path / f"{variant}.zip", ids, refs, literals)) as z:
                assert z.read("Espheim_RA.xml").decode("utf-8") != shipped, variant


# ---------------------------------------------------------------------------
# (b), (c) HVDC: one balanced group of two units on the two EIs, usable in a run
# ---------------------------------------------------------------------------

def _hvdc_zip(tmp_path: Path, name: str, ids: str, refs: str, literals: str) -> Path:
    plain = build_hvdc_mock_ncp(tmp_path / "hvdc_plain.zip")
    return rewrite_ids(plain, tmp_path / name, ids, refs, literals)


def _read_ra(zip_path: Path, tmp_path: Path, name: str) -> Path:
    path = tmp_path / f"{name}_{SVEDALA}_RA.xml"
    with zipfile.ZipFile(zip_path) as z:
        path.write_bytes(z.read(f"{SVEDALA}_RA.xml"))
    return path


class TestHvdcWithLeadingUnderscores:
    @pytest.mark.parametrize("variant", sorted(VARIANTS))
    def test_two_units_form_one_balanced_group_on_the_two_eis(self, variant, tmp_path):
        ra_path = _read_ra(_hvdc_zip(tmp_path, "hvdc.zip", *VARIANTS[variant]), tmp_path, variant)
        units = ncp_parser.parse_hvdc_units(ra_path, "TSO-Svedala")
        groups = ncp_parser.parse_balanced_ra_groups(ra_path, "TSO-Svedala")
        assert sorted(u.ei_mrid for u in units) == sorted([EI_SD_EH1, EI_SD_BO3])
        assert all(not u.mrid.startswith("_") for u in units)
        usable_units, usable_groups = hvdc_units.validate_hvdc_structure(units, groups)
        assert len(usable_units) == 2
        assert len(usable_groups) == 1
        assert sorted(usable_groups[0].ra_mrids) == sorted(u.mrid for u in usable_units)

    def test_the_run_uses_both_units_and_gives_the_same_result_as_the_plain_form(self, tmp_path):
        plain = build_hvdc_mock_ncp(tmp_path / "hvdc_plain.zip")
        underscore = _hvdc_zip(tmp_path, "hvdc_underscore.zip", "keep", "keep", "with")
        outputs = []
        for label, zip_path in (("plain", plain), ("underscore", underscore)):
            result = run_pipeline_on_fixture_inputs(
                tmp_path / label, zip_path, enable_nx_analysis=False, ra_types=("hvdc",), calculation_mode="ac_single_pass",
            )
            with open(result.output_dir / "results_hvdc.csv", encoding=TEXT_ENCODING) as handle:
                outputs.append(list(csv.DictReader(handle)))
        assert len(outputs[1]) == 2
        assert outputs[0] == outputs[1]


# ---------------------------------------------------------------------------
# (c) mixed forms on a small hand-made RA file
# ---------------------------------------------------------------------------

def _mixed_ra_file(tmp_path: Path, ra_id: str, literal: str, ra_ref: str, ei_ref: str, group_ref: str, name: str) -> Path:
    body = f"""
    <nc:GridStateAlterationRemedialAction rdf:ID="{ra_id}">
      <cim:IdentifiedObject.mRID>{literal}</cim:IdentifiedObject.mRID>
      <nc:RemedialAction.normalAvailable>true</nc:RemedialAction.normalAvailable>
      <nc:RemedialAction.kind rdf:resource="https://cim4.eu/ns/nc#RemedialActionKind.preventive"/>
    </nc:GridStateAlterationRemedialAction>
    <nc:EquivalentInjectionAction rdf:ID="ACT_1">
      <nc:GridStateAlteration.GridStateAlterationRemedialAction rdf:resource="#{ra_ref}"/>
      <nc:EquivalentInjectionAction.EquivalentInjection rdf:resource="#{ei_ref}"/>
      <nc:GridStateAlteration.PropertyReference rdf:resource="https://energy.referencedata.eu/PropertyReference/EquivalentInjection.p"/>
    </nc:EquivalentInjectionAction>
    <nc:RemedialActionGroup rdf:ID="{group_ref}">
      <cim:IdentifiedObject.mRID>{'_' if literal.startswith('_') else ''}G1</cim:IdentifiedObject.mRID>
    </nc:RemedialActionGroup>
    <nc:RemedialActionDependency rdf:ID="DEP_1">
      <nc:RemedialActionDependency.kind rdf:resource="https://cim4.eu/ns/nc#RemedialActionDependencyKind.balanced"/>
      <nc:RemedialActionDependency.RemedialActionGroup rdf:resource="#{group_ref}"/>
      <nc:RemedialActionDependency.RemedialAction rdf:resource="#{ra_ref}"/>
    </nc:RemedialActionDependency>"""
    path = tmp_path / name
    path.write_text(_RA_HEADER + body + _RA_FOOTER, encoding=TEXT_ENCODING)
    return path


class TestMixedForms:
    @pytest.mark.parametrize("ra_id, literal, ra_ref, ei_ref", [
        ("_RA1", "_RA1", "RA1", "EI1"),     # the id and the mRID have "_", the reference has none
        ("RA1", "RA1", "_RA1", "_EI1"),     # the id and the mRID have none, the reference has "_"
        ("RA1", "_RA1", "_RA1", "_EI1"),    # only the mRID has "_"
        ("RA1", "_RA1", "RA1", "EI1"),      # only the mRID has "_", the references have none
        ("_RA1", "_RA1", "_RA1", "_EI1"),
        ("RA1", "RA1", "RA1", "EI1"),
    ])
    def test_a_reference_resolves_whatever_form_the_id_has(self, tmp_path, ra_id, literal, ra_ref, ei_ref):
        path = _mixed_ra_file(tmp_path, ra_id, literal, ra_ref, ei_ref, "_G1" if ra_id.startswith("_") else "G1", "mixed_RA.xml")
        units = ncp_parser.parse_hvdc_units(path, "TSO-X")
        groups = ncp_parser.parse_balanced_ra_groups(path, "TSO-X")
        assert [(u.mrid, u.ei_mrid) for u in units] == [("RA1", "EI1")]
        assert [(g.mrid, g.ra_mrids) for g in groups] == [("G1", ["RA1"])]
