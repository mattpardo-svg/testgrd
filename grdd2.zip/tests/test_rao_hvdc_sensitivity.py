"""
test_rao_hvdc_sensitivity.py — the sensitivities of HVDC units (docs/specs/hvdc_ra_specs.md H4.3, H8):
the EI pair of the mock (Injection_SD_EH1 +x / Injection_SD_BO3 -x) against a finite difference of
the load flow (AC and DC, N-0 and meshed N-1), the solved-network check, the silent-zero guard, the
last-valid stores and the mock NCP.
"""
import logging
import zipfile
from types import SimpleNamespace

import numpy as np
import pytest

import run_pipeline
from data_model import AEType, AssessedElement, Contingency, ContingencyType, HvdcUnit, RAKind
from helpers import _MOCK_NX_CGM_ZIP
from mock_data.hvdc_mock import (
    EI_SD_BO3, EI_SD_EH1, P0_SD_BO3, P0_SD_EH1, SVEDALA, XNE_BRANCH, build_hvdc_mock_ncp, default_groups, default_ras,
)
from pre_milp import cgmes_loader, hvdc_units, ncp_parser, n0_sensitivity, nx_sensitivity, sensitivity_checks
from pre_milp.dc_conversion import DcCurrentConverter
from pre_milp.lf_parameters import build_loadflow_parameters
from pre_milp.nx_security_analysis import compute_lf_nx
from milp.operating_point_state import OperatingPointState
from text_encoding import TEXT_ENCODING

TS = "1030Z"
STEP_MW = 20.0
# meshed contingencies whose outage leaves both EIs connected (checked against the finite difference)
CO_SD_BO2, CO_ESPHEIM_SVEDALA, CO_SD_BO3_B = (
    "7e253493-0bb4-4306-95b3-374075834b98", "b85e5fb8-7e2b-4264-a059-edab9a838116", "d9622e7f-5bf0-4e7e-b766-b8596c6fe4ae",
)
# both circuits that connect the bus of Injection_SD_BO3: together they island the unit
CO_ISLAND = ("536f4b84-db4c-4545-96e9-bb5a87f65d13", CO_SD_BO3_B)
# an EquivalentInjection in a small island (synchronous component 2): "EI NH-GA HVDC side"
EI_OUTSIDE = "471d1e90-5fb2-45f7-ba23-9ea6cf67bcde"


def _unit(mrid, ei, group="G", kind=RAKind.PREVENTIVE):
    return HvdcUnit(mrid=mrid, name=mrid, tso="TSO-Svedala", ei_mrid=ei, available=True, kind=kind,
                    penalty_factor=1.0, group_mrid=group)


def _contingency(mrid, equipment):
    return Contingency(mrid=mrid, name=mrid, tso="TSO-Svedala", contingency_type=ContingencyType.ORDINARY,
                       must_study={TS: True}, equipment_mrids=list(equipment), equipment_types=["line"] * len(equipment))


def _load_with_lf():
    network = cgmes_loader.load_cgm(_MOCK_NX_CGM_ZIP)
    cgmes_loader.run_initial_loadflow(network, run_pipeline.USE_REACTIVE_LIMITS, run_pipeline.EXTRA_LF_PARAMS)
    return network


def _run_lf(network, dc=False):
    parameters = build_loadflow_parameters(run_pipeline.USE_REACTIVE_LIMITS, run_pipeline.EXTRA_LF_PARAMS)
    import pypowsybl as pp
    result = (pp.loadflow.run_dc if dc else pp.loadflow.run_ac)(network, parameters=parameters)
    assert "CONVERGED" in str(result[0].status)


@pytest.fixture(scope="module")
def env():
    network = _load_with_lf()
    lf_initial = cgmes_loader.build_lf_initial(network)
    branches = sorted(b for b, sides in lf_initial.items() if all(v == v for v in sides.values()))
    ae_flat_list = [
        AssessedElement(mrid=f"AE-{b}", name=b, tso="TSO-Svedala", ae_type=AEType.SECURED, branch_mrid=b,
                        secured_for_region=None, scanned_for_region=None, exclusion_reason=None,
                        patl_ka={TS: 100.0}, branch_side=1)
        for b in branches
    ]
    contingencies = [_contingency(co, [co]) for co in (CO_SD_BO2, CO_ESPHEIM_SVEDALA, CO_SD_BO3_B)]
    contingencies.append(_contingency("CO-ISLAND", CO_ISLAND))
    return SimpleNamespace(network=network, lf_initial=lf_initial, ae_flat_list=ae_flat_list, contingencies=contingencies,
                           branches=branches)


def _dc_converter(network):
    return DcCurrentConverter.from_network(network, 1.0, {"default": 1.0})


def _finite_difference(equipment_out, dc=False):
    """{branch: (A per MW, current before)} (dc: the converter's A) of the side-1 current of every branch for the pair
    Injection_SD_EH1 +x / Injection_SD_BO3 -x, from two load flows of the network with `equipment_out`
    (line mRIDs) disconnected."""
    def currents(shift):
        network = cgmes_loader.load_cgm(_MOCK_NX_CGM_ZIP)
        for line in equipment_out:
            network.update_lines(id=line, connected1=False, connected2=False)
        network.update_generators(id=EI_SD_EH1, target_p=P0_SD_EH1 + shift)
        network.update_generators(id=EI_SD_BO3, target_p=P0_SD_BO3 - shift)
        _run_lf(network, dc)
        return cgmes_loader.build_lf_initial(network, _dc_converter(network) if dc else None)

    before, after = currents(0.0), currents(STEP_MW)
    return {
        b: ((after[b][1] - before[b][1]) / STEP_MW, before[b][1])
        for b in before if after[b][1] == after[b][1] and before[b][1] == before[b][1]
    }


def _agreement(sensitivity, finite_difference, excluded=()):
    """(number of significant branches, relative errors) of S(g1) - S(g2) against the finite difference,
    for the branches with |fd| > 0.05 A/MW whose current cannot change sign within the step (a current is |I|:\n    near zero the finite difference does not measure the signed sensitivity)."""
    errors = []
    for branch, (fd, before) in finite_difference.items():
        if branch in excluded or abs(fd) <= 0.05 or before < 1.5 * abs(fd) * STEP_MW:
            continue
        combined = sensitivity[(branch, EI_SD_EH1)] - sensitivity[(branch, EI_SD_BO3)]
        errors.append(abs(combined - fd) / abs(fd))
    return len(errors), errors


# ---------------------------------------------------------------------------
# finite-difference checks
# ---------------------------------------------------------------------------

class TestN0AgainstFiniteDifference:
    def test_ac_pair_matches_the_load_flow(self, env):
        sensitivity = n0_sensitivity.compute_sensitivity_hvdc_n0(
            env.network, [EI_SD_EH1, EI_SD_BO3], env.ae_flat_list, TS, lf_initial=env.lf_initial,
            use_reactive_limits=run_pipeline.USE_REACTIVE_LIMITS, extra_lf_params=run_pipeline.EXTRA_LF_PARAMS,
        )
        count, errors = _agreement(sensitivity, _finite_difference(()))
        assert count >= 5
        assert np.median(errors) < 0.05 and max(errors) < 0.10

    def test_the_pair_acts_on_the_mock_xne_with_about_minus_2_2_a_per_mw(self, env):
        sensitivity = n0_sensitivity.compute_sensitivity_hvdc_n0(
            env.network, [EI_SD_EH1, EI_SD_BO3], env.ae_flat_list, TS, lf_initial=env.lf_initial,
            use_reactive_limits=run_pipeline.USE_REACTIVE_LIMITS, extra_lf_params=run_pipeline.EXTRA_LF_PARAMS,
        )
        pair = {b: sensitivity[(b, EI_SD_EH1)] - sensitivity[(b, EI_SD_BO3)] for b in env.branches}
        strongest = max(pair, key=lambda b: abs(pair[b]))
        assert strongest == XNE_BRANCH
        assert pair[XNE_BRANCH] == pytest.approx(-2.196, abs=0.05)

    def test_dc_pair_matches_the_dc_load_flow(self, env):
        converter = _dc_converter(env.network)
        network = cgmes_loader.load_cgm(_MOCK_NX_CGM_ZIP)
        _run_lf(network, dc=True)
        lf_initial_dc = cgmes_loader.build_lf_initial(network, converter)
        sensitivity = n0_sensitivity.compute_sensitivity_hvdc_n0(
            network, [EI_SD_EH1, EI_SD_BO3], env.ae_flat_list, TS, lf_initial=lf_initial_dc,
            use_reactive_limits=run_pipeline.USE_REACTIVE_LIMITS, extra_lf_params=run_pipeline.EXTRA_LF_PARAMS,
            dc_converter=converter,
        )
        count, errors = _agreement(sensitivity, _finite_difference((), dc=True))
        assert count >= 5
        assert max(errors) < 0.02


def _nx_sensitivity(env, dc=False, contingencies=None):
    converter = _dc_converter(env.network) if dc else None
    network = env.network
    if dc:
        network = cgmes_loader.load_cgm(_MOCK_NX_CGM_ZIP)
        _run_lf(network, dc=True)
    lf_initial = cgmes_loader.build_lf_initial(network, converter)
    contingencies = env.contingencies if contingencies is None else contingencies
    lf_nx, _skipped = compute_lf_nx(
        network, contingencies, env.ae_flat_list, TS, lf_initial=lf_initial,
        use_reactive_limits=run_pipeline.USE_REACTIVE_LIMITS, extra_lf_params=run_pipeline.EXTRA_LF_PARAMS,
        dc_converter=converter,
    )
    hvdc_out = {}
    nx_sensitivity.compute_sensitivities_nx(
        network, contingencies, [], [], env.ae_flat_list, TS, lf_nx, lf_initial, with_pst=False, with_rd=False,
        use_reactive_limits=run_pipeline.USE_REACTIVE_LIMITS, extra_lf_params=run_pipeline.EXTRA_LF_PARAMS,
        dc_converter=converter, hvdc_ei_mrids=[EI_SD_EH1, EI_SD_BO3], hvdc_out=hvdc_out,
    )
    return hvdc_out


@pytest.fixture(scope="module")
def nx_ac(env):
    return _nx_sensitivity(env)


@pytest.fixture(scope="module")
def nx_dc(env):
    return _nx_sensitivity(env, dc=True)


class TestN1AgainstFiniteDifference:
    @pytest.mark.parametrize("contingency", [CO_SD_BO2, CO_ESPHEIM_SVEDALA, CO_SD_BO3_B])
    def test_ac_pair_matches_the_post_contingency_load_flow(self, env, nx_ac, contingency):
        sensitivity = nx_ac["sensitivity"][contingency]
        count, errors = _agreement(sensitivity, _finite_difference((contingency,)), excluded=(contingency,))
        assert count >= 3
        assert np.median(errors) < 0.06

    @pytest.mark.parametrize("contingency", [CO_SD_BO2, CO_ESPHEIM_SVEDALA, CO_SD_BO3_B])
    def test_dc_pair_matches_the_post_contingency_dc_load_flow(self, env, nx_dc, contingency):
        sensitivity = nx_dc["sensitivity"][contingency]
        count, errors = _agreement(sensitivity, _finite_difference((contingency,), dc=True), excluded=(contingency,))
        assert count >= 3
        assert max(errors) < 0.05

    def test_every_hvdc_set_has_both_units_for_every_contingency_with_a_load_flow(self, nx_ac):
        for contingency, entries in nx_ac["sensitivity"].items():
            units = {unit for (_branch, unit) in entries}
            assert units <= {EI_SD_EH1, EI_SD_BO3}
            assert units, contingency


# ---------------------------------------------------------------------------
# guards
# ---------------------------------------------------------------------------

class TestSolvedNetworkCheck:
    def test_units_in_the_main_network_are_in_the_solved_network(self, env):
        units = [_unit("A", EI_SD_EH1), _unit("B", EI_SD_BO3)]
        data = hvdc_units.read_unit_network_data(env.network, units)
        assert data[EI_SD_EH1]["p0"] == pytest.approx(P0_SD_EH1, abs=1e-3)
        assert data[EI_SD_BO3]["p0"] == pytest.approx(P0_SD_BO3, abs=1e-3)
        assert all(info["in_solved_network"] and info["connected"] for info in data.values())
        assert data[EI_SD_EH1]["min_p"] < -1e300 and data[EI_SD_EH1]["max_p"] > 1e300   # the CGM gives no limits
        hvdc_units.check_units_in_solved_network(units, data)

    def test_a_unit_in_an_island_is_an_error_naming_unit_ei_and_partner(self, env):
        units = [_unit("A", EI_SD_EH1), _unit("OUT", EI_OUTSIDE)]
        data = hvdc_units.read_unit_network_data(env.network, units)
        assert data[EI_OUTSIDE]["in_solved_network"] is False
        with pytest.raises(ValueError, match=f"OUT.*{EI_OUTSIDE}.*outside the solved main network.*partner \\['A'\\]"):
            hvdc_units.check_units_in_solved_network(units, data)

    def test_a_disconnected_unit_is_an_error(self):
        """A fake network: pypowsybl cannot open a feeder that has no breaker."""
        import pandas as pd

        generators = pd.DataFrame(
            {"name": ["g"], "target_p": [10.0], "min_p": [-1e308], "max_p": [1e308], "connected": [False],
             "bus_id": [""], "CGMES.originalClass": ["EquivalentInjection"]}, index=["ei-1"],
        )
        buses = pd.DataFrame({"synchronous_component": [0]}, index=["bus-1"])
        network = SimpleNamespace(get_generators=lambda all_attributes=True: generators,
                                  get_buses=lambda all_attributes=True: buses)
        units = [_unit("A", "ei-1")]
        data = hvdc_units.read_unit_network_data(network, units)
        assert data["ei-1"]["connected"] is False and data["ei-1"]["in_solved_network"] is False
        with pytest.raises(ValueError, match="A.*not connected"):
            hvdc_units.check_units_in_solved_network(units, data)
    def test_pypowsybl_flips_the_set_point_of_an_ei_but_copies_its_min_p_and_max_p_unchanged(self, tmp_path):
        """What H3.2 receives (docs/specs/hvdc_ra_specs.md H3.2, open question on the sign of minP/maxP): Injection_SD_BO3 with
        EQ minP -30 / maxP 80 added. The SSH EquivalentInjection.p (load sign) is negated into target_p (generation
        sign), minP / maxP reach min_p / max_p as written, and resolve_operating_limits takes them literally."""
        with zipfile.ZipFile(_MOCK_NX_CGM_ZIP) as source, zipfile.ZipFile(tmp_path / "cgm.zip", "w") as target:
            for item in source.infolist():
                data = source.read(item.filename)
                if item.filename.endswith("__Svedala_EQ_1.xml"):
                    text = data.decode("utf-8")
                    end = text.index("</cim:EquivalentInjection>", text.index(f'rdf:ID="_{EI_SD_BO3}"'))
                    data = (text[:end] + "<cim:EquivalentInjection.minP>-30</cim:EquivalentInjection.minP>"
                            "<cim:EquivalentInjection.maxP>80</cim:EquivalentInjection.maxP>" + text[end:]).encode("utf-8")
                target.writestr(item.filename, data)
        network = cgmes_loader.load_cgm(tmp_path / "cgm.zip")
        unit = _unit("B", EI_SD_BO3)
        data = hvdc_units.read_unit_network_data(network, [unit])[EI_SD_BO3]
        assert data["p0"] == pytest.approx(P0_SD_BO3, abs=1e-6)                 # SSH p = -1.55864 -> +1.55864
        assert (data["min_p"], data["max_p"]) == (-30.0, 80.0)                   # not negated
        assert hvdc_units.resolve_operating_limits(unit, data["p0"], data["min_p"], data["max_p"], ranges=[]) == (-30.0, 80.0)

    def test_an_ei_that_is_not_in_the_cgm_is_an_error(self, env):
        with pytest.raises(ValueError, match="not in the CGM.*U1 -> no-such-ei"):
            hvdc_units.read_unit_network_data(env.network, [_unit("U1", "no-such-ei")])

    def test_a_non_ei_generator_is_used_with_a_warning(self, env, caplog):
        synchronous_machine = next(
            g for g, row in env.network.get_generators(all_attributes=True).iterrows()
            if row["CGMES.originalClass"] == "SynchronousMachine"
        )
        with caplog.at_level(logging.WARNING):
            hvdc_units.read_unit_network_data(env.network, [_unit("U1", synchronous_machine)])
        assert any("not an EquivalentInjection" in r.message for r in caplog.records)


class TestSilentZeroGuard:
    def test_n0_unit_outside_the_solved_network_is_an_error_naming_it(self, env):
        with pytest.raises(ValueError, match=f"{EI_OUTSIDE}.*exactly zero"):
            n0_sensitivity.compute_sensitivity_hvdc_n0(
                env.network, [EI_SD_EH1, EI_OUTSIDE], env.ae_flat_list, TS, lf_initial=env.lf_initial,
                use_reactive_limits=run_pipeline.USE_REACTIVE_LIMITS, extra_lf_params=run_pipeline.EXTRA_LF_PARAMS,
            )

    def test_n0_guard_does_not_touch_the_rd_function(self, env):
        """The same zero rows through the RD function are returned silently, as before."""
        rd_unit = SimpleNamespace(available=True, kind=RAKind.PREVENTIVE, gu_mrid=EI_OUTSIDE)
        sensitivity = n0_sensitivity.compute_sensitivity_rd_n0(
            env.network, [rd_unit], env.ae_flat_list, TS, lf_initial=env.lf_initial,
            use_reactive_limits=run_pipeline.USE_REACTIVE_LIMITS, extra_lf_params=run_pipeline.EXTRA_LF_PARAMS,
        )
        assert all(v == 0.0 for v in sensitivity.values())

    def test_nx_isolating_contingency_makes_the_unit_unavailable_there_only(self, nx_ac):
        assert nx_ac["zero_units"] == {"CO-ISLAND": [EI_SD_BO3]}

    def test_nx_isolated_unit_does_not_invalidate_the_contingency_for_the_reference_guard(self, nx_ac):
        assert "CO-ISLAND" not in nx_ac["guard"]

    def test_nx_zero_unit_is_logged(self, env, caplog):
        with caplog.at_level(logging.WARNING):
            _nx_sensitivity(env, contingencies=[env.contingencies[-1]])
        assert any("exactly zero" in r.message and EI_SD_BO3 in r.message for r in caplog.records)


# ---------------------------------------------------------------------------
# the last-valid stores
# ---------------------------------------------------------------------------

def _set(value):
    return {("b1", "ei"): value}


class TestLastValidStores:
    def test_nx_fresh_hvdc_set_is_stored_and_returned(self):
        store, result = {}, {}
        pst, rd, source, failure = sensitivity_checks.resolve_nx(
            {}, {}, {}, {"c1": {}}, store, {"b1"}, set(), set(),
            fresh_hvdc={"c1": _set(1.5)}, allowed_hvdc={"ei"}, hvdc_result=result,
        )
        assert failure is None and source == {"c1": sensitivity_checks.FRESH}
        assert result == {"c1": _set(1.5)} and store["c1"]["hvdc"] == _set(1.5)

    def test_nx_invalid_contingency_gets_the_last_valid_hvdc_set(self):
        store, result = {}, {}
        sensitivity_checks.resolve_nx({}, {}, {}, {"c1": {}}, store, {"b1"}, set(), set(),
                                      fresh_hvdc={"c1": _set(1.5)}, allowed_hvdc={"ei"}, hvdc_result=result)
        pst, rd, source, failure = sensitivity_checks.resolve_nx(
            {}, {}, {"c1": "bad"}, {"c1": {}}, store, {"b1"}, set(), set(),
            fresh_hvdc={"c1": _set(0.0)}, allowed_hvdc={"ei"}, hvdc_result=result,
        )
        assert failure is None and source == {"c1": sensitivity_checks.STALE_REUSED}
        assert result == {"c1": _set(1.5)}

    def test_nx_stored_hvdc_key_that_is_no_longer_available_stops_the_loop(self):
        store, result = {}, {}
        sensitivity_checks.resolve_nx({}, {}, {}, {"c1": {}}, store, {"b1"}, set(), set(),
                                      fresh_hvdc={"c1": _set(1.5)}, allowed_hvdc={"ei"}, hvdc_result=result)
        *_, failure = sensitivity_checks.resolve_nx(
            {}, {}, {"c1": "bad"}, {"c1": {}}, store, {"b1"}, set(), set(),
            fresh_hvdc={"c1": {}}, allowed_hvdc=set(), hvdc_result=result,
        )
        assert failure is not None and "ei is no longer available" in failure

    def test_nx_without_hvdc_stores_and_returns_exactly_what_it_did_before(self):
        store = {}
        out = sensitivity_checks.resolve_nx({"c1": {("b1", "p"): 1.0}}, {}, {}, {"c1": {}}, store, {"b1"}, {"p"}, set())
        assert out == ({"c1": {("b1", "p"): 1.0}}, {}, {"c1": sensitivity_checks.FRESH}, None)
        assert store == {"c1": {"pst": {("b1", "p"): 1.0}, "rd": {}}}

    def test_n0_hvdc_store_and_stale_reuse(self):
        store_pst, store_rd, store_hvdc, result = {}, {}, {}, {}
        sensitivity_checks.resolve_n0({}, {}, {}, {"b1"}, store_pst, store_rd, {"b1"}, set(), set(),
                                      fresh_hvdc=_set(2.0), store_hvdc=store_hvdc, allowed_hvdc={"ei"}, hvdc_result=result)
        assert result == _set(2.0) and store_hvdc == {"b1": _set(2.0)}
        pst, rd, stale, failure = sensitivity_checks.resolve_n0(
            {}, {}, {"b1": "bad"}, {"b1"}, store_pst, store_rd, {"b1"}, set(), set(),
            fresh_hvdc=_set(0.0), store_hvdc=store_hvdc, allowed_hvdc={"ei"}, hvdc_result=result,
        )
        assert failure is None and stale == {"b1": sensitivity_checks.STALE_REUSED} and result == _set(2.0)

    def test_n0_without_hvdc_is_unchanged(self):
        out = sensitivity_checks.resolve_n0({}, {("b1", "g"): 1.0}, {}, {"b1"}, {}, {}, {"b1"}, set(), {"g"})
        assert out == ({}, {("b1", "g"): 1.0}, {}, None)

    def test_state_keeps_the_hvdc_sets_and_their_last_valid_copies(self):
        state = OperatingPointState.at_original_network(
            [], {}, {}, None, {}, {}, sensitivity_pst_nx={"c1": {}}, sensitivity_rd_nx={"c1": {}},
            sensitivity_hvdc_n0=_set(1.0), sensitivity_hvdc_nx={"c1": _set(2.0)},
        )
        assert state.sensitivity_hvdc_n0 == _set(1.0) and state.sensitivity_hvdc_nx == {"c1": _set(2.0)}
        assert state.last_valid_sensitivity_nx["c1"]["hvdc"] == _set(2.0)
        assert state.last_valid_sensitivity_n0_hvdc == {"b1": _set(1.0)}

    def test_state_without_hvdc_has_no_hvdc_key_in_the_store(self):
        state = OperatingPointState.at_original_network([], {}, {}, None, {}, {}, sensitivity_pst_nx={"c1": {}})
        assert state.last_valid_sensitivity_nx == {"c1": {"pst": {}, "rd": {}}}
        assert state.sensitivity_hvdc_n0 == {} and state.last_valid_sensitivity_n0_hvdc == {}


# ---------------------------------------------------------------------------
# EQ description warning (H2.2)
# ---------------------------------------------------------------------------

_EQ_HEADER = ('<?xml version="1.0" encoding="UTF-8"?><rdf:RDF xmlns:rdf="http://www.w3.org/1999/02/22-rdf-syntax-ns#" '
              'xmlns:cim="http://iec.ch/TC57/CIM100#">')


def _eq_file(directory, ei, node_description=None, ei_description=None):
    node_xml = (f'<cim:ConnectivityNode rdf:ID="_CN1"><cim:IdentifiedObject.description>{node_description}'
                f'</cim:IdentifiedObject.description></cim:ConnectivityNode>') if node_description else ""
    ei_desc = f"<cim:IdentifiedObject.description>{ei_description}</cim:IdentifiedObject.description>" if ei_description else ""
    (directory / "20220615T2230Z__Test_EQ_1.xml").write_text(
        _EQ_HEADER + f'<cim:EquivalentInjection rdf:ID="_{ei}">{ei_desc}</cim:EquivalentInjection>'
        f'<cim:Terminal rdf:ID="_T1"><cim:Terminal.ConductingEquipment rdf:resource="#_{ei}"/>'
        f'<cim:Terminal.ConnectivityNode rdf:resource="#_CN1"/></cim:Terminal>' + node_xml + "</rdf:RDF>",
        encoding=TEXT_ENCODING,
    )


class TestDescriptionWarning:
    def test_a_connectivity_node_description_starting_with_hvdc_gives_no_warning(self, tmp_path, caplog):
        _eq_file(tmp_path, "ei-1", node_description="HVDC converter A")
        with caplog.at_level(logging.WARNING):
            assert hvdc_units.warn_ei_without_hvdc_description([_unit("A", "ei-1")], tmp_path) == []
        assert not caplog.records

    def test_the_description_of_the_ei_itself_counts(self, tmp_path):
        _eq_file(tmp_path, "ei-1", ei_description="HVDC side 1")
        assert hvdc_units.warn_ei_without_hvdc_description([_unit("A", "ei-1")], tmp_path) == []

    def test_another_description_gives_a_warning_naming_unit_and_ei(self, tmp_path, caplog):
        _eq_file(tmp_path, "ei-1", node_description="BP_GA-NH")
        with caplog.at_level(logging.WARNING):
            assert hvdc_units.warn_ei_without_hvdc_description([_unit("A", "ei-1")], tmp_path) == ["ei-1"]
        assert any("A" in r.message and "ei-1" in r.message and "HVDC" in r.message for r in caplog.records)

    def test_an_ei_missing_from_the_eq_files_is_warned_not_an_error(self, tmp_path, caplog):
        _eq_file(tmp_path, "ei-1")
        with caplog.at_level(logging.WARNING):
            assert hvdc_units.warn_ei_without_hvdc_description([_unit("B", "ei-other")], tmp_path) == ["ei-other"]
        assert any("not found in the EQ files" in r.message for r in caplog.records)

    def test_the_mock_eis_have_no_hvdc_description_in_the_cgm(self, tmp_path):
        with zipfile.ZipFile(_MOCK_NX_CGM_ZIP) as zf:
            for name in zf.namelist():
                if "_EQ_" in name:
                    (tmp_path / name.rsplit("/", 1)[-1]).write_bytes(zf.read(name))
        units = [_unit("A", EI_SD_EH1), _unit("B", EI_SD_BO3)]
        assert hvdc_units.warn_ei_without_hvdc_description(units, tmp_path) == sorted([EI_SD_EH1, EI_SD_BO3])


# ---------------------------------------------------------------------------
# the mock NCP
# ---------------------------------------------------------------------------

def _mock_units(tmp_path):
    ncp = build_hvdc_mock_ncp(tmp_path / "mock.zip")
    with zipfile.ZipFile(ncp) as zf:
        (tmp_path / f"{SVEDALA}_RA.xml").write_bytes(zf.read(f"{SVEDALA}_RA.xml"))
    path = tmp_path / f"{SVEDALA}_RA.xml"
    return (ncp_parser.parse_hvdc_units(path, "TSO-Svedala"), ncp_parser.parse_balanced_ra_groups(path, "TSO-Svedala"))


class TestMockNcp:
    def test_two_units_in_one_balanced_group_pass_the_structure_check(self, tmp_path):
        units, groups = _mock_units(tmp_path)
        usable, kept = hvdc_units.validate_hvdc_structure(units, groups)
        assert {u.ei_mrid for u in usable} == {EI_SD_EH1, EI_SD_BO3} and len(kept) == 1
        assert {u.group_mrid for u in usable} == {default_groups(default_ras())[0][0]}

    def test_ranges_resolve_to_the_documented_limits(self, env, tmp_path):
        units, groups = _mock_units(tmp_path)
        usable, _ = hvdc_units.validate_hvdc_structure(units, groups)
        data = hvdc_units.read_unit_network_data(env.network, usable)
        limits = {
            u.ei_mrid: hvdc_units.resolve_operating_limits(u, data[u.ei_mrid]["p0"], data[u.ei_mrid]["min_p"], data[u.ei_mrid]["max_p"])
            for u in usable
        }
        assert limits[EI_SD_EH1] == (-450.0, 450.0)
        assert limits[EI_SD_BO3] == pytest.approx((P0_SD_BO3 - 40.0, P0_SD_BO3 + 60.0), abs=1e-3)   # the lower down range wins
