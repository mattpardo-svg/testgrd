"""tests/test_rao_milp_builder_scale.py - the curative redispatch rows of the MILP builder (net injection per unit and
contingency, balance per contingency, maxima per unit) are built from the pairs of their own contingency and unit,
with the terms in the order of the sorted pairs; a generated set with many contingencies builds in a stated time.
Generated data only."""

import time

import pyomo.environ as pyo
import pytest

from data_model import AEType, AssessedElement, BidDirection, PowerBid, RAKind, RDUnit
from milp.milp_builder import NxMilpInputs, RdMilpInputs, build_n0_milp_model

UP, DOWN = BidDirection.UP, BidDirection.DOWN


def _bid(mrid, ra_mrid, direction, mw=50.0):
    return PowerBid(
        mrid=mrid, ra_mrid=ra_mrid, direction=direction, available_mw={"1030Z": mw}, price_eur_mw=10.0,
        penalty_factor=0.0, lead_time_h=0.0, activation_cost_eur=None, min_energy_mwh=None, max_energy_mwh=None,
        step_size_mw=None,
    )


def _model(unit_count, contingency_count):
    """unit_count units, each with a curative up and a curative down RA (one bid each, factor 1 on the unit and
    0.5 on the next unit for the up bids: a shared bid), all linked to every contingency."""
    contingencies = [f"C{i:03d}" for i in range(contingency_count)]
    units = [f"GU{i:03d}" for i in range(unit_count)]
    rd_list, bid_list, glsk = [], [], {}
    for i, gu in enumerate(units):
        for direction, suffix in ((UP, "U"), (DOWN, "D")):
            ra = f"RA_{gu}_{suffix}"
            rd_list.append(RDUnit(
                mrid=ra, name=ra, tso="TestTSO", gu_mrid=gu, gu_name=gu, available=True, kind=RAKind.CURATIVE,
                initial_p=100.0, max_p=500.0, min_p=0.0, raise_ramp_rate=None, lower_ramp_rate=None, penalty_factor=0.0,
                linked_contingency_mrids=list(contingencies),
            ))
            bid_list.append(_bid(f"BID_{gu}_{suffix}", ra, direction))
            glsk[ra] = {gu: 1.0} if direction == DOWN else {gu: 0.5, units[(i + 1) % unit_count]: 0.5}
    rd_inputs = RdMilpInputs(
        rd_list=rd_list, bid_list=bid_list, glsk=glsk, sensitivity_rd_n0_pruned={},
        generator_data={gu: {"target_p": 100.0, "max_p": 500.0, "min_p": 0.0} for gu in units},
        penalty_reference_rd_pra=0.0,
    )
    nx_inputs = NxMilpInputs(
        lf_nx={c: {"BRANCH1": {1: 500.0}} for c in contingencies}, sensitivity_pst_nx={},
        sensitivity_rd_nx={c: {} for c in contingencies}, penalty_cost_overload_nx_patl=1.0,
    )
    ae = AssessedElement(
        mrid="AE_BRANCH1", name="AE", tso="TestTSO", ae_type=AEType.SECURED, branch_mrid="BRANCH1",
        secured_for_region=None, scanned_for_region=None, exclusion_reason=None, patl_ka={"1030Z": 1.0}, branch_side=1,
    )
    start = time.perf_counter()
    model = build_n0_milp_model(
        [ae], "1030Z", lf_initial={"BRANCH1": {1: 500.0}}, penalty_cost_overload_n0=1.0,
        rd_inputs=rd_inputs, nx_inputs=nx_inputs,
    )
    return model, rd_inputs, time.perf_counter() - start


def _expected_net_injection(model, rd_inputs, gu, co):
    """The row as the pairs of ALL contingencies filtered by contingency (the original formulation)."""
    pairs = sorted(model.curative_bid_contingency_pairs)
    bids = {bid.mrid: bid for bid in rd_inputs.bid_list}
    terms = [
        float(factor) * (model.curative_rd_volume_upward[b, c] - model.curative_rd_volume_downward[b, c])
        for b, c in pairs if c == co
        for factor in [rd_inputs.glsk.get(bids[b].ra_mrid, {}).get(gu)] if factor is not None
    ]
    return sum(terms) if terms else 0.0


def test_rao_the_curative_rows_have_the_terms_of_their_contingency_in_pair_order():
    model, rd_inputs, _ = _model(6, 4)
    for gu, co in sorted(model.curative_gu_contingency_pairs):
        assert str(model.curative_rd_net_injection_g[gu, co].expr) == str(_expected_net_injection(model, rd_inputs, gu, co))
    for co in model.curative_rd_contingency_ids:
        expected = sum(
            model.curative_rd_net_injection_g[gu, c] for gu, c in sorted(model.curative_gu_contingency_pairs) if c == co
        )
        assert str(model.curative_rd_balancing[co].body) == str(expected)
    assert sorted(model.curative_unit_ids) == [f"GU{i:03d}" for i in range(6)]
    assert len(model.curative_pmax_pmin_constraint) == 6


def test_rao_a_set_with_many_contingencies_builds_within_the_budget():
    """40 units x 2 RAs x 480 contingencies = 38400 (bid, contingency) pairs and 19200 unit rows: the net injection
    rows used to scan all 38400 pairs each (quadratic: 19 s, against 1.7 s now on the development machine). Budget:
    the whole model build in 12 s."""
    model, _, seconds = _model(40, 480)
    print(f"curative RD block: {len(model.curative_bid_contingency_pairs)} pairs, "
          f"{len(model.curative_gu_contingency_pairs)} unit rows, model built in {seconds:.1f} s")
    assert len(model.curative_bid_contingency_pairs) == 40 * 2 * 480
    assert len(model.curative_rd_balancing) == 480
    assert seconds < 12
