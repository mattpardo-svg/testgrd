"""tests/test_rao_output_file_registry.py - tests for output_file_registry.py and for the output files the mock pipeline run writes under their registered names.

Sections: registry and stale-file delete, output file names and column names of the mock run.
"""

import ast
import re
import sys
import pytest
import csv

from pathlib import Path
from helpers import _MOCK_NX_NCP_ZIP, run_pipeline_on_fixture_inputs
from output_file_registry import OUTPUT_FILE_REGISTRY, RENAMED_OUTPUT_FILES, delete_registered_output_files
from data_model import AcVerificationStatus, BidDirection, PowerBid, RAKind, RDUnit
from post_milp.n0_results_export import extract_lead_time_results
from text_encoding import TEXT_ENCODING  # noqa: E402

REPO_ROOT = Path(__file__).resolve().parents[1]


_NCP_GENERIC_ZIP = REPO_ROOT / "tests" / "fixtures" / "NCP_sample_generic_2_4.zip"


STALE_CURRENT_NAMES = ["lf_nx_initial.csv", "results_nx_loadings.csv"]


STALE_OLD_NAMES = [next(iter(RENAMED_OUTPUT_FILES))]  # an OLD name, taken from the rename table


UNRELATED_FILES = ["my_notes.txt", "analysis_by_hand.csv", "results_summary_backup.csv"]


# ---------------------------------------------------------------------------
# the function itself
# ---------------------------------------------------------------------------

def test_registry_has_no_duplicates_and_new_names_are_registered_old_names_are_not():
    assert len(OUTPUT_FILE_REGISTRY) == len(set(OUTPUT_FILE_REGISTRY))
    for old_name, new_name in RENAMED_OUTPUT_FILES.items():
        assert new_name in OUTPUT_FILE_REGISTRY
        assert old_name not in OUTPUT_FILE_REGISTRY


def test_delete_removes_registered_current_and_old_names_and_returns_them(tmp_path):
    for name in STALE_CURRENT_NAMES + STALE_OLD_NAMES:
        (tmp_path / name).write_text("stale", encoding=TEXT_ENCODING)

    deleted = delete_registered_output_files(tmp_path)

    assert sorted(deleted) == sorted(STALE_CURRENT_NAMES + STALE_OLD_NAMES)
    for name in STALE_CURRENT_NAMES + STALE_OLD_NAMES:
        assert not (tmp_path / name).exists()


def test_delete_never_touches_unregistered_files_directories_or_the_log(tmp_path):
    for name in UNRELATED_FILES:
        (tmp_path / name).write_text("mine", encoding=TEXT_ENCODING)
    (tmp_path / "run_log.txt").write_text("log", encoding=TEXT_ENCODING)
    subfolder = tmp_path / "sub"
    subfolder.mkdir()
    (subfolder / "results_pst.csv").write_text("registered name, but inside a subfolder", encoding=TEXT_ENCODING)
    directory_with_registered_name = tmp_path / "results_summary.csv"
    directory_with_registered_name.mkdir()

    deleted = delete_registered_output_files(tmp_path)

    assert deleted == []
    for name in UNRELATED_FILES + ["run_log.txt"]:
        assert (tmp_path / name).read_text(encoding=TEXT_ENCODING) in ("mine", "log")
    assert (subfolder / "results_pst.csv").exists()
    assert directory_with_registered_name.is_dir()


def test_delete_on_a_missing_folder_is_a_no_op(tmp_path):
    assert delete_registered_output_files(tmp_path / "does_not_exist") == []


# ---------------------------------------------------------------------------
# the pipeline calls it (N-X off, generic dataset)
# ---------------------------------------------------------------------------

@pytest.fixture(scope="module")
def generic_run_with_stale_files(tmp_path_factory):
    def plant_stale_and_unrelated(output_dir: Path) -> None:
        for name in STALE_CURRENT_NAMES + STALE_OLD_NAMES:
            (output_dir / name).write_text("stale content from an earlier run", encoding=TEXT_ENCODING)
        for name in UNRELATED_FILES:
            (output_dir / name).write_text("not a pipeline file", encoding=TEXT_ENCODING)

    return run_pipeline_on_fixture_inputs(
        tmp_path_factory.mktemp("generic_stale_run"), _NCP_GENERIC_ZIP,
        enable_nx_analysis=False, prepare_output_dir=plant_stale_and_unrelated,
    )


def test_pipeline_removes_stale_files_of_an_earlier_run_and_keeps_unrelated_files(generic_run_with_stale_files):
    output_dir = generic_run_with_stale_files.output_dir
    for name in STALE_CURRENT_NAMES + STALE_OLD_NAMES:
        assert not (output_dir / name).exists(), f"stale {name} survived the run"
    for name in UNRELATED_FILES:
        assert (output_dir / name).read_text(encoding=TEXT_ENCODING) == "not a pipeline file"


def test_pipeline_logs_the_deleted_names_in_run_log(generic_run_with_stale_files):
    log_text = (generic_run_with_stale_files.output_dir / "run_log.txt").read_text(encoding=TEXT_ENCODING)
    removal_lines = [line for line in log_text.splitlines() if "stale output file" in line]
    assert len(removal_lines) == 1
    for name in STALE_CURRENT_NAMES + STALE_OLD_NAMES:
        assert name in removal_lines[0]
    for name in UNRELATED_FILES:
        assert name not in removal_lines[0]


# ---------------------------------------------------------------------------
# a writer that produces an unregistered file fails a test
# ---------------------------------------------------------------------------

def test_every_file_the_pipeline_writes_is_registered(mock_nx_pipeline_run, generic_run_with_stale_files):
    written = {p.name for p in mock_nx_pipeline_run.output_dir.iterdir() if p.is_file()}
    written |= {
        p.name for p in generic_run_with_stale_files.output_dir.iterdir()
        if p.is_file() and p.name not in UNRELATED_FILES
    }
    assert written - set(OUTPUT_FILE_REGISTRY) == set()


def test_every_output_file_name_literal_in_the_source_is_registered():
    """Static guard for writers the pipeline runs above do not reach: every string literal in
    src that looks like a csv/txt file name is a registered name or an old name from the
    rename table."""
    allowed = set(OUTPUT_FILE_REGISTRY) | set(RENAMED_OUTPUT_FILES)
    file_name_pattern = re.compile(r"^[A-Za-z0-9_]+\.(csv|txt)$")
    unregistered = []
    for path in sorted((REPO_ROOT / "src").rglob("*.py")):
        if path.name == "output_file_registry.py":
            continue
        for node in ast.walk(ast.parse(path.read_text(encoding=TEXT_ENCODING))):
            if isinstance(node, ast.Constant) and isinstance(node.value, str):
                if file_name_pattern.match(node.value) and node.value not in allowed:
                    unregistered.append(f"{path.relative_to(REPO_ROOT)}:{node.lineno}: {node.value}")
    assert unregistered == []


# ===========================================================================
# File and column names of the mock run
# ===========================================================================

def _header(path: Path) -> list[str]:
    with open(path, newline="", encoding=TEXT_ENCODING) as f:
        return next(csv.reader(f))


def _rows(path: Path) -> list[dict]:
    with open(path, newline="", encoding=TEXT_ENCODING) as f:
        return list(csv.DictReader(f))


# ---------------------------------------------------------------------------
# file renames
# ---------------------------------------------------------------------------

def test_pipeline_writes_the_new_file_names_and_none_of_the_old_ones(mock_nx_pipeline_run):
    output_dir = mock_nx_pipeline_run.output_dir
    for old_name, new_name in RENAMED_OUTPUT_FILES.items():
        assert (output_dir / new_name).is_file(), f"{new_name} was not written"
        assert not (output_dir / old_name).exists(), f"old name {old_name} was still written"


# ---------------------------------------------------------------------------
# contingency key
# ---------------------------------------------------------------------------

def test_contingency_key_is_named_contingency_mrid_in_every_output_file(mock_nx_pipeline_run):
    output_dir = mock_nx_pipeline_run.output_dir
    for path in sorted(output_dir.glob("*.csv")):
        assert "co_mrid" not in _header(path), f"{path.name} still has a co_mrid column"

    # co_flat_list.csv lists the contingencies themselves: its key was the bare "mrid".
    co_flat_header = _header(output_dir / "co_flat_list.csv")
    assert co_flat_header[0] == "contingency_mrid"
    assert "mrid" not in co_flat_header
    for name in ("pst_cra_availability.csv", "results_curative_pst_groups.csv"):
        assert "contingency_mrid" in _header(output_dir / name), name


# ---------------------------------------------------------------------------
# Step 3a — branch columns: branch_mrid / branch_name everywhere a monitored branch is meant
# ---------------------------------------------------------------------------

def test_scanned_element_list_names_its_branch_columns_branch_mrid_and_branch_name(tmp_path):
    from data_model import AEType, AssessedElement
    from pre_milp.scanned_elements import build_scanned_element_list, write_scanned_element_csv

    ae = AssessedElement(
        mrid="ae-1", name="AE one", tso="T", ae_type=AEType.SCANNED, branch_mrid="branch-1",
        secured_for_region=None, scanned_for_region="CORE", exclusion_reason="x",
        patl_ka={"1030Z": 1.0},
    )
    scanned = build_scanned_element_list([ae], ["1030Z"])
    path = tmp_path / "scanned_element_list.csv"
    write_scanned_element_csv(scanned, path, ["1030Z"], branch_mrid_to_name={"branch-1": "Line one"})
    header = _header(path)
    assert header[:2] == ["branch_mrid", "branch_name"]
    assert "mrid" not in header and "name" not in header
    row = _rows(path)[0]
    assert row["branch_mrid"] == "branch-1" and row["branch_name"] == "Line one"


def test_pst_cra_availability_names_the_monitored_branch_branch_mrid(mock_nx_pipeline_run):
    output_dir = mock_nx_pipeline_run.output_dir
    header = _header(output_dir / "pst_cra_availability.csv")
    assert "branch_mrid" in header and "xne_mrid" not in header
    monitored_branches = {row["branch_mrid"] for row in _rows(output_dir / "tatl_data.csv")}
    availability_branches = {row["branch_mrid"] for row in _rows(output_dir / "pst_cra_availability.csv")}
    assert availability_branches and availability_branches <= monitored_branches, (
        "the column holds the monitored (secured, TATL) branch — the same entity as branch_mrid elsewhere"
    )


def test_no_output_file_keeps_the_old_branch_column_names(mock_nx_pipeline_run):
    for path in sorted(mock_nx_pipeline_run.output_dir.glob("*.csv")):
        assert "xne_mrid" not in _header(path), path.name


