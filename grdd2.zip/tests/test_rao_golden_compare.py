"""tests/test_rao_golden_compare.py - the comparison rule of the golden matrix (mock_data/golden/compare_runs.py):
counts (integer cells) are exact, other numbers go through the relative / column-maximum / dust-floor tolerances."""

import subprocess
import sys
from pathlib import Path

import pytest

from mock_data.paths import REPO_ROOT

SCRIPT = REPO_ROOT / "mock_data" / "golden" / "compare_runs.py"


def _compare(tmp_path, a_rows, b_rows, header="name,count,value"):
    for root, rows in (("a", a_rows), ("b", b_rows)):
        folder = tmp_path / root / "case"
        folder.mkdir(parents=True)
        (folder / "results.csv").write_text(header + "\n" + "".join(f"{r}\n" for r in rows), encoding="utf-8")
    done = subprocess.run([sys.executable, str(SCRIPT), str(tmp_path / "a"), str(tmp_path / "b")],
                          capture_output=True, text=True, encoding="utf-8", check=True)
    return done.stdout


def test_rao_golden_compare_an_integer_cell_that_differs_by_one_is_a_difference(tmp_path):
    out = _compare(tmp_path, ["x,1000000000,5.0"], ["x,1000000001,5.0"])
    assert "'diff': 1" in out and "count count row 1" in out


def test_rao_golden_compare_a_float_inside_the_tolerance_is_equal(tmp_path):
    out = _compare(tmp_path, ["x,7,1000.0"], ["x,7,1000.0000000001"])
    assert "'diff': 0" in out and "problems 0" in out


def test_rao_golden_compare_a_float_outside_the_tolerance_is_a_difference(tmp_path):
    out = _compare(tmp_path, ["x,7,1000.0"], ["x,7,1000.001"])
    assert "'diff': 1" in out and "num value row 1" in out


def test_rao_golden_compare_dust_around_zero_is_equal(tmp_path):
    out = _compare(tmp_path, ["x,0,1e-13"], ["x,0,0.0"])
    assert "'diff': 0" in out


def test_rao_golden_compare_last_solve_columns_have_an_absolute_tolerance_of_1e_6(tmp_path):
    header = "name,last_solve_volume,volume"
    out = _compare(tmp_path, ["x,0.015033102282,5.0"], ["x,0.015033107070,5.0"], header)           # 4.8e-9 apart, relative 3e-7
    assert "'diff': 0" in out


def test_rao_golden_compare_last_solve_columns_above_1e_6_and_other_columns_keep_the_old_rule(tmp_path):
    header = "name,last_solve_volume,volume"
    assert "'diff': 1" in _compare(tmp_path / "far", ["x,0.015,5.0"], ["x,0.0151,5.0"], header)         # 1e-5 apart
    assert "'diff': 1" in _compare(tmp_path / "other", ["x,0.5,0.015033102282"], ["x,0.5,0.015033107070"], header)   # not a last_solve column
