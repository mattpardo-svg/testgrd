"""
test_rao_scanned_elements.py — tests for scanned_elements.py, on synthetic data (no data
files), covering the acceptance criterion cases.
"""
import csv
import pytest
import tempfile
from pathlib import Path
from data_model import AssessedElement, AEType
from pre_milp.scanned_elements import build_scanned_element_list, write_scanned_element_csv
from text_encoding import TEXT_ENCODING  # noqa: E402

TS = ["1030Z", "1130Z"]

EXCL_REASON = "SecuredExclusionReasonKind.nonNativeCapacityCalculationRegion"


def _make_scanned_ae(mrid="ae-1", branch_mrid="b-1", patl_ka=None):
    return AssessedElement(
        mrid=mrid, name=f"Line {mrid}", tso="TSO-Belgovia",
        ae_type=AEType.SCANNED, branch_mrid=branch_mrid,
        secured_for_region=None, scanned_for_region="CORE",
        exclusion_reason=EXCL_REASON,
        patl_ka=patl_ka or {"1030Z": 1.0, "1130Z": 1.0},
    )


def _make_secured_ae(mrid="ae-s", branch_mrid="b-s"):
    return AssessedElement(
        mrid=mrid, name=f"Secured {mrid}", tso="TSO-Belgovia",
        ae_type=AEType.SECURED, branch_mrid=branch_mrid,
        secured_for_region="CORE", scanned_for_region=None,
        exclusion_reason=None,
        patl_ka={"1030Z": 1.0, "1130Z": 1.0},
    )


# ---------------------------------------------------------------------------
# Core behaviour
# ---------------------------------------------------------------------------

class TestBuildScannedElementList:
    def test_empty_input_returns_empty(self):
        result = build_scanned_element_list([], TS)
        assert result == []

    def test_secured_aes_excluded(self):
        aes = [_make_secured_ae(), _make_scanned_ae()]
        result = build_scanned_element_list(aes, TS)
        assert len(result) == 1
        assert result[0].mrid == "ae-1"

    def test_all_timestamps_present(self):
        ae = _make_scanned_ae()
        result = build_scanned_element_list([ae], TS)
        for ts in TS:
            assert ts in result[0].patl_cgm_ka
            assert ts in result[0].patl_scanned_ka
            assert ts in result[0].effective_limit_ka

    def test_no_none_values_in_result(self):
        ae = _make_scanned_ae()
        result = build_scanned_element_list([ae], TS)
        sc = result[0]
        for ts in TS:
            assert sc.patl_cgm_ka[ts] is not None
            assert sc.patl_scanned_ka[ts] is not None
            assert sc.effective_limit_ka[ts] is not None

    def test_fields_copied_correctly(self):
        ae = _make_scanned_ae(mrid="ae-x", branch_mrid="b-x")
        result = build_scanned_element_list([ae], TS)
        sc = result[0]
        assert sc.mrid == "ae-x"
        assert sc.branch_mrid == "b-x"
        assert sc.tso == "TSO-Belgovia"

    def test_soft_and_penalty_passed_through(self):
        ae = _make_scanned_ae()
        result = build_scanned_element_list([ae], TS, soft=True, penalty=500.0)
        assert result[0].soft is True
        assert result[0].penalty == 500.0

    def test_default_soft_false_penalty_zero(self):
        ae = _make_scanned_ae()
        result = build_scanned_element_list([ae], TS)
        assert result[0].soft is False
        assert result[0].penalty == 0.0

    def test_skips_ae_without_branch_mrid(self):
        ae = _make_scanned_ae()
        ae.branch_mrid = None
        result = build_scanned_element_list([ae], TS)
        assert len(result) == 0


# ---------------------------------------------------------------------------
# Spec acceptance criterion cases (zero virtual margin — dataset default)
# ---------------------------------------------------------------------------

class TestEffectiveLimitLogic:
    """
    Spec cases with virtualPositiveLoadMargin = 0 (dataset default).
    With margin=0: patl_scanned = patl_cgm.
    """

    def test_case1_no_lf_initial_effective_equals_patl_scanned(self):
        """Case 1: lf_initial=None → effective = patl_scanned (conservative)."""
        ae = _make_scanned_ae(patl_ka={"1030Z": 1.0})
        result = build_scanned_element_list([ae], ["1030Z"], lf_initial=None)
        assert result[0].effective_limit_ka["1030Z"] == 1.0

    def test_case2_lf_below_patl_effective_equals_patl_scanned(self):
        """Case 2: initial loading < patl_scanned → effective = patl_scanned."""
        ae = _make_scanned_ae(patl_ka={"1030Z": 1.0})
        lf = {"1030Z": {"b-1": 0.8}}
        result = build_scanned_element_list([ae], ["1030Z"], lf_initial=lf)
        assert result[0].effective_limit_ka["1030Z"] == 1.0  # max(1.0, 0.8)

    def test_case3_lf_exceeds_patl_effective_equals_lf(self):
        """Case 3: initial loading > patl_scanned → effective = initial loading."""
        ae = _make_scanned_ae(patl_ka={"1030Z": 1.0})
        lf = {"1030Z": {"b-1": 1.2}}
        result = build_scanned_element_list([ae], ["1030Z"], lf_initial=lf)
        assert result[0].effective_limit_ka["1030Z"] == 1.2  # max(1.0, 1.2)

    def test_case4_branch_missing_from_lf_initial_conservative(self):
        """Case 4: branch absent from lf_initial → conservative (patl_scanned)."""
        ae = _make_scanned_ae(patl_ka={"1030Z": 1.0})
        lf = {"1030Z": {"other-branch": 0.9}}  # b-1 not present
        result = build_scanned_element_list([ae], ["1030Z"], lf_initial=lf)
        assert result[0].effective_limit_ka["1030Z"] == 1.0

    def test_case5_timestamp_missing_from_lf_initial_conservative(self):
        """Case 5: timestamp absent from lf_initial → conservative."""
        ae = _make_scanned_ae(patl_ka={"1030Z": 1.0, "1130Z": 1.0})
        lf = {"1030Z": {"b-1": 1.2}}  # 1130Z not present
        result = build_scanned_element_list([ae], TS, lf_initial=lf)
        assert result[0].effective_limit_ka["1030Z"] == 1.2
        assert result[0].effective_limit_ka["1130Z"] == 1.0  # conservative

    def test_patl_scanned_equals_patl_cgm_when_margin_zero(self):
        """With virtual_margin=0 (dataset default): patl_scanned = patl_cgm."""
        ae = _make_scanned_ae(patl_ka={"1030Z": 1.5})
        result = build_scanned_element_list([ae], ["1030Z"])
        assert result[0].patl_scanned_ka["1030Z"] == 1.5
        assert result[0].patl_cgm_ka["1030Z"] == 1.5
        assert result[0].virtual_load_margin_pct == 0

    def test_multiple_aes_processed_independently(self):
        ae1 = _make_scanned_ae(mrid="ae-1", branch_mrid="b-1", patl_ka={"1030Z": 1.0})
        ae2 = _make_scanned_ae(mrid="ae-2", branch_mrid="b-2", patl_ka={"1030Z": 2.0})
        lf = {"1030Z": {"b-1": 1.5, "b-2": 0.5}}
        result = build_scanned_element_list([ae1, ae2], ["1030Z"], lf_initial=lf)
        assert len(result) == 2
        limits = {sc.branch_mrid: sc.effective_limit_ka["1030Z"] for sc in result}
        assert limits["b-1"] == 1.5  # lf > patl
        assert limits["b-2"] == 2.0  # patl > lf


# ---------------------------------------------------------------------------
# CSV output
# ---------------------------------------------------------------------------

class TestWriteScannedElementCsv:
    def test_creates_file(self):
        ae = _make_scanned_ae()
        result = build_scanned_element_list([ae], TS)
        with tempfile.TemporaryDirectory() as d:
            path = Path(d) / "scanned.csv"
            write_scanned_element_csv(result, path, TS)
            assert path.exists()

    def test_correct_row_count(self):
        ae1 = _make_scanned_ae(mrid="ae-1", branch_mrid="b-1")
        ae2 = _make_scanned_ae(mrid="ae-2", branch_mrid="b-2")
        result = build_scanned_element_list([ae1, ae2], TS)
        with tempfile.TemporaryDirectory() as d:
            path = Path(d) / "scanned.csv"
            write_scanned_element_csv(result, path, TS)
            with open(path, encoding=TEXT_ENCODING) as f:
                rows = list(csv.DictReader(f))
            # 2 AEs × 2 timestamps = 4 rows
            assert len(rows) == 4

    def test_correct_columns(self):
        ae = _make_scanned_ae()
        result = build_scanned_element_list([ae], TS)
        with tempfile.TemporaryDirectory() as d:
            path = Path(d) / "scanned.csv"
            write_scanned_element_csv(result, path, TS)
            with open(path, encoding=TEXT_ENCODING) as f:
                reader = csv.DictReader(f)
                cols = reader.fieldnames
            expected = [
                "branch_mrid", "branch_name", "tso", "timestamp",
                "patl_cgm_ka", "virtual_load_margin_pct",
                "patl_scanned_ka", "initial_loading_ka", "effective_limit_ka",
            ]
            assert cols == expected

    def test_initial_loading_ka_blank_when_lf_initial_not_provided(self):
        ae = _make_scanned_ae()
        result = build_scanned_element_list([ae], TS)
        with tempfile.TemporaryDirectory() as d:
            path = Path(d) / "scanned.csv"
            write_scanned_element_csv(result, path, TS)
            with open(path, encoding=TEXT_ENCODING) as f:
                rows = list(csv.DictReader(f))
            for row in rows:
                assert row["initial_loading_ka"] == ""

    def test_initial_loading_ka_populated_when_lf_initial_provided(self):
        ae = _make_scanned_ae(mrid="ae-1", branch_mrid="b-1")
        result = build_scanned_element_list([ae], TS)
        lf_initial = {"1030Z": {"b-1": 0.85}, "1130Z": {"b-1": 0.95}}
        with tempfile.TemporaryDirectory() as d:
            path = Path(d) / "scanned.csv"
            write_scanned_element_csv(result, path, TS, lf_initial=lf_initial)
            with open(path, encoding=TEXT_ENCODING) as f:
                rows = {row["timestamp"]: row for row in csv.DictReader(f)}
            assert float(rows["1030Z"]["initial_loading_ka"]) == 0.85
            assert float(rows["1130Z"]["initial_loading_ka"]) == 0.95

    def test_initial_loading_ka_blank_when_branch_missing_from_lf_initial(self):
        ae = _make_scanned_ae(mrid="ae-1", branch_mrid="b-1")
        result = build_scanned_element_list([ae], ["1030Z"])
        lf_initial = {"1030Z": {"other-branch": 1.5}}  # b-1 not present
        with tempfile.TemporaryDirectory() as d:
            path = Path(d) / "scanned.csv"
            write_scanned_element_csv(result, path, ["1030Z"], lf_initial=lf_initial)
            with open(path, encoding=TEXT_ENCODING) as f:
                rows = list(csv.DictReader(f))
            assert rows[0]["initial_loading_ka"] == ""

    def test_empty_list_writes_header_only(self):
        with tempfile.TemporaryDirectory() as d:
            path = Path(d) / "scanned.csv"
            write_scanned_element_csv([], path, TS)
            assert path.exists()
            with open(path, encoding=TEXT_ENCODING) as f:
                rows = list(csv.DictReader(f))
            assert len(rows) == 0
