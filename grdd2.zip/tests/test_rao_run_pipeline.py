"""tests/test_rao_run_pipeline.py - fast tests of run_pipeline.py (they do not run main()).

Sections: config keys, config range checks, the result model selector, the RD workflow gate.
"""

import ast
import shutil
import subprocess
import sys
import pytest
import yaml
import logging
import run_pipeline

from pathlib import Path
from data_model import BidDirection, PowerBid, RAKind, RDUnit
from pre_milp.workflow_gates import rd_inputs_required
from text_encoding import TEXT_ENCODING  # noqa: E402

REPO_ROOT = Path(__file__).resolve().parents[1]


SRC = REPO_ROOT / "src" / "rao"


CONFIG_DIR = SRC / "config"


def _keys_read_by_code() -> set[tuple]:
    """Every key path passed to _cfg(...) in run_pipeline.py (the only reader of rao_config.yaml)."""
    tree = ast.parse((SRC / "run_pipeline.py").read_text(encoding=TEXT_ENCODING))
    keys = set()
    for node in ast.walk(tree):
        if isinstance(node, ast.Call) and isinstance(node.func, ast.Name) and node.func.id == "_cfg":
            assert all(isinstance(a, ast.Constant) for a in node.args), "_cfg keys must be literals"
            if node.args:
                keys.add(tuple(a.value for a in node.args))
    return keys


def _load(name: str) -> dict:
    return yaml.safe_load((CONFIG_DIR / name).read_text(encoding=TEXT_ENCODING))


def _exists(config: dict, keys: tuple) -> bool:
    for key in keys:
        if not isinstance(config, dict) or key not in config:
            return False
        config = config[key]
    return True


def test_the_scan_finds_the_keys_and_no_other_reader_bypasses_it():
    keys = _keys_read_by_code()
    assert len(keys) >= 30
    assert ("thresholds", "max_change_ra") in keys and ("logging_options", "debug_log_mode") in keys
    assert '_rao_config["' not in (SRC / "run_pipeline.py").read_text(encoding=TEXT_ENCODING), \
        "read config through _cfg(...) so the scan sees the key"
    others = [p.name for p in SRC.rglob("*.py") if p.name != "run_pipeline.py" and "import yaml" in p.read_text(encoding=TEXT_ENCODING)]
    assert not others, f"{others} read YAML config outside run_pipeline.py: extend the scan"


@pytest.mark.parametrize("name", ["rao_config.default.yaml", "rao_config.yaml"])
def test_every_key_read_by_the_code_exists_in_the_file(name):
    config = _load(name)
    missing = sorted(k for k in _keys_read_by_code() if not _exists(config, k))
    assert not missing, f"{name} lacks keys the code reads: {missing}"


_LEAF_TABLES = {"current_factor_by_nominal_voltage_kv"}  # a user adds entries (400: 1.1) to the active file


def _key_tree(config):
    return {
        key: None if key in _LEAF_TABLES else _key_tree(value) for key, value in config.items()
    } if isinstance(config, dict) else None


def test_default_and_active_config_have_the_same_keys():
    assert _key_tree(_load("rao_config.default.yaml")) == _key_tree(_load("rao_config.yaml"))


@pytest.mark.parametrize("section, expected", [
    ("curative_ra", {"pst_group_kind_default": "blockedGroup", "pst_group_kind_per_tso": {},
                     "tatl_fallback_duration_s": 600}),
    ("ra_limits", {"max_taps_per_tso": 6, "max_taps_per_tso_overrides": {}}),
    ("performance", {"lf_thread_count": 1, "solver_time_limit_seconds": None, "solver_mip_rel_gap": None}),
    ("outputs", {"write_nx_sensitivity_csvs": True}),
])
def test_the_config_loader_returns_the_documented_defaults(section, expected):
    from run_pipeline import _config_value

    config = _load("rao_config.default.yaml")
    for key, value in expected.items():
        assert _config_value(config, (section, key), CONFIG_DIR / "rao_config.default.yaml") == value


def test_a_missing_key_names_the_key_and_the_file():
    from run_pipeline import ConfigKeyError, _config_value

    path = Path("/x/rao_config.yaml")
    with pytest.raises(ConfigKeyError) as excinfo:
        _config_value({"thresholds": {"a": 1}}, ("thresholds", "max_change_ra"), path)
    message = str(excinfo.value)
    assert "thresholds.max_change_ra" in message and "rao_config.yaml" in message
    assert "rao_config.default.yaml" in message
    assert isinstance(excinfo.value, KeyError)
    with pytest.raises(ConfigKeyError):
        _config_value({}, ("logging_options", "debug_log_mode"), path)
    assert _config_value({"a": {"b": 3}}, ("a", "b"), path) == 3


def test_the_pipeline_module_loads_with_the_default_file_alone(tmp_path):
    """Copy the sources, replace the active config by the default one, import run_pipeline."""
    shutil.copytree(REPO_ROOT / "src", tmp_path / "src",
                    ignore=shutil.ignore_patterns("__pycache__"))
    shutil.copy(REPO_ROOT / "pytest.ini", tmp_path / "pytest.ini")
    config = tmp_path / "src" / "rao" / "config"
    shutil.copy(config / "rao_config.default.yaml", config / "rao_config.yaml")
    code = (
        "import sys; sys.path[:0] = ['.', 'pre_milp']; import run_pipeline as r; "
        "print(r.MAX_CHANGE_RA, r.MAX_CHANGE_OVERLOAD, r.DEBUG_LOG_MODE)"
    )
    result = subprocess.run(
        [sys.executable, "-I", "-B", "-c", code], cwd=tmp_path / "src" / "rao",
        capture_output=True, text=True, timeout=300,
    )
    assert result.returncode == 0, result.stderr[-1500:]
    assert result.stdout.split() == ["1.0", "1.0", "False"]


# ===========================================================================
# Config range checks and unknown TSO names
# ===========================================================================

REPO_SRC = Path(__file__).resolve().parents[1] / "src" / "rao"


# ---------------------------------------------------------------------------
# max_taps_per_tso_overrides: range checks and unknown TSO names
# ---------------------------------------------------------------------------

def _default_config():
    import yaml
    return yaml.safe_load((REPO_SRC / "config" / "rao_config.default.yaml").read_text(encoding=TEXT_ENCODING))


def test_the_shipped_default_config_passes_the_range_checks():
    import run_pipeline
    run_pipeline.validate_config_ranges(_default_config(), Path("/x/rao_config.yaml"))


@pytest.mark.parametrize("section, key, bad", [
    ("thresholds", "min_loading_threshold_pct", -1.0),
    ("thresholds", "min_loading_threshold_pct_nx", -0.1),
    ("thresholds", "sensitivity_threshold_pct_pst", -5),
    ("thresholds", "sensitivity_threshold_pct_rd", -5),
    ("thresholds", "sensitivity_threshold_pct_pst_nx", -5),
    ("thresholds", "sensitivity_threshold_pct_rd_nx", -5),
    ("thresholds", "max_change_ra_sum_threshold", -1),
    ("thresholds", "max_change_ra", -1),
    ("thresholds", "max_change_overload", -1),
    ("iteration_caps", "max_linearisation_iterations", 0),
    ("iteration_caps", "max_completeness_iterations", 0),
    ("iteration_caps", "incremental_ac_fallback_max_steps", 0),
    ("iteration_caps", "max_linearisation_iterations", 2.5),
    ("thresholds", "max_change_ra", "high"),
    ("performance", "lf_thread_count", 0),
    ("performance", "lf_thread_count", 1.5),
    ("performance", "solver_time_limit_seconds", 0),
    ("performance", "solver_time_limit_seconds", -1.0),
    ("performance", "solver_mip_rel_gap", -0.1),
    ("outputs", "write_nx_sensitivity_csvs", "yes"),
    ("curative_ra", "tatl_fallback_duration_s", 0),
    ("curative_ra", "tatl_fallback_duration_s", 600.5),
])
def test_an_out_of_range_config_value_raises_a_clear_error_naming_key_value_and_file(section, key, bad):
    import run_pipeline
    config = _default_config()
    config[section][key] = bad
    with pytest.raises(ValueError) as excinfo:
        run_pipeline.validate_config_ranges(config, Path("/x/rao_config.yaml"))
    message = str(excinfo.value)
    assert f"{section}.{key}" in message and repr(bad) in message and "rao_config.yaml" in message


def test_set_solver_limits_and_a_thread_count_above_one_are_accepted():
    import run_pipeline
    config = _default_config()
    config["performance"].update(lf_thread_count=4, solver_time_limit_seconds=30, solver_mip_rel_gap=0.0)
    config["outputs"]["write_nx_sensitivity_csvs"] = False
    run_pipeline.validate_config_ranges(config, Path("/x/rao_config.yaml"))


def test_a_threshold_of_exactly_zero_and_an_iteration_cap_of_one_are_accepted():
    import run_pipeline
    config = _default_config()
    config["thresholds"]["max_change_ra"] = 0
    config["iteration_caps"]["max_completeness_iterations"] = 1
    run_pipeline.validate_config_ranges(config, Path("/x/rao_config.yaml"))


def test_unknown_tso_names_in_the_tap_limit_overrides_are_warned_about_one_by_one(caplog):
    import run_pipeline
    with caplog.at_level(logging.WARNING):
        run_pipeline.warn_unknown_tso_names(
            "max_taps_per_tso_overrides", ["TSO-A", "TSO-TYPO", "TSO-Z"], {"TSO-A", "TSO-B"},
        )
    warnings = [r.message for r in caplog.records if r.levelno == logging.WARNING]
    assert len(warnings) == 2
    assert any("TSO-TYPO" in w and "max_taps_per_tso_overrides" in w and "TSO-A" in w for w in warnings)
    assert any("TSO-Z" in w for w in warnings)


def test_known_tso_names_in_the_overrides_give_no_warning(caplog):
    import run_pipeline
    with caplog.at_level(logging.WARNING):
        run_pipeline.warn_unknown_tso_names("max_taps_per_tso_overrides", ["TSO-A"], {"TSO-A", "TSO-B"})
    assert not [r for r in caplog.records if r.levelno == logging.WARNING]


# ---------------------------------------------------------------------------
# Pipeline-level wiring (real run on the mock inputs)
# ---------------------------------------------------------------------------

def test_a_bad_config_value_stops_the_import_of_the_pipeline(tmp_path):
    import shutil
    import subprocess
    root = Path(__file__).resolve().parents[1]
    shutil.copytree(root / "src", tmp_path / "src", ignore=shutil.ignore_patterns("__pycache__"))
    shutil.copy(root / "pytest.ini", tmp_path / "pytest.ini")
    config_dir = tmp_path / "src" / "rao" / "config"
    text = (config_dir / "rao_config.default.yaml").read_text(encoding=TEXT_ENCODING)
    assert "max_change_ra: 1.0" in text
    (config_dir / "rao_config.yaml").write_text(text.replace("max_change_ra: 1.0", "max_change_ra: -1.0"),
                                                encoding=TEXT_ENCODING)
    result = subprocess.run(
        [sys.executable, "-I", "-B", "-c", "import sys; sys.path[:0] = ['.', 'pre_milp']; import run_pipeline"],
        cwd=tmp_path / "src" / "rao", capture_output=True, text=True, timeout=300,
    )
    assert result.returncode != 0
    assert "thresholds.max_change_ra" in result.stderr and "must be a number >= 0" in result.stderr



# ===========================================================================
# RD workflow gate
# ===========================================================================

def _unit(kind, available=True, mrid="RD1"):
    return RDUnit(
        mrid=mrid, name=mrid, tso="TestTSO", gu_mrid="GU1", gu_name="GU1", available=available,
        kind=kind, initial_p=50.0, max_p=100.0, min_p=0.0, raise_ramp_rate=None, lower_ramp_rate=None,
        linked_contingency_mrids=["CO1"], linked_xne_mrids=[],
    )


# ---- 1. gate predicate -----------------------------------------------------

def test_gate_preventive_rd_opens_with_and_without_nx():
    for nx in (True, False):
        assert rd_inputs_required([_unit(RAKind.PREVENTIVE)], enable_nx_analysis=nx)


def test_gate_curative_only_rd_opens_only_with_nx():
    """Only a preventive unit opening the gate would leave curative-only RD without inputs."""
    assert rd_inputs_required([_unit(RAKind.CURATIVE)], enable_nx_analysis=True)
    assert not rd_inputs_required([_unit(RAKind.CURATIVE)], enable_nx_analysis=False)


def test_gate_stays_closed_without_available_rd():
    assert not rd_inputs_required([], enable_nx_analysis=True)
    assert not rd_inputs_required([_unit(RAKind.CURATIVE, available=False)], enable_nx_analysis=True)
    assert not rd_inputs_required([_unit(RAKind.PREVENTIVE, available=False)], enable_nx_analysis=False)


# ===========================================================================
# Workflow options: ra_types and calculation_mode
# ===========================================================================

def test_the_default_config_holds_both_workflow_options():
    toggles = _load("rao_config.default.yaml")["workflow_toggles"]

    assert toggles["ra_types"] == ["pst", "rd"]
    assert toggles["calculation_mode"] == "ac_iterative"
    assert "enable_pst_remedial_actions" not in toggles and "enable_rd_remedial_actions" not in toggles


@pytest.mark.parametrize("value", [
    ["pst"], ["rd"], ["pst", "rd"], ["rd", "pst"], ["hvdc"], ["pst", "hvdc"], ["hvdc", "rd", "pst"],
    ["countertrade"], ["rd", "countertrade"], ["pst", "rd", "hvdc", "countertrade"],
])
def test_valid_ra_types_are_returned_as_a_list(value):
    assert run_pipeline.validate_ra_types(value, "x") == value


@pytest.mark.parametrize("value", [[], ["pst", "pst"], ["hvdc", "hvdc"], ["countertrade", "countertrade"], "pst", None])
def test_invalid_ra_types_stop_with_a_message_that_names_ra_types(value):
    with pytest.raises(ValueError, match="ra_types"):
        run_pipeline.validate_ra_types(value, "x")


@pytest.mark.parametrize("value", [[["pst"]], [["pst", "rd"]], ["pst", ["rd"]], [{"pst": 1}], [1]])
def test_a_nested_or_non_text_ra_type_list_gives_the_normal_message(value):
    with pytest.raises(ValueError, match="Invalid ra_types .* must be a non-empty list with values from"):
        run_pipeline.validate_ra_types(value, "x")


def test_countertrade_and_hvdc_are_allowed_and_an_unknown_type_is_reported_as_not_yet_supported():
    assert "hvdc" in run_pipeline.RA_TYPE_VALUES and "countertrade" in run_pipeline.RA_TYPE_VALUES
    assert run_pipeline.validate_ra_types(["pst", "hvdc", "countertrade"], "x") == ["pst", "hvdc", "countertrade"]
    with pytest.raises(ValueError, match=r"\['topology'\] not yet supported"):
        run_pipeline.validate_ra_types(["pst", "hvdc", "topology"], "x")

# ---- the two HVDC penalty references (docs/specs/hvdc_ra_specs.md H7.1) ----

def test_both_config_files_hold_the_hvdc_penalty_references_equal_to_the_rd_reference():
    for name in ("rao_config.default.yaml", "rao_config.yaml"):
        costs = _load(name)["penalty_costs"]
        assert costs["penalty_reference_hvdc_pra"] == costs["penalty_reference_rd_pra"]
        assert costs["penalty_reference_hvdc_cra"] == costs["penalty_reference_rd_pra"]


def test_the_hvdc_penalty_references_are_returned_as_floats():
    config = _load("rao_config.default.yaml")
    config["penalty_costs"].update(penalty_reference_hvdc_pra=7, penalty_reference_hvdc_cra=0)
    assert run_pipeline.validate_hvdc_penalty_references(config, Path("/x/rao_config.yaml")) == (7.0, 0.0)


@pytest.mark.parametrize("key", ["penalty_reference_hvdc_pra", "penalty_reference_hvdc_cra"])
@pytest.mark.parametrize("bad", [-1.0, "10", None, True])
def test_a_bad_hvdc_penalty_reference_names_key_value_and_file(key, bad):
    config = _load("rao_config.default.yaml")
    config["penalty_costs"][key] = bad
    with pytest.raises(ValueError, match=f"penalty_costs.{key}.*must be a number >= 0"):
        run_pipeline.validate_hvdc_penalty_references(config, Path("/x/rao_config.yaml"))


def test_a_missing_hvdc_penalty_reference_is_a_config_key_error():
    config = _load("rao_config.default.yaml")
    del config["penalty_costs"]["penalty_reference_hvdc_cra"]
    with pytest.raises(run_pipeline.ConfigKeyError, match="penalty_costs.penalty_reference_hvdc_cra"):
        run_pipeline.validate_hvdc_penalty_references(config, Path("/x/rao_config.yaml"))


def test_the_references_are_checked_only_when_hvdc_is_in_ra_types():
    """A config that predates the keys stays valid for every run without hvdc."""
    config = _load("rao_config.default.yaml")
    del config["penalty_costs"]["penalty_reference_hvdc_pra"]
    del config["penalty_costs"]["penalty_reference_hvdc_cra"]
    run_pipeline.validate_config_ranges(config, Path("/x/rao_config.yaml"))
    config["workflow_toggles"]["ra_types"] = ["pst", "hvdc"]
    with pytest.raises(run_pipeline.ConfigKeyError, match="penalty_reference_hvdc_pra"):
        run_pipeline.validate_config_ranges(config, Path("/x/rao_config.yaml"))


@pytest.mark.parametrize("mode", ["ac_iterative", "ac_single_pass", "dc"])
def test_valid_calculation_modes_are_returned(mode):
    assert run_pipeline.validate_calculation_mode(mode, "x") == mode


def test_no_calculation_mode_is_reserved_any_more():
    assert run_pipeline.CALCULATION_MODE_RESERVED == ()
    assert "dc" in run_pipeline.CALCULATION_MODE_VALUES


@pytest.mark.parametrize("value", ["AC_ITERATIVE", "single_pass", "", None, 3, "DC"])
def test_an_unknown_calculation_mode_lists_the_allowed_values(value):
    with pytest.raises(ValueError, match="ac_iterative.*ac_single_pass.*dc"):
        run_pipeline.validate_calculation_mode(value, "x")


def test_the_config_check_validates_both_options_and_rejects_the_removed_keys():
    path = Path("rao_config.yaml")
    config = _load("rao_config.default.yaml")
    run_pipeline.validate_config_ranges(config, path)  # the default passes

    for key, value in (("ra_types", []), ("calculation_mode", "fast")):
        broken = _load("rao_config.default.yaml")
        broken["workflow_toggles"][key] = value
        with pytest.raises(ValueError, match=key if key == "ra_types" else "calculation_mode"):
            run_pipeline.validate_config_ranges(broken, path)

    old = _load("rao_config.default.yaml")
    old["workflow_toggles"]["enable_pst_remedial_actions"] = True
    with pytest.raises(ValueError, match="enable_pst_remedial_actions.*ra_types"):
        run_pipeline.validate_config_ranges(old, path)


# ---------------------------------------------------------------------------
# dc_mode: the factor table and dc_power_factor
# ---------------------------------------------------------------------------

def test_both_config_files_hold_the_dc_mode_table_with_a_default_of_one():
    for name in ("rao_config.default.yaml", "rao_config.yaml"):
        assert _load(name)["dc_mode"] == {"current_factor_by_nominal_voltage_kv": {"default": 1.0}}
    assert set(_load("rao_config.default.yaml")["dc_mode"]) == {"current_factor_by_nominal_voltage_kv"}  # no pf key here


def _dc_config():
    config = _load("rao_config.default.yaml")
    config["workflow_toggles"]["calculation_mode"] = "dc"
    return config


@pytest.mark.parametrize("table, message", [
    ({}, "default"),
    ({"default": 0}, "default.*> 0"),
    ({"default": 1.0, 400: -1.0}, r"\.400.*> 0"),
    ({"default": 1.0, "abc": 1.0}, r"Unknown key.*abc"),
    ({"default": 1.0, 400: True}, r"\.400.*> 0"),
    ({"default": 1.0, 400: float("nan")}, r"\.400.*> 0"),
    ({"default": 1.0, 0: 1.0}, r"Unknown key"),
    ({"default": 1.0, 400: 1.0, "400.0": 1.1}, "Duplicate"),
    (None, "must be a table"),
])
def test_an_invalid_factor_table_stops_with_a_message_that_names_the_key(table, message):
    config = _dc_config()
    config["dc_mode"]["current_factor_by_nominal_voltage_kv"] = table
    with pytest.raises(ValueError, match=message):
        run_pipeline.validate_config_ranges(config, Path("rao_config.yaml"))


def test_a_valid_factor_table_with_numeric_and_string_keys_passes():
    config = _dc_config()
    config["dc_mode"]["current_factor_by_nominal_voltage_kv"] = {"default": 1.0, 400: 1.1, "220": 1.05, 110.0: 1}
    run_pipeline.validate_config_ranges(config, Path("rao_config.yaml"))


def test_a_missing_dc_mode_table_names_the_key():
    config = _dc_config()
    del config["dc_mode"]
    with pytest.raises(run_pipeline.ConfigKeyError, match="dc_mode.current_factor_by_nominal_voltage_kv"):
        run_pipeline.validate_config_ranges(config, Path("rao_config.yaml"))
    with pytest.raises(run_pipeline.ConfigKeyError, match="dc_mode.current_factor_by_nominal_voltage_kv"):
        run_pipeline.dc_factor_table(config, Path("rao_config.yaml"))


@pytest.mark.parametrize("mode", ["ac_iterative", "ac_single_pass"])
def test_the_ac_modes_ignore_an_invalid_factor_table_and_a_missing_one_is_the_default(mode):
    config = _load("rao_config.default.yaml")
    config["workflow_toggles"]["calculation_mode"] = mode
    config["dc_mode"]["current_factor_by_nominal_voltage_kv"] = {"default": -1.0, "abc": 0}
    run_pipeline.validate_config_ranges(config, Path("rao_config.yaml"))  # not checked outside dc

    del config["dc_mode"]
    run_pipeline.validate_config_ranges(config, Path("rao_config.yaml"))
    assert run_pipeline.dc_factor_table(config, Path("rao_config.yaml")) == {"default": 1.0}


@pytest.mark.parametrize("value", [0, -0.5, True, "0.9", None, float("nan")])
def test_an_invalid_dc_power_factor_stops_with_a_message_that_names_the_key(value):
    config = _load("load_flow_config.default.yaml")
    config["dc_power_factor"] = value
    with pytest.raises(ValueError, match="dc_power_factor"):
        run_pipeline.validate_load_flow_config(config, Path("load_flow_config.yaml"))


def test_the_shipped_load_flow_configs_have_a_valid_dc_power_factor():
    for name in ("load_flow_config.default.yaml", "load_flow_config.yaml"):
        run_pipeline.validate_load_flow_config(_load(name), CONFIG_DIR / name)
    assert run_pipeline.DC_POWER_FACTOR == 1.0
    assert run_pipeline.DC_CURRENT_FACTOR_TABLE == {"default": 1.0}
