# Next steps

For work in the target environment where the full data is available. Follow it for the first run on the full input and for performance work. It is part of `docs/`; keep it short and up to date.

## 1. Rules
- Real data is confidential. Never copy it, or file names or element names from it, into `tests/`, `docs/`, comments, commit messages or logs that are committed. Use counts and aggregate numbers. Keep `input/` and `output/` out of version control.
- Do not change behaviour to make a real run "look better". A behaviour change needs the maintainer's decision. Crashes get a minimal fix with a failing test first. Data problems and open questions are reported, not silently handled.
- Every default or dropped input must log a warning and be listed in `docs/ASSUMPTIONS.md`.
- Scope, commands and hard rules are in `.github/copilot-instructions.md`. Those win over this file.

## 2. Setup
1. Python 3.12.9; `pip install -r requirements.txt`.
2. `python -m pytest tests -q` must pass before you start. Write the pass count in the results file.
3. `input/` holds exactly one `cgm*.zip` and one `ncp*.zip`.

## 3. Baseline runs
1. Run `python src/rao/run_pipeline.py` twice with the default config. Copy `output/` of each run to a folder outside the repo (`../rao_runs/run1`, `run2`).
2. Compare run 1 and run 2. The same input can give last-digit differences (pypowsybl); this is the noise level. Equality below means: objective equal within 1e-9 relative; selected taps and MW equal within 1e-6; text, statuses, tap counts and iteration counts exactly equal; every other number counts as equal if |a - b| <= 1e-9 x max(|a|, |b|) or |a - b| <= 1e-9 x the largest absolute value of its column (scaled comparison: values near zero, such as `loading_pct_nx_post_pra_model_diff_pct`, carry no relative meaning, ASSUMPTIONS 16). For a column named `last_solve_*` (a diagnostic of the last solve of the run, not a result) the tolerance is the larger of the one above and 1e-6 absolute: the last N-X solve of a countertrade model ends in one of several vertices within the solver tolerance (DECISIONS 140). For a column named `*_model_diff_pct` the tolerance is the larger of the one above and 1e-6 absolute (percentage points): it is the difference of two nearly equal loadings, so the last-bit noise of the loadings (2.8e-12 relative) is a large share of its own maximum (measured, ASSUMPTIONS 16). Numerical dust floor: two numeric values with |a| <= 1e-9 and |b| <= 1e-9 (absolute, unit of the column) are equal; text, statuses and counts stay exact (DECISIONS 112). The wall-clock `seconds_*` columns and `run_log.txt` are not compared.
3. Time every phase from `output/run_log.txt` and the total wall time. Record peak memory (process working set).

## 4. Parser check on the real files
Do this before the baseline results are trusted. The real XML may differ from the mock data.
1. Read the inventory summary and the warnings of the first run.
2. Count the same element types (assessed elements, contingencies, PSTs, RD units, bids, TSOs) in the real files with a throwaway script outside the repo. They must match the parser's counts.
3. Treat these as a parser mismatch: zero PSTs, RD units, bids or contingencies; every assessed element excluded; PATL 0 everywhere; many "not found" or "skipped" warnings.
4. Read the line `Run time:` of the run log. If it says that the CGM time is inside no time-point series (or that the CGM has no scenario time), the run used the start hour 1030Z and the old per-reader rules. After this first real-data run decide whether such a run should stop with an error instead of the fallback with a warning (ASSUMPTIONS OPEN-32).
4. Compare the dropped and defaulted inputs in the log (warning counts, section 5 D) with what the files contain.
5. Spot-check about 5 elements by hand: one assessed element, one PST, one RD bid, one contingency, one limit. Compare the values in the file with what the parser read. Report only whether they match.
6. If the format differs: write a small synthetic XML with the same structure and fake values, write the test (it must fail), fix the parser, keep the test. Never copy real content into the test.

## 5. Results file
Create `docs/Real_Data_Results.md` (not committed if the repo is shared) with these sections. Put open questions for the maintainer at the top.
- A. Size: buses, branches, assessed elements by class (secured, scanned, excluded and why), contingencies (must-study, skipped and why), PSTs, RD units, bids, TSOs, N-X pairs in the model, MILP rows, columns and non-zeros.
- B. Run status: termination status, inner and outer iterations, objective, summary flags.
- C. Time and memory per phase and in total (two runs).
- D. Warnings in the log, counted by message type.
- E. The items under "To verify on real data" in `docs/ASSUMPTIONS.md`: for each, what you checked, the result (counts), and whether it is settled.
- F. Findings: crashes, wrong or odd results, data problems. For each: evidence, impact, proposed action (fix / report / ask the maintainer).
- G. Performance: see section 6.

## 6. Performance
Do nothing if the total run is under 10 minutes and peak memory under 8 GB. Otherwise find the dominant phase (above 40 % of the time) and act as follows. Prove each change with an equality test (section 3 rule) on the test fixtures and on a real run; undo any change that fails it.

| Dominant phase | Action |
|---|---|
| N-X security analysis or N-X sensitivities | Try `performance.lf_thread_count` 4 and 8. Keep the value only if the equality rule holds; otherwise keep 1 and report. |
| Model build or Pyomo-to-HiGHS translation | (a) Build N-X rows from non-zero sensitivities only and index the curative (unit, contingency) pairs by contingency. (b) Skip N-X rows that can never bind: current + sum(abs(coefficient) x maximum movement of that RA) <= limit, using tap bounds, the per-TSO tap cap, bid availability and the curative bounds; keep such pairs in the monitoring and export sets and in the completeness check. Both are exact changes. |
| Solve | Record solve times per iteration. If one solve exceeds 5 minutes, report it with the model size and recommend `performance.solver_time_limit_seconds` and `performance.solver_mip_rel_gap` values. Do not set them; a limit changes results and the maintainer decides. |
| Memory | Keep only the results (rows, values) of earlier loop members for the cycle exit, instead of whole models. Behaviour of the cycle exit must stay the same. |
| Output size | Set `outputs.write_nx_sensitivity_csvs` to false if the two N-X sensitivity CSVs are very large, and say so in the results file. |

Not allowed without the maintainer's decision: positive pruning or loading thresholds, a solver limit or gap, lazy constraint schemes, changing defaults in config.

## 7. Finish
`docs/Real_Data_Results.md` is complete; the tests pass; `docs/CHANGELOG.md`, `docs/DECISIONS.md` and `docs/ASSUMPTIONS.md` are updated for anything you changed; the open questions for the maintainer are listed at the top of the results file.

## 8. Tests
- Write every test against the Relicapgrid mock data in `tests/fixtures/`, or against small networks or XML built inside the test.
- Never use real data in a test. Never copy real values, names, mRIDs or file contents into `tests/`, fixtures, docs, logs or comments.
- A bug found in a real run is reproduced on the mock data or a small synthetic case. The test must fail before the fix and pass after it.
- Do not add real data to `tests/fixtures/`. Test names start with `test_rao_`.
- The maintainer's gate `python mock_data/golden/run_gate.py OUTDIR TAG none` also runs the documentation link check (`mock_data/tools/check_doc_links.py`): a dead relative link or `docs/...` path in a live file fails it; `docs/Real_Data_Results.md` is whitelisted until the real-data run creates it, and CHANGELOG, DECISIONS and `docs/archive/` are exempt (old paths quoted as history).
