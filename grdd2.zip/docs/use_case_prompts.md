# Use case build instructions (use cases 3, 4, 5)

Instruction file for the coder agent. Read it completely before starting. It tells you to build three more use cases, one after another, unattended. The owner is asleep: nobody answers questions.

Order: use case 3 (countertrade) -> use case 4 (HVDC) -> use case 5 (all four RA types together).
Use cases 1 (PST) and 2 (redispatch) are already built and committed; they are the templates.

---------------------------------------------------------------------------------------------------

## 0. Run rules (apply to the whole run)

0.1 Repository: branch `ncp-standard-alignment`, local commits only (dulwich), never push, `main` untouched. The owner has no git. One commit per use case (3 commits in total), made when that use case is finished and checked.

0.2 Allowed changes: `use_cases/` (the new folders `use_cases/03_ct/`, `use_cases/04_hvdc/`, `use_cases/05_all/`, and backward-compatible additions to `use_cases/_common/`), one line per use case in `docs/CHANGELOG.md`, one DECISIONS entry per use case (next free numbers), the one-line-per-use-case entry in the use_cases README and in `use_cases/index.html` generation. FORBIDDEN: `src/`, `tests/`, repo configs, `input/`, `input_old/`, `tests/fixtures`, golden baselines, this instruction file (do not edit it), use cases 1 and 2 results and data. No full test suite is needed (only `use_cases/` changes); do not run it.

0.3 NO QUESTIONS, NO WAITING. Where a decision is needed, take the fallback rule given in this file, write the decision in the use case README ("Decisions taken") and in `use_cases/FINDINGS.md`, and continue. A genuine tool or solver failure of one workflow (for example a crash in dc mode) goes into FINDINGS like in use case 1; it is not fixed in `src/`.

0.4 Failure handling between use cases:
- If a variant cannot be built meaningfully (see 2.4), drop that variant, say why, renumber the titles consecutively, continue.
- If a whole use case cannot be built (for example the parser cannot read the RA type from the data, or the base case gives no activation after the attempts in 2.3), write `use_cases/0X_.../README.md` with "Not built" and the reasons, commit that, and go to the next use case. Do not stop the run.
- STOP the whole run only if a change to the shared code in `use_cases/_common/` changed any result or page of an earlier use case (see check 3.6) and you cannot make it backward compatible. In that case revert your shared-code change, report, and stop.

0.5 Before each use case: confirm the previous use case is committed (print the commit id and `git status` equivalent), `use_cases/01_pst` and `use_cases/02_rd` exist, and the tool results of the earlier use cases are unchanged (hashes, see 3.6). Always `PYTHONHASHSEED=0`. Delete only the git-ignored work folder of the use case you are building (`use_cases/0X_.../work/`) before each fresh run, so no stale extraction is used. Never write into `input/`.

0.6 Run log: after each use case, append to `use_cases/RUN_LOG.md` (create if missing, tracked) a short block: use case, date and time, commit id, variants built/dropped, key numbers, open points. Keep it short; the owner reads it in the morning.

0.7 Style rules for everything you write (pages, READMEs, texts): short sentences, plain words, no names of people or tools/models in the repo, element names simple (see 2.2), numbers never typed into texts (inserted by script from the real results), code comments short and about the current function only; decision history goes into docs/DECISIONS.md.

---------------------------------------------------------------------------------------------------

## 1. Template and structure (same for all use cases)

Use the latest committed use case pages as the template: `use_cases/_common/` and `use_cases/02_rd/` (the newest). Reuse the shared code; do not copy-paste it. If the template needs a small extension for a new RA type, add it to `_common` in a backward-compatible way (default behaviour unchanged for use cases 1 and 2).

Folder per use case: `use_cases/03_ct/`, `use_cases/04_hvdc/`, `use_cases/05_all/`, each with: `README.md` (how to run, how to open results/index.html, variant table, "Data facts", "Decisions taken", "Not built" if any), `case.json` (variants, titles, texts, feature rows, element names), `variants.md`, `expected_results.md` (generated), case zips (CGM and NCP, derived from the input pair by the deterministic `make_case.py` with an explicit change list; never edit input files), `rao_config_<uc>.yaml`, `make_case.py` (with `--check`), `run_case.py` (`--all`, `--pages`, one variant by id), `check_summary.py`, and git-ignored `results/` and `work/`.

Base data: the pair `input/CGM_package_hvdc.zip` + `input/NCP_mock_hvdc.zip` (the latest package; HVDC RAs already merged in the NCP). The run config of each use case has `ra_types` as stated in the use case section and N-1 analysis ON (N-0 and N-1 are always simulated together in the same run, never separate). Three workflows per variant: ac_iterative, ac_single_pass, dc (tabs on the summary page).

Page design (same as use cases 1 and 2): per variant a summary page with three workflow tabs; in EVERY tab the four-part box (Use case in general words without element names; What we change, element names allowed; What to look at, two bullets with script-inserted numbers; Feature tag as names from `use_cases/_common/features.json`, row numbers only in tooltips); problem table; optimiser actions table; result table; cost terms; balance check where relevant; three-workflow comparison; takeaway by template; schematic with before and after loadings, one layout for all tabs and variants, 70-node rule, hollow connecting nodes, minimum node distance 40 px or more, zoom and pan, legend; the dc and ac_single_pass tabs carry the extra line about the linearised model. The index page of the use case lists number, title, use-case sentence and feature names. `use_cases/index.html` (generated, git-ignored result) links the index page of each use case that exists; add your use case.

---------------------------------------------------------------------------------------------------

## 2. General method for building one use case (apply to 3, 4 and 5)

2.1 Discover (read only). From the input pair and the parser, list the RAs of the type(s) of this use case: name, TSO, preventive/curative, contingency link, elements, limits, ranges, penalty factors, groups, and sensitivities to the candidate overload elements. Write the list into README "Data facts". The previous work knows: ct token in `ra_types` is `countertrade`; HVDC token `hvdc`; PST `pst`; RD `rd`. Read the specs of the repo for the RA type (for example `countertrade_ra_specs.md`, `hvdc_ra_specs.md`, `curative_rd_tatl_specs.md`, `dc_mode_specs.md`, `calculation_mode_specs.md`; find them by name in the repo) so the page text and the modelling rules are right.

2.2 Names. Give every element used in the case a simple name (like `Svedala_CT1`, `Espheim_HVDC1`), kept in `case.json` and shown on the pages with the mRID only in the tooltip.

2.3 Base case. Lower the limits of 2 assessed elements (choose those with a high sensitivity to the RAs of this use case, so that they can relieve them) so that N-0 and some contingencies are overloaded; no other change. Run once and check that the RA type of the use case is actually activated (at least one preventive and, where the spec allows it, at least one curative action) and that the overload is relieved fully or partly. If not: try the next best elements, deterministic, max 15 attempts, and report which were used. Cleanup rule (as in use cases 1 and 2): if the original data has overloads that the RA types of this use case cannot relieve, raise those limits so that they do not hide the case; list every raised limit in README "Decisions taken". If the base case still shows no activation, apply the fallback of the use case section; if there is none, mark the use case "Not built" (0.4).

2.4 Variants. One change each against the base. A variant must differ visibly from the base in at least one result number, otherwise it counts as "no effect": try a stronger change (max 3 deterministic attempts); if it still has no effect, drop it and write why. Variant ids are fixed in the use case sections; folder names = ids; titles are displayed texts only.

2.5 Page content for RA actions: show the actions of the RA type in the optimiser actions table in the units natural to it (see the use case sections); cost terms as in the objective; the balance check where the RA type needs a balance.

---------------------------------------------------------------------------------------------------

## 3. Checks after each use case (light, report numbers in the run log)

3.1 `run_case.py --all`: per variant and workflow: converged Y/N, objective, number of preventive and curative actions of the RA type(s), remaining overload.
3.2 Sanity: balance conditions of the RA types hold within 1e-6; all limits of the elements respected; the objective equals the sum of the cost terms; solve with the RA actions fixed to zero gives the "before" overloads.
3.3 `check_summary.py`: 0 mismatches between page numbers and CSV files; drawn graph is 1 connected component; layout identical across tabs and variants (layout hash for PYTHONHASHSEED 0, 1 and 77); four-part box in every tab; feature names come from features.json and no text "Rows N" is shown; node and edge counts, minimum node distance.
3.4 Headless Edge: no network requests, no console errors, zoom and pan test script works. Save 4 screenshots (PNG, 1400 px wide) in `results/screenshots/`: index, base ac_iterative, base dc, and the variant with the most different result. Open them yourself, describe in two sentences each what you see, and fix obvious problems (overlapping labels, unreadable text, markers hiding nodes).
3.5 `make_case.py --check` passes; link check 0 dead links; only allowed files changed (hash comparison of everything else, including `src/`, `tests/`, `input/`, `input_old/`).
3.6 Earlier use cases unchanged: re-run `--pages` of every earlier use case and compare the CSV hashes of their results (unchanged) and the check_summary result (0 mismatches). If anything changed, apply rule 0.4 (stop).
3.7 One commit with dulwich. Commit message: "use case N: <name>". Run log block (0.6).

---------------------------------------------------------------------------------------------------

## 4. USE CASE 3 - Countertrade (CT)   folder use_cases/03_ct/

Idea for the reader: a countertrade RA moves volume up and down between units by a participation key over the remaining capacity; it is balanced like redispatch (total up = total down) and costs a reservation price plus the activation price. Only the remaining-capacity strategy is implemented (the spec says so; a CT RA with another strategy is ignored with a warning; missing penalty factor falls back to 1.0; weights are fixed from the original set points, the same in all modes and iterations, preventive and curative).

ra_types: [countertrade] for the variants ct_base, ct_vol, ct_cost; [rd, countertrade] for ct_rd.

Data fallback: the ReliCapGrid data has no real countertrade bids; the NCP mock carries mocked CT RAs. First find which CT RAs exist in the current NCP (README Data facts). If none or if no curative one exists, add CT RAs to the use-case NCP zip (copy of the mock, standard form the parser reads, based on the spec and on an existing RD RA), choose generating units of different areas with a real sensitivity to the lowered elements, and say so. Read the CT spec for what is allowed for curative CT and follow it.

Variants (displayed titles and sentences; element names and numbers only in "What we change" and in script-inserted bullets):
1. ct_base - "1 - Preventive and curative countertrade". Use case: Overloads in N-0 and N-1 are relieved by shifting volume between units by a fixed participation key; the optimiser chooses between acting before the contingency and after it, and keeps the total balanced. Features: rows 1, 10, 20.
2. ct_vol - "2 - Limited countertrade volume". Use case: When the volume available for countertrade is small, the relief is capped and the remaining overload gets a penalty. Change: the offered volume of the CT RA lowered. Features: rows 10, 20.
3. ct_cost - "3 - Expensive countertrade". Use case: When countertrade is expensive, the optimiser accepts some overload instead of paying the full price. Change: the price (and reservation cost) of the CT RA raised so that the trade-off against the overload penalty changes. Row 20.
4. ct_rd - "4 - Countertrade together with redispatch". Use case: With both redispatch and countertrade available the optimiser takes the cheaper relief per MW first; countertrade joins the common balance of the redispatch. Change: ra_types includes rd. Rows 1, 6, 10, 20.
Add the CT reservation cost row to the cost terms table (the spec has a CT reservation cost summary row). Page units: MW per unit and the participation factor in the actions table, the shifted volume up and down.

---------------------------------------------------------------------------------------------------

## 5. USE CASE 4 - HVDC   folder use_cases/04_hvdc/

Idea for the reader: the set point of an HVDC link is a decision variable. The link is modelled as two generating-like units in a balanced group: one unit takes MW at one end, the other gives the same MW at the other end (sum of the two changes = 0). The range comes from the RA; if the set point lies outside the range the range is widened to the set point (warning H3.4); missing penalty factor falls back to 1.0.

Facts known from the earlier experiment (re-verify, do not assume): the Espheim-Svedala DC link is removed in the new package and replaced by a pair of equivalent injections, one at the Espheim side (mRID adcbb277-4ef5-22b8-4957-2cc29d68dc6a, about -543 MW) and one at the Svedala side (mRID 46f50bf7-4f81-efb5-1b8e-667cad94dfd4, about +545 MW); the HVDC RA bodies are merged into the Espheim and Svedala RA files of the NCP in the input pair; the range of 250 MW in the data is an arbitrary value; the other HVDC (Nordheim-Galia and Britheim) have both converters in the same substation and carry no HVDC RA. In the schematic the HVDC links are NOT drawn (decision of the owner); the HVDC use case shows the two injection substations as markers (small square) with the set-point change in the tooltip, and the legend gets "HVDC set point".

ra_types: [hvdc] for all variants (N-1 on).

Congestion fallback: in the experiment the HVDC RA was not activated because no branch was overloaded where the HVDC can help. Find (PTDF/sensitivity of every branch to the two injections) the branches where the HVDC shift has the highest sensitivity and lower the limits of 2 of them (max 15 attempts as in 2.3) until the HVDC is activated. If none works, mark "Not built".

Variants:
1. hvdc_base - "1 - Preventive and curative HVDC set point". Use case: Overloads in N-0 and N-1 are relieved by changing the power on an HVDC link, which moves flow between two areas without changing the generation. Features: rows 1, 11, 20.
2. hvdc_range - "2 - Narrow HVDC range". Use case: When the allowed range of the set point is small, the relief is capped and some overload remains with a penalty. Change: range of the HVDC RA reduced. Row 11.
3. hvdc_wide - "3 - Wide HVDC range". Use case: With a wide range the HVDC solves everything before the contingency and no curative action is needed. Change: range enlarged (only if it differs visibly from the base). Row 11.
4. hvdc_cost - "4 - Expensive HVDC". Use case: When the penalty factor of the HVDC is high the optimiser uses it less and accepts remaining overload. Change: penalty factor raised. Row 20.
Page units: set point before/after of both units (MW), the sum of changes (must be 0), the range used and any widening warning, cost term of the HVDC, per state (preventive, per contingency for curative).

---------------------------------------------------------------------------------------------------

## 6. USE CASE 5 - All four RA types together   folder use_cases/05_all/

Idea for the reader: PST, redispatch, countertrade and HVDC are all available, preventive and curative, N-0 and N-1 simulated together. The optimiser chooses the cheapest mix. The page shows which RA type does what.

Data: build the base case by reusing the case builders of use cases 1 to 4 (import their change functions from the make_case modules or from `_common`; no copy-paste): the same lowered limits and RAs as in the earlier use cases, plus anything needed so that every RA type is activated at least once in the base case if possible. Report which RA types are activated. If one type is never activated in the base case, keep it available anyway and say so; try max 3 deterministic changes to get it activated.

ra_types: [pst, rd, countertrade, hvdc] for the base; the other variants change ra_types as stated.

Variants:
1. all_base - "1 - All four RA types together". Use case: All four RA types compete to relieve the overloads; the optimiser takes the cheapest combination, before and after the contingency. Features: rows 1, 2, 6, 10, 11, 20.
2. all_nopst - "2 - Without PST". Use case: When PSTs are not available, the other RA types must take over the relief and the cost rises. Change: ra_types without pst. Rows 1, 20.
3. all_nord - "3 - Without redispatch". Use case: When redispatch is not available, the relief comes from PST, countertrade and HVDC. Change: ra_types without rd. Rows 1, 20.
4. all_noct_hvdc - "4 - Without countertrade and HVDC". Use case: With only the national-level RA types (PST and redispatch) the cross-border relief of countertrade and HVDC is missing. Change: ra_types without countertrade and hvdc. Rows 1, 20.
5. all_limit - "5 - Limit of actions per TSO". Use case: A limit on the number of RAs per TSO forces the optimiser to choose the most effective ones and leaves some overload. Change: the max number of RAs per TSO and state set to a small value (use the config key of the prototype; find it in the config; if no such key exists, drop this variant and say so). Rows 12, 20.
Page: the optimiser actions table lists all RA types together (type, unit, TSO, preventive/curative, contingency, before, after, change, cost); an extra table "Who does what": per RA type the number of actions, MW or taps, and cost share, per variant; the schematic uses the markers of all RA types (PST arrow, RD marker, CT marker, HVDC square) with one legend line each; a before/after comparison table of the five variants on the index page (objective, remaining overload, number of actions per type), all inserted from the results.

---------------------------------------------------------------------------------------------------

## 7. Final report (short, plain; the owner reads it in the morning)

For each use case: built Y/N, commit id, variants built/dropped and why, one-line result per variant (objective, actions, remaining overload), data facts (what existed, what was mocked), decisions taken from the fallback rules, check results (numbers), screenshot paths and two sentences each, FINDINGS additions, open questions as yes/no. Also give the file `use_cases/RUN_LOG.md` path. Nothing else.
