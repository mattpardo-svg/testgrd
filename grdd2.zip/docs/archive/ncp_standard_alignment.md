# NCP standard alignment: analysis and plan (phase 1)

Status: plan (phase 1, 22 Oct 2026) plus work package 0 done (23 Oct 2026): converter tool and equivalence
harness, no parser change (sections 4 to 9 record the owner decisions and the WP0 result). The alignment
table (section 1) is the phase 1 analysis, with the corrections listed in section 8.
Date: 2026-10-22. Decision by the spec owner: the mock NCP data is ours and may be wrong; the
ENTSO-E profiles are the reference. We (a) correct the mock to the standard and (b) change the
parser to read the standard-defined RAs and bids.

## 0. Sources, scope, how to read this

**Reference documents** (text extracted with pypdf; `pdftotext` is not installed on this machine, the
text was checked against the layout of every table quoted below):

- RA profile: *Remedial Action Profile Specification*, version 2.5.0, 2026-09-10, ICTC approved (71 pages).
  Cited as **RA-spec**, with table numbers.
- SIS profile: *State Instruction Schedule Profile Specification*, cover "version 2.5.0", revision table
  last row 2.5.1, 2026-09-10, ICTC approved (123 pages). Cited as **SIS-spec**.
- Repository side: `docs/ncp_data_requirements.md` sections 6 to 10 (what the parser reads), the parser
  `src/rao/pre_milp/ncp_parser.py`, `glsk_resolver.py`, `ct_units.py`, the mock builders in `tests/`.

**The two NCP samples in the repo are not the same thing.**

| Sample | What it is | Profile version it claims |
|---|---|---|
| `tests/fixtures/NCP_generic.zip` ("G") | ENTSO-E style sample (`dcterms:conformsTo ap.cim4.eu/StateInstructionSchedule/2.4`, `cim4.eu/ns/nc/2.4#`). Not made by us. | **2.4** |
| `tests/fixtures/NCP_pst_fallback_scenario.zip` ("P", identical to `input/NCP_mock_cleaned.zip` and `input/_extracted_ncp`) and the builders `tests/hvdc_mock.py`, `tests/ct_mock.py`, `tests/ncp_dataset.py` | Our mock | **2.4** in its dataset headers (copied from the sample), no real version |

G is therefore a useful second witness of the standard form, but it is 2.4, and the PDFs are 2.5.x.
**Authority (decision 85, 23 Oct 2026):** the official ENTSO-E ReliCapGrid 2.5 files `Belgovia_RA.xml` and
`Belgovia_SIS.xml` (github.com/entsoe/relicapgrid, branch `cgmes-3.0_ncp-2.5_tc-2.0`) define the standard
form. Their licence file says CC BY-SA 4.0 while the dataset headers say CC BY 4.0, so nothing is copied into
the repository: the converter and the harness mirror the structure and use our own ids. Where the official
files, the older samples and the PDFs disagree, section 7 lists it.
Differences between G and the 2.5.x text are visible (G: `CountertradeRemedialAction.powerShiftKey`
and `.method`, `PowerBidDependency.kind` and `.delay`, `PowerBidDependencyKind`, `BidDirectionKind`,
the inverse `RemedialAction.ContingencyWithRemedialAction`; none of these is in 2.5.x). See OPEN-1.

**Predicate rule.** The RDF predicate is `DeclaringClass.name`. Inherited attributes are declared by the
parent: for example `nc:RemedialAction.kind` on a `RedispatchRemedialAction`,
`nc:GridStateAlteration.timePerStage` on a `TapPositionAction`, `nc:RangeConstraint.direction` on a
`StaticPropertyRange`, `nc:BaseTimeSeries.interpolationKind` on a `PowerBidSchedule`. Association ends
follow the same rule (`nc:GridStateAlteration.GridStateAlterationRemedialAction` on every
set-point action). Cardinality `a..b` is the multiplicity of the end as printed in the "to" columns of the
spec tables; `1..1` required, `0..1` optional.

**Columns of the alignment table (section 1).**

- *Standard*: declaring class.attribute, cardinality, type, spec table.
- *Mock today*: what P and the builders write. *G* is added where G shows the standard form.
- *Parser today*: `std` reads the standard form, `mock` reads only the mock form, `both`, `neither`.
- *Consequence on standard data*: `ok`, `ignored` (silently or with a warning, stated), `error` (run
  stops), `wrong result` (data is read but gives a different meaning).
- *Needed*: does the model need it (yes / no / optional).
- *Change*: proposed change; the size S/M/L is in section 2.

OPEN items are marked **OPEN-n** and listed in section 3 with who must answer.

## 1. Alignment table

### 1A. Common to all RA types (`{TSO}_RA.xml`)

| # | Item | Standard | Mock today | Parser today | Consequence on standard data | Needed | Change |
|---|---|---|---|---|---|---|---|
| A1 | Identity | `IdentifiedObject.mRID` 1..1 String; `name`, `description` 0..1 (RA-spec Table 95 etc.). Classes with stereotype Description use `rdf:about`, others `rdf:ID` (RA-spec 2.3). | `rdf:ID="_<mRID>"` plus mRID literal. G: `rdf:ID` and, for `PowerShiftKeyStrategy`, `rdf:about="#_..."`. | both (subject URI fragment or mRID literal, R0.1) | ok | yes | none |
| A2 | `RemedialAction.kind` | `RemedialAction.kind` 1..1 `RemedialActionKind` {curative, preventive}; curative needs a ContingencyWithRemedialAction, preventive must not have one (Table 95) | present on every RA | both. Missing kind: silently preventive | ok for valid data; a missing (invalid) kind silently becomes preventive | yes | S: warning on missing kind |
| A3 | `RemedialAction.normalAvailable` | 1..1 Boolean | present | both. Missing: not available, silent | ok | yes | none (optional S: warning) |
| A4 | **done (WP7)** `RemedialAction.penaltyFactor` | 0..1 Float, "positive number greater than zero, default is one" (Table 95) | present (1.0) | both. Missing: PST, RD, CT 1.0 with warning; **HVDC 0.0** with warning | HVDC without penalty gets cost 0 instead of the standard default 1; no check that the value is > 0 | yes | S: HVDC default 1.0; warn on value <= 0. Changes HVDC expected numbers only where the mock omits the attribute (OPEN-2) |
| A5 | `RemedialAction.timeToImplement` | 0..1 Duration | present on curative RAs | both | ok | yes | none |
| A6 | `RemedialAction.isCrossBorderRelevant` | 1..1 Boolean | present (44 in P) | neither | ignored | no | none |
| A7 | `RemedialAction.isManual` | 0..1 Boolean | absent | neither | ignored | no | none |
| A8 | `RemedialAction.impactThresholdMargin` | 0..1 PerCent, [0,100]: RA "should not be used if it cannot resolve violation with more than the margin" | absent | neither | ignored: an RA the data provider meant to filter stays usable | optional | later; not in this plan |
| A9 | `RemedialAction.AppointedToRegion` | 1..1 Region; "normally the Y EIC of the capacity calculation region" (RA-spec 2.3 rule `Region:reference`) | absent in P; G: UUID ref | neither (TSO = file prefix, R0.7) | ignored | no | none (CD out of scope; see the earlier EIC investigation) |
| A10 | `RemedialAction.RemedialActionSystemOperator` | 0..1 SystemOperator; "normally the X EIC of the TSO" | absent in P; G: UUID ref | neither | ignored | no | none |
| A11 | `ContingencyWithRemedialAction.RemedialAction`, `.Contingency` | 1..1 each (Table 32) | present | both | ok | yes | none |
| A12 | **done (WP6)** `ContingencyWithRemedialAction.combinationConstraintKind` | **1..1** `ElementCombinationConstraintKind` {included, excluded, considered}. "included: can only be applied for this contingency; excluded: should not be used for this contingency; considered: can be considered" (Table 31) | present on every link in P | **neither** | a link with `excluded` is read as "RA applicable to that contingency": wrong result. `considered` is read as `included` (restricts the RA to the listed contingencies) | yes | M: read the kind. `excluded` removes the RA for that contingency; `considered` needs a rule (OPEN-3) |
| A13 | **warn only** `ContingencyWithRemedialAction.normalEnabled` | 0..1 Boolean: disabled link under normal conditions | absent | neither | a disabled link is used | optional | S with A12 |
| A14 | Curative RA without link | RA-spec Table 95: a curative RA "is required to have" a ContingencyWithRemedialAction | mocks have curative RAs without links (all contingencies) | std tolerant: PST none (info), RD/CT/HVDC all contingencies | not an error in our code; invalid by the standard | yes | leave; document as deliberate tolerance (OPEN-4) |
| A15 | `GridStateAlterationRemedialAction.isActivationRestricted` | 1..1 Boolean: true = all GridStateAlterations of the RA must be available to activate it; false = the rest can be activated (Table 52) | present (44 in P) | neither | PST group kind (blocked or reduced) comes from config, not from data | optional | M: map to the PST group kind (OPEN-5) |
| A16 | `GridStateAlteration.normalEnabled`, `.maximumPerDay`, `.minimumActivation` | 0..1 each (Table 49) | `normalEnabled` present; others absent in P (G has them) | neither | ignored | no | none |
| A17 | `GridStateAlteration.GridStateAlterationRemedialAction` | each set-point action links to one GSARA or to a GridStateAlterationCollection (constraint `C:NC:RA:GridStateAlteration:associations`) | GSARA link | std | actions in a Collection (scheme stages) ignored silently | yes | none |
| A18 | `GridStateAlteration.PropertyReference` | 1..1, one of the values published in the PropertyReference collection (external list, not in the PDFs) | present | neither, except HVDC range check on the string ending | ignored | no | OPEN-6 (list not available) |
| A19 | Other RA classes | `SchemeRemedialAction`, `AvailabilityRemedialAction` (Tables 25, 104), set-point and other GSA subclasses (`TopologyAction`, `LoadAction`, `ShuntCompensatorModification`, `StaticVarCompensatorAction`, `RegulatingControlAction`, `InServiceAction`, `BatteryUnitAction`, ...) | absent in P; G has several | neither | ignored silently; a GSARA made only of such actions is "not a PST/RD/HVDC" | no | none; list in the doc as out of the four types |

### 1B. PST (GridStateAlterationRemedialAction with TapPositionAction)

| # | Item | Standard | Mock today | Parser today | Consequence on standard data | Needed | Change |
|---|---|---|---|---|---|---|---|
| B1 | Class `TapPositionAction` | inherits GridStateAlteration (not SetPointAction); `TapPositionAction.TapChanger` 1..1 (Table 119) | same | std | ok | yes | none |
| B2 | `GridStateAlteration.timePerStage` | 0..1 Duration, "comes in addition to timeToImplement and is multiplied by the number of stages" (Table 49) | present (`PT1M`) | std | ok | yes (curative) | none |
| B3 | `StaticPropertyRange` | `RangeConstraint.GridStateAlteration` 1..1; `StaticPropertyRange.PropertyReference` 1..1 (Table 115) | absent in P; builders create some | std | ok | yes (curative bounds) | none |
| B4 | `RangeConstraint.direction` | 1..1 `RelativeDirectionKind` {up, down, upAndDown ("both up and down values are equal"), none} (Tables 12, 89) | up/down | std; `upAndDown` sets the upper bound only | for PST `upAndDown` is read as upper only; for HVDC the same token is read as plus or minus the value (see H4): the two readings disagree | yes | OPEN-7 |
| B5 | `RangeConstraint.valueKind` | 1..1 `ValueOffsetKind` {absolute, incremental, incrementalPercentage} (Table 18) | absolute values only | **neither** (values taken as absolute tap) | an `incremental` range (relative to the current tap) is read as an absolute tap: wrong result | yes | M: honour absolute and incremental, reject incrementalPercentage with a warning |
| B6 | `RangeConstraint.normalValue` | 0..1 Float, "the normal (initial) value" of the referenced attribute; for incremental kinds positive (Table 89) | present | std (cast to int) | meaning of "normal value" as the range limit is our reading (OPEN-8) | yes | none until OPEN-8 |
| B7 | `IntertemporalPropertyRange` | max change between two time stamps or per time unit, per direction (Table 56) | absent | neither | ignored | no (single timestamp) | none |
| B8 | PST group | not a class: several `TapPositionAction` on one GSARA; kind via `isActivationRestricted` (A15) | same | std | group kind from config | optional | see A15 |

### 1C. Redispatch (RD)

| # | Item | Standard | Mock today | Parser today | Consequence on standard data | Needed | Change |
|---|---|---|---|---|---|---|---|
| C1 | RA class | **`RedispatchRemedialAction`**, inheritance `PowerRemedialAction : RemedialAction` (Tables 91, 92). Associations: `PowerRemedialAction.BiddingZone` 0..1, `PowerRemedialAction.BiddingZoneBorder` 0..1, `RemedialAction.AppointedToRegion` 1..1, `RemedialAction.RemedialActionSystemOperator` 0..1. No GridStateAlteration. | `GridStateAlterationRemedialAction` that owns `RotatingMachineAction`s | mock only. A `RedispatchRemedialAction` gets one warning (with bid and time-point counts); RA and bids ignored | **a standard RD RA is dropped with a warning; no redispatch happens** | yes | L: see WP3 **done (WP3, 23 Oct 2026): read as a redispatch RA when a generating unit is found in its shift keys; gate open, see ncp_alignment_progress.md** |
| C2 | Tie of an RD RA to its units | Chain: `PowerBidSchedule.PowerRemedialAction` (0..1, to a PowerRemedialAction) <- `PowerShiftKeyDistribution.PowerBidSchedule` (0..1) -> `PowerShiftKeyDistribution.PowerShiftKeySchedule` (1..1) -> `PowerShiftKeySchedule.GeneratingUnit` (0..1; one and only one resource per schedule, constraint `PowerShiftKeySchedule:associations`) with `ParticipationFactorTimePoint`. G shows exactly this for its `RedispatchRemedialAction` (bid 6c0b..., key 3b57..., one `GeneratingUnit` of the CGM). | RD units from `RotatingMachineAction.RotatingMachine`; GLSK chain present in SIS and ends at the same machine | mock only (units from RotatingMachineAction; GLSK only reweights them) | on standard data there is no RotatingMachineAction, so no RDUnit exists and GLSK is never resolved | yes | L: derive the RD units from the GLSK (WP3) **done (WP3): units from the shift keys, both routes** |
| C3 | Bid target type | `PowerBidSchedule.PowerRemedialAction` must be a PowerRemedialAction. A GSARA is not one. | bids point to a GSARA | n/a | the mock link is not valid by the profile (OPEN-9) | yes | WP3 **done (WP3): bids of a RedispatchRemedialAction are read** |
| C4 | `RotatingMachineAction` | `SetPointAction`; attributes only those of GridStateAlteration (Table 102); `RotatingMachineAction.RotatingMachine` 1..1. **No ramp-rate attribute.** | `RotatingMachineAction.raiseRampRate`, `.lowerRampRate` | mock form read into `RDUnit.raise_ramp_rate`, `lower_ramp_rate` | not in the profile; the MILP does not use the values | no | drop from mock (WP3); parser keeps reading as old-form fallback only **done (WP3): the standard reader sets no ramp rates (None); the old form is read with a deprecation warning** |
| C5 | Ramp limits (standard places) | `PowerBidSchedule.maxRampUpP`, `.maxRampDownP` ActivePower 0..1 (Table 173, "from one time point to the next"); `IntertemporalPropertyRange` on a GSA (unit of "per time unit" not stated, OPEN-10) | absent | neither | ignored | no (single timestamp today) | none |
| C6 | What RotatingMachineAction still contributes | A GSARA with RotatingMachineAction plus PropertyReference `RotatingMachine.p` and a StaticPropertyRange is a set-point alteration of a machine (G has such an RA). It has no price or bid. | n/a | read as RD | an RD built this way has no standard bid at all | no | keep as old-form fallback only |
| C7 | Unit data | not in the profile: initial P, Pmin, Pmax come from the CGM | CGM | CGM | ok | yes | none |
| C8 | **done (WP4)** Unit identification | `PowerShiftKeySchedule.GeneratingUnit` = CIM `GeneratingUnit`. In the CGM the pypowsybl generator id is the SynchronousMachine id; `GeneratingUnit` is its parent (`RotatingMachine.GeneratingUnit`). | PSKS refer to the **SynchronousMachine** id, same as RotatingMachineAction | mock only: `glsk_resolver` compares the SIS id directly with `network.get_generators().index`. `parse_unit_costs` does map GeneratingUnit to generator through `CGMES.GeneratingUnit` (`run_pipeline.py:993`) | with standard (G-like) data every GLSK unit is "not found in network", removed, GLSK empty: wrong result | yes | M: map GeneratingUnit to generator for GLSK as for unit costs (WP4) |

### 1D. Bids (`PowerBidSchedule`, `PowerBidScheduleTimePoint`, `PowerBidDependency`)

SIS-spec Tables 173 to 176, 171, 172. `PowerBidSchedule` inherits `BaseIrregularTimeSeries : BaseTimeSeries`.
Rule `C:NC:SIS:PowerBidSchedule:associations`: one and only one of `ScheduleResource` or `PowerRemedialAction`.
Rule `C:NC:SIS:PowerBidScheduleTimePoint:attributes`: a time point carries one of the combinations
activationCost, or shutdownCost, or any of p, minimumActivationP, price, reservePrice, stepIncrementP.

| # | Item | Standard | Mock today | Parser today | Consequence on standard data | Needed | Change |
|---|---|---|---|---|---|---|---|
| D1 | `PowerBidSchedule.PowerRemedialAction` | 0..1 PowerRemedialAction | to GSARA (RD) or CT RA | std | ok for CT; RD see C3 | yes | WP3 |
| D2 | `PowerBidSchedule.ScheduleResource` | 0..1; bids of a schedule resource (DSO collection) | absent | neither | bid without RA ignored silently | no | none |
| D3 | **done (WP2)** `PowerBidSchedule.direction` | 0..1 **`MarketRegulationDirectionKind`** {up, down, upAndDown, stable} (SIS-spec 3.23, Table 13) | `BidDirectionKind.up/.down` (G the same) | token read: contains "down" is down, anything else (also missing, `upAndDown`, `stable`) is up, silent | enum class name is not checked, so both class names work; `stable` and `upAndDown` become "up": wrong result | yes | S/M: accept the standard literals; `upAndDown` bid = both directions, `stable` = no volume (WP2) |
| D4 | **done (WP2)** Sign of `PowerBidScheduleTimePoint.p` | 0..1 ActivePower, "active power injection, **load sign convention**, positive sign means flow out from a node" (Table 175). By that wording up regulation (more injection) is negative p. **The official 2.5 sample contradicts the wording: its up bids have p > 0 (+100, +150) and its down bid p < 0 (-50)** (OPEN-30). | positive magnitude with the direction literal (`p=50`, direction up and down alike) | `abs(p)` used, direction from the literal (missing = up, silent) | the size abs(p) is right under either reading. A bid with no direction is read as up, silently: wrong result when it was a down bid (the official sample has an RD bid with p = -125.46 and no direction). Decision 92: direction literal authoritative, no direction = skip with a warning, sign only a cross-check | yes | M: WP2 (decisions 92, 93) |
| D5 | Unit of `p` | `ActivePower` datatype, unit not fixed in the text | MW | MW | OPEN-12 | yes | none until OPEN-12 |
| D6 | `PowerBidScheduleTimePoint.atTime` | 1..1 DateTime | present | std; reduced to HHMMZ (R0.4) | ok | yes | none |
| D7 | **done (WP2)** `BaseTimeSeries.interpolationKind` | 1..1 {none, previous, next, linear} (declared by BaseTimeSeries) | present (`next`) | neither | time point missing at a run timestamp gives volume 0 even for `previous` or `linear`, where the standard holds or interpolates the value: wrong result | yes | M: apply the kind between points (WP2) |
| D8 | `PowerBidScheduleTimePoint.price` | 0..1 Decimal | present | std | ok | yes | none |
| D9 | `PowerBidSchedule.activationCost`, `PowerBidScheduleTimePoint.activationCost` | 0..1 Decimal each; time point overrides (Table 173, 175) | schedule level | std | ok | yes | none |
| D10 | `PowerBidScheduleTimePoint.reservePrice` | 0..1 Decimal "price for reserving the step increment active power" | in CT mock | std | meaning "reserving the *step increment* active power" differs from our use (curative reservation price): OPEN-13 | optional | none |
| D11 | `PowerBidSchedule.currency` | 0..1 Currency | EUR | std | ok | yes | none |
| D12 | `PowerBidSchedule.leadTime` | 0..1 Duration | present | std | ok | yes | none |
| D13 | **done (WP2)** `PowerBidSchedule.isFixed` | 0..1 Boolean: all bid values must be taken unchanged (take-it-or-leave-it) | absent | neither | a fixed bid is optimised as continuous: wrong result | optional | M: warn when true; implement later (OPEN-14) |
| D14 | **done (WP2)** `PowerBidScheduleTimePoint.minimumActivationP`, `.stepIncrementP` | 0..1 ActivePower | absent | neither | semi-continuous and stepped bids relaxed to continuous: wrong result | optional | S: warning when present |
| D15 | `PowerBidSchedule.totalMinimumEnergy`, `.totalMaximumEnergy` | 0..1 RealEnergy; minimum "has to be activated" | absent. Mock writes non-standard `minEnergyBid`, `maxEnergyBid` (only the dataset builder) | mock names read and not used | standard names ignored; a total minimum that forces activation is lost | optional | S: rename in mock; warn when the standard names are present |
| D16 | `PowerBidSchedule.priority` | 0..1 Integer, lower value higher priority | present (1) | neither | ignored | no | none |
| D17 | `PowerBidSchedule.isOffer` | 0..1 Boolean | absent | neither | ignored | no | none |
| D18 | Uptime, off-time, shutdown, ramps | `minimumUptime`, `maximumUptime`, `minimumOffTime` Duration; `shutdownCost` Decimal (also on the time point); `maxRampUpP`, `maxRampDownP` ActivePower; all 0..1 | `minimumUptime` in G only | neither | ignored | no | none |
| D19 | **done (WP2)** `PowerBidSchedule.penaltyFactor` | **not in the standard**; the RA-level `RemedialAction.penaltyFactor` is | present (P and builders) | mock, read into `PowerBid.penalty_factor`, "not used" | none on standard data (absent, default 0.0) | no | remove from the mock; parser read removed after fallback period |
| D20 | **done (WP2)** `PowerBidSchedule.stepSizeCTRD` | not in the standard (closest: `stepIncrementP` on the time point) | dataset builder only | mock, read, not used | none | no | remove from the mock |
| D21 | **done (WP2)** `PowerBidDependency` | `DependentPowerBidSchedule` 1..1 and `DependeePowerBidSchedule` 1..1; `constraintKind` 1..1 {exclusive, inclusive, restrictive}; lags `finishToFinishLag`, `finishToStartLag`, `startToStartLag`, `overlap` with `...Kind` {exact, minimum, maximum} (Tables 166, 171, 172) | absent | neither | ignored: an `exclusive` pair (up and down bid of one RA) is not enforced | optional | later (OPEN-15) |

### 1E. Per-RA and per-group volume limits

| # | Item | Standard | Mock today | Parser today | Consequence on standard data | Needed | Change |
|---|---|---|---|---|---|---|---|
| E1 | **warn only (WP7)** `PowerRemedialActionSchedule` | `PowerRemedialActionSchedule.PowerRemedialAction` 1..1; time point `PowerRemedialActionTimePoint.PowerRemedialActionSchedule` 1..1, `.atTime` 1..1, **`.maxRegulatingDown` 0..1, `.maxRegulatingUp` 0..1 ActivePower** "maximum net amount of active power that the remedial action can regulate" (Tables 181 to 184) | absent | neither | a per-RA cap is ignored: wrong result (more volume than the data provider allows) | optional | M: read as a cap on the RA's bid volume per direction (OPEN-16 on precedence over bids) |
| E2 | **done (WP1)** `RemedialActionGroupSchedule` | `RemedialActionGroupSchedule.RemedialActionGroup` 1..1 (Table 196) | absent; the mock has no schedule class | neither | see E3 | yes | S: WP1 |
| E3 | **done (WP1)** `RemedialActionGroupTimePoint` | `RemedialActionGroupTimePoint.RemedialActionGroupSchedule` 1..1, `.atTime` 1..1, **`RemedialActionGroupTimePoint.maxRegulatingDown` 0..1, `.maxRegulatingUp` 0..1** ActivePower (Tables 197, 198) | `RemedialActionGroupTimePoint.RemedialActionGroup` (direct link, not in the standard), predicates `nc:RemedialActionGroup.maxRegulatingUp` / `.maxRegulatingDown` on the time point (not declared by that class) | mock only | on standard data no time point is found for the group: warning "none for the group at START_HOUR", **no limit**: wrong result | yes | S/M: WP1 |

### 1F. GLSK chain

| # | Item | Standard | Mock today | Parser today | Consequence on standard data | Needed | Change |
|---|---|---|---|---|---|---|---|
| F1 | **done (WP4)** `PowerShiftKeyDistribution` | `.PowerBidSchedule` 0..1, `.PowerShiftKeySchedule` 1..1, `.PowerShiftKeyStrategy` 0..1; exactly one of PowerBidSchedule or PowerShiftKeyStrategy (rule `PowerShiftKeyDistribution:associations`) | `.PowerBidSchedule`, `.PowerShiftKeySchedule` | std for the bid route; strategy route not read | a key attached to a `PowerShiftKeyStrategy` (G "Option 4", RA-level key without a bid) is unused; RD with only that key: GLSK empty, warning | yes | M: WP4 (OPEN-17 on which route RD uses) |
| F2 | **done (WP4)** `PowerShiftKeySchedule` resource | exactly one of 13 associations (rule `PowerShiftKeySchedule:associations`): `GeneratingUnit`, `PowerElectronicsUnit`, `HydroPump`, `EnergyConsumer`, `EnergySource` (deprecated), `EquivalentInjection`, `ExternalNetworkInjection`, `DCEquivalentInjection`, `DCPole`, `EnergyBlockOrder`, `EnergyResourceGroupCapacity`, `ScheduleResource`, `SchedulingArea` (Table 188), each 0..1 | `GeneratingUnit` only | `PowerShiftKeySchedule.GeneratingUnit` only; a schedule with any other resource is skipped with **no message** (`if not gu_mrids: continue`) | a key mixing a generator and a consumer or a power-electronics unit is renormalised over the generators only, silently: wrong result. Renewable units are `PowerElectronicsUnit` by the deprecation note on EnergySource | yes | M: warn per skipped schedule; decide support per type (OPEN-18) |
| F3 | **done (WP4)** `ParticipationFactorTimePoint` | `.PowerShiftKeySchedule` 1..1; `.participationFactor` 0..1 Float positive; **`.atTime` 0..1** (rule `R:NC:SIS:ParticipationFactorTimePoint.atTime:cardinality`: optional because a schedule used in a bid pattern follows the bid time) | `.atTime` present | `at_time is None` -> point ignored | a standard time point without `atTime` is dropped: GLSK empty | yes | S/M: no `atTime` = valid for every timestamp (OPEN-19) |
| F4 | **sharing only, assumed** Sharing vs priority | Table 164: "in the case of a sharing strategy V = T/sum(PF); in the case of priority strategy the item with the lowest number gets allocated first". No attribute selects the strategy. | n/a | always sharing | priority keys are read as sharing: wrong result | yes | OPEN-20 |
| F5 | `GridStateAlterationTimePoint.participationFactor` | 0..1 PerCent; "sum for all grid state alterations of the same remedial action shall be 100%" (Table 148); with `enabled` 0..1 | G only | neither | ignored | no | none |
| F6 | `PowerShiftKeySchedule.ParticipationFactorTimePoint` count | rule `C:NC:SIS:PowerShiftKeySchedule.ParticipationFactorTimePoint:dependency`: 1..n "except if the schedule is associated with PowerShiftKeyDistribution" | n/a | n/a | wording unclear (OPEN-21) | no | none |

### 1G. Groups and dependencies

| # | Item | Standard | Mock today | Parser today | Consequence on standard data | Needed | Change |
|---|---|---|---|---|---|---|---|
| G1 | `RemedialActionGroup` | RA profile: `IdentifiedObject` only, "grouping of remedial actions that can be operated together" (Table 99). SIS profile: abstract stub; schedule and time point in the SIS (E2, E3). **No `maxRegulating` attribute on the group** | `RemedialActionGroup` with mRID, name | std | ok | yes | none |
| G2 | `RemedialActionDependency` | RA profile only (SIS has an abstract stub with no attribute): `.kind` 1..1 `RemedialActionDependencyKind` {exclusive, inclusive, restrictive, none, balanced}; `.mRID` 1..1; `.normalEnabled` 0..1; **`.RemedialAction` 0..1, `.DependingRemedialActionGroup` 0..1** (Tables 97, 98, 13) | `.kind`, `.RemedialAction`, `.DependingRemedialActionGroup` (hvdc_mock, G) or `.RemedialActionGroup` (ct_mock, dataset builder) | std plus the alias `.RemedialActionGroup` | the alias is our invention; `.mRID`, `.normalEnabled` ignored (a disabled dependency still counts) | yes | S: drop the alias after the fallback period |
| G3 | Restrictive group = volume limit | The profile describes `restrictive` as "The need to include or to exclude might depend on the model, e.g. simplified DC model versus detailed DC model", not as a sum limit. The limit is `RemedialActionGroupTimePoint.maxRegulatingUp/Down` of the group. | restrictive + limit | gates the limit on `kind` = restrictive | a group limit under kind `none` or `inclusive` is not applied (OPEN-22) | yes | none until OPEN-22 |
| G4 | `balanced` | "applies only to a set of power remedial actions (including HVDC which play role to balance power) and means the RA needs to be balanced between the area ... it is applied to" (Table 13) | HVDC pairs | HVDC only, exactly 2 units, same side | a balanced set of RD or CT RAs is not interpreted | optional | none (OPEN-23) |
| G5 | Other kinds | `exclusive`, `inclusive`, `none` | G: exclusive | ignored silently | ignored | no | none |
| G6 | Group in which file | the profile does not say which TSO's RA file holds a group shared by several TSOs | same group mRID in several TSO files: merged for HVDC | | | no | OPEN-24 |

### 1H. HVDC (GridStateAlterationRemedialAction with EquivalentInjectionAction)

| # | Item | Standard | Mock today | Parser today | Consequence on standard data | Needed | Change |
|---|---|---|---|---|---|---|---|
| H1 | `EquivalentInjectionAction` | `SetPointAction`; `EquivalentInjectionAction.EquivalentInjection` 1..1; `GridStateAlteration.GridStateAlterationRemedialAction` (Tables 41, 42) | same | std | ok | yes | none |
| H2 | Ranges | `StaticPropertyRange` with `RangeConstraint.GridStateAlteration`, `.direction`, `.valueKind`, `.normalValue`, `StaticPropertyRange.PropertyReference` (a published value, here ending in `EquivalentInjection.p`) | same | std | ok | yes | none |
| H3 | `valueKind` | absolute, incremental, incrementalPercentage | absolute, incremental | std; `incrementalPercentage` -> warning, range ignored | range lost with a warning | optional | S: support incrementalPercentage (P0 +/- v % of ...) or leave (OPEN-8) |
| H4 | `upAndDown` | "both up and down values are equal" | used | absolute `upAndDown` v -> plus or minus abs(v); PST reads the same token as upper bound only | inconsistent between PST and HVDC | yes | OPEN-7 |
| H5 | Balanced pair | `RemedialActionDependency.kind = balanced`, `.RemedialAction`, `.DependingRemedialActionGroup` (G2, G4) | same | std | ok | yes | none |
| H6 | HVDC RA class | the HVDC RA is a GSARA (not a PowerRemedialAction); `balanced` text says "including HVDC" | GSARA | std | OPEN-25 | yes | none |

### 1I. Countertrade (CT)

| # | Item | Standard | Mock today | Parser today | Consequence on standard data | Needed | Change |
|---|---|---|---|---|---|---|---|
| I1 | RA class | `CountertradeRemedialAction : PowerRemedialAction`; "relieve physical congestions where the location of activated resources within the bidding zone is not known" (Table 35, 36). `PowerRemedialAction.BiddingZone` 0..1, `.BiddingZoneBorder` 0..1 | same, BiddingZone | std for BiddingZone; a CT RA with only a BiddingZoneBorder is dropped with a warning | border-based CT unsupported | yes | none (OPEN-26) |
| I2 | **done (WP5)** **gLSKStrategy** | **No such attribute in either profile.** G (2.4) has `CountertradeRemedialAction.powerShiftKey` (GLSKStrategyKind.generatorPmax) and `.method` (ShiftMethodKind.shared), both gone in 2.5.x | `CountertradeRemedialAction.gLSKStrategy` and `PowerBidSchedule.gLSKStrategy` = `GLSKStrategyKind.proportionalForRemainingCapacity` | mock only. No strategy declared: warning, **RA ignored**. Other value: RA ignored | **every standard CT RA is ignored** (no strategy declared) | yes | M: WP5 |
| I3 | Places a strategy can be expressed | (a) `PowerShiftKeyStrategy` (RA-spec 3.85: IdentifiedObject only, **no kind attribute**) tied to the RA by `PowerShiftKeyStrategy.PowerRemedialAction` 1..1 and to a key by `PowerShiftKeyDistribution.PowerShiftKeyStrategy`; (b) the key data itself: `PowerShiftKeySchedule` to a resource (including `SchedulingArea`) with `ParticipationFactorTimePoint`; (c) the economic margins (I4); (d) `GridStateAlterationTimePoint.participationFactor` (F5). Nothing names a kind such as "proportional for remaining capacity". | none of these | none | OPEN-20 | yes | WP5 |
| I4 | `maxEconomicPMargin`, `minEconomicPMargin` | `CountertradeRemedialAction`, 0..1 PerCent, [0,100]. Max: "high economic active power limit given by the percentage of the relevant units operating p"; example 100 MW generator and 50 MW load at 90 % give 90 MW and 45 MW. Min: same with the unit's minimum operating p. **The min example is inconsistent: 90 % of 10 MW and 5 MW is stated as 11 MW and 5.5 MW** (Table 35, 36) | absent | neither | ignored: units can be used to 100 % of Pmax | optional | M: scale the CT unit limits (upper = max% of Pmax, lower = min% of Pmin) once OPEN-27 is answered |
| I5 | CT units and weights | not in the NCP: the bidding zone's units come from the CGM through the Organisation profile (out of scope); weights today `proportionalForRemainingCapacity` | CGM | CGM | ok | yes | none |
| I6 | CT bids | `PowerBidSchedule.PowerRemedialAction` -> the CT RA; same bid rows as D | same | std | D3, D4 apply | yes | WP2 |
| I7 | Per-RA cap | E1 applies to CT | absent | neither | see E1 | optional | WP2/E1 |

### 1J. Unit costs

| # | Item | Standard | Mock today | Parser today | Consequence on standard data | Needed | Change |
|---|---|---|---|---|---|---|---|
| J1 | `UnitCostSchedule` | `.GeneratingUnit` 1..1; `.currency` 0..1 Currency (Tables 213, 214); `BaseTimeSeries` attributes | only in `ncp_dataset.py` | std (maps GeneratingUnit to generator via `CGMES.GeneratingUnit`) | ok | yes (RD on/off cost) | none |
| J2 | `UnitCostTimePoint` | `.UnitCostSchedule` 1..1, `.atTime` 1..1, `.startupCost`, `.warmStartupCost`, `.shutdownCost` 0..1 Decimal (Tables 215, 216) | dataset builder | std | ok | yes | none |
| J3 | ER fallback `GeneratingUnit.normalWarmStartupCost` etc. | ER profile, not supplied | none | read | out of scope | no | none |

### 1K. Time-dependent availability and enabling (SIS)

| # | Item | Standard | Mock today | Parser today | Consequence on standard data | Needed | Change |
|---|---|---|---|---|---|---|---|
| K1 | **warn only (WP6)** RA availability schedule | `GenericAvailableSchedule.RemedialAction` 0..1 (Table 131); `AvailabilityTimePoint.atTime` 1..1, `.available` 1..1; the end name in Table 62 is "GenericAvailabilitySchedule" while the class is `GenericAvailableSchedule` (OPEN-28) | absent | neither | an RA scheduled unavailable at the run timestamp is still used: wrong result | optional | M, optional (WP6) |
| K2 | Enabling schedules | `GenericEnablingSchedule` with `.ContingencyWithRemedialAction`, `.RemedialActionDependency`, `.AssessedElementWithRemedialAction`, ...; `EnablingTimePoint.enabled` 1..1 (Tables 114, 132, 133) | absent | neither | ignored | optional | WP6 |
| K3 | `GridStateAlterationSchedule` / `GridStateAlterationTimePoint.enabled` | G has them (PST/topology actions disabled at a time) | absent in P | neither | ignored | optional | WP6 |
| K4 | `GridStateIntensitySchedule` | value replacing the attribute of a GSA over time, with `valueKind` and `RangeConstraint` | absent | neither | ignored | no | none |
| K5 | **warn only (WP6), reader = WP9** `AssessedElementSchedule` / `AssessedElementTimePoint` | `AssessedElementSchedule.AssessedElement` 1..1; `AssessedElementTimePoint.AssessedElementSchedule` 1..1, `.atTime` 1..1, `.enabled` (SIS-spec 3.68 to 3.71 and the official ReliCapGrid 2.5 `Belgovia_SIS.xml`, enabled false at one time) | absent in P; the converter adds one enabled and one disabled variant; G and the official sample have one disabled | neither (`parse_assessed_elements` does not read the SIS) | a disabled assessed element is still monitored: wrong result (too many constraints; an element the data provider switched off limits the optimisation). Pinned by a strict xfail in the harness | yes | M: later work package; the AE reader takes the SIS (OPEN-29) |

### 1L. Types, units, namespaces

| # | Item | Standard | Mock today | Parser today | Consequence | Needed | Change |
|---|---|---|---|---|---|---|---|
| L1 | `ActivePower` | datatype value, unit, multiplier; unit not fixed in the text; rule `C:452:ALL:NA:datatypes`: not serialised, multiplier 1 | plain MW | MW | OPEN-12 | yes | none |
| L2 | `Duration` | ISO 8601 `PnYnMnDTnHnMnS` | `PT5M`, `P0Y0M0DT0H0M0S` | std; years or months other than 0 unreadable | ok | yes | none |
| L3 | `DateTime` | `atTime` | `...Z` | clock part HHMMZ only, date ignored (R0.4) | a time point of another day with the same clock time matches: wrong result on multi-day data | yes | S, outside this plan |
| L4 | Enumeration literals | `nc:RemedialActionKind.*`, `ElementCombinationConstraintKind.*`, `MarketRegulationDirectionKind.*`, ... | `nc:` namespace | token after `#` or `.`, class name not checked | tolerant | yes | none |

**Row count.** 1A 19, 1B 8, 1C 8, 1D 21, 1E 3, 1F 6, 1G 6, 1H 6, 1I 7, 1J 3, 1K 5, 1L 4 = **96 rows**.

## 2. Plan

### 2.1 The two readings of the old mock form

For every change below, three options for data in the **old mock form** after the change:

| Option | Behaviour | Pro | Con |
|---|---|---|---|
| A. Standard only | old form is not read; one warning per ignored object | simplest code | every existing mock, builder and test breaks at once; old private data stops working silently apart from the warning |
| B. Standard first, old form as fallback | new form wins; if only the old form is present, read it and log a deprecation warning once per file; both present: new wins, warning | tests migrate one at a time; no behaviour change for old data; goldens stay valid during migration | two code paths for one release |
| C. Standard only, old form is an error | `ValueError` naming the file and object | clear signal | breaks old data hard |

**Recommendation: B for this release, then A after the mock is converted and the spec owner confirms no old-form
data is in use (C only if they want hard failure).** The spec owner decides.

### 2.2 Work packages (order = dependency order)

Sizes: S under half a day, M one to two days, L three days or more. "Goldens" = `tests/fixtures/milp_model_fingerprints.json`
and any pinned expected numbers.

| WP | Content | Rows | Mock change | Parser change | Tests to change or add | Goldens / fingerprints | Risk | Size |
|---|---|---|---|---|---|---|---|---|
| WP0 | Conversion tool and equivalence harness: a script that converts a mock zip from old to standard form (deterministic, same mRIDs); a test that parses the old and the converted zip and asserts equal `RDUnit`, `PowerBid`, GLSK, groups, HVDC, CT results | all | none (tool only) | none | new: `test_rao_ncp_standard_equivalence.py`, one case per WP | **proves "unchanged"** for every later WP | low | M |
| WP1 | Group limits on the standard chain: `RemedialActionGroupSchedule` + `RemedialActionGroupTimePoint` with `RemedialActionGroupTimePoint.maxRegulatingUp/Down`; drop the `.RemedialActionGroup` alias on dependencies | E2, E3, G2 | `ct_mock.py` (group point), `ncp_dataset.py` (2 refs to the alias), P has no groups | `parse_ra_groups`: read the new chain first; fall back to the direct `RemedialActionGroupTimePoint.RemedialActionGroup` and `nc:RemedialActionGroup.maxRegulating*` with a deprecation warning | `test_rao_ncp_parser` (RemedialActionGroupTimePoint: 4 refs, `RemedialActionGroup.maxRegulating`: 2, alias: 4), `test_rao_ct_*` through `ct_mock.group` | unchanged if values equal (same group mRID, same limits) | low; silent loss of a limit today is the real risk | S |
| WP2 | Bids: direction literals and sign; `interpolationKind`; unsupported standard attributes warn; remove non-standard attributes (`penaltyFactor`, `minEnergyBid`, `maxEnergyBid`, `stepSizeCTRD`) from the mock | D3 to D20, I6 | `ncp_dataset.py` (3 refs), `ct_mock.py`, P (SIS: 32 bids with `penaltyFactor`); p written with load sign (negative for up) | `parse_power_bids`: map MarketRegulationDirectionKind; derive direction from sign when absent (rule per OPEN-11); apply `previous/next/linear`; warn on `isFixed`, `minimumActivationP`, `stepIncrementP`, `totalMinimumEnergy`; keep non-standard reads as fallback | `test_rao_ncp_parser` (`BidDirectionKind`: 2, negative p tests, penalty 1), `test_rao_ct_parser` (1), builders | unchanged if sign convention and direction give the same volumes as before; **changes** if a mock bid has p positive with direction up and the sign rule is made authoritative (OPEN-11) | medium: the sign rule affects every bid | M |
| WP3 | Redispatch to the standard: `RedispatchRemedialAction` with `PowerRemedialAction.BiddingZone`; RD units derived from the GLSK (`PowerShiftKeySchedule.GeneratingUnit`); initial P, Pmin, Pmax from the CGM; bids point to the RD RA; `RotatingMachineAction` form kept as fallback | C1 to C8, D1 | P: for each RD GSARA create a `RedispatchRemedialAction` with the same mRID and a `PowerRemedialAction.BiddingZone`; drop `RotatingMachineAction`, ramp rates; `PowerShiftKeySchedule.GeneratingUnit` carries the CIM GeneratingUnit id (P has the machine id today, so P needs the GU ids of the CGM); BiddingZone ids must exist in the Organisation profile | `parse_rd_units` split: RAs first (new class), then `resolve_glsk`, then `RDUnit` per (RA, GLSK unit); `glsk_resolver` gets RAs from the RA file, not from `rd_list`; `warn_unsupported_power_remedial_actions` stops warning for RedispatchRemedialAction; old form kept | `test_rao_ncp_parser` (RedispatchRemedialAction: 9 refs, mostly pinning the ignore-with-warning), `test_rao_glsk_resolver`, `test_rao_milp_builder_rd`, `test_rao_ncp_dataset_*`, `helpers.py`, end-to-end tests that use P | **should be unchanged** if every RD unit of P is also in its GLSK with the same factor (true for Belgovia: 2 of 2; to be verified for all TSOs by WP0). Changes if an RD unit has no GLSK entry (it would disappear) or the reverse | **high**: the biggest semantic change; unit set no longer comes from the RA file | L |
| WP4 | GLSK chain: GeneratingUnit to generator mapping (same as unit costs), strategy route (`PowerShiftKeyDistribution.PowerShiftKeyStrategy`), other resource types, optional `atTime` | C8, F1 to F4 | add a strategy-route and an optional-`atTime` case to the dataset builder; one PSKS per resource type for a negative test | `resolve_glsk`: map GU to generator; warn per skipped schedule with the unsupported resource type; `atTime` absent = all timestamps; strategy route per OPEN-17 | `test_rao_glsk_resolver` (22 KB), `ncp_dataset` valid and variants | unchanged for GeneratingUnit-only data once WP3 stores GU ids and the mapping gives back the same generator ids | medium (mapping must reproduce the current ids) | M |
| WP5 | Countertrade without `gLSKStrategy`: strategy not read; default `proportionalForRemainingCapacity` for every CT RA (or a config key); read `maxEconomicPMargin` / `minEconomicPMargin` as optional limits | I2 to I4 | remove `CountertradeRemedialAction.gLSKStrategy` and `PowerBidSchedule.gLSKStrategy` from `ct_mock.py` (3) and `ncp_dataset.py` (4); keep `strategy=` builder parameters only for negative tests of the fallback | `parse_ct_remedial_actions` (`ct_units.py`, 6 refs): no strategy declared is no longer an error; old attribute present: fallback, other value than the proportional one: still ignored with warning (as today) | `test_rao_ct_parser` (5), `test_rao_ct_mock` (1), `test_rao_ct_config` (1), `test_rao_ncp_dataset_variants` (2) | unchanged: the strategy already defaults the weights; margins absent means 100 % | medium: tests that pin "no strategy -> RA ignored" flip | M |
| WP6 | Contingency link kind (A12, A13) and time-dependent availability (K1 to K3) | A12, A13, K1 to K3 | add `excluded`/`considered` links and an availability schedule to the dataset builder | `ContingencyWithRemedialAction.combinationConstraintKind`; `GenericAvailableSchedule` / `AvailabilityTimePoint` at the run timestamp | `test_rao_ncp_parser`, `test_rao_cra_preprocessing`, new cases | unchanged: P has only `included`-like links today (to be checked; if P has `excluded`, results change and are then correct) | medium (touches PST, RD, CT, HVDC availability) | M |
| WP7 | Small items: HVDC penalty default 1.0; kind/normalAvailable missing warnings; PST `valueKind`; `isActivationRestricted` as PST group kind; per-RA `maxRegulating` (E1) | A2, A4, A15, B5, E1 | cases in the dataset builder | respective parsers | `test_rao_hvdc_parser`, `test_rao_ncp_parser` | A4 changes HVDC numbers only where the mock omits `penaltyFactor`; B5 changes curative PST bounds only for `incremental` ranges (none in P) | low each | S each (M together) |
| WP8 | Fixtures and documents: regenerate `NCP_pst_fallback_scenario.zip` in standard form (new file name or same name, see 2.4); `ncp_data_requirements.md` and `ncp_dataset_coverage.md` rewritten to the standard form; this file updated to "done" | all | see 2.4 | none | all tests that load P (list in 2.4) | see 2.5 | medium (many tests load P) | M |

Order: WP0, WP1, WP2, WP3, WP4, WP5, WP6, WP7, WP8. WP1 and WP5 are independent of WP3 and can run first if
the spec owner wants early wins. WP3 needs WP4's GU mapping to be correct for real data; do them together in
one branch.

### 2.3 Deviation list: what to change where

| Deviation | Rows | Recommendation | Size |
|---|---|---|---|
| RD as GSARA + RotatingMachineAction, bid on a GSARA | C1 to C4, D1 | **both**: mock to `RedispatchRemedialAction`, parser reads it and derives units from the GLSK; old form fallback | L |
| RotatingMachineAction ramp rates | C4 | mock only (remove); parser leaves the fallback read | S |
| Unit id: machine id in `PowerShiftKeySchedule.GeneratingUnit` | C8 | **both**: mock carries GeneratingUnit ids; parser maps | M |
| CT `gLSKStrategy` (RA and bid) | I2 | **both**: remove from mock; parser stops requiring it | M |
| CT margins | I4 | parser only (optional) | M |
| Group limit chain and predicates | E3, G2 | **both** | S |
| `PowerBidSchedule.penaltyFactor`, `minEnergyBid`, `maxEnergyBid`, `stepSizeCTRD` | D15, D19, D20 | mock only; parser read stays as fallback, later removed | S |
| Direction literals and sign of p | D3, D4 | **both** | M |
| `interpolationKind` | D7 | parser only | M |
| `combinationConstraintKind` | A12 | parser only (mock already carries it) | M |
| HVDC penalty default | A4 | parser only | S |
| PST `valueKind` | B5 | parser only | S |
| `isActivationRestricted` | A15 | parser only | M |
| Per-RA cap | E1 | parser only, optional | M |
| Time-dependent availability | K1 to K3 | parser only, optional | M |
| Bid attributes with no model meaning (`isFixed`, `minimumActivationP`, `stepIncrementP`) | D13, D14 | parser only: warn | S |
| `PowerBidDependency` | D21 | leave | - |
| Non-RD/CT/PST/HVDC RA classes, EIC references | A9, A10, A19 | leave | - |
| G (`NCP_generic.zip`) | - | **leave unchanged**: it is the external sample and the only standard-form witness. Do not regenerate | - |

### 2.4 Test data to regenerate

| Item | Action |
|---|---|
| `tests/fixtures/NCP_pst_fallback_scenario.zip` (P) | regenerate by the WP0 converter. Recommended: keep the old file as `NCP_pst_fallback_scenario_legacy.zip` (used by fallback tests) and write the standard form under the current name, so the 13 test references keep working |
| `tests/fixtures/NCP_generic.zip` (G) | do not change |
| `tests/fixtures/ra_shared_tapchanger_preventive_and_curative.xml` | PST only, GSARA form is standard: unchanged |
| `tests/fixtures/milp_model_fingerprints.json` | regenerate only if WP0 shows a difference; otherwise it must stay byte-identical (that is the acceptance test) |
| `tests/hvdc_mock.py` | HVDC is already standard (H1, H2, H5): only penalty default (A4) and a `incrementalPercentage` case; builds on P so inherits the P change |
| `tests/ct_mock.py` | remove `gLSKStrategy` (2 places), group point chain (WP1), alias `.RemedialActionGroup` (1), `BidDirectionKind` -> `MarketRegulationDirectionKind`, p sign; builds on P |
| `tests/ncp_dataset.py` (55 KB, 49 users) | the generator of the covering dataset: update `gLSKStrategy` (4), alias (2), `minEnergyBid`/`maxEnergyBid`/`stepSizeCTRD` (3), `BidDirectionKind` (1); add cases for each new WP; `docs/ncp_dataset_coverage.md` follows |
| Tests that pin the mock form | `test_rao_ncp_parser.py` (RedispatchRemedialAction 9, group time point 4, `maxRegulating` 2, alias 4, `BidDirectionKind` 2, bid `penaltyFactor` 1): rewrite the expectations to the standard form and keep one test per old form that asserts the deprecation warning; `test_rao_ct_parser.py`, `test_rao_ct_mock.py`, `test_rao_ct_config.py`, `test_rao_ncp_dataset_variants.py` (`gLSKStrategy`): flip "no strategy is ignored" |

### 2.5 Goldens and fingerprints

`milp_model_fingerprints.json` hashes constraint families of models built from P (`helpers._MOCK_NX_NCP_ZIP`) and a
synthetic model. The hash covers row names and coefficients. Therefore:

- **They stay unchanged** if the converted standard-form P parses to the same `RDUnit`, `PowerBid`, GLSK, group,
  HVDC and CT objects (same mRIDs, same order, same numbers). Acceptance test: WP0 equivalence harness first,
  then the fingerprint test on the converted P.
- **They change** only for: (i) a bid whose direction or sign changes under the new rule (WP2, OPEN-11);
  (ii) an RD unit that is in the RotatingMachineAction list but not in the GLSK of P, or the other way round
  (WP3); (iii) HVDC cost where the mock omits `penaltyFactor` (WP7); (iv) `excluded` links if P has any (WP6).
  Each such change is a deliberate correction; the diff of the changed families is the review artefact.
- RA mRIDs must be kept when the class changes (GSARA to RedispatchRemedialAction); constraint names contain them.

## 3. OPEN items

Who: **DP** = data provider (the TSOs / NCP producer), **EN** = ENTSO-E (profile maintainers), **SO** = spec owner (us).

| OPEN | Question | Who |
|---|---|---|
| OPEN-1 | Which profile version is the target: RA 2.5.0 and SIS 2.5.0 (cover) or 2.5.1 (revision table), or the 2.4 of sample G? Removed in 2.5.x relative to G: CT `powerShiftKey`/`method`, `PowerBidDependency.kind/delay`. | DP, SO |
| OPEN-2 | HVDC missing `penaltyFactor`: spec default is 1. Is 0.0 (today) a deliberate choice? | SO |
| OPEN-3 | Meaning of `ElementCombinationConstraintKind.considered` for our optimiser (RA may be used for this contingency, and also for others?), and whether `excluded` removes the RA for that contingency only. | EN, SO |
| OPEN-4 | Curative RA without ContingencyWithRemedialAction: standard says invalid; we treat it as "all contingencies" for RD/CT/HVDC. Keep? | SO, DP |
| OPEN-5 | Does `isActivationRestricted` = true map to the "blocked group" and false to the "reduced group" of our PST groups? | EN |
| OPEN-6 | The PropertyReference collection (published values such as `RotatingMachine.p`, `EquivalentInjection.p`) is not in the PDFs; need the list. | EN |
| OPEN-7 | `RelativeDirectionKind.upAndDown` in an absolute StaticPropertyRange: symmetric plus/minus, or a single bound? Today PST upper only, HVDC plus/minus. | EN |
| OPEN-8 | `RangeConstraint.normalValue` is "the normal (initial) value" yet we use it as the limit of the range; confirm for StaticPropertyRange (and for `incrementalPercentage`: base value). | EN |
| OPEN-9 | A bid cannot point to a GSARA (type PowerRemedialAction). What do real RD data point to? Is `RedispatchRemedialAction` always used for market-based redispatch? | DP |
| OPEN-10 | Unit of the "per time unit" in `IntertemporalPropertyRange` (ramp). | EN |
| OPEN-11 | Direction of a bid: `direction` literal, sign of `p` (load sign), or both? What if they disagree, or `direction` is absent, `upAndDown` or `stable`? Are `p` values per time point the offered volume (not cumulative)? | EN, DP |
| OPEN-12 | Unit of `ActivePower` (W with multiplier M, or MW) is not stated. | EN |
| OPEN-13 | `reservePrice` is "price for reserving the step increment active power"; is it the price for reserving the bid volume as we use it for curative RD/CT? | EN, DP |
| OPEN-14 | `isFixed`: should a fixed bid be activated fully or not at all (binary)? | SO |
| OPEN-15 | `PowerBidDependency` constraint kinds: needed for up/down exclusivity? | SO |
| OPEN-16 | Precedence between `PowerRemedialActionTimePoint.maxRegulating*`, the bid volume `p` and the group `maxRegulating*`. | EN |
| OPEN-17 | RD key via `PowerShiftKeyDistribution.PowerBidSchedule` (per bid) or via `PowerShiftKeyStrategy` (per RA)? Which one does the data provider send? If both, which wins? | DP |
| OPEN-18 | PSKS resource types other than GeneratingUnit (PowerElectronicsUnit, EnergyConsumer, EquivalentInjection, ExternalNetworkInjection, SchedulingArea, ...): which occur in the data and how should each enter the redispatch? | DP |
| OPEN-19 | `ParticipationFactorTimePoint.atTime` absent: "schedules follow the bid time" (rule text); does that mean valid for every bid time point? | EN |
| OPEN-20 | How is the shift key strategy (sharing, priority, proportional for remaining capacity) expressed? `PowerShiftKeyStrategy` has no kind attribute. | EN |
| OPEN-21 | Rule `PowerShiftKeySchedule.ParticipationFactorTimePoint:dependency` ("1..n except if associated with PowerShiftKeyDistribution") reads inconsistently. | EN |
| OPEN-22 | Does the group `maxRegulatingUp/Down` apply for every dependency kind or only `restrictive`? The kind text describes a model-resolution case, not a power limit. | EN |
| OPEN-23 | `balanced` for sets of RD or CT RAs: what is the required balance? | EN |
| OPEN-24 | Which TSO's RA file holds a group shared by several TSOs? | DP |
| OPEN-25 | HVDC is a GSARA with an EquivalentInjectionAction; `balanced` text says power remedial actions "including HVDC". Is the HVDC RA to be a PowerRemedialAction? | EN |
| OPEN-26 | CT given by `BiddingZoneBorder` instead of `BiddingZone`: expected? | DP |
| OPEN-27 | `minEconomicPMargin` example arithmetic is inconsistent (90 % of 10 MW stated as 11 MW). Which formula is intended, and is "operating p" the unit's current P or its limit? | EN |
| OPEN-28 | End name `AvailabilityTimePoint.GenericAvailabilitySchedule` against class `GenericAvailableSchedule` (SIS Table 62): typo? | EN |

| OPEN-29 | A disabled `AssessedElementTimePoint` (`enabled` false): does it switch the element off for the whole run or only at that time; how is `atTime` matched to the run timestamp; is a missing time point "enabled"? | EN, DP |
| OPEN-30 | Sign of `p`: the profile text says load sign (positive = flow out of a node, so an up bid would be negative), the official 2.5 sample has up bids positive and down bids negative. Which is normative? (decision 92 follows the sample as a cross-check only) | EN |

**30 OPEN items.**

## 4. Questions for the spec owner and the decisions (23 Oct 2026)

Decisions are numbered in `docs/DECISIONS.md` (85 to 105). Questions 18 to 21 were added by the owner.

| # | Question | Phase 1 recommendation | Decision | DECISIONS |
|---|---|---|---|---|
| 1 | Target RA 2.5.0 + SIS 2.5.x, G (2.4) kept as legacy sample? | yes | **yes** | 85 |
| 2 | Standard first, old form as fallback with a deprecation warning? | yes | **yes** | 86 |
| 3 | Remove the old-form code in the next release? | yes | **yes** | 87 |
| 4 | RD units derived from the GLSK, `RotatingMachineAction` old form only? | yes | **yes** | 88 |
| 5 | GLSK resource that is not a GeneratingUnit: warn and drop? | warn and drop | **yes** | 89, 102 |
| 6 | CT without strategy defaults to `proportionalForRemainingCapacity`? | yes | **yes**, our own assumption (ASSUMPTIONS) | 90 |
| 7 | Read `maxEconomicPMargin` / `minEconomicPMargin`? | yes, after OPEN-27 | **no**, wait for OPEN-27 | 91 |
| 8 | Bid direction | sign of `p` authoritative | **changed**: the direction literal is authoritative (last word); no direction = warn and skip; sign only a cross-check (warn on disagreement, value unchanged); size = abs(p) | 92 |
| 9 | Correct the mock sign of `p`? | yes | **no**: bid signs and quantities of the mock are not touched | 93 |
| 10 | Apply `interpolationKind`? | yes | **yes** | 94 |
| 11 | Read `combinationConstraintKind`? | yes | **yes** for included and excluded; `considered` waits for OPEN-3 | 95 |
| 12 | Group limits for every dependency kind? | no | **no** | 96 |
| 13 | `isActivationRestricted` as PST group kind? | no | **no** | 96 |
| 14 | HVDC missing `penaltyFactor` = 1.0? | yes | **yes** | 97 |
| 15 | Per-RA `maxRegulating*` and time-dependent availability? | no, warn | **no**, warn only | 96 |
| 16 | Regenerate P in standard form, G untouched? | yes | **yes**, legacy copy of P kept | 98 |
| 17 | Fingerprints byte-identical on the converted P? | yes | **yes**; a difference = stop and report, not fix | 99 |
| 18 | `CountertradeRemedialAction.powerShiftKey` / `.method` | (not asked) | old-version attributes: warn if present, do not read; old `gLSKStrategy` still read as fallback | 100 |
| 19 | Unit routes (a) bid, (b) strategy | (not asked) | support both; for one bid the bid's own route wins, the strategy route is the RA-level fallback | 101 |
| 20 | Non-generator resources in a shift key schedule | (not asked) | not read, warn and drop with a count; SIS shift keys only, HVDC unaffected | 102 |
| 21 | Participation factors | (not asked) | relative weights normalised to sum 1 over the units of a key, warn when the raw sum is not 1 | 103 |

## 5. Decisions applied to the work packages

| WP | Change after the decisions |
|---|---|
| WP0 | done (section 6) |
| WP1 | unchanged (group limits on the standard chain; the dependency alias goes with it) |
| WP2 | direction rule of decision 92 replaces the sign rule of the phase 1 plan; the mock's signs and quantities stay (93); no `interpolationKind` change needed in the mock beyond what the converter adds (`none`) |
| WP3 | RD units from the GLSK; both routes (101); the converter already writes both |
| WP4 | non-generator resources warn and drop with a count (89, 102); factors normalised with a warning on a raw sum other than 1 (103; the code normalises already); GeneratingUnit to generator mapping as for unit costs |
| WP5 | strategy default (90); `maxEconomicPMargin` / `minEconomicPMargin` removed from the package (91); `powerShiftKey` / `method` warn (100); old `gLSKStrategy` kept as fallback |
| WP6 | `included` and `excluded` only (95); P has 74 links, all `included`, so P does not change |
| WP7 | A15 (`isActivationRestricted`) and E1 (`maxRegulating*`) dropped (96); A4 (HVDC penalty 1.0) stays (97); B5 (PST `valueKind`) stays |
| WP8 | regenerate P with `tools/convert_ncp_to_standard.py`, keep the legacy copy (98); acceptance rule 99 |
| WP9 (new) | disabled assessed element (K5, OPEN-29, decision 105); size M |

## 6. Work package 0: converter and equivalence harness (23 Oct 2026)

Files: `tools/convert_ncp_to_standard.py` (not imported by `src/`), `tests/test_rao_ncp_standard_equivalence.py`.
No `src/` change. Usage and options are in the module docstring; sections `groups`, `bids`, `redispatch`,
`glsk`, `countertrade`, `other` are independent and every change is written to the conversion log.

| Section | What the converter does | Harness result with the current parser |
|---|---|---|
| groups, dependency predicate | `RemedialActionDependency.RemedialActionGroup` -> `.DependingRemedialActionGroup` | pass (parsed groups equal) |
| groups, limit chain | `RemedialActionGroupSchedule` (interpolationKind `none`) and `RemedialActionGroupTimePoint.maxRegulatingUp/Down` | strict xfail, reader in WP1 (limits lost: None instead of 100 / 80) |
| bids | direction literal -> `MarketRegulationDirectionKind` (last word kept), `interpolationKind none` where missing; option: drop the four non-standard attributes | pass (32 bids equal); with the option the only difference is `PowerBid.penalty_factor` (1.0 -> 0.0) |
| bid without direction (variant) | removes the direction of one up bid | pass (read as up today); strict xfail for the decision 92 behaviour, reader in WP2 |
| redispatch | `GridStateAlterationRemedialAction` with `RotatingMachineAction` -> `RedispatchRemedialAction` (same mRID, `PowerRemedialAction.BiddingZone` from the Organisation profile), route (b) with a `PowerShiftKeyStrategy` element that points at the RA (32 RAs) | strict xfail, reader in WP3 (no RD unit found) |
| glsk | `PowerShiftKeySchedule.GeneratingUnit` carries the CIM GeneratingUnit id (64 schedules, 0 unresolved), `interpolationKind none` | strict xfail, reader in WP4 (every unit "not in the network"); factors and times unchanged: pass |
| countertrade | removes `gLSKStrategy` (RA and bid), `powerShiftKey`, `method` | strict xfail, reader in WP5 (the CT RAs are ignored) |
| other | dataset header `conformsTo` -> 2.5; `AssessedElementSchedule` / `AssessedElementTimePoint` (enabled true and false variants) | pass (ignored today); strict xfail for the disabled element, reader in WP9 |
| HVDC (already standard) | all sections run over the HVDC mock (preventive; preventive and curative) and the CT + HVDC mock | pass: units and balanced groups equal |
| PST | not touched | pass: the triples of the PST actions are equal |
| converter properties | deterministic (two runs, equal bytes); converting a converted zip changes nothing; a hand-made standard-form RA/SIS pair is returned byte for byte with an empty log; each section can be switched off; both routes present and equal; no strategy reference on an RA | pass |

Result: 22 passed, 6 xfailed (strict). With a converter that does nothing, 15 tests fail (including the strict
xfails, which then pass unexpectedly), so the harness does see the conversion.

Compared fields: all of `RDUnit`, `PowerBid`, the GLSK dictionaries, the group dictionaries, `HvdcUnit`,
`HvdcGroup`, `CtRa`, `AssessedElement`, except `RDUnit.raise_ramp_rate` / `lower_ramp_rate` (the standard
`RotatingMachineAction` has no ramp attributes; the MILP does not use them).

Gate: ﻿full suite (49 files, run in parallel by file): 1910 passed, 6 skipped, 6 xfailed (strict), 0 failed (before: 1888 passed, 6 skipped; the 22 new tests pass, the 6 xfails are the harness markers). `src/` is unchanged. Golden matrix, 42 runs (mock x2, generic, countertrade mock x2, HVDC mock, countertrade + HVDC mock; `ac_iterative`, `ac_single_pass`, `dc`; N-X off and on; hash seed 0): there is no stored baseline and no code change, so the matrix was run twice on the same code and compared with the rule of Next_Steps section 3.2: 672 of 738 files byte-identical, 40 of 42 cases equal under the rule; 2 cases (`ct ac_iterative countertrade` and `countertrade+rd`, N-X on) differ in one column, `loading_pct_nx_post_pra_model_diff_pct` of `results_nx_loadings.csv` (338 and 66 cells, largest |a-b| 4.3e-7 of the column maximum). The same difference appears between two serial runs of the same code (not load), so it is the run-to-run noise of ASSUMPTIONS 16, not this work; the maintainer may want to check why the noise in that column of the countertrade runs is larger than 1e-9 of its maximum. Fingerprints unchanged (the fingerprint test passed in the suite).

## 7. Official ReliCapGrid 2.5 sample against the old samples and the PDFs

| # | Item | PDFs (RA 2.5.0, SIS 2.5.x) | Official 2.5 `Belgovia_RA/SIS.xml` | Old sample G (2.4) | Our mock P | Used |
|---|---|---|---|---|---|---|
| 1 | Direction literal class | `MarketRegulationDirectionKind` {up, down, upAndDown, stable} | `MarketRegulationDirectionKind.up/.down` | `BidDirectionKind.up/.down` | `BidDirectionKind` | official; the parser matches the last word |
| 2 | Sign of `p` | load sign (up = negative) | up bids +100, +150; down bid -50; an RD bid without direction -125.46 | same values | positive magnitudes, direction literal | cross-check only (decision 92), OPEN-30 |
| 3 | Bid dependency | `PeerTemporalDependency.constraintKind` {exclusive, inclusive, restrictive}, `PeerTemporalDependency.mRID` | same | `PowerBidDependency.kind` (`PowerBidDependencyKind`), `.delay`, `PowerBidDependency.mRID` | absent | official; not read yet |
| 4 | Countertrade RA | no strategy attribute; `maxEconomicPMargin`, `minEconomicPMargin` | none of them on the sample RA | `powerShiftKey`, `method` | `gLSKStrategy` (RA and bid) | official (decisions 90, 91, 100) |
| 5 | Strategy element | `PowerShiftKeyStrategy` (RA profile, Description stereotype) with `PowerShiftKeyStrategy.PowerRemedialAction` | `rdf:about`, only that association and the mRID, attached to the second RD RA; its key has a `GeneratingUnit` | same, key without resource | none | official (decision 101) |
| 6 | Unit id in a key | `PowerShiftKeySchedule.GeneratingUnit` = GeneratingUnit | a GeneratingUnit of the CGM | the same | the SynchronousMachine id | official (finding C8) |
| 7 | Interpolation | `BaseTimeSeries.interpolationKind` 1..1 {none, previous, next, linear} | bids `next` / `previous`, keys `none` | bids `next` or absent | bids `next` or absent, keys absent | official; converter adds `none` where absent (no change of behaviour) |
| 8 | `PropertyReference` IRI | published collection | `http://iec.ch/TC57/CIM100#RotatingMachine.p` | `https://energy.referencedata.eu/PropertyReference/RotatingMachine.p` | the same as G | the parser compares the end of the string only |
| 9 | Currency IRI | `Currency` enumeration | `https://cim.ucaiug.io/ns#Currency.EUR` | `.../ns#` and `http://iec.ch/TC57/CIM100#` | `.../ns#` | tolerant |
| 10 | Dataset header | | RA `ap.cim4.eu/RemedialAction/2.5` but namespace `cim4.eu/ns/nc/2.4#`; SIS `.../StateInstructionSchedule/2.5` and `nc/2.4#` | 2.4 | 2.4 | converter writes 2.5 for the profile IRI, leaves the namespace |
| 11 | Inverse link `RemedialAction.ContingencyWithRemedialAction` | not in the tables | absent | present | absent | not written |
| 12 | Redispatch RA without ramp attributes | `RotatingMachineAction` has none | none | none | `raiseRampRate`, `lowerRampRate` | removed by the converter, logged |
| 13 | Group limits | `RemedialActionGroupSchedule` / `RemedialActionGroupTimePoint.maxRegulating*` | **no group in the sample** | none | none | PDF only: the group chain is unconfirmed by a sample (ASSUMPTIONS 14 stays) |
| 14 | `AssessedElementSchedule` | SIS-spec 3.68 to 3.71 | one, `enabled` false | one | none | converter variants (K5) |

## 8. Corrections to the phase 1 text

- Section 0 said the mock claims no version: its headers claim 2.4 (fixed above).
- D4 said "positive p with no direction is down by the standard": the PDF wording says so, the official sample
  contradicts it. Rewritten, OPEN-30 added.
- K5 and OPEN-29 were missing: the assessed element schedule (the official sample has a disabled element) was not
  in the table.
- C1: `GridStateAlterationRemedialAction.isActivationRestricted` is not an attribute of `RedispatchRemedialAction`;
  the converter drops it from the converted RD RAs and logs it.
- Confirmed, not wrong: P has 32 RD RAs with one `RotatingMachineAction`, one bid and one one-unit key each, so the
  units of the RA file and of the GLSK are the same 32 (the fingerprint claim of WP3 can hold for P); P has 74 contingency links, all
  `included` (WP6 does not change P); HVDC needs no conversion (harness passes).
- New ids: the strategy route needs new elements; their ids are `uuid5` of the RA and key ids (deterministic), not the ids of
  the old elements.
- WP count: 10 (WP9 new). OPEN items: 30. Rows: 96.

## 9. Report

- Alignment rows: **96**. OPEN items: **30**. Work packages: **10** (WP0 done).
- Questions: 17 asked, 4 added by the owner, all decided (section 4).

## 10. Status after the execution run (23 Oct 2026, WP1 to WP8)

Done in the parser, the converter and the fixtures; decisions DECISIONS 106 to 117; details in `ncp_alignment_progress.md`.

| Rows | Package | Status | Where |
|---|---|---|---|
| E3, G2 (group limit chain, dependency predicate) | WP1 | done | DECISIONS 106 |
| I2, I3 (countertrade without strategy, `powerShiftKey`/`method`) | WP5 | done; the default strategy is our own assumption | DECISIONS 107 |
| A4 (HVDC penalty default 1.0), E1/K1-K3/D21 (per-RA caps, availability schedules, bid dependencies: warn only) | WP7 | done | DECISIONS 108 |
| D1-D8, D13-D20 (bids: direction literal, sign cross-check, interpolation, unread attributes, non-standard attributes) | WP2 | done | DECISIONS 109, 113, 114 |
| A12 (combination constraint kind), K4 (disabled assessed element: warn only) | WP6 | done; `considered` is read as `included` with a warning | DECISIONS 110 |
| C8, F1-F4 (shift keys: generating unit mapping, both unit routes, non-generator resources, factors, optional `atTime`) | WP4 | done | DECISIONS 111, 112 |
| C1-C4, C6 (redispatch as `RedispatchRemedialAction`, units from the shift keys, bids on the RA) | WP3 | done; sample G's second redispatch RA is now recognised without units | DECISIONS 115, 116 |
| Fixtures and documents | WP8 | done: P regenerated, legacy copy kept, G unchanged | DECISIONS 117 |
| Disabled assessed element not monitored | WP9 | **not executed**: owner decision needed (OPEN-29); the strict xfail `test_rao_a_disabled_assessed_element_is_not_monitored` stays | - |

Rows not touched by the plan stay as analysed: B5 (PST `valueKind`), A15 (`isActivationRestricted`), I4 (margins, OPEN-27), A9, A10, A19, and the remaining OPEN items 1 to 30 except those answered by the decisions
above (OPEN-2 by 108, OPEN-3 by 110 in part, OPEN-9 by 115, OPEN-11 by 109/113/114, OPEN-17 and OPEN-19 and OPEN-21 by 111, OPEN-18 by 111).
Left for later (not in the plan): the mock builders `ct_mock.py` and `ncp_dataset.py` still write the old forms (`gLSKStrategy`, the group alias, `minEnergyBid`, `BidDirectionKind`, positive down bids) on top of P;
the old forms are removed from the parser in the next release (owner decision 3).
