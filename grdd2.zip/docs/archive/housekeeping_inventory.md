# Housekeeping inventory (read-only; nothing has been moved, renamed or deleted)

Counted on the working tree of branch `ncp-standard-alignment` (212 tracked files: `src` 105, `tests` 64, `docs` 20, `reference` 14, `input` 2, root and `.github` 7). The same tables are in `housekeeping_inventory.csv`. Nothing is executed until the owner approves this list; the owner has no git, so a deletion can be undone only from the local commits of this branch.

## 0. Summary

| Section | KEEP | ARCHIVE | DELETE | Other |
|---|---|---|---|---|
| A. `docs/` (20 files) | 13 | 3 | 4 | - |
| A. `reference/` (14 files, owner's call, lean only) | 6 | 8 | 0 | not edited by rule |
| A. root, `.github`, devcontainer (5 files) | 5 (3 need edits) | 0 | 0 | - |
| B. `tests/fixtures/` (6 files) | 6 (3 renamed) | 0 | 0 | no unused file, no unneeded duplicate inside the folder |
| B. `input/` (2 files) | 1 | 0 | 1 (`NCP_mock_cleaned.zip`) | + 1 new copy `NCP_mock_standard.zip` |
| C. generator scripts | - | - | - | 5 files MOVE into `mock_data/`; 3 scripts outside the repo ADD |
| E. leftovers | see E | | | |

Main findings:
1. **No test reads `input/`.** All tests build their own `input/` in `tmp_path` from `tests/fixtures`. So `input/` can hold exactly `CGM_package.zip` + `NCP_mock_standard.zip` without touching a test. Tests must keep reading the fixture copies (a user who puts real data into `input/` would break them otherwise).
2. **Everything that regenerates the data is either in `tests/` or outside the repo.** `tests/ct_mock.py`, `hvdc_mock.py`, `ncp_dataset.py` and `tools/convert_ncp_to_standard.py` are in the repo; the golden-matrix scripts, the baselines (2 x 21 MB), the gate script and the P-inventory script live only in the session scratch folder and would be lost.
3. **The finished alignment documents are still cited** by DECISIONS, ASSUMPTIONS, Spec_Coverage and the User Guide (OPEN-3, 11, 20, 22, 27, 29, 30 are defined only in `ncp_standard_alignment.md`). Archive them only after those items are copied to ASSUMPTIONS / Next_Steps and the pointers are changed.
4. **Rename risk is small**: tests use constants from `tests/helpers.py`; the names appear as text in 11 test files (plus conftest, helpers and the 3 builders), 1 source comment, 3 reference files, `.github/copilot-instructions.md` and about 12 docs (section D).

Main risks: moving the builders must not change one byte of the generated zips (the byte-equality test, the 42-run matrix and the fingerprints are the guard); the import change touches about 20 test files; `reference/` files cannot be edited so they keep the old names unless the owner decides otherwise; `mock_data/` is outside the "change only `src/rao`, tests and docs" scope of `.github/copilot-instructions.md`, which therefore needs a line.

Proposed order: (1) save the scratch scripts into the repo (no behaviour change); (2) `mock_data/` skeleton with `paths.py`; (3) move the builders one at a time with a re-export shim; (4) switch the test imports and remove the shims; (5) CLI; (6) rename and move the zips through `paths.py`; (7) docs: update, archive, delete. Details in sections C and D.

## A. Documentation

### A.1 `docs/` (20 files)

| File | Bytes | Purpose | Referenced by | Action | Reason | What breaks |
|---|---|---|---|---|---|---|
| docs/README.md | 6895 | Entry point: scope, flow, run and test commands, code layout, doc index. | docs: CHANGELOG.md(11), User_Guide.md(1); root: copilot-instructions.md(1) | KEEP | The map of the repo; needs an update (says 48 test files, now 53; tells to copy NCP_generic.zip for a mock run). | - |
| docs/User_Guide.md | 59733 | How to run, config, output files, NCP test data (where to run, names and content), shared-bid use cases. | docs: CHANGELOG.md(8), README.md(2), ncp_alignment_progress.md(1); root: copilot-instructions.md(1) | KEEP | Required by the contributor rules (output files / config keys); many file names inside change with the renames. | - |
| docs/DECISIONS.md | 63849 | Numbered decisions and reasons (1 to 125). | docs: CHANGELOG.md(6), User_Guide.md(2), ncp_alignment_execution_plan.md(1), ncp_standard_alignment.md(1), Next_Steps.md(1), README.md(1); reference: Design_Overview.md(1); root: copilot-instructions.md(3) | KEEP | Source of truth after code and tests. | - |
| docs/ASSUMPTIONS.md | 12706 | Assumptions about data and spec. | docs: CHANGELOG.md(6), Next_Steps.md(3), README.md(1), Spec_Coverage.md(1), User_Guide.md(1); reference: Design_Overview.md(1); root: copilot-instructions.md(2) | KEEP | Source of truth after code and tests. | - |
| docs/CHANGELOG.md | 67628 | One entry per task. | docs: Next_Steps.md(1), README.md(1), User_Guide.md(1); root: copilot-instructions.md(1) | KEEP | Required after every task; 252 lines, no pruning needed. | - |
| docs/Spec_Coverage.md | 64888 | Spec coverage per CORNET / BUC item, deviations, deferred items. | docs: CHANGELOG.md(12), calculation_mode_specs.md(1), DECISIONS.md(1), ncp_alignment_progress.md(1), README.md(1); reference: curative_rd_tatl_specs.md(5), R0_Data_Ingestion.md(2), R1_N0_PST_PRA.md(2), R2_RD_PRA_Basic.md(2), R3_NX_CRA.md(2), R4_MultiTimestamp_PST_RD.md(2) +3; root: copilot-instructions.md(1) | KEEP | Required by the contributor rules. Header calls itself 'reference document (background)': fix the wording. | - |
| docs/Next_Steps.md | 6954 | Rules and steps for the first run on the full input; rule 2 is the matrix comparison rule. | docs: ASSUMPTIONS.md(2), CHANGELOG.md(1), ncp_alignment_execution_plan.md(1), ncp_alignment_progress.md(1), README.md(1); root: copilot-instructions.md(1) | KEEP | Named by the contributor rules; the comparison rule is used by the golden matrix. | - |
| docs/calculation_mode_specs.md | 11291 | Feature spec W1-W8: calculation_mode and ra_types (implemented). | docs: CHANGELOG.md(5), Spec_Coverage.md(2), dc_mode_specs.md(1) | KEEP | Functional spec of an implemented feature; cited by code comments and Spec_Coverage. | - |
| docs/countertrade_ra_specs.md | 19813 | Feature spec C1-C12: countertrade RA (implemented). | code: data_model.py(2), rao_config.default.yaml(2), rao_config.yaml(2), milp_builder.py(2), run_pipeline.py(1), ct_results_export.py(1) +3; tests: test_rao_milp_builder_ct.py(2), ct_mock.py(1), test_rao_ct_config.py(1), test_rao_ct_mock.py(1), test_rao_ct_modes.py(1), test_rao_ct_outputs.py(1) +3; docs: Spec_Coverage.md(4), CHANGELOG.md(3), calculation_mode_specs.md(2), ncp_alignment_progress.md(2); reference: MILP_Mathematical_Formulation.md(2), Design_Overview.md(1) | KEEP | Cited by 12 source and test files. | - |
| docs/dc_mode_specs.md | 13900 | Feature spec D1-D10: DC calculation mode (implemented). | code: dc_pass.py(1); tests: test_rao_dc_conversion.py(1), test_rao_dc_mode.py(1), test_rao_dc_pass.py(1); docs: CHANGELOG.md(5), Spec_Coverage.md(2), calculation_mode_specs.md(1), DECISIONS.md(1), hvdc_ra_specs.md(1) | KEEP | Cited by dc_pass.py and 3 tests. | - |
| docs/hvdc_ra_specs.md | 15071 | Feature spec H1-H13: HVDC RA (implemented). | code: milp_builder.py(5), n0_results_export.py(4), run_pipeline.py(1), rao_config.default.yaml(1), rao_config.yaml(1), operating_point_state.py(1) +5; tests: test_rao_hvdc_sensitivity.py(2), hvdc_mock.py(1), test_rao_hvdc_gui_config.py(1), test_rao_hvdc_loop.py(1), test_rao_hvdc_milp.py(1), test_rao_hvdc_parser.py(1) +2; docs: Spec_Coverage.md(4), CHANGELOG.md(3), calculation_mode_specs.md(2), ncp_alignment_progress.md(2), dc_mode_specs.md(1), DECISIONS.md(1) +1; reference: Design_Overview.md(1), MILP_Mathematical_Formulation.md(1) | KEEP | Cited by about 10 source and test files. | - |
| docs/ncp_data_requirements.md | 80883 | What the NCP reader needs per class and predicate (rows by fixture code G, P, H, C ...). | tests: ncp_dataset.py(1), test_rao_ncp_dataset_valid.py(1), test_rao_ncp_dataset_variants.py(1); docs: ncp_alignment_progress.md(7), CHANGELOG.md(2), ncp_standard_alignment.md(2), User_Guide.md(2), ncp_dataset_coverage.md(1), Spec_Coverage.md(1) | KEEP | Cited by the dataset builders and 2 dataset tests; defines the fixture codes G and P. | - |
| docs/ncp_dataset_coverage.md | 30795 | Maps every requirement row to its data and test; section 8 = shared-bid cases. | tests: ncp_dataset.py(2), test_rao_ncp_dataset_valid.py(1), test_rao_ncp_dataset_variants.py(1); docs: ncp_alignment_progress.md(6), CHANGELOG.md(2), ncp_standard_alignment.md(2), User_Guide.md(2), DECISIONS.md(1), ncp_data_requirements.md(1) +1 | KEEP | Cited by ncp_dataset.py and 2 tests; names change with the renames. | - |
| docs/ncp_standard_alignment.md | 70056 | Analysis and plan of the NCP standard-form alignment (87 OPEN-ids, tables, owner decisions). | docs: ncp_alignment_execution_plan.md(2), User_Guide.md(2), ASSUMPTIONS.md(1), CHANGELOG.md(1), DECISIONS.md(1), ncp_data_requirements.md(1) +1 | ARCHIVE | Finished work (WP0-WP8 done). BUT DECISIONS and ASSUMPTIONS cite OPEN-3, 11, 20, 22, 27, 29, 30 that are defined here. | Pointers in DECISIONS (line 111), ASSUMPTIONS (line 11), Spec_Coverage (line 369), ncp_data_requirements, User_Guide must be re-pointed; first move the still-open OPEN items into ASSUMPTIONS or Next_Steps. |
| docs/ncp_alignment_execution_plan.md | 15918 | Instruction document for the execution run (S1-S3, WP1-WP8), owner decisions 1-25. | docs: User_Guide.md(1) | ARCHIVE | Executed and closed; its decisions are in DECISIONS 85-117. | Only the User_Guide mention (1) and the two other alignment documents; no code or test. |
| docs/ncp_alignment_progress.md | 41095 | Run log of the execution (stop reports, gate results, final report) and the shared-bid findings. | tests: test_rao_rd_shared_bid.py(1); docs: User_Guide.md(4), ncp_standard_alignment.md(2), CHANGELOG.md(1), ncp_alignment_execution_plan.md(1) | ARCHIVE | Mostly history (three stale 'Status: stopped' headers). The shared-bid sections are the only unique content: move their facts to DECISIONS 119-125 / ASSUMPTIONS (already summarised there) before archiving. | tests/test_rao_rd_shared_bid.py cites it in its docstring (comment only); User_Guide (4 mentions) and the other alignment documents. |
| docs/ncp_p_ra_inventory.md | 30462 | Generated inventory of the PST / RD RAs, bids and generators of P (tables A to D). | nothing | DELETE | Generated, regenerable; the User_Guide section 'NCP test datasets: names and content' has the summary. Only the generator script is needed. | Nothing reads it. The generator is NOT in the repo (scratch inv_p.py, 25.7 KB): save it into mock_data/ first, then it can be regenerated. |
| docs/ncp_p_inventory_pst.csv | 5757 | PST rows of the inventory (12 rows). | docs: ncp_p_ra_inventory.md(1) | DELETE | Same as the inventory md; derived data. | Only the inventory md links it. |
| docs/ncp_p_inventory_rd.csv | 14510 | RD rows of the inventory (32 rows). | docs: ncp_p_ra_inventory.md(1) | DELETE | Same. | Only the inventory md links it. |
| docs/ncp_p_inventory_bids.csv | 12284 | Bid rows of the inventory (32 rows). | docs: ncp_p_ra_inventory.md(1) | DELETE | Same. | Only the inventory md links it. |

Notes:
- All 20 files of `docs/` are in the table. The KEEP files are the working documents (README, User_Guide, DECISIONS, ASSUMPTIONS, CHANGELOG, Spec_Coverage, Next_Steps), the four feature specs and the two NCP data documents.
- `docs/archive/` does not exist yet; "ARCHIVE" = move into it, links inside the other docs then point to `docs/archive/<name>`.
- No test reads a document at runtime (rule of `.github/copilot-instructions.md`, checked: only comments and docstrings cite docs). So no test breaks from removing or moving a document; only the comments named above go stale.
- Can the inventory be regenerated? Only with the scratch script `inv_p.py` (reads P and the CGM with rdflib and pypowsybl and writes the markdown and 3 CSVs). Save it as `mock_data/tools/inventory_p.py` before deleting the outputs.

### A.2 `reference/` (14 files) - owner's call

`reference/` is not edited by rule, so these are leanings only; nothing was touched.

| File | Bytes | Purpose | Referenced by | Lean | Reason | What breaks |
|---|---|---|---|---|---|---|
| reference/spec/specs.md | 528249 | The functional specification (CORNET / BUC items), 528 KB. | code: milp_builder.py(7), n0_results_export.py(5), rao_config.default.yaml(3), rao_config.yaml(3), data_model.py(2), run_pipeline.py(2) +10; tests: test_rao_hvdc_sensitivity.py(2), test_rao_milp_builder_ct.py(2), ct_mock.py(1), hvdc_mock.py(1), test_rao_ct_config.py(1), test_rao_ct_mock.py(1) +14; docs: CHANGELOG.md(20), Spec_Coverage.md(15), calculation_mode_specs.md(7), ncp_alignment_progress.md(4), dc_mode_specs.md(3), hvdc_ra_specs.md(3) +4; reference: curative_rd_tatl_specs.md(9), MILP_Mathematical_Formulation.md(3), Design_Overview.md(2) | KEEP | Read by contributors; cited by about 15 files. | - |
| reference/spec/curative_rd_tatl_specs.md | 35050 | Requirement spec for curative RD, TATL, generator on/off, objective (implemented). | docs: Spec_Coverage.md(3), CHANGELOG.md(1) | KEEP | Cited by Spec_Coverage and CHANGELOG. | - |
| reference/technical/MILP_Mathematical_Formulation.md | 42915 | Equations of the MILP. | docs: CHANGELOG.md(3); reference: R3_NX_CRA.md(2), R1_N0_PST_PRA.md(1), R2_RD_PRA_Basic.md(1), Design_Overview.md(1) | KEEP | Background but used as the formula reference; cited by Design_Overview and the release plans. | - |
| reference/technical/Data_Validation_Reference.md | 69746 | What the pipeline checks on its inputs, where, and what it does. | docs: CHANGELOG.md(12); reference: R3_NX_CRA.md(1), Design_Overview.md(1) | KEEP | Cited 12 times by CHANGELOG. | - |
| reference/technical/Design_Overview.md | 8933 | Design overview (written 2026-10-12). | nothing | KEEP | Index of the technical references. Has a wrong link ('../release_plan/Spec_Coverage.md', the file is docs/Spec_Coverage.md). | - |
| reference/technical/Scalability_Report.md | 21849 | Run time and memory measurements. | docs: CHANGELOG.md(1), User_Guide.md(1); reference: Design_Overview.md(1) | KEEP | Measured facts; mentions the fixture names NCP_pst_fallback_scenario.zip and NCP_generic.zip (stale after the renames). | Only stale names; owner's call because reference/ is not edited. |
| reference/technical/Code_Review_Report.md | 25700 | Read-only code review of an early state (26 modules, 26 test files). | nothing | ARCHIVE | Outdated (now 31 modules, 53 test files, no smoke tests). | Nothing references it. |
| reference/release_plan/R0_Data_Ingestion.md | 28502 | Original release plan R0. | nothing | ARCHIVE | Original plan, partly out of date; Spec_Coverage is right where they differ. | Spec_Coverage cites the R files (2 mentions each); R3 is also cited by copilot-instructions, User_Guide, the formulation. |
| reference/release_plan/R1_N0_PST_PRA.md | 48588 | Original release plan R1. | nothing | ARCHIVE | As R0. | As R0. |
| reference/release_plan/R2_RD_PRA_Basic.md | 51149 | Original release plan R2. | nothing | ARCHIVE | As R0. | As R0. |
| reference/release_plan/R3_NX_CRA.md | 126021 | Original release plan R3 (126 KB). | docs: User_Guide.md(1); reference: R1_N0_PST_PRA.md(1), MILP_Mathematical_Formulation.md(1); root: copilot-instructions.md(1) | ARCHIVE | As R0; mentions NCP_generic once. | copilot-instructions (1), User_Guide (1), MILP formulation (1). |
| reference/release_plan/R4_MultiTimestamp_PST_RD.md | 59258 | Original release plan R4. | nothing | ARCHIVE | As R0 (multi-timestamp work is out of scope). | As R0. |
| reference/release_plan/R5_Generator_Physics.md | 30041 | Original release plan R5. | nothing | ARCHIVE | As R0. | As R0. |
| reference/release_plan/R6_HVDC_CT_SystemConstraints.md | 17524 | Original release plan R6. | docs: countertrade_ra_specs.md(1) | ARCHIVE | As R0. | countertrade_ra_specs.md (1). |

If the owner archives `reference/release_plan/` and `Code_Review_Report.md`, the citations in `docs/Spec_Coverage.md`, `docs/countertrade_ra_specs.md`, `.github/copilot-instructions.md`, `docs/User_Guide.md` and `reference/technical/MILP_Mathematical_Formulation.md` need a new path. `reference/` also keeps stale fixture names (Scalability_Report, R3) after the renames.

### A.3 Root and other documentation-like files

| File | Bytes | Purpose | Action | Reason |
|---|---|---|---|---|
| README.md | 80 | Two-line stub. | KEEP | Should point to docs/README.md and mock_data/README.md. |
| .github/copilot-instructions.md | 4998 | Contributor rules. | KEEP | Needs updates: fixture names, mock_data/ scope, 'tests use NCP_generic' (the mock case is P). |
| requirements.txt | 646 | Pinned requirements. | KEEP | - |
| pytest.ini | 59 | norecursedirs only. | KEEP | May get one line 'pythonpath = .' (see C). |
| .devcontainer/devcontainer.json | 770 | Dev container (Python 3.12.9, runs the suite). | KEEP | - |

## B. Fixtures

### B.1 `tests/fixtures/` (6 files, 2.57 MB)

| File | Bytes | Purpose | Used by / matrix / regenerable | Action | Note |
|---|---|---|---|---|---|
| tests/fixtures/CGM_package.zip | 2390641 | ReliCapGrid CGM (official sample, 9 areas). | tests: 29 files: ct_mock, hvdc_mock, ncp_dataset and 26 tests (ac_convergence_loop, cgmes_loader, ct_config, ct_mock, ct_modes, ct_outputs, ct_pipeline, ct_weights, dc_mode, dc_pass, hvdc_pipeline, hvdc_sensitivity, lf_parameters, n0_results_export, ncp_dataset_valid/variants, ncp_parser, ncp_standard_equivalence, nx_results_export, nx_sensitivity, output_file_registry, rd_shared_bid, run_pipeline_end_to_end, scanned_without_preventive, single_pass, text_encoding); conftest, helpers; golden matrix / fingerprints: yes (all 42 runs, fingerprints); regenerable: no (official sample) | KEEP | Identical to input/CGM_package.zip (same SHA-256, 2.4 MB tracked twice). |
| tests/fixtures/NCP_generic.zip | 59503 | G: official ReliCapGrid NCP sample, profile 2.4, unchanged. | tests: 11 test files (ac_convergence_loop, ct_parser, ct_pipeline, ct_weights, dc_pass, hvdc_parser, ncp_loader, ncp_parser, output_file_registry, run_pipeline_end_to_end, single_pass) + conftest.real_input_folder / helpers.build_fixture_input_folder; golden matrix / fingerprints: yes (generic__* cases, fingerprint fixture_run); regenerable: no (official sample) | KEEP | Rename to NCP_sample_generic_2_4.zip. |
| tests/fixtures/NCP_pst_fallback_scenario.zip | 57660 | P: standard-form mock NCP; base of every builder. | tests: 24 test files (18 direct: ac_convergence_loop, ct_pipeline, dc_pass, hvdc_pipeline, lf_parameters, n0_results_export, ncp_standard_equivalence, nx_results_export, output_file_registry, rd_shared_bid, run_pipeline_end_to_end, scanned_without_preventive, single_pass, text_encoding, 3 builder-based tests; 6 only through the builders: ct_config, ct_modes, ct_outputs, hvdc_sensitivity, ncp_dataset_valid, ncp_dataset_variants) + conftest.mock_nx_pipeline_run, the 3 builders; golden matrix / fingerprints: yes (mock__ cases and the base of ct__, hvdc__, cthvdc__; fp_check); regenerable: yes: tools/convert_ncp_to_standard.py from the legacy copy; a test asserts byte equality | KEEP | Rename to NCP_mock_standard.zip. |
| tests/fixtures/NCP_pst_fallback_scenario_legacy.zip | 55924 | Old-form mock (source of the converter, fallback tests). | tests: 1 test file (ncp_standard_equivalence) + helpers constant; golden matrix / fingerprints: no (the equivalence harness only); regenerable: no (hand-made origin, first committed as input/NCP_mock_cleaned.zip in July 2026) | KEEP | Rename to NCP_mock_legacy.zip. Identical to input/NCP_mock_cleaned.zip (same SHA-256). |
| tests/fixtures/milp_model_fingerprints.json | 4969 | Expected MILP model fingerprints (fixture_run, synthetic). | tests: 1 test file (milp_builder_nx) + helpers; golden matrix / fingerprints: yes (it is the fingerprint reference); regenerable: yes: helpers.write_milp_model_fingerprints | KEEP | - |
| tests/fixtures/ra_shared_tapchanger_preventive_and_curative.xml | 2183 | Hand-written RA XML with two GSARAs on one tap changer. | tests: 1 test file (ncp_parser); golden matrix / fingerprints: no; regenerable: no (hand-made, 2 KB) | KEEP | Used by one test only; fine. |

- Every file is used by at least one test; none is unused. Golden matrix and fingerprints need the five data files above (the XML is used by one parser test only).
- Two duplicates exist across folders, not inside `tests/fixtures`: `input/CGM_package.zip` = `tests/fixtures/CGM_package.zip` and `input/NCP_mock_cleaned.zip` = `NCP_pst_fallback_scenario_legacy.zip` (same SHA-256).
- Regeneration: P by `python tools/convert_ncp_to_standard.py tests/fixtures/NCP_pst_fallback_scenario_legacy.zip OUT.zip --cgm tests/fixtures/CGM_package.zip --drop-nonstandard-bid-attributes` (all sections and the sign correction are the defaults; `test_rao_ncp_standard_equivalence` asserts that the shipped P equals this output byte for byte); the fingerprint file by `helpers.write_milp_model_fingerprints`; CGM, G and the legacy mock cannot be regenerated (official samples and a hand-made mock).

### B.2 `input/`

| File | Bytes | Purpose | Action | Reason |
|---|---|---|---|---|
| input/CGM_package.zip | 2390641 | Default input of a plain run (CGM). | KEEP | Duplicate of the fixture (SHA-256 equal); stays as the demo input. |
| input/NCP_mock_cleaned.zip | 55924 | Default input of a plain run (NCP) = the legacy mock. | DELETE | Replace by input/NCP_mock_standard.zip (copy of the standard P); the legacy copy lives in tests/fixtures. |

`input/_extracted_cgm` (27 files, 15.6 MB) and `input/_extracted_ncp` (19 files) are untracked run products (ignored).

## C. Mock-data generators

### C.1 What exists

| Path | Bytes | Purpose | Imported by |
|---|---|---|---|
| tests/ct_mock.py | 18737 | Countertrade mock NCP builder on top of P (build_ct_mock_ncp, build_ct_and_hvdc_mock_ncp, _fixed_entry). | imported by 9 modules: ncp_dataset, test_rao_ct_config, ct_mock, ct_modes, ct_outputs, ct_pipeline, ncp_dataset_valid, ncp_dataset_variants, ncp_standard_equivalence; imports helpers and hvdc_mock |
| tests/hvdc_mock.py | 11351 | HVDC mock NCP builder on top of P (build_hvdc_mock_ncp, default/curative RAs, groups). | imported by 8 modules: ct_mock, ncp_dataset, ct_modes, hvdc_pipeline, hvdc_sensitivity, ncp_dataset_valid, ncp_dataset_variants, ncp_standard_equivalence; imports helpers |
| tests/ncp_dataset.py | 71056 | Valid NCP dataset, invalid and warning variants, data rules, shared-bid cases (A, A_strategy, B_preventive, C_preventive, D_espheim). | imported by test_rao_ncp_dataset_valid, test_rao_ncp_dataset_variants, test_rao_rd_shared_bid; imports ct_mock, hvdc_mock, helpers |
| tools/convert_ncp_to_standard.py | 31934 | Old-form to standard-form NCP converter with CLI (produced the shipped P). | imported by tests/helpers (mock_generators_by_unit) and test_rao_ncp_standard_equivalence via a sys.path hack; not imported by src |
| tests/helpers.py | 56156 | Mixed: fake data objects of unit tests (stay) and data builders: path constants, run_pipeline_on_fixture_inputs, fixture_instance_root, build_fixture_input_folder, mock_generators_by_unit, fingerprint helpers. | imported by 43 modules |
| tests/conftest.py | 2426 | Fixtures real_input_folder and mock_nx_pipeline_run; puts src/rao and the repo root on sys.path. | pytest |

Outside the repo (session scratch folder, lost when it is cleaned):

| Script | Purpose | Where |
|---|---|---|
| (scratch) run_case.py, run_matrix.py, compare_runs.py, run_suite.py, run_gate.py, fp_check.py | Golden matrix (42 runs), comparison rule, suite in parallel, fingerprint check, gate. | outside the repo (session scratch folder); baselines mxA and mxB 21 MB each |
| (scratch) inv_p.py | Generator of docs/ncp_p_ra_inventory.md and its CSVs. | outside the repo, 25.7 KB |
| (scratch) gitc.py | Local commits with dulwich (no git executable). | outside the repo |

Builders inside `tests/helpers.py` that belong to the data side: `_FIXTURES`, `_MOCK_NX_CGM_ZIP`, `_MOCK_NX_NCP_ZIP`, `_MOCK_NX_NCP_LEGACY_ZIP`, `FIXTURE_CGM_ZIP`, `FIXTURE_NCP_GENERIC_ZIP`, `fixture_instance_root`, `build_fixture_input_folder`, `mock_generators_by_unit`, `run_pipeline_on_fixture_inputs` (runs the pipeline; stays a test helper), and the fingerprint helpers (`milp_model_fingerprint*`, `synthetic_curative_milp_inputs`, `fixture_run_models`, `write_milp_model_fingerprints`; test side, stay).

### C.2 Proposal: top-level `mock_data/`

```
mock_data/
  README.md                 what it is, the commands below, the rule "generators only; no test code, no src import"
  __init__.py
  paths.py                  REPO, FIXTURES, INPUT and the file names of CGM / standard / legacy / sample zips (one place to rename)
  zipio.py                  _fixed_entry, append/replace helpers now spread over ct_mock and ncp_dataset
  convert_ncp_to_standard.py  (from tools/, CLI kept)
  hvdc_mock.py  ct_mock.py  ncp_dataset.py   (from tests/; internal imports relative)
  cli.py + __main__.py      python -m mock_data ...
  golden/                   run_case.py run_matrix.py compare_runs.py fp_check.py run_gate.py (+ README; baseline as one zip, ~4 MB, or regenerate)
  tools/inventory_p.py      the P inventory generator
```
Commands (all deterministic, fixed zip time stamps):
- `python -m mock_data standard [--out PATH]` - convert the legacy copy with the documented options (the shipped standard P).
- `python -m mock_data check` - SHA-256 of the fixture zips, standard = converter(legacy), prints differences.
- `python -m mock_data variant ct|hvdc|cthvdc|dataset OUT.zip`, `python -m mock_data dataset-variant NAME OUT.zip`, `python -m mock_data shared-bid A|A_strategy|B_preventive|C_preventive|D_espheim OUT.zip`.
- `python -m mock_data install-input` - copy `CGM_package.zip` and `NCP_mock_standard.zip` into `input/` (refuses to overwrite any other `cgm*`/`ncp*` zip).
- `python -m mock_data inventory-p` - regenerate the P inventory (only if the owner wants it back).

README outline: purpose; file map; the commands; the rules (zips are byte-stable, sample zips are official and unchanged, no real data); how to add a variant; how the tests and the golden matrix use it; known limits (legacy mock and official samples cannot be regenerated).

Import changes:
- `mock_data/*.py`: `from helpers import _FIXTURES, _MOCK_NX_NCP_ZIP` becomes `from .paths import FIXTURES, STANDARD_ZIP`; `import ct_mock` / `import hvdc_mock` become `from . import ct_mock, hvdc_mock`; `ct_mock._fixed_entry` becomes `zipio.fixed_entry`. The reverse dependency (a generator importing a test helper) disappears.
- `tests/helpers.py`: the path constants are imported from `mock_data.paths` under the same names (so the 40 users of `_MOCK_NX_*` do not change); `mock_generators_by_unit` uses `from mock_data import convert_ncp_to_standard`.
- Tests: `import ct_mock` (9 files), `import hvdc_mock` (8), `import ncp_dataset` (3) become `from mock_data import ct_mock` etc.; `test_rao_ncp_standard_equivalence.py` replaces its `tools` path hack by `from mock_data import convert_ncp_to_standard`.
- `sys.path`: `tests/conftest.py` already inserts the repo root, but only after `from helpers import ...` has run, so `helpers.py` must insert `REPO_ROOT` itself before importing `mock_data`, or `pytest.ini` gets `pythonpath = .` (one line in a root config file: owner's approval).
- Transition shim: during the move leave `tests/ct_mock.py` etc. as a three-line re-export (`import sys; from mock_data import ct_mock as _m; sys.modules[__name__] = _m`; `from ... import *` would hide the underscore names the builders use). Remove the shims in step 4.

Risks: (1) any change of bytes in a generated zip (guards: byte-equality test, matrix, fingerprints); (2) circular imports (`paths.py` imports nothing; `helpers` imports `mock_data.paths` only); (3) the GUI must not import `mock_data`; (4) `.github/copilot-instructions.md` scope and the line "a test file never imports another test file" stay true (builders are not test files); (5) the converter's CLI path changes in 8 docs.

Order of steps (suite green after each; run the full suite after steps 3, 4, 6, matrix + fingerprints after 3, 4, 6):
1. Copy the scratch scripts (`golden/`, `tools/inventory_p.py`) into the repo, untouched, with a README. No test impact.
2. Create `mock_data/` with `__init__.py`, `paths.py`; `helpers.py` imports the constants from it. Suite green.
3. Move, one module per commit, with shim: `convert_ncp_to_standard.py`, then `hvdc_mock.py`, then `ct_mock.py` (+ `zipio.py`), then `ncp_dataset.py`.
4. Change the test imports (about 20 files), delete the shims and the empty `tools/`.
5. Add the CLI and 3 small tests (standard equals shipped P, check, install-input into a tmp folder).
6. Rename and move the zips by editing `paths.py` and the names in the 11 test files, conftest, the builders and 1 source comment (section D).
7. Docs: update README, User_Guide, copilot-instructions, DECISIONS (new entry); then the ARCHIVE / DELETE of section A.

## D. `input/` and the names

References (from the working tree, counts in brackets):

- `NCP_mock_cleaned.zip`: docs only - User_Guide (6), ncp_alignment_progress (1), ncp_standard_alignment (1). No code, no test.
- `NCP_pst_fallback_scenario.zip` (standard P): tests - conftest (1), ct_mock (1), helpers (1), hvdc_mock (1), ncp_dataset (1), test_rao_ac_convergence_loop (2), test_rao_ncp_standard_equivalence (1), test_rao_run_pipeline_end_to_end (5), test_rao_scanned_without_preventive (1); docs - CHANGELOG, DECISIONS (3), User_Guide (9), hvdc_ra_specs, ncp_alignment_execution_plan (2), ncp_alignment_progress, ncp_data_requirements, ncp_dataset_coverage, ncp_p_ra_inventory, ncp_standard_alignment (3); reference - Scalability_Report (1). No `src` reference.
- `NCP_pst_fallback_scenario_legacy.zip`: tests - helpers (1); docs - CHANGELOG, DECISIONS, User_Guide (5), ncp_alignment_progress, ncp_data_requirements, ncp_dataset_coverage, ncp_standard_alignment.
- `NCP_generic.zip`: `.github/copilot-instructions.md` (1); src - `pre_milp/ncp_parser.py` (1, a comment); tests - helpers (3), test_rao_ac_convergence_loop, ct_pipeline, dc_pass, hvdc_parser (2), ncp_loader, ncp_parser (2), output_file_registry, run_pipeline_end_to_end (2), single_pass; docs - CHANGELOG (4), DECISIONS, README (2), User_Guide (9), hvdc_ra_specs, ncp_data_requirements, ncp_standard_alignment (3); reference - R3_NX_CRA (1), Scalability_Report (2).
- `CGM_package.zip` (name stays): the same kind of places; no change needed.
- The golden-matrix scripts and the gate use `helpers._MOCK_NX_NCP_ZIP` and `FIXTURE_NCP_GENERIC_ZIP`, so they follow `paths.py`.

Proposed final state:
- `input/`: `CGM_package.zip` and `NCP_mock_standard.zip` only (the pipeline needs exactly one `cgm*.zip` and one `ncp*.zip`; any other zip left there makes a run fail with "not unique"). `NCP_mock_standard.zip` is a byte-identical copy of the fixture, written by `python -m mock_data install-input`; `NCP_mock_cleaned.zip` is deleted (it is the legacy mock).
- `tests/fixtures/`: `CGM_package.zip`, `NCP_mock_standard.zip` (was `NCP_pst_fallback_scenario.zip`), `NCP_mock_legacy.zip` (was `..._legacy.zip`), `NCP_sample_generic_2_4.zip` (was `NCP_generic.zip`), `milp_model_fingerprints.json`, `ra_shared_tapchanger_preventive_and_curative.xml`. Tests keep reading only these.
- Not recommended: making `input/NCP_mock_standard.zip` the only copy. 24 test files would then depend on a folder the owner overwrites with real data, and the contributor rules forbid touching `input/`.
- Tests that currently read `input/`: **none**. Tests that need a new path after the move: none for `input/`; for the renames the 11 test files with the names as text (ac_convergence_loop, ct_pipeline, dc_pass, hvdc_parser, ncp_loader, ncp_parser, output_file_registry, run_pipeline_end_to_end, single_pass for G and P; plus ncp_standard_equivalence and scanned_without_preventive for P) and `tests/conftest.py`, `tests/helpers.py` and the 3 builders.

## E. Other leftovers

1. **Outside the repo**: the session scratch folder (121 files: gate outputs, the matrix baselines `mxA`/`mxB` 21.2 MB each, profile text dumps `RemedialAction*.txt` / `StateInstructionSchedule*.txt` of 0.2-0.6 MB which must not be committed) and `C:\Temp` (`rd_shared\`, `d_edit*.json`, `refs_docs.json`, `hk_*.json`, `x.txt`). Safe to delete after step 1 of the order.
2. **Stale `output/`** (ignored, 21 files): old names `results_rd.csv`, `results_ra_count.csv`, `results_ra_groups.csv`, `sensitivity_nx.csv` from an earlier version; the pipeline deletes only registered names, so these stay. Safe to delete.
3. **`logs/`**: 7 empty `pytsc_*.log` (ignored).
4. **Caches** (ignored, untracked): 12 `__pycache__` folders, `.pytest_cache`, `tools/__pycache__`. Nothing tracked is a cache, an output or a log (checked on the 212 tracked files).
5. **Document drift**: `docs/README.md` (48 test files, now 53; mock run with `NCP_generic.zip`), `.github/copilot-instructions.md` (says the tests use `NCP_generic.zip`), root `README.md` is a two-line stub, `Spec_Coverage.md` calls itself background, `Design_Overview.md` has a wrong link, `Code_Review_Report.md` is outdated, `ncp_alignment_progress.md` has three stale "Status: stopped" headers, `.gitignore` comment about the committed input zips changes with step 6.
6. **GUI** (not touched by rule): empty placeholder pages `src/olf_pages/7_OLF_Apply_Remedial_Actions.py`, `8_Open_RAO.py`, `src/pf_pages/6_PF_Apply_Remedial_Actions.py` (0 bytes); `load_flow_config.yaml` equals `load_flow_config.default.yaml` (by design).
7. **Duplicated tracked data**: `input/CGM_package.zip` (2.4 MB) = fixture; `input/NCP_mock_cleaned.zip` = legacy mock.
8. **`tests/helpers.py`** (56 KB, 43 importers) mixes unit-test fakes with data builders; the data side moves to `mock_data/paths.py` and the rest can stay.
