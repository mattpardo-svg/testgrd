# Unattended run report (review fixes, then performance)

State: finished. Branch `ncp-standard-alignment`, local commits, nothing pushed, `main` untouched; nothing in `input/` or `reference/` edited; no new dependency.

## Summary

**Done.** Part 1 (review fixes): stages 1, 2 and 4 done; stage 3 deliberately not implemented because the spec requires the single row (quote below). Part 2 (performance): items 1 to 5 done, item 6 done as the streaming of the CGM EQ files (the largest remaining result-identical item); the other candidates of item 6 would change results and are listed, not applied. Nothing was reverted. Every stage and item passed the full gate: suite (2162 passed, 6 skipped, 1 xfailed, 64 test files at the end), the 42-run matrix with 0 differences against both stored baselines (rule 2 of `docs/Next_Steps.md` section 3, now with integer cells exact), MILP fingerprints byte-identical, and the byte-equality test of the shipped P. The last code commit is `ea60a85`; the final gate was run again on the tree of commit `11ae15f` (code identical, only this report added): 2162 passed, 6 skipped, 1 xfailed in 64 files; matrix 42 cases, 0 differences against both baselines; fingerprints identical; byte-equality test passed.

**Reverted:** nothing. One gate run failed and was fixed (item 4: 5 tests; cause: the pipeline function had been renamed and a test counted `_load_graph` calls without the new keyword; fixed with a decorator and a keyword in the test stand-in, no assertion changed or weakened). **Tests adapted on purpose, assertions kept:** `test_the_pipeline_parses_each_eq_file_once` (counts the stream calls too, item 4 and 6) and, in the new tests, nothing else; `test_rao_rd_shared_bid.py` got one more assertion (the real reason in the countertrade IGNORED lines).

**Before and after (same machine, PYTHONHASHSEED=0, back to back, mock with N-X on, `mock_data/golden/timing.py`):**

| Case | Before (741c659) | After (ea60a85) |
|---|---|---|
| pst+rd | 11.5 s, 392 MB peak | 6.8 s, 360 MB peak (-41 %) |
| pst+rd+countertrade | 20.8 s, 403 MB | 11.0 s, 395 MB (-47 %) |

At pan-European scale the gains that matter are not visible on the mock (2 to 10 contingencies): N-X sensitivities as numpy tables (memory 18 times less and 20 times faster on a generated set; 2000 branches x 30 units x 300 contingencies = 18 million entries in 277 MB and 7.4 s instead of about 3 GB), curative redispatch rows without the quadratic scans (480 contingencies: 19.0 s to 1.7 s), the N-0 guard (129000 entries: 12.7 s to 0.02 s), the export (3000 rows x 600 units: 4.5 s to 0.25 s), EQ streaming (4 MB file: 2.0 s to 0.11 s; a 33 MB file in 28 MB).

**Part 1 in short.** Stage 1: 7 new counting warnings (shift keys of countertrade, contingencies without `normalMustStudy`, non-restrictive dependencies, disabled grid state alterations, standard RD RAs with old actions, assessed-element switches and links) + OPEN-31; the countertrade IGNORED line names the real reason; the assessed-element link classes no longer give "spec violation"; bids and bid-route distributions are found by rdf:ID (findings 1, 2, 4, 5, 6, 7, 8 and 9 of the review were checked by new tests: 18 of the 21 tests of stages 1 and 2 fail on the code before the fixes, commit 6a7ec9c, and pass after; the 3 that pass before are the ones that assert no new warning where there is nothing to warn about). Stage 2: bids with points on several days are read by date and time. Stage 3: not implemented (below). Stage 4: DECISIONS 20, 31, 37, 73, 104, 117, 118, 125, 126 corrected, the 7 broken line breaks of DECISIONS 112 and 115 repaired, ASSUMPTIONS sentence rejoined, HVDC config comment fixed, the golden comparison treats integer cells as exact (found nothing).

**Not applied because it would change results (list for the owner):** dropping the zero-sensitivity terms from the N-X rows (Pyomo 6.10.1 keeps `0.0*x` as a term, so the expression text, the fingerprints and perhaps the HiGHS path change; DECISIONS 39); a persistent APPSI solver or warm start between iterations (review rank 6; variable and row order may change); building the rows with `quicksum`/`LinearExpression` (a flatter tree, but other expression text); merging the two N-0 sensitivity runs (numerical noise, ASSUMPTIONS 16); `lf_thread_count` above 1 (ASSUMPTIONS 15); a solver time limit or gap. After this run Pyomo expression handling (APPSI `collect_vars_and_named_exprs`, `standard_repn`) is more than half of a countertrade run and the network load (1.75 s) is the next largest fixed part.

**Dependencies:** none added. Wish: `psutil` for the memory column of `timing.py` on non-Windows systems (it uses the Windows API through ctypes now).

## Progress

| Step | State | Gate (suite / matrix / fingerprints / byte-equality) | Commit |
|---|---|---|---|
| 0 review report committed unchanged | done | - | 6a7ec9c |
| P1 stage 1 warnings, lookup, messages | done | suite 2098 passed, 6 skipped, 1 xfailed (56 files); matrix 42 cases 0 differences vs both baselines; fingerprints identical; byte-equality passes | 0fa9e32 |
| P1 stage 2 bid time points | done | suite 2106 passed, 6 skipped, 1 xfailed (57 files); matrix 0 differences vs both baselines (no cell moved on mock or samples); fingerprints identical; byte-equality passes | c123f4b |
| P1 stage 3 curative Pmin/Pmax per contingency | stopped by the spec, no code change (DECISIONS 130) | no code changed; covered by the stage 4 gate | with stage 4 |
| P1 stage 4 docs | done | suite 2110 passed, 6 skipped, 1 xfailed (58 files); matrix 0 differences vs both baselines; golden comparison with exact integer cells found nothing; fingerprints identical; byte-equality passes | 741c659 |
| P2 item 1 N-X sensitivities | done | suite 2128 passed, 6 skipped, 1 xfailed (59 files); matrix 0 differences vs both baselines; fingerprints identical; byte-equality passes | 24c6fea |
| P2 item 2 curative model rows | done | suite 2130 passed, 6 skipped, 1 xfailed (60 files); matrix 0 differences vs both baselines; fingerprints identical; byte-equality passes | 1bca34a |
| P2 item 3 N-0 sensitivity check | done | suite 2138 passed, 6 skipped, 1 xfailed (61 files); matrix 0 differences vs both baselines; fingerprints identical; byte-equality passes | f42a202 |
| P2 item 4 graph parsed once | done (first gate run failed 5 tests because the pipeline function was renamed and a test counted _load_graph calls without the new keyword; fixed by a decorator instead of a rename and by a keyword in the test stand-in, no assertion changed; the second gate is the one listed) | suite 2143 passed, 6 skipped, 1 xfailed (62 files); matrix 0 differences vs both baselines; fingerprints identical; byte-equality passes | 55210db |
| P2 item 5 N-X results export | done | suite 2147 passed, 6 skipped, 1 xfailed (63 files); matrix 0 differences vs both baselines; fingerprints identical; byte-equality passes | 059777e |
| P2 item 6a CGM EQ files streamed (review rank 5) | done | suite 2162 passed, 6 skipped, 1 xfailed (64 files); matrix 0 differences vs both baselines; fingerprints identical; byte-equality passes | ea60a85 |

## Timings (performance part; same machine, PYTHONHASHSEED=0, before/after measured back to back)
The speed of the machine drifts between sessions (the first reference run took 11.4 s, the same code 17.0 s later), so every item is compared with the committed state before it, run in the same minutes.

| Item | Case | Before | After |
|---|---|---|---|
| 1 N-X sensitivity table | mock pst+rd, N-X on (2 contingencies) | 17.0 s, 398 MB | 17.2 s, 390 MB |
| 1 | sensitivity stage, 2000 branches x 30 units x 20 contingencies (generated) | dict 10.1 s, 303 MB | table 0.5 s, 17 MB |
| 2 curative RD rows | mock pst+rd, N-X on | 11.4 s, 390 MB | 11.4 s, 390 MB |
| 2 | mock pst+rd+countertrade, N-X on | 20.9 s, 403 MB | 20.8 s, 403 MB |
| 2 | generated: 40 units x 2 curative RAs, 240 contingencies (19200 pairs), model build | 5.0 s | 0.7 s |
| 2 | generated: 480 contingencies (38400 pairs), model build | 19.0 s | 1.7 s |
| 3 N-0 guard | generated: 3000 branches x 43 elements (129000 entries), resolve_n0 | 12.7 s | 0.02 s |
| 3 | mock (20 branches) | no measurable change | |
| 4 graphs parsed once | mock pst+rd, N-X on | 11.4 s, 392 MB | 11.0 s, 411 MB |
| 4 | mock pst+rd+countertrade, N-X on | 20.8 s, 404 MB | 16.0 s, 400 MB |
| 5 N-X export | mock pst+rd, N-X on | 10.8 s | 10.9 s |
| 5 | mock pst+rd+countertrade, N-X on | 15.9 s | 15.1 s |
| 5 | generated: effect of 3000 rows x 600 units | 4.5 s | 0.25 s |
| 6 EQ files streamed | mock pst+rd, N-X on | 10.7 s, 411 MB | 6.8 s, 360 MB |
| 6 | mock pst+rd+countertrade, N-X on | 15.0 s, 402 MB | 11.0 s, 393 MB |
| 6 | EQ file of 4 MB: read the three maps | rdflib 2.0 s | stream 0.11 s |
| 6 | generated EQ file of 33 MB | (rdflib: about 1 KB per triple, not run) | 28 MB peak memory |
| 1 | 2000 x 30 x 300 contingencies = 18 million entries (generated) | about 3 GB as dicts (estimate) | 7.4 s, 277 MB peak (test budget 450 MB / 60 s) |

## Reverted or skipped
- Part 1 stage 3 (curative Pmin/Pmax per contingency): not implemented. The spec requires the single row. Quote, `reference/spec/curative_rd_tatl_specs.md` R7: "1. One constraint pair (lower and upper bound) per unit, not per contingency." / "4. The formula above is the requirement and is not changed." / "6. ... In the net form the up and down maxima can cancel, so R7 can be looser than today's per-contingency check (example: up 40 under c1 and down 60 under c2 gives 120 + 40 - 60 = 100, accepted; today's check rejects c1 at 160 against Pmax 150). R7 therefore changes real results." Per-contingency rows would reject the plan that item 6 accepts. Only DECISIONS 73 was corrected (stage 4); DECISIONS 130 records this.
- `reference/technical/MILP_Mathematical_Formulation.md` was not touched (reference/ is not edited).

## Findings checked
- Finding 10 of section 0.1 of the review (byte damage) is only partly right: the review counts 6 bare CR bytes in DECISIONS 112 and 115; the file has 7 places where a letter was lost and a CR LF pair stands in its place (one is an `n` lost to `\n`).
- Finding 3 (stage 3) is real as a description of the net form, and the spec states it itself (R7 item 6); it is not a code defect.
- DECISIONS 112 and 115: the "bare CR bytes" of the review are in fact 7 places where a letter was lost and a line break stands instead (`\r`/`\n` read as an escape): repaired from the context.
- The run day of bids (stage 2) cannot come from the CGM (fixture CGM dates differ from the NCP dates): see the open question.

## Open yes/no questions
1. Stage 2: is "the earliest day of the bid time points in the SIS file" the right run day for real data (the alternative is a run date in the config)? Used today; changes results only for a file with bids on several days.
2. Stage 3: add per-(unit, contingency) curative Pmin/Pmax rows anyway, as a deliberate deviation from spec R7 (changes results; re-baseline)?
3. Other time-point readers (group limits, participation factors, unit costs, PATL) still match by clock time only: switch them to date and time too?

4. Result-changing performance work (list above): may I try dropping the zero terms from the N-X rows and a persistent solver, and report the differences in objective and activated RAs before anything is adopted?
5. WP9 / OPEN-31: implement the assessed-element switches and links as the owner recommended (apply at matching run time, absent = enabled, log what was applied)? Today they only give counting warnings.
6. The golden matrix has no case with the 8 countertrade RAs of P switched on (`pst+rd+countertrade` on the mock): add it (a new baseline, 6 more runs)?


# Round 2 (run time from the CGM, assessed-element switches, countertrade matrix case, experiments)

## Round 2 summary

**Done.** Step 1 (run time from the CGM, every time-point reader by date and time) and step 3 (countertrade cases in the golden matrix: 5 new cases, 47 runs) are committed and passed the full gate; the Pmin/Pmax decision is recorded in DECISIONS 130. **Stopped and reverted on the branch:** step 2 (assessed-element switches and links): it was implemented and tested completely, but applying the `included` links of sample G moves three existing matrix cases (rule: stop, revert, report); the work is saved on the local branch `wip-ae-switches` (commit `43a6597`, not pushed) for the owner's decision. Step 4 (experiments) was run in a copy outside the repo and deleted; nothing was adopted. Final gate on the last commit: suite 2179 passed, 6 skipped, 1 xfailed (65 files), matrix 47 cases with 0 differences against both baselines, fingerprints identical, byte-equality passed.

**Commits:** step 1 `55f5f3c`, step 3 `423df0b`. Step 2 only on `wip-ae-switches` (`43a6597`).

**Table of changed cases.** Step 1: none (the mock, the CT/HVDC mocks and sample G keep the start hour 1030Z and their old readers; matrix 0 differences). Step 3: no old cell changed; 5 new cases (below). Step 2 (not on the branch): `generic__{ac_iterative,ac_single_pass,dc}__pst+rd__nx1` would change in two files only (`results_completeness_iterations.csv` `total_nx_constraints`, `results_nx_loadings.csv` `slack_patl` blank for 124 rows each); objective and activated RAs unchanged.

| Case (new, step 3) | Objective | Activated (preventive RD / PST / curative RD / countertrade / curative countertrade) |
|---|---|---|
| mock ac_iterative pst+rd+countertrade nx1 (not in the matrix, not reproducible) | 101206.3155 | 2 / 3 / 3 / 5 / 3 |
| the five in the matrix | see `mock_data/golden/baseline.zip` (`results_summary.csv` of each case) | |

**Timings.** Step 1 and 3: no change of the run time (the mock is not on the CGM date; the start hour is kept). Step 4 below.

**Step 4: experiments that change the model (throw-away copy, default config, N-X on, ac_iterative; time, peak memory, result against the committed state in the same copy):**

| Experiment | pst+rd | pst+rd+countertrade | Objective, activated RAs, golden rule | Fingerprints | Assessment |
|---|---|---|---|---|---|
| committed state (reference) | 6.9 s, 357 MB | 11.1 s, 393 MB | - | identical | - |
| (a) drop the zero-sensitivity terms from the N-X rows | 6.7 s, 357 MB | 11.1 s, 392 MB | objective 1030987.0169 / 101206.3155 (relative difference 0 and 7.6e-15), same activated RAs, 0 golden differences | identical (the default config keeps every sensitivity, so the mock has no zero term) | no effect at the default config; identical optimum |
| (a) with N-X pruning 0.02 % (many entries missing) | 7.1 s / 7.2 s | 9.2 s (-16 %) / 10.9 s | objective differs by 1.2e-13 and 2.2e-10 (relative), same activated RAs, golden rule 2 and 40 cells outside the tolerance | not computed | same optimum, different tie-break at the 1e-10 level |
| (b) one solver object + warm start from the previous solution | 6.8 s, 362 MB | 11.0 s, 397 MB | objective relative difference 0 and 7.8e-15, same RAs, 0 golden differences | identical | identical optimum, no gain on the mock (small models) |
| (c) `quicksum` for the N-X rows | 7.0 s, 361 MB | 11.1 s, 393 MB | relative difference 0 and 7.6e-15, same RAs, 0 golden differences | identical | identical optimum, no gain |

Reading: none of the three gives a measurable gain on the mock at the default configuration; (a) matters only when sensitivities are pruned (configuration `sensitivity_threshold_pct_*_nx` above 0) and then gives about 16 % on the countertrade mock with the optimum unchanged but the last digits different. A persistent in-place model update (not tried: it needs a rewrite of the iteration loop) is the only variant that could still change the picture at pan-European scale.

**Open yes/no questions (6):**
1. Merge the assessed-element switches from `wip-ae-switches` although the `included` links of sample G change the N-X constraint count of the three generic nx1 cases (same optimum; those three cases are re-baselined)?
2. Treat `isCombinableWithContingency=false` as "not monitored after any contingency" and `isCombinableWithRemedialAction=false` as "no remedial action is applied for this element" (today: warning only, ASSUMPTIONS OPEN-31)?
3. Accept a larger tolerance for the `last_solve_*` diagnostic columns so that `mock__ac_iterative__pst+rd+countertrade__nx1` can join the matrix (DECISIONS 140)?
4. A CGM without a scenario time, or one outside every NCP series, keeps the start hour 1030Z with a warning: should such a run stop with an error instead (real data)?
5. Drop the zero-sensitivity terms when the N-X pruning thresholds are above 0 (about 16 % on the countertrade mock, same optimum, last digits differ)?
6. Should the run take the start hour from the CGM scenario time also when the NCP series only touch it with a single point (today: inside the span of any series, inclusive)?

## Round 2 progress

| Step | State | Gate | Commit |
|---|---|---|---|
| 0 DECISIONS 130 owner confirmation | done (with step 1) | - | 55f5f3c |
| 1 run time from the CGM | done | suite 2179 passed, 6 skipped, 1 xfailed (65 files); matrix 0 differences vs both baselines; fingerprints identical; byte-equality passes | 55f5f3c |
| 2 assessed-element switches | **stopped, reverted, not committed on the branch** (see the note below) | gate r2s2: suite 2204 passed; matrix: three existing cases moved (generic pst+rd nx1 in the three modes: fewer N-X constraints, same optimum) | work saved on the local side branch `wip-ae-switches` (43a6597) |
| 3 matrix cases with countertrade | done: 5 of 6 cases (DECISIONS 140) | suite 2179 passed, 6 skipped, 1 xfailed (65 files); matrix 47 cases 0 differences vs both baselines (the 42 old cells unchanged, the 5 new ones reproduced by a third run); fingerprints identical; byte-equality passes | 423df0b |
| 4 performance experiments (not committed) | done in a throw-away copy (deleted); nothing adopted | - | - |

## Round 2 notes
- Step 1: the CGM scenario time (`network.case_date`) is 2022-06-16T23:30Z in every model file of the fixture CGM (the Portheim files of 2024-12-23 are not used by pypowsybl). A test of the date alone was too weak (sample G has one point on 2022-06-16 and moved), then a test "inside the span of some time-point series" keeps the mock, the CT/HVDC mocks and sample G unchanged. Readers that match time points: bids, PATL (SHS), participation factors, unit costs, group limits; counted-only (not read): AssessedElementTimePoint, GenericAvailableSchedule, GridStateAlterationTimePoint (step 2 reads the first).
- Fallback for readers other than bids is clock time only as before (a warning counts series on several days); the earliest-day rule of round 1 stays for bids only, because the CT mock has a stray SHS point on 2022-06-15 and the earliest-day rule would have changed its PATL.
- Step 2 (assessed-element switches): implemented in full and tested (24 new tests; model rows absent or restricted, objective differs, pipeline variants), but the gate found that EXISTING data moves, which the task says must stop the step: sample G (generic cases) carries `AssessedElementWithContingency` links of kind `included` on 8 assessed elements that exist in the mock CGM (Espheim 5, Svedala 3). Applying them removes the N-X pairs of those elements for the contingencies they are not linked to, so the three cases `generic__{ac_iterative,ac_single_pass,dc}__pst+rd__nx1` change in `results_completeness_iterations.csv` (`total_nx_constraints`) and in `results_nx_loadings.csv` (`slack_patl` blank for the pairs that no longer have a constraint; 124 rows each); the objective, the activated RAs and every RA result are unchanged (the summary file shows no difference beyond 1e-6). No other case moved; the mock and the other samples carry only enabled / in-base-case switches set to true. Per the rule the working tree was restored to the last commit and nothing was committed on `ncp-standard-alignment`; the complete work (code, 24 tests, docs, DECISIONS 139, the variants builder) is on the local branch `wip-ae-switches` (commit 43a6597, one commit on top of `55f5f3c`, never pushed) so that it can be merged after the owner's decision. Question for the owner (yes/no): apply the included/excluded links although this changes the N-X constraint count of sample G (generic nx1; same optimum) and requires a re-baseline of those three cases? The other switches in that commit (normalEnabled, time-dependent enabled, inBaseCase) move nothing.
- Step 3: `mock__ac_iterative__pst+rd+countertrade__nx1` is not reproducible within rule 2 (see DECISIONS 140), so the matrix has 47 runs: the new cases are `mock__{ac_iterative,ac_single_pass,dc}__pst+rd+countertrade__nx0`, `mock__{ac_single_pass,dc}__pst+rd+countertrade__nx1`.


# Round 3 (merge of the AE switches, tolerance, pruning, sixth CT case, docs)

## Round 3 summary

**Done: all six steps.** Step 1 (assessed-element switches and links merged from `wip-ae-switches`, which stays) `56a458f`; step 2 (isCombinableWith* warn-only, clearer warning) `e0a7504`; step 3 (`last_solve_*` tolerance and the sixth countertrade case, matrix 48 runs) `9fbf820`; step 4 (fallback stays a warning, OPEN-32) `666fc5b`; step 5 (zero terms dropped when N-X pruning is on) and step 6 (single-point rule pinned) `8e3ae1a` and the last code commit. **Reverted:** nothing. **Final gate** (after step 5, the last code change): suite 2215 passed, 6 skipped, 0 xfailed (67 files); matrix 48 cases, 0 differences against both baselines; fingerprints identical; byte-equality passed. Steps 2, 4 and 6 change no behaviour (text, docs, tests); their gates are covered by the gates of steps 1, 3 and 5 on the same code.

**Changed cases (step 1, re-baselined on purpose; nothing else moved):** `generic__{ac_iterative,ac_single_pass,dc}__pst+rd__nx1`.

| Column group | Old | New |
|---|---|---|
| `results_completeness_iterations.csv` `total_nx_constraints` | 261 in every iteration | 137 in every iteration |
| `results_nx_loadings.csv` `slack_patl` | filled in 261 of 261 rows | blank in 124 rows (no constraint left), no other cell differs |
| `results_summary.csv` (objective, all sums, activated RAs) | 1936325.6933 (ac_iterative, ac_single_pass), 1626875.6832 (dc) | identical |

**Timing (step 5, threshold 0.02 % for both N-X kinds, mock, ac_iterative, N-X on, best of 3):**

| Case | Before | After |
|---|---|---|
| pst+rd | 7.3 s, 364 MB | 7.0 s, 358 MB |
| pst+rd+countertrade | 10.9 s, 394 MB | 9.2 s, 377 MB (-16 %) |

With the default thresholds (0) nothing changes (fingerprints and all 48 cells identical). The sixth countertrade case passed in 12 of 12 runs under the new `last_solve_*` tolerance (one of the last six differed in bytes, inside the rule).

**Open yes/no questions (4):**
1. After the real-data run: make a CGM without scenario time (or outside every NCP series) stop with an error instead of the 1030Z fallback (ASSUMPTIONS OPEN-32)?
2. Is `isCombinableWithContingency=false` meant to mean "not monitored after any contingency", and `isCombinableWithRemedialAction=false` "no remedial action applied for this element" (OPEN-31; the standard or the data provider has to say)?
3. Should the N-X pruning thresholds (0.02 % in the measurement) become part of the golden matrix as extra cases, so that the dropping of zero terms is guarded by the gate?
4. Delete the side branch `wip-ae-switches` now that its work is merged?

## Round 3 progress

| Step | State | Gate | Commit |
|---|---|---|---|
| 1 merge the assessed-element switches | done | suite 2204 passed, 6 skipped (66 files); matrix: exactly the three expected cases moved and were re-baselined, the other 44 unchanged; fingerprints identical; byte-equality passes | 56a458f |
| 2 isCombinableWith* stays warn-only | done (warning text and OPEN-31 only) | suite 2204 passed, 6 skipped (66 files); matrix 47 cases 0 differences vs both baselines; fingerprints identical; byte-equality passes | e0a7504 |
| 3 tolerance for last_solve_* and the sixth CT case | done | suite 2206 passed, 6 skipped (66 files); matrix 48 cases 0 differences vs both baselines (the old 47 cells included); the sixth case passed in 12 of 12 runs; fingerprints identical; byte-equality passes | 9fbf820 |
| 4 fallback stays a warning (open item) | done (open item only; docs only, no gate rerun: the code is that of step 3) | - | 666fc5b |
| 5 drop zero terms when pruning is on | done (DECISIONS 142) | suite 2215 passed, 6 skipped (67 files); matrix 48 cases 0 differences vs both baselines; fingerprints identical; byte-equality passes | 27a9bf6 |
| 6 pin the single-point rule | done (tests and one sentence; test-only, covered by the final gate) | 21 tests of test_rao_run_time.py pass | 8e3ae1a |

## Round 3 notes
- Step 1: the work of `wip-ae-switches` (43a6597) was applied as one commit (no conflicts with the round-2 code: the touched src and test files had not changed since; the docs were re-applied by hand, the DECISIONS entry is now 141 because 139/140 were taken). The side branch stays. Changed cases (old -> new), per column group: `results_completeness_iterations.csv` `total_nx_constraints` 261 -> 137 in every iteration (ac_iterative 2 rows, ac_single_pass 1, dc 1); `results_nx_loadings.csv` `slack_patl` blank 0 -> 124 of 261 rows (no other cell of that file differs); `results_summary.csv` identical (objective 1936325.6933 for ac_iterative and ac_single_pass, 1626875.6832 for dc); activated RAs identical. Only timing columns and last-digit noise differ elsewhere (iteration history, sensitivity_rd_nx). The other 44 cases: 0 differences. `baseline.zip` holds the new files of those three cases.






# Round 4 (pruning cases in the matrix, side branch)

## Round 4 summary

**Done: both steps; nothing reverted.** Step 1: four golden-matrix cases with both N-X pruning thresholds at 0.02 %, all on the mock with N-X on: `mockpruned__ac_iterative__pst+rd__nx1`, `mockpruned__dc__pst+rd__nx1`, `mockpruned__ac_iterative__pst+rd+countertrade__nx1`, `mockpruned__dc__pst+rd+countertrade__nx1` (new input `mockpruned` in `run_case.py`, which sets the two thresholds). They passed in 7 of 7 runs, so none was left out. **The matrix now has 52 runs** (48 + 4); the 48 old cells show 0 differences against both baselines; the four cases really prune (objectives 1030978.53 and 102125.04 against 1030987.02 and 101206.32 without pruning). `baseline.zip` is 6.47 MB; the gate script, `mock_data/README.md`, `.github/copilot-instructions.md` and DECISIONS 142 say 52 / name the cases. Step 2: the local branch `wip-ae-switches` (43a6597) was deleted after checking its content: of the 14 files it changed, 6 are byte-identical on `ncp-standard-alignment` (`ae_switch_variants.py`, `data_model.py`, `post_ra_congestion_check.py`, `ae_switches.py`, and two test files); 4 docs files differ because the DECISIONS entry was renumbered (139 -> 141) and later rounds edited them; 4 source/test files differ only by the later deliberate changes (round 3: the clearer isCombinable warning text in `ncp_parser.py`, its test assertion, and the `drop_zero_*` flags in `milp_builder.py` and `run_pipeline.py`; 8, 7, 2 and 4 changed lines, all of that kind). Only that ref was deleted; the other refs are unchanged (`main`, `ncp-standard-alignment`). **Final gate:** suite 2215 passed, 6 skipped (67 files); matrix 52 cases, 0 differences against both baselines; fingerprints identical; byte-equality passed.

**Open yes/no questions (2):**
1. Should the pruned cases also cover `ac_single_pass` and the nx0 variants (not needed for the dropped terms, which only exist with N-X on)?
2. Should the golden-matrix timing (about 25 minutes per gate) be reduced by running the old `nx0` cases of the CT/HVDC mocks less often?


# Round 5 (assessed-element combination switches per the AssessedElement Profile Specification v2.4.1)

## Round 5 summary

**Step 1 done (code check), step 2 done, step 3 not implemented on purpose (warn-only, ASSUMPTIONS OPEN-33), step 4 done. Nothing reverted.** Source: AssessedElement Profile Specification v2.4.1, 2026-09-10, tables 9, 11, 13 and the constraint on `considered`. Code commit `e59e451` (steps 1c and 2), docs commit after it. **Final gate** (tree of the docs commit, code identical to `e59e451`): suite 2220 passed, 6 skipped, 0 failed (67 files); matrix 52 cases, 0 differences against both baselines; fingerprints identical; byte-equality passed.

| Step | Result |
|---|---|
| 1 code check | 6 of 7 points OK, 1 differed and was fixed in step 2's commit (table below) |
| 2 `isCombinableWithContingency=false` | applied; 5 new tests, 3 adapted; gate passed (suite 2220 passed, 6 skipped, 67 files; matrix 52 cases 0 differences vs both baselines; fingerprints identical; byte-equality passes) |
| 3 AE-RA links and `isCombinableWithRemedialAction=false` | **not implemented**: not containable (reasons and estimate below); stays a counting warning that now names OPEN-33 |
| 4 data effect and docs | no existing case moved; docs updated |

**Step 1: code check against the spec**

| Point | Result |
|---|---|
| a. `normalEnabled` on the element | OK (`ncp_parser.py` `parse_assessed_elements`, element becomes EXCLUDED) |
| a. `normalEnabled` on `AssessedElementWithContingency` | OK (`ae_switches.py` `read_element_contingency_links`: a disabled link is ignored and counted) |
| a. `normalEnabled` on `AssessedElementWithRemedialAction` | differs, not read: the links are not applied at all (step 3 / OPEN-33); counted in the warning |
| a. `inBaseCase` (false = no N-0 row, N-X stays) | OK (`data_model.branch_monitoring_rules`, `milp_builder` N-0 selection) |
| a. time-dependent `enabled` overrides `normalEnabled` at the run time | OK (`ncp_parser.py` schedule value replaces `enabled`) |
| b. links: included = only those, excluded = not that one, absent = all | OK (`data_model.monitored_after_contingency`, used by the PATL, TATL and scanned pair builders and the post-RA check) |
| c. `considered` on an AE-contingency link | **differed**: it was read as `included` (warning "missing, considered or unknown"). Now: own counting warning "considered ... treated as absent"; missing / unknown kinds are still read as `included` with their own warning (`ae_switches.py`). |

Not checked because outside the brief: "a BaseCaseCurrentLimit requires `inBaseCase=true`" is not validated by the parser.

**Step 2.** `isCombinableWithContingency=false` makes `included_contingencies` the tuple of the `included` links (empty tuple = assessed after no contingency; `None` still means all). The existing rules then do the rest, so there is no new code in the MILP: `excluded` and disabled links still apply, the N state follows `inBaseCase` only. Tests: parser (2 new: `considered`; the false switch with included / excluded / considered / disabled links, none, `inBaseCase=false`), MILP rows (the pair is absent, N-0 row stays, the objective no longer pays the overload, element in neither state gives no row), pipeline variants of the mock built with `mock_data/ae_switch_variants.py` (2 new): with the switch and one included link the N-X rows (`slack_patl` non-blank) exist for that contingency only and the same number as without the switch; with no link there is none; a `considered` link changes nothing and warns once; `excluded` beats `included`. No change to the builder was needed.

**Step 3: assessment and decision (not containable).** Read: `milp_builder._add_nx_block`, `_nx_pst_and_rd_effect`, the N-0 rows, `rd_net_injection_rule`, the curative blocks. (1) The rows are per (branch, contingency); several assessed elements of one branch share the row, so a per-element rule needs one row per distinct rule set. (2) The preventive redispatch effect is the unit-level expression `rd_net_injection_g`, shared by all bids and the countertrade bids, and the curative one `curative_rd_net_injection_g` has "no per-bid identity" (comment in the code); a per-remedial-action term must be rebuilt for N-0, the PATL, TATL and scanned N-X rows and for the HVDC and countertrade parts. (3) The post-RA check, the model loadings and the convergence check re-evaluate the same terms and must follow. (4) The effect of the remedial actions on the loadings is then no longer the effect on the network (the action still moves the flow): that is a modelling choice to confirm. Estimate: 4 source files, several hundred lines, about 40 tests, 3 to 5 working days, re-baseline of every case with such a link. Not started; ASSUMPTIONS OPEN-33 and DECISIONS 143. The existing option `activate_cra_xne_linkage` (default false) already limits a curative RA to the elements it is linked to, whatever the kind of the link.

**Step 4: effect on existing data (counts).**

| Switch | Sample G | Mock P |
|---|---|---|
| `isCombinableWithContingency=false` | 1 element (Belgovia, equipment is not a line or 2W transformer of the CGM: never in the model) | 0 (29 elements have `true`) |
| `isCombinableWithRemedialAction=false` | 1 element (same reason) | 0 |
| `AssessedElementWithContingency` links | 14 `included`, 1 `excluded`, 0 `considered` (already applied since round 3) | 0 |
| `AssessedElementWithRemedialAction` links | 2 `included` (not applied, warning) | 0 |

Result: no matrix cell moved (52 cases, 0 differences vs both baselines, 1031 files compared), so there is no old/new table.

**Open yes/no questions (4):**
1. Is leaving one remedial action's effect out of one element's constraint (the standard's exclusive combination) wanted although the action still moves that flow in the network, so that step 3 should be built (3 to 5 days, OPEN-33)?
2. Should a link with a missing or unknown `combinationConstraintKind` (mandatory 1..1 in the standard) be treated as absent, like `considered`, instead of `included`?
3. Should a disabled (`normalEnabled=false`) link keep being ignored as if absent? For an element with `isCombinableWithContingency=false` that means no contingency from that link; for `true` it means the element is monitored after all contingencies (today's behaviour in both cases).
4. Should the parser reject an assessed element with a `BaseCaseCurrentLimit` and `inBaseCase=false` (the standard requires `inBaseCase=true`)?

## Round 5 progress

| Step | State | Gate | Commit |
|---|---|---|---|
| 1 code check | done (one point differed: `considered`) | covered by step 2 | e59e451 |
| 2 `isCombinableWithContingency=false` | done | suite 2220 passed, 6 skipped (67 files); matrix 52 cases 0 differences vs both baselines; fingerprints identical; byte-equality passes | e59e451 |
| 3 AE-RA links, `isCombinableWithRemedialAction` | not implemented, decision recorded (OPEN-33) | - | docs commit |
| 4 data effect and docs | done | final gate: suite 2220 passed, 6 skipped, 0 failed (67 files); matrix 52 cases, 0 differences against both baselines; fingerprints identical; byte-equality passed | docs commit |

## Round 5 notes
- Baselines for "both baselines": the two previous 52-case matrices (`mxA`, `mxB` of the earlier session) passed to `run_gate.py` as `BASELINE_DIR`; the stored `golden/baseline.zip` holds the same cells.
- With `isCombinableWithContingency=false`, "the exclusive combination" is read as the enabled `included` links (agreed with the owner for the `included` kind; the disabled-link case is question 3).


# Round 6 (small assessed-element fixes, then docs reorganisation)

## Round 6 summary

**Part A done, Part B done; nothing reverted.** Final gate (tree of the Part B commit): suite 2223 passed, 6 skipped, 0 failed (67 files); matrix 52 cases, 0 differences against both baselines; fingerprints identical; byte-equality passed.

**Part A** (commit `d1ee429`; one commit and one gate for A1 to A4 together, not one each: the four changes touch the same two parser functions and one test file, so a gate per change would have cost 4 x 25 minutes for the same tree): A1 a link with a missing or unknown `combinationConstraintKind` is treated as absent with a counting warning (like `considered`); A2 a link with `normalEnabled=false` stays ignored as if absent, pinned by a test for `isCombinableWithContingency` true and false, one sentence in DECISIONS 143; A3 `inBaseCase=false` with a `BaseCaseCurrentLimit` is not rejected: counting warning naming the count, the element is scanned in the base case (parser test with generated XML; the pipeline test on the mock variant now expects it, because the mock's Belgovia element has a `BaseCaseCurrentLimit`); A4 the warnings for `isCombinableWithRemedialAction=false` and the remedial-action links name OPEN-33 and say the effect is NOT removed. Gate: suite 2223 passed, 6 skipped, 0 failed (67 files); matrix 52 cases 0 differences vs both baselines; fingerprints identical; byte-equality passes. **No matrix cell moved because of A3** (no element of the mock or sample G has `inBaseCase=false` with a `BaseCaseCurrentLimit`). First gate run: 1 test failed (the pipeline variant above, expected text only) and `mock__ac_iterative__pst+rd+countertrade__nx1` differed by 1.55e-9 (relative) in the curative countertrade / RD volumes, the known vertex noise of that case (DECISIONS 140, `last_solve_*` tolerance does not cover these columns); three isolated reruns gave 0 differences against both baselines, and the full gate rerun after the test fix passed.

**Part B** (docs reorganisation): 8 files moved (4 to `docs/specs/`, 2 to `docs/data/`, 2 to `docs/archive/`), byte-identical by SHA-256; 93 references re-pointed (87 `docs/<name>` path strings in 48 live files, 6 bare names); `docs/specs/README.md` and `mock_data/tools/check_doc_links.py` added; `docs/README.md`, DECISIONS 144 and CHANGELOG written; no test needed a new expected string.

**Dead links left.** In live files: 7, none caused by the move: `docs/Next_Steps.md` names `docs/Real_Data_Results.md` twice (the file is created on the target machine and is not committed); `docs/User_Guide.md` lines 266 and 361 to 364 name `tests/test_incremental_ac_fallback.py`, `tests/fixtures/NCP_pst_fallback_scenario.zip`, `..._legacy.zip`, `tests/fixtures/NCP_generic.zip` and `tests/ct_mock.py`, which do not exist under those names. In `reference/technical/` (not edited): `Design_Overview.md` line 23 and `MILP_Mathematical_Formulation.md` lines 20, 21 and 703 name the old `docs/hvdc_ra_specs.md` and `docs/countertrade_ra_specs.md`. History files (not changed): CHANGELOG 23 lines, DECISIONS 10, archive 58 (old paths quoted as written, and some paths that never existed).

**Open yes/no questions (3):**
1. Fix the 5 stale fixture / test names in `docs/User_Guide.md` (lines 266, 361 to 364) to the current ones?
2. Update the four old paths in `reference/technical/` (needs your permission, `reference/` is not edited by these rounds)?
3. Should `check_doc_links.py` become part of the gate (it needs the 7 live dead links above fixed or whitelisted first)?

## Docs reorg

**Step 1: references found before the move** (lines / files, all file kinds under docs, src, tests, mock_data, .github, reference, root; history files included):

| File | Lines | Files |
|---|---|---|
| calculation_mode_specs.md | 21 | 6 |
| countertrade_ra_specs.md | 45 | 28 |
| dc_mode_specs.md | 23 | 12 |
| hvdc_ra_specs.md | 49 | 28 |
| ncp_data_requirements.md | 30 | 13 |
| ncp_dataset_coverage.md | 25 | 13 |
| review_report.md | 7 | 4 |
| unattended_run_report.md | 0 | 0 |

Kinds: code comments and docstrings in `src/` (16 files, among them both config yaml files' comments), `tests/` docstrings and comments (20 files), `mock_data/` (5 files), docs. Nothing in `.github/`, `.gitignore`, `pytest.ini` or the root README names them; no GUI text; no code opens a doc at run time (`mock_data/tools/inventory_p.py` and `mock_data/cli.py` write into `docs/` by default, files that are not among the moved ones). `reference/technical/` names 4 old paths.

**Steps 2 and 3.** Moved by `Move-Item`, SHA-256 before and after equal for all 8. Re-pointing by a regex on `docs/<name>` in every live file (not CHANGELOG, DECISIONS, archive), then 6 bare names by hand. The two config yaml files were changed in the same way (comments only, still identical to each other in these lines).

**Step 4.** `mock_data/tools/check_doc_links.py`: before re-pointing 94 dead in live files, after 7 (listed above).


# Round 7 (doc link fixes, link check in the gate)

## Round 7 summary

**All three steps done; nothing reverted.** Link check: **0 dead links** in live files (91 quoted in history files, exempt). Final gate (tree of the Round 7 commit): suite 2229 passed, 6 skipped, 0 failed (68 files); matrix 52 cases, 0 differences against both baselines; fingerprints identical; byte-equality passed; `LINKS OK`. Lines changed: step 1 none (see below), step 2 4 lines (5 path strings, 30 bytes added), step 3 the checker (+whitelist, `root` parameter, `reference/technical/` added), `run_gate.py` (+6 lines), 1 new test file (6 tests), 4 doc lines (`mock_data/README.md`, `docs/Next_Steps.md`, `.github/copilot-instructions.md`, DECISIONS 145 / CHANGELOG).

**Step 1: not applied, on purpose.** The 5 "stale" names in `docs/User_Guide.md` are not stale: line 266 is the "earliest trace in the repository history" note (it must say `tests/test_incremental_ac_fallback.py`, the file of that time) and lines 361 to 364 are the "Was" column of the rename table of 24 Oct 2026, whose "Is" column already holds the current names. Replacing them would make the table say "X was X". They are whitelisted in the checker instead (comment in the script). Old -> new, for the record: `tests/fixtures/NCP_pst_fallback_scenario.zip` -> `NCP_mock_standard.zip`; `..._legacy.zip` -> `NCP_mock_legacy.zip`; `tests/fixtures/NCP_generic.zip` -> `NCP_sample_generic_2_4.zip`; `tests/ct_mock.py` -> `mock_data/ct_mock.py`; `tests/test_incremental_ac_fallback.py` has no successor (history).

**Step 2 (one-time exception for `reference/technical/`).** Changed with a script that checks `new` with the inserted directory names removed equals the old bytes, so only path characters changed:

| File:line | Old | New |
|---|---|---|
| Design_Overview.md:23 | `docs/hvdc_ra_specs.md` | `docs/specs/hvdc_ra_specs.md` |
| Design_Overview.md:23 | `docs/countertrade_ra_specs.md` | `docs/specs/countertrade_ra_specs.md` |
| MILP_Mathematical_Formulation.md:20 | `docs/countertrade_ra_specs.md` | `docs/specs/countertrade_ra_specs.md` |
| MILP_Mathematical_Formulation.md:21 | `docs/hvdc_ra_specs.md` | `docs/specs/hvdc_ra_specs.md` |
| MILP_Mathematical_Formulation.md:703 | `docs/countertrade_ra_specs.md` | `docs/specs/countertrade_ra_specs.md` |

`Scalability_Report.md` and `Data_Validation_Reference.md` had no old path. No other file in `reference/` was touched.

**Step 3.** `check_doc_links.py` now also scans `reference/technical/`; rules: a dead relative markdown link or path string in a live file fails (exit 1). History rule: a file is history when it is `docs/CHANGELOG.md`, `docs/DECISIONS.md` or under `docs/archive/`; dead paths there are listed with `history` (hidden by `--live-only`) and never fail. Whitelist: 6 (file, path) pairs listed in the script with the reason. The checker does not scan itself. `run_gate.py` runs it last and writes `LINKS OK` / `LINKS DEAD`, exit code 1 on a dead link. A new test file (`tests/test_rao_doc_links.py`, 6 tests) uses a temp folder: valid link passes, a broken link or path (also in a source comment) fails, history files do not fail, a whitelisted pair passes only in its own file, and the repository itself has 0 dead links. `mock_data/golden/README.md` does not exist (the gate is described in `mock_data/README.md`), so the line went into `mock_data/README.md`, `docs/Next_Steps.md` and `.github/copilot-instructions.md`.

**Open yes/no questions (2):**
1. Create `mock_data/golden/README.md` (the brief names it; today the gate is described in `mock_data/README.md`)?
2. Remove the 91 old paths quoted in the history files by adding a "path moved" note instead of leaving them as written?
