# NCP standard alignment - progress

## 2026-10-23 - STOP at step S1 (before WP1)

Status: stopped. No branch created, nothing committed, no package started. Condition: a statement of the plan
proves wrong when tried (plan section 5, third bullet), and the way forward needs a decision that is not in the plan.

What the plan assumes (section 3b, S1): WP0 is the only uncommitted work, so `WP0: converter and equivalence
harness` can be committed on its own.

What the repository shows (checked with a git library, because no `git` executable is installed on this machine):

- `main` (HEAD `201500373d`, "reporting update") holds an old snapshot of 102 files. Compared with the working tree:
  66 of its files are missing from the tree (for example `config/`, `data/`, `specs/`, `smoke_tests/`, 9 of 9
  old `docs/` files, 44 old `tests/` files), 26 differ, 9 are the same.
- The working tree has about 451 files (without `.venv` and `.git`); most of the project is untracked: all of
  `src/rao/pre_milp/ct_units.py`, `hvdc_units.py`, `dc_*`, `single_pass.py`, ..., 49 `tests/test_rao_*.py` files,
  `tests/helpers.py`, the mock builders, and the current `docs/` (DECISIONS, ASSUMPTIONS, CHANGELOG, Next_Steps, ...).
- So a commit of "WP0" can not contain WP0 only. WP0's own files (`tools/convert_ncp_to_standard.py`,
  `tests/test_rao_ncp_standard_equivalence.py`) are in the same state as the rest, and the doc changes of WP0 sit in
  files that git has never seen, so there is no diff that isolates them either.
- Staging "everything" would put the whole project, and the deletion of 66 tracked files, under the message of WP0.
  That is a decision about the history of the repository, not in the plan.

Decision needed from the owner (one of):

1. Commit the current working tree as a baseline first (message of your choice, on `main` or on the new branch), then
   WP0 is only the delta of the WP0 files. Because the WP0 changes in the shared docs and in `tests/helpers.py` are not
   separable afterwards, say whether WP0 should be committed together with that baseline (one commit) or whether the
   baseline commit is made by you and WP0 is then not a separate commit.
2. Tell me that the branch may start from the full working tree and that the first commit is
   `WP0: converter and equivalence harness` containing everything.
3. Fix the history yourself (for example commit or reset the old snapshot) and tell me when the tree is clean.

Also needed: no `git` executable is installed. I can commit with a pure-Python git library kept outside the repo (in
the scratch directory); say if that is acceptable.

Not started because of the stop: S2 (golden baseline, two runs of the 42-run matrix), S3 (10 runs of the two
countertrade N-X cases), WP1 to WP8. For S2 and S3 the tools exist in the scratch directory from the WP0 gate
(`run_case.py`, `run_matrix.py`, `compare_runs.py`, `compare_agg.py`); the WP0 gate already ran the matrix twice (42
cases, 40 equal under the Next_Steps rule, 2 differ in `loading_pct_nx_post_pra_model_diff_pct`).

## 2026-10-23 - S1 done: baseline commit

- Branch `ncp-standard-alignment` created from `main` (`main` untouched, nothing pushed). Baseline commit `d66d6bf` "Baseline: working tree before NCP alignment (includes WP0)": 168 files added, 29 modified, 67 removed (the old snapshot files that no longer exist in the tree, among them the gitlink `data/relicapgrid`).
- Check: status clean (0 differences between index and working tree); committed files 203 = 201 non-ignored working-tree files + the 2 tracked files of `input/` (`CGM_package.zip`, `NCP_mock_cleaned.zip`, byte-identical to the committed copies, not re-added). Nothing over 50 MB. Skipped (by rule, not touched): `input/` (2 mock zips already tracked). Ignored by `.gitignore`: `output/`, `logs/*.log`, caches, `input/_extracted_*`, `.venv`.
- Commits are made with dulwich (installed outside the repo, scratch directory). Note: the commit was built from the working tree without line-ending conversion (bytes as on disk).

## 2026-10-23 - S2 and S3 done

- S2 golden baseline: two runs of the 42-run matrix on the WP0 code (`src/` unchanged since; hash seed 0) are stored outside the repo (scratch directory `mxA` = baseline 1, `mxB` = baseline 2). Same-code spread under the Next_Steps rule with the S3 addition: 0 differences in 207,980 cells; 672 of 738 files byte-identical. Every package's matrix is compared with `mxA` (and `mxB`).
- S3 noise: the 2 countertrade N-X cases, 10 runs each on unchanged code. `loading_pct_nx_post_pra` and `..._model` agree to 2.8e-12 relative; `loading_pct_nx_post_pra_model_diff_pct` has an absolute spread of at most 5.6e-11 pp (condition: at most 1e-6 and 1e-9: met). Rule added: `*_model_diff_pct` columns tolerate 1e-6 absolute (Next_Steps section 3 rule 2, ASSUMPTIONS 16). Observation: the pure `countertrade` case has two result states between runs (differences of 2.8e-11 pp in that column), also in serial runs; the `countertrade+rd` case varies in the loading columns at 1e-12 relative and in `slack_patl` at 2e-10.

## WP1 - group limits: done (commit "WP1: group limits on the standard SIS chain")

- `parse_ra_groups` reads `RemedialActionGroupTimePoint` -> `RemedialActionGroupSchedule` -> `RemedialActionGroup` with `maxRegulatingUp/Down` declared by the time point; the old direct form is a fallback with one deprecation warning per file (new helper `warn_deprecated_form_once`); both forms for the same group: standard wins, warning. DECISIONS 106, ASSUMPTIONS 14, alignment rows E2/E3 marked done.
- Tests: 4 new in `test_rao_ncp_parser.py` (3 failed before the change, 1 is a guard); harness `test_rao_group_limits_are_equal` flipped from xfail to must-pass (23 passed, 5 xfailed).
- Gate: suite 49 files 1911 passed, 6 skipped, 5 xfailed; the 4 failures of the first run (BOM that my edit wrote into `ncp_parser.py`) fixed, the 4 affected files rerun: pass. Matrix 42 runs vs baseline 1 and 2: 0 differences (rule with `*_model_diff_pct`). Fingerprints on the mock converted with the sections enabled so far (`groups`): identical.
- Deviations: the dependency alias `RemedialActionDependency.RemedialActionGroup` is still accepted silently (not in the plan's WP1 text). Open: none new.

## WP5 - countertrade without `gLSKStrategy`: done (commit "WP5: countertrade without gLSKStrategy")

- `parse_ct_remedial_actions`: no strategy declared -> `proportionalForRemainingCapacity` with a warning per RA; old `gLSKStrategy` (RA or bid) = fallback with one deprecation warning per file; mixed/other value still ignores the RA; `powerShiftKey` / `method` -> warning, not read; margins not read. DECISIONS 107, ASSUMPTIONS (decision 6 bullet), alignment row I2 done.
- Tests: 3 new + 1 changed in `test_rao_ct_parser.py` (the "missing strategy ignores the RA" and the legacy-sample tests flipped on purpose; the 4 failed before the change); `test_rao_ct_pipeline.py::...repo_ncp...` changed on purpose; harness `test_rao_countertrade_ras_and_bids_are_equal` flipped to must-pass (4 xfailed left).
- Gate: suite 49 files: 1917 passed, 6 skipped, 4 xfailed, 1 failed in the first run (the pipeline test above, which pinned that the legacy sample's countertrade RA is unusable) - changed and rerun: pass. Matrix 42 runs vs baseline 1 and 2: 0 differences. Fingerprints on the mock converted with `groups,countertrade`: identical.
- Deviation to know: the legacy sample (G) countertrade RA (`powerShiftKey`, no `gLSKStrategy`) is now USABLE (default strategy), so a run with `countertrade` on G now writes countertrade results. This follows from decisions 6 and 18; no other decision conflicts.
- Doc debt for WP8: `ncp_data_requirements.md` 10.1/10.3 and 10.4, `countertrade_ra_specs.md`, DECISIONS 70 (superseded by 107).

## WP7 - small items: done (commit "WP7: HVDC penalty default and per-RA cap warning")

- HVDC missing `penaltyFactor` -> 1.0 with a warning (`parse_hvdc_units`); new `warn_unsupported_sis_content` (called per TSO in `run_pipeline.main`): one warning per SIS file for `PowerRemedialActionSchedule` / `PowerRemedialActionTimePoint` (per-RA caps, decision 15: warn only). Decisions 12, 13: nothing changed. DECISIONS 108, ASSUMPTIONS (standard-form bullets), alignment rows A4 done, E1 warn-only.
- Tests: `test_rao_hvdc_parser` (changed to 1.0, failed before), 2 new warning tests (parser, in-run), `test_rao_hvdc_pipeline` and `test_rao_ncp_dataset_variants` changed on purpose (they pinned 0.0). Harness: section "other" has nothing to flip (its only xfail, the disabled assessed element, is WP9 and stays).
- Gate: suite 49 files: 1918 passed, 2 failed in the first run (the two tests above that pinned the old default) - changed, rerun with their files: 79 + passed. Matrix 42 vs baseline 1 and 2: 0 differences. Fingerprints on the mock converted with `groups,countertrade,other`: identical. (No HVDC mock case omits the factor, so no matrix result changes.)
- Doc debt for WP8: `ncp_data_requirements.md` 6.1 / 9.1 (HVDC default), `ncp_dataset_coverage.md` C38, `hvdc_ra_specs.md`, DECISIONS 62.

## WP2 - bids: done (commit "WP2: bids in the standard form")

- `parse_power_bids`: direction = last word of the literal (up/down); no direction or upAndDown/stable -> skipped with a warning (never inferred from p); sign of p = cross-check warning, |p| used; `interpolationKind` applied (none/previous/next/linear, missing = none with one warning, unknown = none with a warning); warnings for `isFixed` (true), `totalMinimumEnergy`, `totalMaximumEnergy`, `minimumActivationP`, `stepIncrementP`; `PowerBidDependency` warning in `warn_unsupported_sis_content`; the 4 non-standard attributes still read with a deprecation warning. DECISIONS 109, ASSUMPTIONS (line 8 and the standard-form bullets), alignment rows D3/D4/D7/D13/D14/D19/D20/D21.
- Tests: 14 new in `test_rao_ncp_parser.py` (13 failed before the change); harness: "bid without direction is skipped" flipped to must-pass, the "read as up today" test replaced by a converter test; `test_rao_ncp_dataset_variants` changed on purpose (bid without direction was an up bid). Remaining harness xfails: redispatch (WP3), glsk (WP4), disabled assessed element (WP9).
- Gate: suite 49 files 1945 passed, 6 skipped, 3 xfailed; the one failure of the first run (the dataset-variant test above) changed and rerun: pass. Matrix 42 vs baseline 1 and 2: 0 differences. Fingerprints on the mock converted with `groups,countertrade,other,bids`: identical, and also identical with the four non-standard bid attributes dropped (so WP8 may drop them).
- Assumption taken that the plan does not state (for the owner): a bid with direction `upAndDown` or `stable` is skipped with a warning like a bid with no direction (ASSUMPTIONS, DECISIONS 109); `isFixed = false` is not warned about.
- Consequence to know: every mock down bid has p > 0, so each run now logs one sign warning per down bid (the values used are unchanged; decision 9: the mock signs are not touched).
- Doc debt for WP8: `ncp_data_requirements.md` section 8.2 / 8.7, `ncp_dataset_coverage.md`, User_Guide, Spec_Coverage.

## WP6 - contingency combination kind: done (commit "WP6: combinationConstraintKind and unsupported SIS content")

- `read_contingency_links` (one reader for the PST, RD, HVDC and countertrade parsers): included keeps the link, excluded -> new field `excluded_contingency_mrids` (`PST`, `RDUnit`, `HvdcUnit`, `CtRa`), considered / missing / unknown -> read as included with a warning once per file. Consumers subtract the excluded ones: `effective_linked_contingencies` (curative RD pairs in `milp_builder`), the HVDC contingency rows, PST availability and PST groups in `cra_preprocessing`. `warn_unsupported_sis_content` also warns about `GenericAvailableSchedule` and `AssessedElementTimePoint` with `enabled=false` (not read). DECISIONS 110, ASSUMPTIONS, alignment A12/A13/K1/K5.
- Tests: new `test_rao_ncp_combination_kind.py` (19, failed on import before), 1 new RD builder test (3 cases), 1 new HVDC builder test. The WP9 xfail (disabled assessed element) stays, as the plan says; it is an open owner decision.
- Gate: suite 50 files 1969 passed, 6 skipped, 3 xfailed, 0 failed. Matrix 42 vs baseline 1 and 2: 0 differences. Fingerprints (`groups,countertrade,other,bids`): identical. (P has 74 links, all `included`.)
- Assumptions taken that the plan does not state (for the owner): `considered`, missing and unknown kinds are read as `included` (plan: "considered warns"); a curative PST with excluded links only has no CRA; a link `normalEnabled=false` is not read.
- Doc debt for WP8: `ncp_data_requirements.md` section 6 (contingency links), `ncp_dataset_coverage.md`.

## WP4 - GLSK and unit mapping: implemented, STOP at the gate (commit "WP4: shift keys in the standard form (matrix difference open)")

Status: **stopped, WP3 and WP8 not started.** Stop condition: a golden-matrix difference that is not covered by a documented noise rule (plan section 5, bullet 1).

- Implemented: `resolve_glsk` maps CIM GeneratingUnit ids to generators (`generators_by_unit`, built in `run_pipeline` from `CGMES.GeneratingUnit`); old form (generator id) = deprecation warning once per file; unit with several generators = dropped with a warning; both unit routes (bid route wins when it reaches an existing key, strategy route via `ra_path` as the fallback, per RA); non-generator resources dropped with a counting warning per RA; participation factors normalised, warning when the raw sum is not 1; optional `atTime`; `interpolationKind` of the key schedule applied (missing = none, one warning per call). DECISIONS 111, ASSUMPTIONS, alignment rows C8/F1-F4.
- Tests: new `test_rao_glsk_standard.py` (16, all failed before), harness `test_rao_glsk_is_equal` flipped to must-pass plus a pipeline test (glsk section only: same `glsk_resolved.csv`). Remaining harness xfails: redispatch (WP3), disabled assessed element (WP9).
- Gate: suite 51 files 1987 passed, 6 skipped, 2 xfailed, 0 failed. Fingerprints (`groups,countertrade,other,bids,glsk`): identical. Matrix 42 vs baseline 1 and 2: 41 cases equal; **1 case differs**: `mock__ac_single_pass__rd__nx1`, `results_curative_rd.csv`, column `curative_volume_mw`, 3 cells: baseline (both baseline runs and every gate of WP1 to WP6) has solver dust of 5.7e-14, 1.06e-13 and -5.7e-14 MW in 3 of 60 rows, the WP4 matrix run has exactly 0.0 there. Under the Next_Steps rule this counts as a difference because the largest value of the column is itself 1.06e-13 (scaled tolerance 1e-22).
- Why I think it is not caused by WP4 (evidence, not a rule): the same case on the WP4 code run 3 times in sequence gives the baseline values (dust) each time; run 12 times with 6 in parallel it gives dust 11 times and all zeros once (same code, hash seed 0). So the all-zero outcome is a rare variation of the same code under load. Its size is below 2e-13 MW.
- Not done, because it is a change of the comparison rule and not in the plan: an absolute floor for values at numerical-dust level (for example: two values with |a|, |b| <= 1e-9 are equal). Decision needed from the owner: (1) add that floor to `Next_Steps.md` section 3 rule 2 and ASSUMPTIONS 16 and treat the WP4 gate as passed; or (2) another rule; or (3) require a rerun of the matrix. After the decision, WP3 and WP8 follow; the WP3 design is ready (units from the key chain via a shared helper in `glsk_resolver`, `generators_by_unit` passed to `parse_rd_units`).
- Assumptions taken that the plan does not state (for the owner): unit with several generators is dropped (not split); the unit routes are chosen per RA (GLSK is per RA); a factor without `atTime` applies at every timestamp; factors are read as sharing weights.
- Doc debt for WP8: `ncp_data_requirements.md` section 8.3, `ncp_dataset_coverage.md`, `glsk_resolver` docs.

## WP4 gate - decision of the owner (23 Oct 2026)

Owner decisions 22 to 24 recorded as DECISIONS 112 to 114 and in plan section 2. Decision 22 (dust floor) added to Next_Steps section 3 rule 2 and ASSUMPTIONS 16. Matrix of WP4 re-compared with baseline 1 and 2 under the new rule: 42 cases, 0 differences. **The WP4 gate counts as passed** (the matrix case named above is no longer a difference). Next: WP3 in three stages, then WP8.

## WP3 - redispatch as RedispatchRemedialAction: implemented, STOP at the gate (commit "WP3: redispatch as RedispatchRemedialAction (matrix difference on sample G open)")

Status: **stopped, WP8 not started.** Stop condition: a golden-matrix difference that is not covered by a documented noise rule (plan section 5, bullet 1).

- Implemented: (a) standard reader (units from the shift key chain, both routes, mapped to generators; `generators_by_unit` passed from `run_pipeline`; the helpers `read_key_routes` / `_generator_of_unit` moved to `ncp_parser`, `resolve_glsk` uses them); (b) bids on the RA (no code change: `parse_power_bids` already takes the RA mRIDs; tests added); (c) the old `RotatingMachineAction` form stays, one deprecation warning per file. The warning "not used and is IGNORED" now names the reason. DECISIONS 115, ASSUMPTIONS, alignment rows C1-C4.
- Tests: new `test_rao_redispatch_standard.py` (18, all failed before; the ones of stage (c) failed until stage (c)); harness `test_rao_redispatch_units_and_bids_are_equal` flipped to must-pass, plus a pipeline test (same RD result files on the mock converted with `redispatch,glsk,bids`). Remaining harness xfail: disabled assessed element (WP9).
- Gates: stage (a)+(b) full gate (suite 2006 passed, 1 failed = the stage (c) test, 6 skipped, 1 xfailed; matrix; fingerprints `groups,countertrade,other,bids,glsk,redispatch` **identical**). After stage (c) the full suite alone: 52 files, 2007 passed, 0 failed, 6 skipped, 1 xfailed; the matrix and the fingerprint check were not repeated for stage (c) (it only adds a warning; the matrix run of stage (a) stands), because the gate had already stopped.
- **Matrix difference (the reason for the stop):** 33 of 42 cases equal to both baselines; the 6 sample-G cases with `rd` in `ra_types` (`generic__{ac_iterative,ac_single_pass,dc}__pst+rd__nx0/nx1`) differ in 9 files: `glsk_resolved.csv` (one new row) and `rd_cra_availability.csv` (12 new rows, nx1 only). Every difference is an ADDED row of the second Belgovia RD RA of sample G (a `RedispatchRemedialAction` whose shift key resolves nothing at 1030Z). No existing row and no number of any other file changes (checked row by row against baseline 1). Cause: the plan asks to recognise the standard class (finding C1), and sample G contains one that was dropped before. Not covered by the comparison rule (shape differs).
- Decision needed from the owner: (1) accept the added rows of sample G as the intended effect of WP3 and re-baseline those 9 files (then the gate counts as passed); or (2) limit the reader so that sample G stays unchanged (the plan does not say how; it would need a rule); or (3) another way. After the decision WP8 follows.
- Assumptions taken that the plan does not state (for the owner): the units of an RA are all generating units of its keys at any time point; unit with several generators dropped (as WP4); the standard reader sets no ramp rates; an RA with no generating unit in its keys is ignored with the existing warning.
- Doc debt for WP8: `ncp_data_requirements.md` (redispatch section), `countertrade_ra_specs`/`redispatch` specs, `ncp_dataset_coverage.md` (C1-C4, G row).

## WP3 gate - decision of the owner (23 Oct 2026)

Owner decision 25 recorded (DECISIONS 116, ASSUMPTIONS, CHANGELOG, plan section 2). The 9 files of the 6 G cases were re-baselined (baseline 1 and 2; the added rows were checked against both baselines: only added rows, no existing row changed). Model check on `generic__ac_iterative__pst+rd__nx1` (hash seed 0): the N-0 model has the same fingerprint with coefficients and 546 variables and constraints with and without the RA's unit; no variable or constraint name contains the RA id. So no model variable or constraint is created for that RA. Full gate of stage (c) below.

## WP3 - gate PASSED (commit "WP3: gate passed (G re-baselined)")

- Full gate of stage (c) with the G re-baseline (9 files): suite 52 files, 2007 passed, 0 failed, 6 skipped, 1 xfailed (WP9). Matrix 42 vs baseline 1 and 2: 0 differences, 0 problems. Fingerprints on the mock converted with all sections (`groups,countertrade,other,bids,glsk,redispatch`): identical.
- With the baselines re-baselined only in the 9 named files, the earlier comparison of the added rows (only added rows, no existing row or number changed) stands.

## WP8 - fixtures and documents: done (commit "WP8: standard-form fixtures and documents")

- `NCP_pst_fallback_scenario.zip` regenerated by the converter with every section, the four non-standard bid attributes dropped and the bid signs corrected (owner decisions 24 and the WP2 result); the legacy copy is `NCP_pst_fallback_scenario_legacy.zip`; G unchanged. The converter got the option `correct_bid_signs` (default on, `--keep-bid-signs`). The harness converts the legacy copy; new tests: signs (4), the shipped P equals the converter output byte for byte, the shipped P is standard form and gives no deprecation or sign warning. `helpers.mock_generators_by_unit()` added; four tests that read P in the old form were adapted (`test_rao_ct_mock.py` 2, `test_rao_hvdc_pipeline.py` 1, `ncp_dataset.add_reaction_time_to_curative_ras` for the new class).
- Fingerprints with the signs corrected and the attributes dropped: identical (checked on the converted mock before the regeneration, and on the shipped P in the final gate). The sign warning no longer appears on the regenerated mock.
- Doc debt cleared: `ncp_data_requirements.md` (sections 1, 6, 8.1 to 8.7, 9, 10, U8.1), `ncp_dataset_coverage.md` (C38, new section 7), `countertrade_ra_specs.md`, `hvdc_ra_specs.md`, `User_Guide.md`, `Spec_Coverage.md`, DECISIONS 62 and 70 marked superseded, DECISIONS 117, ASSUMPTIONS, CHANGELOG, alignment doc (new section 10 with the status of every package and what is left).
- Final gate: suite 52 files, 2013 passed, 0 failed, 6 skipped, 1 xfailed (WP9). Matrix 42 vs baseline 1 and 2 (G cases re-baselined in the 9 files of decision 25): 0 differences, 0 problems, so the regenerated P gives the same results as the old P in every P-based case. Fingerprints on the shipped P: identical.

## Final report (plan section 7)

| Package | Status | Commit |
|---|---|---|
| S1 baseline commit | done (203 files; main untouched) | d66d6bf |
| S2 baseline, S3 noise rule | done | a1e56a5 (plan note d7e852d) |
| WP1 group limits | done | fb9aba0 |
| WP5 countertrade | done | a8e5d82 |
| WP7 small items | done | f8000a5 |
| WP2 bids | done | e040921 |
| WP6 combination kind | done | 72be02b |
| WP4 shift keys | done; gate passed with the dust floor (decision 22) | 1371f33, ac63172 |
| WP3 redispatch | done; gate passed with the G re-baseline (decision 25) | fd8e0d3, 6f0e6a6 |
| WP8 fixtures and documents | done | the commit "WP8: standard-form fixtures and documents" (see git log) |
| WP9 disabled assessed element | **not executed** (owner decision needed, OPEN-29); the strict xfail stays | - |

Nothing was pushed; `main` is untouched; HEAD is on `ncp-standard-alignment`.

**Assumptions taken that the plan did not state** (all in ASSUMPTIONS and DECISIONS 106 to 117):
- Bids: `upAndDown`, `stable` and unknown directions are skipped like a missing one (confirmed, decision 23); `isFixed = false` is not warned about.
- Contingency links: `considered`, a missing and an unknown kind are read as `included` with a warning (OPEN-3); a curative PST with only excluded links has no curative availability; a link with `normalEnabled=false` is not read.
- Shift keys: a unit with several generators is dropped (not split); the unit route is chosen per RA (bid route wins for the whole RA when it reaches an existing key); a factor without `atTime` is valid at every timestamp; factors are sharing weights (OPEN-20).
- Countertrade: a CT RA without any strategy uses `proportionalForRemainingCapacity` (our own assumption); sample G's countertrade RA is therefore usable.
- Redispatch: the units of a `RedispatchRemedialAction` are all generating units of its keys at any time point; ramp rates stay unset; an RA without a generating unit is ignored with a warning; sample G's second redispatch RA is recognised without units (decision 25).
- Comparison rules: `*_model_diff_pct` 1e-6 absolute; numeric dust floor 1e-9 absolute (decision 22).
- Mock: bid signs corrected in the converter and the regenerated P (decision 24).

**Warnings added** (each has a test): deprecation (once per file) for the old group-limit form, `gLSKStrategy`, generator ids in shift keys, `RotatingMachineAction`, the old bid attributes (`penaltyFactor`, `minEnergyBid`, `maxEnergyBid`, `stepSizeCTRD`), the dependency predicate alias, and `considered` / missing / unknown link kinds; countertrade strategy assumed; `powerShiftKey` / `method` not read; HVDC penalty defaulted to 1.0; missing `interpolationKind` on bids and shift keys; bids with no direction, with an unsupported direction, with a sign that disagrees with the direction, with unread attributes (`isFixed`, energy totals, activation minimum, step increment); non-generator resources dropped (counted per RA); factor sum not 1; a unit with several generators dropped; SIS content not read (per-RA caps, bid dependencies, availability schedules, disabled assessed elements); redispatch RA without a generating unit ("not used and is IGNORED", reworded).

**Owner decisions still open:**
1. WP9: a disabled `AssessedElementTimePoint` is not yet switched off (OPEN-29); the xfail stays.
2. The mock builders `ct_mock.py`, `hvdc_mock.py` and `ncp_dataset.py` still write old forms on top of P (the plan regenerates P only); regenerate them before the old forms are removed (decision 3, next release).
3. The remaining OPEN items of the alignment doc section 3 (for example OPEN-4, OPEN-5, OPEN-14, OPEN-27); none blocks the run.
4. The real data was not used; the sign of `p` (OPEN-30) and the unit of ActivePower (OPEN-12) are still to be confirmed with the data provider.

**Gate results:** WP1 to WP6 and WP8 gates passed (suite, 42-run matrix vs both baselines, fingerprints); WP4 passed after decision 22; WP3 passed after decision 25. Final: suite 2013 passed, 0 failed, 6 skipped, 1 xfailed; matrix 0 differences; fingerprints identical.
## Shared-bid redispatch use cases A, B, C (24 Oct 2026): step 0 findings and results

Task: one redispatch RA whose key has 2 or 3 generating units with participation factors. Step 0 was read-only on `src/`: the characterisation tests are in `tests/test_rao_rd_shared_bid.py` (parser and `resolve_glsk`, the MILP on small models with the real generators and limits, and full runs of the variants). The variants are built on the standard-form P by `ncp_dataset.build_shared_bid_ncp` (not in `VARIANTS`, not matrix cases). **No defect found**; nothing in `src/` was changed.

**Split.** `parse_rd_units` gives one `RDUnit` per (RA, unit) and one bid per RA. `resolve_glsk` gives each RA of the pair the factors of the variant, normalised to sum 1 (raw weights 3 and 2 give 0.6 / 0.4 and a warning that the sum is not 1); the bid route and the strategy route resolve to the same shares (A and A_strategy are identical in `glsk_resolved.csv` and in the results). The MILP does not normalise (it only requires factor >= 0): every unit moves by exactly factor x volume (`rd_net_injection_g`), checked in the models and in the runs. Precondition, not defect: the pipeline always goes through `resolve_glsk`.

**Cost.** Preventive: (penalty factor x `penalty_reference_rd_pra` [per-TSO override] + bid price) x TOTAL bid volume; there is no price per generator. `results_generating_units.csv` shares the cost over the units in proportion to their moves. Case A, down 100 MW: (1.0 x 100 + 90) x 100 = 19000 EUR (penalty 10000 + price 9000); Breed 11400 (60 MW), Philo 7600 (40 MW). Curative: the same per-MW amount on the maximum volume over the contingencies, the price being the reservePrice, else the energy price (not run for B and C, see below).

**Generator limit (REPORT, owner decides).** Each unit has hard rows Pmin <= P + factor x volume <= Pmax. The bid volume therefore stops where the FIRST unit reaches its limit: total <= headroom of the unit / its factor. The rest of the bid stays unused; it is not moved to the other units of the key (the factors are fixed). Cases (target, limits from the CGM):

| Case | Up headroom GA-G2 | Result |
|---|---|---|
| bid 150 up (B) | 45 MW = 0.3 x 150 exactly | 150 MW used: GA-G1 +75, GA-G2 +45 (production 225 = Pmax), GA-G3 +30; the limit is reached but not exceeded |
| bid 200 up (C) | 45 MW | 150 MW used (= 45 / 0.3): +75 / +45 / +30; 50 MW of the bid unused |
| bid 200 down (C) | down headroom GA-G2 50 MW (180 - 130) | 166.67 MW used: -83.33 / -50 / -33.33 (model-level; the runs activate the up direction) |

The same holds for the curative block (per-unit rows on the maxima, CORNET-4614). It follows from the rows that a unit that is already at its limit in the bid direction (headroom 0) with a factor > 0 blocks the whole bid in that direction; this was not run. Not decided: whether the surplus should be passed on to the other units (renormalised factors), or the bid left as it is.

**Curative pair B / C is not activated.** The curative balance of a contingency sums to 0 (CORNET-574, a lone curative bid cannot move: existing test `test_lone_curative_up_bid_cannot_move_without_a_counterpart`). The up and the down RA of B and C have the same key, so their volumes must be equal and cancel on every unit: the pair can never move, whatever the bid size or price. The model-level test shows it, and the full runs of B and C read the pair (factors right) and activate nothing. With a partner on other units the curative bid behaves like the preventive one (model-level test). The overload of the contingency exists (CO3: TieLine_SD_BO2 106.8 %) but is relieved by other means. Not tuned: bid size and price cannot change this, and the task forbids changing the grid or the generators.
Because of that two preventive twins were added (decision taken here, DECISIONS 118): `B_preventive` and `C_preventive` (Galia, preventive, no contingency link, same units, factors, prices and bids as B and C). They are balanced by the RD RAs of the other TSOs, are activated, and give the 3-unit numbers and the limit case in a full run.
Side effect of B and C: removing all Galia RD RAs (the generators G1, G2, G3 are all in the shared bid) leaves two N-X PATL slack rows after the run (A: none); this is the grid without its Galia redispatch, not a defect.

**Numbers per generator (full runs, pst+rd, ac_iterative, N-X on).**

| Case | RA used | GA/Espheim generators | Cost of the RA |
|---|---|---|---|
| A (bid route) | down, -100 MW (the whole bid) | Breed -60 (359.412 MW), Philo -40 (150.083 MW) | 19000 EUR (penalty 10000) |
| A_strategy | identical to A | identical | identical |
| B (curative) | none (pair cannot move) | 0 / 0 / 0 | 0 |
| C (curative) | none | 0 / 0 / 0 | 0 |
| B_preventive | up, +150 MW (the whole bid) | GA-G1 +75 (780.637), GA-G2 +45 (225.0 = Pmax), GA-G3 +30 (210.0) | 24000 EUR (penalty 15000) |
| C_preventive | up, +150 MW of 200 | as B_preventive | as B_preventive |

In every run the RD moves of all units add up to 0 and the logs have no deprecated-form, sign, ignored-RA, interpolation or empty-GLSK warning (a test per run).

**Owner decisions pending:** (1) behaviour at a unit limit (stop at the first limit, as now / pass the surplus to the other units / reject the bid); (2) whether curative shared bids need a documented partner rule (the pair on one key can never move); (3) whether the preventive twins stay in the dataset; (4) whether a price per generator (not per bid) is ever needed.

## Shared-bid redispatch, round 2 (25 Oct 2026): scope of the balance, case D, warning

Owner decisions recorded as DECISIONS 119 to 123 (surplus accepted, one price per bid, curative B and C dropped, case D, data warning). Round-1 commit `90f0277` was not changed.

**Step 0: scope of the balance (characterisation tests, no change in `src/`; they confirm the expected answers).**
1. Preventive RD: ONE hard row `rd_balancing_n0`, the sum of the moves of all units in the model is 0. It has no TSO and no bidding zone: an up bid of TSO T1 is balanced by a down bid of T2 (T1 has no down bid), and the row holds the variables of both bids (`test_rao_balance_scope_preventive_is_one_row_over_the_whole_network_not_per_tso`). The full runs show it too: a Galia / Belgovia / Svedala move balances an Espheim move.
2. Curative RD: one hard row per contingency over every curative RD RA acting in it, from any TSO. An RA acts in the contingencies it is linked to, or in all contingencies of the N-X results when it has no link, minus its excluded ones (`effective_linked_contingencies`). Shown by: a Svedala down bid linked to CO1 balanced by an up bid of Galia linked to CO1; an unlinked RA balancing a linked one in both CO1 and CO2; an up RA linked to CO2 only NOT balancing the down RA of CO1 (overload stays).

**Case D (Svedala) on the full run (pst+rd, ac_iterative, N-X on).** The four RAs are read with exactly the requested factors (`glsk_resolved.csv`): SHARED3_UP 0.5 / 0.3 / 0.2 on G1 / G2 / G3, SHARED2_UP 0.6 / 0.4 on G3 / G4, SHARED3_DOWN 0.4 / 0.4 / 0.2 on G1 / G2 / G3, SHARED2_DOWN 0.5 / 0.5 on G3 / G4; no deprecated-form, sign, ignored-RA, interpolation, empty-GLSK or "no net movement" line. **None of them is activated.** Bid size and price were tuned as allowed (1 EUR/MW and 400 MW on all four RAs): still nothing moves, so it cannot be activated in this grid. Why: HALLAN_G1..G4 sit at one substation with almost identical sensitivities. On the overloaded TieLine_SD_BO2 they are +0.65 A/MW (an up move makes it worse, only downs help), on CL5 -0.21 A/MW (ups help). The preventive ups worsen TieLine_SD_BO2 (about 650 EUR per MW at the slack price) more than they relieve CL5 (about 210 EUR per MW); the curative downs on the same units cancel the effect of the kept curative ups, so no curative move gains anything. The removed Svedala preventive downs of P were the RAs that relieved TieLine_SD_BO2 in A; without them the run leaves PATL slack rows (CL5, TieLine_SD_BO2, 23-25), as in B and C of round 1.
What D does when it can move is shown on small models with the real Svedala units, limits, factors and prices (`test_rao_shared_bid_d_*`):

| Part | Result |
|---|---|
| Preventive ups, 250 A over, every unit -1 A/MW | SHARED3_UP 150 MW and SHARED2_UP 100 MW both used up: G1 +75, G2 +45, G3 +90 (0.2 x 150 + 0.6 x 100, in both bids), G4 +40; balanced by a down move of 250 MW of another unit (here a free partner `GU_BAL`; in the grid it would be the preventive downs of the other TSOs); cost (100 + 40) x 150 + (100 + 45) x 100 = 35500 EUR |
| Curative under CO1 (40 A over, relieved by G3 and G4 only) | SHARED2_DOWN 40 MW (G3 -20, G4 -20, the cheaper way to relieve), SHARED3_DOWN 0; balanced by the kept curative ups of G1 and G2, +40 MW together (the split between G1 and G2 is a tie); the moves of the four units sum to 0 |

**Data warning "no net movement possible" (DECISIONS 123).** `glsk_resolver.warn_curative_no_net_movement(rd_list, bid_list, glsk, contingencies, timestamp)`, called in `run_pipeline` after the GLSK resolution (N-X on). Per contingency: the curative RD RAs acting there (any TSO; available, with a key and a bid of positive size; countertrade left out); a warning when only one direction exists or when every up and every down RA has the same normalised key (factors rounded to 9 digits); one warning per contingency, naming the contingency (id, name, TSO) and the RAs. Tests first (8 tests on synthetic sets: sole pair on one key fires, different keys do not, a partner of another TSO with another key does not, one direction fires for up and for down, an unlinked pair fires in every contingency, an exclusion makes it a one-direction case, preventive and keyless RAs are ignored, one warning per contingency). It does not fire in the runs of P, A, A_strategy, B_preventive, C_preventive and D (a test per run) nor in the golden matrix (checked in the gate).

**Owner decisions pending:** (1) D cannot be activated in this grid; to see the full-run split of D's curative downs and preventive ups a variant would need a different set of generators or a different location of the units (not changed, the task forbade changing the grid); (2) whether the warning should also be raised when the pair has different keys but the same net effect (generators at one substation, as in D) - not done, the check is on keys only.

## Shared-bid redispatch, final round (26 Oct 2026): case D in Espheim

Owner decisions: DECISIONS 124 (the warning compares keys only) and 125 (D moves to Espheim). No change in `src/`, the grid or the generators.

**Step 1: sensitivities used** (A per MW up, from `sensitivity_rd_nx.csv` / `sensitivity_rd_n0.csv` of the P run; the overloads of that run: CL5 under Svedala CO2 123 %, slack 96 A left; TieLine_SD_BO2 under three Svedala contingencies 106 to 114 %; 23-25 under Espheim CO2 105.5 %, 0.36 A slack left; 60-61 under Espheim CO3 / CO4 96.8 %, no overload):

| Branch, contingency | Breed | Philo | CabinCrk | Claytor |
|---|---|---|---|---|
| 23-25, Espheim CO2 | -0.007 | -0.073 | -0.124 | -0.133 |
| 60-61, Espheim CO3 / CO4 | +0.021 | -0.535 | -0.164 | -0.182 |
| TieLine_SD_BO2, Svedala contingencies | -0.05 to -0.07 | -0.24 to -0.27 | -0.22 to -0.25 | -0.22 to -0.25 |
| CL5, Svedala CO2 | +0.174 | +0.025 | +0.037 | +0.037 |
| N-0 (only the preventive units have it): 9-10, 68-81, TieLine_SD-EH1 | +0.305, -0.06, -1.93 | -0.268, +0.641, -0.172 | - | - |

Reading: of the Espheim contingencies only CO2 has an overload to relieve (23-25); ups on CabinCrk and Claytor relieve it most, Breed hardly changes it. The only large unresolved overload is CL5, which Breed relieves by going DOWN (+0.174 A/MW) and every other unit worsens by going up (about 360 EUR per MW at the slack price). So the useful preventive direction is DOWN. The first design (preventive ups) was read wrongly from the TieLine_SD_BO2 row alone; it was not activated at 85 / 90 nor at 40 / 45 EUR/MW, nor with CabinCrk and Claytor in the keys, and is not counted as an attempt (the direction is part of step 1).

**Step 2: attempts** (limit 2).
1. Bid size and price: preventive downs 60 / 40 MW, curative downs 100 / 80 MW: both preventive downs activated; of the curative downs only the 2-unit one (its keys cancel less of the curative ups) and the CabinCrk and Claytor ups; the 3-unit curative down (with CabinCrk 0.2) stayed at 0.
2. Generator choice: the third unit of the 3-unit curative down changed from CabinCrk to Claytor (0.5 / 0.3 / 0.2 on Breed / Philo / Claytor) and the curative 2-unit down reduced to 40 MW: **all four RAs activated.** Stop.

**Result (full run, pst+rd, ac_iterative, N-X on)** - factors in `glsk_resolved.csv` as designed; no deprecated-form, sign, ignored-RA, interpolation, empty-GLSK or "no net movement" line.

| RA | Volume | Cost |
|---|---|---|
| `PRA_RD_ES_SHARED3_DOWN` (bid 60 MW, 85) | -60 MW (used up) | (100 + 85) x 60 = 11100 EUR |
| `PRA_RD_ES_SHARED2_DOWN` (bid 40 MW, 90) | -40 MW (used up) | (100 + 90) x 40 = 7600 EUR |
| `CRA_RD_ES_SHARED2_DOWN` (bid 40 MW, 90) | 40 MW (used up) under CO2 and CO_VComp_Linear | (100 + 90) x 40 = 7600 EUR (worst case over the contingencies) |
| `CRA_RD_ES_SHARED3_DOWN` (bid 100 MW, 85) | about 28 MW under the same two contingencies | (100 + 85) x about 28 EUR |

Preventive moves per generator: Breed -54 MW (0.5 x 60 + 0.6 x 40), Philo -34 (0.3 x 60 + 0.4 x 40), Claytor -12 (0.2 x 60), CabinCrk 0; cost per unit: Breed 10110, Philo 6370, Claytor 2220 EUR. Balance: the preventive downs (-100 MW) and the Svedala down `PRA_RD_SV_HALLAN_G4_DOWN` (about -79 MW) are balanced by the preventive ups `PRA_RD_GA_G1_UP` (+100), `PRA_RD_GA_G2_UP` (+40) and `PRA_RD_BO_G1_UP` (about +39); no Espheim up RA moves. Curative: in each of the two contingencies the downs (40 + about 28 MW) are balanced by the kept `CRA_RD_ES_CABINCRK_UP` (60) and `CRA_RD_ES_CLAYTOR_UP` (about 8). The curative shares per generator follow from the factors (model-level tests); the curative moves of the units are not exported.
Tests (`test_rao_rd_shared_bid.py`): the factors (glsk file), the preventive moves, shares and cost, the curative balance with the kept ups and the cost, the logs of every run without NCP-form or "no net movement" warning. Nothing is left open for the shared-bid topic.
