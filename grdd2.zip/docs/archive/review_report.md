# RAO prototype: read-only review, NCP wiring focus

Branch `ncp-standard-alignment`, working tree clean at the start. No repo file was changed. Throw-away scripts and their outputs are in the session scratchpad (`me/`, `forkA/`, `forkB/`, `forkD/`). The pipeline was profiled only on a copy outside the repo. `input/` was read (hashes) and never written.

Method: read, grep and trace. Doubtful claims were run against copies of the fixtures. Every file:line was read in this review unless it is marked **unverified**.

---

## 0. Top findings

### 0.1 Correctness, ranked by risk to results

| # | Sev | Where | Evidence (one sentence) | Proposed fix |
|---|---|---|---|---|
| 1 | HIGH | `src/rao/pre_milp/ncp_parser.py:1187-1192` (`_iso_to_hhmmz`, `:117-126`) | A bid time point is keyed by clock time only, and a later point overwrites an earlier one silently. Script run: a bid with 100 MW on 2022-06-15T10:30Z and 5 MW on 2022-06-16T10:30Z was read as 5 MW at 1030Z, three runs out of three; which point wins depends on file order. | Key the points by full datetime and select the run's datetime. At least warn when two points of one schedule share a clock time. DECISIONS 109(3) documents clock-time matching but not the overwrite. |
| 2 | HIGH | `src/rao/pre_milp/ncp_parser.py:242-246, 279-286, 334-374` | `AssessedElement.normalEnabled`, `inBaseCase`, `isCombinableWithContingency/RemedialAction` and the `AssessedElementWithContingency` links (incl. `excluded`) are read nowhere in `src/rao` (grep). An element the TSO marks off or N-0-only is still a row in every contingency. Sample G carries a `false` or `excluded` value of each. | Read the flags, or warn once per file with counts, the way `AssessedElementTimePoint.enabled=false` is warned about today. |
| 3 | HIGH (physics) / documented | `src/rao/milp/milp_builder.py:1671-1705` | The curative unit limit is one row per unit on the per-bid maxima over all contingencies (net form). A unit's up bid peaking in contingency A and its down bid peaking in B cancel in that row, so in A the unit can go above Pmax (or below Pmin). Reasoned from the rows, not run. This follows the spec formula on purpose (R7, `reference/spec/curative_rd_tatl_specs.md:70-87`), but DECISIONS 73 says "per contingency". The mock has separate up and down CRAs per unit (e.g. `CRA_RD_GA_G1_UP/DOWN`), so the case is realistic. | Owner decision (section 10): add per-(unit, contingency) rows next to the R7 row. This changes results, so it is a correctness change. Correct the wording of DECISIONS 73 either way. |
| 4 | MEDIUM | `src/rao/pre_milp/ncp_parser.py:1191, 1206, 1260` | Time points are stored under the schedule's rdf:ID fragment but looked up by its `IdentifiedObject.mRID` literal. Script run: a schedule with mRID ≠ rdf:ID was read as 0 MW, price 0, with only "no price ... set to 0". `read_key_routes` (`:1351-1374`) has the same mismatch for the bid route. | Look the points up by the subject URI fragment, as `read_key_routes` does for distributions. Add the bid-schedule case to `warn_unmatched_ra_references`. |
| 5 | MEDIUM | `src/rao/pre_milp/ncp_parser.py:477-478` | A contingency without `normalMustStudy` is "not must-study" and never analysed. The only trace is an info count (`:513-517`), checked on a synthetic file. | Warn per file with the count, or confirm the profile default and document it. |
| 6 | MEDIUM | `src/rao/pre_milp/ncp_parser.py:1743-1744, 1858-1859` | `exclusive` (and every other non-restrictive, non-balanced) RA dependency is skipped silently. On G Svedala, `parse_ra_groups` returns `{}` with no log. | Warn with kind counts. |
| 7 | MEDIUM | `src/rao/pre_milp/ncp_parser.py:984-1020` | `warn_unsupported_sis_content` does not cover `GridStateAlterationSchedule/TimePoint.enabled=false`. G Espheim and Svedala carry it and get no warning. It also does not cover shift keys on countertrade RAs or bids (`ct_units.py` reads none). | Add both to the warning. |
| 8 | MEDIUM | `src/rao/pre_milp/ncp_parser.py:1109-1113` | With default `ra_types` every run on P logs the 8 countertrade RAs as "IGNORED — it has no generating unit in a shift key". Exactly 8 lines (checked), but the reason is wrong: countertrade is not in `ra_types`. | Use a class-specific reason. Drop the dead `"_" + mrid` lookup at `:1100` (`_frag` already strips `_`). |
| 9 | MEDIUM | `src/rao/pre_milp/ncp_parser.py:279-286` | The AE link classes are in `ae_types_to_parse` (`:244-245`), so each valid link object gives a "spec violation" warning: 4 on G Belgovia. The warning is wrong, and the link is dropped. | Read them as associations, or warn "not read". |
| 10 | MEDIUM | `docs/DECISIONS.md` 20, 31, 37, 73, 104, 117, 118, 125, 126; `src/rao/config/rao_config.default.yaml:229`, `src/rao/config/rao_config.yaml:232` | Stale statements: activation and start-up cost are in the objective (`milp_builder.py:1016-1031, 2626-2643`); `reservePrice` is parsed and used (`ncp_parser.py:1182, 1295-1300`; `milp_builder.py:1419-1430`); the strategy route is built; P is no longer "converter output byte for byte" (`mock_data/standard.py:48-55`); `tools/`/`tests/` paths are now `mock_data/`; the config comment says a missing HVDC factor is 0 (the code uses 1.0, `ncp_parser.py:1958-1965`). Byte damage: DECISIONS 112 and 115 contain 6 bare CR bytes where an "r" was, and ASSUMPTIONS line 18 is cut mid-sentence and continues at line 21. | Correct the texts. Mark 20, 31 and 37 as superseded. |

### 0.2 Performance, top 5 (no change in results)

| # | Where | Evidence | Proposed change |
|---|---|---|---|
| P1 | `src/rao/pre_milp/nx_sensitivity.py:157-184`, `:170-171` | A dense `{(branch, variable): float}` dict per contingency, so memory grows with C·N·V. `row_count`/`column_count` call `list.count` inside a comprehension, which is O(V²) and O(N²) per matrix. | Use `collections.Counter`, which gives identical values. Keep the numpy matrix, or store only the pairs the model reads. |
| P2 | `src/rao/pre_milp/ncp_parser.py:170-173` | `_load_graph` has no cache: 57 parses in one pst+rd run, 72 with countertrade (measured). Each SIS and RA file is parsed 3-5 times. | Cache one graph per (path, mtime) per run, or pass graphs. |
| P3 | `src/rao/run_pipeline.py:682`; `src/rao/pre_milp/ct_units.py:218-231` | Full rdflib parse of the EQ files: 9.1 s of 18.5 s profiled (pst+rd). With countertrade the same EQ files are parsed a second time (+9.5 s of 45 s). | Read the three maps needed (TapChanger→Transformer, CurrentLimit side, ControlAreaGeneratingUnit) with one streaming `lxml.iterparse` pass per EQ file. |
| P4 | `src/rao/milp/milp_builder.py:1585-1613, 1678-1727, 1916-1990` | Rule bodies scan every pair or unit for each index: O(G·C·B·C) for curative net injection, O(C²·G) for the balance, O(N·C·(P+G)) for N-X rows (sensitivity lookups mostly 0). | Group once by contingency and unit. Keep the term order, so the expressions stay identical. |
| P5 | `src/rao/post_milp/nx_results_export.py:21-67` | Re-evaluates Pyomo expressions for every (C, N) row: 3.9 s of 45 s (countertrade run). | Read variable values into dicts once. Keep the summation order. |

---

## 1. Wiring of parsed NCP attributes

WIRED = parsed and used in the model, sensitivities or outputs. DROPPED-SILENTLY = no runtime log line (a doc may still mention it).

### Remedial-action kinds and common attributes
| # | Attribute | Parsed where | Used where | Status |
|---|---|---|---|---|
| 1 | PST = GSARA + `TapPositionAction.TapChanger` | ncp_parser.py:723-731, 749-757 | TapChanger→transformer ncp_parser.py:637-695, 792; milp_builder.py:100-120, cost :393 | WIRED |
| 2 | `RedispatchRemedialAction`, units from shift keys | ncp_parser.py:1495-1501, 1513-1514 | run_pipeline.py:717-724, 1027-1045 | WIRED |
| 3 | RD old form `RotatingMachineAction` | ncp_parser.py:1467-1478, 1515-1522 | as 2, deprecation warning once per file | WIRED (deprecated) |
| 4 | `raiseRampRate` / `lowerRampRate` | ncp_parser.py:1480-1492 | stored :1587-1588; no reader in milp/ | PARSED-NOT-USED (DECISIONS 115) |
| 5 | `CountertradeRemedialAction` | ct_units.py:66, 85-151 | ct_units.py:367-406 → run_pipeline.py:799-817 | WIRED (only with `countertrade` in ra_types) |
| 6 | HVDC = GSARA + `EquivalentInjectionAction` | ncp_parser.py:1892-1904, 1941-1953 | run_pipeline.py:738, 1056-1121 | WIRED |
| 7 | `normalAvailable` (missing = False) | PST :761-762, RD :1527-1528, CT ct_units.py:131,144, HVDC :1956,1971 | run_pipeline.py:850,854,938; milp_builder.py:115,120,198-202,662,768,1449 | WIRED |
| 8 | `RemedialAction.kind` ("curative" substring, else preventive) | PST :764-766, RD :1530-1532, CT ct_units.py:132-133, HVDC :1957,1972 | run_pipeline.py:850-869; milp_builder.py:100-104 | WIRED. An unknown or missing kind becomes PREVENTIVE silently |
| 9 | `penaltyFactor` PST (missing 1.0, warning) | ncp_parser.py:768-776 | milp_builder.py:393; n0_results_export.py:146 | WIRED |
| 10 | `penaltyFactor` RD (missing 1.0, warning) | ncp_parser.py:1536-1544 | milp_builder.py:2587-2619, 1400-1416 → 2700-2703 | WIRED |
| 11 | `penaltyFactor` CT (missing 1.0, warning) | ct_units.py:134-141 | milp_builder.py:2654-2657, 2719-2721 | WIRED |
| 12 | `penaltyFactor` HVDC (missing 1.0, warning) | ncp_parser.py:1958-1965 | milp_builder.py:2668-2680 | WIRED (the fill line of `hvdc_info` is unverified) |
| 13 | `timeToImplement` PST | ncp_parser.py:779-783 | cra_preprocessing.py:144,157 | WIRED |
| 14 | `timeToImplement` RD / CT / HVDC | ncp_parser.py:1547-1549; ct_units.py:146-148; ncp_parser.py:1974-1976 | cra_preprocessing.py:32-36,76; ct_results_export.py:212; HVDC R9 (line unverified) | WIRED |
| 15 | `GridStateAlteration.timePerStage` | ncp_parser.py:823-840 | cra_preprocessing.py:144,157 | WIRED |
| 16 | several TapPositionActions in one GSARA → group | ncp_parser.py:789 | pst_groups.py:19-20; cra_preprocessing.py:259-262 | WIRED |
| 17 | `StaticPropertyRange` (curative PST range) | ncp_parser.py:879-966 | run_pipeline.py:1218-1231 | WIRED |
| 18 | `RangeConstraint` direction / valueKind / normalValue (HVDC) | ncp_parser.py:1913-1938 | run_pipeline.py:1077-1085 | WIRED |
| 19 | `isCrossBorderRelevant`, `AppointedToRegion`, `RemedialActionSystemOperator` | – | TSO comes from the file name | DROPPED-SILENTLY |
| 20 | `isActivationRestricted` | – | – | DROPPED-SILENTLY (DECISIONS 96) |
| 21 | `GridStateAlteration.normalEnabled` | – | – | DROPPED-SILENTLY (ncp_data_requirements.md:332) |
| 22 | `maximumPerDay`, `minimumActivation` | – | – | DROPPED-SILENTLY (G Svedala 9 each) |
| 23 | GSARA with only non-tap actions (topology, shunt, ...) | ncp_parser.py:755-757 (no log) | – | DROPPED-SILENTLY (G: 28 topology actions) |
| 24 | RA schemes, stages, gates, AvailabilityRemedialAction | – | – | DROPPED-SILENTLY |

### Contingency links
| # | Attribute | Parsed where | Used where | Status |
|---|---|---|---|---|
| 25 | `ContingencyWithRemedialAction.RemedialAction/Contingency` | ncp_parser.py:69-100 | PST :734,785; RD :1454,1590; CT ct_units.py:73,149; HVDC :1907,1977 | WIRED |
| 26 | kind `included` | ncp_parser.py:82-83, 99 | linked_contingency_mrids | WIRED |
| 27 | `excluded` → `excluded_contingency_mrids` | ncp_parser.py:84-86 | `effective_linked_contingencies` data_model.py:176; milp_builder.py:1464-1465 (RD/CT curative), :1188-1189 (HVDC); cra_preprocessing.py:161-163, 283-284; glsk_resolver.py:333-334 | WIRED |
| 28 | `considered` (= included, warning once per file) | ncp_parser.py:87-92 | as included | DROPPED-WITH-WARNING (OPEN-3) |
| 29 | missing or unknown kind | ncp_parser.py:93-98 | as included | WIRED with a warning |
| 30 | `ContingencyWithRemedialAction.normalEnabled` | – | a link with `false` is still used | DROPPED-SILENTLY (the "not read" of ASSUMPTIONS:22 is ambiguous) |
| 31 | effective links (no link = all, minus excluded) | data_model.py:176 | milp_builder.py:1464; glsk_resolver.py:333 | WIRED. PST: no included link means no CRA (cra_preprocessing.py:134-141) |

### Bids (SIS `PowerBidSchedule`)
| # | Attribute | Parsed where | Used where | Status |
|---|---|---|---|---|
| 32 | `PowerBidSchedule.PowerRemedialAction` | ncp_parser.py:1208-1215 | milp_builder.py:589-594, 2599 | WIRED (a bid of an RA that is not wanted is skipped at debug level, :1214) |
| 33 | `direction` (last word up/down) | ncp_parser.py:1217-1225 | MILP direction (line unverified); ct_units.py:405,419 | WIRED |
| 34 | `upAndDown` / `stable` / missing direction | ncp_parser.py:1218-1224 | bid skipped | DROPPED-WITH-WARNING (113) |
| 35 | time point `p` (abs; sign cross-check) | ncp_parser.py:1179, 1192-1197, 1260-1264, 1281-1286 | milp_builder.py:673, 1022 | WIRED. **Clock-time collision (0.1 #1) and mRID/rdf:ID lookup (0.1 #4)** |
| 36 | time point `price` | ncp_parser.py:1180, 1266-1279 | milp_builder.py:2617, 2658, 1430 | WIRED |
| 37 | bid `interpolationKind` | ncp_parser.py:1227-1235, 1129-1150 | available_mw and price | WIRED |
| 38 | `activationCost` (bid / time point) | ncp_parser.py:1247-1248, 1181, 1288-1292 | milp_builder.py:1016-1023, 2638-2643, 2659-2660 | WIRED (DECISIONS 20 stale) |
| 39 | `reservePrice` | ncp_parser.py:1182, 1290, 1295-1300 | milp_builder.py:1419-1430 → 2702, 2722 | WIRED (DECISIONS 31 stale) |
| 40 | `leadTime` | ncp_parser.py:1244-1245 | milp_builder.py:869-880, 1560-1575 | WIRED |
| 41 | `currency` | ncp_parser.py:1302-1303 | warning only (`warn_if_not_eur`) | WIRED (no conversion) |
| 42 | `isFixed` (true), `totalMinimumEnergy`, `totalMaximumEnergy` | ncp_parser.py:1119, 1237-1242 | – | DROPPED-WITH-WARNING (**one line per bid**; a large dataset gets one line per affected bid) |
| 43 | `minimumActivationP`, `stepIncrementP` | ncp_parser.py:1120, 1198-1200, 1240 | – | DROPPED-WITH-WARNING (per bid) |
| 44 | `priority` | – | – | DROPPED-SILENTLY (P: 56 bids; ncp_data_requirements.md:509) |
| 45 | `minimumUptime` | – | – | DROPPED-SILENTLY (G: 3) |
| 46 | non-standard `penaltyFactor`, `minEnergyBid`, `maxEnergyBid`, `stepSizeCTRD` | ncp_parser.py:1250-1258, 1314-1316 | not used (milp_builder.py:2585-2586) | PARSED-NOT-USED, one deprecation warning per call (:1325-1330) |
| 47 | `PowerBidDependency` / `PeerTemporalDependency` | count only, ncp_parser.py:1007-1012 | – | DROPPED-WITH-WARNING (once per SIS file; fires on G Belgovia) |

### Shift keys and participation factors (both unit routes)
| # | Attribute | Parsed where | Used where | Status |
|---|---|---|---|---|
| 48 | bid route `PowerShiftKeyDistribution.PowerBidSchedule` → `.PowerShiftKeySchedule` | ncp_parser.py:1351-1357, 1369-1374 | glsk_resolver.py:124, 165-170; ncp_parser.py:1386-1401 | WIRED |
| 49 | strategy route `PowerShiftKeyStrategy.PowerRemedialAction` + `...Distribution.PowerShiftKeyStrategy` | ncp_parser.py:1359-1364, 1375-1378 | the bid route wins per RA (glsk_resolver.py:166-170; ncp_parser.py:1399) | WIRED. All 32 RD RAs of P have both routes, so P never exercises the strategy fallback alone; the shared-bid cases A_strategy and D do |
| 50 | `PowerShiftKeySchedule.GeneratingUnit` → generator | glsk_resolver.py:133-135; ncp_parser.py:1392, 1404-1429 | milp_builder.py:594 | WIRED (a unit with several generators is dropped with a warning) |
| 51 | the 12 other resource types | ncp_parser.py:1336-1340; glsk_resolver.py:136-138, 209-230 | – | DROPPED-WITH-WARNING (one per RA, with counts) |
| 52 | `ParticipationFactorTimePoint` factor / atTime | glsk_resolver.py:175-204 | normalised :247-290 (warning when the sum ≠ 1) | WIRED |
| 53 | key `interpolationKind` | glsk_resolver.py:149-163 | `_factor_at` :55-74 | WIRED. A point without atTime overrides every timed point (:59-61); not documented |
| 54 | a key with several GeneratingUnits | glsk_resolver.py:141-148 | factor applied to each, then normalised | WIRED with a warning |
| 55 | different keys on the up and down bids of one RA | glsk_resolver.py:166-170 (union per RA) | one merged GLSK per RA (milp_builder.py:594) | WIRED-LOSSY, no direct warning (DECISIONS 111(2) names the per-RA limitation) |
| 56 | shift key on a countertrade RA or bid | never read | weights from remaining capacity, ct_units.py:409-426 | DROPPED-SILENTLY (deliberate per DECISIONS 126 / C3; no runtime warning) |
| 57 | CT `gLSKStrategy` (old form) | ct_units.py:76-82, 90-119 | strategy check | WIRED (deprecated; predicate `nc:RemedialAction.gLSKStrategy`, ct_units.py:91, not the name DECISIONS 70 gives) |
| 58 | CT `powerShiftKey`, `method` | ct_units.py:94-100 | – | DROPPED-WITH-WARNING (100) |
| 59 | `PowerRemedialAction.BiddingZone` | ct_units.py:126-129, 143 | ct_units.py:300-364 | WIRED |

### Groups, SIS content, AE, Org/CD, margins
| # | Attribute | Parsed where | Used where | Status |
|---|---|---|---|---|
| 60 | `restrictive` dependency (both group predicates) | ncp_parser.py:1703-1716, 1740-1764 | milp_builder.py:2272-2354, called :2463 | WIRED. Only preventive bids are summed (:2464); PST and HVDC members of a group are not counted, silently |
| 61 | standard chain `RemedialActionGroupTimePoint.RemedialActionGroupSchedule` → group, `maxRegulatingUp/Down` | ncp_parser.py:1779-1795, 1809 | same | WIRED (exact clock-time match; schedule interpolationKind not applied, ASSUMPTIONS 14) |
| 62 | old direct group form | ncp_parser.py:1781, 1789-1790, 1796-1802 | same | WIRED (deprecated; standard wins) |
| 63 | `balanced` (HVDC) | ncp_parser.py:1850-1876 | run_pipeline.py:1056 (hvdc_units.validate_hvdc_structure) | WIRED |
| 64 | `exclusive` and other kinds | skipped ncp_parser.py:1743-1744, 1858-1859 | – | DROPPED-SILENTLY (0.1 #6) |
| 65 | `RemedialActionDependency.normalEnabled` | – | – | DROPPED-SILENTLY |
| 66 | `PowerRemedialActionSchedule/TimePoint` (per-RA caps) | count only :1013-1020 | – | DROPPED-WITH-WARNING (108) |
| 67 | `GenericAvailableSchedule` | count only :992-997 | – | DROPPED-WITH-WARNING |
| 68 | `GridStateAlterationSchedule/TimePoint.enabled` | – | – | DROPPED-SILENTLY (0.1 #7) |
| 69 | `AssessedElementTimePoint.enabled` | ncp_parser.py:998-1006 (counts `== "false"` only) | – | DROPPED-WITH-WARNING (WP9 xfail) |
| 70 | AE `ConductingEquipment` / `Line` | ncp_parser.py:261-264 | run_pipeline.py:747 and every branch row | WIRED |
| 71 | AE `OperationalLimit` + EQ side | ncp_parser.py:302-316, 581-634 | TATL side, nx_security_analysis.py:258 (use line unverified) | WIRED |
| 72 | SHS `CurrentLimitSchedule/TimePoint` | ncp_parser.py:209-237 | patl_ka :378-411 | WIRED |
| 73 | `BaseCaseCurrentLimit.normalValue` | ncp_parser.py:318-331 | PATL fallback :393-394 | WIRED |
| 74 | `SecuredForRegion` / `ScannedForRegion` / `exclusionReason` | ncp_parser.py:334-374 | AEType → run_pipeline.py:833 | WIRED (presence only, the region is never compared with a CCR) |
| 75 | `AssessedElement.normalEnabled` | – | – | DROPPED-SILENTLY (0.1 #2) |
| 76 | `inBaseCase` | – | – | DROPPED-SILENTLY (0.1 #2) |
| 77 | `isCombinableWithContingency` / `...WithRemedialAction` | – | – | DROPPED-SILENTLY (0.1 #2) |
| 78 | `AssessedElementWithContingency` (+ kind) | iterated as an AE, :242-246 → warning :279-286 | association never used | DROPPED-WITH-MISLEADING-WARNING (0.1 #9) |
| 79 | `AssessedElementWithRemedialAction` | ncp_parser.py:737-745, 1457-1465, only with `ae_path` | run_pipeline.py:712, 717 never pass it; milp_builder.py:1859,1876 gated by `ACTIVATE_CRA_XNE_LINKAGE=False` | PARSED-NOT-USED (dead path; DECISIONS 30, 69) |
| 80 | `CrossBorderRelevance` | – | – | DROPPED-SILENTLY |
| 81 | `Contingency.normalMustStudy` (missing = False) | ncp_parser.py:477-478 | nx_security_analysis.py:29-31 | WIRED, but a missing value is silently "not studied" (0.1 #5) |
| 82 | contingency classes + `ContingencyEquipment.Equipment` | ncp_parser.py:455-511 | nx_security_analysis.py:35-44 | WIRED |
| 83 | `contingentStatus`, `EquipmentOperator`, `ExceptionalContingency.kind` | – | every element is tripped | DROPPED-SILENTLY (harmless on P/G) |
| 84 | Org/CD TSO, `ControlArea.SystemOperator` | tso_name_resolver.py:52-74 | TSO names | WIRED |
| 85 | Org/CD `BiddingZone`, `SchedulingArea.*` | ct_units.py:181-201 | CT zones; run_pipeline.py:809 | WIRED (CT only) |
| 86 | CGM `ControlAreaGeneratingUnit` | ct_units.py:218-231 | ct_units.py:325 | WIRED |
| 87 | Org/CD `CapacityCalculationRegion`, `BiddingZoneBorder`, `TieCorridor` | – | – | DROPPED-SILENTLY (no CCR filter on AEs or RAs) |
| 88 | `max/minEconomicPMargin` | – | – | DROPPED-SILENTLY (DECISIONS 91; absent from P/G) |
| 89 | `normalPositiveVirtualMargin` | – | `virtual_load_margin_pct` 0, scanned_elements.py:55 | DROPPED-SILENTLY (ASSUMPTIONS check 11) |
| 90 | SIS `UnitCostSchedule`, ER `GeneratingUnit.normal*Cost` | ncp_parser.py:1631-1694 | milp_builder.py:704-705, 2626-2637 | WIRED (only for TSOs with RD, run_pipeline.py:1010) |
| 91 | files of other profiles (SSI, CD_OR, PS, RAS, FAP) and cross-TSO CO files | ncp_loader.py:42, 52-53, 68-74 | – | DROPPED-SILENTLY (DECISIONS 37). G: `Svedala-Belgovia_CO.xml` and `DC-Espheim-Svedala_CO.xml` hold 6 must-study contingencies that are never read |

No USED-WITHOUT-PARSE case was found. The nearest is the PST operating range, which comes from the CGM hardware range (ncp_parser.py:816-817).

## 2. Silent drops and warning frequency

Silent at runtime, roughly by how much the result can move on real data:
1. Bid time points: clock-time collision across days, and the mRID/rdf:ID lookup (0.1 #1, #4).
2. AE gating flags and AE-contingency links (rows 75-78). The run warns about the time-dependent `enabled=false` but not about the static `normalEnabled=false`.
3. A contingency without `normalMustStudy` (row 81).
4. Exclusive dependencies (row 64); `GridStateAlteration*.enabled=false` (row 68).
5. Group limits count only preventive bids (row 60); up and down keys of one RA are merged (row 55); shift keys on countertrade are ignored (row 56).
6. An unknown `RemedialAction.kind` becomes PREVENTIVE (ncp_parser.py:766, 1532, 1972; ct_units.py:133).
7. With `ra_types` without `rd`, `parse_rd_units` is not called (run_pipeline.py:716), so RD and CT RAs and their bids are not mentioned at all. DECISIONS 43 says so; it is noted here because the "IGNORED" warning then never runs.
8. `priority`, `minimumUptime`, the remaining GSA attributes, non-tap GSARAs, cross-TSO CO files (rows 19-24, 44-45, 65, 91).

Warning checks:
- `warn_unsupported_sis_content` (ncp_parser.py:984-1020) fires once per SIS file and class. For the AE time point it fires **only** for `enabled == "false"` (line 1000), never for `true`. On G it fires for Belgovia (1 AE time point, 2 PowerBidDependency); it never fires on P. It misses `GridStateAlterationSchedule` (gap). It runs per TSO whatever `ra_types` is (run_pipeline.py:707) and reparses the SIS file.
- `warn_deprecated_form_once` (ncp_parser.py:56-66) uses a module-level set that is never reset. In one process (GUI, pytest session) a second run on the same extracted path logs nothing, so a test that asserts the warning depends on test order (unverified whether one does). It is also used for the non-deprecated `considered` and unknown-kind warnings (:88, :94): the behaviour is right, the name is misleading.
- Countertrade "not used and IGNORED" (ncp_parser.py:1109-1113): exactly 8 lines per default run on P (checked). The bids add no lines, because a bid of an RA that is not wanted is logged at debug level (:1214). The reason text is wrong (0.1 #8).
- `warn_curative_no_net_movement` (glsk_resolver.py:304-357) needs `rd` and N-X. It compares the keys of all up and down RAs of a contingency as one set (:345-347), so a same-key pair is not flagged once a third RA with another key acts there. This matches DECISIONS 123/124. It never fires on the fixtures (not re-run here).
- `warn_unmatched_ra_references` (ncp_parser.py:1023-1063) checks only CWRA and bid references. It skips dependency and strategy references, the contingency side of a link, and the bid-schedule mRID/rdf:ID case of 0.1 #4.
- Per-bid warnings (ncp_parser.py:1242 for unread attributes; 1271, 1274 for price; 1283 for sign) give one line per bid. On pan-European data that is thousands of lines; one aggregated line per call would be easier to read (the other bid warnings already aggregate, :1320-1330).
- Generic warnings carry dataset-specific text ("Jotunheim"): glsk_resolver.py:235-243, ncp_parser.py:1816-1823.

## 3. Countertrade in the standard form

- **Code:** a CT RA is read with zone, availability, kind, penaltyFactor, timeToImplement and links (incl. excluded), ct_units.py:66-151. It has no strategy, so `proportionalForRemainingCapacity` is assumed with one warning per RA (:120-125). Bids go through the shared `parse_power_bids`. Units and weights come from BiddingZone ← SchedulingArea → ControlArea (CD) → `ControlAreaGeneratingUnit` (EQ) → remaining capacity (ct_units.py:181-231, 409-426). No shift key is ever read for CT; `read_key_routes` / `resolve_glsk` only see RD RAs.
- **What the 2.5 form says** (`docs/archive/ncp_standard_alignment.md`): no line says a CT bid carries a `PowerShiftKeyDistribution`. L191 (I5) says "CT units and weights: not in the NCP; the bidding zone's units come from the CGM through the Organisation profile". L192 (I6) and L120 (D1) treat CT bids as the RD bid rows. A `PowerShiftKeyStrategy` binds to any `PowerRemedialAction` (L187, L189), and the CT RA is one, so the structure *permits* a strategy route for CT. That is an inference, not a statement of the doc. Sample G: the CT RA (`Belgovia_RA.xml:53`) carries the old `powerShiftKey=generatorPmax` and `method`; its 3 bids have no time points and no distribution; the only strategy in G points at an RD RA.
- **Verdict:** this is a **deliberate, documented deviation** (countertrade_ra_specs.md C3.2, DECISIONS 69-72, 126; alignment I5). The **gap** is that a key the data does carry for a CT RA or bid is dropped without a warning.
- **Owner decision:** "Warn (no result change) when a CT RA has a `PowerShiftKeyStrategy` or a CT bid has a `PowerShiftKeyDistribution`?" Recommendation: **yes**.
- **The 8 mock CT RAs** (`mock_data/countertrade_p.py`) are consistent with this reading:
  - 4 regions × {preventive, curative} (`:22-27`, `:115-116`), each with a zone mRID of `Org-NineRealms_CD.xml`, kind, `normalAvailable` true, penaltyFactor 1.0, and no strategy, powerShiftKey or method.
  - The curative RAs are linked `included` to every contingency of their region; the counts 2/5/1/8 are asserted (`:28`, `:113-114`).
  - Bids: direction literal, p > 0 up and p < 0 down, `interpolationKind next`, one point at RUN_TIME, activationCost 0, leadTime 0. Prices are 50 / 40-70-110 / 50 / 60, as in DECISIONS 126.
  - No shift key is written.
  - LOW gaps: no `timeToImplement` (R9 is never exercised by P's CT) and no `reservePrice` (the reservation fallback to the energy price is the only path exercised).

## 4. Dead and old-form code

| Code path | file:line | Reachable by a supported input? | Status |
|---|---|---|---|
| `RotatingMachineAction` RD form + ramp rates | ncp_parser.py:1467-1492, 1515-1522 | yes: `NCP_mock_legacy.zip` and builders that write old forms on P (DECISIONS 117; which builder writes which token is unverified) | kept on purpose (86, 88, 115) |
| non-standard bid attributes | ncp_parser.py:1122, 1250-1258, 1311-1316 | yes (legacy, builders) | PARSED-NOT-USED, warned, kept (109.5). `PowerBid.penalty_factor` defaults to 0.0 (:1251) and is unused (milp_builder.py:2585-2586) |
| CT `gLSKStrategy` (RA, bid) | ct_units.py:76-82, 91-93, 101-119 | yes (ct_mock / ncp_dataset negative cases; per-file unverified) | kept (100, 107) |
| CT `powerShiftKey` / `method` | ct_units.py:94-100 | yes (sample G) | warn-only, never read (100) |
| direct group-limit form | ncp_parser.py:1781-1809 | yes (legacy and builders; which builder is unverified) | kept (106) |
| `RemedialActionDependency.RemedialActionGroup` predicate | ncp_parser.py:1703-1716 | yes | kept (67, ASSUMPTIONS 14), no warning |
| shift-key unit = network generator id | ncp_parser.py:1423-1429 | yes (legacy) | kept (111) |
| `BidDirectionKind.*` | last-word match ncp_parser.py:1221-1225 | yes (sample G) | works; **no deprecation warning** (LOW) |
| `PowerBidDependencyKind` | count only, :1007-1012 | yes (sample G) | DROPPED-WITH-WARNING (109.4) |
| `AssessedElementWithRemedialAction` → `linked_xne_mrids` | ncp_parser.py:737-745, 1457-1465 | **no**: `ae_path` is never passed (run_pipeline.py:712, 717) and the use is gated False | dead (DECISIONS 30, 69) |
| `schedules_by_ra.get("_" + mrid)` | ncp_parser.py:1100 | **no** (`_frag` strips `_`) | dead branch |
| `cumulative_tap_change` | operating_point_state.py:230 | no caller in src, tests or mock_data | **dead** |
| `flows_to_currents` | dc_conversion.py:141 | test only (test_rao_dc_conversion.py:115) | test-only |
| `validate_load_flow_config` | run_pipeline.py:381 | tests only; `main` calls `validate_dc_power_factor` directly (:503) | test-only wrapper; its missing-key message never reaches a real run |

- **Config:** every leaf key of `rao_config.default.yaml` is read (grep for each quoted key in `src/`); no unused key. The two YAML files differ only in one comment. Stale comments:
  - `rao_config.default.yaml:229` and `rao_config.yaml:232` say a missing HVDC factor is "0, non-costly" (MEDIUM; the code uses 1.0).
  - `rao_config.default.yaml:207` says "7 values"; there are 11 (LOW).
  - `rao_config.default.yaml:4` gives a wrong path (LOW).
- **Duplicated logic:**
  - Interpolation is implemented twice: `ncp_parser.py:1117-1150` and `glsk_resolver.py:47-74`.
  - Key-route choice ("the bid route wins if it reaches an existing key") is implemented twice: `ncp_parser.py:1382-1401` (`read_redispatch_units`) and `glsk_resolver.py:126-170`. The SIS graph is parsed for each.
  - Namespaces are redefined in `glsk_resolver.py:33-34`.
  - Contingency-link reading is shared (`read_contingency_links`); not duplicated.
- **Stale text:** the `glsk_resolver.py:9-10` docstring says strategy-route distributions are not used.

## 5. Tests

- **xfail:** exactly one in `tests/`, `tests/test_rao_ncp_standard_equivalence.py:570` (`test_rao_a_disabled_assessed_element_is_not_monitored`, strict, WP9).
  - Its reason is still true: nothing reads `AssessedElementTimePoint` except the warning at `ncp_parser.py:998-1006`.
  - Caveat: the test calls `parse_assessed_elements` without the SIS file (around :554, :577), so it will keep failing even after a SIS reader is added, until the call is changed.
  - All skips in `tests/` are conditional (fixture presence, mode, `importorskip`), and none fires on this checkout.
- **Run:** 14 NCP-related test files with `-p no:cacheprovider` and the temp folder outside the repo: **589 passed, 1 xfailed** (307 s).
- **Self-reference:** `test_rao_ncp_dataset_valid.py:325-331` (`test_a_lead_time_delays_the_bid`) takes its expected value from `milp_builder._compute_earliest_usable_timestamp`, the code under test.
- **Missing check:** `test_rao_redispatch_standard.py:157-160` asserts `units == []` for non-GeneratingUnit resources, but not the counting warning that DECISIONS 89 and 102 require.
- **Weak tests:**

| # | Test | Weakness |
|---|---|---|
| 1 | test_rao_ncp_standard_equivalence.py `test_rao_converter_output_is_byte_identical_for_the_same_input` (line unverified) | converter vs itself: a determinism check only |
| 2 | same file, `test_rao_fingerprints_are_byte_identical_on_the_converted_mock` (line unverified) | expected values are generated output (regression, not correctness; DECISIONS 99 makes this the rule) |
| 3 | same file, :186 and :205 | parser(standard) vs parser(converted legacy): both sides share the converter, so a converter bug and a parser bug can cancel; no hand values |
| 4 | same file, :660 | P vs `build_standard` output byte for byte: self-comparison of data |
| 5 | test_rao_ncp_dataset_valid.py, row-count tests (lines unverified) | counts of `glsk_resolved` / `rd_cra_availability` rows, not unit ids or factors |
| 6 | test_rao_ncp_dataset_valid.py, full runs (lines unverified) | status, file presence and counts; no numeric result value |
| 7 | test_rao_p_countertrade.py | XML content only (8 RAs, names, bids, prices, links); no parse with countertrade on, no weights, no IGNORED count |
| 8 | test_rao_ncp_combination_kind.py | checks the parser split and one warning, not that `excluded` removes HVDC or CT variables in the MILP |
| 9 | test_rao_redispatch_standard.py | old vs standard form equality; factors not compared to hand values |
| 10 | test_rao_glsk_standard.py | warning substrings without the counts in them |
| 11 | test_rao_rd_shared_bid.py, full-run part (lines unverified) | "activated" (> 0) and shares; the total volume is not pinned to an independent value |
| 12 | test_rao_ncp_dataset_variants.py | most variants assert that a warning or error occurs, not its model consequence |

No assertion whose expected value was copied from the code's own output was found, apart from the fingerprint file (#2), which is a deliberate regression gate.

- **10 most valuable missing assertions:**
  1. Points on two days at the same clock time: the run-day point governs (fails today, 0.1 #1).
  2. A bid schedule with mRID ≠ rdf:ID keeps its volume and price (fails today, 0.1 #4).
  3. Curative RD/CT unit stays within Pmax in each contingency when its up and down bids peak in different contingencies (fails today, 0.1 #3; needs the owner decision).
  4. An `excluded` link removes the curative HVDC and CT variables and rows of that contingency (variable count, row presence).
  5. A missing HVDC `penaltyFactor` gives the numeric 1.0 × reference × |ΔP| in `hvdc_pra_penalty_cost`.
  6. A group limit from the standard chain appears as the RHS of the group row; with both forms present the standard value wins.
  7. CT zone weights of P: sum to 1 per direction, and hand values for one zone (e.g. Belgovia).
  8. Default `ra_types` on P: exactly 8 IGNORED lines with the (fixed) countertrade reason.
  9. Non-generator shift-key resources: the count in the warning equals the number of dropped schedules.
  10. An AE with `normalEnabled=false` or `inBaseCase=false` is excluded or warned about (fails today, 0.1 #2).

## 6. Consistency with DECISIONS 85-127 and ASSUMPTIONS

| # | Verdict | Evidence / mismatch |
|---|---|---|
| 85 | not checkable (scope) | – |
| 86 | **partly does not match** | Groups match (ncp_parser.py:1796-1809). Not warned: an RA typed `RedispatchRemedialAction` that also has `RotatingMachineAction`s silently drops the old actions (:1513-1516, "both present: standard wins, *with a warning*"); the old dependency predicate (:1709-1716) and `BidDirectionKind.*` (:1221) are accepted with no deprecation warning |
| 87 | not checkable (future) | – |
| 88 | matches | ncp_parser.py:1495-1514; old form :1467-1522 |
| 89 | **partly** | glsk_resolver.py:209-230 counts and names the types per RA. But `read_redispatch_units` (ncp_parser.py:1392-1400) drops them silently, so an RD RA whose keys are all non-GU resources gets only the generic IGNORED line (:1109-1113), with no count or types |
| 90 | matches | ct_units.py:120-125 |
| 91 | matches | no `EconomicPMargin` in src |
| 92 | matches | ncp_parser.py:1217-1225, 1281-1286 |
| 93 | superseded by 114 | – |
| 94 | matches | ncp_parser.py:1129-1150, 1227-1235 |
| 95 | matches | ncp_parser.py:69-100 |
| 96 | matches | ncp_parser.py:1013-1020 |
| 97 | matches in code; **config comment mismatch** | ncp_parser.py:1958-1965 vs rao_config.default.yaml:229, rao_config.yaml:232 |
| 98 | matches (renamed per 127) | mock_data/paths.py |
| 99 | matches | fingerprint test (line unverified) |
| 100 | matches | ct_units.py:94-100 |
| 101 | matches | ncp_parser.py:1343-1379 |
| 102 | matches | as 89 |
| 103 | matches | glsk_resolver.py:247-252 |
| 104 | **path mismatch** | names `tools/convert_ncp_to_standard.py`; the file is now `mock_data/convert_ncp_to_standard.py` |
| 105 | matches (not built, as stated) | xfail test_rao_ncp_standard_equivalence.py:570; `AssessedElement.normalEnabled=false` in the AE profile is neither read nor warned about |
| 106 | matches | ncp_parser.py:1779-1809 |
| 107 | matches | ct_units.py:76-125 (70's predicate name differs from the code, :91; LOW) |
| 108 | matches | ncp_parser.py:1958-1965, 1013-1020 |
| 109 | matches | ncp_parser.py:1117-1330. Its rule "a time point counts by its clock time" hides the overwrite of 0.1 #1 |
| 110 | matches | ncp_parser.py:69-100; data_model.py:176; milp_builder.py:1464-1465 |
| 111 | matches | glsk_resolver.py:77-290 |
| 112 | dust floor matches (mock_data/golden/compare_runs.py:43); **"counts stay exact" not implemented**: every cell that parses as a number goes through the relative or column-max tolerance (:39-44); **text damaged** (CR byte, line 140) | – |
| 113 | matches | ncp_parser.py:1222-1224 |
| 114 | matches | countertrade_p.py:74, 95; converter default (line unverified) |
| 115 | matches; **text damaged** (5 CR bytes, lines 143-149) | ncp_parser.py:1432-1600 |
| 116 | not checkable here (re-baselined outputs) | – |
| 117 | **does not match** | "a test checks that the shipped P is the converter output byte for byte": since 126, P = converter + countertrade_p (mock_data/standard.py:48-55), and the test (:660) compares with `build_standard`. Also old `tools/`/`tests/` paths |
| 118 | paths stale | `tests/ncp_dataset.py` → `mock_data/ncp_dataset.py` |
| 119 | matches | milp_builder.py:959-971 (preventive hard rows, no redistribution) |
| 120 | matches | milp_builder.py:2613-2619 |
| 121 | matches | mock_data/ncp_dataset.py `SHARED_BID_CASES` (line unverified) |
| 122 | matches | milp_builder.py:2471-2477, 1600-1613 |
| 123 | matches | glsk_resolver.py:304-357; run_pipeline.py:999-1006 |
| 124 | matches | glsk_resolver.py:345-347 |
| 125 | paths stale | `tests/ncp_dataset.py` |
| 126 | matches (8 lines, ncp_parser.py:1109); paths stale | the reason text of those lines is wrong (0.1 #8) |
| 127 | matches, with LOW exceptions | mock_data imports no test; src does not import mock_data (grep); pytest.ini `pythonpath = .`; input/ holds the two zips (byte-identical to the fixtures) plus git-ignored `_extracted_*`. But `test_rao_mock_data_cli.py:16-20` runs `cli.check`, which globs and hashes `input/` (cli.py:70-74): a test reads `input/`, against 127(3) and `.github/copilot-instructions.md:34` |

Outside 85-127, contradicted by the code:
- **DECISIONS 20:** says activation cost and start-up cost are not in the objective; both are (milp_builder.py:1016-1031, 2626-2643).
- **DECISIONS 31:** says no reservation price is parsed; `reservePrice` is parsed and used (ncp_parser.py:1182, 1295-1300; milp_builder.py:1419-1430).
- **DECISIONS 37:** says the strategy-route GLSK is not built and the RD/CT classes are ignored; both are built (WP3, WP4, WP5).
- **DECISIONS 73:** says the RD + CT Pmin/Pmax rows are "per contingency"; the curative rows are per unit on the maxima (milp_builder.py:1671-1705).

Byte-level damage:
- `docs/DECISIONS.md` entries 112 (line 140) and 115 (lines 143-149) have six bare 0x0D bytes where an "r" stood (`\r` interpreted on writing).
- `docs/ASSUMPTIONS.md` line 18 ends "…and ", and the sentence continues at line 21 ("d_cra_availability.csv …", the "r" of `rd_` lost), with two bullets inserted between.

OPEN items: every "Today" text is true.

| Id | Code evidence |
|---|---|
| OPEN-3 | ncp_parser.py:84-98 |
| OPEN-11 | ncp_parser.py:1217-1225, 1281-1286; references 92 and 113 are correct |
| OPEN-20 | glsk_resolver.py:247-252; CT default ct_units.py:120-125 |
| OPEN-22 | ncp_parser.py:1743-1744: only `restrictive` |
| OPEN-27 | no reader |
| OPEN-29 | warning only, ncp_parser.py:998-1006; strict xfail |
| OPEN-30 | as OPEN-11; mock signs countertrade_p.py:95 |

## 7. Cost model and balance

| Rule | Verdict | Evidence |
|---|---|---|
| cost = (penalty factor × reference + price) × total bid volume | **matches** | milp_builder.py:2613-2619, volume term :846-864 (cumulative against the original state); per-TSO override :2609-2611; an RA not found gives 0 with a warning (:2600-2607) |
| extra preventive terms | note | activation cost :2638-2643; start-up and shut-down :2626-2637 (DECISIONS 20 stale) |
| generator limits: hard rows, surplus not redistributed | **matches (preventive)** | units move by factor × bid volume (:900-909); `pmax_pmin_rule` :959-971; on/off :950-957; CT one-sided :1004-1012; no slack, so a shared bid stops at the first unit limit (DECISIONS 119). A small Pyomo case run confirmed the stop |
| curative generator limits | **net form over maxima, not per contingency** | :1671-1705; see 0.1 #3 |
| preventive balance: one row over the whole network | **matches** | :2471-2477, `sum(rd_net_injection_g[g] for g in m.gu_ids) == 0`; `gu_ids` covers every unit of every TSO incl. CT (:785, :816); HVDC is outside it (:2467-2469) |
| curative balance: one row per contingency over all curative RAs from any TSO | **matches** | :1600-1613; pairs from every available curative RD and CT bid (:1450-1469), effective links :1464-1466 |
| curative RD cost | matches 31/74 | :2688-2707: (factor × **preventive** RD reference + reservePrice or price) × (max up + max down) |
| curative PST cost | note | :2566-2581: a sum over (PST, contingency), not a maximum (as commented) |
| HVDC missing `penaltyFactor` = 1.0 | **matches** | ncp_parser.py:1958-1965 (the default is in the parser, not in hvdc_units.py); used at milp_builder.py:2668-2680 |

## 8. mock_data and housekeeping

- The generators in `mock_data/` import nothing from tests. But the golden scripts `mock_data/golden/run_case.py:7-8` and `fp_check.py` put `tests/` on `sys.path` and import `helpers` from there (LOW: the README rule "a generator never imports a test file" holds only for the generators). Nothing in `src/` mentions `mock_data` (grep), so the GUI does not import it.
- `input/` holds exactly `CGM_package.zip` and `NCP_mock_standard.zip`, both byte-identical to `tests/fixtures/` (SHA-256 compared). Also `_extracted_cgm/` and `_extracted_ncp/`: git-ignored, recreated by every run (run_pipeline.py:613, 624). So "exactly two files" holds only for zips. Note: any pipeline run writes into `input/`.
- `pytest.ini`: `pythonpath = .`, as DECISIONS 127 says.
- Links: no broken markdown link in `docs/`, `.github/`, `reference/` or the READMEs (script). Stale back-ticked paths: `docs/User_Guide.md:266-269` and `:361-364` are rename history (fine); `docs/Next_Steps.md:31` names `docs/Real_Data_Results.md`, a file still to be written (fine); the DECISIONS paths are listed in section 6.
- `mock_data/README.md` matches the CLI: all 8 commands and their options (cli.py:78-140).
- LOW: `cli.check` prints "standard = converter(legacy)" (cli.py:68) although the shipped mock is converter + countertrade. Also `check` reads `input/` and is run by a test (section 6, row 127).
- Leftovers: `logs/pytsc_*.log` (git-ignored by `*.log`), `tests/__pycache__`, `.pytest_cache` (git-ignored). Nothing else found.

## 9. Performance at pan-European scale

**Profile (measured):** cProfile on a copy outside the repo, mock P, `ac_iterative`, N-X on, default config. Profiler overhead inflates rdflib and Pyomo.

Unprofiled (measured by the performance reviewer; not re-run by me):
- pst+rd: 10.34 s. EQ parsing 4.31 s (42 %), NCP parsing 1.1 s (45 parses of 21 files), translation + HiGHS 0.25 s per solve.
- with countertrade: 19.44 s, translation + HiGHS 1.12 s per solve.

`reference/technical/Scalability_Report.md`: items Q1, Q2, Q3, Q5 and Q6 (N-X only) are done, Q4 was rejected under DECISIONS 39, and B1-B7 are still open (reviewer's reading; not re-checked).

| Case | Wall (profiled) | rdflib `_load_graph` | of which EQ | other hotspots |
|---|---|---|---|---|
| pst+rd | 18.7 s | 11.2 s, 57 calls | 9.1 s, 4 calls | `build_n0_milp_model` 0.54 s ×2; `compute_sensitivities_nx` 0.63 s; `warn_unmatched_ra_references` 0.62 s; `export_nx_loadings_csv` 0.27 s |
| with countertrade | 45.6 s | 21.0 s, 72 calls | 9.4 s, plus `read_control_area_units` 9.5 s | `export_nx_loadings_csv` 4.0 s; `build_n0_milp_model` 1.36 s ×3 |

The profile attributes about 16-27 s cumulative to APPSI `add_variables` / `_check_for_new_vars`. The calls are recursive and the totals exceed the wall time, so those numbers are **not reliable** and are not used. Solver translation was not measured cleanly.

**Ranked by expected gain at scale.** N = monitored branches, C = contingencies, V = sensitivity variables (PSTs + units), G = units, B = bids, F = NCP files. Every row keeps results identical.

| Rank | Location | Why it scales badly | Proposed change | Expected gain | Risk | Verify |
|---|---|---|---|---|---|---|
| 1 | nx_sensitivity.py:157-184 (`_matrix_entries`), callers :322, :440 | dense Python dict of (branch, variable) tuples per contingency, memory ~ C·N·V × ~150 B (estimate: C=500, N=5000, V=500 gives about 1e9 entries, which does not fit in memory); `list.count` in comprehensions :170-171 is O(V²+N²) per matrix | Counter for the counts; keep numpy matrices (or store only the pairs the builder reads) and index lazily | the run becomes possible at all; the count fix alone removes O(C·N²) work (estimate) | none for the Counter; needs care for the storage change (same values, same lookup order) | fingerprint test, golden matrix |
| 2 | milp_builder.py:1585-1613, 1678-1727 | `curative_rd_net_injection_rule` scans every (bid, contingency) pair for each (unit, contingency): O(G·C·B·C); the balance scans every (unit, contingency) pair per contingency: O(C²·G); the maxima rows O(G·B) | pre-group pairs by contingency and bids by unit, iterating in the same order as today | quadratic → linear in C (estimate: hours to seconds at C≈1000) | none if the term order is kept (DECISIONS 39) | fingerprints byte-identical |
| 3 | milp_builder.py:1935-1990, 1916-1933 (N-X rows) | each of N·C rows loops over all PSTs and units with dict lookups that are mostly 0: O(N·C·(P+G)); the profile shows 274k genexpr calls on the mock | iterate only the variables with a stored sensitivity, in the same order as today | large (estimate 10-50× at V≫ non-zeros) | **needs care**: DECISIONS 39 rejected "sum only non-zero" because outputs changed in the last digits. Dropping `0.0*x` terms changes the expression. Keep the zero terms, or prove byte-identical fingerprints | fingerprints, golden matrix |
| 4 | ncp_parser.py:170-173 and its 15+ call sites | no graph cache: F files parsed 3-5 times each (57-72 parses measured) | per-run cache keyed by (path, mtime), or pass graphs from run_pipeline | measured on the mock: about 2 s of 11.2 s rdflib (non-EQ part); at scale proportional to NCP size × 3-5 | none (read-only graphs) | full suite + matrix |
| 5 | run_pipeline.py:682, ct_units.py:218-231 | rdflib parse of the full EQ files (4 MB each on the mock; hundreds of MB at scale, rdflib needs about 1 KB per triple) just for three small maps; with countertrade a second full parse | one streaming lxml/iterparse pass per EQ file that builds the three maps | measured 9.1 s of 18.7 s (pst+rd), +9.5 s (CT); at scale minutes and GBs (estimate) | none if the maps are equal (assert equality in a test against the rdflib version) | map-equality test, matrix |
| 6 | milp_builder.py:2430 + milp_solver.py:68-87 | a new ConcreteModel and SolverFactory every solve; APPSI translates the whole model each time (iterations × completeness solves) | persistent APPSI solver with in-place updates of coefficients and RHS | large at scale (estimate 30-60 % of the MILP phase; unmeasured) | **needs care**: variable and row order may change; HiGHS may take another path on degenerate LPs | fingerprints + matrix; probably not identical, treat as result-changing until proven |
| 7 | post_milp/nx_results_export.py:21-67, 122+ | N·C rows × (P+G) `pyo.value` calls plus Pyomo expression evaluation per row | read variable values into float dicts once; same summation order | measured 4.0 s of 45.6 s (CT case); at scale O(N·C·V) Python work (estimate) | none if the order is identical | golden matrix CSV diff |
| 7b | sensitivity_checks.py:208-229 (N-0 guard per branch) | `of_branch` rescans the whole fresh dict for every branch: O(N × entries) on every iteration. Reviewer's measurement: 0.02 / 0.31 / 2.6 s at 5k / 30k / 120k entries | group the entries by branch once, keeping the insertion order | quadratic → linear (measured trend) | none | suite + matrix |
| 7c | hvdc_units.py:305-309 | `path.read_bytes()` inside a comprehension over the HVDC units: each EQ file is read once per unit, then parsed with rdflib a further time | read the bytes once per file; reuse the per-TSO EQ data | O(U × EQ size) → O(EQ size) | none | HVDC tests + matrix |
| 8 | ncp_parser.py:1023-1063, 984-1020 | diagnostic passes reparse RA and SIS per TSO | reuse the cached graphs of rank 4 | measured 0.8 s of 18.7 s | none | suite |
| 9 | n0_sensitivity.py:234, :340 | two N-0 sensitivity runs (PST, RD) per refresh | one run with two variable sets, as already done for N-X (nx_sensitivity.py:84-134) | one load-flow factorisation per refresh (estimate small) | numerical noise possible (ASSUMPTIONS 16) | matrix with rule 2 |

**Would change results** (not recommended as performance fixes):
- summing only non-zero sensitivities (DECISIONS 39);
- `lf_thread_count` > 1 (last digits, ASSUMPTIONS 15);
- a solver time limit or gap;
- warm start of the N-X refresh (DECISIONS 13);
- a loading-threshold filter > 0 before the analysis;
- rank 6 unless proven identical.

The performance reviewer's claim of `iterrows` in `n0_results_export.py` is false (grep: no `iterrows` in `src/rao`) and was dropped.

## 10. Yes/no decisions for the owner

1. Key bid time points by full datetime and select the run's date (fixes 0.1 #1)? **Yes.**
2. Add per-(unit, contingency) curative Pmin/Pmax rows for RD/CT next to the R7 net row (changes results)? **Yes**, as a correctness change with re-baselining.
3. Read `AssessedElement.normalEnabled` / `inBaseCase` / `isCombinableWith*` and the AE-contingency links, or at least warn with counts? **Yes**, warn now; read after a decision on semantics.
4. Warn when a CT RA or CT bid carries a shift key (no result change)? **Yes.**
5. Look up bid time points by rdf:ID fragment, so that mRID ≠ rdf:ID keeps the volume? **Yes.**
6. Warn on contingencies without `normalMustStudy`, on exclusive dependencies and on `GridStateAlteration*.enabled=false`? **Yes.**
7. Clean the docs: correct DECISIONS 20, 31, 37, 73, 104, 117, 118, 125, 126 and the config comment; repair the CR bytes and the split ASSUMPTIONS sentence? **Yes.**
8. Do the result-identical performance work (ranks 1, 2, 4, 5, 7) before the first real-data run? **Yes**, rank 1 is a blocker at pan-European scale.

## Not checked, and why

- **Full pipeline runs against `input/`:** not done (they write into `input/_extracted_*`). One profile on a copy outside the repo only.
- **Full test suite and golden gate:** not run (about 25 min, and the gate writes outputs). Only the 14 NCP-related test files were run (589 passed, 1 xfailed); `test_rao_ncp_dataset_variants.py` and the `ct_*` / `hvdc_*` test files were not reviewed in detail.
- **Not measured:** solver translation time (profile attribution unreliable), and memory use at scale (estimates only).
- **Not run:** the curative Pmin/Pmax violation (0.1 #3) was shown by reading the rows, not by building a model.
- **Not traced to a line:** where `hvdc_info` is filled, the exact rows of the RD direction and headroom bounds, the TATL side use, and the line numbers of some tests (all marked unverified).
- **Not swept:** dead code in `src/core`, `src/rao_pages` and calls made through `getattr` or strings. The GUI is out of scope.
- **No official 2.5 file:** the 2.5 profile PDFs and official 2.5 files were not opened. The 2.5 reading rests on `docs/archive/ncp_standard_alignment.md` and the 2.4 sample.
