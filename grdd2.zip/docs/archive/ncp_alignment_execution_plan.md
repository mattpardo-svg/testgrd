# NCP standard alignment - execution plan (WP0 to WP8)

Owner: Mahir. Companion to `docs/ncp_standard_alignment.md` (the analysis; row ids, OPEN ids and finding ids such as C1, C8, I2, E3 refer to it).
Save this file as `docs/ncp_alignment_execution_plan.md`. Where the two documents disagree, THIS file wins (it contains the owner decisions).

## 1. Goal

Make the mocked NCP data and the NCP parser follow the ENTSO-E profiles (RA 2.5 and SIS 2.5), without changing any optimisation result on the existing mock. Work package by package, each one proven by the equivalence harness and the fingerprints.

Reference shape of "standard form": the official ENTSO-E ReliCapGrid 2.5 files `Belgovia_RA.xml` and `Belgovia_SIS.xml` (github.com/entsoe/relicapgrid, branch cgmes-3.0_ncp-2.5_tc-2.0, Instance/Belgovia/NetworkCode/cimxml). Check the repository licence before copying anything into our fixtures; if unclear, mirror structure only and use our own ids. Older-version forms (BidDirectionKind, PowerBidDependencyKind, CountertradeRemedialAction.powerShiftKey / .method) are NOT the target. Match enumeration literals by their last word (up/down/upAndDown, etc.) so both namespaces and kind names are accepted. Where old samples and the PDFs disagree on predicate names, the official 2.5 files are the authority; list each disagreement in the alignment doc.

The data provider cannot answer questions, so every uncertainty is decided by inference and recorded in ASSUMPTIONS.

Findings from the WP0 report that apply to all packages:
- The official 2.5 files carry profile 2.5 in the header but namespace 2.4; the mock headers say 2.4. Never choose between standard and old form from the header version or namespace; decide by which elements and predicates are present.
- Official dependencies use `PeerTemporalDependency` (with `constraintKind`); sample G uses `PowerBidDependency.kind/.delay`. Treat both as "dependency: warn and ignore".
- Official shift keys use CIM GeneratingUnit ids; the mock uses SynchronousMachine ids (WP4 maps them).
- The licence of the official repository is unclear (CC BY-SA 4.0 file, CC BY 4.0 headers): copy nothing, mirror structure with our own ids.

## 2. Owner decisions (record each as a numbered entry in docs/DECISIONS.md; add a "Decision" column to the 17-question table in the alignment doc)

1. Target RA 2.5 and SIS 2.5. Sample G (profile 2.4) stays legacy and unchanged.
2. Standard form first; old form as fallback with a deprecation warning.
3. Old form is removed in the next release.
4. Redispatch units are derived from the GLSK chain.
5. Non-generator resources: warn and drop (see 20).
6. Countertrade without a strategy defaults to proportionalForRemainingCapacity (our own assumption; document it as such).
7. NO: do not read maxEconomicPMargin / minEconomicPMargin (wait for OPEN-27).
8. Direction: the literal on `PowerBidSchedule.direction` is authoritative (match by last word). A bid (redispatch or countertrade) with NO direction: warn and skip it; never infer direction from p. The sign is a cross-check only: in the official sample up bids have p>0 and down bids p<0; if direction and sign of p disagree, warn (do not change the value used). Bid size = |p|. Record as assumptions (OPEN-11 stays open: the profile says "load sign", the sample shows the opposite).
9. (Superseded by 24.) Do not touch bid quantities in the mock; signs: see 24.
10. Apply `interpolationKind` between time points (bid schedules and shift key schedules). State the default when it is missing.
11. Read `combinationConstraintKind`: `included` and `excluded` only; `considered` waits for OPEN-3 (warn).
12. NO (group limits for every dependency kind). 13. NO (keep config, do not map isActivationRestricted). 15. NO (per-RA caps and availability schedules: warn only).
14. HVDC missing `penaltyFactor` defaults to 1.0.
16. Regenerate the P zip (`NCP_pst_fallback_scenario.zip`), keep a legacy copy, leave G unchanged.
17. Fingerprints in `tests/fixtures/milp_model_fingerprints.json` stay byte-identical on the converted mock. Any difference = stop and report, never "fix".
18. `CountertradeRemedialAction.powerShiftKey` and `.method` are old-version attributes: warn if present, do not read. Keep reading the old `gLSKStrategy` as fallback.
19. Unit routes: support both (a) bid route: RA <- PowerBidSchedule <- PowerShiftKeyDistribution -> PowerShiftKeySchedule -> GeneratingUnit, and (b) RA strategy route: RA <- PowerShiftKeyStrategy <- PowerShiftKeyDistribution -> PowerShiftKeySchedule -> GeneratingUnit. If an RA has both, the bid's own route wins for that bid; the strategy route is the RA-level fallback. The strategy points to the RA (`PowerShiftKeyStrategy.PowerRemedialAction`), never the other way round. An RA without a strategy is valid.
20. Non-generator resources inside `PowerShiftKeySchedule` (EnergyConsumer, HydroPump, PowerElectronicsUnit, EquivalentInjection, ExternalNetworkInjection, EnergyBlockOrder, ScheduleResource, ...): not read, warn and drop (count them in the warning). Applies only to shift key schedules in SIS. HVDC RAs (EquivalentInjectionAction in the RA profile) are unaffected; the HVDC section of the harness must pass from WP0 on.
21. Participation factors: relative weights, normalised to sum 1 across the units of a key; warn when the sum is not 1. First report what the current code does; if it already normalises, no behaviour change.
22. Comparison rule, numerical dust floor: two numeric values with |a| <= 1e-9 and |b| <= 1e-9 (absolute) are equal; numeric columns only (DECISIONS 112). 23. Bids with direction upAndDown or stable: skipped with a warning (DECISIONS 113). 25. Sample G: the second RedispatchRemedialAction is recognised without units; the 9 added-row files of the 6 G cases with rd are re-baselined (DECISIONS 116). 24. Mock sign correction, supersedes 9: in the converter and the regenerated P mock, down bids get p < 0 and up bids p > 0, same |p|; results and fingerprints must stay identical, else stop (DECISIONS 114).

## 3. Execution order

WP0, WP1, WP5, WP7, WP2, WP6, WP4, WP3, WP8. (WP4 before WP3: the unit mapping first, then the redispatch class on top of it.)

## 3b. Start-up steps (before WP1)

S1. (Changed by the owner after the stop of 23 Oct 2026: `main` holds an old snapshot, most of the project was never committed.) Create the local branch `ncp-standard-alignment` from `main` and make ONE baseline commit of the whole current working tree: "Baseline: working tree before NCP alignment (includes WP0)". Never touch `main`, never push. Commit with dulwich (installed outside the repo; no `git` executable on the machine). Respect `.gitignore`; add no input data, result files, caches or file over 50 MB (list skipped files in the progress file); afterwards the status must be clean and the committed file count must equal the working tree minus ignored files, else STOP. Per-package commits are `WPn: <title>` with only that package's changes; if a commit fails, take a file-level snapshot of `src/`, `tests/`, `docs/`, `tools/` in the scratch directory first and continue.
S2. Golden baseline. Run the golden matrix (42 runs) twice on the WP0 commit and store both outputs OUTSIDE the repo (scratch directory). From now on every package's matrix run is compared with this baseline under the Next_Steps rule, and the two baseline runs give the same-code spread.
S3. Known noise to quantify. The WP0 report found that in 2 countertrade N-X cases the column `loading_pct_nx_post_pra_model_diff_pct` differs by up to 4.3e-7 of the column maximum between two runs of the SAME code. Probable cause: the column is a difference of two nearly equal loadings, so the usual ~1e-11 relative noise of the loadings is amplified relative to the column maximum. Run those 2 cases 10 times on the unchanged code and record the absolute spread (percentage points) of that column and of the two loadings it is computed from. If the absolute spread of the column is at most 1e-6 and the loadings agree to 1e-9 relative, add this to the comparison rule: for columns named `*_model_diff_pct` the tolerance is the larger of the existing tolerance and 1e-6 absolute. Record it in ASSUMPTIONS 16 and in Next_Steps section 3 rule 2. If the evidence does not hold, STOP and report.

## 4. Loop rules for EVERY work package

1. Test first. Show each new test failing, then passing.
2. Implement only what the work package says; no extras.
3. Flip the work package's section of the equivalence harness from strict xfail to must-pass.
4. Gate: full suite in parallel by file; golden matrix of 42 runs compared with the stored baseline (S2) under the comparison rule in docs/Next_Steps.md section 3 rule 2 (including the `*_model_diff_pct` rule if S3 added it); fingerprints byte-identical on the converted mock.
5. New warnings go through the existing warning mechanism and have a test each.
6. Update DECISIONS / ASSUMPTIONS entries for the work package; keep docs/ncp_standard_alignment.md rows marked done.
7. Make ONE local commit on branch `ncp-standard-alignment` (create it at the start; never push, never touch main). Commit message: `WPn: <title>`. The owner reviews and merges.
8. Append a short entry to `docs/ncp_alignment_progress.md` (work package, status, gate result, deviations, open questions) and go on to the next work package.

## 5. STOP conditions (write the entry in the progress file, then stop; do not continue to the next work package)

- A fingerprint or golden-matrix difference that is not explained by a documented noise rule.
- A full-suite failure you cannot fix inside the work package within two attempts.
- A statement of the plan or this file that proves wrong when tried (e.g. a reader cannot be built as described).
- A decision above that you cannot apply without breaking another decision.
- A change that would need a new owner decision (anything not covered in section 2).
Do not work around any of these; report them.

## 6. Work packages

### WP0 - DONE (in working tree, to be committed in step S1). Original scope kept below for reference.
### WP0 - converter tool and equivalence harness (M). No change in src/.
A. Converter (new, e.g. `tools/convert_ncp_to_standard.py`, not imported by src/). Reads the old-form mock NCP zip and writes a standard-form zip. Independent sections so later packages enable their own: (1) group limits, (2) bids, (3) redispatch, (4) GLSK, (5) countertrade, (6) other small items. No change of values, signs or units. Writes a conversion log of every element changed.
 - Strategy link: a `PowerShiftKeyStrategy` element carries `PowerShiftKeyStrategy.PowerRemedialAction` -> the RA. Never a strategy reference on the RA.
 - Redispatch: produce BOTH unit routes (decision 19). GeneratingUnit ids are CIM GeneratingUnit ids (finding C8).
 - Bids: MarketRegulationDirectionKind literals, PowerBidScheduleTimePoint with p and price, interpolationKind on the schedule. Also produce one test variant where a bid has no direction.
 - Include an AssessedElementSchedule / AssessedElementTimePoint (one variant enabled true, one false). If the alignment doc does not cover it, add a row and an OPEN item.
 - Participation factors: produce ParticipationFactorTimePoint.
B. Harness `tests/test_rao_ncp_standard_equivalence.py`: per section parse old zip and converted zip with the current parser and compare the objects (comparison rule from Next_Steps). Sections whose reader does not exist yet: strict xfail with reason "reader in WPx".
C. Sections the parser already reads in standard form (e.g. HVDC) must pass today; if one differs, stop and report.
D. Tests: converter deterministic (two runs byte-identical); converting an already standard file changes nothing.
Report: per decision 8, 19, 20, 21 one line on what the current code does today versus the decision; list official-vs-old disagreements.

### WP1 - group limits (S)
Read group limits through `RemedialActionGroupSchedule` / `RemedialActionGroupTimePoint` (`maxRegulatingUp` / `maxRegulatingDown`) as the SIS profile says (finding E3). Old non-standard form (`nc:RemedialActionGroup.maxRegulatingUp` linked directly from the time point) stays as fallback with a deprecation warning. No official sample exists: record as an assumption. Enable converter section (1); flip its harness section.

### WP5 - countertrade without `gLSKStrategy` (M)
A standard `CountertradeRemedialAction` is recognised even without `gLSKStrategy` (finding I2) and gets the default strategy proportionalForRemainingCapacity (decision 6). Old `gLSKStrategy` stays as fallback with a deprecation warning. Warn on `powerShiftKey` / `method` (18). Do not read margins (7). Enable converter section (5); flip its harness section.

### WP7 - small items (S)
HVDC missing `penaltyFactor` defaults to 1.0 (14). Other small rows of the alignment doc only as far as decisions 12, 13, 15 allow (warn only, no new behaviour). Enable converter section (6); flip its harness section.

### WP2 - bids (M)
Bid direction per decision 8 (authoritative literal, skip with warning when missing, sign cross-check warning, size |p|); apply `interpolationKind` (10); warn on `isFixed`, `minimumActivationP`, `stepIncrementP`, `totalMinimumEnergy`, `totalMaximumEnergy` when present; `PowerBidDependency` and `PeerTemporalDependency`: warn and ignore. The strict xfail "bid without direction" of the harness flips to must-pass here (skip with warning replaces today's silent "read as up"). Non-standard bid attributes of the mock (`penaltyFactor`, `minEnergyBid`, `maxEnergyBid`, `stepSizeCTRD`): move to the standard form only if that keeps the fingerprints byte-identical; otherwise stop and report. Enable converter section (2); flip its harness section.

### WP6 - contingency combination kind (M)
Read `ContingencyWithRemedialAction.combinationConstraintKind`: `included` keeps today's behaviour, `excluded` removes the RA for that contingency, `considered` warns (11). Availability schedules: warn only (15). `AssessedElementTimePoint.enabled = false`: warn only. The WP0 harness holds a strict xfail "disabled element not monitored" labelled WP9. WP9 is NOT executed in this run: it needs an owner decision. Leave that xfail in place and list it in the final report as an open decision.

### WP4 - GLSK and unit mapping (M)
Map CIM `GeneratingUnit` ids to generators (finding C8; unit costs already use `CGMES.GeneratingUnit`). Both unit routes (19). Non-generator resources: warn and drop (20). Participation factors (21). Optional `atTime` on `ParticipationFactorTimePoint`. Enable converter section (4); flip its harness section.

### WP3 - redispatch as `RedispatchRemedialAction` (L, high risk)
Recognise the standard class (finding C1, today dropped). Units come from the GLSK chain (4, 19); bids point to the RD RA (finding C3); ramp rates are not in the profile (finding C4): keep the config/old behaviour and document it. `RotatingMachineAction` form stays as fallback with a deprecation warning. Stage it: (a) reader for the standard class with units, gate; (b) bids on the RD RA, gate; (c) fallback and warnings, gate. Enable converter section (3); flip its harness section. Fingerprints must stay byte-identical.

### WP8 - fixtures and docs (S)
Regenerate `NCP_pst_fallback_scenario.zip` with the converter (all sections on), keep the legacy copy, G unchanged (16). Update docs: ncp_data_requirements, User_Guide, Spec_Coverage, specs, ASSUMPTIONS, DECISIONS, CHANGELOG, alignment doc (all rows closed or marked OPEN with the assumption taken). Final full gate.

## 7. Final report (after the last package or at a STOP)

Short: table of work packages with status and commit id; list of assumptions taken (OPEN ids); list of warnings added; anything the owner must decide; gate results. Do not push.
