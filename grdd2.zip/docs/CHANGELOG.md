# Changelog

Newest first. One short entry per task: date, what changed, tests, open items.

## 2026-10-28 - Round 28: information pages and navigation (use_cases/ only)
- use_cases/ only: cover, workflow, features and MILP model pages, a navigation bar and footer on every page, the use case list moved to use_cases.html (index.html is the cover); formulas rendered to static MathML at build time; texts in `_common/pages/`.

## 2026-10-26 - Round 13: use case 01 light-weight pages (DECISIONS 148)
- use_cases/ only: detailed report removed; summary pages with a four-part use-case box in every tab, one schematic layout for all tabs and variants, variants renumbered 1-5 (findings F15, F16).

## 2026-10-28 - Round 27: region layout and generic page fixes rolled out to all use cases (use_cases/ only)
- use_cases/ only: layout "regions" (one layout per use case, case.json key `layout` at the top) and the marker label placement (no node label, line, marker or other label under a label; leader line) on all variants of use cases 01 to 05; the line "Remaining overload in the model (slack)" and the cleanup remark in "What we change" removed (cleanup stays in the README); check_pages.py checks both and "budget". Follow-up: region names move to a free spot on their area (no marker, node or label under a name); the leader of a marker label avoids node labels where a clear path exists. Result CSVs unchanged (hash).

## 2026-10-28 - Round 26: use case pages with whole curative taps (use_cases/ only)
- use_cases/ only: use cases 01 and 05 rerun with the integer curative taps (old and new numbers in FINDINGS F33); PST tables and texts with whole taps, one-sentence note, check_summary without rounding tolerance and with a whole-taps check; intro map: Svedala injection label inside its area (three lines); base schematic: PST marker label moved off the node labels (leader line). Use cases 02 to 04 unchanged (hash).

## 2026-10-28 - Round 25: curative PST taps are integer (DECISIONS 154)
- src/rao/milp/milp_builder.py: the curative tap variables use the domain of the preventive taps (integer when `pst_taping_discrete`); two new tests, one test setup changed (it relied on a tie); 9 of 52 golden baseline folders replaced (8 tie-breaks, 1 real change: `mock__ac_single_pass__pst+rd__nx1`, objective +57.67 EUR); docs updated (Spec_Coverage R3.5, User_Guide, MILP formulation).

## 2026-10-27 - Round 24: use case 01 pilot page corrections, region order (use_cases/ only)
- use_cases/ only: variant 1 texts shortened and "budget" -> "limit" in use case 01; PST tables with taps from -> to, taps moved, penalty per tap and penalty (case.json switch "pst_detail", sums checked against the cost term); regions in the fixed order Galia ... Espheim on the use case 01 base page and the intro map (schematic.REGION_ORDER); intro map labels of the injections moved to empty spots; use cases 02-05 and all result CSVs unchanged (hash). Light checks only.

## 2026-10-27 - Round 23: intro page texts replaced, values removed (use_cases/ only)
- use_cases/intro.html, _common/intro.py, _common/check_intro.py: owner texts for what it is, who does what and the objective; no penalty or price values, no nominal-voltage row, no table notes or map caption; injection labels centred above their squares; the check script tests the texts and the removals. Light checks only.

## 2026-10-27 - Round 22: intro page texts updated (use_cases/ only)
- use_cases/intro.html, _common/intro.py, _common/check_intro.py: new texts for what it is and the objective (checked against the code), PST row with the number that have remedial actions, the two HVDC equivalent injections in the table and on the region map, region first in the link names.

## 2026-10-27 - Round 21: intro page corrected (use_cases/ only)
- use_cases/intro.html and _common/intro.py, _common/check_intro.py: proofread texts, GitHub source link, objective terms read from the code, nominal voltages, lines inside areas and tie lines, transformers by windings, HVDC links in a table and on the region map.

## 2026-10-27 - Round 20: intro page and region layout pilot (DECISIONS 153)
- use_cases/ only: `use_cases/intro.html` (the ReliCapGrid test system, numbers from the input pair) linked from every index page; layout mode "regions" (case.json key `layout`) in the shared schematic code, used by use case 01 base only (finding F32).

## 2026-10-27 - Round 19: use case 05 (all four RA types) in `use_cases/05_all/` (DECISIONS 152)
- New folder `use_cases/05_all/` and shared code in `use_cases/_common/` (nothing in `src/` or `tests/` changed): five variants with PST, redispatch, countertrade and HVDC together, findings F30, F31.

## 2026-10-27 - Round 18: use case 04 (HVDC) in `use_cases/04_hvdc/` (DECISIONS 151)
- New folder `use_cases/04_hvdc/` and shared code in `use_cases/_common/` (nothing in `src/` or `tests/` changed): three variants of the HVDC set point RA type, findings F27-F29.

## 2026-10-27 - Round 17: use case 03 (countertrade) in `use_cases/03_ct/` (DECISIONS 150)
- New folder `use_cases/03_ct/` and shared code in `use_cases/_common/` (nothing in `src/` or `tests/` changed): four variants of the countertrade RA type, findings F24-F26.

## 2026-10-27 - Round 16: use case 02 (redispatch) in `use_cases/02_rd/` (DECISIONS 149)
- New folder `use_cases/02_rd/` and shared code in `use_cases/_common/` (nothing in `src/` or `tests/` changed): five variants of the redispatch RA type with the use case 01 pages, `use_cases/README.md`, findings F18-F23.

## 2026-10-27 - Round 15: use case 01 feature tags as names (DECISIONS 148)
- use_cases/ only: the feature tag shows names from the new shared use_cases/_common/features.json (row number as tooltip, a missing row fails the build) instead of row numbers.

## 2026-10-27 - Round 14: use case 01 schematic cleanup (DECISIONS 148)
- use_cases/ and one README line: HVDC loops removed (in-substation lines), schematic at full page width with zoom and pan, minimum node distance 44 px; FINDINGS F16, F17 (dc runs differ in the last digits from run to run).

## 2026-10-26 - Round 12: use case 01 pilot: summary page, grid schematic, simple PST names (DECISIONS 148)
- New `use_cases/_common/` (shared join, schematic layout, summary pages); `results/index.html` and `results/<variant>/summary.html` for use case 01; the six PSTs are `<Area>_PST<n>` in the case data (results identical to the run with the old names). Nothing in `src/`, `tests/` or the repo config changed.

## 2026-10-26 - Round 11: use case 01 (PST) in `use_cases/01_pst/` (DECISIONS 148)
- New folder `use_cases/` (nothing in `src/` or `tests/` changed): generated zips, config, `run_case.py` (5 variants x 3 workflows), `export_before_after.py` (offline HTML report), `expected_results.md` (generated), `FINDINGS.md` (tool findings F1-F10; the N-0 PST sensitivity CSV has a wrong column name, no real inconsistency). `results/` and `work/` are git-ignored.

## 2026-10-26 - Round 10: the HVDC pair in `input/`, the old pair in `input_old/` (DECISIONS 147)
- `input/` holds `CGM_package_hvdc.zip` + `NCP_mock_hvdc.zip`; the old pair moved to `input_old/` (tracked); `HVDC_use_case/` is in `.gitignore`; new User Guide section "HVDC use case"; docs and the `mock_data` help text updated. Defaults unchanged (objective 0 with them); with `ra_types` pst+rd+hvdc and N-1 on: 158,953 (AC), 101,820 (DC). Gate unchanged.

## 2026-10-26 - Round 9: a leading "_" in NCP ids and references is ignored (DECISIONS 146)
- `ncp_parser.ncp_id` (one helper, used by `_frag` and by every `IdentifiedObject.mRID` read from an NCP file in `ncp_parser`, `glsk_resolver`, `ct_units`, `tso_name_resolver` and `run_pipeline`) removes one leading `_`; the colleague's HVDC RA files now give 2 units in 1 balanced group. New `tests/test_rao_ncp_leading_underscore.py` (29 tests, 24 of them failed before). Gate: suite, 52-run matrix, fingerprints, P byte-equality and link check unchanged.

## 2026-10-25 - Round 8: `mock_data/golden/README.md`
- New README of the golden matrix (52 runs by pattern, baselines, comparison rule, gate steps, scripts, commands); the gate and timing text moved there from `mock_data/README.md`. Docs only.

## 2026-10-25 - Round 7: link check in the gate (DECISIONS 145)
- `mock_data/tools/check_doc_links.py` is the last step of `run_gate.py` (dead link in a live file = gate fails; history files and a whitelist of 6 pairs are exempt) and covers `reference/technical/` too; the 5 old `docs/...` path strings there were re-pointed (path text only). 6 tests of the checker. No behaviour change.

## 2026-10-25 - Round 6 part B: docs reorganisation (DECISIONS 144)
- `docs/specs/` (4 specs + README), `docs/data/` (2 NCP data files), `review_report.md` and `unattended_run_report.md` to `docs/archive/`; 93 references re-pointed; `docs/README.md` index updated; new `mock_data/tools/check_doc_links.py`. Files byte-identical, no behaviour change.

## 2026-10-25 - Round 6 part A: small assessed-element fixes (DECISIONS 143)
- A link with a missing or unknown `combinationConstraintKind` is treated as absent (counting warning), not as `included`; a disabled link stays ignored (pinned by tests); `inBaseCase=false` with a `BaseCaseCurrentLimit` is scanned in the base case with a counting warning; the OPEN-33 warnings say the effect of the remedial actions is not removed.

## 2026-10-25 - Round 5: assessed-element combination switches (DECISIONS 143)
- `isCombinableWithContingency=false` is applied: the element is assessed after the contingencies with an `included` link only (none without one); a `considered` AE-contingency link is not allowed by the standard and is treated as absent (counting warning). `isCombinableWithRemedialAction` and the `AssessedElementWithRemedialAction` links stay warn-only (ASSUMPTIONS OPEN-33: not containable). ASSUMPTIONS OPEN-31 now holds the definitions of the standard. Mock and golden matrix unchanged (52 cases, 0 differences); 5 new tests, 3 adapted.

## 2026-10-24 - Round 4 step 1: pruning cases in the golden matrix (DECISIONS 142)
- Four cases `mockpruned__{ac_iterative,dc}__{pst+rd,pst+rd+countertrade}__nx1` (N-X thresholds 0.02 %) guard the dropped zero terms; the matrix has 52 runs, the 48 old cells are unchanged, `baseline.zip` grew by the four cases.

## 2026-10-24 - Round 3 step 5: zero-sensitivity terms are dropped from the N-X rows when pruning is on (DECISIONS 142)
- Only with an N-X pruning threshold above 0 (default 0: nothing changes). Countertrade mock with 0.02 %: 10.9 s to 9.2 s, 394 to 377 MB; same optimum. 5 new tests.

## 2026-10-24 - Round 3 step 6: the single-point rule is pinned
- 4 tests (a series of one point exactly at the CGM date and hour gives the run time; a point at another hour or day does not); one sentence in DECISIONS 138. No code change.

## 2026-10-24 - Round 3 step 4: the run-time fallback stays a warning (ASSUMPTIONS OPEN-32)
- Open item added to ASSUMPTIONS and to the parser check of `docs/Next_Steps.md` section 4: after the real-data run decide whether a CGM without scenario time or outside every NCP series should stop with an error. No code change.

## 2026-10-24 - Round 3 step 3: tolerance for last_solve_* columns and the sixth countertrade case (DECISIONS 140)
- `last_solve_*` columns: absolute tolerance 1e-6 in `compare_runs.py` and in rule 2 of `docs/Next_Steps.md`; `mock__ac_iterative__pst+rd+countertrade__nx1` joins the matrix (48 runs), `baseline.zip` 4.95 MB. 2 new tests.

## 2026-10-24 - Round 3 step 2: isCombinableWith* stays warn-only
- The warning now says that the switch is not applied and why (meaning not settled, OPEN-31); OPEN-31 lists the two candidate readings and waits for the standard / the data provider. No behaviour change.

## 2026-10-24 - Round 2 step 2: assessed-element switches and links are applied (DECISIONS 141)
- normalEnabled / enabled at the run time (element not monitored), inBaseCase (no N-0 row), links to contingencies (included / excluded) are applied; isCombinableWith* stay warn-only (open). Every element switched off or restricted is logged. Existing cases unchanged. 24 new tests, the WP9 xfail test passes.

## 2026-10-24 - Round 2 step 3: golden matrix cases with countertrade on (DECISIONS 140)
- Five new cases `mock__*__pst+rd+countertrade__nx*` (the matrix has 47 runs); the sixth, ac_iterative with N-X, does not reproduce within rule 2 (solver tolerance in a diagnostic column) and is left out. New baseline entries only (baseline.zip 4.3 MB); the 42 old cells unchanged.

## 2026-10-24 - Round 2 step 1: the run time comes from the CGM (DECISIONS 138)
- The CGM scenario time (date and hour) selects every time-dependent NCP value (bids, PATL, participation factors, unit costs, group limits) when the NCP has time points on its date; otherwise the start hour 1030Z and the per-reader fallbacks as before (logged). Existing cases unchanged. 16 new tests.

## 2026-10-24 - Performance item 6: CGM EQ files streamed instead of parsed with rdflib (DECISIONS 137)
- `eq_stream.stream_eq` (xml.etree, standard library) answers the calls of the three EQ map readers; rdflib is the fall-back for anything it cannot answer exactly. Mock pst+rd run 10.7 s to 6.8 s, with countertrade 15.0 s to 11.0 s. 15 new tests; matrix and fingerprints unchanged.

## 2026-10-24 - Performance item 5: N-X results export reads the solved values once (DECISIONS 136)
- `_SolvedValues` replaces the Pyomo evaluation per row in `export_nx_loadings_csv` / `export_nx_scanned_elements_csv`; same numbers (compared with ==). 3000 rows x 600 units 4.5 s to 0.25 s; countertrade mock run 15.9 s to 15.1 s. 4 new tests; matrix and fingerprints unchanged.

## 2026-10-24 - Performance item 4: every input file is parsed once per run (DECISIONS 135)
- `ncp_parser.graph_cache()` around the pipeline run keeps the NCP graphs (not the big EQ graphs; the countertrade control-area units are remembered from the first EQ parse). Mock run with countertrade 20.8 s to 16.0 s, pst+rd 11.4 s to 11.0 s. 5 new tests; matrix and fingerprints unchanged.

## 2026-10-24 - Performance item 3: N-0 sensitivity guard groups by branch (DECISIONS 134)
- `resolve_n0` groups the fresh sets by branch once instead of rescanning them per branch: 129000 entries 12.7 s to 0.02 s. 8 new tests; matrix and fingerprints unchanged.

## 2026-10-24 - Performance item 2: curative redispatch rows by contingency and unit (DECISIONS 133)
- The net injection, balance and maxima rows of the curative RD block use pairs grouped once by contingency and bids grouped once by unit; same terms in the same order. Generated set with 480 contingencies: model build 19.0 s to 1.7 s. 2 new tests; matrix and fingerprints unchanged.

## 2026-10-24 - Performance item 1: N-X sensitivities in a numpy table (DECISIONS 132)
- `SensitivityTable` replaces the dict of tuples per contingency (AC mode); same keys, values and order; the loading and magnitude filters share the array; the quadratic duplicate counting is linear. Memory and time on the sensitivity stage: 18 times and 20 times less on a synthetic set; the mock run is unchanged. 18 new tests, matrix and fingerprints unchanged.

## 2026-10-24 - Review fixes, stages 3 and 4: curative Pmin/Pmax stays as specified, document corrections, exact counts in the golden comparison (DECISIONS 130, 131)
- Stage 3: no code change. The spec (R7, CORNET-4614) requires one row pair per unit over the maxima of all contingencies and accepts the net-form example that per-contingency rows would reject; DECISIONS 130 records the quote and the open question. DECISIONS 73 is corrected ("per contingency" was wrong for the curative rows).
- Stage 4: DECISIONS 20, 31, 37 marked superseded with today's behaviour; old paths and the "shipped mock is the plain converter output" statement corrected (104, 117, 118, 125, 126); the 7 broken line breaks in DECISIONS 112 and 115 repaired (a letter lost where an escape was read; the review counted them as CR bytes, the file had CR LF pairs inside the entries); the split ASSUMPTIONS sentence rejoined; the HVDC `penalty_factor` comment in `rao_config.default.yaml` and `rao_config.yaml` now says missing = 1.0 with a warning. `mock_data/golden/compare_runs.py` compares integer cells exactly; run on the latest 42-run matrix against both baselines it found nothing (0 differences). 4 new tests (`tests/test_rao_golden_compare.py`).

## 2026-10-24 - Review fixes, stage 2: bid time points by date and time (DECISIONS 129)
- A bid schedule with points on several days is read by date and time (run day = the earliest day of the file's bid points unless a run date is given); a schedule on one day is read as before. Mocks and samples unchanged. 8 new tests.

## 2026-10-24 - Review fixes, stage 1: warnings, bid lookup by rdf:ID, messages (DECISIONS 128)
- Counting warnings for shift keys of countertrade, contingencies without `normalMustStudy`, non-restrictive dependencies, disabled grid state alterations, standard RD RAs with old actions, assessed-element switches and links (OPEN-31 added); the countertrade IGNORED line names its real reason; no false "spec violation" for the assessed-element link classes; bids and bid-route distributions are found by rdf:ID. No result changes. 13 new tests.

## 2026-10-24 - mock_data/, countertrade bids in P, renamed zips, input/ and cleanup (DECISIONS 126, 127)
- New top-level `mock_data/`: paths, converter, `standard`, `countertrade_p`, `ct_mock`, `hvdc_mock`, `ncp_dataset`, `zipio`, command line `python -m mock_data` (standard, check, variant, dataset-variant, shared-bid, install-input, inventory-p), `golden/` (matrix, comparison, suite, fingerprints, gate, `baseline.zip`), `tools/` (inventory, commit helper). `tools/` removed; `tests/` has no builder modules any more; 11 test files import `from mock_data import ...`; `pytest.ini` has `pythonpath = .`. No behaviour change, no generated zip changed by a byte (gate after each step).
- P (the standard-form mock) carries 8 countertrade RAs (a preventive and a curative one per region, Espheim with three bids per direction at 40 / 70 / 110 EUR/MW, the curative RAs linked to all contingencies of the region); the other mocks start from the base without them, so the `ct__*`, `hvdc__*`, `cthvdc__*` matrix cases are unchanged. With the default `ra_types` every run on P logs 8 `nc:CountertradeRemedialAction ... is not used and is IGNORED` lines. New `tests/test_rao_p_countertrade.py` (14 tests), `tests/test_rao_mock_data_cli.py` (3).
- Zips renamed (`NCP_mock_standard.zip`, `NCP_mock_legacy.zip`, `NCP_sample_generic_2_4.zip`); `input/` = `CGM_package.zip` + `NCP_mock_standard.zip`; `NCP_mock_cleaned.zip` deleted.
- Docs: alignment documents and the housekeeping inventory moved to `docs/archive/`, 7 release plans and `Code_Review_Report.md` to `reference/archive/`, generated P inventory deleted, open items into ASSUMPTIONS, README files, User_Guide, copilot-instructions, Spec_Coverage header updated.
- Tests: 55 files, 2085 passed, 6 skipped, 1 xfailed (WP9); matrix 0 differences against both baselines; fingerprints identical.

## 2026-10-26 - Shared-bid redispatch: case D in Espheim (final)
- DECISIONS 124 (warning on keys only) and 125 (D moved from Svedala to Espheim). `D_espheim` replaces the Svedala D in `tests/ncp_dataset.py`; all four shared RAs (two preventive downs, two curative downs with the kept curative ups as partners) are activated in the full run. Tests in `tests/test_rao_rd_shared_bid.py` (54); the Svedala D stays as model-level example. No change in `src/`. The shared-bid topic is closed.

## 2026-10-25 - Shared-bid redispatch, round 2: case D and the no-net-movement warning
- Owner decisions recorded (DECISIONS 119 to 123): surplus above the first unit limit accepted, one price per bid, curative B and C dropped (A, A_strategy, B_preventive, C_preventive kept), case D, data warning.
- Code: `glsk_resolver.warn_curative_no_net_movement`, called by `run_pipeline` after the GLSK resolution (N-X on): a warning per contingency in which the curative RD RAs have only one direction or one common key. Behaviour of the model unchanged.
- Test data and tests: case D in `tests/ncp_dataset.py` (`build_shared_bid_ncp(..., "D", overrides=...)`), scope-of-balance tests, D model tests, warning tests in `tests/test_rao_rd_shared_bid.py` (54 tests). D is read with its factors but not activated in the grid (progress file).

## 2026-10-24 - Shared-bid redispatch use cases (A, B, C)
- Test data: `build_shared_bid_ncp` in `tests/ncp_dataset.py` (variants A, A_strategy, B, C and the preventive twins B_preventive, C_preventive on the standard-form P; P, baselines and matrix unchanged). Tests: `tests/test_rao_rd_shared_bid.py` (characterisation of the split, the cost and the generator limit; 39 tests). No change in `src/`; no defect found.
- Open (owner): behaviour at a generator limit, a curative pair on one key cannot move, the preventive twins (progress file, last section; DECISIONS 118).

## 2026-10-23 - NCP standard form, work packages 1 to 8 (WP1, WP5, WP7, WP2, WP6, WP4, WP3, WP8)
- Readers: group limits through the schedule chain (WP1); countertrade without a strategy attribute, `powerShiftKey`/`method` warned (WP5); HVDC penalty default 1.0 and warnings for per-RA caps, bid dependencies, availability schedules (WP7); bid direction literal (skip with a warning when missing or not up/down), sign cross-check, `interpolationKind`, unread attributes (WP2); `combinationConstraintKind` (WP6); shift keys with CIM generating units, both unit routes, non-generator resources dropped (WP4); redispatch as `RedispatchRemedialAction` with units from the shift keys (WP3). Old forms are fallbacks with one deprecation warning per file. DECISIONS 106-117.
- Comparison rule: `*_model_diff_pct` tolerance 1e-6 absolute (ASSUMPTIONS 16) and a dust floor 1e-9 absolute for numeric columns (DECISIONS 112).
- Fixtures: `NCP_pst_fallback_scenario.zip` regenerated in the standard form (bid signs corrected, four non-standard bid attributes dropped), legacy copy `NCP_pst_fallback_scenario_legacy.zip`; G unchanged. Converter option `correct_bid_signs`.
- Tests: suite 1888 -> see `archive/ncp_alignment_progress.md` for the final numbers; golden matrix of the P cases unchanged against the baselines; fingerprints byte-identical. New test files: `test_rao_ncp_combination_kind.py`, `test_rao_glsk_standard.py`, `test_rao_redispatch_standard.py`.
- Open: WP9 (disabled assessed element not monitored) needs an owner decision; the mock builders still write old forms; the old forms are removed in the next release.

## 2026-10-23 - NCP standard form, work package 3: redispatch as RedispatchRemedialAction
- The RD reader recognises the standard class: units come from the shift keys (bid route and strategy route), mapped to generators; the old `RotatingMachineAction` form is still read with a deprecation warning. Bids on the RA are read as before. DECISIONS 115, 116.
- Sample G: the second redispatch RA of Belgovia is now recognised, still without units (its shift key resolves nothing at 1030Z): `glsk_resolved.csv` gets 1 row and `rd_cra_availability.csv` 12 rows in the 6 G cases with RD. Nothing else changes.

## 2026-10-23 â€” NCP standard form, work package 0: converter and equivalence harness (no parser change)
- New `tools/convert_ncp_to_standard.py` (not imported by `src/`): rewrites the old-form mock NCP zip into the standard form (groups, bids, redispatch with both unit routes, glsk with GeneratingUnit ids, countertrade, other), deterministic, values and signs unchanged, every change in a CSV log. New `tests/test_rao_ncp_standard_equivalence.py`: per section the old and the converted zip are parsed with the current parser and compared; sections without a reader are strict xfail (readers in WP1 to WP5, WP9). HVDC, the dependency predicate, the bid literals and the PST actions pass today.
- Docs: `DECISIONS.md` 85-105 (owner decisions of 23 Oct 2026), `ASSUMPTIONS.md` (bid direction, countertrade default, shift key rules), `archive/ncp_standard_alignment.md` (decision column, official 2.5 sample against old samples and PDFs, K5 assessed element schedule, OPEN-29/30, corrections). The official sample's licence (CC BY-SA 4.0 against CC BY 4.0 in its headers) is unclear, so nothing is copied; structure only, own ids.
- Tests: 22 passed + 6 xfailed new; with a converter that does nothing 15 of them fail. Suite 1888 -> 1910 passed, 6 skipped, 6 xfailed. Golden matrix (42 runs, run twice on unchanged code): 40 cases equal under the Next_Steps rule, 2 countertrade N-X cases differ in `loading_pct_nx_post_pra_model_diff_pct` only, also between two serial runs (run-to-run noise, ASSUMPTIONS 16). Fingerprints unchanged.
- Open: the bid sign (OPEN-30), the disabled assessed element (OPEN-29), the group limit chain has no official sample.

## 2026-10-22 â€” Run-to-run variation located; scaled comparison rule (ASSUMPTIONS 16, docs only)
- `ASSUMPTIONS.md` 16: the run-to-run variation comes from OpenLoadFlow (last bits of the sensitivities for the mock's double-line outages CO3/CO4, AC and DC, also serially with a fixed hash seed and within one process; pypowsybl alone reproduces it); about 1e-11 relative in the results, discrete results unaffected (100 runs).
- `Next_Steps.md` section 3 rule 2: a number is equal within 1e-9 relative or within 1e-9 of its column's largest absolute value; text, statuses, tap and iteration counts exactly equal; `seconds_*` columns and the run log not compared; the objective (1e-9 relative) and taps and MW (1e-6) rules unchanged. No code or test change.

## 2026-10-22 â€” Out-of-reach curative PST range recorded (ASSUMPTIONS 17, docs only)
- `ASSUMPTIONS.md` 17: a non-empty curative PST range that no allowed tap can reach (single PST, not in a group) makes the MILP infeasible; curative taps are not limited to the hardware range. Decided not to fix; to count on real data. No code or test change.

## 2026-10-22 â€” Empty curative PST range ignored with a warning (DECISIONS 84)
- `build_pst_tap_bounds_curative`: a curative range whose lower bound is above its upper bound gives a warning naming the PST and both bounds and is ignored; the PST falls back to its operating range like the other unusable curative ranges. Lower = upper stays valid (PST fixed). Before, Pyomo refused to build the curative tap-bound row (`InvalidConstraintError`) and the run stopped. Other paths checked, no change: operating range = CGM hardware range; preventive range and curative group check already exclude empty ranges.
- Tests: C16 changed to the new behaviour (failed on the old code, passes now); new variant `fixed_curative_tap_range` and tests for lower = upper (accepted, no warning) and an `ac_iterative` run of the valid dataset with the inverted range (N-X on, all four RA types: no stop, Aac's curative rows carry its operating range). Mutations: check removed (kills the C16 and run tests), `>=` for `>` (kills the lower = upper test). Docs: `ncp_data_requirements.md` (7.3, 7.4, attribute row, F19), `ncp_dataset_coverage.md` (C16, section 5, counts).
- Gates: full suite (48 files, parallel by file) 1888 passed, 6 skipped. Golden matrix (42 runs: mock, generic, CT mock, HVDC mock, three modes, N-X off and on): no warning of the new check in any run; the 24 N-X-off runs differ only in the wall-clock `seconds_*` columns (otherwise byte-identical); N-X-on runs equal within 1e-9 relative apart from those columns, except `results_nx_loadings.csv` of `mock_ac_iterative_pst+rd_1` (max 1.2e-3 relative, gone on a rerun of the new code) and `mock_ac_single_pass_rd_1` (1.1e-8, also between two runs of the old code): run-to-run noise under parallel load, not this change. Fingerprints unchanged. Open: a non-empty curative range that no tap reachable within the curative tap cap fits (single PST, not in a group) still gives an infeasible MILP (recorded as ASSUMPTIONS 17).

## 2026-10-21 â€” NCP test dataset; two NCP input fixes (DECISIONS 81-83)
- `parse_psts`: a zero or unreadable `GridStateAlteration.timePerStage` is left unset with a warning naming the PST (as a missing one: no curative availability); `compute_pst_cra_availability` also skips a time per stage of 0 or less. Before, a division by zero stopped the run (D81).
- New `ncp_parser.warn_unmatched_ra_references`, called per TSO in `run_pipeline.main`: one warning per contingency link (RA file) and per bid (SIS file) whose RA reference is the mRID of no RA of the TSO's RA file, e.g. an RA whose rdf:ID differs from its mRID; matching unchanged, no warning on the fixtures (D82). The PST range direction (`up` / `upAndDown` upper, `down` lower) is recorded as intended (D83).
- Generated NCP test dataset `tests/ncp_dataset.py` (mock data on `CGM_package.zip`, built from the HVDC and countertrade mocks plus text edits of the base package, data rules asserted by the generator) and `docs/ncp_dataset_coverage.md` (102 rows: 2 fixes, 47 valid-package rows, 53 invalid / warning variants; what the NCP cannot produce; F1-F45 closed out). The valid package runs in `ac_iterative`, `ac_single_pass` and `dc` with `pst+rd+hvdc+countertrade` and N-X on; every RA type acts. New tests `test_rao_ncp_dataset_valid.py` (46 functions, 58 items) and `test_rao_ncp_dataset_variants.py` (57, 68); each fails under a mutation of the behaviour it covers (104 mutations). `ncp_data_requirements.md` (F-list status, PST range note, the two fixes), README test layout.
- Gates: targeted tests (parser, CRA preprocessing, loader, HVDC and CT parsers, `run_pipeline`, N-X builder with the model fingerprints, frozen imports, text encoding) and the new tests: 566 passed. Golden matrix (N-X on, `pst+rd`, three modes, both fixtures): 156 of 171 files byte-identical, the others equal within 1e-9 relative apart from the wall-clock `seconds_*` columns; fingerprints unchanged. Open: a curative tap range with its lower bound above its upper bound is passed on unchecked (coverage file section 5).

## 2026-10-20 â€” Docs refresh and a scanned-row test
- File:line citations re-mapped and verified against the code in `Data_Validation_Reference.md` (CT rows added to 9b), `MILP_Mathematical_Formulation.md` (outdated statements corrected, countertrade section 8) and `Spec_Coverage.md` (stale citations with their own symbol mapped to its definition; the rest listed as unverifiable); new test `test_rao_scanned_without_preventive.py` (hard N-0 scanned row with only curative RD, N-X on). Suite: 1759 -> 1760 passed.
- `Spec_Coverage.md`: the stale citations without their own symbol now name file and symbol (no line numbers); `MILP_Mathematical_Formulation.md`: one price per bid, the curative PST linkage factor also in the scanned row, the curative PST group rules as in the code.

## 2026-10-20 â€” Countertrade: CT-only units in results_generating_units.csv (DECISIONS 80, C11.5)
- With a usable countertrade RA, every countertrade unit in no RD glsk gets a row after the RD units (RD columns 0, `ct_volume_net_mw` = its CT part, production = initial + CT, TSO of its RA); the CT column sums to the net CT volume of each zone. Without countertrade the file is unchanged. Tests (GA-G2 and GA-G3 without RD in `ac_iterative`) fail when the CT-only rows are dropped or carry the wrong sign. Suite: 1757 -> 1759 passed.

## 2026-10-20 â€” Countertrade: unit file with RD and CT apart; CT and HVDC acting together (DECISIONS 79, C11.5)
- `results_generating_units.csv` with a usable countertrade RA: `result_production_mw` is the final dispatch (initial + RD + CT) again, the RD columns stay the RD part, and a new column `ct_volume_net_mw` (after the RD columns) holds the CT part; both parts from the cumulative bid volumes. Without countertrade the file is unchanged. Checked for the same mixing, no change needed: `results_preventive_rd.csv`, the RA-count, group and lead-time files (RD bids only, D76), `results_net_positions.csv` (RD and CT apart), the summary (RD and CT rows apart), the applied set points (RD + CT); `results_iteration_history.csv` and the iteration log count CT MW in the `rd` MW columns by design (C8.2), with the CT volume shown on the log line.
- New mock scenario `ct_mock.build_ct_and_hvdc_mock_ncp` (PATL 100 A on the Belgovia half of GA_BO4, 175 A on TieLine_SD-EH1, penalty factors 0.05 for CT and 0.1 for HVDC): with `pst+rd+hvdc+countertrade` in `ac_iterative` CT and HVDC both act; tests for the HVDC pair balance outside the RD + CT balance, separate cost terms, the summary rows against the result files and the AC check of both branches.
- Tests: each new assertion fails under a mutation (production without CT, RD column with CT, CT column with RD, HVDC in the global balance, CT terms dropped, HVDC pair unbalanced). Suite: 1753 -> 1757 passed. Golden matrix: no difference above 1e-9 relative, N-X-off runs byte-identical.

## 2026-10-20 â€” Countertrade review fixes (DECISIONS 76, 77; countertrade_ra_specs.md C3.7, C5.2, C13)
- `results_generating_units.csv` in a run with countertrade: the RD columns are summed from the cumulative RD bid volumes (glsk x net volume); before, in `ac_iterative` the build baseline carried the countertrade moves of earlier iterations into the RD column of a shared unit (-67.9 MW on BO-G1 with RD at 0). Runs without countertrade unchanged.
- `countertrade_glsk_resolved.csv` only with a usable countertrade RA (C14 row 17); before, a header-only file was written (also for `rd+countertrade` on the repo NCP).
- C5.2 limit log: from the final combined dispatch (original set point + cumulative RD and CT movement of every bid), so a unit that reached its limit in an earlier iteration is logged. C3.7: one log line per RA and direction for an empty direction (the weights' warning; the MILP adds none for a countertrade bid with empty weights; RD lines unchanged). A negative countertrade weight names the bid, not an "RD remedial action".
- Tests: the mock zip is byte-identical between builds (fixed entry time stamps); new behavioural tests (fixed weights while RD moves a shared unit, curative R4 gate row, one-sided unbounded Pmin, DC after-state and DC relief in `dc`, curative countertrade in `ac_iterative` and `dc`, two CT RAs in one zone, two bids of one RA, the dropped RA, CT in scanned N-0 and N-X PATL/TATL/scanned rows, criterion 4, RD cost unchanged next to CT); weak assertions replaced by values from the model (no mock-tuned numbers); `ac_single_pass` tolerance = the measured RD-only single-pass residual (1.42 A) + 0.1 A. Each new test fails under a mutation of the behaviour it covers. Suite: 1730 -> 1753 passed.
- Docs: `Data_Validation_Reference.md` (ra_types row, section 9b levels and tests, the clean-exit message), `Spec_Coverage.md` 4d rows 16-22, the latent `linked_xne_mrids` gap (C13, DECISIONS 69). The open item of the entry below (the old clean-exit message) is fixed. `probe_nx.py` (empty, not part of the work) removed.

## 2026-10-20 â€” Countertrade remedial actions (`ra_types: countertrade`, docs/countertrade_ra_specs.md, DECISIONS 69-78)
- New RA type `countertrade`: a bid per bidding zone whose volume is spread over the zone's generators by remaining-capacity weights (up: Pmax - PROD, down: PROD - Pmin, normalised after the exclusion), preventive and curative, in `ac_iterative`, `ac_single_pass` and `dc`, with or without `rd`. The weights are computed once from the original set points; CT is in the global and per-contingency balance with RD; hard Pmin/Pmax rows on the RD + CT total; one-sided on/off rows for CT; cost = penaltyFactor x `penalty_reference_ct_pra` / `_cra` x volume plus bid price and activation cost (curative: maximum over the contingencies and the reservation price). Without `countertrade` nothing changes (golden matrix of 9 runs, 205 CSV files: 0 differences; fingerprints unchanged).
- Code: `data_model` (`CtRa`, `CtZoneUnit`, `RDUnit.countertrade`); new `pre_milp/ct_units.py` (CT RA and bid parsing, zone to units from the Organisation profile and the EQ files, weights per RA and direction), `pre_milp/ct_weights.py`, `post_milp/ct_results_export.py`; `ncp_parser` (`parse_power_bids` shared with RD, keywords to leave CT out of the "ignored" warning); `milp_builder` (`_participation_of_bid` replaces the 16 glsk-by-RA lookups, `CtMilpInputs`, CT rows, named CT terms, curative CT cost); loops (`build_model_at_state`, `run_single_pass`, `run_dc_pass` take `ct_inputs`; the iteration log line shows the CT volume); `run_pipeline` (wiring, `validate_ct_penalty_references`, workflow label); GUI toggle, two reference inputs, result groups; yaml keys `penalty_reference_ct_pra` / `_cra`.
- Outputs (only with `countertrade`): `results_countertrade.csv`, `results_curative_countertrade.csv`, `countertrade_glsk_resolved.csv`, `ct_cra_availability.csv`, `results_net_positions.csv`, `results_zone_exchange.csv`, summary rows `sum_ct_volume_upward_mw`, `sum_ct_volume_downward_mw`, `sum_pra_penalty_cost_ct_eur`, `sum_cra_penalty_cost_ct_eur`, `sum_cra_reservation_cost_ct_eur`, `sum_ct_cost_eur` (in the objective residual); registry 32 -> 38 names. The RD result files stay RD-only.
- Behaviour to know: the input data has no valid CT RA (the fixture RA uses `powerShiftKey` / `generatorPmax` and has no volumes): it is ignored with a warning, the feature is tested on the generated mock `tests/ct_mock.py`; the `gLSKStrategy` predicate names are an implementation choice (unconfirmed, C13); one `ac_single_pass` leaves a linearisation residual (about a tenth of the relief on the mock), `ac_iterative` converges; a `dc` run whose DC model sees no overload leaves the set points; curative CT is never applied to the network; bid dependencies are not implemented (RD neither).
- Tests: new `test_rao_ct_weights.py` (14), `_parser.py` (30), `_mock.py` (28), `test_rao_milp_builder_ct.py` (38), `test_rao_ct_pipeline.py` (23), `_modes.py` (24), `_config.py` (32), `_outputs.py` (21); changed on purpose: the `ra_types` cases of `test_rao_run_pipeline.py` and `_end_to_end.py` (`countertrade` is allowed now). CT goldens (11 runs: preventive, curative and coexistence in the three modes) are repeatable. Suite: 1523 -> 1730 passed.
- Docs: `countertrade_ra_specs.md` (implemented), `DECISIONS.md` 69-78, `Spec_Coverage.md` (R6.5-R6.7, section 4d), `User_Guide.md`, `calculation_mode_specs.md`, `reference/technical` (formulation scope, overview), `Data_Validation_Reference.md` (row for the ignored RAs, section 9b).
- Open: unconfirmed profile names (C13); the "Neither PST, RD, HVDC, nor N-X has anything to optimise" row of `Data_Validation_Reference.md` still quotes the old message (it now names countertrade); the file:line citations of that file are older than this entry.

## 2026-10-19 â€” HVDC review fixes (DECISIONS 68, hvdc_ra_specs.md H3.4)
- New rule H3.4: a CGM set point outside the resolved range widens the range to include it, with a warning naming the unit, its EI and both bounds (before, the hard bounds forced a paid move without any overload, or made the model infeasible). Deviation H14 row 14, Spec_Coverage 4c, D68.
- `hvdc_units.validate_hvdc_structure`: a `balanced` group without any HVDC unit is skipped with a log line (it stopped hvdc runs before); the unit-in-two-groups check runs over all HVDC groups before a group is dropped for an unavailable unit.
- `ncp_parser.parse_hvdc_units`: only the ranges of HVDC actions are read and warned about (no spurious "direction none" warnings for remedial-action-scheme actions on NCP_generic).
- GUI: `results_curative_hvdc.csv` is grouped with the other curative result files.
- Tests: H3.4 (limits, MILP preventive and curative, end to end), the two structure fixes, the range warnings on NCP_generic, the GUI grouping; end-to-end tests for the three breaks the review found uncaught (N-X HVDC sensitivities refreshed every iteration, outage-element gate wired from the pipeline, initial N-X zero units wired in `ac_single_pass` and `dc`); the pypowsybl sign of EI minP/maxP and the slack behaviour of the EI set points pinned by tests. The HVDC test files read the result files with the shared text-encoding constant. Suite: 1501 -> 1523 passed; golden matrix without `hvdc` (24 runs): 0 diffs; deliberate breaks of the fixes and the four breaks the review found uncaught: all caught.
- Docs: H3.1/H13.2/User Guide/D61 "most restrictive range wins"; H6.6 and User Guide: curative post-contingency value = AC N-X current at the applied state + linearised effect; D63 (connection is a startup error, not a gate); `dc_mode_specs.md` D3.4 names the variable and the function; H12 ("unbalanced data" removed, P0 warning added); `Data_Validation_Reference.md` file:line citations of `run_pipeline.py`, `milp_builder.py` and `ncp_parser.py` remapped to the current code and the configuration rows corrected (they were 4 lines off), the HVDC rows updated, two rows added.
- Decided after the review: EquivalentInjection minP/maxP stay in generation sign as given (assumption per the CIM definition and pypowsybl's import, to be verified on real HVDC data, pinned by test; H3.2, D61). The builder's "nothing to optimise" message names the four inputs (pst, rd, hvdc, nx) and no longer says "all three absent".

## 2026-10-19 â€” HVDC remedial actions (`ra_types: hvdc`, docs/hvdc_ra_specs.md, DECISIONS 60-67)
- New RA type `hvdc`: two generating-like EquivalentInjection units per link in a `balanced` RemedialActionGroup, preventive and curative, in `ac_iterative`, `ac_single_pass` and `dc`. Balance dg1 + dg2 = 0 (formula 3.61 corrected), range = the most restrictive `RangeConstraint` capped by the EI technical limits, exact curative bound per contingency, cost = penaltyFactor x reference x change (curative: x max over contingencies). Without `hvdc` nothing changes (golden matrix of 21 combinations: 0 diffs).
- Code: `data_model` (`HvdcUnit`, `HvdcGroup`, `HvdcRange`); new `pre_milp/hvdc_units.py` (structure checks, limits, solved-network check, EQ description warning); `ncp_parser` (`parse_hvdc_units`, `parse_balanced_ra_groups`, both dependency predicates for balanced and restrictive groups); `n0_sensitivity` / `nx_sensitivity` / `sensitivity_checks` (EI injection sensitivities, silent-zero guard, last-valid store key `hvdc`); `milp_builder` (`HvdcMilpInputs`, `_add_hvdc_block`, `_add_curative_hvdc_block`, HVDC term in the N-0, scanned and N-X rows, objective terms `hvdc_pra_penalty_cost` / `hvdc_cra_penalty_cost`); loops (`ac_convergence_loop`, `single_pass`, `dc_pass`, `post_ra_congestion_check`: write-back through the RD `target_p` dictionary, refresh, criteria 1 and 3, fallback ramp); `run_pipeline` (preprocessing, `penalty_reference_hvdc_pra/cra`, GUI toggle and fields).
- Outputs: `results_hvdc.csv`, `results_curative_hvdc.csv`, `hvdc_cra_availability.csv` (TSO column, floats; reasons: reaction time, outage element, zero sensitivity, group atomicity), summary rows `sum_hvdc_penalty_cost_eur`, `sum_pra_penalty_cost_hvdc_eur`, `sum_cra_penalty_cost_hvdc_eur` (only with `hvdc`, in the objective residual), HVDC terms in the "predicted after PRA/CRA" columns of the N-X exports, HVDC column in the inventory table (only with `hvdc`), registry entries (29 -> 32 names), GUI results group.
- Behaviour to know: factor 0 = non-costly (the pair can end at the edge of its range; set a small factor above 0 to limit use); HVDC MW is in `sum_abs_rd_change_mw` / `max_abs_rd_change_mw` and criteria 1 and 3; a `dc` run whose DC model sees no overload leaves the set points; the curative post-contingency result is the MILP prediction (no AC N-X re-check); lossless mismatch shows in the final AC check; HVDC link contingencies act only through "the EI is an outage element".
- Documented exception to "outputs unchanged without `hvdc`": the predicate fix (restrictive groups with `DependingRemedialActionGroup` are now found); fixtures show no diff. Also fixed: a hard scanned N-0 row without any variable (constant left side) now builds (it stopped Pyomo before).
- Tests: 6 new files (`test_rao_hvdc_parser.py` 48, `_sensitivity.py` 35, `_milp.py` 81, `_pipeline.py` 72, `_loop.py` 11, `_gui_config.py` 6) and the generated mock `tests/hvdc_mock.py` (mock NCP: Injection_SD_EH1 / Injection_SD_BO3 pair on TieLine_SD-EH1, preventive and curative variants); changed: ra_types cases in `test_rao_run_pipeline.py` and `_end_to_end.py`. Each behaviour checked by deliberate breaks in a scratch copy; the independent review of 19 Oct 2026 found 3 breaks no test caught (N-X HVDC sensitivities not refreshed in the loop, outage elements not passed from the pipeline, initial N-X zero units not passed to the state): tests added, see the entry above. Suite: 1233 -> 1501 passed.
- Docs: `DECISIONS.md` 43 (updated), 60-67; `Spec_Coverage.md` (R6.1-R6.4, section 4a/4b, H14 deviations); `User_Guide.md`; `Data_Validation_Reference.md` (section 9a, ra_types row); `dc_mode_specs.md`, `calculation_mode_specs.md` ("HVDC out of scope" removed); `README.md` counts; `rao_config*.yaml` comments; `hvdc_ra_specs.md` status "implemented".
- Open: `Data_Validation_Reference.md` file:line citations of `run_pipeline.py`, `milp_builder.py` and `ncp_parser.py` rows written before this entry moved with the new code and were not re-checked; HVDC link contingencies (converters, DC line) are not modelled; countertrade is still not supported.
## 2026-10-18 â€” text encoding: UTF-8 without BOM, explicit everywhere (DECISIONS 59)
- New `src/rao/text_encoding.py`: `TEXT_ENCODING = "utf-8"` and `not_utf8_message`. Used at every text read and write of the pipeline (29 CSV writers in 10 modules, `run_log.txt`, the YAML config read), the GUI (YAML, settings JSON, temp config, results CSV reads; loaded by file path) and the tests (about 130 calls in 23 files; the `errors="replace"/"ignore"` workarounds removed).
- Was: every CSV writer and the config read used the platform default (cp1252 on Windows): `lf_basecase.csv` held the fixture's `HÃ„LLAN`/`HÃ„STSJÃ–` names in cp1252, and a name outside cp1252 (Cyrillic, CJK) would have stopped the run with a `UnicodeEncodeError`.
- GUI pipeline subprocess: the child gets `PYTHONIOENCODING=utf-8` and the pipe is decoded as UTF-8 (both used the locale codepage).
- A config YAML that is not valid UTF-8 stops with a message naming the file (cp1252 was decoded silently before). There are no user-supplied CSV inputs; input XML (CGM, NCP) is unchanged.
- Tests: new `test_rao_text_encoding.py` (7): AST scan of `src/` for text-file calls without an encoding (open, Path.open/read_text/write_text, read_csv/to_csv, log file handlers, text-mode subprocess pipes; allow-list with reasons), no literal encoding in the RAO code, no BOM, config not UTF-8, a pipeline run with line names ending in "Ã© Ã¼ Ã¸ Ã¥ Ð– ç·š" (every written file strict UTF-8, no BOM, names intact), the GUI pipe without the shell's encoding variables. Each checked by breaking the code in a scratch copy (5 breaks, all detected).
- Golden outputs: `ac_iterative` and `ac_single_pass`, mock and generic, N-X off and on, and one `dc` run: identical at rel 1e-6 to the outputs before this change; only `lf_basecase.csv` changed its bytes, by the encoding alone (cp1252 -> UTF-8 of the fixture's own accented transformer names; the text is identical).
- Docs: `DECISIONS.md` 59, `User_Guide.md` (Excel: Data > From Text/CSV, UTF-8; config files UTF-8).
- Suite: 1226 -> 1233 passed.
- Open: the platform layer outside the RAO app (`src/core/logger.py`, the PowerFactory request pipes and CSV reads in `src/core/pf/`) is unchanged and on the allow-list (not runnable here; `src/core` cannot import the RAO constant without reversing the dependency).

## 2026-10-18 â€” calculation_mode dc: review fixes
- Failed final AC check (D5.3a): `dc_pass` sets `state.current_lf_nx` to None, so `results_nx_loadings.csv` and `results_nx_scanned_elements.csv` get `lf_nx_final=None` and their "post-PRA" / "after" columns show the model's prediction (before: the initial DC N-X currents next to the moved PST taps) (DECISIONS 51).
- Validation only in `dc` (D6.3, DECISIONS 57): `validate_config_ranges` checks the factor table only when the file's mode is `dc`; `main()` checks `dc_power_factor` and the table at its start in `dc`. Other modes: a missing `dc_mode` section is the default table (`run_pipeline.dc_factor_table`, `dc_conversion.DEFAULT_FACTOR_TABLE`), `dc_power_factor` is not checked (no import-time check any more). Key-tree test unchanged.
- GUI: a saved `dc_power_factor` that is not a number > 0 becomes 1.0 with a note shown on every page (`_gui_common.migrate_saved_load_flow_config`, `load_settings()["notes"]`; DECISIONS 58); `save_settings` no longer writes `dc_mode` into the settings JSON (DECISIONS 56).
- DC backend removed (D8.1, DECISIONS 50): `milp/dc_backend.py` deleted, `CalculationBackend` back to its single-pass shape (`single_pass.py` byte-identical to before the DC mode); `run_pipeline` builds the `DcCurrentConverter` and calls `build_lf_initial(..., dc_converter=...)`; one initial DC load flow path (`cgmes_loader.run_initial_dc_loadflow`).
- `sensitivity_checks.DC_NX_RELATIVE_TOLERANCE` (5 %) kept and commented with the measured deviations; DECISIONS 55 confirmed. `cgmes_loader.build_lf_initial_dc`: the dead `is None` check is a NaN check (`_has_flow`).
- Tests: N-X currents with factors != 1.0 against pypowsybl's i1/i2 x factor; N-X sensitivities checked branch by branch by finite difference (14 branches with a negative reference flow); P_ref = -tol/2 gives +1; PREVIOUS_VALUES (unit test of `ac_check_parameters` and a DC run); the AC N-X guard keeps 1 %; end-to-end factor on 220 kV only (22 branches x1.3, 332 others unchanged); migration of a saved pf 0.0 (settings, load flow page); settings JSON without `dc_mode`; the N-X files after a failed final check; dc-only validation (AC modes ignore an invalid table / pf, a dc run stops at startup). Each new test was checked by breaking the code in a scratch copy (10 breaks, all detected).
- Docs: `reference/technical/Data_Validation_Reference.md`: every `file:line` citation checked against the code and corrected (about 230, most stale from earlier refactors, not only from the DC change), the DC rows rewritten, a DC load flow row added; `reference/spec/dc_mode_specs.md` (old draft) deleted; `DECISIONS.md` 48, 50, 51, 55, 56 updated, 57-58 new; `User_Guide.md`, `Spec_Coverage.md`, `README.md`.
- AC modes unchanged: golden-output comparison of `ac_iterative` and `ac_single_pass`, mock and generic, N-X off and on, against the outputs stored before these fixes: 8 of 8 identical.
- Suite: 1204 -> 1226 passed.
- Open: `lf_basecase.csv` encoding (unchanged; fixed by the text-encoding entry above).

## 2026-10-18 â€” calculation_mode dc (docs/dc_mode_specs.md D1-D10)
- Step 0 (comments only): `load_flow_config*.yaml`: the `dc_power_factor` comment (converts current limits to power limits in the DC security analysis, not an HVDC setting; also the DC mode's pf) and the header that said the codebase runs AC only.
- Config: `dc_mode.current_factor_by_nominal_voltage_kv` (`default: 1.0` + optional kV entries) in both `rao_config*.yaml`; `dc` is an allowed `calculation_mode` (no reserved mode left). `run_pipeline.validate_config_ranges` checks the table (keys `default` or numeric, numeric strings accepted, values finite > 0, errors name the key); `validate_load_flow_config` checks `dc_power_factor` > 0 at import. `DC_POWER_FACTOR`, `DC_CURRENT_FACTOR_TABLE` constants.
- New `pre_milp/dc_conversion.py`: `DcCurrentConverter` (kV and factor per (branch, side) built once from the network; `scale`, `current`, `sensitivity` with sign(P_ref), 1e-6 MW tolerance, one log line), table parser and pf validator.
- DC primitives with an optional `dc_converter` (None = the unchanged AC path): `cgmes_loader.run_initial_dc_loadflow`, `build_lf_initial(â€¦, dc_converter)`, `print_network_summary(â€¦, load_flow="DC")`; `nx_security_analysis.compute_lf_nx` (DC security analysis from p1/p2); `n0_sensitivity.compute_sensitivity_pst_n0/rd_n0`, `nx_sensitivity.compute_sensitivity_pst_nx/rd_nx/compute_sensitivities_nx` (DC analysis, BRANCH_ACTIVE_POWER_1/2, MW converted to A with the sign of the reference flow; the guard gets converted references). `run_pipeline` passes the converter only in `dc`.
- `milp/single_pass.CalculationBackend`: optional `basis`, `compute_lf_n0`, `dc_converter`. New `milp/dc_backend.py` (DC backend) and `milp/dc_pass.py` (`run_dc_pass`: one build, solve, apply, final AC check; D5 failure paths). `apply_solution_and_refresh` got the optional hook `prepare_fallback` (start voltages for the incremental fallback after a DC load flow; default None, loops unchanged). `run_single_pass` and the loops are not touched.
- Summary rows in `dc` only: `dc_power_factor`, `dc_voltage_levels_with_factor`, `lf_basecase_basis`, `original_network_currents_basis`, `final_check_basis`, `final_check_evaluated`, `final_check_reason` (failure). No CSV shape changes.
- Deviation from the spec text, decided in implementation (DECISIONS 55, to confirm): the N-X deviation check of the sensitivity guard uses 5 % in `dc` (`sensitivity_checks.DC_NX_RELATIVE_TOLERANCE`). With 1 % the first DC run on the mock fixture stopped at the start: after a contingency that disconnects generation the DC security analysis and the DC sensitivity analysis redistribute the distributed slack differently (1.1 % of the current; with `distributed_slack` off they agree to 3e-12 MW).
- GUI: `dc` selectable, caps and thresholds greyed out as in single pass, the factor table read from the active `rao_config.yaml` and never saved into the GUI settings, `dc_power_factor` minimum 0.01 and a save check on the load flow page.
- Docs: `DECISIONS.md` 46-56 (45 marked superseded), `Spec_Coverage.md` 4a/4b, `User_Guide.md` (DC mode, factors, accuracy limits D9), `README.md` layout, `reference/technical/Data_Validation_Reference.md` (3 rows).
- Tests: new `test_rao_dc_conversion.py` (19), `test_rao_dc_mode.py` (DC load flow, `target_p` unchanged, no-NaN `lf_n0`, formula against the pypowsybl DC security analysis at 1e-9, DC N-X currents, N-0 and N-X sensitivities by finite difference, GUI), `test_rao_dc_pass.py` (12 runs: mock and generic x N-X off/on x `[pst]`, `[rd]`, `[pst, rd]` with spies; factors; failure paths: final AC load flow not converging, fallback with the extra load flow, no start voltages, solve not optimal, DC load flow not converging). Changed: the three tests that expected `dc` to be rejected, the key-tree test (the factor table is a leaf).
- AC modes unchanged: golden-output diff of `ac_iterative` and `ac_single_pass` on both fixtures, N-X off and on, before and after (176 files, 262,525 cells, tolerance 1e-6 relative, only the `seconds_*` timing columns skipped): 0 differences; fingerprint test unchanged.
- Suite: 1125 -> 1204 passed.
- Open: `lf_basecase.csv` is written in the platform encoding, not UTF-8 (branch names with accents; existing behaviour, tests read it with `errors="replace"`); `reference/spec/dc_mode_specs.md` is the old draft of the spec; the `file:line` citations of the other rows of `Data_Validation_Reference.md` shifted by a few lines in `run_pipeline.py`; DC `results_nx_loadings.csv` "final" columns show the DC N-X state when the final check was not evaluated. (All but the encoding fixed by the review-fix entry above.)

## 2026-10-17 â€” ra_types and calculation_mode: review fixes (ac_single_pass, dc reserved)
- Spec: `calculation_mode_specs.md` W2 rule 5 (default mode unchanged except the two new summary rows) and W3 rule 5 (the final check covers every N-X pair and scanned element) reworded.
- `milp/single_pass.py`: the final check now covers every pair of the refreshed N-X analysis (PATL, TATL, scanned), not only the pairs in the model (`nx_element_limits`, `nx_overloads_ampere`; same limit rules as the builder and `find_new_congested_pairs`). Pairs in the model keep the model's side and limit and the linearised curative effect (PATL as before, now also the scanned pairs, whose rows bound the post-curative current); pairs outside the model: AC current alone. It reports, it adds no pair. New summary rows `final_check_nx_scanned_*` (single pass only); `final_check_nx_evaluated` is False when N-X is off. Duplicate `nx_build_baseline` assignment removed.
- `milp/ac_convergence_loop.py`: unused `import dataclasses` removed (no behaviour change; fingerprint test unchanged).
- `run_pipeline.validate_ra_types`: a nested or non-text list gives the normal "Invalid ra_types" `ValueError` (was a `TypeError`). `dc` still stops at startup.
- GUI: the calculation mode chosen on the main page is kept in a non-widget session key (`_gui_common.CALCULATION_MODE_STATE_KEY`, `selected_calculation_mode`), so the settings page greys out the caps and thresholds also after an edit, and returning to the main page keeps the mode (it read a widget key of the main page before, which Streamlit deletes on a page change).
- Tests (`test_rao_single_pass.py`, `test_rao_run_pipeline.py`): final check over pairs outside the model (unit and an end-to-end run with `min_loading_threshold_pct_nx` = 50), curative effect on scanned pairs, N-X off; single pass with N-X off and on the generic input, solver not optimal, empty generator read-back; disabled-type summary fields == 0; `converged` and the cycle columns `n/a`; GUI pages with Streamlit `AppTest` (greying, mode kept, results section on single-pass output); nested `ra_types`.
- Docs: `reference/technical/Data_Validation_Reference.md` (ra_types, removed keys, calculation_mode rows; validated at import and at the start of `main()`), `reference/technical/MILP_Mathematical_Formulation.md` Â§6 (ra_types), `Spec_Coverage.md` 4b, `User_Guide.md`.
- Suite: 1106 -> 1125 passed.
- Open: page navigation between GUI pages not tested in a browser (AppTest runs one page at a time); the PST/RD/N-X toggles on the main page still reset on return (as before); the N-0 part of the final check covers the model's branches only; DC (flow-to-ampere conversion).

## 2026-10-17 â€” ra_types and calculation_mode (W1-W8 of docs/calculation_mode_specs.md)
- Config: `workflow_toggles.ra_types` (list of `pst`, `rd`) replaces `enable_pst_remedial_actions` / `enable_rd_remedial_actions` (no alias; the old keys give an error naming `ra_types`); `workflow_toggles.calculation_mode` (`ac_iterative` default, `ac_single_pass`; `dc` stops at startup). Validated in `run_pipeline.validate_ra_types`, `validate_calculation_mode`, `validate_config_ranges` and again at the start of `main()` (fail fast, before any file is read or written). `main()` uses `enable_pst` / `enable_rd` derived from `RA_TYPES`; the late "both off" guard is gone.
- Disabled type leaves no file: `results_curative_pst*.csv` only with PST on, `rd_cra_availability.csv` only with RD on.
- `milp/ac_convergence_loop.py`: `build_model_at_state` (model build at a state) and `apply_solution_and_refresh` (apply, AC load flow with incremental fallback, state update, N-X refresh) cut out of `run_post_rao_ac_verification_loop`; the loop calls them, results unchanged.
- New `milp/single_pass.py`: `run_single_pass` (one build, one solve, one apply, one final check), `run_final_check` (N-X security analysis at the applied state, remaining overloads N-0 / N-X PATL / TATL with the linearised curative effect), `CalculationBackend` (load flow, security analysis, N-X sensitivities as one interface; `ac_backend`).
- `data_model.AcVerificationStatus.SINGLE_PASS` (reason "single pass completed"). Summary: `calculation_mode`, `ra_types`, `completeness_iterations`, `final_check_*` (single pass). Iteration history: one row, `n/a` in the criterion columns. Completeness file: row 0 only, written whenever N-X is on.
- GUI: RA type toggles and calculation mode selection on the main page (Run disabled without an RA type), caps and convergence thresholds greyed out on the settings page in `ac_single_pass`, saved settings with the old keys migrated (`_gui_common.migrate_saved_workflow_toggles`).
- Tests: new `tests/test_rao_single_pass.py`; additions in `test_rao_run_pipeline.py` and `test_rao_run_pipeline_end_to_end.py`; the old module constants (`ENABLE_PST_REMEDIAL_ACTIONS`, `ENABLE_RD_REMEDIAL_ACTIONS`) in `helpers.py` and 5 test files replaced by `RA_TYPES`.
- Docs: `Spec_Coverage.md` section 4b, `User_Guide.md`, `README.md`.
- Suite: 1046 -> 1106 passed (60 new, none removed; one test replaced: the old "both RA types off" guard test became the empty `ra_types` test).
- Open: DC (flow-to-ampere conversion); spec line 4 of `calculation_mode_specs.md` still names `docs/specs.md`; DECISIONS not updated (ask first).

## 2026-10-16 â€” Docs and reference tidy (docs only)
- `docs/specs.md` deleted (identical to `reference/spec/specs.md`); `docs/curative_rd_tatl_specs.md` moved to `reference/spec/`, paths, names and the deviation list updated (list stays in `docs/Spec_Coverage.md`); old `reference/release_plan/Spec_Coverage.md` deleted.
- `docs/Spec_Coverage.md`: paths updated, new section 4a with 8 deferred rows; `docs/User_Guide.md`: `rd_cra_availability.csv`; `docs/README.md` and `.github/copilot-instructions.md` updated (`reference/spec/` readable, new rows rule).
- Comment/name cleanups in `src/app.py` (footer caption), `tests/test_rao_lf_parameters.py` (parameter renamed), `docs/ASSUMPTIONS.md` item 15.
- Suite: 1046 before and after (see report).

## 2026-10-12 â€” Coverage check and data-validation reference (docs only)
- `docs/Coverage_Checklist.md` filled from the code and tests: 72 rows (31 Built, 6 Partly, 6 Deviation, 29 Not built), section B (60 rows), section C (34 rows).
- New `docs/Data_Validation_Reference.md`: checks on inputs and intermediate data per area (12 areas) and 78 silent drops/defaults.
- No source or test change; suite not run.
- Open: Partly rows R0.8 (no SAR cross-check), R1.3 (operating tap limits not parsed), R2.8 (RA count covers preventive RD only), R3.5 (curative taps continuous), R3.7 (only per-contingency Pmax/Pmin); no test sets the per-timeframe RA-count limit.

## 2026-10-11 â€” Performance quick wins (results identical)
Fixture run (mock N-X case, wall time per phase as in docs/Scalability_Report.md), before -> after: total 16.0 s -> 10.5 s; generic fixture 12.5 s -> 7.9 s. Output files compared byte by byte against the run before the changes (iteration-history timing columns and log timing lines excluded).
- Q1: each EQ file is parsed once (`ncp_parser.load_eq_graph`; `build_current_limit_side_map` and `build_tap_changer_to_transformer_map` take an optional `graph`). RDF parsing 9.05 s -> 4.80 s. Tests: maps from one graph = maps from separate parses (every fixture EQ file); a run parses each EQ file once.
- Q2: `compute_lf_nx` reads the security analysis in one pass (`_index_branch_results`, first row per (contingency, branch) as before). 0.92 s -> 0.22 s. Tests: equal to the per-contingency selection on synthetic results (duplicate row, NaN, missing branch, own trip, non-convergent) and on an IEEE 14 security analysis.
- Q3: N-X sensitivities: one factor matrix per side for all contingencies (`ContingencyContextType.ALL`), numpy read-back (`_matrix_entries`, first value of a duplicate label, NaN kept). Works for TRANSFORMER_PHASE and BRANCH_CURRENT_2. 1.19 s -> 0.61 s. Tests: numpy read = per-cell `.loc` (duplicate row/column, NaN); ALL = per-contingency matrices on IEEE 14 (RD, both sides) and on the fixture network (PST).
- Q6: PST and RD N-X sensitivities from one analysis (`compute_sensitivities_nx`; the frozen `compute_sensitivity_pst_nx` / `compute_sensitivity_rd_nx` stay). 0.61 s -> 0.48 s. Tests: one analysis = two analyses (values, guard results, reference currents) on IEEE 14 with two added phase shifters and on the fixture network. The call-site test of `test_rao_lf_parameters.py` now checks the one combined call (two parametrized cases fewer).
- Q4 not kept: summing only non-zero N-X sensitivities gave the same model (fingerprint test) but outputs differing in the last digits (term order inside the rows); no gain on the dense fixture. The model fingerprint test (`tests/fixtures/milp_model_fingerprints.json`, PYTHONHASHSEED=0 subprocess) stays as a guard for builder changes.
- Q5, B4, B6: config keys `performance.lf_thread_count`, `performance.solver_time_limit_seconds`, `performance.solver_mip_rel_gap`, `outputs.write_nx_sensitivity_csvs` (defaults keep the earlier behaviour; range checks). Tests: the thread count reaches every security and sensitivity analysis of a run; a 1 Âµs limit ends the run as `SOLVER_NON_OPTIMAL`; a 1 ms limit on the synthetic model raises not-optimal; the CSVs are skipped when switched off and written by default.
- Found: run-to-run variation in the last digits (pypowsybl sensitivities, hash-seed-dependent summation order) that exists with the old code too: ASSUMPTIONS 16. 8 threads changed `lf_nx_initial.csv` in the last digits.
- Docs: DECISIONS 38-39, ASSUMPTIONS 15-16, README and User_Guide config keys.
- Suite: 947 passed, 0 failed (908 before; 41 tests added, 2 parametrized call-site cases merged into the combined one).

## 2026-10-11 â€” Last smoke-test references
- `tests/test_rao_frozen_imports.py`: `test_frozen_module_exposes_the_names_the_gui_and_smoke_scripts_import` renamed to `test_frozen_module_exposes_the_frozen_names`.
- `.github/copilot-instructions.md`: `smoke_tests/` removed from the never-change list.
- Suite: 908 passed, 0 skipped, 0 failed.

## 2026-10-11 â€” data/ and smoke_tests/ removed
- `data/` and `smoke_tests/` deleted from the repository. Suite before the doc edits: 908 passed, 0 skipped, 0 failed.
- Smoke-test comments removed: `tests/test_rao_frozen_imports.py` (module docstring, the `# smoke tests` group label, the comment about `extract_scanned_element_results`; the test and its frozen names unchanged), `docs/ASSUMPTIONS.md` item 8 (removed; later items keep their numbers), `docs/README.md` (smoke-test line and the smoke mention in the test layout).
- Suite after the edits: 908 passed, 0 skipped, 0 failed.

## 2026-10-11 â€” Tests and code no longer need data/
- `tests/helpers.py`: `fixture_instance_root()` builds an `Instance/`-shaped tree once per session in a temp folder from `tests/fixtures/NCP_generic.zip` (the NCP files of the ReliCapGrid instance) and `CGM_package.zip` (its EQ files); both hold the same content as `data/relicapgrid/Instance` apart from line endings. `build_fixture_input_folder()` builds the input/ folder `real_input_folder` used to build from `data/` (checked identical: same 18 NCP files, same CGM zip). Nothing added to `tests/fixtures`.
- The 41 tests that skipped without `data/` now run on the fixtures: `test_rao_ncp_parser.py` (23) and `test_rao_run_pipeline_end_to_end.py` (8) on `fixture_instance_root()`; `test_rao_ncp_loader.py` (6) on a small synthetic `Instance/` tree under `tmp_path` (the Organisation profile from `NCP_generic.zip`, placeholder profile files); `test_rao_ac_convergence_loop.py` (1) via `real_input_folder`; `test_rao_cgmes_loader.py` (3) gated on `tests/fixtures/CGM_package.zip`. No assertion changed, no test deleted. Unused `data/` skip markers removed from `test_rao_milp_builder_pst.py` / `_rd.py`.
- `cgmes_loader`: `get_cgm_files`, `CGM_ZIP` and `RELICAPGRID_ROOT` removed; `load_cgm(cgm_zip_override)` needs the zip path (no default source, `FileNotFoundError` when missing). `run_pipeline` error text for a missing input folder no longer mentions `data/relicapgrid`.
- Removed: `.gitmodules` (only the `data/relicapgrid` submodule), the `data/` lines of `.gitignore`, `data/relicapgrid` in `pytest.ini`, `requirements-gui.txt`, `.python-version`. Updated: `.github/copilot-instructions.md` (scope, test command, hard rule about real data in `input/`), `docs/README.md`, `docs/ASSUMPTIONS.md` item 8.
- Suite: 908 passed, 0 skipped, 0 failed; again with `data/` renamed: 908 passed, 0 skipped (`data/` restored).
## 2026-10-11 â€” Follow-up fixes, requirements merge, data/ check
- `tests/test_rao_nx_security_analysis.py`: the merged TATL test split again; the second half is `test_several_tatls_on_one_side_give_no_entry_and_no_patl_fallback` (it had lost its `def` and ran inside `test_no_per_branch_correction_log_only_summary`).
- Deleted `test_module_header_says_curative_taps_are_continuous` (it read a docstring); `n0_results_export` module docstring back to the short form.
- Requirement IDs and document references removed from code strings: argparse descriptions (`ncp_loader`, `scanned_elements`, `tso_name_resolver`), log texts (`ncp_parser` "cancelling the AE parse", `nx_security_analysis` "(exactly one expected)", `run_pipeline` "RA group volume limits (per TSO)"), the `build_n0_milp_model` ValueError text (still contains "nothing to optimise"), test assertion messages, and the comments in `rao_config.yaml` / `rao_config.default.yaml` (parsed values unchanged). Renamed tests: `test_group_upward_limit_caps_combined_dispatch`, `test_pst_only_scanned_constraint_has_only_pst_term`, `test_pruning_on_the_real_rd_sensitivity_shape`.
- `requirements.txt` now also holds the GUI packages (own section) and starts with `# Python 3.12.9`; `requirements-gui.txt` and `.python-version` kept. `docs/README.md` updated (install, tests without `data/`).
- Suite: 908 passed. With `data/` renamed: 867 passed, 41 skipped, 0 failed (`data/` restored, 361 files).
## 2026-10-11 â€” Comment clean-up (no behaviour change)
- `src/rao` (all 26 modules) and `tests/`: comments and docstrings describe the current code; history, requirement IDs, spec references, personal names and names of modules or test files that no longer exist removed; long blocks shortened. Comment lines: `src/rao` 5267 â†’ 1720, `tests` 3163 â†’ 2242. Checked by comparing the AST without docstrings against the original (identical for `src/rao`; for `tests` identical apart from the renames below). Two dead duplicate strings removed (a second module docstring in `cgmes_loader.py`, an attribute docstring rewritten in `nx_sensitivity.py` / `nx_security_analysis.py`).
- `ncp_parser.py`: the RD `penaltyFactor` comment said the PST default is 0.0; it is 1.0 (DECISIONS 27).
- `milp_builder.py`: the "Item B" wording removed; the curative RD energy-price deviation is DECISIONS 31.
- Test renames (history words): `TestPreFixBypassConfirmed` â†’ `TestRdActiveRunUsesAcVerification`, `TestNoRegressionWhenNxDisabled` â†’ `TestRdOnlyOutputWhenNxDisabled`, and 11 test functions (`..._now_...`, `..._new_...`, `..._regression_...`, `..._legacy_...`, `..._old_..._now_...`) renamed after what they check.
- Docs: DECISIONS 31â€“37, ASSUMPTIONS 11â€“14; wording removed from `docs/` and `.github/copilot-instructions.md`; comment rule added to `.github/copilot-instructions.md`.
- Suite: 907 passed, 1 failed (`test_module_header_says_curative_taps_are_continuous` reads the `n0_results_export` module docstring, which had lost the file name `results_curative_pst.csv`); docstring corrected, that test and its file (86) pass. Count 908 unchanged.

## 2026-10-11 â€” Fixes from the code review (A, B, C, E findings)
- Group 1 (crashes, wrong output): a stop in a later completeness iteration returns the last applied model of the run (A1); `remaining_overload_count` reads secured branches only (A2); with nothing applied the result files describe the original network, objective blank (A3, `describe_original_network`); a non-optimal solve ends the loop with the new status `SOLVER_NON_OPTIMAL` instead of raising, the solver loads solutions only after the termination check (A4); cycle exit restores the snapshot when both re-applications fail (A11); an empty generator read-back stops before applying (A13).
- Group 2 (no silent defaults): NaN Pmax/Pmin of a generator is 0.0 with a warning (A5); NaN/unreadable N-0 sensitivity excludes the branch (A6); a missing N-0 current is NaN (A7); PST and RD `penaltyFactor` default 1.0 with a warning (A8); bid price is the run timestamp's price, missing or negative = 0 with a warning (A9); `compute_lf_nx` catches lookup errors only (A14); `extract_equipment_dicts` logs failing accessors (A15); tap 0 kept in the non-DataFrame path (A17).
- Group 3 (clean code, no behaviour change): `select_result_models`/`ResultModels` removed with their 3 tests (B6, C1, C2); one pair builder for N-X PATL and scanned pairs (B4); one `_get_monitored_branch_sides` (in `milp_builder`, B5); the solver no longer writes CSV (B7, B8, B14); unused imports removed (B9, AST re-scan clean); dead variable and branch removed (B10, B11); named tolerances (B13); a real-solve test in `test_rao_milp_solver.py` (C4); unused test helpers left by the merges removed.
- Group 4: comments E1â€“E9 rewritten. Docs: DECISIONS 22â€“30, ASSUMPTIONS (bid price, `remaining_overload_count`, items 9â€“10), User_Guide status table.
- Suite: 908 passed (888 + 23 added âˆ’ 3 deleted). Line endings of `src/rao` and `tests` normalised to LF.

## 2026-10-11 â€” Test merge, steps 7-9: registry, run_pipeline, source-text tests, final check
- Step 7: `test_rao_output_file_registry.py` (13 tests) absorbed the former rename tests; `test_rao_run_pipeline.py` (32, fast: config keys, range checks, selector, RD gate) and `test_rao_run_pipeline_end_to_end.py` (49, tests that run `main()`: integration, operating point of the loop, sensitivity guard in a full run, selection runtime test, curative-only RD, lf_nx baseline, summary identity, unknown TSO) replace 9 files. Tests named `t1`â€¦`t7` renamed after what they check. Suite 892 after the step.
- Step 8: deleted `test_pipeline_builds_fallback_from_curative_psts_only`, `test_no_source_still_writes_the_old_branch_headers`, `test_main_has_no_dead_convergence_check_after_the_initial_load_flow`, `test_registry_has_29_names_and_no_sar_files` (source text or removed code). Replaced (count-neutral): the `inspect.getsource` tolerance test by `test_net_volume_at_the_edge_of_the_tolerance_decides_the_count`; the two "both config files carryâ€¦" tests by one parametrized `test_the_config_loader_returns_the_documented_defaults` (2 cases); `test_default_and_active_config_have_the_same_keys_and_values` now compares keys only. `test_rao_validation_fix_pass.py` is gone (empty). Suite: 888.
- Step 9: all 26 test files start with `test_rao_`; no test imports another test file; `tests/helpers.py` comments reworded; `docs/README.md` test layout and `.github/copilot-instructions.md` updated; `docs/Refactor_Inventory.md` deleted. A merge hazard found on the way: an autouse fixture applies to every test moved into its file (`fake_pyomo` in `test_rao_milp_solver.py`), and top-level `try:` blocks that define names must travel with the tests that use them.
- Suite: 888 (892 âˆ’ 4 deleted).

## 2026-10-11 â€” Test merge, step 6: ac_convergence_loop, post_ra_congestion_check, milp_solver
- `test_rao_ac_convergence_loop.py` (66 tests) now holds the old file, `test_rao_convergence_check.py` and `test_rao_cycle_exit.py` (both deleted), the completeness outer-loop and `_count_nx_pairs` classes of the completeness file, the 2 N-0 refresh tests of the guard file and 3 state/history tests of the fix-pass file. New `test_rao_post_ra_congestion_check.py` (15 tests: extract/apply/restore and find-new-congested-pairs classes). `test_rao_operating_point_state.py` unchanged. The scanned-branch solve test of the fix-pass file went to `test_rao_milp_builder.py` (42 tests), not to `test_rao_milp_solver.py`, because that file's autouse `fake_pyomo` fixture replaces `pyomo.environ` and the test needs real Pyomo.
- Suite: 892 (unchanged).

## 2026-10-11 â€” Test merge, step 5: milp_builder in four files, cra_preprocessing
- `test_rao_milp_builder.py` (core, results, RA limits, scanned elements, N-0 zero-PATL and NaN-current tests), `test_rao_milp_builder_pst.py` (58: PST blocks, curative PST penalty, tap limit per TSO, PST kinds, empty tap range), `test_rao_milp_builder_rd.py` (47: RD blocks, availability, curative RD cost, lead time, curative-only RD scenario), `test_rao_milp_builder_nx.py` (23: N-X blocks plus the N-X pair tests of the fix-pass file). New `test_rao_cra_preprocessing.py` (48: curative PST groups, fallback tap bounds, PST tap bounds and group pairs, curative PST availability). The curative-bounds live-data class moved to `test_rao_ncp_parser.py` (64). Ten old files deleted.
- Suite: 892 (unchanged).

## 2026-10-11 â€” Test merge, step 4: nx_results_export, n0_results_export
- `test_rao_nx_results_export.py` (33 tests) now also holds the scanned-element results file tests (`test_rao_nx_scanned_elements_results.py`, deleted) and 3 tests from `test_rao_validation_fix_pass.py` (loading after RAO, contingency status reasons). New `test_rao_n0_results_export.py` (85 tests) takes `test_rao_ra_count_export.py`, `test_rao_curative_rd_results.py`, `test_rao_generating_units_results.py`, `test_rao_curative_pst_results_file.py`, `test_rao_pipeline_output_files.py` (all deleted, their mock-run tests keep using the session fixture), 6 summary tests from `test_rao_results_summary.py`, 2 lead-time tests from `test_rao_output_renames.py`, the 6 writer-status classes of `test_rao_ac_convergence_loop.py`, `TestCyclicRepetitionStatus` of `test_rao_convergence_check.py` (moved whole), the completeness-iterations writer test, and 3 tests from `test_rao_validation_fix_pass.py`. The non-converged initial load flow test moved to `test_rao_cgmes_loader.py`.
- Left for later steps: `test_identity_holds_on_the_mock_n_x_pipeline_run` (alone in `test_rao_results_summary.py`, runs `main()`).
- Suite: 892 (unchanged).

## 2026-10-11 â€” Test merge, step 3: n0_sensitivity, nx_security_analysis, nx_sensitivity
- `test_rao_sensitivity_n0.py` renamed `test_rao_n0_sensitivity.py`. `test_rao_nx_filters_and_scanned_elements.py` is dissolved: its monitored-sides test went to `test_rao_nx_security_analysis.py`, the two filter classes to `test_rao_nx_sensitivity.py`, the two model tests to `test_rao_milp_builder_nx.py`, the real-dataset scanned-AE test to `test_rao_ncp_parser.py`. From `test_rao_validation_fix_pass.py`: 2 NaN/tripped-branch tests to `test_rao_nx_security_analysis.py`, 2 Pmax/Pmin tests to `test_rao_ncp_parser.py` (43 tests left there).
- Suite: 892 (unchanged).

## 2026-10-11 â€” Test merge, step 2: sensitivity_checks, lf_parameters
- New `test_rao_sensitivity_checks.py` (37 tests: 17 guard-rule tests from `test_rao_sensitivity_guard.py`, all 17 of `test_rao_sensitivity_reuse.py`, 3 guard-tolerance tests from the propagation file) and `test_rao_lf_parameters.py` (24 tests: all of `test_rao_sensitivity_lf_parameters.py` and the 7 other propagation tests). `test_rao_sensitivity_reuse.py`, `test_rao_sensitivity_lf_parameters.py` and `test_rao_contingency_propagation.py` are deleted.
- `test_rao_sensitivity_guard.py` (27 tests) stays for now: 25 of its tests run `main()` (step 7) and 2 test the N-0 loop refresh (step 6).
- Suite: 892 (unchanged).

## 2026-10-11 â€” Test merge, step 1: ncp_parser, glsk_resolver
- `test_rao_ncp_ignored_power_ras.py` and the 3 assessed-element tests of `test_rao_validation_fix_pass.py` moved into `test_rao_ncp_parser.py` (59 tests); `test_rao_glsk.py` renamed `test_rao_glsk_resolver.py` (10 tests). `test_rao_cgmes_loader.py`, `test_rao_ncp_loader.py`, `test_rao_data_model.py` and `test_rao_scanned_elements.py` already mirror their module and are unchanged. Tests moved, not rewritten; sys.path set-up lines of merged files dropped (`conftest.py` and `helpers.py` set the path).
- Suite: 892 (unchanged).

## 2026-10-11 â€” Source cleanup, step 6: docs
- `docs/README.md` code layout updated: 26 modules in `src/rao` (28 before steps 4 and 5), `sensitivity_checks`, curative PST groups inside `cra_preprocessing`, `select_by_side` in `data_model`, 53 test files plus `conftest.py` and `helpers.py`. `docs/Refactor_Inventory.md` is kept until all steps are accepted.
- Suite: 892 (unchanged; docs only). Summary of steps 0-5: 884 â†’ 901 (frozen-import tests) â†’ 895 (dead code) â†’ 892 (duplicate tests). Open: `.github/copilot-instructions.md` could mention `tests/helpers.py`; the smoke scripts have drifted (see ASSUMPTIONS item 8).

## 2026-10-11 â€” Source cleanup, step 5: merge M2
- `pre_milp/curative_pst_groups.py` merged into `pre_milp/cra_preprocessing.py` (its two existing public names are unchanged; the group code and its docstring, now a comment block, are appended). `run_pipeline` imports `validate_pst_group_kind` and `build_curative_pst_group_constraints` from there (3 call sites); `tests/helpers.py` and `test_rao_curative_pst_groups.py` import from the new path; `milp_builder` comment updated. The old module is removed.
- Suite: 892 (unchanged).

## 2026-10-11 â€” Source cleanup, step 4: merge M1
- `pre_milp/sensitivity_validation.py` and `pre_milp/sensitivity_reuse.py` merged into `pre_milp/sensitivity_checks.py` (guard first, reuse second; code unchanged, one combined docstring). Imports updated in `run_pipeline`, `ac_convergence_loop`, `n0_sensitivity`, `nx_sensitivity`, `test_rao_contingency_propagation` and `test_rao_sensitivity_guard`; comments in `operating_point_state`, `n0_sensitivity` and `nx_sensitivity` updated. Both old modules are removed.
- Suite: 892 (unchanged).

## 2026-10-11 â€” Source cleanup, step 3: duplicate helpers
- `nx_sensitivity` imports `_get_monitored_branch_sides_nx`, `_get_must_study_contingencies` and `_register_contingencies` from `nx_security_analysis` (copies deleted); `glsk_resolver` imports `_frag`, `_load_graph`, `_iso_to_hhmmz` from `ncp_parser` (copies deleted; the two `_iso_to_hhmmz` versions had the same regex and results). `n0_sensitivity._get_monitored_branch_sides` (with the loading-threshold filter) is renamed `_get_loading_filtered_branch_sides`, so it no longer shares a name with the unfiltered `milp_builder._get_monitored_branch_sides`. No behaviour change.
- Suite: 892 (unchanged).

## 2026-10-10 â€” Source cleanup, step 2: one `select_by_side`
- `data_model.select_by_side` replaces the five `_select_by_side` copies (`milp_builder`, `n0_sensitivity`, `nx_security_analysis`, `nx_sensitivity`, `nx_results_export`); `ac_convergence_loop`, `milp_solver`, `n0_results_export`, `post_ra_congestion_check` and a test import it from there instead of from `milp_builder`. It keeps the `nx_results_export` guard (empty or None dict â†’ None). The 3 duplicate tests in `test_rao_nx_security_analysis.py` were deleted; the other set moved to `test_rao_data_model.py`. Removed the dead `if __name__ == "__main__":` block of `cgmes_loader.py` (it called `run_loadflow` and `build_branch_name_to_mrid`, which do not exist).
- Suite: 892 (895 âˆ’ 3).

## 2026-10-10 â€” Source cleanup, step 1: dead code removed
- Deleted `cgmes_loader.pu_to_ka` and `select_by_side`, `pst_bounds._is_within_bounds`, `nx_security_analysis._get_limit_by_branch_nx`, `n0_results_export.write_lf_post_csv`, `post_ra_congestion_check.extract_pst_tap_solution`, the 6 tests that covered only them (3 for `select_by_side`, 3 for `extract_pst_tap_solution`), an unused `import math` and one unused test helper. Comments and docstrings that cited them were rewritten. No behaviour change.
- Suite: 895 (901 âˆ’ 6).

## 2026-10-10 â€” Source cleanup, step 0: test helpers and frozen-import test
- New `tests/helpers.py` holds the builders that test files used to import from each other (`_make_ae`, `_make_pst`, `Scenario`, `_run_nested`, `run_pipeline_on_fixture_inputs` and the rest); all cross-test imports now go there; `conftest.py` keeps fixtures and imports the pipeline-run helper from it. New `tests/test_rao_frozen_imports.py` (17 tests) checks the modules and names the GUI and smoke scripts import, and the paths of `run_pipeline.py`, `data_model.py` and the config files. No source change.
- Suite: 901 (884 + 17). Open: `smoke_test_r2_1_rd_sensitivity.py` imports `extract_scanned_element_results`, which no longer exists.

## 2026-10-10 â€” README matched to the repo
- `docs/README.md`: Python 3.12.9, pandas 3.0.3, numpy 2.5.1, pinned `requirements.txt`, 52 test files, `src/rao_pages` in the code layout. New `requirements-gui.txt` (streamlit, plotly, pillow). BOM removed from `test_rao_validation_fix_pass.py`; document citations removed from `smoke_test_r3_nx_cra.py`. No behaviour change.

## 2026-10-10 â€” Docs in place and cleanup
- Created `reference/spec`, `reference/technical`, `reference/release_plan` (empty). Removed three tests that read documents; comments in `src` and `tests` no longer cite document files (rule stated in the comment). Corrected the PST-group pair comment in `milp_builder.py` (only pairs naming a dropped PST are dropped). No behaviour change.
- Suite: 884 passed, 0 skipped (the 41 dataset tests ran because `data/relicapgrid` is present). Open: README Environment section differs from `requirements.txt` and the venv (Python, pandas, numpy versions).

## 2026-10-10 â€” Repo restructuring (docs)
- Documents split: `docs/` (working documents) and `reference/` (background). Instructions in `.github/copilot-instructions.md`.

## 2026-10-10 â€” Validation fix pass
- AE with no region code and no exclusion reason: excluded. Scanned-only AE stays secured.
- PST with empty tap range dropped consistently; groups dropped with a warning.
- PATL â‰¤ 0 excluded on the N-X side; missing/NaN `lf_nx` currents and N-X NaN sensitivities skip the pair with a warning.
- Export curative effect uses the builder's own effect (same gating).
- Pmax/Pmin default warns; summary flag `completeness_iteration_limit_reached`; skipped-contingency reasons in `results_contingency_status.csv`; column `nx_contingencies_lost_at_refresh`.
- `solve_n0_milp_model` fixed for scanned branches; config range checks; sar module and registry entries removed (29 output names).
- Suite: 846 passed, 41 skipped. Open: NaN in N-0 sensitivities; no pipeline-level test for the skipped-reason merge.

## Before 2026-10-10 (summary)
- Loop redesign (state object, nested loops, cumulative MILP, convergence criteria, cycle exit), sensitivity load-flow parameter fix with guard, propagation off, results export and file registry, config completion with `ConfigKeyError`, dead code removed.
