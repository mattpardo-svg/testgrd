# Spec coverage

Working document (updated with every new, changed or deferred requirement). Written 2026-10-12 from the code (not from the docs) by reading modules and tests row by row, with DECISIONS up to 39 and ASSUMPTIONS up to 16. Updated 2026-10-16 for reference/spec/curative_rd_tatl_specs.md (R2, R4, R7, R9, R11, R15, F2, O1) and its review round. Updated 2026-10-19 for the HVDC remedial actions (R6.1-R6.4, sections 4a-4c, DECISIONS 60-68). Updated 2026-10-20 for the countertrade remedial actions (R6.5-R6.7, section 4d, DECISIONS 69-78). Spec: R25_1-ELA-SFS-SYS_14_03_RAO_Calculation-LOT3_09FIN (v14.11.2025). Identifiers are the spec's CORNET / BUC / SF numbers.

The release plan files in `reference/archive/` (R0-R6) are the original plan. They are partly out of date: where a plan file and this document disagree, this document and the code are right.

**Status words.** Built = in the code and tested. Partly = some of the title is in the code. Deviation = built differently from the spec on purpose (D = DECISIONS number). Not built = in the plan, not in the code.

## 1. Summary

| Release | Content | Built | Partly | Deviation | Not built |
|---|---|---|---|---|---|
| R0 | Data ingestion | 6 | 1 | 2 | 0 |
| R1 | N-0 PST | 7 | 1 | 2 | 0 |
| R2 | N-0 RD | 11 | 1 | 0 | 0 |
| R3 | N-X and curative | 7 | 2 | 2 | 0 |
| R4 | Multi-timestamp | 0 | 1 | 0 | 9 |
| R5 | Generator physics | 0 | 0 | 0 | 10 |
| R6 | HVDC, countertrade, system constraints | 2 | 0 | 5 | 3 |
| Total | 72 rows | 33 | 6 | 11 | 22 |

## 2. What this means

- R0-R3 (single timestamp, N-0 and N-X, preventive and curative PST and RD) are in the code. The gaps inside them are the Partly and Deviation rows below.
- R4 and R5 are not built (decision "single timestamp", D1, D20); in R6 HVDC (R6.1-R6.4, D60-D68) and countertrade (R6.5-R6.7, D69-D78) are built, the system constraints are not. The only trace is the per-timeframe RA-count limit (R4.7) and parsed-but-unused fields (section 7).
- Open gaps worth a decision: R0.8 SAR cross-check; R1.3 operating and relative PST tap limits never read; R2.8 RA count covers preventive RD only; R3.5 (curative taps continuous) closed by D154; R3.7 Pmax/Pmin per unit only (the other CORNET-498/537 system constraints are not built); eq. 3.35 not built (R1.7).

## 3. Increments R0-R6, status per row

| ID | Title | Spec items | Status | Evidence | Note |
|---|---|---|---|---|---|
| R0.1 | CGM load and base-case AC load flow | CORNET-97 | Built | `pre_milp/cgmes_loader.py:37` `load_cgm`, `:58` `run_initial_loadflow`; `test_a_non_converged_initial_load_flow_halts_with_runtime_error_and_a_fatal_log` | `use_reactive_limits` false by default (D32). |
| R0.2 | TSO name resolution via EQ file SubGeographicalRegion | §3.2.1 | Deviation (D35) | `pre_milp/tso_name_resolver.py:41` `_build_from_org_file` (called from `run_pipeline.py` `main` through `build_tso_name_map`); `test_returns_four_tsos` | Names come from the Organisation profile; the EQ path `build_substation_mrid_to_tso` (`pre_milp/tso_name_resolver.py` `build_substation_mrid_to_tso`) exists but the pipeline never calls it and no test covers it. |
| R0.3 | NCP file discovery and TSO inventory | CORNET-85 | Built | `pre_milp/ncp_loader.py:79` `extract_ncp_zip`, `:111` `classify_extracted_ncp_files`; `test_missing_required_profile_raises` | Input is one flat `ncp*.zip`; profiles SSI, PS, RAS, FAP skipped without a warning (D37); ER is an optional profile (generating-unit start-up / shut-down costs). |
| R0.4 | Assessed element (XNE) parsing with exclusion logic | CORNET-336, SF927 | Deviation (D15) | `pre_milp/ncp_parser.py:131` `parse_assessed_elements`, classification in `parse_assessed_elements`; `test_ae_with_neither_region_code_nor_exclusion_is_excluded_and_logged` | Scanned code only = secured; scanned only when an exclusion reason and a scanned code are both present. |
| R0.5 | Contingency parsing | CORNET-3693 | Built | `pre_milp/ncp_parser.py:385` `parse_contingencies`; `test_returns_contingencies_with_valid_equipment` | CoMo type "bus" not mapped (D37); contingency type is parsed but never used. |
| R0.6 | PST remedial action parsing | CORNET-338, CORNET-21 | Built | `pre_milp/ncp_parser.py:647` `parse_psts`; `test_returns_pst_with_known_tapchanger` | Operating tap range is the CGM hardware range; no NCP operating limits read (see R1.3). |
| R0.7 | RD remedial action and power bid parsing | CORNET-335 | Built | `pre_milp/ncp_parser.py:921` `parse_rd_units`; `test_the_bid_price_is_the_price_of_the_run_timestamp` | Price of the run timestamp only (D28); Redispatch/Countertrade RAs ignored with a warning (D37; a countertrade RA is parsed by `pre_milp/ct_units.py` when `countertrade` is in `ra_types`, D69). |
| R0.8 | Inventory summary and SAR cross-check |  | Partly | `pre_milp/inventory_summary.py:12` `print_inventory_summary`; test none | Inventory table is logged; no SAR cross-check exists in the code. |
| R0.9 | Scanned element parsing | CORNET-439 | Built | `pre_milp/scanned_elements.py:28` `build_scanned_element_list`; `test_case3_lf_exceeds_patl_effective_equals_lf` | The list only feeds `scanned_element_list.csv`; the MILP recomputes limits in `milp/milp_builder.py` `_get_monitored_branch_limits_and_ae_types`. Virtual margin 0 (A11). |
| R1.1 | Initial AC load flow convergence check | CORNET-111 | Built | `pre_milp/cgmes_loader.py:81-83`; `test_a_non_converged_initial_load_flow_halts_with_runtime_error_and_a_fatal_log` | Status read from component 0 only (A10). |
| R1.2 | N-0 AC sensitivity matrix for PSTs | CORNET-4836, CORNET-102 | Built | `pre_milp/n0_sensitivity.py:168` `compute_sensitivity_pst_n0`; `test_compute_sensitivity_pst_n0_mixed_sides_issues_two_calls` | Side-aware, same LF parameters (D10), guarded (D12); 3-winding PSTs left out (D37). |
| R1.3 | PST tap bounds and operational limit constraints | CORNET-2895 | Partly | `pre_milp/pst_bounds.py:10` `build_pst_tap_bounds`, `milp/milp_builder.py` `_add_pst_block` (`tap_upper_bound_rule`, `tap_lower_bound_rule`); `test_hardware_and_operating_limits_applied` | Bounds logic exists, but operating and relative limits are never parsed: operating = hardware (`pre_milp/ncp_parser.py` `parse_psts`), relative limits always None. |
| R1.4 | PST group equality constraint construction | CORNET-21 | Built | `pre_milp/pst_groups.py:12` `build_pst_group_equality_pairs`, `milp/milp_builder.py` `_add_pst_block` (`pst_group_equality`); `test_valid_group_builds_pairs` | Pairs naming a dropped PST are dropped (D18). |
| R1.5 | N-0 MILP construction: PST variables and XNE loading constraints | CORNET-1790 | Built | `milp/milp_builder.py:2357` `build_n0_milp_model`, `:2475-2487` `xne_loading_n0`; `test_pst_only_solves_to_expected_tap_change` | Soft (slack) constraint; cumulative tap variables (D4). |
| R1.6 | Pyomo/HiGHS solve and result extraction | SF3079 | Built | `milp/milp_solver.py:49` `solve_n0_milp_model`; `test_a_real_model_is_solved_and_its_tap_change_extracted` | Non-optimal raises and ends the loop as `SOLVER_NON_OPTIMAL` (D23). |
| R1.7 | Post-solve LF and linearisation loop | CORNET-12, CORNET-4850 | Deviation (D9) | `milp/ac_convergence_loop.py:645` `run_post_rao_ac_verification_loop`; `test_run_post_rao_linearisation_loop_terminates_on_threshold` | Built per D2-D8; the sum-of-RA-change criterion (eq. 3.35) is not built, taps and MW share one threshold. |
| R1.8 | PST penalty costs in objective function | CORNET-2998 | Built | `milp/milp_builder.py` `build_n0_milp_model` (PST penalty term on `cum_tap_up_term` / `cum_tap_down_term`); `test_objective_equals_cost_of_cumulative_changes_after_several_iterations` | Missing `penaltyFactor` = 1.0 with a warning (D27); priced on the cumulative change. |
| R1.9 | Full LF result output per branch and per node | CORNET-98, CORNET-3221 | Deviation (D37) | `pre_milp/cgmes_loader.py:338` `write_lf_basecase_csv`, `post_milp/n0_results_export.py:1485` `write_lf_post_iterations_csv`; `test_lf_post_n0_holds_every_ac_iteration_up_to_the_summary_iteration_count` | `lf_results_branches.csv` / `lf_results_buses.csv` not produced; no per-node output; `lf_post_n0.csv` lists secured branches only. |
| R1.10 | PST tap-change limit per TSO, single-timestamp | CORNET-3653, CORNET-3654 | Built | `milp/milp_builder.py:564-566` `max_taps_per_tso_constraint`; `test_constraint_blocks_a_combined_move_exceeding_the_per_tso_limit` | Hard, cumulative, preventive PSTs only; per-TSO overrides. |
| R2.1 | N-0 AC sensitivity matrix for RD units | CORNET-4836, CORNET-102 | Built | `pre_milp/n0_sensitivity.py:395` `compute_sensitivity_rd_n0`; `test_compute_sensitivity_rd_n0_side_routing_and_shape` | Preventive available units only. |
| R2.2 | Sensitivity threshold pruning | CORNET-3624 | Built | `pre_milp/n0_sensitivity.py:520` `prune_sensitivity_by_threshold`, `pre_milp/nx_sensitivity.py` `prune_sensitivity_pst_nx`, `prune_sensitivity_rd_nx`; `test_branch_below_sensitivity_threshold_is_dropped` | N-0 drops the branch from that matrix; N-X drops entries, the pair keeps a slack-only constraint. |
| R2.3 | GLSK participation factor mapping | CORNET-4848 | Built | `pre_milp/glsk_resolver.py:43` `resolve_glsk`; `test_resolve_glsk_normalises_across_two_units` | Only the PowerBidSchedule chain; factors renormalised after dropping units not in the network. |
| R2.4 | RD MILP variables and Pmax/Pmin constraints | CORNET-36, CORNET-37 | Built | `milp/milp_builder.py` `_add_rd_block`, `pmax_pmin_constraint`, `_rd_unit_status`; `test_rd_only_pmax_pmin_constrains_dispatch`, `test_a_running_unit_below_pmin_gets_pmin_set_to_its_production` | Missing Pmax/Pmin = 0.0 with a warning (D16). Pmin := PROD for Pmin > 0 and 0 < PROD < Pmin (CORNET-37 4231-4235); the start-up/shut-down phase check is time coupling and not done. |
| R2.4a | Generator on/off: status, start-up, shut-down (semi-continuous) | CORNET-37, BUC14#103, BUC14#106 | Built (single timestamp) | `milp/milp_builder.py` `_rd_unit_status`, `rd_unit_on`, `rd_unit_on_lower/upper`; `pre_milp/glsk_resolver.py` (unconnected units); `test_an_offline_unit_with_a_start_up_cost_can_be_started_and_pays_it`, `test_an_online_unit_with_a_shut_down_cost_can_be_shut_down_and_pays_it` | On = connected and (\|PROD\| > 1e-6 MW, or PROD = 0 with Pmin <= 0). One binary per unit with Pmin > 0, also inside multi-unit bids (on/off judged on PROD0 + sum of participation factor x volume over all its bids; source Open RAO). Static check before the solve: an off unit that cannot be started (no start-up cost, or Pmin above the sum of participation factor x available up volume) blocks every bid containing it, one log line per bid naming the unit and the reason. Pmin > Pmax: warning. A preventive bid with an empty GLSK is fixed to 0. The reported original network (non-convergent run) has every initially-on unit on. PROD = SSH target_p (deviation, CGMES 3.0 has no initialP). Ramps, min up/down, lead/lag times: time coupling, not built. Tests: `test_a_multi_unit_bid_with_an_off_unit_is_0_or_at_least_pmin_over_the_factor`, `test_a_multi_unit_bid_whose_share_cannot_reach_pmin_is_blocked_with_one_log_line`, `test_the_reported_original_network_has_no_shut_down_cost`. |
| R2.5 | RD N-0 loading constraints extension |  | Built | `milp/milp_builder.py:910-917` `rd_effect_on_branch`, `build_n0_milp_model` (`xne_loading_n0_rule`); `test_pst_and_rd_together_both_present_and_summed` |  |
| R2.6 | RD balancing constraint | CORNET-73 | Built | `milp/milp_builder.py:2470-2473` `rd_balancing_n0`; `test_rd_only_balancing_constraint_exists_and_holds_when_solved` | Hard, no slack; preventive RD only. |
| R2.7 | RD penalty and price costs in objective | CORNET-4606 | Built | `milp/milp_builder.py:1678-1713`; `test_cheaper_bid_preferred_when_both_resolve_the_same_congestion` | RA-level penalty factor × reference + run-timestamp price (D28). |
| R2.8 | RA count limit per TSO per timestamp | BUC14#119, CORNET-3649 | Partly | `milp/milp_builder.py:2192` `_add_ra_activation_and_count_constraints`; `test_hard_limit_caps_activated_ra_count` | Counts preventive RD RAs only; PST and curative RAs are not counted. Binary linked one-sided (D5). |
| R2.9 | RA group volume limits | CORNET-4838 | Built | `pre_milp/ncp_parser.py:1341` `parse_ra_groups`, `milp/milp_builder.py` `_add_ra_group_volume_constraints`; `test_group_upward_limit_caps_combined_dispatch` | Preventive RD bids only; group predicates inferred (A14). |
| R2.10 | RD lead time enforcement | CORNET-3616 | Built | `milp/milp_builder.py:271-283` `_timestamp_is_usable`, `_add_rd_block`, `_add_curative_rd_block`; `test_bid_with_unmet_lead_time_gets_zero_upper_bounds` | radp = one hour before the timestamp (RAART fixed None, D30). |
| R2.11 | Combined PST+RD results output | BUC14#132 | Built | `post_milp/n0_results_export.py:1074` `extract_results_summary`, `:520` `extract_rd_results`; `test_summary_identity_and_cumulative_costs` |  |
| R2.12 | Scanned element MILP constraints | CORNET-439 | Built | `milp/milp_builder.py:2497-2518` `scanned_element_n0`; `test_hard_constraint_acceptance_criterion_loading_never_exceeds_limit` | Hard by default (`scanned_element_constraint_hard`); limit anchored to the original LF (D29). |
| R3.1 | Custom N-X sensitivity computation via conventional AC LF |  | Built | `pre_milp/nx_sensitivity.py:525` `compute_sensitivities_nx`, `pre_milp/nx_security_analysis.py:93` `compute_lf_nx`; `test_one_analysis_for_pst_and_rd_equals_two_analyses_on_the_fixture_network` | Done with one AC sensitivity analysis over all contingencies, checked against the security analysis, not a per-contingency LF perturbation. |
| R3.2 | N-X loading constraints in MILP | CORNET-1790, CORNET-16 | Built | `milp/milp_builder.py:1739` `_add_nx_block`, `:2079-2092` `nx_patl_loading`; `test_nx_only_overload_resolved_by_pst_tap_change_end_to_end` | Every secured branch under every must-study contingency (AE-contingency links not used). |
| R3.2a | N-X scanned-element loading constraints | CORNET-439 | Built | `milp/milp_builder.py:2172-2187` `nx_scanned_loading`; `test_scanned_branch_gets_constraint_against_effective_limit` | Always soft; limit = max(PATL, original N-0 current) (D29). |
| R3.3 | TATL constraint for N-X | CORNET-1790, CORNET-1792 | Built (one TATL per branch, no steps) | `pre_milp/nx_security_analysis.py` `compute_tatl_data`, `milp/milp_builder.py` `_add_nx_block` `nx_tatl_loading`; `test_tatl_and_patl_constraints_coexist_independently`, `test_no_tatl_constraint_without_a_tatl_above_the_patl` | TATL row = state after the preventive actions only; PATL row = after preventive and curative. Only for a TATL strictly above the PATL, with a tolerance of 1e-6 A (`milp_builder.tatl_is_above_patl`, also used by the post-RA congestion check; the convergence check follows the builder's rows): PATL 1.005 kA = 1004.9999999999999 A and a TATL of 1005.0 A give no TATL row. No TATL row: duration `curative_ra.tatl_fallback_duration_s` (600 s) for the reaction-time checks, no TATL constraint. Test: `test_a_tatl_equal_to_the_patl_up_to_float_noise_gives_no_tatl_row`. |
| R3.3a | Curative RD reaction time vs TATL duration | CORNET-613 | Built | `pre_milp/ncp_parser.py` `parse_rd_units` (timeToImplement), `pre_milp/cra_preprocessing.py` `rd_cra_is_available`, `compute_rd_cra_availability` (`rd_cra_availability.csv`); `test_curative_rd_enters_a_branch_only_if_its_reaction_time_fits_the_tatl_duration` | No timeToImplement = 0; an unreadable one = 0 with a warning; ISO durations with a day part are read (P1D = 1440 min). Availability per (RA, branch), the rule has no contingency term. One helper (`compute_rd_cra_availability` with `branch_tatl_duration_seconds`) serves the MILP (every branch it evaluates) and `rd_cra_availability.csv` (every monitored branch, scanned and fallback-duration branches included). Tests: `test_a_scanned_branch_uses_the_fallback_duration_in_the_milp_and_in_the_csv`, `test_an_unreadable_rd_time_to_implement_is_zero_with_a_warning`. |
| R3.4 | Curative PST RA parsing and reaction time | BUC14#110, CORNET-1978 | Built | `pre_milp/ncp_parser.py` `parse_psts`, `pre_milp/cra_preprocessing.py:103` `compute_pst_cra_availability`; `test_acceptance_criteria_example_from_spec` | PST without timing data is skipped with a warning. |
| R3.5 | Curative PST variables and MILP constraints | CORNET-1985, SF3074 | Built | `milp/milp_builder.py` `_add_curative_pst_block`; `test_acceptance_criteria_curative_pst_linked_to_one_contingency_only`; `test_rao_curative_pst_taps_are_whole_numbers_when_taps_are_discrete` | Curative tap variables use the domain of the preventive taps (integer when `pst_taping_discrete`, D154); group kind from config (D33). |
| R3.6 | Curative RD RA variables and MILP constraints | BUC14#106, BUC14#43, CORNET-4614 | Built, with deviations | `milp/milp_builder.py` `_add_curative_rd_block`, `curative_rd_reservation_price_eur_mw`; `test_curative_only_rd_scenario_solves_uses_bid_and_nx_block_links_it`, `test_curative_rd_contingency_link_decides_the_bid_contingency_pairs`, `test_curative_cost_uses_the_reserve_price_else_the_energy_price_with_a_log_line` | No contingency link = every contingency. Acts only if at least one unit of its GLSK is on after the preventive actions: volume <= available MW x sum of the units' on/off binaries (a continuous unit that is on counts 1); a bid containing a unit that cannot be started is blocked; the per-unit R7 row keeps an off unit's share at 0. Cost (penalty factor x preventive reference + reservePrice, else energy price, logged; a negative reservePrice is 0 with a warning) on the max over contingencies. Test: `test_a_multi_unit_curative_bid_acts_if_at_least_one_unit_is_on_initially`. |
| R3.6a | Curative RD balancing per contingency | CORNET-574 | Built | `milp/milp_builder.py` `curative_rd_balancing`; `test_curative_up_and_down_bids_on_two_units_balance_per_contingency` | Hard equality, no slack. |
| R3.7 | Pmin/Pmax with PRA and CRA per generating unit | CORNET-4614 | Built | `milp/milp_builder.py` `_add_curative_rd_block`: `curative_pmax_pmin_constraint`, `curative_on_off_lower/upper`, exact maxima `max_curative_lower`, `max_curative_single`, `curative_max_choice`, `curative_max_upper`; `validate_participation_factors`; `test_the_spec_example_is_rejected_by_the_per_unit_constraint`, `test_the_curative_maxima_cannot_be_inflated` | One pair per unit, net form: P after PRA + sum pf*max_up - sum pf*max_down within [Pmin, Pmax] (Pmin*u, Pmax*u with an on/off binary). A unit with an on/off binary also gets two one-sided rows, sum pf*max_up <= Pmax*u and sum pf*max_down <= Pmax*u (`curative_on_off_up_maxima`, `curative_on_off_down_maxima`), so up and down maxima of different bids cannot cancel on an off unit (F2 rule 7; test `test_up_and_down_curative_bids_cannot_cancel_on_an_off_unit`). Exact max: one binary per (bid, contingency) for bids with several contingencies (52 on the mock input). Participation factor < 0: the run stops with an error naming the RA and the unit. Other CORNET-498/537 system constraints: not built. |
| R3.8 | Completeness iteration loop | CORNET-16 | Built | `milp/ac_convergence_loop.py:1290` `run_nested_rao_loop`, `milp/post_ra_congestion_check.py:260` `find_new_congested_pairs`; `test_runs_the_linearisation_loop_again_when_new_congestion_is_found_then_stops` | New pairs are counted, then enter through the rebuild at the refreshed N-X LF (D2). |
| R3.9 | N-X results export | BUC14#142, BUC14#141 | Built | `post_milp/nx_results_export.py:66`, `:219`, `:265`; `test_columns_match_spec_exactly` | Corridor results not built (D37). |
| R3.10 | Pipeline integration (`ENABLE_NX_ANALYSIS`) |  | Built | `run_pipeline.py` `ENABLE_NX_ANALYSIS`, `main` (N-X preprocessing); `test_real_nx_artifacts_produced_and_non_trivial` | Config key `workflow_toggles.enable_nx_analysis`. |
| R4.1 | Multi-timestamp operating point per timestamp |  | Not built | none | D1. A 4-entry timestamp list is built (`run_pipeline.py` `main`, `build_timestamp_list`) and PATL/bids parsed per timestamp, but only `START_HOUR` is optimised. |
| R4.2 | Multi-timestamp MILP variables and N-0 loading constraints |  | Not built | none | D1; one model per single timestamp. |
| R4.3 | PST tap-change limit per timestamp | CORNET-3653 | Not built | none | D1; only the single-timestamp limit of R1.10. |
| R4.4 | PST tap-change limit per optimisation timeframe | CORNET-3654 | Not built | none | D1; with one timestamp the R1.10 limit stands for both. |
| R4.5 | Multi-timestamp RD operating point per timestamp |  | Not built | none | D1; `available_mw` parsed per timestamp (`pre_milp/ncp_parser.py` `parse_power_bids`), one used. |
| R4.6 | Multi-timestamp RD MILP variables, Pmax/Pmin, and N-0 loading constraint extension |  | Not built | none | D1. |
| R4.7 | Multi-timestamp RD balancing, costs, and RA/group limits |  | Partly | `milp/milp_builder.py:2257-2265` `ra_count_limit_per_timeframe`; test none | Only the per-timeframe RA-count limit exists (soft, acts on the one timestamp); no test sets it. Balancing and costs single-timestamp. |
| R4.8 | Multi-timestamp RD lead time enforcement |  | Not built | none | `results_lead_times.csv` reports the earliest usable timestamp of the 4-entry list (`n0_results_export.py:877`); reporting only. |
| R4.9 | Combined PST+RD multi-timestamp linearisation loop and results output |  | Not built | none | D1. |
| R4.10 | Pipeline integration (`ENABLE_MULTITIMESTAMP`) |  | Not built | none | No such config key or flag. |
| R5.1 | Power gradient constraints | CORNET-45, CORNET-46 | Not built | none | Ramp rates parsed (`pre_milp/ncp_parser.py` `parse_rd_units`) into `RDUnit`, never used. |
| R5.2 | Minimum up and down times | CORNET-4595 | Not built | none | Nothing in the code. |
| R5.3 | Start-up ramp | CORNET-47, CORNET-49, CORNET-69 | Not built | none | Nothing in the code. |
| R5.4 | Shutdown ramp | CORNET-48, CORNET-50, CORNET-70 | Not built | none | Nothing in the code. |
| R5.5 | Lead and lag times | CORNET-4596, CORNET-91 | Not built | none | Single-timestamp lead time only (R2.10); no lag time. |
| R5.6 | Start-up costs | BUC14#103, SF3077 (3.39) | Built (single timestamp) | `pre_milp/ncp_parser.py` `parse_unit_costs`, `milp/milp_builder.py` objective `startup_cost`; `test_an_offline_unit_with_a_start_up_cost_can_be_started_and_pays_it` | Source: UnitCostTimePoint.warmStartupCost, startupCost, ER normalWarmStartupCost. No cost: no start-up. Avoided start-up credit (time coupling) not built. |
| R5.7 | Energy limits per bid | CORNET-3626, CORNET-3711 | Not built | none | `minEnergyBid`/`maxEnergyBid` parsed (`pre_milp/ncp_parser.py` `parse_power_bids`), never used. |
| R5.8 | RD step sizes | CORNET-3632 | Not built | none | `stepSizeCTRD` parsed (`pre_milp/ncp_parser.py` `parse_power_bids`), never used. |
| R5.9 | Bid activation costs | BUC14#102, SF3077 (3.38) | Built (single timestamp) | `pre_milp/ncp_parser.py` `parse_rd_units`, `milp/milp_builder.py` `rd_bid_activated`, objective `bid_activation_cost`; `test_a_bid_with_an_activation_cost_pays_it_once_when_used` | PowerBidSchedule.activationCost, the time-point value overrides; preventive only; binary only for a cost > 0. Contiguity over timestamps: time coupling. |
| R5.10 | Shutdown costs | CORNET-71 | Built (deviation: spec defers it) | `pre_milp/ncp_parser.py` `parse_unit_costs`, objective `shutdown_cost`; `test_an_online_unit_with_a_shut_down_cost_can_be_shut_down_and_pays_it` | Unit level only: UnitCostTimePoint.shutdownCost, ER normalShutdownCost; the bid-level shutdownCost is not used. No cost: no shut-down. |
| R6.1 | HVDC equivalent injection parsing | BUC14#55 | Built | `pre_milp/ncp_parser.py` `parse_hvdc_units`, `parse_balanced_ra_groups`; `pre_milp/hvdc_units.py` `validate_hvdc_structure`, `resolve_operating_limits`; `test_rao_hvdc_parser.py` | A unit is a GSARA with one `EquivalentInjectionAction` on an EI of the CGM (identified by the RA link, an EI description other than "HVDC" is a warning only, D60); `RangeConstraint`s (the most restrictive wins, incremental values are magnitudes; a CGM set point outside the range widens it, H3.4); group = `RemedialActionGroup` with a `balanced` dependency, both predicate names. AEs via DCTieCorridor are still skipped (`ncp_parser.py`). |
| R6.2 | HVDC sensitivity computation |  | Built | `pre_milp/n0_sensitivity.py` `compute_sensitivity_hvdc_n0`, `pre_milp/nx_sensitivity.py` `compute_sensitivities_nx(hvdc_ei_mrids=...)`; `test_rao_hvdc_sensitivity.py` (finite-difference check) | INJECTION_ACTIVE_POWER on the EI generators, AC and DC, N-0 and N-X; guards: all-zero N-0 = error, all-zero N-X in a contingency = group unavailable there, solved-network check (D64). |
| R6.3 | HVDC MILP variables and balanced group constraint | BUC14#55, §3.6.11 | Deviation (D60, H14 1) | `milp/milp_builder.py` `_add_hvdc_block`; `test_rao_hvdc_milp.py`, `test_rao_hvdc_pipeline.py` | Balance dg1 + dg2 = 0 instead of the printed formula 3.61; costs in the objective (SF3077 has no HVDC term); floats instead of Integer; direct EI link instead of GLSK. All deviations: section 4c. |
| R6.4 | HVDC curative remedial actions | BUC14#55 | Deviation (D63, H14 2, 8) | `milp/milp_builder.py` `_add_curative_hvdc_block`; `pre_milp/hvdc_units.py`; `test_rao_hvdc_milp.py` `TestCurative*`, `test_rao_hvdc_pipeline.py` `TestCurative*` | The functional spec defers curative HVDC; it is modelled here, with exact bounds per contingency (the spec gives none). |
| R6.5 | Countertrade parsing and GLSK strategies | CORNET-4847, CORNET-4848 | Deviation (D70, D71, D72, C14 3, 7) | `pre_milp/ct_units.py` `parse_ct_remedial_actions`, `resolve_zone_units`; `pre_milp/ct_weights.py`; `test_rao_ct_parser.py`, `test_rao_ct_weights.py`, `test_rao_ct_mock.py` | Only `proportionalForRemainingCapacity` (direction-aware, from the original set points, normalised after the exclusion); other strategies and a mixed RA are ignored with a warning; the zone is mapped to its units through the Organisation profile and the EQ files. All deviations: section 4d. |
| R6.6 | Countertrade MILP variables and constraints | CORNET-73 | Deviation (D69, D73, D74, C14 1, 5, 6, 9, 12) | `milp/milp_builder.py` (`_participation_of_bid`, `_add_rd_block`, `_add_curative_rd_block`, `CtMilpInputs`); `test_rao_milp_builder_ct.py`, `test_rao_ct_pipeline.py`, `test_rao_ct_modes.py` | A CT bid is an RD bid with its own weights per direction; CT is in the global and the per-contingency balance, in the RA count and the group caps; preventive and curative, in all three modes. |
| R6.7 | CT technical limits for generating units | CORNET-4849 | Deviation (D73, C14 4, 13) | `milp/milp_builder.py` (`pmax_pmin_constraint`, `ct_on_off_up/down`, curative Pmin/Pmax rows); `test_rao_milp_builder_ct.py` | Hard Pmin/Pmax rows on the combined RD + CT total (preventive and per contingency) instead of the adaptive weight recalculation (`MaxAdaptionCT`); one-sided on/off rows for CT. |
| R6.8 | System constraints — active power limits | CORNET-498 | Not built | none | Only per-unit Pmax/Pmin (R2.4, R3.7). |
| R6.9 | System constraints — current limits | CORNET-537 | Not built | none | Only per-branch PATL/TATL constraints (R1.5, R3.2, R3.3). |
| R6.10 | Final consolidated results export |  | Not built | none | Result files exist for the single timestamp only. |


## 4. Deviations kept on purpose

| Topic | Spec | This prototype |
|---|---|---|
| TATL | No TATL means none is considered | No TATL constraint unless the TATL is strictly above the PATL (as the spec), with a tolerance of 1e-6 A (PATL is kA x 1000, the TATL comes from the CGM in A) |
| TATL fallback duration | - | `curative_ra.tatl_fallback_duration_s` (default 600 s, one named constant `TATL_FALLBACK_DURATION_S_DEFAULT`) is the duration of a branch without a real TATL, for the RD reaction-time check and the PST cap |
| PROD | GeneratingUnit.initialP (EQ) | SSH target_p: CGMES 3.0 has no initialP |
| Shut-down cost | Later release (CORNET-71) | Built, unit level only |
| Bid-level shut-down cost | - (NC: PowerBidSchedule.shutdownCost "overrides any cost on the specific unit") | Not used: a unit can sit in several bids with different values |
| Unconnected generating unit | Not in the redispatch (2839) | Removed from its RA's GLSK and the remaining factors renormalised (as 3012-3014 for units outside the largest subgrid), with a warning |
| Curative penalty reference | Separate curative reference (3.41) | The preventive reference |
| Missing curative penaltyFactor | 0 (BUC14#43, 5338) | 1.0 (NC default), logged |
| Currency | - | All costs taken as EUR; another currency is a warning, no conversion |
| Generator on/off for multi-unit GLSKs | Silent | Per-unit on/off binaries also for units inside multi-unit bids, written on the unit's total injection (source: Open RAO, one binary per generator); a curative bid acts if at least one unit of its GLSK is on after the preventive actions |
| Negative participation factor | Report it | The run stops with an error naming the RA and the unit (a wrong sign would silently give wrong bounds) |
| Curative RD availability (CORNET-613) | Per assessed element | Per (RA, branch), valid for every contingency (the rule has no contingency term); an unreadable `timeToImplement` counts as 0 (available everywhere) with a warning |
| Scanned-element penalties | One EUR/A parameter (8252) | Two: N-0 in EUR/kA, N-X in EUR/A |
| ER `GeneratingUnit.costCurrency` | - | Also checked for EUR (warning, no conversion) |
| Assessed element classes | - | Exactly one of secured, scanned, excluded; neither code and no exclusion reason: excluded, not optimised. Scanned-only without exclusion stays secured. Invalid exclusionReason cancels the RAO (as in the spec) |
| Pmax/Pmin | - | Missing: default 0.0 and a warning per unit (the unit is then fixed) |
| Curative RD cost | reservePrice, no energy price (BUC14#43 5317) | reservePrice when given, else the energy price (logged); a negative reservePrice is set to 0 with a warning (like a negative energy price) |
| Reactive limits | - | `use_reactive_limits` defaults to false |
| PST group kind | In data | Not in the data: taken from config (blockedGroup and a per-TSO map) |
| PATL source | - | Order: SHS, BaseCaseCurrentLimit, CGM static limit, 0 with warning |
| TSO names | - | From the Organisation profile, not from the EQ sub-region |
| Missing PST penaltyFactor / RD penaltyFactor | - | Default 1.0 with a warning |
| Bid price | - | Price of the run's timestamp; negative or missing: warning, treated as 0 |
| N-X scanned limit | - | max(PATL, original N-0 current) |
| Missing N-0 current | - | NaN, branch excluded with a warning |
| Applied taps | - | Rounded to integers when applied; continuous inside the MILP |
| Contingency analysis | FOA / FCC | Conventional AC security analysis per contingency |
| Fixed parameters | - | `START_HOUR`, `N_TIMESTAMPS`, `RAART`, per-TSO penalty overrides and the CRA-XNE linkage switch are set in code, not in config |


## 4a. Deferred and parked items

| Item | Spec reference | Status | Note |
|---|---|---|---|
| R12 (TATL constraint) | R12; CORNET-1790 | Deferred | The TATL constraint follows the spec: no real TATL above the PATL, no constraint. The 600 s fallback duration is a config value (`curative_ra.tatl_fallback_duration_s`). Open spec question, no code change planned. |
| Per-TSO penalty reference overrides | CORNET-4339 | Deferred | Hard-coded to None. Needs the TSO of each RA, the `RAOControlParameterSetForTSO` input and a separate curative reference (`penaltyReferenceRD_CRA`); to investigate with real data. |
| Hard N-0 scanned constraint without preventive RAs | CORNET-439 | Built (19 Oct 2026) | A hard scanned N-0 row with a constant left side (no preventive RA touches it) is a satisfied row and builds (`milp/milp_builder.py`, found with curative-only HVDC); the effective limit is at least the original loading. A violated constant row would raise a clear error. The `ra_types: [rd]` / `[pst]` case of `specs/calculation_mode_specs.md` is covered by the same rule. |
| Multiple TATLs per branch, TATL duration bands or steps, R19 | CORNET-1790 | Deferred | One TATL and one TATL duration per branch; several TATLs give no TATL (row "Several TATLs on one side"). Steps with index d not built. |
| Other features not in the curative/TATL spec set | R3 (XNE links), BUC14#55 | Deferred | Links to XNEs (R3): not built (the HVDC set point is built, R6.1-R6.4; countertrade with remaining-capacity weights is built, R6.5-R6.7) (the single-pass AC and DC workflows are built, section 4b). |
| Curative balancing per assessed element; slack node types with multi-unit GLSK; curative start-up | CORNET-574, 4925 | Deferred | Outlook in the spec only. Balancing is per contingency; a curative action can neither start up nor shut down a unit. |
| Time coupling in the generator model | CORNET-47 to 50, 69, 70, 91, 4593, 4595, 4596, 6081 | Deferred | Ramps, min up/down times, start-up and shut-down processes, lead/lag times, activation cost over contiguous timestamps: not built (R4, R5 rows). |
| Spec text errors found | 6107, 4761, 5301-5317, 4098 | Deferred | `PowerBidSchedule.startupCost` is not an NC attribute (the code reads `activationCost`); `GenExtensionErList.warmStartupCost` is not an NC class; `reservePrice` exists only per time point; `initialP` is absent in CGMES 3.0. For the spec authors, no code change. |


## 4b. Calculation modes

Not a deviation table: these are further calculation modes next to the iterative RAO of the functional spec (which describes the iterative workflow, e.g. CORNET-12, CORNET-13, CORNET-16). Requirement: `docs/specs/calculation_mode_specs.md` (W1-W8) and, for `dc`, `docs/specs/dc_mode_specs.md` (D1-D10).

| Item | Spec reference | Status | Note |
|---|---|---|---|
| `workflow_toggles.ra_types` (pst, rd, hvdc, countertrade) | W1 | Built | Replaces `enable_pst_remedial_actions` and `enable_rd_remedial_actions` (no alias; the old keys stop the run with a message naming `ra_types`). A type that is not listed is not parsed and leaves no sensitivity call, MILP block or output file. `hvdc` is built (D60-D68, `docs/specs/hvdc_ra_specs.md`), `countertrade` is built (D69-D78, `docs/specs/countertrade_ra_specs.md`). |
| `workflow_toggles.calculation_mode` | W2 | Built | `ac_iterative` (default, unchanged workflow), `ac_single_pass`, `dc` (built, see the DC row). Mode and RA types are in the log and in `results_summary.csv`. |
| `ac_single_pass` | W3 | Built | A separate mode next to the iterative RAO, not a deviation: one build, one solve, one applied solution, one final check (`milp/single_pass.py`). No loops, no convergence criteria, no new-pair check, no sensitivity refresh; the pairs are those of the first build. The apply, AC load flow and N-X refresh step (`apply_solution_and_refresh`) and the model build (`build_model_at_state`) are shared with the iterative loop. The linearisation is not refreshed: overloads can remain and are reported. The final check covers every N-X pair and scanned element of the refreshed N-X analysis (PATL, TATL, scanned), not only the pairs in the model (relevant when `min_loading_threshold_pct_nx` > 0); it reports and adds no pair. |
| Outputs of `ac_single_pass` | W4 | Built | Status `SINGLE_PASS`; `results_iteration_history.csv` one row with `n/a` in the criterion columns; `results_completeness_iterations.csv` row 0 only (written whenever N-X is on, as in the iterative mode); `final_check_*` summary metrics (`n0`, `nx_patl`, `nx_tatl`, `nx_scanned`; `final_check_nx_evaluated` False when N-X is off). |
| GUI and configuration | W5, D6 | Built | Per-run selection of RA types and mode (`ac_iterative`, `ac_single_pass`, `dc`) on the main page; the caps and convergence thresholds are greyed out on the settings page in `ac_single_pass` and `dc` (the chosen mode is kept across pages in a non-widget session key); settings saved before `ra_types` existed are migrated. The DC factor table is edited in the config file only (the GUI reads it from the active `rao_config.yaml`); the load flow page does not accept `dc_power_factor` = 0. |
| DC calculation mode (`dc`) | W6, `docs/specs/dc_mode_specs.md` D1-D10 | Built | A separate mode: DC load flow, DC N-X security analysis and DC sensitivities (active power, converted to ampere by one rule: `pre_milp/dc_conversion.py`, factor table `dc_mode.current_factor_by_nominal_voltage_kv`, `dc_power_factor` of the load flow config), one MILP build and solve, one apply, one final AC check that only reports (`milp/dc_pass.py`). No initial AC load flow. The AC calculation functions take an optional `dc_converter` (None = unchanged AC path); there is no separate DC backend object (D8.1). `dc_mode` and `dc_power_factor` are checked only in `dc` (D6.3, DECISIONS 57). Final AC load flow not converging: the DC solution is kept, `final_check_evaluated` False, the N-X result files show the model's prediction. One extra AC load flow at the unmodified state gives the fallback start voltages on the failure path only. DC-only summary rows: `dc_power_factor`, `dc_voltage_levels_with_factor`, `final_check_basis`, `final_check_evaluated`, `final_check_reason`, `lf_basecase_basis`, `original_network_currents_basis`. The N-X sensitivity guard tolerance is 5 % in DC (DECISIONS 55, confirmed). Known limits (reactive flow, losses, overestimated sensitivities, voltage violations) are in the User Guide. |
| HVDC as RA type | W1, H1-H15 | Built | `ra_types: hvdc` in all three calculation modes; requirement `docs/specs/hvdc_ra_specs.md`; deviations in section 4c. |
| Countertrade as RA type | W1, C1-C15 | Built | `ra_types: countertrade` in all three calculation modes, preventive and curative; requirement `docs/specs/countertrade_ra_specs.md`; deviations in section 4d. |

## 4c. HVDC deviations from the functional spec (`docs/specs/hvdc_ra_specs.md` H14)

Requirement: `docs/specs/hvdc_ra_specs.md` (H1-H15), decisions D60-D68. Status of every row: implemented as stated in the right column.

| # | Functional spec | This prototype |
|---|---|---|
| 1 | Formula 3.61 as printed (and R6.3 form) | dg1 + dg2 = 0 (matches the spec's text and acceptance criteria) |
| 2 | "Must be preventive, curative future release" (6552, 6505) | Curative modelled (matches 3.61 text, 3.63, acceptance criteria) |
| 3 | EI must have "HVDC" description | Identified by RA link; a different description is only a warning (read from the EQ files) |
| 4 | Technical limits from EI minP/maxP | Same; missing limits allowed with a warning if RangeConstraints bound the unit, a side with no bound is an error |
| 5 | Set points Integer | Floats, applied unrounded |
| 6 | Cost "in objective (SF3077)" but SF3077 has no HVDC term | HVDC cost terms added to the objective |
| 7 | Acceptance criteria say linked via GLSK | Direct EI link, no GLSK (an EI that is also an RD GLSK unit is an error) |
| 8 | Curative bounds not specified | Exact per-contingency bounds, counting the preventive change of the same solve |
| 9 | Missing group data not detected | Errors for group size, foreign RA, unit without group, unit outside the solved network, no bound, two preventive units on one EI |
| 10 | Dependency predicate as in the repo parser | Both predicate names accepted |
| 11 | Penalty references PST/RD/CT only | New `penalty_reference_hvdc_pra` / `_cra` (default = the RD reference) |
| 12 | Incremental low: P0 - low (6567) | Same; the incremental down value is a magnitude |
| 13 | Predicate fix changes restrictive groups on real data | Documented exception to "identical outputs without hvdc"; fixtures show no diff |
| 14 | HVDCMaxOperating / HVDCMinOperating used as given; a CGM set point outside them is not addressed | The range is widened to include the CGM set point, with a warning (H3.4, D68) |

Not part of the model: converter losses, gradient limits, HVDC link contingencies (only "the EI is an outage element" makes the RA unavailable), the line-based model with one set point per link (the natural future model, it would replace the two-unit group).

## 4d. Countertrade deviations from the functional spec (`docs/specs/countertrade_ra_specs.md` C14)

Requirement: `docs/specs/countertrade_ra_specs.md` (C1-C15), decisions D69-D78. Developed and tested on a generated mock (`mock_data/ct_mock.py`); the repo fixture CT RA (strategy `generatorPmax`, no volumes) is ignored with a warning. Status of every row: implemented as stated in the right column.

| # | Functional spec | This prototype |
|---|---|---|
| 1 | Balancing of CT deferred to a later release (6175) | CT is in the global and the per-contingency balance (CORNET-73, R6.6) |
| 2 | Remaining capacity: Pmax - actPROD for both directions (2999) | Direction-aware: footroom actPROD - Pmin for down |
| 3 | Normalisation formula as printed (3029) | PF_g / (1 - sum of excluded PF) (the spec's example) |
| 4 | Unit limits "not considered" (5398), adaptation MaxAdaptionCT | Hard Pmax/Pmin rows on the combined total (R6.7) |
| 5 | CT and RD sharing a unit: allowed (5408) and forbidden (3044) | Allowed; one combined total per unit |
| 6 | Dynamic weights include the actions of the same solution (2963) | Weights fixed from the original set points, in all modes and iterations |
| 7 | Three strategies (explicit, proportional for generator, remaining capacity) | Only remaining capacity (default when no strategy is given, assumed with a warning; old-form `gLSKStrategy`, RA level and bid level, token after the last ".", is a deprecated fallback); other values: RA ignored with a warning |
| 8 | Integer steps `stepSizeCTRD` (8658) | Continuous volumes (as RD) |
| 9 | Penalty formulas for RD only (3.36-3.44, 4606) | The same structure for CT with `penalty_reference_ct_pra` / `_cra` (default = the RD reference) |
| 10 | Missing penaltyFactor not defined for CT | 1.0 with a log line (as RD) |
| 11 | RAOResultsCountertrade, RAOResultsExchange | Minimal files: net positions per zone and zone exchange (before/after the applied results) |
| 12 | Curative CT: cost only (8786) | Full curative modelling (as curative RD) |
| 13 | Adaptive GLSK recalculation when units hit their limits (CORNET-4849, MaxAdaptionCT) | Not implemented; the volume is reduced by the hard limit rows |
| 14 | Bid dependencies apply to CT as to RD (CORNET-4838) | Restrictive RA groups only, as RD; dependencies not implemented for RD or CT |
| 15 | Units with PROD above Pmax: Pmax := PROD (CORNET-36) | CT excludes such units; RD unchanged |
| 16 | Not stated: whether CT RAs count in the RA-count limits | They count (RA-count and group caps); the RD result files, the RA-count and group files too, list RD only |
| 17 | Not stated: where a result file is written | Only with `countertrade` in `ra_types` and a usable CT RA (as HVDC), `countertrade_glsk_resolved.csv` included |
| 18 | RAOResultsExchange | The after-state of `results_zone_exchange.csv` comes from a fresh load flow of the final network (AC in the AC modes, DC in `dc`) |
| 19 | Not stated: the strategy predicate | `gLSKStrategy` on the RA (and optionally its bids) is an implementation choice (C13) |
| 20 | Not stated: a unit with an unbounded or NaN limit | Excluded from CT (RD unchanged) |
| 21 | Curative test data | No existing contingency overloads a GA_BO tie; the mock adds an outage of TieLine_GA_BO5 (both halves) with a curative PATL of 200 A |
| 22 | Exact relief of a fixed-weight model | `ac_single_pass` leaves a linearisation residual (about 1.4 A over the PATL on the mock, as an RD-only single pass); `ac_iterative` converges |

`results_generating_units.csv` with a usable CT RA: RD columns = RD part, `ct_volume_net_mw` = CT part, `result_production_mw` = initial + RD + CT (D79, C11.5); CT-only units are own rows after the RD units, RD columns 0 (D80).

Implementation choices not in the functional spec (details in DECISIONS 69-78): a CT RA is an RD unit per movable unit of its zone with `countertrade=True`, its bids carry their own participation (`RdMilpInputs.bid_participation`); the zone's units come from `BiddingZone` <- `SchedulingArea` -> `ControlArea` <- `ControlAreaGeneratingUnit` (Organisation profile and EQ files; generators without a unit id or area are dropped with a log line); a unit with an unbounded or NaN limit on either side is excluded; CT counts in the RA-count limits; the RD result files stay RD-only (the RA-count and group files too); the `gLSKStrategy` predicate names are an implementation choice, unconfirmed against the ENTSO-E profile (C13).

Not part of the model: the strategies `explicitInstruction` and `proportionalForGenerator`, loads in the GLSK, merit-order GLSK, weights that depend on the actions of the same solution, integer volume steps, time coupling, the full result blocks RAOResultsCountertrade and RAOResultsExchange.

## 5. Out of scope (decided)

SPS (BUC14#131, 111); topological RAs (BUC14#84, 85, 105, 146); CoMo formats and updates (CORNET-4841/4842/4844/4845/4846, SF2927); HPC manager and runtime estimate (BUC14#130, 83); production export formats (CORNET-3697/4344); RA status from RAC (BUC14#115); load-flow internals (CORNET-103-106); per-node and 3-winding results (CORNET-107/109); RTE-specific TATL (CORNET-2586); multi-terminal HVDC (a two-converter link is built, R6.1-R6.4); end-of-timeframe min up/down.


## 6. Behaviour in the code that the plan does not mention

One row each: item, where, what it does, whether DECISIONS/ASSUMPTIONS document it.

| Item | Where | What it does | In DECISIONS / ASSUMPTIONS |
|---|---|---|---|
| Required config files, no fallback | `run_pipeline.py:138-154` | Missing `rao_config.yaml` / `load_flow_config.yaml` stops the import | yes (D19) |
| `ConfigKeyError` | `run_pipeline.py:170-189` | Missing key names the dotted key and the file | yes (D19) |
| Config range checks | `run_pipeline.py:192-251` | 9 thresholds ≥ 0, 5 integer keys ≥ 1 (incl. `curative_ra.tatl_fallback_duration_s`), solver limit/gap, CSV switch boolean | yes (D19, D38) |
| `curative_ra.tatl_fallback_duration_s` | `run_pipeline.py`, `pre_milp/nx_security_analysis.py` `compute_tatl_data` | TATL duration (default 600 s) of a branch without a TATL; used for the PST cap and the RD reaction-time check | no |
| Optional `{TSO}_ER.xml` and SIS `UnitCostSchedule` | `pre_milp/ncp_loader.py`, `pre_milp/ncp_parser.py` `parse_unit_costs` | Generating-unit start-up / shut-down costs; absent: no start-up or shut-down | no |
| Unknown-TSO warning for tap overrides | `run_pipeline.py` `warn_unknown_tso_names` (called in `main`) | Warns per unknown TSO name in `max_taps_per_tso_overrides` only | no |
| `ra_limits.max_taps_per_tso_overrides` | `run_pipeline.py` `MAX_TAPS_PER_TSO_OVERRIDES`, `milp/milp_builder.py` `_add_pst_block` (`limit_overrides`) | Per-TSO override of the tap limit | no |
| `workflow_toggles.pst_taping_discrete` | `run_pipeline.py` `PST_TAPING_DISCRETE`, `milp/milp_builder.py` `_add_pst_block` (`tap_domain`) | Integer or continuous preventive taps | no |
| `workflow_toggles.ra_limit_constraint_hard`, `ra_limits.ra_limit_penalty` | `milp/milp_builder.py` `_add_ra_activation_and_count_constraints`, `build_n0_milp_model` (RA-count slack penalty) | Hard or soft per-timestamp RA count; penalty per RA over a limit | no |
| `workflow_toggles.scanned_element_constraint_hard`, `penalty_costs.scanned_element_penalty_eur_per_ka` | `milp/milp_builder.py` `build_n0_milp_model` (`scanned_element_n0_rule`, scanned slack penalty) | Hard N-0 scanned constraint (can make the solve infeasible) or slack priced in EUR/kA | yes (D23, partly) |
| Separate N-X penalty rates (PATL, TATL, scanned) | `run_pipeline.py:331-333`, `milp/milp_builder.py:1769-1791` | Three slack prices for the N-X constraint kinds | no |
| `logging_options.debug_log_mode` | `run_pipeline.py` `DEBUG_LOG_MODE`, `milp/milp_builder.py:25-36` | Hides solver trace and repeated INFO lines | no |
| Fixed parameters `START_HOUR`, `N_TIMESTAMPS`, `RAART`, per-TSO penalty overrides, `ACTIVATE_CRA_XNE_LINKAGE` | `run_pipeline.py` `START_HOUR`, `N_TIMESTAMPS`, `RAART`, `PENALTY_REFERENCE_PST_PRA_PER_TSO`, `PENALTY_REFERENCE_RD_PRA_PER_TSO`, `ACTIVATE_CRA_XNE_LINKAGE` | Hard-coded run constants | yes (D30) |
| Input discovery `cgm*` / `ncp*` | `run_pipeline.py:102-126` | Exactly one zip per prefix in `input/`, else stop | no |
| NCP zip duplicate-name check | `pre_milp/ncp_loader.py:80-96` | Two entries with one base name stop the run | no |
| Known-irrelevant NCP files | `pre_milp/ncp_loader.py:25-61`, `classify_extracted_ncp_files` | SSI, CD_OR, other profiles, cross-TSO exports skipped silently | yes (D37) |
| Stale output deletion | `output_file_registry.py:57-74`, `run_pipeline.py:370-377` | Deletes registered result files of an earlier run at start | no |
| `run_log.txt` | `run_pipeline.py:364-366` | Log file, overwritten per run | no |
| One LF parameter set everywhere | `pre_milp/lf_parameters.py:18-30` | Same parameters for LF, security and sensitivity analyses | yes (D10) |
| Contingency propagation off | `pre_milp/lf_parameters.py:33-46` | Security analysis trips only the listed equipment | yes (D11) |
| `component_mode` MAIN_SYNCHRONOUS, `use_reactive_limits` false | `config/load_flow_config.default.yaml:23`, `:75` | LF settings the loop depends on | yes (D32, D36) |
| `performance.lf_thread_count`, solver time limit and MIP gap, `outputs.write_nx_sensitivity_csvs` | `pre_milp/lf_parameters.py:11-15`, `milp/milp_solver.py` `SOLVER_TIME_LIMIT_SECONDS`, `SOLVER_MIP_REL_GAP`, `solve_n0_milp_model`, `run_pipeline.py` `WRITE_NX_SENSITIVITY_CSVS` | Run-time settings | yes (D38) |
| PATL source chain incl. `BaseCaseCurrentLimit` | `pre_milp/ncp_parser.py:297-332` | SHS, then AE normalValue, then CGM static, then 0 | yes (D34) |
| SHS vs CGM PATL difference warning | `pre_milp/ncp_parser.py:306-312` | Warns when SHS PATL differs > 10 % from the CGM static PATL | no |
| CurrentLimit side from EQ `sequenceNumber` | `pre_milp/ncp_parser.py:502-555` | Side 1/2 of each AE limit | yes (A12) |
| One must-study flag for all timestamps | `pre_milp/ncp_parser.py` `parse_contingencies` | `normalMustStudy` copied to every timestamp | no |
| Contingency equipment-type check (8 of 9 types) | `pre_milp/cgmes_loader.py:361-387`, `pre_milp/ncp_parser.py:406-422` | Unknown equipment dropped, empty contingency excluded | yes (D37) |
| Likely network split detection | `pre_milp/nx_security_analysis.py:45-68` | Contingency with a monitored branch missing from results is skipped | no |
| TATL = PATL with 600 s; TATL < PATL raised | `pre_milp/nx_security_analysis.py:239`, `:311-376` | TATL fallbacks | yes (D14) |
| 3-winding PSTs out of sensitivities | `pre_milp/n0_sensitivity.py:86-111`, `pre_milp/nx_sensitivity.py:37-64` | Left out with a warning | yes (D37) |
| N-0 sensitivity loading pre-filter keyed on the sensitivity threshold | `pre_milp/n0_sensitivity.py` `_get_loading_filtered_branch_sides`, called in `compute_sensitivity_pst_n0`, `compute_sensitivity_rd_n0`, `compute_sensitivity_hvdc_n0` | Branches with loading below `sensitivity_threshold_pct_*` are not requested from the analysis | no |
| Degrees per tap averaged | `pre_milp/cgmes_loader.py:210-260` | (alpha_last − alpha_first)/(steps − 1); non-uniform steps warned | no |
| Duplicate matrix label: first value | `pre_milp/nx_sensitivity.py:146-173` | Warns and uses the first row/column | no |
| Sensitivity guard and reuse | `pre_milp/sensitivity_checks.py:29-203` | Reference-current check, last-valid-set reuse, stop | yes (D12) |
| Initial invalid sensitivities stop the run | `run_pipeline.py` `main` (raises `SensitivityGuardError`) | `SensitivityGuardError`, minimal outputs | yes (D12) |
| Cumulative MILP against the original state | `milp/milp_builder.py:399-436`, `:567-611` | Tap limit, bid headroom, RA count and cost on cumulative change | yes (D4) |
| Applied taps integer-rounded | `milp/ac_convergence_loop.py:112-115`, `:739-742` | Rounded before apply and read back | yes (D4) |
| Incremental AC fallback | `milp/post_ra_congestion_check.py` `_apply_changes_incrementally`, `iteration_caps.incremental_ac_fallback_max_steps` | Stepwise warm-started apply after a failed direct LF | yes (D8, D36) |
| Convergence criteria 1/3/4, shared tap/MW threshold | `milp/ac_convergence_loop.py:584-840`, `run_pipeline.py:1083-1085` | OR of criteria; MW uses the tap-sum value | yes (D6, D9) |
| Cycle exit and member selection | `milp/ac_convergence_loop.py` `run_post_rao_ac_verification_loop` (`find_cyclic_repetition`), `resolve_cyclic_repetition`, `:983-1066` | `CYCLIC_REPETITION`, best member re-applied | yes (D7, D24) |
| Statuses `AcVerificationStatus` | `data_model.py:43-87` | 8 statuses incl. `SENSITIVITY_INVALID`, `SOLVER_NON_OPTIMAL`, `NOT_APPLICABLE` | yes (D22-D24, partly) |
| Results describe the original network when nothing applied | `milp/ac_convergence_loop.py:249-288`, `:886-898` | Variables zeroed, slacks = overload | yes (D22) |
| Empty generator read-back stop | `milp/ac_convergence_loop.py:659-668` | Stops before applying | yes (D25) |
| Lost-contingency count at N-X refresh | `milp/ac_convergence_loop.py` `apply_solution_and_refresh` | Column `nx_contingencies_lost_at_refresh` | yes (A1) |
| Graceful "nothing to optimise" exit | `run_pipeline.py` `main` (the "has anything to optimise" exit) | Ends after preprocessing when PST, RD and N-X are all absent | no |
| radp default and strict lead-time test | `milp/milp_builder.py:178-198` | radp = timestamp − 60 min; usable only strictly after radp + lead time | no |
| ISO durations with a day part | `pre_milp/ncp_parser.py` `_parse_iso_duration_hours_or_none` | The day part is read for every duration: RD/PST `timeToImplement`, PST `timePerStage` and bid `leadTime` (P1D = 24 h; before 2026-10-16 a lead time of P1D was read as 0 h). A non-zero year or month is not a fixed duration: unreadable (lead time 0; RD reaction time 0 with a warning). All leadTime values of the input and the fixtures are P0Y0M0DT0H0M0S (0 h, unchanged). Test: `test_a_bid_lead_time_with_a_day_part_is_read_in_hours` | yes (reference/spec/curative_rd_tatl_specs.md R9 note) |
| Curative RD "in operation" gate | `milp/milp_builder.py` `_add_curative_rd_block` (`_curative_gate`, `curative_rd_unit_gate`) | F2 unit status, not the original target_p > 0: a curative bid acts if at least one unit of its GLSK is on after the preventive actions (volume <= available MW x sum of the units' on/off binaries; a continuous unit that is on counts 1); a bid containing a unit that cannot be started is fixed to 0 | yes (reference/spec/curative_rd_tatl_specs.md R4, F2 rule 9) |
| Curative RD cost on the max over contingencies | `milp/milp_builder.py:956-974`, `:1720-1736` | Pays the worst-case reservation once | no (D31 covers the price only) |
| Curative PST penalty summed over contingencies | `milp/milp_builder.py:1656-1675` | Sum, not max | no |
| Curative PST that is an outage element | `pre_milp/cra_preprocessing.py:79-81` | No curative entry for that contingency | no |
| PST group kind from config | `pre_milp/cra_preprocessing.py:145-253` | blockedGroup/reducedGroup per TSO | yes (D33) |
| Two RAs on one transformer | `milp/milp_builder.py:302-316`, `:335-344` | Modelled once; different penalties: the larger | no |
| Scanned limit anchored to original LF | `milp/milp_builder.py:1513-1519` | max(PATL, original N-0 current) | yes (D29) |
| GLSK renormalisation | `pre_milp/glsk_resolver.py:177-220` | Units not in the network removed, rest rescaled to sum 1 | no |
| RA-count tolerance in the export | `post_milp/n0_results_export.py:605` | RA counted when net volume > 1e-6 MW | no |
| `remaining_overload_count` from MILP slack | `post_milp/n0_results_export.py` `extract_results_summary` | Secured branches with N-0 slack > 1e-6 A | yes (A) |
| `objective_residual_eur` | `post_milp/n0_results_export.py` `extract_results_summary` | Objective minus all reported cost components | no |
| `results_iteration_history.csv` | `post_milp/n0_results_export.py:1286-1313` | One row per solve: criteria, statuses, guard counts, timings | no |
| `results_tso_tap_limits.csv` | `post_milp/n0_results_export.py:307-363` | Taps used, limit, headroom, binding per TSO | no |
| `results_curative_pst_groups.csv` | `post_milp/n0_results_export.py:246-304` | Common curative delta per group and contingency | no |
| `results_contingency_status.csv` | `post_milp/nx_results_export.py:219-262` | Converged, skip reason, in MILP, guard result per contingency | yes (A1) |
| Diagnostic inputs `co_flat_list.csv`, `glsk_resolved.csv`, `tatl_data.csv`, `pst_cra_availability.csv`, `lf_nx_initial.csv`, `scanned_element_list.csv` | `output_file_registry.py:13-43` | Preprocessing results written to `output/` | no |

## 7. Spec items the code ignores

Parsed or present in the data but unused, used with a default, or skipped. "Warning" = whether the run logs it.

| Item | Where | What happens | Warning |
|---|---|---|---|
| `RotatingMachineAction.raiseRampRate` / `lowerRampRate` (old form; not in the profile) | `pre_milp/ncp_parser.py` `parse_rd_units` | Parsed into `RDUnit` in the old form only, never used; the standard `RedispatchRemedialAction` has no ramp rates | no |
| `PowerBidSchedule.activationCost` | `pre_milp/ncp_parser.py` `parse_rd_units`, `milp/milp_builder.py` `rd_bid_activated` | In the objective for preventive bids with a cost > 0 (one binary per such bid; the time-point value overrides the schedule value); not charged for curative bids (6097) | no |
| `PowerBidSchedule.minEnergyBid` / `maxEnergyBid` | `pre_milp/ncp_parser.py` `parse_power_bids` | Parsed, never used | no |
| `PowerBidSchedule.stepSizeCTRD` | `pre_milp/ncp_parser.py` `parse_power_bids` | Parsed, never used | no |
| `PowerBidSchedule.penaltyFactor` (old form; not in the profile) | `pre_milp/ncp_parser.py` `parse_power_bids` | Parsed (missing = 0.0), never used; deprecation warning once per file | no |
| Bid prices and volumes of other timestamps | `pre_milp/ncp_parser.py` `parse_power_bids` | Volumes kept per timestamp, only `START_HOUR` used; other prices dropped | no |
| PATL of other timestamps | `pre_milp/ncp_parser.py` `parse_assessed_elements` | Resolved per timestamp, only `START_HOUR` used | no |
| `normalMustStudy` per timestamp | `pre_milp/ncp_parser.py` `parse_contingencies` | One value for all timestamps; missing = not studied | no |
| Contingency type (Ordinary / Exceptional / OutOfRange) | `pre_milp/ncp_parser.py:387-391` | Parsed, all treated alike | no |
| `AssessedElementWithContingency` link | `pre_milp/ncp_parser.py` `parse_assessed_elements` | Parsed as a plain AE; every secured branch is monitored under every contingency | no |
| `AssessedElementWithRemedialAction` (CRA–XNE link) | `run_pipeline.py` `ACTIVATE_CRA_XNE_LINKAGE`, `pre_milp/ncp_parser.py:663-672` | AE path never passed, `linked_xne_mrids` always empty, linkage off | no |
| PST operating and relative tap limits | `pre_milp/ncp_parser.py:742-744`, `data_model.py:161-162` | Not read; operating range = CGM hardware range | no |
| `normalPositiveVirtualMargin` | `pre_milp/scanned_elements.py:55` | Not parsed; margin 0 | no |
| PSTGroupKind | `pre_milp/cra_preprocessing.py:145-147` | Not in data; config value used | no |
| Curative RD reservation price | `pre_milp/ncp_parser.py` `parse_rd_units`, `milp/milp_builder.py` `curative_rd_reservation_price_eur_mw` | `PowerBidScheduleTimePoint.reservePrice` of the run timestamp is parsed and used; missing: the energy price (logged once per bid and run); negative: 0 | yes |
| RA availability reference time (RAART) | `run_pipeline.py:346` | Not read; radp = one hour before the timestamp | no |
| RemedialAction `timeToImplement` of preventive PSTs and RD | `pre_milp/ncp_parser.py` `parse_psts`, `parse_rd_units` (`_parse_reaction_time_minutes`) | Read for every PST and RD RA; used only for curative ones (PST cap, RD reaction time vs TATL duration); unreadable RD value = 0 | yes (RD, unreadable value) |
| AE via DCTieCorridor / PowerTransferCorridor / OperationalLimit only | `pre_milp/ncp_parser.py:187-198` | Skipped | no (INFO) |
| AE on equipment that is not a line or 2W transformer | `pre_milp/ncp_parser.py:210-219` | Skipped | no (INFO) |
| Scanned-only AE | `pre_milp/ncp_parser.py:287-295` | Treated as secured | no (DEBUG) |
| CoMo equipment type "bus" | `pre_milp/cgmes_loader.py` `build_equipment_mrid_to_type` | Not mapped; equipment dropped as "not found in CGM" | yes |
| `RedispatchRemedialAction` / `CountertradeRemedialAction` | `pre_milp/ncp_parser.py:904-942` | Ignored with their bids (a `CountertradeRemedialAction` is read by `pre_milp/ct_units.py` when `countertrade` is in `ra_types`) | yes |
| PowerShiftKeyStrategy distributions | `pre_milp/glsk_resolver.py:87-118` | Not used | no |
| NCP profiles SSI, CD_OR, PS, RAS, FAP, cross-TSO CO | `pre_milp/ncp_loader.py:25-61` | Skipped (ER is read as an optional profile: generating-unit costs and costCurrency) | no |
| RA count for PST and curative RAs | `milp/milp_builder.py:1315-1344` | Only preventive RD RAs counted | no |
| RA group limits for curative bids | `milp/milp_builder.py:1391-1412` | Only preventive bids capped | no |
| Missing `normalAvailable` (PST, RD) | `pre_milp/ncp_parser.py` `parse_psts`, `parse_rd_units` | Not available | no |
| Missing or unknown `RemedialAction.kind` | `pre_milp/ncp_parser.py` `parse_psts`, `parse_rd_units` | Preventive | no |
| Missing bid direction / lead time | `pre_milp/ncp_parser.py:1109-1114` | UP / 0 h | no |
| Missing PST or RD RA `penaltyFactor` | `pre_milp/ncp_parser.py` `parse_psts`, `parse_rd_units` | 1.0 | yes |
| Missing generator Pmax/Pmin | `pre_milp/cgmes_loader.py:476-488` | 0.0 (unit fixed) | yes |
| Missing or negative bid price | `pre_milp/ncp_parser.py:1131-1143` | 0 | yes |
| Several TATLs on one side | `pre_milp/nx_security_analysis.py:337-343` | No TATL for the branch | yes |
| Curative PST timing missing | `pre_milp/cra_preprocessing.py:62-70` | PST not available as curative RA | yes |

## 8. Open questions for the domain expert

From the code analysis of 2026-09-29, filtered: questions answered by later decisions are removed. Check each against `docs/ASSUMPTIONS.md` before you ask.

1. **RAART / radp.** With no RAART, radp = t - 60 min, so every bid with lead time >= 1 h is unusable. What is the intended meaning, and is 60 min a business rule?
2. **Current-magnitude constraints.** Loading constraints are one-sided upper bounds built from a signed sensitivity (no absolute value). Expected approximation, and how to treat a sign change of the current?
3. **TATL data.** On the mock input 18 of 29 TATLs were below PATL and were raised to PATL. Data issue or expected?
4. **SHS vs CGM PATL.** A 10 % difference triggers a warning. Which source is authoritative; is 10 % a business tolerance?
5. **Excluded AEs.** They can still supply a limit for pruning and `lf_basecase.csv`. Should an excluded AE carry a limit at all?
6. **Scanned margin.** `virtual_load_margin_pct` is 0 as produced. What margin is expected?
7. **Penalty values.** All seven penalty costs are placeholders; one is in EUR/kA and the rest in EUR/A. Real values and units?
8. **Shared tap changers.** In the input every PST tap changer has one preventive and one curative action. What does that mean operationally?
9. **CRA-XNE linkage.** `linked_xne_mrids` holds AE mRIDs while the builder compares branch mRIDs. Do they coincide in real data?
10. **Dataset.** The test dataset has no curative RD, the default mock input has 16 curative RD bids. Which reflects the target?
11. **max_taps_per_tso.** Currently 6 for all (range 5-7). Is it TSO specific in reality?
12. **Convergence thresholds.** `max_change_ra`, `max_change_overload` (1.0 each) have no spec default. One threshold is used for both taps and MW. What values and units?
13. **Loadings above 100 % with zero slack.** Five N-X pairs on mock data show 101-120 % while all slacks are 0. Expected reading of the loading columns?

### Standard-form NCP data (WP1 to WP8, 23 Oct 2026)

The readers take the standard form of RemedialAction 2.5 / StateInstructionSchedule 2.5 first, the old mock form as a deprecated fallback: group limits through the schedule chain, bids with the
`MarketRegulationDirectionKind` literal (skipped with a warning when missing) and `interpolationKind`, redispatch as `RedispatchRemedialAction` with units from the shift keys (both routes) mapped to generators,
countertrade without a strategy attribute, `combinationConstraintKind` (`excluded` removes the RA for that contingency), HVDC penalty default 1.0. Not read, warned about: per-RA volume caps, bid dependencies,
availability schedules, disabled assessed elements, `isFixed`, energy totals, minimum activation, step increment. See `archive/ncp_standard_alignment.md` section 10 and `data/ncp_data_requirements.md`.
