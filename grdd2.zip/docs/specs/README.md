# Specs

Requirement specs of the features built after the first specification (`reference/spec/specs.md`):
- `calculation_mode_specs.md`: the calculation modes `ac_iterative`, `ac_single_pass`, `dc` and how the RA types combine with them.
- `dc_mode_specs.md`: the DC calculation mode.
- `hvdc_ra_specs.md`: the HVDC remedial action (`ra_types: hvdc`).
- `countertrade_ra_specs.md`: the countertrade remedial action.

The curative RD / TATL spec is `reference/spec/curative_rd_tatl_specs.md` (`reference/` is not edited).
