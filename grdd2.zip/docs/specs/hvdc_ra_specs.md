# HVDC RA specs (`hvdc_ra_specs.md`)

Status: implemented (19 Oct 2026; DECISIONS 60-68, Spec_Coverage 4c). Source: functional spec BUC 14#55 and 14#109 (reference/spec/specs.md ~6430-6720), rewritten. The functional spec is a reference, not binding; deviations are listed in section 14. The code is the source of truth for "today".

## H1. Purpose and activation

- H1.1 HVDC RAs change the active power set point of an HVDC link as a decision variable, preventive and curative.
- H1.2 New `ra_types` value `hvdc` (next to `pst`, `rd`). Any combination is allowed. Without `hvdc` nothing changes: outputs are identical to the version before this feature.
- H1.3 HVDC RAs work in all calculation modes (`ac_iterative`, `ac_single_pass`, `dc`). The DC-mode statement "HVDC as decision variable is out of scope" (dc_mode_specs.md) was removed.
- H1.4 Curative HVDC RAs need N-X analysis on (same as curative RD).
- H1.5 If `hvdc` is in `ra_types` and the NCP has no HVDC RA: log line, no error; if nothing else is optimisable, the existing graceful "nothing to optimise" exit is used.

## H2. Input data (NCP)

- H2.1 An HVDC unit is a `GridStateAlterationRemedialAction` whose action is an `EquivalentInjectionAction` pointing to an EquivalentInjection (EI) of the CGM. Class and property names are taken from the fixtures (nc:EquivalentInjectionAction, EquivalentInjectionAction.EquivalentInjection, EquivalentInjection.p); they are verified against the NCP_sample_generic_2_4 and mock files.
- H2.2 Identification is by this RA link. A description starting with "HVDC" on the EI is not required; if missing, a warning only. The check reads the EQ XML (pypowsybl does not expose descriptions) and is done in the pipeline wiring.
- H2.3 Per RA: availability preventive/curative, contingency links, reaction time, `penaltyFactor`, `RangeConstraint`s.
- H2.4 Group: `RemedialActionGroup` with `RemedialActionDependency` of kind `balanced`. The parser accepts both predicate names (`...RemedialActionGroup` and `...DependingRemedialActionGroup`) for balanced and restrictive groups.
- H2.5 The EI is turned into a generating unit in generation sign (as the network loader already does). P0 = its target_p in the CGM.

## H3. Range of a unit

- H3.1 `RangeConstraint` is read with direction (up / down / upAndDown) and valueKind (absolute / incremental). Only the static range type counts. If several ranges apply in one direction, the most restrictive wins (the lowest maximum, the highest minimum; for absolute down ranges that is the highest value). Values are in generation sign; "up" means more injection into the AC grid.
- H3.2 Operating limits (the spec's HVDCMaxOperating / HVDCMinOperating):
  - max = min(maximumSetpoint, highSetpointAbsolute), or min(maximumSetpoint, P0 + highSetpointRelative)
  - min = max(minimumSetpoint, lowSetpointAbsolute), or max(minimumSetpoint, P0 - lowSetpointRelative)
  - Direction upAndDown with a single value v is a symmetric range: absolute gives [-|v|, +|v|], incremental gives P0 +/- v.
  - Absolute values are taken literally in generation sign. Incremental values are magnitudes: up adds to P0, down subtracts from P0. P0 is the original set point of the CGM (not the current iteration value).
  - minimumSetpoint/maximumSetpoint are the technical limits of the EI (minP/maxP; Pmin may be negative). If the EI has none, they are unbounded and a warning is logged; the bounds then come from the RangeConstraints only. pypowsybl negates the SSH `EquivalentInjection.p` into target_p but passes minP/maxP unchanged; they are used as given. Assumption: EI minP/maxP are injection (generation) sign per the CIM definition and pypowsybl's import; to be verified on real HVDC data; pinned by test (`test_pypowsybl_flips_the_set_point_of_an_ei_but_copies_its_min_p_and_max_p_unchanged`, DECISIONS 61).
- H3.3 If a unit ends up with no bound on a side at all, error (the unit would be unlimited).
- H3.4 If the CGM set point P0 lies outside the resolved range [Pmin_op, Pmax_op], the range is widened to include P0 (so the unit may stay at P0) and a warning names the unit, its EI and the original and widened bounds. Without this the hard bounds would force a move (and its cost) without any overload, or make the model infeasible. An empty range (Pmin_op > Pmax_op) stays an error.

## H4. Group rules

- H4.1 A balanced group with at least one HVDC unit is an HVDC group: it has exactly two HVDC units and no other unit, otherwise error. A balanced group without any HVDC unit belongs to another RA type: it is skipped with a log line.
- H4.2 Balance (generation sign): dg1 + dg2 = 0, i.e. equal absolute change, opposite direction (corrects the printed formula 3.61).
- H4.3 Both units must be in the solved main network. If one is outside (islanded or non-synchronous side), error naming the unit.
- H4.4 The group is atomic: if one unit is unavailable (gate, reaction time, outage), both are fixed to zero change in that situation.
- H4.5 An HVDC unit without a group is an error.
- H4.6 An EI that is also a unit of an RD GLSK is an error. One RA with more than one EI action is an error. A group mixing preventive and curative RAs is an error. Two preventive units on one EI are an error (a set point has one preventive RA); a preventive and a curative unit on one EI are allowed. A unit in two HVDC groups is an error, checked over all groups before a group is dropped for an unavailable unit (H4.4).
- H4.7 Atomicity and availability per branch (reaction time): the pair's term appears on a branch only if both units are available there; the variables exist if the units are available on at least one branch.

## H5. MILP: preventive

- H5.1 Per unit u: dP+_u, dP-_u >= 0 (continuous, no binaries, no on/off class), change dP_u = dP+_u - dP-_u against the original P0.
- H5.2 Bounds: Pmin_op <= P0 + dP_u <= Pmax_op.
- H5.3 Group balance per H4.2, hard equality.
- H5.4 The HVDC units do not enter the global N-0 RD balance (the group is self-balanced).
- H5.5 Effect on every monitored branch: add sum_u S_{b,u} * dP_u to the N-0 loading, scanned N-0, and N-X (PATL, TATL, scanned) constraints, exactly like RD terms.

## H6. MILP: curative

- H6.1 Variables per (unit, contingency c) after the availability rules: dPc+_{u,c}, dPc-_{u,c} >= 0.
- H6.2 Availability: no contingency link = all contingencies (R2); reaction-time availability per (RA, branch) as for RD (R9); gate = available, connected, link not an outage element of c. A contingency in which an EI or its link is an outage element makes the group unavailable in c (H4.4).
- H6.3 Bound per contingency c (exact, no max construction): Pmin_op <= P0 + dP_u + dPc_{u,c} <= Pmax_op, negative Pmin allowed.
- H6.3a A curative RA without its own RangeConstraint uses the preventive ranges of the same unit.
- H6.3b The curative maximum variables (cost) are lower-bounded only, no binaries; the exact bounds of H6.3 prevent inflation.
- H6.4 Balance per (group, c): dPc_{g1,c} + dPc_{g2,c} = 0. HVDC does not enter the R15 curative RD balance.
- H6.5 Curative effect enters the N-X PATL and scanned rows of c (not TATL, as for curative RD, R11) and the curative effect used for criterion 4.
- H6.6 Curative actions are never applied to the network; only preventive set points are written back. The post-contingency result of a curative HVDC RA is therefore the MILP prediction (the AC N-X current at the applied state plus the linearised curative effect); there is no AC N-X load flow of the curative state.

## H7. Cost

- H7.1 Config keys `penalty_reference_hvdc_pra` and `penalty_reference_hvdc_cra` (EUR/MW), also in the GUI. Default: same value as the existing RD reference.
- H7.2 Per RA `penaltyFactor` from the NCP. Missing = 1.0 with a warning (WP7, DECISIONS 108; earlier 0, non-costly). The factor can be set above 0 to limit the use of the RA. At factor 0 the pair may move anywhere inside its range at no cost and the solver can end at the edge of the range (documented in the User Guide).
- H7.3 Preventive cost: sum over both units of factor_u * ref_PRA * (dP+_u + dP-_u).
- H7.4 Curative cost: factor_u * ref_CRA * max over c of (dPc+_{u,c} + dPc-_{u,c}), as curative RD; no energy or reserve price.
- H7.5 The objective equals the sum of reported terms (existing test principle). Summary rows: sumHVDCPenaltyCost, sumPRAPenaltyCostHVDC, sumCRAPenaltyCostHVDC.

## H8. Sensitivities

- H8.1 The EI generators are added to the injection-sensitivity variables (same variable type as RD), AC and DC, N-0 and N-X. The last-valid store gets the key `hvdc`.
- H8.2 A unit outside the solved network returns zero silently; therefore the check in H4.3 is mandatory (synchronous component of the EI bus after the initial load flow). Guard: a unit with all-zero N-0 sensitivities is an error naming the unit; a unit with all-zero N-X sensitivities in contingency c makes the group unavailable in c, with a log line. The guard applies to HVDC units only.
- H8.3 N-X sensitivities for a unit are unreliable when the contingency isolates its bus or its radial tie; the existing guards apply and a log line is written.

## H9. Calculation modes and loops

- H9.1 `ac_iterative`: HVDC sensitivities are refreshed every iteration with the RD sensitivities; convergence criteria 1 and 3 include HVDC MW.
- H9.2 `ac_single_pass`: one pass with the same builders, then the final AC check.
- H9.3 `dc`: HVDC sensitivities from the DC sensitivity analysis; no extra feedback loop.
- H9.4 Write-back: preventive set points are applied to the EI generators (target_p) through the same dictionary as RD; the incremental fallback ramp includes them. The final AC check is unchanged.
- H9.5 Losses are not modelled (as in the spec). A lossless pair leaves a mismatch that goes into the slack and is visible in the final AC check.
- H9.6 HVDC MW is counted in `sum_abs_rd_change_mw`, `max_abs_rd_change_mw` and the `*_rd_*_mw` iteration-history columns, and in criteria 1 and 3. In `dc`, a run whose DC model sees no overload leaves the set points unchanged.

## H10. Outputs

- H10.1 New `results_hvdc*.csv` (preventive set points and changes per unit, curative per contingency), `hvdc_cra_availability.csv` (like the RD file), summary rows (H7.5, `ra_types`).
- H10.2 Set points are reported as floats (the functional spec has Integer) and applied unrounded. Files: results_hvdc.csv, results_curative_hvdc.csv, hvdc_cra_availability.csv, with a TSO column. Summary columns: sum_hvdc_penalty_cost_eur, sum_pra_penalty_cost_hvdc_eur, sum_cra_penalty_cost_hvdc_eur.
- H10.3 Output file registry, GUI pages, and docs (User_Guide, Spec_Coverage, DECISIONS, CHANGELOG, Data_Validation_Reference) are updated.
- H10.4 Files exist only with `hvdc` in `ra_types`; `results_curative_hvdc.csv` and `hvdc_cra_availability.csv` only with curative units and N-X on. `results_curative_hvdc.csv` has one row per (unit, contingency); `penalty_cost_eur` is per unit and repeated on its rows; `max_curative_change_mw` is the largest actual curative change of the unit. `hvdc_cra_availability.csv` has rows with scope `branch` (reaction time) and `contingency` (gate), each with `available` and a `reason` (reaction time, outage element, zero sensitivity, group atomicity with the partner's reason); contingencies without a link have no row. The N-X exports include the HVDC terms in their predicted columns; the inventory table has an HVDC column.

## H11. Link outages

- H11.1 The loader maps converter/DC-line contingency elements today as "not found". For the HVDC RA only this matters: if a contingency removes the EI, the HVDC RA is unavailable in it (H6.2). Full modelling of an HVDC link contingency (converters and DC line elements) is not defined by this spec.

## H12. Validation summary

Errors: HVDC group with other than two units or with a foreign RA; unit without group; unit in two groups; unit outside the solved network; unit with no bound; empty range; two preventive units on one EI; an EI that is also an RD GLSK unit. Warnings: EI without "HVDC" description; no technical limits; missing penaltyFactor (value 1.0); CGM set point outside its range (range widened, H3.4). Log line only: balanced group without any HVDC unit (skipped).

## H13. Mock data and tests

- H13.1 Real CGM stations cannot be used (one station per link in the solved network; balanced pairs give ~0 net effect). Tests use a mock NCP based on NCP_mock_standard.zip with two EquivalentInjectionActions: Injection_SD_EH1 (P0 418.5 MW) and Injection_SD_BO3 (P0 1.56 MW), pair effect about -2.2 A/MW on TieLine_SD-EH1; its PATL is lowered to force relief.
- H13.2 Ranges: absolute upAndDown on g1; incremental up and down on g2; a second range in one direction to prove "the most restrictive range wins".
- H13.3 Tests: preventive relief (dg1 + dg2 = 0, set point in range, cost = sum factor*ref*|d|, objective = sum of terms, XNE below PATL after AC check); curative relief in one contingency (term only in that contingency row, per-contingency balance, network set point unchanged); R9 reaction time; missing penaltyFactor = 1.0 (warning) and factor > 0 limits use; negative tests (H12); `ra_types` with and without hvdc; `ac_iterative`, `ac_single_pass`, `dc`; parser tests for both predicate names, absolute/incremental, upAndDown; no-hvdc regression (golden outputs unchanged).

## H14. Deviations from the functional spec

| # | Functional spec | This spec |
|---|---|---|
| 1 | Formula 3.61 as printed (and R6.3 form) | dg1 + dg2 = 0 (matches the spec's text and acceptance criteria) |
| 2 | "Must be preventive, curative future release" (6552, 6505) | Curative modelled (matches 3.61 text, 3.63, acceptance criteria) |
| 3 | EI must have "HVDC" description | Identified by RA link; description only a warning |
| 4 | Technical limits from EI minP/maxP | Same, but missing limits allowed with warning if RangeConstraints bound the unit |
| 5 | Set points Integer | Floats |
| 6 | Cost "in objective (SF3077)" but SF3077 has no HVDC term | HVDC cost terms added to the objective |
| 7 | Acceptance criteria say linked via GLSK | Direct EI link, no GLSK |
| 8 | Curative bounds not specified | Exact per-contingency bounds |
| 9 | Missing group data not detected | Errors per H12 |
| 10 | Dependency predicate as in the repo parser | Both predicate names accepted |
| 11 | Penalty references PST/RD/CT only | New HVDC_PRA/HVDC_CRA references |
| 12 | Incremental low: P0 - low (6567) | Same; the incremental down value is a magnitude |
| 13 | Predicate fix changes restrictive groups on real data | Documented exception to "identical outputs without hvdc"; fixtures show no diff |
| 14 | HVDCMaxOperating / HVDCMinOperating used as given, P0 outside them not addressed | A range that does not hold the CGM set point is widened to include it, with a warning (H3.4) |

## H15. Not part of this model (noted)

Losses of converters; gradient limits; line-based model with one set point variable per link (HVDC_LINE_ACTIVE_POWER, loss-aware) is the natural future model and would replace the two-unit group.
