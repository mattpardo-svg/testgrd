# Calculation mode and RA types: Feature Specs (W1-W8)

Status: agreed and implemented (17 Oct 2026). Independent review done; fixes: final check covers all pairs (W3 rule 5), GUI greying, weak tests, stale reference docs. Source: investigation report of 16 Oct 2026 (code verified by runs). Location in the repo: docs/specs/calculation_mode_specs.md.
Code is the source of truth for "today". These are new calculation modes. They do not change the iterative workflow and are not a deviation from the functional spec (reference/spec/specs.md): the functional spec describes the iterative RAO, this document adds further calculation modes next to it.

## 0. Scope

In scope: option `ra_types`, option `calculation_mode` with the values `ac_iterative` (today) and `ac_single_pass` (new), `dc` reserved (rejected with a clear message).
Out of scope: time coupling. (DC was implemented later, `docs/specs/dc_mode_specs.md`; `hvdc` was added to `ra_types` on 19 Oct 2026, `docs/specs/hvdc_ra_specs.md`; `countertrade` on 20 Oct 2026, `docs/specs/countertrade_ra_specs.md`.)

Today (verified):
- RA types exist as two booleans, `workflow_toggles.enable_pst_remedial_actions` and `enable_rd_remedial_actions` (rao_config.yaml). PST only, RD only and both run without error on the mock and the generic input, with N-X off and on.
- With the default thresholds (min loading 0) the first model already holds all N-X pairs.
- Both iteration caps = 1 is not a single pass (convergence checks, new-pair check and a second build are still possible).

---

## W1. Option ra_types

1. New config key `workflow_toggles.ra_types`: a list with values from `pst`, `rd` (and, since 19 Oct 2026, `hvdc`). Default `[pst, rd]`.
2. It replaces `enable_pst_remedial_actions` and `enable_rd_remedial_actions`. No alias: the old keys are removed from both YAML files, the GUI (1_Main.py, _gui_common.py fallback), the tests and the User Guide are migrated.
3. Validation at startup: a list, not empty, no duplicates, only `pst`, `rd`, `hvdc` and `countertrade`. Other values stop the run with a clear "not yet supported" message.
4. Meaning: a type that is not in the list is not parsed, gets no sensitivities, no MILP block and no output file. Existing behaviour is kept (verified in the runs).
5. The check "no RA type left" is replaced by rule 3 (an empty list) and runs before any parsing, so it fails fast.
6. Files of a disabled type are not written: `results_curative_pst*.csv` with PST off, `rd_cra_availability.csv` and RD result files with RD off. The summary fields of the disabled type are 0 or empty, not missing.
7. Curative-only RD with N-X on keeps opening the RD workflow (workflow_gates), as today.

Acceptance:
- Test (parametrised): `[pst]`, `[rd]`, `[pst, rd]` on both NCP zips, N-X off and on: run finishes, the other type has no sensitivity call, no block and no file.
- Test: empty list, duplicate, unknown value: clear error before parsing.
- Test: old keys in a config give a clear error that names `ra_types`.
- Existing fingerprint tests unchanged for `[pst, rd]`.

---

## W2. Option calculation_mode

1. New config key `calculation_mode` (top level of the workflow section), default `ac_iterative`.
2. Values: `ac_iterative` (today's workflow, unchanged), `ac_single_pass` (W3), `dc` (reserved). `dc` stops the run at startup with "calculation_mode dc is not yet supported". Any other value is an error listing the allowed values.
3. `ra_types` and `calculation_mode` are independent. All combinations of {pst, rd, pst+rd} and {ac_iterative, ac_single_pass} must work.
4. The mode is shown in the run log and in the results summary (`calculation_mode`, `ra_types`).
5. The default mode must leave the MILP model and all existing outputs unchanged, except the two new summary rows from rule 4.

Acceptance:
- Test: default mode gives the same model fingerprints and outputs as before.
- Test: `dc` and an unknown value stop at startup.

---

## W3. Mode ac_single_pass

One pass: AC load flow, N-X analysis and sensitivities once at the initial state, one MILP build and solve, one AC check of the result. No completeness loop, no linearisation loop.

Steps:
1. Steps 1-9 of the current pipeline run as today (initial AC load flow, parsing, N-0 sensitivities, GLSK and costs, N-X security analysis, N-X sensitivities, TATL data, availability, curative groups, initial invalid-sensitivity stop).
2. Exactly one build and one solve of the MILP at the original network state.
3. The pairs in the model are the ones the existing builder rule selects at the initial state (`min_loading_threshold_pct_nx`, default 0 = all usable pairs, plus the TATL and scanned rules). Nothing is added later.
4. Apply the solution once: preventive PST taps and RD set points to the network, AC load flow (with the existing incremental fallback), then the N-X security analysis at the applied state.
5. The final check reports the remaining overloads against PATL and TATL, N-0 and N-X, including the linearised effect of the curative actions (as the loop does today). It covers every N-X pair and scanned element in the refreshed N-X analysis, not only the pairs that are in the model (relevant when `min_loading_threshold_pct_nx` > 0). It reports; it does not add pairs and does not start another pass.
6. No convergence checks (criteria 1, 3, 4), no cyclic check, no post-RA new-pair check, no sensitivity refresh, no completeness iteration.
7. The iteration caps and convergence thresholds are ignored. One log line says so. The GUI greys out these settings in this mode. `incremental_ac_fallback_max_steps` stays active, because rule 4 requires the incremental fallback.
8. If the final AC load flow does not converge: the same behaviour as today (incremental fallback, then the original network is reported with the no_applied_solution flag).
9. The existing stop reasons before the solve (invalid sensitivities, solver not optimal) behave as today.
10. Reuse: the loop functions are not changed. The single pass is a separate function that calls the same build, solve, apply, AC load flow and N-X refresh pieces. The apply, AC load flow and N-X refresh part of the loop body is moved into a reusable function used by both modes. [the implementation proposes the cut; the iterative result must stay identical]
11. The final check is a separate step that takes the calculation backend (load flow, security analysis, sensitivities as one interface), so that `dc` can be added later without touching the single-pass flow.

Accuracy note (information): the linearisation is not refreshed. On the mock data the objective was 1,021,328 after pass 1 and 1,030,987 after pass 2. Single-pass results can leave overloads that the iterative mode would remove; they are reported by the final check.

Acceptance:
- Test (spies): exactly 1 MILP build, 1 solve, 1 apply, 1 AC load flow, 2 N-X security analyses in total (initial and final), 0 sensitivity refreshes, 0 find_new_pairs calls.
- Test: caps and thresholds set to unusual values have no effect.
- Test: a case where the iterative mode adds pairs or iterates more than once: single pass still finishes with one build.
- Test: non-convergent final load flow gives the original-network report.
- Test: all six combinations (3 RA type sets x 2 AC modes) finish on the mock data.

---

## W4. Outputs in ac_single_pass

1. New `AcVerificationStatus` value for the single pass (name proposed: `SINGLE_PASS`). The existing values and names stay. GUI and exporters handle the new value.
2. `results_iteration_history.csv`: one row; criterion and `converged_by` columns contain `n/a`.
3. `results_completeness_iterations.csv`: row 0 only, written whenever N-X is on (same rule as the iterative mode).
4. Summary fields: `ac_iteration_count` = 1, `completeness_iteration_limit_reached` = False, completeness iterations = 0, `calculation_mode` = ac_single_pass.
5. The summary adds the remaining overloads from the final check: number of overloaded branches and sum of overload amperes, N-0 and N-X, PATL and TATL. `results_nx_loadings.csv` and `results_nx_scanned_elements.csv` come from the N-X state after applying (as today).
6. All other result files keep their columns.

Acceptance:
- Test: output files exist with the shapes above.
- Test: the GUI result readers do not fail on one row or on the new status.

---

## W5. Configuration, GUI, validation

1. Both options are in `rao_config.yaml` and `rao_config.default.yaml` with the same key tree (test_rao_run_pipeline.py:74).
2. GUI: a selection for the RA types (PST, RD) and for the calculation mode. `dc` is shown as not available. The GUI writes the temp config as today.
3. Validation is added to `validate_config_ranges` (list and enum checks).
4. User Guide: both options described.

Acceptance:
- Test: key tree equal in both YAML files.
- Test: GUI temp config round trip keeps both options.

---

## W6. DC mode: design constraints only (no implementation now)

1. `calculation_mode: dc` means DC load flow, DC security analysis and DC sensitivities (next release).
2. The single-pass design keeps the three calculation calls behind one backend interface, with the current result shapes: lf_n0 `{branch:{1:A,2:A}}`, lf_nx `{contingency:{branch:{1:A,2:A}}}`, sensitivities keyed by (branch, RA).
3. Open issue for the DC release: DC returns active-power flows, not currents. The model works in amperes against PATL and TATL. A defined conversion (for example nominal voltage and a fixed power factor) is needed. Not decided now.
4. Loop concepts (criteria, caps, completeness) must not leak into the single-pass path.

---

## W7. Tests

- Spies and parametrised tests as listed in W1-W5.
- Tests that set the old module constants (ENABLE_PST_..., about 8 e2e tests and helpers.py:1009) are migrated to `ra_types`.
- Fingerprint tests: default mode unchanged.
- Reset of module-level state (reset_run_log_state, DEBUG_LOG_MODE, LF_THREAD_COUNT, SOLVER_* globals) is checked for two consecutive runs in different modes in one process.

## W8. Documentation

- docs/Spec_Coverage.md: a new section "Calculation modes" (not a deviation table entry). It states that ac_single_pass is a separate mode next to the iterative RAO of the functional spec, and that dc is reserved.
- User Guide: description of both options.

---

## Open points

Decided (16 Oct 2026): ra_types replaces the two booleans without alias; all pairs up front in single pass; final check with N-X refresh and overload report; new status value; non-convergence as today; caps ignored with a log line; dc rejected at startup; fail-fast check; no files for disabled types; single pass recorded as a separate calculation mode, not a deviation.

Decided in implementation: the reusable functions are `build_model_at_state` and `apply_solution_and_refresh`; status value `SINGLE_PASS`; a failed apply in single pass reports the original network with the status `REVERTED_NON_CONVERGENT` and runs no final-check security analysis.

Parked: DC implementation and the MW-to-ampere conversion; XNE links (HVDC `docs/specs/hvdc_ra_specs.md` and countertrade `docs/specs/countertrade_ra_specs.md` are built); multiple TATLs; CORNET-4339. (The N-0 scanned constraint error when no preventive RA exists is fixed since 19 Oct 2026: a hard scanned row with a constant left side builds.)
