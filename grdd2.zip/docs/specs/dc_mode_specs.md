# DC calculation mode: Feature Specs (D1-D10)

Status: agreed for implementation, 18 Oct 2026 (after the implementation plan review). Source: DC investigation report of 17 Oct 2026 (pypowsybl 1.15.0, OpenLoadFlow 2.2.0, runs on the fixture CGM) and decisions of 18 Oct 2026. Location in the repo: docs/specs/dc_mode_specs.md.
This completes the reserved value `calculation_mode: dc` of docs/specs/calculation_mode_specs.md (W2, W6). It is a separate calculation mode next to `ac_iterative` and `ac_single_pass`. It does not change the AC modes.

## 0. Scope and facts

DC mode = DC load flow, DC security analysis, DC sensitivities, one MILP build and solve, one apply, one final AC check. One pass: no loops, no feedback from the final check.

Out of scope: losses model, voltage violations in DC, per-branch factors, calibration of the correction factors (the user adds them later), time coupling.

Facts from the investigation (verified by run):
- DC load flow (run_dc) gives p1/p2 only. q, i and bus voltages are NaN.
- The DC security analysis returns p1/p2 and i1/i2 (pre- and post-contingency rows) with I = |P| x 1000 / (sqrt(3) x V_nom,side x dc_power_factor). The documentation of PowSyBl does not describe this, so the mode does not rely on it (D2).
- DC sensitivities support only active-power functions (BRANCH_ACTIVE_POWER_1/2) with variables TRANSFORMER_PHASE (MW per degree) and INJECTION_ACTIVE_POWER (MW per MW). Current functions are refused.
- Accuracy at factor 1.0 on the fixture: current error median about 8 %, mean 15-17 % (DC underestimates on branches with high reactive flow); sensitivity error median about 9 %, mean 15-19 % (DC overestimates). DC found 1 of 3 N-0 overloads and missed 11-13 post-contingency violation pairs per fixture.
- Losses are ignored (slack 954 MW in DC against 511 MW in AC).

---

## D1. Workflow of calculation_mode dc

1. Load the CGM and the inputs as today. The initial AC load flow is not run in DC mode (confirmed: nothing needs it; only the incremental fallback needs voltages, see D5). A DC load flow that does not converge stops the run, as the AC initial load flow does.
2. DC load flow (N-0), with the pipeline's load flow parameters (distributed slack as configured, as in AC).
3. N-0 currents in A from the DC load flow p1/p2 (D2). N-X currents in A from the DC security analysis branch results p1/p2 (D2).
4. DC sensitivities N-0 and N-X (D3), converted to A (D2).
5. GLSK, unit costs, TATL data, availability, curative groups: unchanged.
6. One MILP build and one solve, as in ac_single_pass. Same RA types (`ra_types`), same constraints and objective.
7. Apply the preventive solution to the network once.
8. Final AC check (D5).
9. Exports (D7).

No convergence criteria, no caps, no completeness loop, no refresh. The same stop reasons before the solve as in ac_single_pass (invalid sensitivities, solver not optimal).

## D2. Current conversion (one rule for flows and sensitivities)

1. Current of a branch side: I = f(vl) x |P| x 1000 / (sqrt(3) x V_nom,side x pf), with P in MW, V_nom in kV, I in A.
   - V_nom,side is the nominal voltage of the voltage level on that side (transformers have different values on the two sides).
   - pf = `dc_power_factor` from load_flow_config.yaml (the existing key, default 1.0). It is the only power-factor setting: pypowsybl and our formula read the same value.
   - f(vl) = correction factor by nominal voltage, default 1.0 for every level (rule 3).
   - The converter is built once from the network and holds kV and factor per (branch, side).
2. Sensitivity in A: dI/dx = sign(P_ref) x f(vl) x dP/dx x 1000 / (sqrt(3) x V_nom,side x pf). P_ref is the DC reference flow of the same branch and side (per contingency for N-X). dP/dx is MW per degree (PST) or MW per MW (injection), so the result is A per degree or A per MW, the same units as in the AC modes. If |P_ref| is below 1e-6 MW (a constant, not configurable), the sign is +1 and one log line is written per run.
3. Correction factors: config table `dc_mode.current_factor_by_nominal_voltage_kv` with an entry `default: 1.0` and optional entries per nominal voltage in kV (for example 400, 220, 110). A branch side uses the entry of its nominal voltage (exact match: 400 matches 400.0; numeric strings from the GUI settings JSON are accepted), otherwise `default`; an unmatched level is logged once per run. All values > 0. The same factor is used for flows and for sensitivities (no separate values). The user fills real values later.
4. The conversion lives in one function. Current from pypowsybl (i1/i2 of the DC security analysis) is not used, because it cannot apply the factors and is undocumented.
5. The result shapes stay as in the AC modes: lf_n0 `{branch:{1:A,2:A}}`, lf_nx `{contingency:{branch:{1:A,2:A}}}`, sensitivities keyed (branch, RA).
6. Branch sides with NaN p (disconnected side) are excluded as today with NaN currents.

## D3. Sensitivities in DC

1. N-0: pp.sensitivity.create_dc_analysis with BRANCH_ACTIVE_POWER_1/2 and variables TRANSFORMER_PHASE (PSTs) and INJECTION_ACTIVE_POWER (RD units / GLSK). Converted per D2.
2. N-X: DC analysis with the same function and variable types, contingency context ALL as in the AC code (the SPECIFIC context with several contingencies fails in the library, as in AC).
3. `find_invalid_n0_branches` (sensitivity guard) compares reference values with the initial currents: in DC the reference is in MW and is converted per D2 before the comparison.
4. HVDC sensitivities (`ra_types` value `hvdc`, added 19 Oct 2026, `docs/specs/hvdc_ra_specs.md` H9.3) come from the same DC sensitivity analysis as the RD ones: variable INJECTION_ACTIVE_POWER on the EI generators, function BRANCH_ACTIVE_POWER_1/2 of the monitored branches, converted to ampere by the same rule.
5. The N-X reference guard compares the sensitivity reference with the DC security analysis current. In DC its tolerance is 5 % (AC: 1 %), because after a contingency that disconnects generation the two DC analyses redistribute the distributed slack slightly differently (measured worst case 1.14 %). The missing-reference, zero-reference and all-zero checks stay exact.

## D4. Starting dispatch for redispatch

1. RD headroom and Pmin/Pmax use the CGM set points (`target_p`), as in the AC modes. The DC load flow applies distributed slack to the flows only. Verified by run: target_p is unchanged after the DC load flow (113 generators, max difference 0.0); a test keeps this.
2. No other change to the generator logic (on/off, costs, R7).

## D5. Final AC check (single, report only)

1. After the preventive solution is applied, one AC load flow (with the existing incremental fallback) and one AC N-X security analysis at the applied state.
2. Remaining overloads against PATL and TATL, N-0 and N-X, including the linearised effect of the curative actions converted per D2 (the DC sensitivity conversion), reported with the same `final_check_*` summary rows as ac_single_pass. The check covers every N-X pair and scanned element (as W3 rule 5). It reports; it adds no pairs and starts nothing.
3. Fallback voltages: a DC load flow leaves all bus voltages NaN, and the incremental fallback of the apply step warm-starts from them. If the direct AC jump fails, the apply step may run one extra AC load flow at the unmodified state to obtain voltages for the fallback. The normal path has no extra calculation.
3a. If the AC load flow does not converge after the fallback: the DC solution stays as the result (the PST and RD rows of the solved model are kept and recorded in the state without a load flow), `final_check_evaluated` = False with `final_check_reason`, the overload rows are omitted, the status stays SINGLE_PASS, `solution_applied_to_network` = False in lf_post_n0.csv, and the run does not stop. The "post-PRA" / "after" columns of results_nx_loadings.csv and results_nx_scanned_elements.csv then show the model's prediction (not the initial DC state). This differs from ac_single_pass, where the original network is reported: the DC solution has no AC state that could be reverted.
4. The summary adds `final_check_basis` (= ac) so the reader knows the check is AC while the optimisation is DC.

## D6. Configuration, GUI, validation

1. `calculation_mode: dc` is accepted. The startup rejection of W2 rule 2 is removed.
2. New config section `dc_mode` in both rao_config YAML files (same key tree) with one entry: `current_factor_by_nominal_voltage_kv` (table with `default: 1.0`). The table counts as a leaf in the key-tree test (a user may add `400:` to the active file). `dc_power_factor` stays in load_flow_config.yaml; the load flow GUI validates it > 0.
3. Validation (only when `calculation_mode` is `dc`; in the other modes a missing `dc_mode` section uses the default table with all factors 1.0, and `dc_power_factor` is not checked): `dc_power_factor` a number > 0 (not a bool); the table is a dict containing `default`; keys are `default` or numeric (numeric strings accepted); values finite numbers > 0. Errors name the key.
4. GUI: `dc` becomes selectable in the calculation mode selection; the iteration caps and thresholds are greyed out as in single pass. The factor table is edited in the config file only.
5. Fix the wrong comment of `dc_power_factor` in load_flow_config.yaml (it converts current limits to power limits in the DC security analysis; it is not an HVDC setting) and the header that says the codebase runs AC only, in both load_flow_config files. Comments only, separate first step.
6. User Guide: describe the mode, the factors, and the accuracy limits (D9).

## D7. Outputs

1. Same files as ac_single_pass (one-row iteration history with n/a, completeness row 0 when N-X is on, status SINGLE_PASS, summary rows `calculation_mode` = dc and `ra_types`).
2. Summary rows, written in DC mode only (AC summaries unchanged): `dc_power_factor`, `dc_voltage_levels_with_factor`, `final_check_basis` (= ac), `final_check_evaluated`, `final_check_reason` (on failure only), the existing `final_check_*` rows, `lf_basecase_basis` (= dc) and `original_network_currents_basis` (= dc). The last two cover every file with original-network currents: lf_basecase.csv, lf_nx_initial.csv, the "initial" columns of results_nx_loadings.csv and results_nx_scanned_elements.csv, scanned_element_list.csv and the "before" side of lf_post_n0.csv. No header comments and no new columns in the CSV files (AC file shapes unchanged).
3. All currents in the result files are the converted currents in A. The label "converged=True" in the network summary print says DC in this mode.

## D8. Design constraints

1. DC mode works through an optional `dc_converter` argument on the existing compute functions (N-0 load flow, N-0 and N-X security analysis, sensitivities; default None = AC path, unchanged). There is no separate DC backend object (decided after the review: the backend load flow and basis field were never used). DC mode runs in a separate function (`run_dc_pass`) that reuses the shared build, solve, apply and final-check pieces; `run_single_pass` and the loop stay untouched. Where the AC code calls pypowsybl directly (incremental fallback, build_lf_initial), DC mode must not silently get NaN: build_lf_initial gets the DC variant (p plus D2) behind the backend.
2. Loop concepts do not enter the DC path.
3. The AC modes and all existing outputs stay unchanged. Model fingerprints of the AC modes unchanged.

## D9. Known limits (to be written in the User Guide)

- Reactive flow is ignored: currents on transformers with high reactive flow (generator step-ups) are underestimated. Overloads there can be missed. The correction factors are the lever; the final AC check shows what DC missed.
- Sensitivities are overestimated, flows are underestimated; one factor per voltage level is applied to both.
- Losses ignored; voltage violations are not seen.

## D10. Acceptance tests

- Unit: conversion function against hand calculation (P = 100 MW, V = 400 kV, pf 1.0, f 1.0 gives 144.3 A); factor per voltage level changes only branches of that level; side-specific V_nom on a transformer; PST and injection sensitivity conversion with sign of P_ref; P_ref = 0 case.
- DC mode run on the mock and the generic input, N-X off and on, for `[pst]`, `[rd]`, `[pst, rd]`: finishes, 1 build, 1 solve, 1 apply, 0 refreshes, 0 find_new_pairs, final check once (1 AC load flow, 1 AC N-X analysis).
- lf_n0 in DC mode has no NaN currents for connected branches (guards against the silent-NaN trap).
- Final AC load flow not converging: DC solution kept, final_check_evaluated False, run does not stop.
- Default and ac modes unchanged: fingerprint and existing tests.
- Config validation: invalid pf, negative factor, unknown key.
- Check against the investigation: at factor 1.0 the N-0 DC currents equal the pypowsybl DC security analysis pre-contingency i1/i2 on the fixture (tolerance 1e-9), as a regression of the formula.
- target_p is unchanged after the DC load flow (D4).

## Open points

Decided (18 Oct 2026): correction factor per voltage level, default 1.0, config table; pf = 1.0 as config value; final AC check once, no feedback; currents computed by our own formula from DC p (no reliance on pypowsybl i); one set of factors for flows and sensitivities; RD headroom on CGM set points; comment fix as a separate change.
Decided after the plan review (18 Oct 2026): one power-factor key (the existing dc_power_factor); extra AC load flow for fallback voltages on the failure path only; failed final AC load flow keeps the DC solution; separate run_dc_pass; optional dc_converter argument; scanned limits in DC use the DC-converted initial current and the final AC check reuses them (consistent with the model); DC load flow non-convergence stops the run; DC-only summary and basis rows.
Parked: calibration of the factors, per-branch factors, losses, voltage checks in DC.
