# Countertrade RA specs (`countertrade_ra_specs.md`)

Status: implemented (20 Oct 2026; DECISIONS 69-78, Spec_Coverage 4d). Sources: functional spec CORNET-4847/4848/4849, SF3077, 3.36-3.44, CORNET-73 (reference/spec/specs.md ~2933-3120, 5398-5508, 6175, 8386-8403, 8761-8921), release plan R6.5-R6.7 (reference/archive/R6_HVDC_CT_SystemConstraints.md), the countertrade investigation of 19 Oct 2026. The functional spec is a reference, not binding; deviations are listed in section C14. The code is the source of truth for "today". The input data is not valid for countertrade (the ReliCapGrid data has no CT bids, and the CT RA in the repo fixture is incomplete: no volumes, strategy value not supported); this feature is implemented and tested with a generated mock example, as for HVDC (C12).

## C1. Purpose and activation

- C1.1 A countertrade (CT) RA is a bid per bidding zone (volume, price) that shifts generation inside that zone. The volume is distributed over the generating units of the zone by a GLSK strategy. Up and down bids in different zones, balanced together with the redispatch bids, create the cross-border effect.
- C1.2 New `ra_types` value `countertrade` (next to `pst`, `rd`, `hvdc`). Any combination is allowed, including `countertrade` without `rd` (the RD wiring runs when either flag is set). Without it, nothing changes: outputs are identical to the version before this feature.
- C1.3 CT works in all calculation modes (`ac_iterative`, `ac_single_pass`, `dc`), preventive and curative. Curative CT needs N-X analysis on (same as curative RD).
- C1.4 The balancing of CT, deferred by the functional spec (line 6175), is part of this feature (C6.4).
- C1.5 If `countertrade` is in `ra_types` and the NCP has no usable CT RA: log line, no error; if nothing else is optimisable, the existing graceful "nothing to optimise" exit is used.

## C2. Input data (NCP, SIS, CD)

- C2.1 CT RA: `nc:CountertradeRemedialAction` with its bidding zone (`PowerRemedialAction.BiddingZone`), strategy, kind (preventive or curative, `RAactivationKind`), availability, linked contingencies, reaction time, `penaltyFactor`.
- C2.2 (updated by WP5, DECISIONS 107: a CT RA without any strategy is read with `proportionalForRemainingCapacity` assumed and a warning; `gLSKStrategy` is an old-form fallback with a deprecation warning; `powerShiftKey` and `method` are old-version attributes, warned about and not read) Strategy attribute (implementation choice, predicate names unconfirmed): `nc:CountertradeRemedialAction.gLSKStrategy` on the RA and an optional `nc:PowerBidSchedule.gLSKStrategy` on bids, the token being the text after the last ".". Name in the functional spec: `gLSKStrategy` (functional spec line 5400: explicitInstruction, proportionalForGenerator, proportionalForRemainingCapacity; other kinds are not considered by the RAO). Only `proportionalForRemainingCapacity` is implemented. Any other value, including the fixture's `powerShiftKey` / `generatorPmax`: the RA is ignored with a warning (confirmed by the spec owner). If several bids of one CT RA declare different strategies, the RA is ignored with a warning; all bids of one RA must share the same GLSK (functional spec 5400).
- C2.3 Bids: `PowerBidSchedule` of the RA (direction up/down, volume, price per bid in EUR/MWh, activation cost, lead time; curative bids also a reservation price). A RA may have several bids (as RD, CORNET-2006). A bid without volume has volume 0 and a warning. Energy cost = activated volume x bid price; activation cost is charged once if the bid is used (activation binary).
- C2.4 Restrictive RA groups work for CT RAs exactly as for RD (same parser and rows, keyed by the real RA id). Bid dependencies (restrictive/inclusive) are not implemented for RD and are not implemented for CT (noted gap, C14).
- C2.5 Zone to units: `BiddingZone` <- `SchedulingArea` (CD file) -> `ControlArea` -> CGM `ControlArea` <- `ControlAreaGeneratingUnit` -> `GeneratingUnit`, read from the EQ and CD XML (pypowsybl does not expose unit membership of an area). A zone that is not found, or that has no generating unit, drops the RA with a warning. Units without a unit id or without an area membership are dropped from the zone with a log line.
- C2.6 Candidate units are generating units only: no EquivalentInjection (they appear as generators with limits of ±1.8e308), no external grid, no load. Units not connected or outside the main synchronous component are removed.

## C3. Participation factors (GLSK strategies)

- C3.1 Weights are computed per CT RA and per direction, from the current set points `actPROD` (C3.5), over the candidate units of the zone.
- C3.2 Only the strategy `proportionalForRemainingCapacity` exists (no GLSK data is read from the NCP for CT; the weights come from the zone's units and their limits).
- C3.3 Remaining capacity in the direction of the variation:
  - up: PF_g = (Pmax_g - actPROD_g) / sum (Pmax - actPROD)
  - down: PF_g = (actPROD_g - Pmin_g) / sum (actPROD - Pmin), with Pmin_g = the unit's effective Pmin (Pmin of a unit in operation with Pmin > 0 is kept: CT cannot shut a unit down). A negative Pmin (consumption mode) is accepted: the footroom is actPROD - Pmin including the negative part, as RD uses the raw Pmin.
  The functional spec gives only the up form for both directions (line 2999); the footroom form for down is a deviation (C14).
- C3.4 (units) Pmax and Pmin are the unit limits of the CGM; units with an unbounded or missing (NaN) limit, even one-sided, are excluded.
- C3.5 `actPROD` = the original set point of the unit (before any RA). The weights are computed once and are the same in every iteration and in every calculation mode (`ac_iterative`, `ac_single_pass`, `dc`), preventive and curative. They never depend on the actions of the same or an earlier solve (no bilinear terms, no refresh, no adaptive recalculation). The final AC check shows the effect of the approximation.
- C3.6 Excluded units: out of operation by the F2 rule (a connected unit is on if PROD <> 0 or Pmin <= 0, so a unit with PROD = 0 and Pmin <= 0 takes part), units with PROD above Pmax (CT only; the RD rows are unchanged), and units that cannot move in the direction (up: Pmax reached; down: Pmin reached). Normalisation after the exclusion: PF_g / (1 - sum of the excluded PF) (corrects the printed formula 3029; the spec's own example needs it).
- C3.7 If no unit is left for a direction, the volume upper bound of that bid is 0 and one log line is written (as an empty RD GLSK).
- C3.8 The weights are non-negative by construction.
- C3.9 CT cannot start up or shut down a unit (units that are off are excluded from the weights).

## C4. Relation to redispatch (RD)

- C4.1 A CT bid behaves like an RD bid whose participation factors come from the zone's remaining capacity (C3) instead of a `PowerShiftKeyDistribution`. All RD machinery is reused: bid variables, bounds, net injection per unit, global balance, curative per-contingency variables, R2, R4 gate, R9, R7 (curative maxima), cost, restrictive group caps.
- C4.2 Units may be shared between CT and RD (the functional spec contradicts itself, 2933/5408 vs 3044). Both enter the same per-unit total: Pmin_g <= PROD + RD + CT <= Pmax_g as hard rows. For a unit with an on/off binary u (F2), the CT injection is restricted by u in one-sided rows (CT up <= Pmax*u, CT down <= Pmax*u): a unit that RD shuts down receives no CT injection; CT itself never changes the status of a unit. These one-sided rows are added for CT only; the existing preventive RD net-form rows stay untouched. CT bids do not count for the start-up test of a unit, and CT-only units get the same status treatment (Pmin := PROD for 0 < PROD < Pmin).
- C4.3 An EI that is also an HVDC unit is never a CT unit (excluded in C2.6).
- C4.4 Several CT RAs in one zone are allowed; each uses its own weights and the same unit totals.
- C4.5 CT RAs count as RAs in the per-TSO and per-timeframe RA-count limits (maxNumRA).

## C5. Limits

- C5.1 Per-unit Pmax/Pmin are enforced as hard rows on the combined RD + CT total (release plan R6.7 form, CORNET-4849). The functional spec says unit limits are "not considered" (5398) and describes an adaptation (MaxAdaptionCT); the adaptive GLSK recalculation is not implemented, the optimiser respects the bound and reduces the volume.
- C5.2 A log line is written for every unit whose combined dispatch hits Pmax or Pmin.
- C5.3 Bid volumes cap the up and down volume of each bid (continuous variables; `stepSizeCTRD` is not modelled, as for RD).

## C6. MILP: preventive

- C6.1 Variables per CT bid: ct_up, ct_down >= 0 (continuous), cumulative against the original state as for RD.
- C6.2 Net injection per unit: sum over bids of PF_g * (ct_up - ct_down), added to the RD net injection of the unit.
- C6.3 Effect on every monitored branch: added to the N-0 loading, scanned N-0, and N-X (PATL, TATL, scanned) rows with the injection sensitivities of the units (the units are RD-like; no new sensitivity call is needed, the CT units are added to the unit set; sensitivity pruning as for RD).
- C6.4 Balance: sum over all units of (RD net injection + CT net injection) = 0, hard equality (CORNET-73). The CT bids are therefore balanced by down bids in other zones or by RD bids.
- C6.5 Restrictive RA group volume caps apply to CT bids as to RD bids.
- C6.6 Cost: as RD (bid price, activation cost with activation binary, `penaltyFactor` x reference) with the new references; missing `penaltyFactor` = 1.0 with a log line (as RD). The named terms are in the objective and in the objective-equals-terms test.

## C7. MILP: curative

- C7.1 Curative CT bids have per-(bid, contingency) variables like curative RD: R2 (no link = all contingencies), R4 gate (units in operation after the preventive actions), R9 (reaction time per (RA, branch)), exact maxima for the combined PRA + CRA bounds (R7).
- C7.2 Weights of a curative bid are the same as for the preventive bid: original set points (C3.5).
- C7.3 Balance per contingency: sum over all curative RD and CT injections = 0 (R15 extended to CT).
- C7.4 Curative effect enters the N-X PATL and scanned rows of the contingency (not TATL, R11) and the effect used for criterion 4.
- C7.5 Curative cost: reference CRA, maximum over contingencies as curative RD; reserve price with the energy price as fallback, as RD; the reservation part is also reported separately (C11.2).
- C7.6 Curative actions are never applied to the network.

## C8. Calculation modes and write-back

- C8.1 Write-back: the net CT injection of each unit is added to its `target_p` through the same dictionary as RD; apply, restore and the incremental fallback ramp are unchanged.
- C8.2 `ac_iterative`: sensitivities refreshed each iteration, weights unchanged (C3.5); convergence criteria 1 and 3 count CT MW.
- C8.3 `ac_single_pass` and `dc`: same weights; `dc` uses DC sensitivities as for RD; a DC run without DC overload leaves the set points unchanged.
- C8.4 The final AC check is unchanged; the distributed slack makes any residual imbalance visible.

## C9. Validation summary

Errors: none specific to CT. Warnings (RA or bid dropped or volume 0): unknown or not implemented strategy (RA ignored), bids of one RA with different strategies (RA ignored), zone not found or without units (RA dropped), bid without volume, no unit left in a direction, missing `penaltyFactor` (1.0).

## C10. Config and GUI

- C10.1 Config keys `penalty_reference_ct_pra` and `penalty_reference_ct_cra` (EUR/MW), default = the RD preventive reference (RD has no curative reference key; curative RD keeps using the preventive one; the CRA key exists for CT only); checked >= 0 only when `countertrade` is in `ra_types`.
- C10.2 GUI: a toggle for `countertrade`, the two reference inputs, result-file groups.

## C11. Outputs

- C11.1 Only with `countertrade` in `ra_types`: `results_countertrade.csv` (per bid: RA, bid, TSO, zone, direction, volume, price cost, penalty cost, activation), `results_curative_countertrade.csv` (per bid and contingency, penalty cost per bid repeated on its rows), `countertrade_glsk_resolved.csv` (RA, direction, unit, strategy, participation factor), `ct_cra_availability.csv` (like the RD availability file, with reasons), TSO column in all.
- C11.2 Summary rows (repo style): sum_ct_volume_upward_mw, sum_ct_volume_downward_mw (names in the repo style of the RD rows), sum_pra_penalty_cost_ct_eur, sum_cra_penalty_cost_ct_eur, sum_cra_reservation_cost_ct_eur (reservation cost of curative CT bids), sum_ct_cost_eur, included in the objective-residual check.
- C11.3 Minimal net-position outputs: `results_net_positions.csv` (per zone: net change of injection from RD and CT, all modes) and `results_zone_exchange.csv` (per zone pair: change of the tie-line flow between the original state and the state after the applied results, all modes). In `ac_*` modes both states come from AC load flows (the original state and the final AC check); in `dc` mode both come from DC load flows (original network and network with the applied set points), so the two states always use the same calculation. The two halves of a tie line (one per area boundary) are paired by their shared element name and opposite flow; a tie without a partner is skipped with a log line. The CGM interchange values are not used (they do not match their targets). The full functional-spec result blocks (RAOResultsCountertrade, RAOResultsExchange) are not built.
- C11.4 Set points and volumes as floats, files with TEXT_ENCODING, registered in the output registry.
- C11.5 `results_generating_units.csv` (RD units) with a usable CT RA: RD columns = RD part only, a column `ct_volume_net_mw` after them = CT part, `result_production_mw` = initial + RD + CT (DECISIONS 79); CT units in no RD glsk follow the RD units as own rows with RD columns 0 (DECISIONS 80).

## C12. Mock data and tests

- C12.0 The input data is not valid for CT. The implementation must be developed and tested on a generated mock example, like the HVDC RA (a test helper builds it; the repo fixture CT RA is not used as a test case, except for one negative test: it is ignored with a warning). The mock is the reference for the feature; no real CT data is assumed.
- C12.1 The ReliCapGrid data has no CT bids; tests use a generated mock NCP (as for HVDC, a helper builds it from an existing mock NCP): bidding zones Belgovia and Galia (five ties TieLine_GA_BO1-5, 50-250 A), one CT RA per zone with an up and a down bid, volumes of 100 MW or more, ranges, penalty factors; the PATL of TieLine_GA_BO4 is lowered to force relief.
- C12.2 Data gotchas verified: EIs appear as generators with ±1.8e308 limits (excluded); the Britheim External Grid has Pmax 100000 and is outside the main component (excluded); ControlArea EIC fields are empty (zone mapping goes through the CD file); the Belgovia units BO-G1 and BO-G2 are already RD units (use them for the sharing test).
- C12.3 Tests: remaining-capacity weights computed by hand from the CGM set points (up and down, normalisation after exclusion, unit at Pmax or Pmin, unit off, units with unbounded limits excluded); preventive relief (the relief on the lowered branch, global balance sum(RD+CT)=0, unit limits respected, cost = sum of terms, objective = sum of terms, XNE below PATL after the AC check); CT and RD sharing a unit (combined total and on/off rows); curative relief in one contingency (term only in that contingency's rows, per-contingency balance, network unchanged), R9; restrictive group cap on a CT bid; penalty factor 0 / > 0 / missing; negative cases (unknown or not implemented strategy, zone without units, bid without volume, all units at Pmax for an up bid); `ra_types` combinations; `ac_iterative`, `ac_single_pass`, `dc`; no-countertrade regression (golden outputs unchanged, fingerprint tests unchanged).

## C13. Open assumptions (to verify on real data)

- The exact RDF predicate and enumeration names of the ENTSO-E NC profile for the strategy (C2.2 states the implementation choice) (the spec uses `gLSKStrategy` / `proportionalForRemainingCapacity` from the functional spec, line 5400).
- Whether real CT RAs carry volumes per time point and a reaction time.
- Latent: the CT parser never fills `linked_xne_mrids` (the XNE links of a curative CT RA). This matters only if `ACTIVATE_CRA_XNE_LINKAGE` (hard-coded False in `run_pipeline.py`) is enabled; the CT parser then needs the AE file, as the RD and PST parsers do.

## C14. Deviations from the functional spec

| # | Functional spec | This spec |
|---|---|---|
| 1 | Balancing of CT deferred to a later release (6175) | CT is in the global and the per-contingency balance (CORNET-73, R6.6) |
| 2 | Remaining capacity: Pmax - actPROD for both directions (2999) | Direction-aware: footroom actPROD - Pmin for down |
| 3 | Normalisation formula as printed (3029) | PF_g / (1 - sum of excluded PF) (the spec's example) |
| 4 | Unit limits "not considered" (5398), adaptation MaxAdaptionCT | Hard Pmax/Pmin rows on the combined total (R6.7) |
| 5 | CT and RD sharing a unit: allowed (5408) and forbidden (3044) | Allowed; one combined total per unit |
| 6 | Dynamic weights include the actions of the same solution (2963) | Weights fixed from the original set points, in all modes and iterations |
| 7 | Three strategies (explicit, proportional for generator, remaining capacity) | Only remaining capacity (default when none is given, or old-form `gLSKStrategy`); other values: RA ignored with a warning |
| 8 | Integer steps `stepSizeCTRD` (8658) | Continuous volumes (as RD) |
| 9 | Penalty formulas for RD only (3.36-3.44, 4606) | The same structure for CT with the CT references |
| 10 | Missing penaltyFactor not defined for CT | 1.0 with a log line (as RD) |
| 11 | RAOResultsCountertrade, RAOResultsExchange | Minimal before/after net-position and exchange deltas |
| 12 | Curative CT: cost only (8786) | Full curative modelling (as curative RD) |
| 13 | Adaptive GLSK recalculation when units hit their limits (CORNET-4849, MaxAdaptionCT) | Not implemented; the volume is reduced by the hard limit rows |
| 14 | Bid dependencies apply to CT as to RD (CORNET-4838) | Restrictive RA groups only, as RD; dependencies not implemented for RD or CT |
| 15 | Units with PROD above Pmax: Pmax := PROD (CORNET-36) | CT excludes such units; RD unchanged |
| 16 | Not stated: whether CT RAs count in the RA-count limits | They count (RA-count and group caps); the RD result files, the RA-count and group files too, list RD only |
| 17 | Not stated: where a result file is written | Only with `countertrade` in `ra_types` and a usable CT RA (as HVDC) |
| 18 | RAOResultsExchange | The after-state of `results_zone_exchange.csv` comes from a fresh load flow of the final network (AC in the AC modes, DC in `dc`) |
| 19 | Not stated: the strategy predicate | `gLSKStrategy` on the RA (and optionally its bids) is an implementation choice (C13) |
| 20 | Not stated: a unit with an unbounded or NaN limit | Excluded from CT (RD unchanged) |
| 21 | Curative test data | No existing contingency overloads a GA_BO tie; the mock adds an outage of TieLine_GA_BO5 (both halves) with a curative PATL of 200 A |
| 22 | Exact relief of a fixed-weight model | `ac_single_pass` leaves a linearisation residual (about 1.4 A over the PATL on the mock); `ac_iterative` converges |

## C15. Not part of this model (noted)

Time coupling, the strategies `explicitInstruction` and `proportionalForGenerator`, merit-order GLSK, loads in the GLSK, adaptive GLSK recalculation (CORNET-4849), weights that depend on the actions of the same solution, integer volume steps (`stepSizeCTRD`), the full result blocks RAOResultsCountertrade and RAOResultsExchange (decided by the spec owner, 19 Oct 2026).
