# NCP data requirements

What the RAO reads from the NCP (network code profile) files, in RDF/XML terms, with what the code
does with each value. The code is the source of truth: every statement below was read from
`src/rao` (ncp_loader, ncp_parser, glsk_resolver, ct_units, hvdc_units, scanned_elements,
nx_security_analysis, cra_preprocessing, pst_groups, pst_bounds, and the callers in run_pipeline
and milp_builder where they decide the outcome). The purpose is a test dataset that covers every
feature.

Out of scope: the Organisation profile `Org-NineRealms_CD.xml` (Organisation, BiddingZone,
SchedulingArea, ControlArea), the CGM/EQ files, and the profiles the loader skips (SSI, CD_OR, PS,
RAS, FAP, cross-TSO CO exports). ER is not parsed for anything except the start-up/shut-down cost
fallback; those rows are kept (section 8.5) and marked, because the code does read them.

## 1. Conventions

**Namespaces.** `nc:` = `https://cim4.eu/ns/nc#`, `cim:` = `https://cim.ucaiug.io/ns#`. All
classes and predicates below are looked up in exactly these namespaces (the CIM100 fallback exists
only for the EQ files, out of scope). A class or predicate in another namespace is not found and
behaves as "missing".

**Fixture codes** (last column of every table):

| Code | Fixture |
|---|---|
| G | `tests/fixtures/NCP_generic.zip` |
| P | `tests/fixtures/NCP_pst_fallback_scenario.zip` (also the base every mock copies) |
| H | `tests/hvdc_mock.py` `build_hvdc_mock_ncp` with defaults |
| Hc | `build_hvdc_mock_ncp` with `default_ras() + curative_ras()` and both group sets |
| C | `tests/ct_mock.py` `build_ct_mock_ncp` with defaults |
| Cc | `build_ct_mock_ncp` with `default_ras() + curative_ras()` and one `group(...)` |
| CH | `ct_mock.build_ct_and_hvdc_mock_ncp` |
| m:`x` | not in a default build; produced only by the mock builder parameter or helper `x` |
| — | in no fixture |

Mock contents were established by building the mocks in a scratch directory and listing the
classes, predicates and values of every file; `extra_ra_xml` / `extra_co_xml` (free XML text) is not
counted as coverage. Hand-written XML inside individual tests is not counted either.

**General rules that apply to every row** (stated once here, not repeated):

- R0.1 Identity. A subject's id is `cim:IdentifiedObject.mRID` when present, else the fragment of
  its `rdf:ID`/`rdf:about` with a leading `_` stripped. A reference (`rdf:resource`) is always
  reduced to that fragment. Several links compare the referenced fragment with the target's mRID
  literal (bids to RA, contingency links of PST and RD, restrictive group members), so a dataset
  must keep `rdf:ID="_<mRID>"` (fragment = mRID). A mismatch loses the link; a contingency link or
  bid that refers to no RA mRID of the TSO's RA file is named in a warning (DECISIONS 82).
- R0.2 Single-valued predicates are read with rdflib `Graph.value`, which returns one arbitrary
  value when a predicate is repeated on one subject. A duplicated single-valued predicate is
  therefore not detected and one value is used; no warning. Exceptions (multi-valued, all values
  used) are named in the rows.
- R0.3 Enumerations are read as the text after the last `#` (or after the last `.`, where the row
  says "token"). The enumeration namespace is not checked.
- R0.4 `atTime` (`xsd:dateTime`) is reduced to `HHMMZ` from the `THH:MM:` part only. The date and
  any time zone offset are ignored, so a time point of another day with the same clock time
  matches. A time point whose `HHMMZ` is not one of the run timestamps (`START_HOUR`,
  `N_TIMESTAMPS`) is ignored silently.
- R0.5 ISO 8601 durations: `PnDTnHnMnS` (decimals allowed). Years or months other than 0 make the
  value unreadable. What "unreadable" leads to is stated per row.
- R0.6 Numbers are read with `float(str(literal))`. Where a row says "non-numeric: run stops" the
  `ValueError` is not caught.
- R0.7 The TSO of every NCP object is the file name prefix (`{TSO}_{PROFILE}.xml`); no predicate
  inside the NCP files is read for it.

## 2. Files and profiles

### 2.1 File name patterns

Zip mode (`input/ncp*.zip`, `extract_ncp_zip` then `classify_extracted_ncp_files`):

| Entry name | Category | Outcome | Code location | Fixtures |
|---|---|---|---|---|
| `Org-NineRealms_CD.xml` | organisation | required: missing raises `FileNotFoundError` (run stops); out of scope here | `ncp_loader.py:extract_ncp_zip` | G, P, all mocks |
| `Org-NineRealms_CD_OR.xml`, `*_SSI.xml` | known_irrelevant | skipped, no log | `ncp_loader.py:_classify_ncp_zip_entry` | G (both), P (CD_OR) |
| `{Country}_{P}.xml`, P in AE, CO, RA, SHS, SIS, ER | recognized | parsed for TSO `TSO-{Country}` | `ncp_loader.py:_classify_ncp_zip_entry` | G, P, all mocks (no ER anywhere) |
| `{Country}_{other}.xml` (PS, RAS, RAS_FAP, OR, AS, ...) for a known country | known_irrelevant | skipped, no log | `ncp_loader.py:_classify_ncp_zip_entry` | — |
| `{A}-{B}_{P}.xml` (hyphen in the prefix, no known-country prefix) | known_irrelevant (cross-TSO export) | skipped, no log | `ncp_loader.py:_classify_ncp_zip_entry` | G (`DC-Espheim-Svedala_CO.xml`, `Svedala-Belgovia_CO.xml`) |
| anything else (not `.xml`, no `_`, unknown country) | unrecognized | one warning listing the files; skipped | `ncp_loader.py:classify_extracted_ncp_files` | — |

`{Country}` must equal a TSO display name from the Organisation profile without its `TSO-` prefix
(`_country_from_display`); matching is by prefix, so a profile suffix may contain `_`.

Folder mode (`build_ncp_files`): `{instance_root}/{Country}/NetworkCode/cimxml/{Country}_{P}.xml`
for P in AE, CO, RA, SHS, SIS, ER; a country without `NetworkCode/cimxml/` is logged (info) and left
out.

### 2.2 Profiles and what reads them

| Profile | Required | When missing | Read by | Sections |
|---|---|---|---|---|
| AE | yes | `ValueError` (run stops) | `ncp_parser.py:parse_assessed_elements` | 3 |
| SHS | no | warning "SHS fallback to CGM static value" | `ncp_parser.py:parse_assessed_elements` | 4 |
| CO | yes | `ValueError` (run stops) | `ncp_parser.py:parse_contingencies` | 5 |
| RA | yes | `ValueError` (run stops) | `parse_psts`, `build_pst_tap_bounds_curative`, `parse_rd_units`, `warn_unsupported_power_remedial_actions`, `parse_ra_groups`, `parse_hvdc_units`, `parse_balanced_ra_groups` (ncp_parser), `ct_units.py:parse_ct_remedial_actions` | 6-10 |
| SIS | no | warning "no power bids, no GLSK, no unit costs from SIS" | `ncp_parser.py:parse_power_bids`, `parse_ra_groups`, `parse_unit_costs`, `glsk_resolver.py:resolve_glsk`, `ct_units.py:parse_ct_remedial_actions` | 8, 10 |
| ER | no | info "no GeneratingUnit start-up/shut-down costs from ER" | `ncp_parser.py:parse_unit_costs` | 8.5 |

Which RA parsers run depends on `ra_types` (`run_pipeline.py:main`): `pst` gates `parse_psts`,
`rd` gates `parse_rd_units`, unit costs and GLSK, `countertrade` gates
`parse_ct_remedial_actions`, `hvdc` gates `parse_hvdc_units` and `parse_balanced_ra_groups`.
Restrictive groups are parsed when `rd` is on or a countertrade RA is usable.

### 2.3 Rules and checks

- Zip not found: `FileNotFoundError`, run stops (`extract_ncp_zip`).
- Two zip entries with the same base name (different folders): `ValueError`, run stops.
- The same (TSO, profile) recognised twice: `ValueError`, run stops.
- A TSO with at least one recognised file but without AE, CO or RA: `ValueError`, run stops (all
  TSOs listed in one message).
- A TSO with no recognised file at all: not an error; that TSO has no NCP data.
- Missing SHS or SIS: warning per TSO; missing ER: info per TSO.

### 2.4 Edge cases

- `X_SSI.xml` next to `X_SIS.xml`: SSI skipped silently, SIS parsed.
- `X_RAS.xml`, `X_PS.xml`: skipped silently.
- `A-B_CO.xml`: skipped silently (cross-TSO export).
- `Unknown_AE.xml` (country not in the Organisation profile): one warning, skipped.
- `readme.txt` in the zip: one warning, skipped.
- TSO with AE and CO but no RA: run stops with "missing required profile(s): RA".
- TSO without SHS: warning; PATL falls back as in section 4.
- TSO without SIS: warning; no bids, no GLSK, no group limits, no unit costs for that TSO.

## 3. Assessed elements (`{TSO}_AE.xml`)

### 3.1 Classes and attributes

| Profile and file | RDF class | RDF predicate | Value type / allowed values | Req. | Missing / invalid / duplicated | Code location | Feature | Fixtures |
|---|---|---|---|---|---|---|---|---|
| AE `{TSO}_AE.xml` | `nc:AssessedElement` | `rdf:type` | class | yes | — | `ncp_parser.py:parse_assessed_elements` | monitoring (all) | G, P, all mocks |
| AE | `nc:AssessedElementWithContingency` | `rdf:type` | class | no | iterated as an AE; without its own `ConductingEquipment`/`Line` it is skipped with a warning ("spec violation") | `ncp_parser.py:parse_assessed_elements` | — (no contingency association is read) | G (15) |
| AE | `nc:AssessedElementWithRemedialAction` | `rdf:type` | class | no | iterated as an AE (as above: warning, skipped); also read as an RA link, section 6 | `ncp_parser.py:parse_assessed_elements` | — | G (2) |
| AE | `nc:AssessedElement` | `cim:IdentifiedObject.mRID` | string | no | fragment used (R0.1); duplicate mRIDs across files not checked | `ncp_parser.py:parse_assessed_elements` | all | G, P, all mocks |
| AE | `nc:AssessedElement` | `cim:IdentifiedObject.name` | string | no | mRID used | `ncp_parser.py:parse_assessed_elements` | outputs | G, P, all mocks |
| AE | `nc:AssessedElement` | `nc:AssessedElement.ConductingEquipment` | resource: mRID of a Line or 2-winding PowerTransformer in the CGM | one of CE / Line | not in the CGM branch set: info, AE skipped. Neither CE nor Line: see the next rows | `ncp_parser.py:parse_assessed_elements` | monitoring | G, P, all mocks |
| AE | `nc:AssessedElement` | `nc:AssessedElement.Line` | resource: branch mRID | one of CE / Line | used only when `ConductingEquipment` is absent | `ncp_parser.py:parse_assessed_elements` | monitoring | — |
| AE | `nc:AssessedElement` | `nc:AssessedElement.DCTieCorridor` | resource | no | presence only, when CE and Line are both absent: info "out of scope", AE skipped | `ncp_parser.py:parse_assessed_elements` | — | — |
| AE | `nc:AssessedElement` | `nc:AssessedElement.AssessedPowerTransferCorridor` | resource | no | as DCTieCorridor | `ncp_parser.py:parse_assessed_elements` | — | — |
| AE | `nc:AssessedElement` | `nc:AssessedElement.OperationalLimit` | resource: a CurrentLimit mRID (EQ) or a BaseCaseCurrentLimit in this file | no | absent: no SHS lookup, no BaseCaseCurrentLimit, side 1; not in the EQ side map: side 1 (debug). Without CE/Line it only gives the "out of scope" info | `ncp_parser.py:parse_assessed_elements` | PATL, side | G, P, all mocks |
| AE | `nc:BaseCaseCurrentLimit` or `cim:BaseCaseCurrentLimit` | `rdf:type` (on the `OperationalLimit` target, in the AE file) | class | no | other type: not used | `ncp_parser.py:parse_assessed_elements` | PATL | P, all mocks |
| AE | `nc:BaseCaseCurrentLimit` | `nc:BaseCaseCurrentLimit.normalValue` | float, A | no | missing: next PATL source; non-numeric: warning, ignored | `ncp_parser.py:parse_assessed_elements` | PATL | P, all mocks |
| AE | `nc:AssessedElement` | `nc:AssessedElement.SecuredForRegion` | resource (any region; value not checked) | no | presence only, see 3.2 | `ncp_parser.py:parse_assessed_elements` | secured | G, P, all mocks |
| AE | `nc:AssessedElement` | `nc:AssessedElement.ScannedForRegion` | resource (any region; value not checked) | no | presence only, see 3.2 | `ncp_parser.py:parse_assessed_elements` | scanned | G |
| AE | `nc:AssessedElement` | `nc:AssessedElement.exclusionReason` | enum `nc:SecuredExclusionReasonKind.systemOperator`, `.capacityCalculationRegion`, `.nonNativeCapacityCalculationRegion` | no | any other value: fatal log and `ValueError`, run stops | `ncp_parser.py:parse_assessed_elements` | excluded, scanned | G (`systemOperator`, `nonNativeCapacityCalculationRegion`) |

Present in the fixtures but not read: `nc:AssessedElement.normalEnabled`, `.inBaseCase`,
`.isCombinableWithContingency`, `.isCombinableWithRemedialAction`, `.AssessedSystemOperator`,
`cim:IdentifiedObject.description`, every `nc:AssessedElementWithContingency.*` predicate,
`nc:CrossBorderRelevance`, and in SIS `nc:AssessedElementSchedule` / `nc:AssessedElementTimePoint`.
`normalPositiveVirtualMargin` is not read either: the scanned margin is always 0
(`scanned_elements.py:build_scanned_element_list`).

### 3.2 Classification (secured / scanned / excluded)

Evaluated in this order in `parse_assessed_elements`:

| exclusionReason | ScannedForRegion | SecuredForRegion | Type | Log |
|---|---|---|---|---|
| absent | any | present | SECURED | — |
| present (valid) | present | any | SCANNED | — |
| present (valid) | absent | any | EXCLUDED (reason kept) | — |
| absent | absent | absent | EXCLUDED, reason "no secured or scanned region code" | info |
| absent | present | absent | SECURED | debug ("undocumented case") |

What each type gets downstream: SECURED is monitored in N-0 and N-X and gets a TATL
(`nx_security_analysis.py:compute_tatl_data`); SCANNED becomes a scanned element with limit
`max(PATL × (1 + 0/100), initial loading)` (`scanned_elements.py:build_scanned_element_list`);
EXCLUDED is not passed to the optimisation.

### 3.3 Rules and checks

- AE without `ConductingEquipment` and `Line`: if it has `OperationalLimit`, `DCTieCorridor` or
  `AssessedPowerTransferCorridor` → info, skipped; else warning "spec violation", skipped.
- `ConductingEquipment`/`Line` must resolve to a CGM Line or 2-winding transformer
  (`cgm_branch_mrids`); else info, skipped (e.g. a BusbarSection).
- `exclusionReason` outside the three values → run stops (`ValueError`).
- `OperationalLimit` must resolve to a CurrentLimit of the EQ file with a Terminal
  `sequenceNumber` 1 or 2 for the side; else side 1 (EQ data, out of scope).
- A scanned AE without branch is skipped with a warning (`build_scanned_element_list`; not reachable
  from the parser, which skips such AEs before).
- No check for duplicate AE mRIDs or two AEs on one branch; the PATL map of the run is keyed by
  branch, the last AE of a branch wins (`run_pipeline.py:main`, `patl`).

### 3.4 Edge cases

- Secured only → SECURED.
- Secured + scanned, no reason → SECURED.
- Scanned + reason (with or without secured) → SCANNED.
- Reason without scanned (with or without secured) → EXCLUDED with that reason.
- Neither region nor reason → EXCLUDED, info.
- Scanned only, no reason → SECURED (debug).
- Each of the three valid exclusion reasons → accepted.
- Invalid exclusion reason (e.g. `SecuredExclusionReasonKind.other`) → run stops.
- `Line` instead of `ConductingEquipment` → branch from `Line`.
- Both `ConductingEquipment` and `Line` → `ConductingEquipment` wins.
- Only `OperationalLimit`, only `DCTieCorridor`, only `AssessedPowerTransferCorridor` → info, skipped.
- No equipment reference at all → warning, skipped.
- Equipment is a BusbarSection (not a CGM branch) → info, skipped.
- `nc:AssessedElementWithContingency` / `nc:AssessedElementWithRemedialAction` subjects → warning, skipped as AEs.
- Missing mRID → fragment; missing name → mRID.

## 4. Limits

### 4.1 PATL (`{TSO}_SHS.xml`, plus `BaseCaseCurrentLimit` in AE)

| Profile and file | RDF class | RDF predicate | Value type / allowed values | Req. | Missing / invalid / duplicated | Code location | Feature | Fixtures |
|---|---|---|---|---|---|---|---|---|
| SHS `{TSO}_SHS.xml` | `nc:CurrentLimitSchedule` | `rdf:type` | class | no | — | `ncp_parser.py:parse_assessed_elements` | PATL | G, P, all mocks |
| SHS | `nc:CurrentLimitSchedule` | `nc:CurrentLimitSchedule.CurrentLimit` | resource: the AE's `OperationalLimit` mRID | yes | missing: schedule ignored silently; no AE with that limit: unused | `ncp_parser.py:parse_assessed_elements` | PATL | G, P, all mocks |
| SHS | `nc:CurrentLimitTimePoint` | `nc:CurrentLimitTimePoint.CurrentLimitSchedule` | resource | yes | missing or unknown schedule: time point ignored silently | `ncp_parser.py:parse_assessed_elements` | PATL | G, P, all mocks |
| SHS | `nc:CurrentLimitTimePoint` | `nc:CurrentLimitTimePoint.atTime` | `xsd:dateTime` (R0.4) | yes | missing: ignored; not a run timestamp: ignored | `ncp_parser.py:parse_assessed_elements` | PATL per timestamp | G, P, all mocks |
| SHS | `nc:CurrentLimitTimePoint` | `nc:CurrentLimitTimePoint.value` | float, A | yes | missing: ignored; non-numeric: run stops (R0.6); two points for one limit and timestamp: the one read last wins, no warning | `ncp_parser.py:parse_assessed_elements` | PATL | G, P, all mocks |

`BaseCaseCurrentLimit.normalValue` (AE file) is listed in 3.1. Not read: `nc:BaseTimeSeries.interpolationKind`.

PATL priority per AE and timestamp (`parse_assessed_elements`):
1. SHS time point of the AE's `OperationalLimit` at that timestamp (warning when it differs by more
   than 10 % from the CGM static limit of the same side);
2. `BaseCaseCurrentLimit.normalValue`;
3. CGM static PATL of the branch side (warning "no PATL in NCP");
4. 0.0 (warning).

### 4.2 TATL

No TATL value or duration is read from the NCP files. `compute_tatl_data` takes the TATL from the
CGM (`network.get_operational_limits()`, rows with `acceptable_duration > 0`). For completeness of a
test dataset, the TATL variants the code distinguishes (all CGM data, outside this document's
scope):
- no TATL on the AE side → TATL = PATL, duration `curative_ra.tatl_fallback_duration_s` (600 s
  default);
- one TATL → used; below the PATL → raised to the PATL (counted, `was_corrected`);
- several TATLs on one side → no entry (warning);
- neither TATL nor PATL → no entry (logged).

### 4.3 Rules and checks

- PATL ≤ 0 (e.g. the 0.0 default) → the branch is excluded from the MILP with a warning
  (`milp_builder.py:_branch_is_above_threshold`) and from sensitivity pruning (`limit > 0` checks in
  n0_sensitivity / nx_sensitivity).
- SHS value more than 10 % away from the CGM static limit → warning, SHS value used.
- `atTime` must match a run timestamp by clock time (R0.4).

### 4.4 Edge cases

- SHS point at every run timestamp → SHS PATL.
- SHS point at some timestamps only → SHS where present, next source elsewhere.
- SHS absent, `BaseCaseCurrentLimit` present → that value for every timestamp.
- Neither, CGM static limit present → CGM value with a warning.
- Nothing → 0.0 with a warning → branch excluded from the MILP.
- SHS differs > 10 % from CGM → warning.
- SHS `atTime` on another date, same clock time → matches.
- `CurrentLimitSchedule` without `CurrentLimit` → ignored.
- Non-numeric `CurrentLimitTimePoint.value` → run stops.
- Non-numeric `BaseCaseCurrentLimit.normalValue` → warning, next source.

## 5. Contingencies (`{TSO}_CO.xml`)

### 5.1 Classes and attributes

| Profile and file | RDF class | RDF predicate | Value type / allowed values | Req. | Missing / invalid / duplicated | Code location | Feature | Fixtures |
|---|---|---|---|---|---|---|---|---|
| CO `{TSO}_CO.xml` | `nc:OrdinaryContingency` | `rdf:type` | class | one of the three | — | `ncp_parser.py:parse_contingencies` | N-X | G, P, all mocks |
| CO | `nc:ExceptionalContingency` | `rdf:type` | class | one of the three | — | `ncp_parser.py:parse_contingencies` | N-X | G, P, all mocks |
| CO | `nc:OutOfRangeContingency` | `rdf:type` | class | one of the three | — | `ncp_parser.py:parse_contingencies` | N-X | G, P, all mocks |
| CO | the three above | `cim:IdentifiedObject.mRID` | string | no | fragment used; the same mRID in two TSO files is not de-duplicated | `ncp_parser.py:parse_contingencies` | N-X, curative links | G, P, all mocks |
| CO | the three above | `cim:IdentifiedObject.name` | string | no | mRID used | `ncp_parser.py:parse_contingencies` | outputs | G, P, all mocks |
| CO | the three above | `nc:Contingency.normalMustStudy` | `xsd:boolean` | no | `true` (any case) → studied at every timestamp; missing or any other value → not studied (no warning) | `ncp_parser.py:parse_contingencies`, `nx_security_analysis.py:_get_must_study_contingencies` | N-X | G, P, all mocks (always `true`) |
| CO | `cim:ContingencyEquipment` | `rdf:type` | class | yes per tripped element | — | `ncp_parser.py:parse_contingencies` | N-X | G, P, all mocks |
| CO | `cim:ContingencyEquipment` | `cim:ContingencyElement.Contingency` | resource: contingency | yes | missing: element ignored silently | `ncp_parser.py:parse_contingencies` | N-X | G, P, all mocks |
| CO | `cim:ContingencyEquipment` | `cim:ContingencyEquipment.Equipment` | resource: equipment mRID of one of the covered CGM types | yes | missing: ignored silently; not in the CGM: warning, element skipped | `ncp_parser.py:parse_contingencies` | N-X | G, P, all mocks |

Not read: `nc:ExceptionalContingency.kind`, `nc:Contingency.EquipmentOperator`,
`cim:ContingencyEquipment.contingentStatus`.

### 5.2 Rules and checks

- Equipment must be a key of `equipment_mrid_to_type` (`cgmes_loader.py:build_equipment_mrid_to_type`,
  the covered CoMo types); else warning per element, element dropped.
- All equipment of a contingency dropped → warning, contingency excluded.
- Some equipment dropped → contingency kept with the remaining elements (no extra warning).
- One element → single-element contingency, several → multiple-elements contingency
  (`nx_security_analysis.py:_register_contingencies`).
- Only must-study contingencies enter the N-X security and sensitivity analysis.
- After the security analysis, a contingency is skipped when not CONVERGED/NO_IMPACT or when a
  monitored branch is missing from its results (likely network split)
  (`_contingency_result_is_usable`).
- A curative PST is not available for a contingency that trips it
  (`cra_preprocessing.py:compute_pst_cra_availability`).

### 5.3 Edge cases

- Ordinary, Exceptional, OutOfRange → all three parsed the same way.
- `normalMustStudy` true → studied; false → parsed, not studied; missing → not studied.
- One equipment → single-element contingency.
- Several equipment (double circuit) → multiple-elements contingency.
- One of two equipment not in the CGM → warning, kept with one element.
- All equipment not in the CGM → warning, excluded.
- No `ContingencyEquipment` at all → kept with an empty equipment list (see U5.1).
- Same contingency mRID in two TSO files → two entries (see U5.2).
- Contingency that trips a curative PST linked to it → that PST is not a CRA for it.

## 6. Common to all RA types (`{TSO}_RA.xml`)

### 6.1 Classes and attributes

The RA subject is `nc:GridStateAlterationRemedialAction` (PST, RD, HVDC) or
`nc:CountertradeRemedialAction` (CT).

| Profile and file | RDF class | RDF predicate | Value type / allowed values | Req. | Missing / invalid / duplicated | Code location | Feature | Fixtures |
|---|---|---|---|---|---|---|---|---|
| RA `{TSO}_RA.xml` | RA subject | `cim:IdentifiedObject.mRID` | string; must equal the `rdf:ID` fragment (R0.1) | no | fragment used | `parse_psts`, `parse_rd_units`, `parse_hvdc_units` (ncp_parser), `ct_units.py:parse_ct_remedial_actions` | all | G, P, all mocks |
| RA | RA subject | `cim:IdentifiedObject.name` | string | no | mRID used | as above | outputs | G, P, all mocks |
| RA | RA subject | `nc:RemedialAction.normalAvailable` | `xsd:boolean` | no | `true` (any case) → available; missing or other → not available, no warning | as above | all | G, P, all mocks (always `true`); m:`hvdc_mock.ra(available=False)`, m:`ct_mock.ra(available=False)` |
| RA | RA subject | `nc:RemedialAction.kind` | enum `nc:RemedialActionKind.preventive` / `.curative` | no | value containing `curative` → curative; missing or anything else → preventive, no warning | as above | preventive / curative | G, P, all mocks (both values) |
| RA | RA subject | `nc:RemedialAction.penaltyFactor` | float ≥ 0 (no sign check) | no | missing: PST, RD, CT 1.0 with warning; HVDC 0.0 with warning; non-numeric: run stops | as above | costs | P, all mocks; missing: G (all RAs); m:`ct_mock.missing_penalty_ras` |
| RA | RA subject | `nc:RemedialAction.timeToImplement` | duration (R0.5) | no | missing: none (reaction time 0, no warning). Unreadable: PST 0 without warning; RD, CT, HVDC 0 with warning | `parse_psts` (`_parse_iso_duration_hours`), `_parse_reaction_time_minutes` (RD, CT, HVDC) | curative | G (`PT20M0S`, on non-PST RAs), P (curative PSTs), Hc, Cc (`PT5M`) |
| RA | `nc:ContingencyWithRemedialAction` | `rdf:type` | class | no | — | `parse_psts`, `parse_rd_units`, `parse_hvdc_units`, `parse_ct_remedial_actions` | curative | G, P, all mocks |
| RA | `nc:ContingencyWithRemedialAction` | `nc:ContingencyWithRemedialAction.RemedialAction` | resource: RA | yes | missing: link ignored silently | as above | curative | G, P, all mocks |
| RA | `nc:ContingencyWithRemedialAction` | `nc:ContingencyWithRemedialAction.Contingency` | resource: contingency mRID (CO) | yes | missing: link ignored; unknown contingency: not checked | as above | curative | G, P, all mocks |
| AE `{TSO}_AE.xml` | `nc:AssessedElementWithRemedialAction` | `nc:AssessedElementWithRemedialAction.RemedialAction` | resource: RA | no | read only when the parser gets `ae_path`; the pipeline never passes it, so RA-to-AE links are never used | `parse_psts`, `parse_rd_units` | CRA-XNE linkage (off) | G (2) |
| AE | `nc:AssessedElementWithRemedialAction` | `nc:AssessedElementWithRemedialAction.AssessedElement` | resource: AE | no | as above | `parse_psts`, `parse_rd_units` | CRA-XNE linkage (off) | G (2) |

Not read on any RA: `nc:RemedialAction.RemedialActionSystemOperator` (the TSO is the file prefix,
R0.7), `.AppointedToRegion`, `.isCrossBorderRelevant`, `nc:RemedialAction.ContingencyWithRemedialAction`
(the inverse link present in G; only the `ContingencyWithRemedialAction` object is read),
`nc:GridStateAlterationRemedialAction.isActivationRestricted`, `nc:GridStateAlteration.normalEnabled`,
`nc:GridStateAlteration.PropertyReference`, `nc:ContingencyWithRemedialAction.combinationConstraintKind`.

### 6.2 Rules and checks

- Contingency links are matched on the RA's mRID literal for PST and RD
  (`gsara_to_linked_contingencies.get(gsara_mrid)`), on mRID or fragment for HVDC and CT (R0.1).
- A `ContingencyWithRemedialAction` (RA file) or `PowerBidSchedule` (SIS file) whose RA reference is
  the mRID of no remedial action of the TSO's RA file (any `nc:...RemedialAction` class) → one
  warning naming the object and the referenced mRID; what is matched is unchanged
  (`ncp_parser.py:warn_unmatched_ra_references`, called per TSO in `run_pipeline.py:main`,
  DECISIONS 82).
- What an empty contingency link list means: PST curative → no CRA at all (info,
  `compute_pst_cra_availability`); RD, CT and HVDC curative → available for every contingency
  (`milp_builder.py:_add_curative_rd_block`, the HVDC curative block).
- A link to a contingency that does not exist or is not must-study has no N-X result to act on (see
  U6.1).
- Unavailable PST, RD and CT RAs are parsed but get no variables and no cost (milp_builder,
  n0/nx sensitivity filters); an unavailable RD/CT RA gets no restrictive group entry, an
  unavailable PST excludes its whole PST group (section 7.3), an unavailable HVDC unit is dropped
  with its group (section 9).
- Curative RAs need N-X analysis on (`ENABLE_NX_ANALYSIS`); curative HVDC units are dropped with an
  info line when it is off.
- RD, CT and HVDC curative availability per branch: reaction time (missing = 0) ≤ TATL duration
  (`cra_preprocessing.py:rd_cra_is_available`); PST: section 7.

### 6.3 Edge cases

- `normalAvailable` true / false / missing → available / not / not.
- `kind` preventive / curative / missing / unknown token → P / C / P / P.
- `penaltyFactor` present / missing (per type default) / non-numeric (run stops).
- `timeToImplement` present / missing / unreadable (`P1M`, `abc`) / `PT0S`.
- Curative RA with zero, one, several contingency links.
- Link to an unknown contingency mRID.
- RA whose mRID literal differs from its `rdf:ID` fragment, with links and bids that use the rdf:ID
  → PST/RD contingency links and all bids lost, one warning per link and bid.

## 7. PST

### 7.1 RA class, attributes, actions

A PST RA is an `nc:GridStateAlterationRemedialAction` with at least one `nc:TapPositionAction`.
`PST.mrid` is the parent PowerTransformer of the TapChanger (resolved from the EQ file).

| Profile and file | RDF class | RDF predicate | Value type / allowed values | Req. | Missing / invalid / duplicated | Code location | Feature | Fixtures |
|---|---|---|---|---|---|---|---|---|
| RA | `nc:GridStateAlterationRemedialAction` | `rdf:type` | class | yes | — | `ncp_parser.py:parse_psts` | PST | G, P, all mocks |
| RA | (common attributes) | section 6 | | | | | | |
| RA | `nc:TapPositionAction` | `rdf:type` | class | yes | — | `ncp_parser.py:parse_psts` | PST | G (curative only), P, all mocks |
| RA | `nc:TapPositionAction` | `nc:GridStateAlteration.GridStateAlterationRemedialAction` | resource: the GSARA | yes | missing: action ignored silently | `ncp_parser.py:parse_psts` | PST | G, P, all mocks |
| RA | `nc:TapPositionAction` | `nc:TapPositionAction.TapChanger` | resource: a PhaseTapChanger (Symmetrical, Asymmetrical, Tabular, Linear) mRID of the EQ file | yes | missing: action ignored; not a phase tap changer (e.g. RatioTapChanger): info, skipped; transformer not in the CGM tap changer data: warning, skipped | `ncp_parser.py:parse_psts`, `build_tap_changer_to_transformer_map` | PST | G, P, all mocks |
| RA | `nc:TapPositionAction` | `nc:GridStateAlteration.timePerStage` | duration (R0.5) | for curative | missing: none → curative PST gets a parse warning and no CRA (warning in `compute_pst_cra_availability`); zero (`PT0S`) or unreadable: a warning naming the PST, then the same as missing (DECISIONS 81) | `ncp_parser.py:parse_psts` | curative PST | P, all mocks (`PT1M`); missing on curative: G |

Tap range: the preventive operating range is the hardware range of the CGM (`low_step`,
`high_step`); no NCP attribute sets it. The current tap is clamped into the hardware range
silently.

### 7.2 Ranges and groups

| Profile and file | RDF class | RDF predicate | Value type / allowed values | Req. | Missing / invalid / duplicated | Code location | Feature | Fixtures |
|---|---|---|---|---|---|---|---|---|
| RA | `nc:StaticPropertyRange` | `rdf:type` | class | no | — | `ncp_parser.py:build_pst_tap_bounds_curative` | curative PST bounds | — (on a TapPositionAction) |
| RA | `nc:StaticPropertyRange` | `nc:RangeConstraint.GridStateAlteration` | resource: the TapPositionAction | yes | missing: range ignored | `ncp_parser.py:build_pst_tap_bounds_curative` | curative PST bounds | — |
| RA | `nc:StaticPropertyRange` | `nc:RangeConstraint.normalValue` | number, absolute tap position (cast to int) | yes | missing: ignored; non-numeric: ignored silently | `ncp_parser.py:build_pst_tap_bounds_curative` | curative PST bounds | — |
| RA | `nc:StaticPropertyRange` | `nc:RangeConstraint.direction` | enum `nc:RelativeDirectionKind.up` / `.down` | yes | token containing `up` → upper bound (so `upAndDown` → upper only; intended, DECISIONS 83); containing `down` → lower; `none`, missing or other → warning, skipped | `ncp_parser.py:build_pst_tap_bounds_curative` | curative PST bounds | — |
| RA | group | (several `nc:TapPositionAction` on one GSARA) | ≥ 2 actions | no | 1 action: no group; ≥ 2: `group_id` = GSARA mRID | `ncp_parser.py:parse_psts` | PST groups | — |

Not read for PSTs: `nc:RangeConstraint.valueKind` (values are taken as absolute tap positions),
`nc:StaticPropertyRange.PropertyReference`. The PST group kind (reducedGroup / blockedGroup) is
not in the data: config `curative_ra.pst_group_kind_default` and `pst_group_kind_per_tso`.

SIS time-point data for PST: none is read (`nc:GridStateAlterationSchedule` /
`nc:GridStateAlterationTimePoint`, present in G, are ignored).

### 7.3 Rules and checks

- TapPositionAction → TapChanger → PowerTransformer must resolve through the EQ file
  (`PhaseTapChanger*.TransformerEnd` or `TapChanger.TransformerEnd` → `PowerTransformerEnd.PowerTransformer`);
  else info/warning, that PST is skipped.
- Two GSARAs on the same TapChanger (one preventive, one curative) → two PST objects on one
  transformer, both used (fixture `tests/fixtures/ra_shared_tapchanger_preventive_and_curative.xml`).
- Effective preventive range empty (min > max) → PST excluded from the MILP with a warning
  (`pst_bounds.py:build_pst_tap_bounds`); from NCP data alone not reachable (the range is the
  hardware range).
- Curative bounds: both an upper and a lower range on the TapPositionAction → `(int(lower),
  int(upper))`; only one or none resolved → warning, fallback to the PST's operating range
  (`pst_bounds.py:build_curative_tap_bounds_with_fallback`, one info line counts fallbacks).
- Curative PST CRA availability: available and curative and ≥ 1 contingency link and both
  `timeToImplement` and `timePerStage` present; `max_curative_taps = floor((TATL_s/60 −
  reaction_min) / timePerStage_min)`, available when > 0 (`compute_pst_cra_availability`).
  Missing timing → warning, PST skipped (no default).
- `timePerStage` unreadable or `PT0S` (= 0 minutes) → parse warning naming the PST and its RA, left
  unset, so the PST is skipped as with missing timing; `compute_pst_cra_availability` also skips a
  PST whose time per stage is 0 or less (DECISIONS 81; before, a division by zero stopped the run).
- PST range direction: `up` and `upAndDown` set the upper bound, `down` the lower bound. This is
  intended (DECISIONS 83); a dataset gives separate up and down ranges. A lower bound above the upper
  bound is passed on unchecked (open finding, `docs/ncp_dataset_coverage.md` section 5).
- Preventive group (`pst_groups.py:build_pst_group_equality_pairs`): any member unavailable →
  group excluded (warning); a member without tap bounds → excluded (warning); empty intersection
  of the members' ranges → excluded (warning); else equal taps for every pair.
- Curative group (`cra_preprocessing.py:build_curative_pst_group_constraints`): per contingency,
  a tripped member blocks the whole group (blockedGroup) or leaves the others (reducedGroup); no
  common delta tap → group excluded for that contingency (warning); members of several TSOs → the
  default kind (warning).

### 7.4 Edge cases

- Preventive PST, one TapPositionAction → single PST, hardware range.
- Curative PST with `timeToImplement` + `timePerStage` + link → CRA availability computed.
- Curative PST missing `timeToImplement` or `timePerStage` → warnings, no CRA.
- Curative PST without contingency link → no CRA (info).
- Curative PST whose transformer is tripped by its linked contingency → no CRA for that contingency.
- `max_curative_taps` ≤ 0 (reaction time ≥ TATL) → entry with available False.
- GSARA with 2+ TapPositionActions → preventive group (equality) / curative group (per contingency).
- Group with one unavailable member → whole group excluded.
- Group with disjoint member ranges → excluded.
- TapPositionAction on a RatioTapChanger → info, skipped.
- TapChanger whose transformer is not in the CGM → warning, skipped.
- StaticPropertyRange up + down on a curative PST → explicit curative bounds.
- Only up, only down, `none`, or `upAndDown` → warning(s), fallback to the operating range.
- Preventive and curative GSARA on the same TapChanger → both kept.

## 8. Redispatch (RD)

### 8.1 RA class and attributes

An RD RA is an `nc:GridStateAlterationRemedialAction` with at least one `nc:RotatingMachineAction`.
One `RDUnit` per (RA, rotating machine); `RDUnit.mrid` is the RA mRID.

| Profile and file | RDF class | RDF predicate | Value type / allowed values | Req. | Missing / invalid / duplicated | Code location | Feature | Fixtures |
|---|---|---|---|---|---|---|---|---|
| RA | `nc:GridStateAlterationRemedialAction` | `rdf:type` | class | yes | — | `ncp_parser.py:parse_rd_units` | RD | G, P, all mocks |
| RA | (common attributes) | section 6 | | | | | | |
| RA | `nc:RotatingMachineAction` | `rdf:type` | class | yes | — | `ncp_parser.py:parse_rd_units` | RD | G, P, all mocks |
| RA | `nc:RotatingMachineAction` | `nc:GridStateAlteration.GridStateAlterationRemedialAction` | resource: GSARA | yes | missing: action ignored silently | `ncp_parser.py:parse_rd_units` | RD | G, P, all mocks |
| RA | `nc:RotatingMachineAction` | `nc:RotatingMachineAction.RotatingMachine` | resource: generator mRID in the CGM | yes | missing: ignored; not in the CGM generating units: warning, that unit skipped | `ncp_parser.py:parse_rd_units` | RD, N-0 sensitivity | G (one RA with two), P, all mocks |
| RA | `nc:RotatingMachineAction` | `nc:RotatingMachineAction.raiseRampRate` | float | no | missing or non-numeric: none; read, not used by the MILP | `ncp_parser.py:parse_rd_units` | — | P, all mocks |
| RA | `nc:RotatingMachineAction` | `nc:RotatingMachineAction.lowerRampRate` | float | no | as raiseRampRate | `ncp_parser.py:parse_rd_units` | — | P, all mocks |
| RA | `nc:RedispatchRemedialAction` | `rdf:type` | class | no | not supported: one warning per RA with its bid and time point counts, RA and bids ignored | `ncp_parser.py:warn_unsupported_power_remedial_actions` | — | G (2) |

`StaticPropertyRange` on a RotatingMachineAction (present in G) is not read. The units the bids move
come from the GLSK (8.3), not from `RotatingMachineAction`; the RotatingMachine is the RD unit's
generator (initial P, Pmin, Pmax from the CGM) and the N-0 sensitivity variable.

### 8.2 Bids (SIS) — shared by RD and CT

| Profile and file | RDF class | RDF predicate | Value type / allowed values | Req. | Missing / invalid / duplicated | Code location | Feature | Fixtures |
|---|---|---|---|---|---|---|---|---|
| SIS `{TSO}_SIS.xml` | `nc:PowerBidSchedule` | `rdf:type` | class | yes | — | `ncp_parser.py:parse_power_bids` | RD, CT | G, P, all mocks |
| SIS | `nc:PowerBidSchedule` | `cim:IdentifiedObject.mRID` | string | no | fragment used | `ncp_parser.py:parse_power_bids` | RD, CT | G, P, all mocks |
| SIS | `nc:PowerBidSchedule` | `nc:PowerBidSchedule.PowerRemedialAction` | resource: RD GSARA or CT RA | yes | missing: bid ignored silently; RA not parsed / not of this run: debug, ignored | `ncp_parser.py:parse_power_bids` | RD, CT | G, P, all mocks |
| SIS | `nc:PowerBidSchedule` | `nc:PowerBidSchedule.direction` | enum `nc:BidDirectionKind.up` / `.down` | yes | token containing `down` → down; missing or anything else → up, no warning | `ncp_parser.py:parse_power_bids` | RD, CT | G, P, all mocks (both) |
| SIS | `nc:PowerBidSchedule` | `nc:PowerBidSchedule.leadTime` | duration (R0.5) | no | missing or unreadable → 0 (no lead-time restriction), no warning | `ncp_parser.py:parse_power_bids` | lead time | G, P, all mocks (`P0Y0M0DT0H0M0S` only) |
| SIS | `nc:PowerBidSchedule` | `nc:PowerBidSchedule.activationCost` | float, EUR | no | missing: none (no activation cost); non-numeric: run stops; overridden by the time point's | `ncp_parser.py:parse_power_bids` | RD, CT on/off cost | G, P, all mocks |
| SIS | `nc:PowerBidSchedule` | `nc:PowerBidSchedule.currency` | `cim:Currency.EUR` | no | other code: warning, costs used as EUR; missing: nothing | `ncp_parser.py:parse_power_bids`, `warn_if_not_eur` | costs | G, P, all mocks (EUR only) |
| SIS | `nc:PowerBidSchedule` | `nc:PowerBidSchedule.penaltyFactor` | float | no | missing → 0.0; read, not used (the RA-level penaltyFactor is used) | `ncp_parser.py:parse_power_bids` | — | P, all mocks |
| SIS | `nc:PowerBidSchedule` | `nc:PowerBidSchedule.minEnergyBid` | float, MWh | no | read, not used | `ncp_parser.py:parse_power_bids` | — | — |
| SIS | `nc:PowerBidSchedule` | `nc:PowerBidSchedule.maxEnergyBid` | float, MWh | no | read, not used | `ncp_parser.py:parse_power_bids` | — | — |
| SIS | `nc:PowerBidSchedule` | `nc:PowerBidSchedule.stepSizeCTRD` | float, MW | no | read, not used | `ncp_parser.py:parse_power_bids` | — | — |
| SIS | `nc:PowerBidScheduleTimePoint` | `rdf:type` | class | per timestamp | no point at a timestamp → volume 0 at that timestamp | `ncp_parser.py:parse_power_bids` | RD, CT | G, P, all mocks; bid without point: G (3), m:`ct_mock.no_volume_ras` |
| SIS | `nc:PowerBidScheduleTimePoint` | `nc:PowerBidScheduleTimePoint.PowerBidSchedule` | resource | yes | missing: point ignored | `ncp_parser.py:parse_power_bids` | RD, CT | G, P, all mocks |
| SIS | `nc:PowerBidScheduleTimePoint` | `nc:PowerBidScheduleTimePoint.atTime` | `xsd:dateTime` (R0.4) | yes | missing: ignored; not a run timestamp: ignored; two points of one bid at one timestamp: last read wins | `ncp_parser.py:parse_power_bids` | RD, CT | G, P, all mocks |
| SIS | `nc:PowerBidScheduleTimePoint` | `nc:PowerBidScheduleTimePoint.p` | float, MW; the magnitude `abs(p)` is used | yes | missing: point ignored; non-numeric: run stops; negative: used as magnitude, no warning | `ncp_parser.py:parse_power_bids` | RD, CT volume | G, P, all mocks; negative: G (1) |
| SIS | `nc:PowerBidScheduleTimePoint` | `nc:PowerBidScheduleTimePoint.price` | float, EUR/MW; read at the run timestamp `START_HOUR` only | yes | missing or negative: warning, 0; non-numeric: run stops | `ncp_parser.py:parse_power_bids` | RD, CT energy cost | G, P, all mocks |
| SIS | `nc:PowerBidScheduleTimePoint` | `nc:PowerBidScheduleTimePoint.activationCost` | float, EUR | no | present at the run timestamp: replaces the schedule-level value | `ncp_parser.py:parse_power_bids` | on/off cost | — |
| SIS | `nc:PowerBidScheduleTimePoint` | `nc:PowerBidScheduleTimePoint.reservePrice` | float, EUR/MW, at the run timestamp | no | negative: warning, 0; missing: the energy price is used for the curative reservation (logged once per bid, `milp_builder.py:curative_rd_reservation_price_eur_mw`) | `ncp_parser.py:parse_power_bids` | curative RD/CT | Cc |

Not read: `nc:BaseTimeSeries.interpolationKind`, `nc:PowerBidSchedule.priority`,
`nc:PowerBidSchedule.minimumUptime`, `nc:PowerBidDependency`.

### 8.3 GLSK (SIS)

Chain: RD RA ← `PowerBidSchedule.PowerRemedialAction` ← `PowerShiftKeyDistribution.PowerBidSchedule`
→ `PowerShiftKeyDistribution.PowerShiftKeySchedule` → `PowerShiftKeySchedule.GeneratingUnit`;
factor from `ParticipationFactorTimePoint`. Only available RD RAs; only the timestamp `START_HOUR`.

| Profile and file | RDF class | RDF predicate | Value type / allowed values | Req. | Missing / invalid / duplicated | Code location | Feature | Fixtures |
|---|---|---|---|---|---|---|---|---|
| SIS | `nc:PowerShiftKeyDistribution` | `nc:PowerShiftKeyDistribution.PowerBidSchedule` | resource(s); multi-valued, all used | yes | missing: distribution unused (e.g. one linked to a `PowerShiftKeyStrategy` only) | `glsk_resolver.py:resolve_glsk` | RD GLSK | G, P, all mocks; strategy-only: G |
| SIS | `nc:PowerShiftKeyDistribution` | `nc:PowerShiftKeyDistribution.PowerShiftKeySchedule` | resource(s); multi-valued, all used | yes | missing: distribution unused | `glsk_resolver.py:resolve_glsk` | RD GLSK | G, P, all mocks |
| SIS | `nc:PowerShiftKeySchedule` | `nc:PowerShiftKeySchedule.GeneratingUnit` | resource(s): network generator id; multi-valued | yes | none: schedule unused; several: warning, the one factor applies to each | `glsk_resolver.py:resolve_glsk` | RD GLSK | G, P, all mocks; none: G (1) |
| SIS | `nc:ParticipationFactorTimePoint` | `nc:ParticipationFactorTimePoint.PowerShiftKeySchedule` | resource | yes | missing: point ignored | `glsk_resolver.py:resolve_glsk` | RD GLSK | G, P, all mocks |
| SIS | `nc:ParticipationFactorTimePoint` | `nc:ParticipationFactorTimePoint.atTime` | `xsd:dateTime`, must be `START_HOUR` (R0.4) | yes | missing or other time: ignored | `glsk_resolver.py:resolve_glsk` | RD GLSK | G, P, all mocks |
| SIS | `nc:ParticipationFactorTimePoint` | `nc:ParticipationFactorTimePoint.participationFactor` | float ≥ 0 | yes | missing: ignored; non-numeric: warning, ignored; two points for one schedule: last read wins; negative: run stops at MILP build | `glsk_resolver.py:resolve_glsk`, `milp_builder.py:validate_participation_factors` | RD GLSK | G, P, all mocks (0.5, 1.0) |

Not read: `nc:PowerShiftKeyDistribution.PowerShiftKeyStrategy`, `nc:PowerShiftKeyStrategy` (RA file).

### 8.4 Restrictive groups (RA + SIS) — shared by RD and CT

| Profile and file | RDF class | RDF predicate | Value type / allowed values | Req. | Missing / invalid / duplicated | Code location | Feature | Fixtures |
|---|---|---|---|---|---|---|---|---|
| RA | `nc:RemedialActionGroup` | `cim:IdentifiedObject.mRID`, `cim:IdentifiedObject.name` | string | no | fragment / mRID used | `ncp_parser.py:parse_ra_groups` | groups | G, H, Hc, Cc, CH |
| RA | `nc:RemedialActionDependency` | `nc:RemedialActionDependency.kind` | enum `nc:RemedialActionDependencyKind.restrictive` (other kinds: `balanced` → HVDC, section 9; `exclusive` and others ignored) | yes | token not containing `restrictive`: dependency ignored here | `ncp_parser.py:parse_ra_groups` | groups | restrictive: Cc; exclusive: G |
| RA | `nc:RemedialActionDependency` | `nc:RemedialActionDependency.DependingRemedialActionGroup` | resource: group | one of the two | missing both: warning, dependency skipped | `ncp_parser.py:_dependency_group_uri` | groups | G, H, Hc, CH |
| RA | `nc:RemedialActionDependency` | `nc:RemedialActionDependency.RemedialActionGroup` | resource: group. IMPLEMENTATION CHOICE (the earlier inferred name, accepted next to the fixture's `DependingRemedialActionGroup`) | one of the two | as above; when both are present `DependingRemedialActionGroup` wins | `ncp_parser.py:_dependency_group_uri` | groups | Cc |
| RA | `nc:RemedialActionDependency` | `nc:RemedialActionDependency.RemedialAction` | resource: member RA | yes | missing: warning, skipped | `ncp_parser.py:parse_ra_groups` | groups | G, H, Hc, Cc, CH |
| SIS | `nc:RemedialActionGroupTimePoint` | `rdf:type` | class. IMPLEMENTATION CHOICE (inferred wrapper class, see U8.1) | no | none for the group at `START_HOUR`: warning, no limit | `ncp_parser.py:parse_ra_groups` | group limits | Cc |
| SIS | `nc:RemedialActionGroupTimePoint` | `nc:RemedialActionGroupTimePoint.RemedialActionGroup` | resource: group. IMPLEMENTATION CHOICE | yes | missing: point ignored | `ncp_parser.py:parse_ra_groups` | group limits | Cc |
| SIS | `nc:RemedialActionGroupTimePoint` | `nc:RemedialActionGroupTimePoint.atTime` | `xsd:dateTime`, must be `START_HOUR`. IMPLEMENTATION CHOICE | yes | missing or other time: ignored | `ncp_parser.py:parse_ra_groups` | group limits | Cc |
| SIS | `nc:RemedialActionGroupTimePoint` | `nc:RemedialActionGroup.maxRegulatingUp` | float, MW (on the time point subject). IMPLEMENTATION CHOICE | no | missing or non-numeric: no upward limit, no warning | `ncp_parser.py:parse_ra_groups` | group limits | Cc; m:`ct_mock.group(max_up=None)` |
| SIS | `nc:RemedialActionGroupTimePoint` | `nc:RemedialActionGroup.maxRegulatingDown` | float, MW. IMPLEMENTATION CHOICE | no | as maxRegulatingUp | `ncp_parser.py:parse_ra_groups` | group limits | Cc; m:`ct_mock.group(max_down=None)` |

### 8.5 Unit start-up / shut-down costs (SIS; ER fallback)

Parsed only for TSOs with RD RAs (`rd` in `ra_types`), at `START_HOUR`. ER rows: out of the
requested scope, listed because the code reads them.

| Profile and file | RDF class | RDF predicate | Value type / allowed values | Req. | Missing / invalid / duplicated | Code location | Feature | Fixtures |
|---|---|---|---|---|---|---|---|---|
| SIS | `nc:UnitCostSchedule` | `nc:UnitCostSchedule.GeneratingUnit` | resource: CGMES GeneratingUnit mRID (mapped to the generator id via `CGMES.GeneratingUnit`) | yes | missing: schedule ignored | `ncp_parser.py:parse_unit_costs` | F2 on/off | — |
| SIS | `nc:UnitCostSchedule` | `nc:UnitCostSchedule.currency` | `cim:Currency.EUR` | no | other: warning, used as EUR | `ncp_parser.py:parse_unit_costs` | F2 on/off | — |
| SIS | `nc:UnitCostTimePoint` | `nc:UnitCostTimePoint.UnitCostSchedule` | resource | yes | missing or unknown schedule: ignored | `ncp_parser.py:parse_unit_costs` | F2 on/off | — |
| SIS | `nc:UnitCostTimePoint` | `nc:UnitCostTimePoint.atTime` | `xsd:dateTime`, must be `START_HOUR` | yes | missing or other time: ignored | `ncp_parser.py:parse_unit_costs` | F2 on/off | — |
| SIS | `nc:UnitCostTimePoint` | `nc:UnitCostTimePoint.warmStartupCost` | float, EUR ≥ 0 | no | first start-up source; negative: `ValueError`, run stops; non-numeric: run stops | `ncp_parser.py:parse_unit_costs` | F2 on/off | — |
| SIS | `nc:UnitCostTimePoint` | `nc:UnitCostTimePoint.startupCost` | float, EUR ≥ 0 | no | second start-up source; as above | `ncp_parser.py:parse_unit_costs` | F2 on/off | — |
| SIS | `nc:UnitCostTimePoint` | `nc:UnitCostTimePoint.shutdownCost` | float, EUR ≥ 0 | no | first shut-down source; as above | `ncp_parser.py:parse_unit_costs` | F2 on/off | — |
| ER (out of scope) | `nc:GeneratingUnit` (subject of the predicate; class not checked) | `nc:GeneratingUnit.normalWarmStartupCost` | float, EUR ≥ 0 | no | third start-up source; negative: run stops | `ncp_parser.py:parse_unit_costs` | F2 on/off | — |
| ER (out of scope) | `nc:GeneratingUnit` | `nc:GeneratingUnit.normalShutdownCost` | float, EUR ≥ 0 | no | second shut-down source; negative: run stops | `ncp_parser.py:parse_unit_costs` | F2 on/off | — |
| ER (out of scope) | `nc:GeneratingUnit` | `nc:GeneratingUnit.costCurrency` | `cim:Currency.EUR` | no | other: warning | `ncp_parser.py:parse_unit_costs` | F2 on/off | — |

A cost that stays missing means that state change is not allowed (`UnitCost` None).

### 8.6 Rules and checks

- A GSARA with RotatingMachineActions whose machines are all missing from the CGM yields no
  RDUnit; its bids are then not parsed (silently).
- Bids are kept only for RAs parsed in this run (`ra_mrids`).
- Bid volume at a timestamp without a time point: 0. Price: the run timestamp's.
- Lead time > 0 not satisfied by RAART at a timestamp → bid volume bounds 0 there
  (`milp_builder.py:_timestamp_is_usable`).
- GLSK: a unit not in the network → removed (warning) and the factors renormalised; a unit not
  connected → removed (warning); remaining total ≤ 0 → empty GLSK (warning); no factor at all →
  empty GLSK (warning). A bid whose GLSK has no modelled unit → volume fixed to 0 (logged).
- Negative participation factor that survives normalisation → `ValueError` at MILP build.
- An HVDC EquivalentInjection that is also a unit of an RD GLSK → `ValueError`
  (`hvdc_units.py:validate_units_not_in_rd_glsk`).
- Restrictive group: sum of the member bids' upward (downward) volume ≤ maxRegulatingUp (Down),
  hard constraint; only bids count, so PST or HVDC members have no effect. No limit in either
  direction → warning, no constraint; limit but no member bid in the model → warning.
- Unit costs: negative start-up or shut-down cost → `ValueError`, run stops.
- `nc:RedispatchRemedialAction` (and `nc:CountertradeRemedialAction` when `countertrade` is not in
  `ra_types`) → one warning per RA, ignored. This warning is written by `parse_rd_units`, so only
  when `rd` is in `ra_types`.

### 8.7 Edge cases

- Preventive RD RA with bids up and down → volumes at each timestamp.
- Curative RD RA, linked / not linked → listed contingencies / all contingencies.
- Curative RD with `timeToImplement` > TATL duration → not available on that branch.
- RD RA with two RotatingMachineActions → two RDUnits, one RA.
- RotatingMachine not in the CGM → warning, unit skipped.
- Bid without any time point → volume 0 everywhere.
- Bid with a point at some timestamps only → 0 at the others.
- Bid without price / negative price → warning, price 0.
- Negative `p` → magnitude used.
- Bid direction missing → up.
- Lead time > 0 → bid blocked at early timestamps.
- Time-point activationCost present → overrides the schedule value.
- reservePrice present / missing / negative → used / energy price / 0 with warning.
- Currency not EUR → warning.
- PowerBidSchedule without `PowerRemedialAction` → ignored.
- GLSK: one unit, several schedules, schedule with several units (warning), unit not in the network,
  unit disconnected, factors summing to 0, negative factor (run stops), no factor at `START_HOUR`
  (empty GLSK).
- Distribution linked to a PowerShiftKeyStrategy only → unused.
- Restrictive group with up only, down only, both, none (warning), no member bid (warning).
- Dependency with `DependingRemedialActionGroup` vs `RemedialActionGroup` predicate → both accepted.
- Dependency of kind `exclusive` → ignored.
- Unit costs: SIS warm start-up, SIS start-up only, ER only, none (state change not allowed), negative (run stops).
- `nc:RedispatchRemedialAction` → warning, ignored.

## 9. HVDC

### 9.1 RA class and attributes

An HVDC unit is an `nc:GridStateAlterationRemedialAction` with exactly one
`nc:EquivalentInjectionAction`.

| Profile and file | RDF class | RDF predicate | Value type / allowed values | Req. | Missing / invalid / duplicated | Code location | Feature | Fixtures |
|---|---|---|---|---|---|---|---|---|
| RA | `nc:GridStateAlterationRemedialAction` | `rdf:type` | class | yes | — | `ncp_parser.py:parse_hvdc_units` | HVDC | H, Hc, CH |
| RA | (common attributes) | section 6; penaltyFactor missing → 0.0 with warning | | | | | | |
| RA | `nc:EquivalentInjectionAction` | `rdf:type` | class | yes | more than one on one RA: `ValueError`, run stops | `ncp_parser.py:parse_hvdc_units` | HVDC | G (scheme only), H, Hc, CH |
| RA | `nc:EquivalentInjectionAction` | `nc:GridStateAlteration.GridStateAlterationRemedialAction` | resource: GSARA | yes | missing: info "part of a remedial action scheme", ignored | `ncp_parser.py:parse_hvdc_units` | HVDC | H, Hc, CH; missing: G (2) |
| RA | `nc:EquivalentInjectionAction` | `nc:EquivalentInjectionAction.EquivalentInjection` | resource: EquivalentInjection mRID = pypowsybl generator id | yes | missing: warning, ignored; not a generator of the network: `ValueError`; another CGMES class: warning, used | `ncp_parser.py:parse_hvdc_units`, `hvdc_units.py:read_unit_network_data` | HVDC | G, H, Hc, CH |

### 9.2 Ranges

| Profile and file | RDF class | RDF predicate | Value type / allowed values | Req. | Missing / invalid / duplicated | Code location | Feature | Fixtures |
|---|---|---|---|---|---|---|---|---|
| RA | `nc:StaticPropertyRange` | `nc:RangeConstraint.GridStateAlteration` | resource: the unit's EquivalentInjectionAction | yes | other target: not read for HVDC | `ncp_parser.py:parse_hvdc_units` | HVDC limits | H, Hc, CH; on scheme actions: G |
| RA | `nc:StaticPropertyRange` | `nc:StaticPropertyRange.PropertyReference` | resource ending in `EquivalentInjection.p` | no | missing: accepted; other property: ignored silently | `ncp_parser.py:parse_hvdc_units` | HVDC limits | H, Hc, CH |
| RA | `nc:StaticPropertyRange` | `nc:RangeConstraint.direction` | token `up`, `down`, `upAndDown` (`nc:RelativeDirectionKind`) | yes | `none`: warning (fixed set point), ignored; other or missing: warning, ignored | `ncp_parser.py:parse_hvdc_units` | HVDC limits | up, down, upAndDown: H, Hc, CH; none: G (scheme, not read) |
| RA | `nc:StaticPropertyRange` | `nc:RangeConstraint.valueKind` | token `absolute`, `incremental` (`nc:ValueOffsetKind`) | yes | other or missing: warning, ignored | `ncp_parser.py:parse_hvdc_units` | HVDC limits | H, Hc, CH (both) |
| RA | `nc:StaticPropertyRange` | `nc:RangeConstraint.normalValue` | float, MW (incremental: magnitude ≥ 0) | yes | missing: warning, ignored; non-numeric: warning, ignored; negative incremental: `ValueError` | `ncp_parser.py:parse_hvdc_units`, `hvdc_units.py:resolve_operating_limits` | HVDC limits | H, Hc, CH |

### 9.3 Balanced groups

| Profile and file | RDF class | RDF predicate | Value type / allowed values | Req. | Missing / invalid / duplicated | Code location | Feature | Fixtures |
|---|---|---|---|---|---|---|---|---|
| RA | `nc:RemedialActionDependency` | `nc:RemedialActionDependency.kind` | token exactly `balanced` | yes | other kinds: not an HVDC group | `ncp_parser.py:parse_balanced_ra_groups` | HVDC groups | H, Hc, CH |
| RA | `nc:RemedialActionDependency` | `nc:RemedialActionDependency.DependingRemedialActionGroup` / `nc:RemedialActionDependency.RemedialActionGroup` (IMPLEMENTATION CHOICE, see 8.4) | resource: group | one of the two | missing: warning, skipped | `ncp_parser.py:_dependency_group_uri` | HVDC groups | DependingRemedialActionGroup: H, Hc, CH |
| RA | `nc:RemedialActionDependency` | `nc:RemedialActionDependency.RemedialAction` | resource: HVDC RA | yes | missing: warning, skipped | `ncp_parser.py:parse_balanced_ra_groups` | HVDC groups | H, Hc, CH |
| RA | `nc:RemedialActionGroup` | `cim:IdentifiedObject.mRID`, `cim:IdentifiedObject.name` | string | no | fragment / mRID; same group mRID in several TSO files: merged | `ncp_parser.py:parse_balanced_ra_groups`, `hvdc_units.py:validate_hvdc_structure` | HVDC groups | H, Hc, CH |

SIS time-point data for HVDC: none is read.

### 9.4 Rules and checks (`hvdc_units.py`)

- The same HVDC RA mRID in two files → `ValueError`.
- A balanced group without any HVDC unit → info, skipped (not an HVDC group).
- A balanced group with a member that is not an HVDC unit → `ValueError`.
- A unit in two balanced groups → `ValueError` (checked before any group is dropped).
- A group with an unavailable unit → group and both units dropped (info).
- A group with other than exactly two units → `ValueError`.
- A group mixing preventive and curative → `ValueError`.
- Both units on the same EquivalentInjection → `ValueError`.
- Two preventive units on one EquivalentInjection → `ValueError`.
- An available unit in no balanced group → `ValueError`.
- EquivalentInjection not a network generator → `ValueError`; not connected or outside the main
  synchronous component → `ValueError` (`check_units_in_solved_network`).
- Description of the EI (or its terminal / node) not starting with `HVDC` → warning only (EQ data).
- Operating limits per side: the most restrictive of the technical limit (EI minP/maxP, CGM) and
  every range of that side (`resolve_operating_limits`): absolute `up` v → max v; `down` v → min v;
  `upAndDown` v → ±|v|; incremental v → P0 ± v.
- No bound on a side (no technical limit and no range) → `ValueError`; Pmin > Pmax → `ValueError`;
  negative incremental value → `ValueError`; no technical limits at all → warning.
- CGM set point outside the resolved range → range widened to include it, warning (H3.4).
- Curative unit without ranges of its own → the preventive unit's ranges on the same EI.
- Curative units when N-X is off → dropped (info).
- EquivalentInjection also in an RD GLSK → `ValueError`.

### 9.5 Edge cases

- Preventive pair, absolute `upAndDown` range on one, incremental up/down on the other.
- Two ranges on one side (e.g. down 60 and down 40) → the more restrictive wins.
- Range direction `none` → warning, ignored.
- Range with a non-numeric value or unknown valueKind → warning, ignored.
- PropertyReference other than `EquivalentInjection.p` → range ignored.
- Range set point outside → widened with warning.
- Unit without ranges and without technical limits → run stops.
- Negative incremental value → run stops.
- Curative pair with own ranges / without (preventive ranges used).
- Curative pair linked to one contingency / unlinked (all contingencies).
- Unit with `normalAvailable` false → its group dropped.
- Group of 1 or 3 units → run stops.
- Mixed preventive/curative group → run stops.
- Unit without group → run stops.
- Same EI in both units → run stops.
- One RA with two EquivalentInjectionActions → run stops.
- The same HVDC RA mRID in two TSO files → run stops.
- EquivalentInjectionAction without GSARA (scheme) → info, ignored.
- Balanced group whose members are not HVDC units only → run stops; with no HVDC unit → info, skipped.
- penaltyFactor missing → 0.0, warning.

## 10. Countertrade (CT)

### 10.1 RA class and attributes

| Profile and file | RDF class | RDF predicate | Value type / allowed values | Req. | Missing / invalid / duplicated | Code location | Feature | Fixtures |
|---|---|---|---|---|---|---|---|---|
| RA | `nc:CountertradeRemedialAction` | `rdf:type` | class | yes | when `countertrade` is not in `ra_types`: warning (from `parse_rd_units`), ignored | `ct_units.py:parse_ct_remedial_actions` | CT | G (1), C, Cc, CH |
| RA | (common attributes) | section 6; kind: `curative` substring, as PST/RD | | | | | | |
| RA | `nc:CountertradeRemedialAction` | `nc:CountertradeRemedialAction.gLSKStrategy` | token `proportionalForRemainingCapacity` (`nc:GLSKStrategyKind`). IMPLEMENTATION CHOICE | one of RA / bids | see 10.3 | `ct_units.py:parse_ct_remedial_actions` | CT | C, Cc, CH; missing: G; m:`ct_mock.ra(strategy=None)`, m:`unknown_strategy_ras` |
| RA | `nc:CountertradeRemedialAction` | `nc:CountertradeRemedialAction.powerShiftKey` | any | no | read only to name it in the "no gLSKStrategy" warning; not supported | `ct_units.py:parse_ct_remedial_actions` | — | G |
| RA | `nc:CountertradeRemedialAction` | `nc:PowerRemedialAction.BiddingZone` | resource: BiddingZone mRID of the Organisation profile | yes | missing: warning, RA ignored; not in the Organisation profile: warning, RA dropped; zone without candidate unit: warning, RA dropped | `ct_units.py:parse_ct_remedial_actions`, `resolve_zone_units` | CT | G, C, Cc, CH; unknown zone: m:`ct_mock.bad_zone_ras` |
| SIS | `nc:PowerBidSchedule` | `nc:PowerBidSchedule.gLSKStrategy` | token as above. IMPLEMENTATION CHOICE | one of RA / bids | see 10.3 | `ct_units.py:parse_ct_remedial_actions` | CT | m:`ct_mock.bid(strategy=...)`, m:`mixed_strategy_ras` |

Not read: `nc:CountertradeRemedialAction.method` (G: `ShiftMethodKind.shared`).
`linked_xne_mrids` of a CT RA is never filled.

### 10.2 Bids, groups, SIS time-point data

Bids: as 8.2 (`parse_power_bids` with the usable CT RA mRIDs), plus `PowerBidSchedule.gLSKStrategy`
above. Restrictive groups: as 8.4 (a CT RA can be a member; parsed for the TSOs of the usable CT
RAs). No GLSK is read from SIS for CT: the units and weights come from the bidding zone's control
areas in the CGM (`resolve_zone_units`, `resolve_ct_weights`).

### 10.3 Rules and checks

- Declared strategies = the RA's `gLSKStrategy` ∪ every `gLSKStrategy` of its bids.
  None declared → warning (naming `powerShiftKey` when present), RA ignored. More than one
  distinct value → warning, RA ignored. One value other than `proportionalForRemainingCapacity`
  → warning, RA ignored.
- No `BiddingZone` → warning, RA ignored.
- Zone not in the Organisation profile → warning, RA dropped; zone with no candidate unit
  (EquivalentInjection or external grid, not connected, outside the main component, or unbounded
  limits) → warning, RA dropped; no unit can move in either direction → warning, RA dropped.
- RA without any bid → warning, kept (it can do nothing).
- Bid without volume at the run timestamp → warning, volume 0.
- penaltyFactor missing → 1.0 with warning.
- Curative CT: available on a branch when reaction time ≤ TATL duration; contingency links as RD.
- CT RA duplicates across files: not checked (see U10.1).

### 10.4 Edge cases

- Strategy on the RA only → usable.
- Strategy on the bids only → usable.
- Strategy on RA and bids, equal → usable.
- RA and bid strategies differ, or bids differ among themselves → ignored.
- Unknown strategy (e.g. `explicitInstruction`) → ignored.
- No strategy, `powerShiftKey` present → ignored (warning names it).
- No BiddingZone → ignored.
- Zone not in the Organisation profile → dropped.
- Zone whose only unit is in another synchronous component → dropped.
- RA without bids → kept, warning.
- Bid without time point → volume 0, warning.
- penaltyFactor missing → 1.0, warning.
- Curative CT with `timeToImplement` and reservePrice, linked / unlinked.
- CT RA in a restrictive group with maxRegulatingUp / Down.
- `countertrade` not in `ra_types` but `rd` is → warning per CT RA, ignored.
- `normalAvailable` false → parsed, not optimised.

## 11. UNVERIFIED items

Things the code does not settle, or that this investigation did not confirm. Each needs a decision
or a check before a test relies on it.

- U3.1 UNVERIFIED: Whether every `AssessedElement.ConductingEquipment` of G resolves to a CGM branch: not
  checked against `CGM_package.zip` here, so the "branch not in the CGM" case is not known to be
  covered.
- U4.1 UNVERIFIED: Whether the SHS values of G and P differ by more than 10 % from the CGM static limit for
  some AE (warning path): not checked against the CGM here.
- U5.1 UNVERIFIED: A contingency with no `ContingencyEquipment` is kept with an empty list and registered with
  `add_multiple_elements_contingency([], ...)`; what pypowsybl does with it is not established.
- U5.2 UNVERIFIED: The same contingency mRID in two TSO files is appended twice; the effect on the pypowsybl
  contingency container (duplicate id) is not established.
- U5.3 UNVERIFIED: Whether any fixture contingency names equipment that is not in the CGM (warning path): not
  checked against the CGM here.
- U6.1 UNVERIFIED: A `ContingencyWithRemedialAction.Contingency` that names an unknown or not-must-study
  contingency is not validated; for PST it creates CRA entries for that mRID. That this has no
  effect on the model is expected from the code but not confirmed by a test.
- U7.1 UNVERIFIED: The PST curative range mapping is stated in the code as not verified against real
  curative PST data. The direction mapping (`up`/`upAndDown` → upper, `down` → lower) is now confirmed
  as intended (DECISIONS 83); `valueKind` being ignored and the values cast to int remain unverified.
- U7.2 UNVERIFIED: Two preventive GSARAs on the same TapChanger give two preventive PST objects on one
  transformer; the MILP behaviour for that case is not established (only preventive + curative is
  covered by a fixture).
- U7.3 UNVERIFIED: `build_pst_tap_bounds_curative` keeps one TapPositionAction per TapChanger (the last read):
  with a preventive and a curative GSARA on the same TapChanger, which action's range is used is
  graph-order dependent.
- U7.4 UNVERIFIED: A GSARA that has both a TapPositionAction and a RotatingMachineAction (or an
  EquivalentInjectionAction) is parsed by each parser independently; the combined effect is not
  established.
- U8.1 UNVERIFIED: `nc:RemedialActionGroupTimePoint` and its predicates (including
  `nc:RemedialActionGroup.maxRegulatingUp/Down` placed on the time point) are inferred names (code
  docstring "inferred"); only the mock uses them, no real NCP sample confirms them.
- U8.2 UNVERIFIED: A negative `maxRegulatingUp/Down` is not checked; with non-negative bid volumes the hard
  group constraint would be infeasible, not confirmed.
- U8.3 UNVERIFIED: A negative bid-level `RemedialAction.penaltyFactor` or `activationCost` is not checked; the
  objective effect is not established.
- U10.1 UNVERIFIED: The same CT RA mRID in two TSO files is not checked.

## 12. Fixture coverage

Present in the fixtures (see the Fixtures column for each row): AE secured / scanned / no-region
classification and two of the three exclusion reasons (G); SHS PATL (G, P, mocks);
BaseCaseCurrentLimit (P, mocks); the three contingency classes with one and two elements (G, P);
preventive and curative PSTs with timing (P); curative PSTs without timing (G); preventive and curative
RD with bids, ramp rates and GLSK (P); unsupported RedispatchRemedialAction and a CT RA without
strategy (G); HVDC preventive and curative pairs with absolute and incremental ranges (H, Hc, CH);
CT preventive and curative RAs, reservePrice and one restrictive group with SIS limits (C, Cc, CH);
bids without time points, negative `p`, a strategy-only PowerShiftKeyDistribution and a
PowerShiftKeySchedule without unit (G); a scheme EquivalentInjectionAction (G).

Gaps (in no fixture, or only through a mock parameter as marked). All of them are closed out by the generated
NCP test dataset (`tests/ncp_dataset.py`); the status after each gap points to the rows of
`docs/ncp_dataset_coverage.md` (section 6 there has the same list):

- F1 ER profile file (any). Status: covered (B34, B35).
- F2 `UnitCostSchedule` / `UnitCostTimePoint` in SIS. Status: covered (B34, C34).
- F3 `AssessedElement.Line`. Status: covered (B9).
- F4 `AssessedElement.DCTieCorridor` / `AssessedPowerTransferCorridor` (AE without equipment but with these). Status: covered (C3).
- F5 AE with secured + scanned and no exclusion reason. Status: covered (B3).
- F6 AE with an exclusion reason and no ScannedForRegion (EXCLUDED by reason). Status: covered (B6).
- F7 `SecuredExclusionReasonKind.capacityCalculationRegion`. Status: covered (B5).
- F8 Invalid exclusion reason. Status: covered (C1).
- F9 AE with no equipment reference at all (only the AssociationWith* subjects of G hit the warning). Status: covered (C2).
- F10 Non-numeric `BaseCaseCurrentLimit.normalValue` / SHS `value`. Status: covered (C5, C7).
- F11 `Contingency.normalMustStudy` false or missing. Status: covered (B16, C9).
- F12 Contingency without `ContingencyEquipment`. Status: covered (parser) (C8).
- F13 Same contingency mRID in two TSO files. Status: covered (parser) (C10).
- F14 `RemedialAction.normalAvailable` false or missing (only m:`hvdc_mock.ra(available=False)`, m:`ct_mock.ra(available=False)`). Status: covered (B25, B26, C37).
- F15 `RemedialAction.kind` missing or unknown token. Status: covered (C11).
- F16 Non-numeric `penaltyFactor`. Status: covered (C12).
- F17 Unreadable `timeToImplement` (years/months, garbage). Status: covered (C13, C14).
- F18 PST GSARA with several TapPositionActions (preventive and curative PST groups). Status: covered (B20, B21).
- F19 PST `StaticPropertyRange` (curative tap bounds), including `upAndDown`, `none`, one-sided. Status: covered (B22, C16-C19).
- F20 TapPositionAction on a RatioTapChanger or on a transformer missing from the CGM. Status: covered / not producible (C15 / section 4).
- F21 `timePerStage` `PT0S` or unreadable on a curative PST. Status: covered (fixed) (A1).
- F22 Restrictive group with RD members (only CT members in Cc). Status: covered (B32).
- F23 Restrictive group without SIS limit, or with one direction only (only m:`ct_mock.group(max_up/max_down=None)`). Status: covered (C20, C21).
- F24 `PowerBidScheduleTimePoint.activationCost` (time-point override). Status: covered (B28).
- F25 Missing or negative `PowerBidScheduleTimePoint.price`. Status: covered (C22).
- F26 Negative `reservePrice`. Status: covered (C23).
- F27 `PowerBidSchedule.leadTime` > 0. Status: covered (B29).
- F28 Currency other than EUR. Status: covered (C24).
- F29 `PowerBidSchedule.direction` missing. Status: covered (C25).
- F30 `minEnergyBid`, `maxEnergyBid`, `stepSizeCTRD` (read, unused). Status: covered (C27).
- F31 PowerShiftKeySchedule with several GeneratingUnits. Status: covered (C29).
- F32 Non-numeric or negative `participationFactor`; factors summing to 0. Status: covered (C30, C31, C32).
- F33 RD RotatingMachine not in the CGM. Status: covered (C33).
- F34 HVDC unit with `normalAvailable` false (only m:`hvdc_mock.ra(available=False)`). Status: covered (C37).
- F35 HVDC `penaltyFactor` missing (only m:`hvdc_mock.ra(penalty=None)`). Status: covered (C38).
- F36 HVDC range with direction `none`, unknown valueKind, non-numeric value, or another PropertyReference on a unit's action. Status: covered (C39, C40).
- F37 HVDC structural errors: group of 1 or 3, mixed kinds, same EI twice, unit without group, unit in two groups, RA with two EquivalentInjectionActions, RA defined twice (only through mock parameters / `extra_ra_xml`). Status: covered (a group of one unit fails the same two-unit check as C35's group of three) (C35, C36).
- F38 HVDC balanced dependency using `RemedialActionDependency.RemedialActionGroup`. Status: covered (C42).
- F39 HVDC EquivalentInjection also in an RD GLSK. Status: covered (C43).
- F40 CT strategy on the bids only, mixed strategies, unknown strategy (only m:`ct_mock.bid(strategy=...)`, m:`mixed_strategy_ras`, m:`unknown_strategy_ras`). Status: covered (C44-C46).
- F41 CT RA without BiddingZone. Status: covered (C47).
- F42 CT zone not in the Organisation profile / without usable unit (only m:`ct_mock.bad_zone_ras`). Status: covered (C48).
- F43 CT bid without volume, CT RA without bids, CT penaltyFactor missing (only m:`no_volume_ras`, m:`missing_penalty_ras`). Status: covered (C49, C50, B43).
- F44 RA whose mRID literal differs from its `rdf:ID` fragment. Status: covered (warning added) (A2).
- F45 Time points dated on another day with a matching clock time. Status: covered (B13, C28).
