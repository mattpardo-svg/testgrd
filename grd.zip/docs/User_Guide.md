# User Guide

A plain-language guide to running this pipeline and understanding its output. For decisions and assumptions behind the code, see `DECISIONS.md` and `ASSUMPTIONS.md` in this folder.

---

## What this pipeline does

Given a network model and a set of TSO-submitted remedial-action data, it decides how to move phase-shifting transformers (PSTs), redispatch generation (RD), shift generation inside bidding zones (countertrade) and move the active-power set points of HVDC links to resolve overloads — both under normal conditions and, optionally, under a list of contingencies (N-X security analysis) — at the lowest total penalty cost.

## Running it

```bash
python src/rao/run_pipeline.py
```

Reads its configuration from two required YAML files (below), reads the network and remedial-action data from `input/`, and writes every output file to `output/`.

### Input folder

`input/` (in the repo root) must contain exactly one CGM zip and exactly one NCP zip. A file counts as the CGM zip if its name starts with `cgm`, and as the NCP zip if it starts with `ncp` (upper or lower case, `.zip`), e.g. `cgm.zip` and `NCP_generic.zip`. Zero or several matches stop the run with a clear message. The zips are unpacked to `input/_extracted_cgm` and `input/_extracted_ncp`.

### Output folder

At the start of every run, files in `output/` whose names are registered output files (current or earlier names) are deleted, so results of an earlier run cannot be mistaken for this one. Other files in `output/` are left alone. The run log is written to `output/run_log.txt`.

---

## Configuration

Two files, both required — the pipeline will not start without them:

### `src/rao/config/rao_config.yaml`

Grouped into the sections below:

- **`workflow_toggles`** — `calculation_mode` and `ra_types` (see "Calculation mode and RA types" below), whether contingency (N-X) analysis runs at all, and a few lower-level solve behaviors.
- **`thresholds`** — cutoffs for which branches get modeled at all, and how tightly the solver has to converge before it stops iterating.
- **`iteration_caps`** — how many times the two internal solve loops are allowed to repeat before giving up (ignored by `ac_single_pass`, except `incremental_ac_fallback_max_steps`).
- **`ra_limits`** — optional per-TSO caps on how many remedial actions can be used at once.
- **`penalty_costs`** — the cost weights the solver uses to decide what's "worth" doing. None of these are finalized real-world values — every one is explicitly marked as a placeholder in the file itself.
- **`curative_ra`** — how a curative PST group is treated when one of its members is itself an outage element of a contingency (`blockedGroup` or `reducedGroup`, optionally per TSO).
- **`logging_options`** — `debug_log_mode`: how much INFO-level detail is logged. Warnings are never hidden.
- **`performance`** — `lf_thread_count` (threads of the N-X security and sensitivity analyses, default 1), `solver_time_limit_seconds` and `solver_mip_rel_gap` (HiGHS time limit per solve and MIP gap, default null = not set). A solve stopped at the time limit ends the run with the status `SOLVER_NON_OPTIMAL`.
- **`outputs`** — `write_nx_sensitivity_csvs` (default true): false skips `sensitivity_pst_nx.csv` and `sensitivity_rd_nx.csv`, which have one row per contingency, branch and remedial action.
- **`dc_mode`** — used by `calculation_mode: dc` only: `current_factor_by_nominal_voltage_kv`, the correction factors of the DC currents by nominal voltage (see "DC mode" below).

A missing key stops the run with a `ConfigKeyError` that names the key and the file. The removed keys `enable_pst_remedial_actions` and `enable_rd_remedial_actions` stop the run with a message that names `ra_types`. Values are range-checked when the pipeline starts: the thresholds (`min_loading_threshold_pct*`, `sensitivity_threshold_pct_*`, `max_change_ra_sum_threshold`, `max_change_ra`, `max_change_overload`) must be numbers ≥ 0, and `max_linearisation_iterations`, `max_completeness_iterations` and `incremental_ac_fallback_max_steps` must be integers ≥ 1; otherwise the run stops with a message naming the key, the value and the file. A TSO named in `max_taps_per_tso_overrides` that is not a TSO of the run gets a warning, because the entry would be unused.

Every setting has its own explanatory comment directly in the file — that's the authoritative description of what each one does, not this guide.

#### Calculation mode and RA types

Both are in `workflow_toggles`, are independent of each other, and are also chosen per run on the GUI main page.

- **`ra_types`** (default `[pst, rd]`): the remedial action types the optimisation may use. A non-empty list, no duplicates, values `pst`, `rd`, `hvdc` and `countertrade` (see "HVDC remedial actions" and "Countertrade remedial actions" below). Any other value stops the run at startup with a "not yet supported" message, before any file is read. A type that is not listed is not parsed, gets no sensitivities, no MILP block and no output file (for example `results_curative_pst*.csv` with PST off, and `rd_cra_availability.csv` and the RD result files with RD off). Its summary metrics are 0. Curative-only RD with N-X on still opens the RD workflow.
- **`calculation_mode`** (default `ac_iterative`):
  - `ac_iterative`: the workflow of the functional specification. Sensitivities are recomputed in the linearisation and completeness loops until they converge.
  - `ac_single_pass`: AC load flow, N-X analysis and sensitivities once at the initial state, one MILP build and solve, one applied solution with its AC load flow, then a final check (N-X security analysis at the applied state and the remaining overloads against PATL and TATL, N-0 and N-X, including the linearised curative effect). The pairs in the model are the ones the first build selects (`min_loading_threshold_pct_nx`, default 0 = all usable pairs); the final check only reports, it adds nothing and starts no second pass. The iteration caps and convergence thresholds are ignored (one log line says so). The linearisation is not refreshed, so overloads can remain that the iterative mode would remove; they are reported. Status `SINGLE_PASS`; if the final load flow does not converge, the original network is reported as in the iterative mode.
  - `dc`: DC load flow, DC N-X security analysis and DC sensitivities (active power only), one MILP build and solve, one applied solution, one final AC check that only reports. The initial AC load flow is not run. A DC load flow that does not converge stops the run. See "DC mode" below.

The summary shows `calculation_mode` and `ra_types`. In `ac_single_pass` and `dc` it also holds `final_check_*` metrics per kind (`n0`, `nx_patl`, `nx_tatl`, `nx_scanned`): `_overloaded_elements` (N-0 branches, N-X pairs), `_overloaded_branches` (distinct branches) and `_overload_a` (sum in ampere), and `final_check_nx_evaluated` (False if N-X is off or the N-X load flow of the applied state could not be computed). The N-X metrics cover every pair of the N-X analysis at the applied state, also pairs the model did not hold (for example below `min_loading_threshold_pct_nx`); such pairs are reported, not added to the model.

#### DC mode (`calculation_mode: dc`)

The DC load flow, DC security analysis and DC sensitivities give active power (MW); the model works in ampere against PATL and TATL. Every conversion uses one rule (`pre_milp/dc_conversion.py`):

- Flow: `I = f * |P| * 1000 / (sqrt(3) * V_nom,side * pf)`, with P in MW, V_nom in kV (the nominal voltage of the voltage level on that side of the branch; a transformer has two), `pf` = `dc_power_factor` of `load_flow_config.yaml` (the only power-factor setting, default 1.0, must be > 0) and `f` the correction factor of that nominal voltage.
- Sensitivity: `dI/dx = sign(P_ref) * f * dP/dx * 1000 / (sqrt(3) * V_nom,side * pf)`, in A per degree (PST) or A per MW (redispatch), the units of the AC modes. `P_ref` is the DC reference flow of the same branch side (per contingency for N-X); below 1e-6 MW the sign is +1.
- Correction factors: `dc_mode.current_factor_by_nominal_voltage_kv` in `rao_config.yaml`: `default: 1.0` (required) plus optional entries by nominal voltage in kV, for example `400: 1.1`. A branch side uses the entry of its nominal voltage (exact match), else `default`. The same factor applies to flows and sensitivities. All values must be numbers > 0; keys are `default` or a number (the validation names the key). The table and `dc_power_factor` are checked only when `calculation_mode` is `dc`; the other modes ignore them (a missing `dc_mode` section means every factor 1.0). The table is edited in the config file only, not in the GUI. The calibration of the factors is left to the user.
- The current of the pypowsybl DC security analysis is not used, because it cannot apply the factors and is not documented.

The run: load the CGM, DC load flow (distributed slack as configured; `target_p` of the generators is not changed by it), N-0 and N-X currents and sensitivities converted to ampere, GLSK, costs, TATL data and availability as before, one MILP build and solve, the solution applied once, then one AC load flow (with the incremental fallback) and one AC N-X security analysis at the applied state. The final check reports the remaining overloads in the same `final_check_*` rows as `ac_single_pass`; it adds no pair and starts nothing. No iteration caps, convergence thresholds, completeness loop or refresh are used (ignored, one log line says so). Status `SINGLE_PASS`; the same files as `ac_single_pass`. If the final AC load flow does not converge (also after the incremental fallback), the DC solution stays the result: `final_check_evaluated` is False with `final_check_reason`, the overload rows are left out, `lf_post_n0.csv` says `solution_applied_to_network` false, and the "post-PRA" / "after" columns of `results_nx_loadings.csv` and `results_nx_scanned_elements.csv` show the model's prediction (no AC N-X state of the solution exists).

Summary rows of the DC mode only: `dc_power_factor`, `dc_voltage_levels_with_factor` (voltage levels of the network whose nominal voltage has its own entry in the factor table), `final_check_basis` (`ac`: the optimisation is DC, the check is AC), `final_check_evaluated`, `lf_basecase_basis` (`dc`) and `original_network_currents_basis` (`dc`). The last two say that the currents of the original network are DC currents in ampere in `lf_basecase.csv`, `lf_nx_initial.csv`, `scanned_element_list.csv`, the "initial" columns of `results_nx_loadings.csv` and `results_nx_scanned_elements.csv`, and the "before" side of `lf_post_n0.csv`. All currents in the result files are the converted currents.

If the final AC load flow does not converge (also after the incremental fallback), the DC solution stays the result: the PST and RD rows are those of the solved model, `final_check_evaluated` is `False` with `final_check_reason`, the overload rows are left out, `lf_post_n0.csv` has `solution_applied_to_network` false, and the run does not stop. (`ac_single_pass` reports the original network instead; the DC solution has no AC state to revert to.) A DC load flow leaves no bus voltages, so when the direct AC jump fails the apply step runs one extra AC load flow at the unmodified state to obtain the start voltages of the incremental fallback; the normal path has no extra calculation. A solve that is not optimal reports the original network without any AC calculation (`SOLVER_NON_OPTIMAL`, `final_check_evaluated` False).

The sensitivity guard also runs in the DC mode. Its N-X deviation check uses a tolerance of 5 % instead of 1 %: after a contingency that disconnects generation or load, the DC security analysis and the DC sensitivity analysis redistribute the distributed slack differently (up to a few MW, 1.1 % of the current on the fixture; with `distributed_slack` off they agree to 1e-12 MW). The checks for a missing reference, a zero reference and all-zero sensitivities stay exact.

Known limits of the DC mode (read before trusting its result):

- Reactive flow is ignored. Currents on transformers with high reactive flow (generator step-up transformers) are underestimated, so overloads there can be missed. The correction factors are the lever; the final AC check shows what the DC optimisation missed. On the fixture at factor 1.0 the current error is about 8 % (median) and 15-17 % (mean), and DC found 1 of 3 N-0 overloads and missed 11-13 post-contingency violation pairs per fixture.
- Sensitivities are overestimated (median error about 9 %, mean 15-19 %) while flows are underestimated; one factor per voltage level is applied to both.
- Losses are ignored (slack 954 MW in DC against 511 MW in AC) and voltage violations are not seen.
- Per-branch factors and time coupling are not part of the mode. HVDC set points are supported (`ra_types: hvdc`, see below); their sensitivities come from the DC sensitivity analysis. A DC run whose DC model sees no overload leaves the set points where they are, even when the AC network is overloaded.

#### HVDC remedial actions (`ra_types: [.., hvdc]`)

An HVDC link is modelled as two generating-like units on two EquivalentInjections (the two converters of the link), moved against each other: the pair keeps the sum of the set points constant (`dg1 + dg2 = 0`, equal change, opposite direction). Losses are not modelled, so a lossless pair leaves a small mismatch that goes into the slack and shows in the final AC check. Without `hvdc` in `ra_types` nothing HVDC is read, calculated or written.

**NCP data.**
- One `GridStateAlterationRemedialAction` per unit with one `EquivalentInjectionAction` pointing to the EI of the CGM; preventive or curative; optional contingency links and reaction time (curative); `RemedialAction.penaltyFactor`; `RangeConstraint`s.
- The two units of a link are in a `RemedialActionGroup` with a `balanced` `RemedialActionDependency` (both predicate names are read). A group with an HVDC unit has exactly two HVDC units and nothing else; a `balanced` group without any HVDC unit belongs to another RA type and is skipped with a log line. Errors (the run stops with a message naming the RA, group or EI): another number of units, a foreign RA in the group, a unit without a group, a unit in two groups (also when one of them is dropped for an unavailable unit), preventive and curative mixed in one group, the same EI twice in a group, two preventive units on one EI, an EI that is also a unit of an RD GLSK, a unit whose EI is not in the CGM or not in the solved main network, a unit with no bound on a side. Warnings: an EI whose description (on the EI, its terminal or its connectivity node) does not start with "HVDC"; an EI without technical limits (minP/maxP); a missing `penaltyFactor`. A group with an unavailable unit is dropped with both units.
- Range of a unit: the most restrictive `RangeConstraint` per side wins (the lowest maximum, the highest minimum: for absolute down ranges that is the highest value), capped by the technical limits of the EI. If the set point of the CGM lies outside the resulting range, the range is widened to include it (the unit may stay where it is) and a warning names the unit, its EI and the original and widened bounds. `absolute` values are literal (generation sign, "up" = more injection into the AC grid); `incremental` values are magnitudes added to / subtracted from the original set point of the CGM; `upAndDown` with one value is symmetric. Only static ranges count.

**Cost.** `penalty_costs.penalty_reference_hvdc_pra` and `penalty_reference_hvdc_cra` (EUR/MW, default 100 = the RD reference; also on the GUI settings page; read only when `hvdc` is on) times the `penaltyFactor` of each unit times the change. Preventive: the cumulative change against the original network, both units. Curative: the largest curative change of the unit over all contingencies (as curative RD). A missing `penaltyFactor` is 0 with a warning. **A factor of 0 means non-costly: the pair may move anywhere inside its range and the solver may end at the edge of the range. To limit the use, set a small factor above 0.**

**Curative HVDC** needs N-X analysis (with N-X off it is ignored with a log line). A curative unit without a contingency link acts in every contingency; its reaction time is compared with the TATL duration of each branch (as curative RD); it is unavailable in a contingency that removes its EI (or whose sensitivities are exactly zero), and then its partner is unavailable too. It uses the ranges of the preventive unit on the same EI when it has none of its own. The bound is exact per contingency (set point after the preventive actions plus the curative change within the range). Curative actions are never written to the network: the post-contingency result is the MILP prediction (the AC N-X current at the applied state plus the linearised curative effect), there is no AC N-X load flow of the curative state.

**Results.** Preventive set points are written to the network (unrounded) and checked by the AC load flow like redispatch. HVDC MW counts in `sum_abs_rd_change_mw`, `max_abs_rd_change_mw` and the `*_rd_*_mw` columns of `results_iteration_history.csv`, and in convergence criteria 1 and 3. The summary has `sum_hvdc_penalty_cost_eur` (= the PRA and CRA rows added), `sum_pra_penalty_cost_hvdc_eur` and `sum_cra_penalty_cost_hvdc_eur` only when `hvdc` is on; they are part of the objective. An HVDC link contingency (converter or DC line) is not modelled; a contingency makes the RA unavailable only when the EI itself is an outage element.

#### Countertrade remedial actions (`ra_types: [.., countertrade]`)

A countertrade (CT) RA is a power bid of a bidding zone (volume and price, up and down) that shifts generation inside that zone: the volume is spread over the generators of the zone by their remaining capacity (up: Pmax - production, down: production - Pmin, both from the original set points, so the weights never change during a run). The cross-border effect comes from the balance: the CT volumes are balanced together with the redispatch bids, so an up bid in one zone needs a down bid in another zone (or an RD bid). CT can be used alone (`ra_types: [countertrade]`) or with any other type, preventive and curative, in all three calculation modes. Without `countertrade` in `ra_types` nothing CT is read, calculated or written (a CT RA in the NCP is then ignored with a warning, as before).

**NCP data.**
- One `nc:CountertradeRemedialAction` per zone and kind, with `PowerRemedialAction.BiddingZone`, `RemedialAction.kind`, `normalAvailable`, `penaltyFactor`, optional contingency links and `timeToImplement` (curative), and the strategy `nc:CountertradeRemedialAction.gLSKStrategy` = `proportionalForRemainingCapacity` (optionally also `nc:PowerBidSchedule.gLSKStrategy` on its bids). **These two predicate names are an implementation choice and unconfirmed against the ENTSO-E profile.** Another strategy (also `powerShiftKey` / `generatorPmax`), no strategy, or different strategies on the RA and its bids: the RA is ignored with a warning. A RA without a bidding zone is ignored too.
- Bids: the `PowerBidSchedule` objects of the RA (direction, price, volume at the run timestamp, activation cost, lead time; curative bids also a reservation price). A bid without volume has volume 0 with a warning.
- The zone's units come from the Organisation profile (`BiddingZone` <- `SchedulingArea` -> `ControlArea`) and the `ControlAreaGeneratingUnit` objects of the CGM EQ files. A zone that is not in the profile, or has no unit that can take part, drops its RA with a warning. Units that take part: generators (no EquivalentInjection, no external grid), connected, in the main synchronous component, with finite limits, on by the F2 rule, with production not above Pmax and with room in the direction; generators without a unit id or area are dropped from every zone (one log line). A direction with no unit left gets volume 0 (a warning).
- Restrictive RA groups (maxRegulatingUp/Down) and the per-TSO RA-count limits work for CT RAs as for RD; bid dependencies are not implemented (for RD neither).

**Model.** CT bids are RD bids with their own weights per direction: the same variables, the same balance (global in N-0, per contingency for the curative bids), hard Pmin/Pmax rows on the total of RD and CT per unit, and for a unit that RD can shut down one-sided rows so that CT never moves it while it is off. CT never starts or stops a unit and a unit may be in an RD and a CT bid. Curative CT acts like curative RD (R2, R4, R7, R9, R15) and is never applied to the network.

**Cost.** `penalty_costs.penalty_reference_ct_pra` and `penalty_reference_ct_cra` (EUR/MW, default 100 = the RD reference; also on the GUI settings page; read only when `countertrade` is on) times the `penaltyFactor` times the volume, plus bid price times volume and the activation cost of a used bid; curative: the largest curative volume over the contingencies, plus the reservation price (`reservePrice`, else the energy price). A missing `penaltyFactor` is 1.0 with a log line.

**Results.** The set points are written to the network like redispatch and checked by the AC load flow; CT MW counts in `sum_abs_rd_change_mw`, `max_abs_rd_change_mw` and convergence criteria 1 and 3. `ac_single_pass` leaves a linearisation residual (the weights are fixed, the load flow is not linear); `ac_iterative` converges. The result files of RD, PST and HVDC contain no CT rows. Files and summary rows are in the tables below.

**Test data.** The ReliCapGrid data has no valid CT RA; the feature is tested on a generated mock (`tests/ct_mock.py`).

### `src/rao/config/load_flow_config.yaml`

Physical solver settings passed to the underlying power-flow engine (voltage initialization, slack distribution, and similar). Most of these can be left at their defaults; the one worth knowing about specifically is `use_reactive_limits`, which is deliberately off by default — turning it on has been confirmed to cause widespread solve failures on this dataset. `dc_power_factor` (default 1.0, must be > 0 in `calculation_mode: dc`; the load flow page does not accept 0, and a value not > 0 saved by an earlier version is replaced by 1.0 with a note on the pages) converts current limits to power limits in the DC security analysis; it is not an HVDC setting. In `calculation_mode: dc` the same value converts the DC active power to ampere.

### If something goes wrong after changing a setting

Both config files have a matching `.default.yaml` copy (`rao_config.default.yaml`, `load_flow_config.default.yaml`) that's never meant to be edited — a known-good baseline. If a change to the active file causes a failure or produces results that don't make sense, copy the `.default.yaml` over the active file to get back to a state that's been verified to work.

---

## Output files

Written to `output/`. Grouped by what they describe, not the order they're written in.

All text files (CSV, `run_log.txt`) are UTF-8 without BOM, so names with accents or non-Latin letters are kept exactly. In Excel, open a CSV with Data > From Text/CSV and choose File Origin "65001: Unicode (UTF-8)"; a double-click opens it in the Windows codepage and shows such names garbled. The config files (`rao_config.yaml`, `load_flow_config.yaml`) must be saved as UTF-8 too; a file in another encoding stops the run with a message naming the file.

### Base-case (no contingency) results

| File | Contents |
|---|---|
| `lf_basecase.csv` | Every monitored branch's current and loading percentage before any remedial action (in `calculation_mode: dc` the DC currents in ampere; the summary row `lf_basecase_basis` says `dc`) |
| `results_pst.csv` | Per PST: original tap, cumulative change against the original network, final tap, and the cost of that cumulative change (only if PST is active); `last_solve_*` columns show what the final solve alone moved |
| `results_preventive_rd.csv` | Cumulative redispatch per bid against the original network and its cost (only if RD is active); `last_solve_rd_volume_net_mw` is the final solve's own change |
| `results_preventive_rd_ra_count.csv` | How many remedial actions were used per TSO, against any configured limits |
| `results_preventive_rd_ra_groups.csv` | Volume usage against any configured remedial-action group limits |
| `results_lead_times.csv` | Every bid's earliest-usable timestamp, based on its own lead time |
| `results_summary.csv` | Cost components that add up to the objective, the status of the verification loop, `calculation_mode`, `ra_types`, `completeness_iterations`, and `completeness_iteration_limit_reached` (True when the contingency-discovery loop stopped at `max_completeness_iterations` and new congestion may remain) |
| `results_countertrade.csv` | Per preventive countertrade bid (only with `countertrade`): the volume against the original network (MW), the price cost, the penalty factor and cost and the activation cost; `tso`, `zone_mrid`, `zone_name` columns |
| `results_net_positions.csv` | Per bidding zone (only with `countertrade`): the change of net injection from RD (`rd_change_mw`), from countertrade (`ct_change_mw`) and in total; the total adds up to 0 over the zones; units outside every zone are one extra row |
| `results_zone_exchange.csv` | Per zone pair with ties (only with `countertrade`): the exchange a -> b before and after the applied results (MW) and the change; both states come from the same kind of load flow (`load_flow` column: AC in the AC modes, DC in `dc`); the two halves of a tie are paired by their element name and opposite flow, a tie without a partner is skipped with a log line; `tie_count`, `tso_a`, `tso_b` |
| `countertrade_glsk_resolved.csv` | The weights of every countertrade RA and direction (`ra_mrid`, `direction`, `gu_mrid`, `strategy`, `participation_factor`, `tso`, zone); they never change during a run, so there is no iteration column (only with `countertrade`) |
| `results_hvdc.csv` | Per preventive HVDC unit (only with `hvdc`): original, result and change of the set point (MW, floats), the last solve's own change, the operating limits, the penalty factor, the reference and the cost; `tso` column |
| `results_tso_tap_limits.csv` | Per TSO with preventive PSTs: taps used against the `max_taps_per_tso` limit, taps remaining, and whether the limit is binding |
| `results_generating_units.csv` | Per generating unit: initial production, net redispatch volume, resulting production, and the redispatch cost and penalty (only if RD is active). With a usable countertrade RA: the RD columns are the RD part only, `ct_volume_net_mw` (after the RD columns) the countertrade part, and the resulting production is the final dispatch (initial + RD + countertrade); countertrade units without RD follow the RD units as own rows (RD columns 0) |
| `lf_post_n0.csv` | Branch currents after remedial action, for every internal solve iteration |

### Contingency (N-X) results — only present if contingency analysis is enabled

| File | Contents |
|---|---|
| `lf_nx_initial.csv` | Every monitored branch's current under every contingency, before any remedial action |
| `results_nx_loadings.csv` | Same, after remedial action — the main N-X results file. The post-action loading is the actual AC result at the final applied state; the model's own linear prediction and the difference are in separate columns. The predicted loadings after PRA and after PRA+CRA include the linearised preventive and curative HVDC terms (with `hvdc`) |
| `results_contingency_status.csv` | Which contingencies were usable, which were skipped and why (also those lost at a later N-X load-flow refresh, shown as "N-X refresh k: reason"), and whether each one ended up mattering to the final model |
| `results_curative_pst.csv` | Per curative PST and contingency: the curative tap change (up, down, net; not rounded), its bounds, whether the PST was available, and the penalty cost |
| `results_curative_pst_groups.csv` | Per curative PST group and contingency: the group's members and its common curative tap change |
| `results_curative_rd.csv` | Per curative redispatch bid and contingency: the curative volume, its maximum, the price and the cost |
| `results_curative_hvdc.csv` | Per curative HVDC unit and contingency (only with `hvdc` and curative units): the set point after the preventive actions, the curative change (MW) and the set point it implies (never applied), the operating limits, `max_curative_change_mw` (the largest actual curative change of that unit over all its contingencies), the penalty factor and reference and `penalty_cost_eur`. **The cost is per unit** (factor x reference x `max_curative_change_mw`), so it is **repeated on every row of the unit**: do not sum the column over rows, take it once per unit. The two units of a link have opposite changes in each contingency. `tso` column |
| `hvdc_cra_availability.csv` | (per curative HVDC unit) rows with `scope` = `branch`: whether the unit's reaction time is within the TATL duration of that monitored branch (`reaction time above the TATL duration`; if only the partner is too slow: `group atomicity: partner ...`); rows with `scope` = `contingency`: whether the group can act in that contingency, with the `reason` when not: `outage element` (the EI is removed by the contingency), `zero sensitivity` (all sensitivities of the EI are exactly 0 there), `reaction time above the TATL duration on every branch`, or `group atomicity: partner <RA>: <reason>` for the unit whose partner failed. Contingencies the unit is not linked to have no row; an empty `reason` means available. `tso` column |
| `results_curative_countertrade.csv` | Per curative countertrade bid and contingency (only with `countertrade` and curative RAs): the curative volume, its maximum over the contingencies, the price and the reservation price. **`penalty_cost_eur` and `reservation_cost_eur` are per bid** (factor x CRA reference x the maximum; reservation price x the maximum), so they are **repeated on every row of the bid**: take them once per bid. `tso` column |
| `ct_cra_availability.csv` | (per curative countertrade RA and monitored branch) Whether the reaction time is at most the TATL duration of the branch (`available`), with the `reason` when not (`reaction time above the TATL duration of the branch`); `tso` column |
| `results_nx_scanned_elements.csv` | Same idea as the main N-X loadings file, but for monitored-only (not fully enforced) branches |
| `results_iteration_history.csv` | One row per optimisation solve (outer completeness × inner linearisation iteration): objective, size of the change, the value of each convergence criterion (`overload_change_ampere` is the change of the element overloads in A, from the AC state), which criterion declared convergence (`converged_by`), the iteration a cyclic repetition matched, whether the solution was applied, how many contingencies the N-X load-flow refresh after the solve lost (`nx_contingencies_lost_at_refresh`), and the runtime of the solve, the load flows and the sensitivities. Status `CYCLIC_REPETITION` in the result files means the loop stopped because a solution repeated an earlier one |
| `results_completeness_iterations.csv` | How many times the contingency-discovery loop had to re-solve, and how much new congestion it found each time |
| `pst_cra_availability.csv` | (per PST, monitored branch `branch_mrid`, contingency) Which curative PSTs had enough reaction time to be usable under which contingency |
| `rd_cra_availability.csv` | (per curative RD RA and monitored branch) Whether the RA's reaction time is at most the TATL duration of that branch (the fallback duration where there is no real TATL), so whether it enters that branch's N-X constraint. Valid for every contingency |
| `tatl_data.csv` | Temporary loading limits used for contingency checking, including any that had to be estimated because none was directly provided |

### Diagnostic and intermediate files

| File | Contents |
|---|---|
| `co_flat_list.csv` | Every contingency that was successfully parsed, before any usability filtering |
| `scanned_element_list.csv` | Every monitored-only branch and its computed limit |
| `glsk_resolved.csv` | How each redispatch remedial action's volume gets distributed across individual generating units |
| `sensitivity_pst_n0.csv`, `sensitivity_rd_n0.csv` | How much each branch's current changes per unit of PST movement or RD dispatch, base case |
| `sensitivity_pst_nx.csv`, `sensitivity_rd_nx.csv` | Same, per contingency |
| `run_log.txt` | The log of the run (warnings, per-iteration summaries, the stale files removed at the start) |

### How the run ended (status)

Every result file carries `ac_verification_status` and the raw termination reason:

| Status | Meaning |
|---|---|
| `CONVERGED` | A convergence criterion held; the last solution is applied. |
| `MAX_ITERATIONS_REACHED` | The iteration cap ended the loop; the last solution is applied. |
| `CYCLIC_REPETITION` | A solution repeated an earlier one; the best member of the cycle is applied. |
| `REVERTED_NON_CONVERGENT` | A load flow failed and nothing was applied in the run: the files show the original network (no change, blank objective). |
| `REVERTED_TO_LAST_CONVERGED_STATE` | A load flow failed later: the files show the last applied solution. |
| `SENSITIVITY_INVALID` | Invalid sensitivities with no earlier valid set: the files show the last applied solution. |
| `SOLVER_NON_OPTIMAL` | A MILP solve was infeasible or otherwise not optimal: the files show the last applied solution, or the original network when nothing was applied. |

The files never show a solution that was not applied to the network.

### A note on empty files

An output file that exists but contains only a header row is a genuine, checked result — "there was nothing to report here" — not a sign that something failed. A file that's missing entirely means that part of the pipeline never ran at all (usually because the relevant toggle is off). These are meant to be distinguishable at a glance.
