# NCP dataset coverage

The generated NCP test dataset and what it covers, row by row against
`docs/ncp_data_requirements.md` (the requirements file). All data is mock data on
`tests/fixtures/CGM_package.zip`; every mRID the package refers to is an object of that CGM or of the package
itself.

- Generator: `tests/ncp_dataset.py`. `build_valid_ncp(dest)` builds the valid package, `build_variant_ncp(dest, case)`
  one invalid or warning variant (the valid package with one change), `check_data_rules(zip)` the data-rule check
  the generator asserts.
- Valid package, built in three steps: `hvdc_mock.build_hvdc_mock_ncp` (HVDC pairs), then
  `ct_mock.build_ct_mock_ncp` on top (countertrade), then the edits of `ncp_dataset.dataset_edits()` on the
  RDF/XML text (assessed elements, contingencies, PST, RD, unit costs, `Svedala_ER.xml`). The base of the mocks is
  `tests/fixtures/NCP_pst_fallback_scenario.zip`; no fixture and no existing mock output changes.
- Tests: `tests/test_rao_ncp_dataset_valid.py` (part B: one `run_pipeline.main()` per mode with
  `ra_types` pst+rd+hvdc+countertrade and N-X on) and `tests/test_rao_ncp_dataset_variants.py` (parts A and C:
  the variants read by the parsers the pipeline uses, with the CGM inputs built as `run_pipeline.main()` builds
  them).

## 1. Data rules

`check_data_rules` (asserted by `build_valid_ncp`, tested by `test_the_generator_checks_the_data_rules`, which
also checks that a variant breaking each rule is reported):

| Rule | How it holds in the valid package |
|---|---|
| PATL > 0 for every secured element | every NCP PATL (SHS, BaseCaseCurrentLimit) and the CGM fallback are positive |
| TATL current >= PATL, TATL duration > 0 | the TATL is CGM data, not NCP. The generator checks PATL <= CGM TATL for the branches whose PATL it writes (`CGM_TATL_A`). The base package's BaseCaseCurrentLimits (1000-2000 A) are above the CGM TATL (500 A) of their branches; the code raises those TATLs to the PATL (`was_corrected`). `test_the_tatl_is_at_least_the_patl_and_lasts` checks `tatl_data.csv`: every TATL >= the branch PATL, every duration > 0, and some rows corrected |
| every RA in one TSO file | checked over all RA files |
| every curative RA with a readable reaction time | the base package's curative RD RAs had none; the generator gives every curative GSARA without one `PT5M` |
| every bid with direction, volume and price | checked at the run timestamp |
| every HVDC balanced group with exactly two units | checked |
| every countertrade zone with >= 2 usable generators | BZ-Belgovia: BO-G1, BO-G2; BZ-Galia: GA-G1, GA-G2, GA-G3 |

## 2. Overloads the RA types relieve

From an ac_iterative run of the valid package (values of `lf_basecase.csv`, `results_nx_loadings.csv` and the
result files, from a run without the RA-count limit the tests add; they are not asserted, the tests assert that
each type acts, B46 and B47):

| RA type | Overload in the data | What acts |
|---|---|---|
| Countertrade, preventive | N-0: Belgovia half of TieLine_GA_BO4, 124.1 A on a PATL of 100 A (SHS) | BZ-Galia up / BZ-Belgovia down (`results_countertrade.csv`) |
| Countertrade, curative | N-1 outage of TieLine_GA_BO5: the same half at 225.4 A | the curative BZ pair linked to that outage, 171 % → 136 % (`results_curative_countertrade.csv`) |
| HVDC, preventive | N-0: TieLine_SD-EH1, 212.1 A on a PATL of 175 A (SHS) | the SD-EH1 / SD-BO3 pair, about 31 MW (`results_hvdc.csv`) |
| HVDC, curative | N-1 CO_ConformLoad_1 (`hvdc_mock.CO_OVERLOAD_A`): TieLine_SD-EH1 at 185 % before RAs | the curative pair linked to it (`results_curative_hvdc.csv`) |
| PST, preventive | the N-0 overloads above and the N-X overloads of the same two branches (above 100 % in most contingencies before RAs) | PRA_PST_BO_GROUP (both members one tap down) and PRA_PST_Aaa1 (`results_pst.csv`); the outputs do not attribute a tap to one branch |
| PST, curative | Espheim CO2 (outage of line 25-27): line 23-25 at 105.2 % after PRAs; Espheim CO3 / CO4: TieLine_SD-EH1 | CRA_PST_Aac in CO2, CO3 and CO4 (+4 to +5 taps; after PRA + CRA 102.9 %, and 39.8 % on TieLine_SD-EH1, curative RD acting there too), CRA_PST_GA_TR2_1 in Galia CO3 (`results_curative_pst.csv`) |
| RD, preventive | the N-0 overloads above | the Galia GA-G2 and GA-G1 bids (`results_preventive_rd.csv`) |
| RD, curative | Galia CO3 (outage of GA-G1): TieLine_GA_BO4 at 322 % | CRA_RD_GA_G3 up (`results_curative_rd.csv`) |

The N-X overload of Galia CO3 (outage of the 706 MW unit GA-G1) is too large for the RAs of the data; it stays as
a soft N-X penalty in every mode.

## 3. Coverage rows

Fixed: part A. Valid package: part B (test file `test_rao_ncp_dataset_valid.py`). Variants: part C (test file
`test_rao_ncp_dataset_variants.py`, variant name in `ncp_dataset.VARIANTS` / `FILE_VARIANTS`). Requirements
references are the section numbers of the requirements file.

### Part A: the two input fixes (DECISIONS 81, 82)

| # | Requirement | Data | Test |
|---|---|---|---|
| A1 | 7.1 `GridStateAlteration.timePerStage` zero or unreadable: warning naming the PST, left unset, no availability (before: division by zero) | variants `time_per_stage_zero` (`PT0S`), `time_per_stage_unreadable` | `test_a_zero_or_unreadable_time_per_stage_stays_unset_with_a_warning` (2), `test_a_curative_pst_with_a_time_per_stage_of_zero_gets_no_availability_instead_of_a_division_by_zero` |
| A2 | 6.2 a link or bid to an RA mRID that matches no RA of the RA file: one warning per object (matching unchanged) | variant `mrid_differs_from_rdf_id` (RD RA, contingency link and bid using its rdf:ID) | `test_an_ra_whose_mrid_differs_from_its_rdf_id_is_warned_about_and_not_matched`, `test_the_valid_dataset_has_no_reference_to_an_unknown_ra` |

### Part B: the valid package

| # | Requirement | Data | Test |
|---|---|---|---|
| B1 | data rules (section 1) | the whole package | `test_the_generator_checks_the_data_rules` |
| B2 | 4.2 TATL >= PATL, duration > 0 (CGM TATL) | every secured element | `test_the_tatl_is_at_least_the_patl_and_lasts` |
| B3 | 3.2 secured + scanned, no reason → SECURED | AE on EH_line1 (Espheim) | `test_secured_and_scanned_without_a_reason_is_secured` |
| B4 | 3.2 reason + scanned → SCANNED; reason `systemOperator` | AE on LineEH-SD4 | `test_a_reason_with_a_scanned_region_is_scanned[...LINE_EH_SD4]` |
| B5 | 3.2 secured + scanned + reason → SCANNED; reason `capacityCalculationRegion` | AE on TieLine_EH-SD2 | `test_a_reason_with_a_scanned_region_is_scanned[...TIE_EH_SD2]` |
| B6 | 3.2 reason without scanned → EXCLUDED; reason `nonNativeCapacityCalculationRegion` | AE on TieLine_EH-HVDC_EH_SD_1 | `test_a_reason_without_a_scanned_region_is_excluded` |
| B7 | 3.2 no region code → EXCLUDED, info line | AE on TieLine_GA-HVDC_GA_BH_1 | `test_no_region_code_is_excluded_with_an_info_line` |
| B8 | 3.2 scanned only → SECURED | AE on TieLine_GA-HVDC_GA_NH_1 | `test_scanned_only_is_secured` |
| B9 | 3.1 `AssessedElement.Line` | AE on TieLine_SD-HVDC_SD_EH_1 | `test_the_line_predicate_gives_the_branch` |
| B10 | 4.1 PATL from SHS, > 10 % from the CGM (warning) | SHS 100 A for the Belgovia half of TieLine_GA_BO4 | `test_the_patl_from_the_shs_file_wins` |
| B11 | 4.1 PATL from BaseCaseCurrentLimit | 950 A on EH_line1 (CGM 1000 A) | `test_the_patl_from_a_base_case_current_limit` |
| B12 | 4.1 PATL from the CGM (warning) | AE on SER-RLC-1230822986 with an EQ CurrentLimit, no NCP value | `test_the_cgm_patl_is_the_fallback_with_a_warning` |
| B13 | R0.4 time point of another date, same clock time | base SHS point 2023-07-22T10:30 for BO-Line_2 | `test_an_shs_time_point_of_another_date_matches_by_clock_time` |
| B14 | 5.2 each mapped equipment type (line, transformer, gen, load, switch, shuntCompensator, staticVarCompensator, busbar) | base contingencies plus outages of BO-TR2_1, a breaker, an SVC, a busbar | `test_every_mapped_equipment_type` (8) |
| B15 | 5.2 unmappable equipment → warning, contingency excluded | outage of the HVDC line DC-Line-EH_SD1 | `test_unmappable_equipment_excludes_the_contingency` |
| B16 | 5.1 `normalMustStudy` false → parsed, not studied | busbar outage, second outage of line 25-27 | `test_a_contingency_that_is_not_must_study_is_parsed_and_not_studied` (2) |
| B17 | 5.1 Ordinary, Exceptional, OutOfRange | base contingencies | `test_the_three_contingency_classes` |
| B18 | 6.2 curative RA with links (only those contingencies) and without (base RD) | curative HVDC pair → CO_OVERLOAD_A, curative CT → GA_BO5 outage | `test_curative_links_restrict_the_contingencies` |
| B19 | 5.2 / 7.3 an RA element is an outage element (blockedGroup) | outage of BO-TR2_1, linked to the curative Belgovia PST group | `test_an_outage_element_blocks_the_curative_pst_group` |
| B20 | 7.2 preventive PST group (several TapPositionActions) | PRA_PST_BO_GROUP: BO-TR2_1 and BO-TR2_2 | `test_a_preventive_pst_group_moves_its_members_together` |
| B21 | 7.3 curative PST group | CRA_PST_BO_GROUP | `test_a_curative_pst_group_has_one_delta_tap` |
| B22 | 7.2 curative StaticPropertyRange, separate up and down | Aac: up 5, down -5 (curative only) | `test_a_curative_range_with_separate_up_and_down_bounds_the_curative_taps` |
| B23 | 7.3 fast and slow curative reaction | CRA_PST_Aac `PT1M`, CRA_PST_Aaa1 `PT15M` (TATL 10 min) | `test_fast_and_slow_curative_psts` (2) |
| B24 | 6.1 missing `penaltyFactor` (PST: 1.0, warning) | PRA_PST_GA_TR2_2 | `test_a_missing_pst_penalty_factor_is_one_with_a_warning` |
| B25 | 6.1 `normalAvailable` false | CRA_PST_GA_TR2_2 | `test_an_unavailable_curative_pst_has_no_curative_entry` |
| B26 | 6.1 `normalAvailable` missing | PRA_PST_GA_TR2_1 | `test_a_pst_without_normal_available_is_not_used` |
| B27 | 8.2 several bids per RA, price, volume, up and down | PRA_RD_GA_G1_UP with three bids | `test_several_bids_of_one_ra` |
| B28 | 8.2 time-point activation cost overrides the schedule's | second bid: schedule 100, time point 150 | `test_the_activation_cost_of_the_time_point_wins` |
| B29 | 8.2 lead time | bid with `PT2H` | `test_a_lead_time_delays_the_bid` |
| B30 | 8.2 reservation price, and the energy price when none | curative bid with reservePrice 3.0 | `test_the_reservation_price_of_a_curative_bid` |
| B31 | 8.3 GLSK over several units, an unconnected unit removed and redistributed | PRA_RD_SV_MULTI: STORFORS_G1 0.6, STENFORSEN_G1 0.4, KÄRNAN_G3 0.2 | `test_a_glsk_over_several_units_drops_an_unconnected_one` |
| B32 | 8.4 restrictive group with RD members and SIS limits | group of PRA_RD_BO_G1_UP and _G2_UP, 80 / 120 MW | `test_a_restrictive_group_with_rd_members` |
| B33 | per-TSO RA-count limit (config, not NCP) | `max_ra_count_per_timestamp_tso` TSO-Galia 1 in every run | `test_the_per_tso_ra_count_limit` |
| B34 | 8.5 unit costs: SIS warm start-up before start-up, ER fallback | STORFORS_G1 (SIS), STENFORSEN_G1 (`Svedala_ER.xml`) | `test_unit_costs_from_sis_and_er` |
| B35 | 2.1 / 2.2 ER file recognised | `Svedala_ER.xml` | `test_the_er_file_is_read` |
| B36 | 6.2 curative RD reaction time against the TATL | `PT5M` on every curative RD RA | `test_a_curative_rd_reaction_time_against_the_tatl` |
| B37 | 9.3 HVDC pair in one balanced group | preventive SD-EH1 / SD-BO3 | `test_the_hvdc_pair_is_one_balanced_group` |
| B38 | 9.2 absolute `upAndDown` | SD-EH1: 450 MW | `test_an_absolute_up_and_down_range` |
| B39 | 9.2 incremental, two ranges on one side | SD-BO3: up 60, down 60 and 40 | `test_incremental_ranges_with_two_on_one_side` |
| B40 | 9.4 set point outside the range → widened (warning) | curative SD-BO3: absolute up 1 MW below P0 1.56 MW | `test_a_set_point_outside_the_range_widens_it` |
| B41 | 9.4 no technical limits, description not "HVDC" (warnings) | the EIs of the CGM | `test_hvdc_units_without_technical_limits_and_description` |
| B42 | 10.1 two zones, up and down bids | BZ-Belgovia, BZ-Galia | `test_countertrade_in_two_zones_up_and_down` |
| B43 | 10.1 penaltyFactor 0, above 0, missing (1.0, warning) | BO 0.0, GA 0.05, BO-cur missing | `test_countertrade_penalty_factors_zero_above_zero_and_missing` |
| B44 | 10.3 proportionalForRemainingCapacity weights | both zones, both directions | `test_countertrade_weights_from_the_remaining_capacity` |
| B45 | data rule: every zone >= 2 usable units | both zones | `test_every_countertrade_zone_has_at_least_two_units` |
| B46 | every RA type acts preventively in ac_iterative, ac_single_pass, dc | the whole package | `test_every_ra_type_acts_in_each_mode` (3) |
| B47 | every RA type acts curatively in ac_iterative | the whole package | `test_every_curative_ra_type_acts_in_ac_iterative` |

### Part C: invalid and warning variants

| # | Requirement | Variant | Expected outcome | Test |
|---|---|---|---|---|
| C1 | 3.3 invalid exclusionReason | `invalid_exclusion_reason` | error (`ValueError`), run stops | `test_an_invalid_exclusion_reason_stops_the_run` |
| C2 | 3.3 AE without any reference | `ae_without_equipment` | warning, AE skipped | `test_an_ae_without_any_equipment_reference_is_skipped_with_a_warning` |
| C3 | 3.3 AE with a corridor only | `ae_corridor_only` | info, skipped | `test_an_ae_with_only_a_corridor_is_skipped_as_out_of_scope` |
| C4 | 3.3 AE on a non-branch (busbar) | `ae_on_busbar` | info, skipped | `test_an_ae_on_a_busbar_is_skipped` |
| C5 | 4.4 non-numeric BaseCaseCurrentLimit | `bccl_non_numeric` | warning, next PATL source | `test_a_non_numeric_base_case_limit_falls_back_to_the_cgm_patl` |
| C6 | 4.3 PATL 0 | `patl_zero` | branch excluded from the MILP (warning) | `test_a_patl_of_zero_excludes_the_branch_from_the_milp` |
| C7 | 4.4 non-numeric SHS value | `shs_non_numeric` | error, run stops | `test_a_non_numeric_shs_value_stops_the_run` |
| C8 | 5.3 contingency without ContingencyEquipment | `contingency_without_equipment` | kept with an empty list (parser level; pypowsybl effect stays U5.1) | `test_a_contingency_without_equipment_is_kept_with_an_empty_list` |
| C9 | 5.3 `normalMustStudy` missing | `contingency_must_study_missing` | not studied | `test_a_contingency_without_normal_must_study_is_not_studied` |
| C10 | 5.3 same contingency in two files | `contingency_in_two_files` | parsed twice (parser level; run effect stays U5.2) | `test_the_same_contingency_in_two_files_is_parsed_twice` |
| C11 | 6.3 kind unknown / missing | `ra_kind_unknown`, `ra_kind_missing` | preventive | `test_an_unknown_or_missing_kind_is_preventive` (2) |
| C12 | 6.3 non-numeric penaltyFactor | `penalty_factor_non_numeric` | error, run stops | `test_a_non_numeric_penalty_factor_stops_the_run` |
| C13 | 6.3 unreadable timeToImplement, RD | `reaction_time_unreadable_rd` | 0 with a warning | `test_an_unreadable_rd_reaction_time_is_zero_with_a_warning` |
| C14 | 6.3 unreadable timeToImplement, PST | `reaction_time_unreadable_pst` | 0, no warning | `test_an_unreadable_pst_reaction_time_is_zero_without_a_warning` |
| C15 | 7.4 TapPositionAction on a RatioTapChanger | `tap_action_on_ratio_tap_changer` | info, skipped | `test_a_tap_action_on_a_ratio_tap_changer_is_skipped` |
| C16 | 7.4 empty curative range (lower above upper) | `empty_curative_tap_range` | passed on unchecked (open finding, section 5) | `test_an_empty_curative_tap_range_is_passed_on_unchecked` |
| C17 | 7.4 `upAndDown` range | `curative_range_up_and_down` | upper bound only (intended), warning, fallback | `test_an_up_and_down_range_sets_the_upper_bound_only` |
| C18 | 7.4 range with direction `none` | `curative_range_none` | warning, skipped | `test_a_range_with_direction_none_is_skipped_with_a_warning` |
| C19 | 7.4 one-sided range | `curative_range_one_sided` | warning, fallback to the operating range | `test_a_one_sided_range_falls_back_to_the_operating_range` |
| C20 | 8.7 group without limit | `group_without_limit` | warning, kept without limit | `test_a_restrictive_group_without_a_limit_is_kept_with_a_warning` |
| C21 | 8.7 group with one direction | `group_up_only` | up limit only | `test_a_restrictive_group_with_an_up_limit_only` |
| C22 | 8.7 missing / negative price | `bid_price_missing`, `bid_price_negative` | 0 with a warning | `test_a_missing_or_negative_price_is_zero_with_a_warning` (2) |
| C23 | 8.7 negative reservePrice | `bid_reserve_price_negative` | 0 with a warning | `test_a_negative_reserve_price_is_zero_with_a_warning` |
| C24 | 8.7 currency not EUR | `bid_currency_not_eur` | used as EUR, warning | `test_a_currency_other_than_eur_is_used_as_eur_with_a_warning` |
| C25 | 8.7 direction missing | `bid_direction_missing` | up | `test_a_bid_without_direction_is_an_up_bid` |
| C26 | 8.7 bid without volume | `bid_without_volume` | volume 0 | `test_a_bid_without_a_time_point_has_volume_zero` |
| C27 | 8.2 minEnergyBid, maxEnergyBid, stepSizeCTRD | `bid_energy_fields` | read, not used | `test_the_energy_fields_of_a_bid_are_read` |
| C28 | R0.4 bid time point of another date | `bid_time_point_other_day` | matches by clock time | `test_a_time_point_of_another_day_matches_by_clock_time` |
| C29 | 8.7 schedule with two units | `glsk_schedule_with_two_units` | warning, the factor for each | `test_a_shift_key_schedule_with_two_units_gives_each_the_factor_with_a_warning` |
| C30 | 8.7 non-numeric participation factor | `glsk_factor_non_numeric` | warning, skipped (empty GLSK) | `test_a_non_numeric_participation_factor_is_skipped_with_a_warning` |
| C31 | 8.7 factors summing to 0 | `glsk_factors_zero` | warning, empty GLSK | `test_participation_factors_summing_to_zero_give_an_empty_glsk` |
| C32 | 8.7 negative participation factor | `glsk_factor_negative` | error at the MILP build | `test_a_negative_participation_factor_stops_the_milp_build` |
| C33 | 8.7 RotatingMachine not in the CGM | `rd_machine_not_in_cgm` | warning, unit skipped | `test_an_rd_machine_that_is_not_in_the_cgm_is_skipped_with_a_warning` |
| C34 | 8.7 negative unit cost | `unit_cost_negative` | error, run stops | `test_a_negative_unit_cost_stops_the_run` |
| C35 | 9.5 HVDC group of three, unit without group, mixed kinds, same EI twice, defined twice, unit in two groups | `hvdc_group_of_three`, `hvdc_unit_without_group`, `hvdc_mixed_kinds`, `hvdc_same_ei_twice`, `hvdc_defined_twice`, `hvdc_unit_in_two_groups` | error, run stops | `test_an_hvdc_structure_error_stops_the_run` (6) |
| C36 | 9.5 two EquivalentInjectionActions in one RA | `hvdc_two_actions` | error | `test_an_hvdc_ra_with_two_equivalent_injection_actions_stops_the_run` |
| C37 | 9.5 unavailable HVDC unit | `hvdc_unit_unavailable` | group dropped with both units (info) | `test_an_unavailable_hvdc_unit_drops_its_group` |
| C38 | 9.5 HVDC penaltyFactor missing | `hvdc_penalty_missing` | 0.0 with a warning | `test_an_hvdc_unit_without_penalty_factor_is_non_costly_with_a_warning` |
| C39 | 9.5 range direction `none`, unknown valueKind, non-numeric value | `hvdc_range_none`, `hvdc_range_unknown_value_kind`, `hvdc_range_non_numeric` | warning, range ignored | `test_an_unusable_hvdc_range_is_ignored_with_a_warning` (3) |
| C40 | 9.5 range of another property | `hvdc_range_other_property` | ignored silently | `test_an_hvdc_range_of_another_property_is_ignored_silently` |
| C41 | 9.5 negative incremental value | `hvdc_negative_incremental` | error | `test_a_negative_incremental_hvdc_value_stops_the_run` |
| C42 | 9.3 `RemedialActionDependency.RemedialActionGroup` predicate | `hvdc_group_predicate_remedial_action_group` | accepted | `test_a_balanced_dependency_with_the_remedial_action_group_predicate_is_accepted` |
| C43 | 9.4 EI in an RD GLSK | `hvdc_ei_in_rd_glsk` | error | `test_an_equivalent_injection_in_an_rd_glsk_stops_the_run` |
| C44 | 10.4 unknown strategy | `ct_unknown_strategy` | warning, RA ignored | `test_an_unknown_countertrade_strategy_ignores_the_ra` |
| C45 | 10.4 mixed strategies | `ct_mixed_strategy` | warning, RA ignored | `test_mixed_countertrade_strategies_ignore_the_ra` |
| C46 | 10.4 strategy on the bids only | `ct_strategy_on_bids_only` | usable | `test_a_countertrade_strategy_on_the_bids_only_is_usable` |
| C47 | 10.4 no BiddingZone | `ct_without_zone` | warning, RA ignored | `test_a_countertrade_ra_without_bidding_zone_is_ignored` |
| C48 | 10.4 zone without usable units / not in the Organisation profile | `ct_zone_without_units` (BZ-Nordheim), `ct_zone_unknown` | warning, RA dropped | `test_a_countertrade_ra_whose_zone_cannot_act_is_dropped` (2) |
| C49 | 10.4 CT bid without volume | `ct_bid_without_volume` | volume 0 with a warning | `test_a_countertrade_bid_without_volume_is_zero_with_a_warning` |
| C50 | 10.4 CT RA without bids | `ct_ra_without_bids` | kept with a warning | `test_a_countertrade_ra_without_bids_is_kept_with_a_warning` |
| C51 | 2.4 unrecognised file | `loader_unrecognized_file` | warning, skipped | `test_an_unrecognized_file_is_skipped_with_a_warning` |
| C52 | 2.4 cross-TSO export | `loader_cross_tso_export` | skipped, no warning | `test_a_cross_tso_export_is_skipped_without_a_warning` |
| C53 | 2.3 missing required profile | `loader_missing_ra` | error, run stops | `test_a_tso_without_its_ra_file_stops_the_run` |

Counts: 2 part A rows, 47 part B rows, 53 part C rows: 102 rows, all covered. Test functions: 46 (valid) +
57 (variants); collected items: 58 and 68. Every test fails under a deliberate break of the behaviour it covers
(104 mutations of `src/` or of the generator, each killing every item of its tests).

## 4. Not producible from the NCP files

| Item | Why |
|---|---|
| TATL value, duration and its cases (no TATL, one, several on a side, TATL below PATL) | read from the CGM (`network.get_operational_limits()`), not from the NCP. The CGM gives 500 A / 600 s on most branches (below their PATL, so corrected) and no TATL on the tie lines used by the dataset; "several TATLs on a side" and "no TATL and no PATL" are not in the CGM |
| empty preventive tap range | the preventive range is the CGM hardware range; no NCP attribute narrows it |
| TapPositionAction on a transformer missing from the CGM (F20, second half) | every TapChanger of an EQ file has its transformer in the CGM, and the dataset may only refer to CGM objects |
| HVDC EquivalentInjection not in the network or outside the solved main network | CGM data |
| countertrade generators without a GeneratingUnit or control area | CGM / Organisation profile data |
| a contingency result skipped for a network split | the outcome of the CGM load flow, not of the NCP data |
| per-TSO RA-count limits | configuration (`ra_limits.max_ra_count_per_timestamp_tso`), set by the tests (B33) |

Out of scope (requirements file, introduction): the Organisation profile content, the CGM/EQ files, and the
profiles the loader skips (SSI, CD_OR, PS, RAS, FAP, cross-TSO CO exports; C52 checks only that such a file is
skipped).

## 5. Findings

- **Empty curative tap range (open).** `build_pst_tap_bounds_curative` returns a lower bound above the upper bound
  without a check or a warning (C16). The curative tap-bound constraint is then infeasible for that PST and
  contingency. Not changed here (only the two input fixes of part A were in scope); C16 pins today's behaviour.
- **PST range direction (intended).** `up` and `upAndDown` set the upper bound, `down` the lower bound
  (DECISIONS 83); the dataset uses separate up and down ranges.
- **TATL below PATL in the base data.** The base package's PATLs exceed the CGM TATL of their branches; the code
  raises the TATL to the PATL (B2).

## 6. F1-F45 of the requirements file

| F | Status | Where |
|---|---|---|
| F1 ER profile file | covered | B34, B35 |
| F2 UnitCostSchedule / UnitCostTimePoint | covered | B34, C34 |
| F3 `AssessedElement.Line` | covered | B9 |
| F4 corridor-only AE | covered | C3 |
| F5 secured + scanned, no reason | covered | B3 |
| F6 reason without ScannedForRegion | covered | B6 |
| F7 `capacityCalculationRegion` | covered | B5 |
| F8 invalid exclusion reason | covered | C1 |
| F9 AE without any reference | covered | C2 |
| F10 non-numeric BaseCaseCurrentLimit / SHS value | covered | C5, C7 |
| F11 `normalMustStudy` false or missing | covered | B16, C9 |
| F12 contingency without ContingencyEquipment | covered (parser) | C8 |
| F13 same contingency in two files | covered (parser) | C10 |
| F14 `normalAvailable` false or missing | covered | B25, B26, C37 |
| F15 kind missing or unknown | covered | C11 |
| F16 non-numeric penaltyFactor | covered | C12 |
| F17 unreadable timeToImplement | covered | C13, C14 |
| F18 PST groups | covered | B20, B21 |
| F19 PST StaticPropertyRange (up and down, upAndDown, none, one-sided) | covered | B22, C16-C19 |
| F20 RatioTapChanger / transformer missing from the CGM | covered / not producible | C15 / section 4 |
| F21 timePerStage `PT0S` or unreadable | covered (fixed) | A1 |
| F22 restrictive group with RD members | covered | B32 |
| F23 group without limit or one direction | covered | C20, C21 |
| F24 time-point activation cost | covered | B28 |
| F25 missing or negative price | covered | C22 |
| F26 negative reservePrice | covered | C23 |
| F27 leadTime > 0 | covered | B29 |
| F28 currency not EUR | covered | C24 |
| F29 direction missing | covered | C25 |
| F30 minEnergyBid, maxEnergyBid, stepSizeCTRD | covered | C27 |
| F31 schedule with several units | covered | C29 |
| F32 non-numeric or negative factor, factors summing to 0 | covered | C30, C31, C32 |
| F33 RotatingMachine not in the CGM | covered | C33 |
| F34 HVDC unit not available | covered | C37 |
| F35 HVDC penaltyFactor missing | covered | C38 |
| F36 unusable HVDC ranges | covered | C39, C40 |
| F37 HVDC structural errors | covered (a group of one unit fails the same two-unit check as C35's group of three) | C35, C36 |
| F38 RemedialActionGroup predicate | covered | C42 |
| F39 EI in an RD GLSK | covered | C43 |
| F40 CT strategies on bids, mixed, unknown | covered | C44-C46 |
| F41 CT without BiddingZone | covered | C47 |
| F42 CT zone unknown / without units | covered | C48 |
| F43 CT bid without volume, RA without bids, penaltyFactor missing | covered | C49, C50, B43 |
| F44 mRID differs from rdf:ID | covered (warning added) | A2 |
| F45 time points of another date | covered | B13, C28 |

44 covered, F20 covered in part and not producible in part, none out of scope.
