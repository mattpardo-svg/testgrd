"""
test_rao_ct_mock.py — the generated countertrade mock (tests/ct_mock.py, docs/countertrade_ra_specs.md
C12): what is in the zip and in each variant, that the WP1 parser reads it, and that its zone units,
weights and sensitivities on TieLine_GA_BO4 match the real CGM.
"""
import logging
import zipfile

import pytest

import ct_mock
import run_pipeline
from data_model import BidDirection, RAKind
from helpers import FIXTURE_CGM_ZIP, _MOCK_NX_NCP_ZIP
from pre_milp import cgmes_loader, ct_units, n0_sensitivity, ncp_loader, ncp_parser

UP, DOWN = BidDirection.UP, BidDirection.DOWN
TS = "1030Z"
LOG = ct_units.log.name


def _extract(tmp_path, ras=None, **kwargs):
    zip_path = ct_mock.build_ct_mock_ncp(tmp_path / "ncp.zip", ras=ras, **kwargs)
    folder = tmp_path / "ncp"
    with zipfile.ZipFile(zip_path) as archive:
        archive.extractall(folder)
    return zip_path, folder


def _parse(folder, tso, caplog=None):
    args = (folder / f"{tso}_RA.xml", folder / f"{tso}_SIS.xml", tso, [TS], TS)
    if caplog is None:
        return ct_units.parse_ct_remedial_actions(*args)
    with caplog.at_level(logging.INFO, logger=LOG):
        return ct_units.parse_ct_remedial_actions(*args)


def _warnings(caplog):
    return [r.getMessage() for r in caplog.records if r.levelno >= logging.WARNING and r.name == LOG]


# ---------------------------------------------------------------------------
# the zip
# ---------------------------------------------------------------------------

def test_only_the_five_files_are_changed_and_no_file_is_added(tmp_path):
    zip_path = ct_mock.build_ct_mock_ncp(tmp_path / "ncp.zip")
    with zipfile.ZipFile(_MOCK_NX_NCP_ZIP) as source, zipfile.ZipFile(zip_path) as mock:
        assert mock.namelist() == source.namelist()
        changed = {n for n in source.namelist() if source.read(n) != mock.read(n)}
    assert changed == {"Belgovia_RA.xml", "Belgovia_SIS.xml", "Galia_RA.xml", "Galia_SIS.xml", "Belgovia_SHS.xml"}


def test_without_a_patl_the_shs_file_is_unchanged(tmp_path):
    zip_path = ct_mock.build_ct_mock_ncp(tmp_path / "ncp.zip", patl_a=None)
    with zipfile.ZipFile(_MOCK_NX_NCP_ZIP) as source, zipfile.ZipFile(zip_path) as mock:
        assert source.read("Belgovia_SHS.xml") == mock.read("Belgovia_SHS.xml")


def test_the_built_zip_is_deterministic(tmp_path):
    first = ct_mock.build_ct_mock_ncp(tmp_path / "a.zip").read_bytes()
    second = ct_mock.build_ct_mock_ncp(tmp_path / "b.zip").read_bytes()
    assert first == second


def test_the_pipeline_loader_finds_the_files_of_the_mock(tmp_path):
    zip_path = ct_mock.build_ct_mock_ncp(tmp_path / "ncp.zip")
    folder = tmp_path / "extracted"
    org = ncp_loader.extract_ncp_zip(zip_path, folder)
    files = ncp_loader.classify_extracted_ncp_files(folder, ncp_loader_tso_names(org))
    assert {"RA", "SIS", "SHS"} <= set(files["TSO-Belgovia"]) and {"RA", "SIS"} <= set(files["TSO-Galia"])


def ncp_loader_tso_names(org_path):
    from pre_milp import tso_name_resolver
    return tso_name_resolver.build_tso_name_map(org_path)


def test_a_source_zip_without_the_needed_file_is_refused(tmp_path):
    with pytest.raises(ValueError, match="no \\['Galia_RA.xml'"):
        source = tmp_path / "small.zip"
        with zipfile.ZipFile(_MOCK_NX_NCP_ZIP) as full, zipfile.ZipFile(source, "w") as small:
            for name in full.namelist():
                if name != "Galia_RA.xml":
                    small.writestr(name, full.read(name))
        ct_mock.build_ct_mock_ncp(tmp_path / "out.zip", source_zip=source)


# ---------------------------------------------------------------------------
# the default mock parses
# ---------------------------------------------------------------------------

def test_the_default_mock_gives_one_preventive_ra_per_zone_with_an_up_and_a_down_bid(tmp_path):
    _, folder = _extract(tmp_path)
    expected = {
        "Belgovia": (ct_mock.ZONE_BELGOVIA, {"up": (150.0, 12.0), "down": (150.0, 8.0)}),
        "Galia": (ct_mock.ZONE_GALIA, {"up": (150.0, 20.0), "down": (150.0, 15.0)}),
    }
    for tso, (zone, bids_expected) in expected.items():
        ras, bids = _parse(folder, tso)
        assert len(ras) == 1 and len(bids) == 2
        ra = ras[0]
        assert ra.zone_mrid == zone and ra.kind == RAKind.PREVENTIVE and ra.available
        assert ra.strategy == ct_mock.STRATEGY and ra.penalty_factor == 1.0
        assert ra.reaction_time_minutes is None and ra.linked_contingency_mrids == []
        for bid in bids:
            volume, price = bids_expected[bid.direction.value]
            assert bid.ra_mrid == ra.mrid and bid.available_mw[TS] == volume and bid.price_eur_mw == price
            assert bid.available_mw[TS] >= 100.0
    belgovia_bids = {b.direction: b for b in _parse(folder, "Belgovia")[1]}
    assert belgovia_bids[UP].activation_cost_eur == 500.0 and belgovia_bids[DOWN].activation_cost_eur == 300.0


def test_the_ct_additions_do_not_change_the_rd_units_of_the_mock(tmp_path, real_network):
    _, folder = _extract(tmp_path)
    with zipfile.ZipFile(_MOCK_NX_NCP_ZIP) as archive:
        archive.extractall(tmp_path / "original")
    unit_data = {
        gu: {"name": g.name, "target_p": g.prod, "max_p": g.pmax, "min_p": g.pmin} for gu, g in real_network.generators.items()
    }
    parsed_rd_units = 0
    for tso in ("Belgovia", "Galia"):
        with_ct = ncp_parser.parse_rd_units(
            folder / f"{tso}_RA.xml", folder / f"{tso}_SIS.xml", tso, [TS], unit_data, price_timestamp=TS, warn_countertrade=False)
        without = ncp_parser.parse_rd_units(
            tmp_path / "original" / f"{tso}_RA.xml", tmp_path / "original" / f"{tso}_SIS.xml", tso, [TS], unit_data,
            price_timestamp=TS)
        assert with_ct == without
        parsed_rd_units += len(without[0])
    assert parsed_rd_units > 0


def test_the_other_tsos_have_no_ct_ra(tmp_path):
    _, folder = _extract(tmp_path)
    for tso in ("Espheim", "Svedala"):
        assert _parse(folder, tso) == ([], [])


def test_penalty_factors_and_volumes_are_parameters(tmp_path):
    _, folder = _extract(tmp_path, ct_mock.default_ras(volume=100.0, penalties=(0.0, 2.5)))
    belgovia, galia = _parse(folder, "Belgovia")[0][0], _parse(folder, "Galia")[0][0]
    assert (belgovia.penalty_factor, galia.penalty_factor) == (0.0, 2.5)
    assert all(b.available_mw[TS] == 100.0 for b in _parse(folder, "Belgovia")[1])


# ---------------------------------------------------------------------------
# the variants
# ---------------------------------------------------------------------------

def test_the_curative_variant_has_links_reaction_time_and_reserve_price(tmp_path):
    _, folder = _extract(tmp_path, ct_mock.curative_ras())
    for tso in ("Belgovia", "Galia"):
        ras, bids = _parse(folder, tso)
        assert len(ras) == 1 and ras[0].kind == RAKind.CURATIVE
        assert ras[0].reaction_time_minutes == pytest.approx(5.0)
        assert ras[0].linked_contingency_mrids == [ct_mock.CONTINGENCY_GA_BO5]
        assert [b.reserve_price_eur_mw for b in bids] == [4.0, 4.0] and all(b.available_mw[TS] == 120.0 for b in bids)


def test_the_curative_variant_without_a_link_acts_in_every_contingency(tmp_path):
    _, folder = _extract(tmp_path, ct_mock.curative_ras(contingencies=()))
    assert _parse(folder, "Belgovia")[0][0].linked_contingency_mrids == []


@pytest.mark.parametrize("strategy", ["explicitInstruction", "proportionalForGenerator", "generatorPmax"])
def test_the_unknown_strategy_variant_is_ignored_with_one_warning(tmp_path, caplog, strategy):
    _, folder = _extract(tmp_path, ct_mock.unknown_strategy_ras(strategy))
    ras, bids = _parse(folder, "Belgovia", caplog)
    assert ras == [] and bids == []
    warnings = _warnings(caplog)
    assert len(warnings) == 1 and "IGNORED" in warnings[0] and strategy in warnings[0]


def test_the_mixed_strategy_variant_ignores_both_ras(tmp_path, caplog):
    _, folder = _extract(tmp_path, ct_mock.mixed_strategy_ras())
    ras, bids = _parse(folder, "Belgovia", caplog)
    assert ras == [] and bids == []
    warnings = _warnings(caplog)
    assert len(warnings) == 2 and all("different gLSKStrategy" in w for w in warnings)


def test_a_zone_not_in_the_organisation_profile_drops_the_ra(tmp_path, caplog, real_network):
    _, folder = _extract(tmp_path, ct_mock.bad_zone_ras())
    ras, _ = _parse(folder, "Belgovia")
    assert len(ras) == 1
    with caplog.at_level(logging.WARNING, logger=LOG):
        kept, _ = ct_units.resolve_zone_units(ras, real_network.zones(folder), real_network.area_units, real_network.generators)
    assert kept == [] and "not in the Organisation profile" in _warnings(caplog)[0]


@pytest.mark.parametrize("zone", [ct_mock.ZONE_NORDHEIM, ct_mock.ZONE_BRITHEIM])
def test_a_zone_without_a_usable_unit_drops_the_ra(tmp_path, caplog, real_network, zone):
    _, folder = _extract(tmp_path, ct_mock.bad_zone_ras(zone))
    ras, _ = _parse(folder, "Belgovia")
    with caplog.at_level(logging.WARNING, logger=LOG):
        kept, units_by_zone = ct_units.resolve_zone_units(ras, real_network.zones(folder), real_network.area_units, real_network.generators)
    assert kept == [] and units_by_zone[zone] == []
    assert "no generating unit" in _warnings(caplog)[0]


def test_the_no_volume_variant_keeps_volume_zero_with_a_warning(tmp_path, caplog):
    _, folder = _extract(tmp_path, ct_mock.no_volume_ras())
    ras, bids = _parse(folder, "Belgovia", caplog)
    assert len(ras) == 1
    by_direction = {b.direction: b for b in bids}
    assert by_direction[UP].available_mw[TS] == 0.0 and by_direction[DOWN].available_mw[TS] == 100.0
    assert len([w for w in _warnings(caplog) if "no volume" in w]) == 1


def test_the_missing_penalty_variant_defaults_to_one_with_a_log_line(tmp_path, caplog):
    _, folder = _extract(tmp_path, ct_mock.missing_penalty_ras())
    ras, _ = _parse(folder, "Belgovia", caplog)
    assert ras[0].penalty_factor == 1.0 and any("penaltyFactor" in w for w in _warnings(caplog))


def test_an_unavailable_ra_is_written_unavailable(tmp_path):
    _, folder = _extract(tmp_path, [ct_mock.ra("off", ct_mock.ZONE_BELGOVIA, [ct_mock.bid("off-up", "up")], available=False)])
    assert _parse(folder, "Belgovia")[0][0].available is False


# ---------------------------------------------------------------------------
# the real CGM behind the mock
# ---------------------------------------------------------------------------

class _RealNetwork:
    """The CGM fixture with the pipeline's initial load flow, the control-area units and the generator table."""

    def __init__(self, work):
        with zipfile.ZipFile(FIXTURE_CGM_ZIP) as archive:
            archive.extractall(work / "cgm")
        self.cgm_dir = work / "cgm"
        self.network = cgmes_loader.load_cgm(FIXTURE_CGM_ZIP)
        cgmes_loader.run_initial_loadflow(
            self.network, use_reactive_limits=run_pipeline.USE_REACTIVE_LIMITS, extra_lf_params=run_pipeline.EXTRA_LF_PARAMS,
        )
        self.lf_initial = cgmes_loader.build_lf_initial(self.network)
        self.generators = ct_units.read_generator_table(self.network)
        self.area_units = ct_units.read_control_area_units(self.cgm_dir)

    def zones(self, ncp_folder):
        return ct_units.parse_bidding_zones(ncp_folder / "Org-NineRealms_CD.xml")


@pytest.fixture(scope="module")
def real_network(tmp_path_factory):
    return _RealNetwork(tmp_path_factory.mktemp("ct_mock_cgm"))


@pytest.fixture(scope="module")
def default_mock(tmp_path_factory, real_network):
    work = tmp_path_factory.mktemp("ct_mock_default")
    _, folder = _extract(work)
    ras = _parse(folder, "Belgovia")[0] + _parse(folder, "Galia")[0]
    bids = _parse(folder, "Belgovia")[1] + _parse(folder, "Galia")[1]
    kept, units_by_zone = ct_units.resolve_zone_units(ras, real_network.zones(folder), real_network.area_units, real_network.generators)
    return folder, kept, bids, units_by_zone, ct_units.resolve_ct_weights(kept, units_by_zone, bids)


def test_the_zones_resolve_to_the_units_of_the_cgm(default_mock):
    _, kept, _, units_by_zone, _ = default_mock
    assert [ra.zone_name for ra in kept] == ["BZ-Belgovia", "BZ-Galia"]
    assert {u.gu_mrid for u in units_by_zone[ct_mock.ZONE_BELGOVIA]} == {ct_mock.BO_G1, ct_mock.BO_G2}
    assert {u.gu_mrid for u in units_by_zone[ct_mock.ZONE_GALIA]} == {ct_mock.GA_G1, ct_mock.GA_G2, ct_mock.GA_G3}


def test_the_belgovia_units_are_the_rd_units_of_the_mock(default_mock):
    folder, _, _, units_by_zone, _ = default_mock
    rd_units, _ = ncp_parser.parse_rd_units(folder / "Belgovia_RA.xml", folder / "Belgovia_SIS.xml", "Belgovia", [TS], {
        u.gu_mrid: {"target_p": u.prod, "max_p": u.pmax, "min_p": u.pmin} for u in units_by_zone[ct_mock.ZONE_BELGOVIA]
    }, price_timestamp=TS, warn_countertrade=False)
    assert {rd.gu_mrid for rd in rd_units} & {ct_mock.BO_G1, ct_mock.BO_G2}


def test_the_weights_of_the_mock_zones_match_the_hand_computed_values(default_mock):
    _, kept, _, _, weights = default_mock
    for ra in kept:
        zone = "Belgovia" if ra.zone_mrid == ct_mock.ZONE_BELGOVIA else "Galia"
        for direction in (UP, DOWN):
            assert weights[(ra.mrid, direction)].pf == pytest.approx(ct_mock.EXPECTED_WEIGHTS[(zone, direction.value)], abs=1e-6)


def test_the_patl_of_the_mock_is_read_for_the_belgovia_half_of_ga_bo4(default_mock, real_network):
    folder = default_mock[0]
    side_map = {}
    for tso in ("Belgovia", "Galia"):
        side_map.update(ncp_parser.build_current_limit_side_map(cgmes_loader.find_eq_file_for_tso(real_network.cgm_dir, tso)))
    assert side_map[ct_mock.XNE_OPERATIONAL_LIMIT] == 1
    elements = ncp_parser.parse_assessed_elements(
        folder / "Belgovia_AE.xml", folder / "Belgovia_SHS.xml", "Belgovia", [TS],
        cgmes_loader.build_cgm_static_patl(real_network.network),
        cgm_branch_mrids=set(real_network.lf_initial), current_limit_side=side_map,
    )
    element = next(e for e in elements if e.branch_mrid == ct_mock.BRANCH_GA_BO4_BELGOVIA)
    assert element.branch_side == 1 and element.patl_ka[TS] == pytest.approx(0.110)
    current = real_network.lf_initial[ct_mock.BRANCH_GA_BO4_BELGOVIA][1]
    assert current == pytest.approx(ct_mock.INITIAL_CURRENT_A, abs=1e-3) and current > 1000 * element.patl_ka[TS]


def _unit_sensitivities(real_network, units, side=1, branch=ct_mock.BRANCH_GA_BO4_BELGOVIA):
    return n0_sensitivity._injection_sensitivity_n0(
        real_network.network, sorted(units), {branch: side}, real_network.lf_initial,
        run_pipeline.USE_REACTIVE_LIMITS, run_pipeline.EXTRA_LF_PARAMS, None, None, None, "ptdf_ct_n0", "CT",
    )


def _pair_effect(weights, kept, sensitivity, branch, belgovia_direction, galia_direction):
    """A per MW of the pair: Belgovia bid in belgovia_direction and Galia bid in galia_direction, each
    injecting its weights times the volume with the sign of its direction."""
    effect = 0.0
    for ra, direction in ((kept[0], belgovia_direction), (kept[1], galia_direction)):
        sign = 1.0 if direction == UP else -1.0
        effect += sign * sum(f * sensitivity[(branch, gu)] for gu, f in weights[(ra.mrid, direction)].pf.items())
    return effect


def test_the_sensitivities_of_the_ct_pair_on_ga_bo4_match_the_cgm(default_mock, real_network):
    import pypowsybl as pp
    from pre_milp.lf_parameters import build_loadflow_parameters

    _, kept, _, _, weights = default_mock
    units = {gu for w in weights.values() for gu in w.pf}
    sensitivity = _unit_sensitivities(real_network, units)
    branch = ct_mock.BRANCH_GA_BO4_BELGOVIA
    relief = _pair_effect(weights, kept, sensitivity, branch, DOWN, UP)      # Belgovia down, Galia up
    worsen = _pair_effect(weights, kept, sensitivity, branch, UP, DOWN)      # Belgovia up, Galia down
    # the pair moves power across the GA_BO border: one direction relieves the Belgovia half, the other loads it; the
    # two differ only through the weights of the direction (both well away from zero: about 0.2 A per MW)
    assert relief < -0.1 and worsen > 0.1
    assert relief == pytest.approx(-worsen, rel=0.05)

    # finite difference: 20 MW of the Belgovia-up / Galia-down pair on the AC load flow of the pipeline
    volume = 20.0
    generators = real_network.network.get_generators()
    original = generators["target_p"].copy()
    try:
        for ra, direction in ((kept[0], UP), (kept[1], DOWN)):
            sign = 1.0 if direction == UP else -1.0
            for gu, factor in weights[(ra.mrid, direction)].pf.items():
                real_network.network.update_generators(id=gu, target_p=float(original[gu] + sign * volume * factor))
        result = pp.loadflow.run_ac(
            real_network.network,
            parameters=build_loadflow_parameters(run_pipeline.USE_REACTIVE_LIMITS, run_pipeline.EXTRA_LF_PARAMS),
        )
        assert result[0].status.name == "CONVERGED"
        after = cgmes_loader.build_lf_initial(real_network.network)[branch][1]
    finally:
        for gu in units:
            real_network.network.update_generators(id=gu, target_p=float(original[gu]))
    finite_difference = (after - real_network.lf_initial[branch][1]) / volume
    # the AC load flow is not linear: 20 MW of the pair stay within 6 % of the linear sensitivity
    assert finite_difference == pytest.approx(worsen, rel=0.06)


def test_the_lowered_patl_needs_relief_and_the_bids_can_give_it(default_mock, real_network):
    _, kept, bids, units_by_zone, weights = default_mock
    units = {gu for w in weights.values() for gu in w.pf}
    sensitivity = _unit_sensitivities(real_network, units)
    relief_per_mw = -_pair_effect(weights, kept, sensitivity, ct_mock.BRANCH_GA_BO4_BELGOVIA, DOWN, UP)
    overload = real_network.lf_initial[ct_mock.BRANCH_GA_BO4_BELGOVIA][1] - ct_mock.DEFAULT_PATL_A
    needed_mw = overload / relief_per_mw
    belgovia_down = next(b for b in bids if b.ra_mrid == kept[0].mrid and b.direction == DOWN)
    galia_up = next(b for b in bids if b.ra_mrid == kept[1].mrid and b.direction == UP)
    assert overload == pytest.approx(ct_mock.INITIAL_CURRENT_A - ct_mock.DEFAULT_PATL_A, abs=1e-3) and overload > 0.0
    assert 0.0 < needed_mw < min(belgovia_down.available_mw[TS], galia_up.available_mw[TS])
    # the room of the units does not limit the pair either (the sums of the remaining-capacity weights)
    room_down = sum(u.prod - u.pmin for u in units_by_zone[ct_mock.ZONE_BELGOVIA])
    room_up = sum(u.pmax - u.prod for u in units_by_zone[ct_mock.ZONE_GALIA])
    assert needed_mw < room_down and needed_mw < room_up


def test_the_galia_half_of_ga_bo4_also_gets_relief_from_the_same_pair(default_mock, real_network):
    _, kept, _, _, weights = default_mock
    units = {gu for w in weights.values() for gu in w.pf}
    sensitivity = _unit_sensitivities(real_network, units, side=1, branch=ct_mock.BRANCH_GA_BO4_GALIA)
    assert _pair_effect(weights, kept, sensitivity, ct_mock.BRANCH_GA_BO4_GALIA, DOWN, UP) < -0.1
