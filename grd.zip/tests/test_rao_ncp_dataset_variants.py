"""
test_rao_ncp_dataset_variants.py — the invalid and warning variants of the NCP test dataset (tests/ncp_dataset.py,
docs/ncp_dataset_coverage.md part C): each variant is the valid package with one change, read by the parser the
pipeline uses, with the outcome docs/ncp_data_requirements.md gives (error, warning and drop, default). Also the two
input fixes of DECISIONS 81 and 82 (a zero or unreadable timePerStage; references to an unknown RA mRID).
"""
import logging
import zipfile
from types import SimpleNamespace

import pytest

import ct_mock
import hvdc_mock
import ncp_dataset as ds
from data_model import BidDirection, PST, RAKind
from helpers import FIXTURE_CGM_ZIP
from milp import milp_builder
from pre_milp import cgmes_loader, cra_preprocessing, ct_units, glsk_resolver, hvdc_units, ncp_loader, ncp_parser
from pre_milp import tso_name_resolver

TIMESTAMPS = ["1030Z"]
TSOS = ("Belgovia", "Espheim", "Galia", "Svedala")


@pytest.fixture(scope="module")
def cgm(tmp_path_factory):
    """The CGM inputs of the parsers, as run_pipeline.main() builds them."""
    work = tmp_path_factory.mktemp("cgm")
    network = cgmes_loader.load_cgm(FIXTURE_CGM_ZIP)
    cgmes_loader.extract_cgm_zip(FIXTURE_CGM_ZIP, work)
    _branches, tap_changer_dict, generating_unit_dict = cgmes_loader.extract_equipment_dicts(network)
    tap_changer_to_transformer, current_limit_side = {}, {}
    for country in TSOS:
        eq = cgmes_loader.find_eq_file_for_tso(work, country)
        graph = ncp_parser.load_eq_graph(eq)
        tap_changer_to_transformer.update(ncp_parser.build_tap_changer_to_transformer_map(eq, graph=graph))
        current_limit_side.update(ncp_parser.build_current_limit_side_map(eq, graph=graph))
    return SimpleNamespace(
        network=network, extract_dir=work, tap_changer_dict=tap_changer_dict, generating_unit_dict=generating_unit_dict,
        tap_changer_to_transformer=tap_changer_to_transformer, current_limit_side=current_limit_side,
        static_patl=cgmes_loader.build_cgm_static_patl(network),
        branch_mrids=set(cgmes_loader.build_branch_mrid_to_name(network)),
        equipment_types=cgmes_loader.build_equipment_mrid_to_type(network),
    )


def _variant(tmp_path, case):
    """{file name: path} of the extracted variant package."""
    package = ds.build_variant_ncp(tmp_path / f"{case}.zip", case)
    folder = tmp_path / case
    with zipfile.ZipFile(package) as zf:
        zf.extractall(folder)
    return {path.name: path for path in folder.iterdir()}


def _aes(cgm, files, tso):
    return ncp_parser.parse_assessed_elements(
        files[f"{tso}_AE.xml"], files.get(f"{tso}_SHS.xml"), f"TSO-{tso}", TIMESTAMPS, cgm.static_patl,
        cgm_branch_mrids=cgm.branch_mrids, current_limit_side=cgm.current_limit_side,
    )


def _psts(cgm, files, tso):
    return ncp_parser.parse_psts(files[f"{tso}_RA.xml"], f"TSO-{tso}", cgm.tap_changer_dict, cgm.tap_changer_to_transformer)


def _rd(cgm, files, tso):
    return ncp_parser.parse_rd_units(
        files[f"{tso}_RA.xml"], files.get(f"{tso}_SIS.xml"), f"TSO-{tso}", TIMESTAMPS, cgm.generating_unit_dict,
        price_timestamp=TIMESTAMPS[0], warn_countertrade=False,
    )


def _hvdc(files):
    units, groups = [], []
    for tso in TSOS:
        units += ncp_parser.parse_hvdc_units(files[f"{tso}_RA.xml"], f"TSO-{tso}")
        groups += ncp_parser.parse_balanced_ra_groups(files[f"{tso}_RA.xml"], f"TSO-{tso}")
    return units, groups


def _ct(files, tso):
    return ct_units.parse_ct_remedial_actions(files[f"{tso}_RA.xml"], files.get(f"{tso}_SIS.xml"), f"TSO-{tso}", TIMESTAMPS)


def _messages(caplog, *parts):
    return [r.getMessage() for r in caplog.records if all(p in r.getMessage() for p in parts)]


# ---------------------------------------------------------------------------
# assessed elements and limits
# ---------------------------------------------------------------------------

def test_an_invalid_exclusion_reason_stops_the_run(cgm, tmp_path):
    files = _variant(tmp_path, "invalid_exclusion_reason")
    with pytest.raises(ValueError, match=f"AE {ds.VARIANT_AE} has invalid exclusionReason 'SecuredExclusionReasonKind.noSuchReason'"):
        _aes(cgm, files, "Belgovia")


def test_an_ae_without_any_equipment_reference_is_skipped_with_a_warning(cgm, tmp_path, caplog):
    files = _variant(tmp_path, "ae_without_equipment")
    with caplog.at_level(logging.INFO):
        aes = _aes(cgm, files, "Belgovia")
    assert ds.VARIANT_AE not in {ae.mrid for ae in aes}
    assert _messages(caplog, ds.VARIANT_AE, "spec violation", "skipped")


def test_an_ae_with_only_a_corridor_is_skipped_as_out_of_scope(cgm, tmp_path, caplog):
    files = _variant(tmp_path, "ae_corridor_only")
    with caplog.at_level(logging.INFO):
        aes = _aes(cgm, files, "Belgovia")
    assert ds.VARIANT_AE not in {ae.mrid for ae in aes}
    assert _messages(caplog, ds.VARIANT_AE, "valid via DCTieCorridor/PowerTransferCorridor/OperationalLimit")


def test_an_ae_on_a_busbar_is_skipped(cgm, tmp_path, caplog):
    files = _variant(tmp_path, "ae_on_busbar")
    with caplog.at_level(logging.INFO):
        aes = _aes(cgm, files, "Belgovia")
    assert ds.VARIANT_AE not in {ae.mrid for ae in aes}
    assert _messages(caplog, ds.VARIANT_AE, ds.BUSBAR_BO, "not a Line or 2W-Transformer")


def test_a_non_numeric_base_case_limit_falls_back_to_the_cgm_patl(cgm, tmp_path, caplog):
    files = _variant(tmp_path, "bccl_non_numeric")
    with caplog.at_level(logging.INFO):
        aes = {ae.mrid: ae for ae in _aes(cgm, files, "Belgovia")}
    assert _messages(caplog, ds.VARIANT_AE, "BaseCaseCurrentLimit.normalValue 'high' is not a valid float")
    assert aes[ds.VARIANT_AE].patl_ka["1030Z"] == pytest.approx(ds.SER_RLC_CGM_PATL_A / 1000.0)


def test_a_patl_of_zero_excludes_the_branch_from_the_milp(cgm, tmp_path, caplog):
    files = _variant(tmp_path, "patl_zero")
    aes = {ae.mrid: ae for ae in _aes(cgm, files, "Belgovia")}
    assert aes[ds.VARIANT_AE].patl_ka["1030Z"] == 0.0
    with caplog.at_level(logging.WARNING):
        kept = milp_builder._branch_is_above_threshold(ds.SER_RLC, {ds.SER_RLC: {1: 56.8}}, {ds.SER_RLC: 0.0}, {ds.SER_RLC: 1}, 0.0)
    assert kept is False and _messages(caplog, ds.SER_RLC, "missing or invalid PATL; excluding from MILP")


def test_a_non_numeric_shs_value_stops_the_run(cgm, tmp_path):
    files = _variant(tmp_path, "shs_non_numeric")
    with pytest.raises(ValueError):
        _aes(cgm, files, "Belgovia")


# ---------------------------------------------------------------------------
# contingencies
# ---------------------------------------------------------------------------

def _contingencies(cgm, files, tso):
    return {c.mrid: c for c in ncp_parser.parse_contingencies(files[f"{tso}_CO.xml"], f"TSO-{tso}", TIMESTAMPS, cgm.equipment_types)}


def test_a_contingency_without_equipment_is_kept_with_an_empty_list(cgm, tmp_path):
    contingencies = _contingencies(cgm, _variant(tmp_path, "contingency_without_equipment"), "Espheim")
    assert contingencies[ds.VARIANT_CONTINGENCY].equipment_mrids == []


def test_a_contingency_without_normal_must_study_is_not_studied(cgm, tmp_path):
    contingencies = _contingencies(cgm, _variant(tmp_path, "contingency_must_study_missing"), "Espheim")
    assert contingencies[ds.VARIANT_CONTINGENCY].must_study == {"1030Z": False}


def test_the_same_contingency_in_two_files_is_parsed_twice(cgm, tmp_path):
    files = _variant(tmp_path, "contingency_in_two_files")
    assert ds.VARIANT_CONTINGENCY in _contingencies(cgm, files, "Espheim")
    assert ds.VARIANT_CONTINGENCY in _contingencies(cgm, files, "Galia")


# ---------------------------------------------------------------------------
# attributes common to every RA type
# ---------------------------------------------------------------------------

GA_TR2_2 = "2184f365-8cd5-4b5d-8a28-9d68603bb6a4"


@pytest.mark.parametrize("case", ["ra_kind_unknown", "ra_kind_missing"])
def test_an_unknown_or_missing_kind_is_preventive(cgm, tmp_path, case):
    psts = _psts(cgm, _variant(tmp_path, case), "Galia")
    from_curative_ra = [p for p in psts if p.mrid == GA_TR2_2 and p.name == "CRA_PST_GA_TR2_2"]
    assert len(from_curative_ra) == 1 and from_curative_ra[0].kind == RAKind.PREVENTIVE


def test_a_non_numeric_penalty_factor_stops_the_run(cgm, tmp_path):
    with pytest.raises(ValueError):
        _rd(cgm, _variant(tmp_path, "penalty_factor_non_numeric"), "Svedala")


def test_an_unreadable_rd_reaction_time_is_zero_with_a_warning(cgm, tmp_path, caplog):
    with caplog.at_level(logging.WARNING):
        units, _bids = _rd(cgm, _variant(tmp_path, "reaction_time_unreadable_rd"), "Galia")
    unit = next(u for u in units if u.mrid == ds.CRA_RD_GA_G1_UP)
    assert unit.reaction_time_minutes == 0.0
    assert _messages(caplog, ds.CRA_RD_GA_G1_UP, "unreadable RemedialAction.timeToImplement 'P1M'")


def test_an_unreadable_pst_reaction_time_is_zero_without_a_warning(cgm, tmp_path, caplog):
    with caplog.at_level(logging.WARNING):
        psts = _psts(cgm, _variant(tmp_path, "reaction_time_unreadable_pst"), "Espheim")
    pst = next(p for p in psts if p.name == "CRA_PST_Aac")
    assert pst.reaction_time_minutes == 0.0
    assert not _messages(caplog, "timeToImplement", "soon")


def test_an_ra_whose_mrid_differs_from_its_rdf_id_is_warned_about_and_not_matched(cgm, tmp_path, caplog):
    files = _variant(tmp_path, "mrid_differs_from_rdf_id")
    with caplog.at_level(logging.WARNING):
        unmatched = ncp_parser.warn_unmatched_ra_references(files["Svedala_RA.xml"], files["Svedala_SIS.xml"], "TSO-Svedala")
    assert {(u["object_class"], u["ra_mrid"]) for u in unmatched} == {
        ("ContingencyWithRemedialAction", ds.MRID_DIFFERS_RDF_ID), ("PowerBidSchedule", ds.MRID_DIFFERS_RDF_ID)}
    assert len(_messages(caplog, ds.MRID_DIFFERS_RDF_ID, "is the mRID of no remedial action of Svedala_RA.xml")) == 2
    assert _messages(caplog, ds.MRID_DIFFERS_BID, "nc:PowerBidSchedule")
    # what is matched is unchanged: the RA is parsed, its link and its bid are lost
    units, bids = _rd(cgm, files, "Svedala")
    unit = next(u for u in units if u.mrid == ds.MRID_DIFFERS_RA)
    assert unit.linked_contingency_mrids == [] and ds.MRID_DIFFERS_BID not in {b.mrid for b in bids}


def test_the_valid_dataset_has_no_reference_to_an_unknown_ra(tmp_path, caplog):
    package = ds.build_valid_ncp(tmp_path / "valid.zip")
    folder = tmp_path / "valid"
    with zipfile.ZipFile(package) as zf:
        zf.extractall(folder)
    with caplog.at_level(logging.WARNING):
        found = [ncp_parser.warn_unmatched_ra_references(folder / f"{t}_RA.xml", folder / f"{t}_SIS.xml", t) for t in TSOS]
    assert found == [[], [], [], []] and not _messages(caplog, "is the mRID of no remedial action")


# ---------------------------------------------------------------------------
# PST
# ---------------------------------------------------------------------------

def _aac(psts):
    return next(p for p in psts if p.name == "CRA_PST_Aac")


@pytest.mark.parametrize("case, text", [("time_per_stage_zero", "PT0S"), ("time_per_stage_unreadable", "one minute")])
def test_a_zero_or_unreadable_time_per_stage_stays_unset_with_a_warning(cgm, tmp_path, caplog, case, text):
    files = _variant(tmp_path, case)
    with caplog.at_level(logging.WARNING):
        aac = _aac(_psts(cgm, files, "Espheim"))
    assert aac.time_per_stage_minutes is None
    assert _messages(caplog, aac.mrid, ds.CRA_PST_AAC, f"zero or unreadable GridStateAlteration.timePerStage {text!r}")
    # the same handling as a missing timing attribute: no availability, no crash
    tatl = {"B1": {"tatl_duration_seconds": 600, "tatl_limit_ampere": 1000.0, "side": 1}}
    with caplog.at_level(logging.WARNING):
        assert cra_preprocessing.compute_pst_cra_availability([aac], tatl) == {}
    assert _messages(caplog, f"curative PST {aac.mrid} missing", "skipped entirely")


def test_a_curative_pst_with_a_time_per_stage_of_zero_gets_no_availability_instead_of_a_division_by_zero(caplog):
    pst = PST(mrid="P1", name="P1", tso="T", available=True, kind=RAKind.CURATIVE, penalty_factor=1.0, low_step=-5,
              high_step=5, r0=0, operating_tap_min=-5, operating_tap_max=5, group_id=None, reaction_time_minutes=1.0,
              time_per_stage_minutes=0.0, linked_contingency_mrids=["CO1"])
    tatl = {"B1": {"tatl_duration_seconds": 600, "tatl_limit_ampere": 1000.0, "side": 1}}
    with caplog.at_level(logging.WARNING):
        assert cra_preprocessing.compute_pst_cra_availability([pst], tatl) == {}
    assert _messages(caplog, "curative PST P1 missing", "skipped entirely")


def test_a_tap_action_on_a_ratio_tap_changer_is_skipped(cgm, tmp_path, caplog):
    with caplog.at_level(logging.INFO):
        psts = _psts(cgm, _variant(tmp_path, "tap_action_on_ratio_tap_changer"), "Belgovia")
    assert "PRA_RATIO" not in {p.name for p in psts}
    assert _messages(caplog, ds.TC_RATIO_BO_TR2_3, "likely a RatioTapChanger")


def _curative_bounds(cgm, files):
    return ncp_parser.build_pst_tap_bounds_curative(files["Espheim_RA.xml"], cgm.tap_changer_to_transformer)


AAC = "2c9a0753-421a-489b-9761-9452f60b3157"


def test_an_empty_curative_tap_range_is_passed_on_unchecked(cgm, tmp_path, caplog):
    # an open finding (docs/ncp_dataset_coverage.md): lower above upper is not checked
    with caplog.at_level(logging.WARNING):
        bounds = _curative_bounds(cgm, _variant(tmp_path, "empty_curative_tap_range"))
    assert bounds[AAC] == (5, -5) and not _messages(caplog, AAC)


def test_an_up_and_down_range_sets_the_upper_bound_only(cgm, tmp_path, caplog):
    with caplog.at_level(logging.WARNING):
        bounds = _curative_bounds(cgm, _variant(tmp_path, "curative_range_up_and_down"))
    assert AAC not in bounds and _messages(caplog, AAC, "upper=3.0, lower=None")


def test_a_range_with_direction_none_is_skipped_with_a_warning(cgm, tmp_path, caplog):
    with caplog.at_level(logging.WARNING):
        bounds = _curative_bounds(cgm, _variant(tmp_path, "curative_range_none"))
    assert bounds[AAC] == (-5, 5) and _messages(caplog, AAC, "unrecognized/ambiguous direction")


def test_a_one_sided_range_falls_back_to_the_operating_range(cgm, tmp_path, caplog):
    with caplog.at_level(logging.WARNING):
        bounds = _curative_bounds(cgm, _variant(tmp_path, "curative_range_one_sided"))
    assert AAC not in bounds and _messages(caplog, AAC, "could not resolve both an upper AND a lower")


# ---------------------------------------------------------------------------
# RD: restrictive groups, bids, GLSK, units
# ---------------------------------------------------------------------------

def _groups(files):
    return ncp_parser.parse_ra_groups(files["Belgovia_RA.xml"], files["Belgovia_SIS.xml"], "TSO-Belgovia", "1030Z")


def test_a_restrictive_group_without_a_limit_is_kept_with_a_warning(tmp_path, caplog):
    with caplog.at_level(logging.WARNING):
        groups = _groups(_variant(tmp_path, "group_without_limit"))
    assert groups[ds.VARIANT_GROUP]["max_regulating_up"] is None and groups[ds.VARIANT_GROUP]["max_regulating_down"] is None
    assert _messages(caplog, ds.VARIANT_GROUP, "has no resolved maxRegulatingUp/maxRegulatingDown")


def test_a_restrictive_group_with_an_up_limit_only(tmp_path):
    group = _groups(_variant(tmp_path, "group_up_only"))[ds.VARIANT_GROUP]
    assert group["max_regulating_up"] == 40.0 and group["max_regulating_down"] is None


def _variant_bid(cgm, tmp_path, case):
    _units, bids = _rd(cgm, _variant(tmp_path, case), "Svedala")
    return next(b for b in bids if b.mrid == ds.VARIANT_BID)


@pytest.mark.parametrize("case, text", [("bid_price_missing", "has no price at 1030Z"), ("bid_price_negative", "has a negative price (-5.0)")])
def test_a_missing_or_negative_price_is_zero_with_a_warning(cgm, tmp_path, caplog, case, text):
    with caplog.at_level(logging.WARNING):
        bid = _variant_bid(cgm, tmp_path, case)
    assert bid.price_eur_mw == 0.0 and _messages(caplog, ds.VARIANT_BID, text)


def test_a_negative_reserve_price_is_zero_with_a_warning(cgm, tmp_path, caplog):
    with caplog.at_level(logging.WARNING):
        bid = _variant_bid(cgm, tmp_path, "bid_reserve_price_negative")
    assert bid.reserve_price_eur_mw == 0.0 and _messages(caplog, ds.VARIANT_BID, "negative reservePrice (-2.0)")


def test_a_currency_other_than_eur_is_used_as_eur_with_a_warning(cgm, tmp_path, caplog):
    with caplog.at_level(logging.WARNING):
        bid = _variant_bid(cgm, tmp_path, "bid_currency_not_eur")
    assert bid.price_eur_mw == 20.0 and _messages(caplog, ds.VARIANT_BID, "currency USD is not EUR")


def test_a_bid_without_direction_is_an_up_bid(cgm, tmp_path):
    assert _variant_bid(cgm, tmp_path, "bid_direction_missing").direction == BidDirection.UP


def test_a_bid_without_a_time_point_has_volume_zero(cgm, tmp_path):
    assert _variant_bid(cgm, tmp_path, "bid_without_volume").available_mw == {"1030Z": 0.0}


def test_the_energy_fields_of_a_bid_are_read(cgm, tmp_path):
    bid = _variant_bid(cgm, tmp_path, "bid_energy_fields")
    assert (bid.min_energy_mwh, bid.max_energy_mwh, bid.step_size_mw) == (10.0, 90.0, 5.0)


def test_a_time_point_of_another_day_matches_by_clock_time(cgm, tmp_path):
    assert _variant_bid(cgm, tmp_path, "bid_time_point_other_day").available_mw == {"1030Z": 100.0}


def _glsk(cgm, tmp_path, case, files=None):
    files = files or _variant(tmp_path, case)
    units, _bids = _rd(cgm, files, "Svedala")
    return glsk_resolver.resolve_glsk(
        files["Svedala_SIS.xml"], units, "TSO-Svedala", set(cgm.network.get_generators().index), "1030Z",
    )


def test_a_shift_key_schedule_with_two_units_gives_each_the_factor_with_a_warning(cgm, tmp_path, caplog):
    with caplog.at_level(logging.WARNING):
        glsk = _glsk(cgm, tmp_path, "glsk_schedule_with_two_units")
    assert glsk[ds.VARIANT_RA] == {ds.STORFORS_G1: 0.5, ds.STENFORSEN_G1: 0.5}
    assert _messages(caplog, "has 2 GeneratingUnits")


def test_a_non_numeric_participation_factor_is_skipped_with_a_warning(cgm, tmp_path, caplog):
    with caplog.at_level(logging.WARNING):
        glsk = _glsk(cgm, tmp_path, "glsk_factor_non_numeric")
    assert glsk[ds.VARIANT_RA] == {} and _messages(caplog, "non-numeric participationFactor")


def test_participation_factors_summing_to_zero_give_an_empty_glsk(cgm, tmp_path, caplog):
    with caplog.at_level(logging.WARNING):
        glsk = _glsk(cgm, tmp_path, "glsk_factors_zero")
    assert glsk[ds.VARIANT_RA] == {} and _messages(caplog, ds.VARIANT_RA, "zero total participation factor")


def test_a_negative_participation_factor_stops_the_milp_build(cgm, tmp_path):
    glsk = _glsk(cgm, tmp_path, "glsk_factor_negative")
    assert glsk[ds.VARIANT_RA][ds.STENFORSEN_G1] < 0.0
    with pytest.raises(ValueError, match=f"{ds.VARIANT_RA}: generating unit {ds.STENFORSEN_G1} has a negative participation factor"):
        milp_builder.validate_participation_factors(glsk)


def test_an_rd_machine_that_is_not_in_the_cgm_is_skipped_with_a_warning(cgm, tmp_path, caplog):
    with caplog.at_level(logging.WARNING):
        units, _bids = _rd(cgm, _variant(tmp_path, "rd_machine_not_in_cgm"), "Svedala")
    assert ds.VARIANT_RA not in {u.mrid for u in units}
    assert _messages(caplog, ds.VARIANT_RA, ds.UNKNOWN_MACHINE, "not found in CGM")


def test_a_negative_unit_cost_stops_the_run(tmp_path):
    files = _variant(tmp_path, "unit_cost_negative")
    with pytest.raises(ValueError, match=f"generating unit {ds.STENFORSEN_G1_UNIT} has a negative start-up cost"):
        ncp_parser.parse_unit_costs(files["Svedala_SIS.xml"], files["Svedala_ER.xml"], "TSO-Svedala", "1030Z")


# ---------------------------------------------------------------------------
# HVDC
# ---------------------------------------------------------------------------

@pytest.mark.parametrize("case, text", [
    ("hvdc_group_of_three", "has 3 HVDC unit(s)"),
    ("hvdc_unit_without_group", f"HVDC unit {ds.VARIANT_RA} "),
    ("hvdc_mixed_kinds", "mixes preventive and curative units"),
    ("hvdc_same_ei_twice", f"both units use the same EquivalentInjection {ds.EI_SD_EH2}"),
    ("hvdc_defined_twice", f"HVDC remedial action {ds.HVDC_PREVENTIVE[0]} is defined twice"),
    ("hvdc_unit_in_two_groups", f"HVDC unit {ds.HVDC_PREVENTIVE[0]} is in two balanced groups"),
])
def test_an_hvdc_structure_error_stops_the_run(tmp_path, case, text):
    units, groups = _hvdc(_variant(tmp_path, case))
    with pytest.raises(ValueError) as error:
        hvdc_units.validate_hvdc_structure(units, groups)
    assert text in str(error.value)


def test_an_hvdc_ra_with_two_equivalent_injection_actions_stops_the_run(tmp_path):
    with pytest.raises(ValueError, match=f"HVDC remedial action {ds.HVDC_PREVENTIVE[0]} has 2 EquivalentInjectionActions"):
        _hvdc(_variant(tmp_path, "hvdc_two_actions"))


def test_an_unavailable_hvdc_unit_drops_its_group(tmp_path, caplog):
    units, groups = _hvdc(_variant(tmp_path, "hvdc_unit_unavailable"))
    with caplog.at_level(logging.INFO):
        usable, kept = hvdc_units.validate_hvdc_structure(units, groups)
    assert not set(ds.HVDC_PREVENTIVE) & {u.mrid for u in usable} and ds.HVDC_PREVENTIVE_GROUP not in {g.mrid for g in kept}
    assert _messages(caplog, ds.HVDC_PREVENTIVE_GROUP, "the group is atomic, both units are dropped")


def test_an_hvdc_unit_without_penalty_factor_is_non_costly_with_a_warning(tmp_path, caplog):
    with caplog.at_level(logging.WARNING):
        units, _groups = _hvdc(_variant(tmp_path, "hvdc_penalty_missing"))
    assert next(u for u in units if u.mrid == ds.HVDC_PREVENTIVE[0]).penalty_factor == 0.0
    assert _messages(caplog, ds.HVDC_PREVENTIVE[0], "has no RemedialAction.penaltyFactor - 0.0 used")


@pytest.mark.parametrize("case, text", [
    ("hvdc_range_none", "has direction none (a fixed set point, not a range) - ignored"),
    ("hvdc_range_unknown_value_kind", "valueKind 'relative'"),
    ("hvdc_range_non_numeric", "has a non-numeric normalValue 'wide' - ignored"),
], ids=["none", "unknown_value_kind", "non_numeric"])
def test_an_unusable_hvdc_range_is_ignored_with_a_warning(tmp_path, caplog, case, text):
    with caplog.at_level(logging.WARNING):
        units, _groups = _hvdc(_variant(tmp_path, case))
    unit = next(u for u in units if u.mrid == ds.HVDC_PREVENTIVE[0])
    assert [(r.direction, r.value_kind, r.value) for r in unit.ranges] == [("upAndDown", "absolute", 450.0)]
    assert _messages(caplog, text)


def test_an_hvdc_range_of_another_property_is_ignored_silently(tmp_path, caplog):
    with caplog.at_level(logging.WARNING):
        units, _groups = _hvdc(_variant(tmp_path, "hvdc_range_other_property"))
    unit = next(u for u in units if u.mrid == ds.HVDC_PREVENTIVE[0])
    assert [(r.direction, r.value) for r in unit.ranges] == [("upAndDown", 450.0)]
    assert not _messages(caplog, "StaticPropertyRange")


def test_a_negative_incremental_hvdc_value_stops_the_run(tmp_path):
    units, _groups = _hvdc(_variant(tmp_path, "hvdc_negative_incremental"))
    unit = next(u for u in units if u.mrid == ds.HVDC_PREVENTIVE[1])
    with pytest.raises(ValueError, match="has a negative value -10.0"):
        hvdc_units.resolve_operating_limits(unit, hvdc_mock.P0_SD_BO3, None, None)


def test_a_balanced_dependency_with_the_remedial_action_group_predicate_is_accepted(tmp_path):
    _units, groups = _hvdc(_variant(tmp_path, "hvdc_group_predicate_remedial_action_group"))
    by_group = {g.mrid: g.ra_mrids for g in groups}
    assert by_group[ds.HVDC_PREVENTIVE_GROUP] == sorted(ds.HVDC_PREVENTIVE)
    assert by_group[hvdc_mock.CURATIVE_GROUP] == sorted(ds.HVDC_CURATIVE)


def test_an_equivalent_injection_in_an_rd_glsk_stops_the_run(cgm, tmp_path):
    files = _variant(tmp_path, "hvdc_ei_in_rd_glsk")
    glsk = _glsk(cgm, tmp_path, "hvdc_ei_in_rd_glsk", files=files)
    units, groups = _hvdc(files)
    usable, _kept = hvdc_units.validate_hvdc_structure(units, groups)
    with pytest.raises(ValueError, match=f"EquivalentInjection {hvdc_mock.EI_SD_EH1} of HVDC unit"):
        hvdc_units.validate_units_not_in_rd_glsk(usable, glsk)


# ---------------------------------------------------------------------------
# countertrade
# ---------------------------------------------------------------------------

def test_an_unknown_countertrade_strategy_ignores_the_ra(tmp_path, caplog):
    with caplog.at_level(logging.WARNING):
        ras, _bids = _ct(_variant(tmp_path, "ct_unknown_strategy"), "Belgovia")
    assert ds.CT_BO not in {r.mrid for r in ras}
    assert _messages(caplog, ds.CT_BO, "gLSKStrategy explicitInstruction is not implemented")


def test_mixed_countertrade_strategies_ignore_the_ra(tmp_path, caplog):
    with caplog.at_level(logging.WARNING):
        ras, _bids = _ct(_variant(tmp_path, "ct_mixed_strategy"), "Galia")
    assert ds.CT_GA not in {r.mrid for r in ras}
    assert _messages(caplog, ds.CT_GA, "declare different gLSKStrategy values")


def test_a_countertrade_strategy_on_the_bids_only_is_usable(tmp_path):
    ras, _bids = _ct(_variant(tmp_path, "ct_strategy_on_bids_only"), "Galia")
    assert next(r for r in ras if r.mrid == ds.CT_GA).strategy == ct_mock.STRATEGY


def test_a_countertrade_ra_without_bidding_zone_is_ignored(tmp_path, caplog):
    with caplog.at_level(logging.WARNING):
        ras, _bids = _ct(_variant(tmp_path, "ct_without_zone"), "Belgovia")
    assert ds.CT_BO not in {r.mrid for r in ras} and _messages(caplog, ds.CT_BO, "has no bidding zone")


@pytest.mark.parametrize("case, text", [
    ("ct_zone_without_units", "has no generating unit that can take part"),
    ("ct_zone_unknown", "is not in the Organisation profile"),
])
def test_a_countertrade_ra_whose_zone_cannot_act_is_dropped(cgm, tmp_path, caplog, case, text):
    files = _variant(tmp_path, case)
    ras, _bids = _ct(files, "Belgovia")
    zones = ct_units.parse_bidding_zones(files["Org-NineRealms_CD.xml"])
    with caplog.at_level(logging.WARNING):
        kept, _units = ct_units.resolve_zone_units(
            ras, zones, ct_units.read_control_area_units(cgm.extract_dir), ct_units.read_generator_table(cgm.network))
    assert ds.CT_BO not in {r.mrid for r in kept} and _messages(caplog, ds.CT_BO, "is DROPPED", text)


def test_a_countertrade_bid_without_volume_is_zero_with_a_warning(tmp_path, caplog):
    with caplog.at_level(logging.WARNING):
        _ras, bids = _ct(_variant(tmp_path, "ct_bid_without_volume"), "Belgovia")
    assert next(b for b in bids if b.mrid == ds.CT_BID["BO-up"]).available_mw == {"1030Z": 0.0}
    assert _messages(caplog, ds.CT_BID["BO-up"], "has no volume at 1030Z - volume 0")


def test_a_countertrade_ra_without_bids_is_kept_with_a_warning(tmp_path, caplog):
    with caplog.at_level(logging.WARNING):
        ras, _bids = _ct(_variant(tmp_path, "ct_ra_without_bids"), "Galia")
    assert ds.CT_GA in {r.mrid for r in ras} and _messages(caplog, ds.CT_GA, "has no power bid - it can do nothing")


# ---------------------------------------------------------------------------
# file discovery
# ---------------------------------------------------------------------------

def _classify(tmp_path, case):
    files = _variant(tmp_path, case)
    folder = files["Org-NineRealms_CD.xml"].parent
    return ncp_loader.classify_extracted_ncp_files(folder, tso_name_resolver.build_tso_name_map(files["Org-NineRealms_CD.xml"]))


def test_an_unrecognized_file_is_skipped_with_a_warning(tmp_path, caplog):
    with caplog.at_level(logging.WARNING):
        ncp_files = _classify(tmp_path, "loader_unrecognized_file")
    assert "Atlantis_AE.xml" not in {p.name for profiles in ncp_files.values() for p in profiles.values()}
    assert _messages(caplog, "did not match the expected", "Atlantis_AE.xml")


def test_a_cross_tso_export_is_skipped_without_a_warning(tmp_path, caplog):
    with caplog.at_level(logging.WARNING):
        ncp_files = _classify(tmp_path, "loader_cross_tso_export")
    assert "Galia-Belgovia_CO.xml" not in {p.name for profiles in ncp_files.values() for p in profiles.values()}
    assert not _messages(caplog, "Galia-Belgovia_CO.xml")


def test_a_tso_without_its_ra_file_stops_the_run(tmp_path):
    with pytest.raises(ValueError, match="TSO-Svedala: missing required profile"):
        _classify(tmp_path, "loader_missing_ra")
