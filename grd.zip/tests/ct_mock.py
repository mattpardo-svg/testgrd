"""
ct_mock.py — the mock NCP of the countertrade RA tests (docs/countertrade_ra_specs.md C12.0-C12.2).

The ReliCapGrid data has no countertrade bids, so build_ct_mock_ncp(dest) copies
NCP_pst_fallback_scenario.zip and adds
  - to Belgovia_RA.xml / Galia_RA.xml one nc:CountertradeRemedialAction per bidding zone
    (BZ-Belgovia, BZ-Galia), and to Belgovia_SIS.xml / Galia_SIS.xml its up and down power bids with a
    time point at the run timestamp 1030Z (volume, price, activation cost, reserve price);
  - to Belgovia_SHS.xml (patched, no new file) a PATL for the Belgovia half of TieLine_GA_BO4, which
    the CGM loads with 124.1 A, so that the monitored branch is overloaded and a Belgovia-down /
    Galia-up pair relieves it (about 0.2 A per MW of the pair).
The CGM stays tests/fixtures/CGM_package.zip. Everything is parameterised so the tests build their
variants (curative, penalty factors, strategies, bad zones, bids without volume) from the same code.

Facts of the CGM used by the tests (pypowsybl, original set points, MW; generation sign):
  Belgovia  BO-G1 52.8181 [-100, 200]   BO-G2 78.9071 [50, 200]     (both are RD units of the mock RA file)
  Galia     GA-G1 705.637 [300, 1000]   GA-G2 and GA-G3 180 [130, 225]
"""
import uuid
import zipfile
from pathlib import Path

from helpers import _MOCK_NX_NCP_ZIP
from hvdc_mock import contingency_xml

ENUM = "https://cim4.eu/ns/nc#"
RUN_TIME = "2022-06-15T10:30:00Z"        # the run timestamp 1030Z of the mock case
STRATEGY = "proportionalForRemainingCapacity"

# bidding zones of Org-NineRealms_CD.xml
ZONE_BELGOVIA = "87fb9f56-fd86-446f-b35d-c0abba19925f"
ZONE_GALIA = "4d4166a4-c0dc-4c77-9b67-a04a7e68ddf2"
ZONE_NORDHEIM = "28c20a8b-917f-41e0-8562-54b6b1044d48"     # its only unit is in another synchronous component
ZONE_BRITHEIM = "d220bcdc-0ab8-44ce-bb17-1c154f02adcd"      # likewise
ZONE_UNKNOWN = "00000000-0000-4000-8000-0000000000ff"       # in no Organisation profile

# generators (SynchronousMachines) of the zones
BO_G1, BO_G2 = "3a3b27be-b18b-4385-b557-6735d733baf0", "550ebe0d-f2b2-48c1-991f-cebea43a21aa"
GA_G1, GA_G2, GA_G3 = (
    "9c3b8f97-7972-477d-9dc8-87365cc0ad0e", "2844585c-0d35-488d-a449-685bcd57afbf", "1dc9afba-23b5-41a0-8540-b479ed8baf4b",
)

# the monitored branch: the Belgovia half of TieLine_GA_BO4, its OperationalLimit (side 1) in Belgovia_AE.xml,
# and the Galia half (monitored in Galia_AE.xml with its own limit)
BRANCH_GA_BO4_BELGOVIA = "78736387-5f60-4832-b3fe-d50daf81b0a6"
BRANCH_GA_BO4_GALIA = "7f43f508-2496-4b64-9146-0a40406cbe49"
XNE_OPERATIONAL_LIMIT = "2ffd9f5b-a4dd-605d-6944-0df84af28173"
INITIAL_CURRENT_A = 124.1148    # CGM current of the Belgovia half on the limit side
DEFAULT_PATL_A = 110.0          # needs about 71 MW of the pair; the default bids allow about 150 MW

# CO3 of Belgovia_CO.xml (outage of BO-G2), a real contingency of the mock case
CONTINGENCY_BELGOVIA_CO3 = "37997e71-cb7d-4a8c-baa6-2a1594956da9"

# the curative scenario: the outage of the tie TieLine_GA_BO5 (its two halves) raises the Belgovia half of
# TieLine_GA_BO4 from 124.1 A to 225.4 A (N-1 of the CGM); with a PATL of 200 A (CURATIVE_PATL_A) the branch is
# fine in N-0 and overloaded by 25.4 A after the outage, which a curative Belgovia-down / Galia-up pair relieves
GA_BO5_HALVES = ("b18cd1aa-7808-49b9-a7cf-605eaf07b006", "e8acf6b6-99cb-45ad-b8dc-16c7866a4ddc")
CURATIVE_PATL_A = 200.0
N1_CURRENT_A = 225.4

# hand-computed weights (C3.3) from the set points above, see test_rao_ct_weights.py
EXPECTED_WEIGHTS = {
    ("Belgovia", "up"): {BO_G1: 147.1819 / 268.2748, BO_G2: 121.0929 / 268.2748},
    ("Belgovia", "down"): {BO_G1: 152.8181 / 181.7252, BO_G2: 28.9071 / 181.7252},
    ("Galia", "up"): {GA_G1: 294.363 / 384.363, GA_G2: 45 / 384.363, GA_G3: 45 / 384.363},
    ("Galia", "down"): {GA_G1: 405.637 / 505.637, GA_G2: 50 / 505.637, GA_G3: 50 / 505.637},
}


def _uid(*parts):
    """A deterministic id for a generated element."""
    return str(uuid.uuid5(uuid.NAMESPACE_URL, "countertrade-mock/" + "/".join(str(p) for p in parts)))


CONTINGENCY_GA_BO5 = _uid("contingency", "GA_BO5 outage")


def outage(key, lines, name=None):
    """An ordinary must-study contingency spec (written into Belgovia_CO.xml): the outage of the lines `lines`."""
    return dict(key=key, mrid=_uid("contingency", key), lines=list(lines), name=name or f"CT mock outage {key}")


def ga_bo5_outage():
    """The outage of TieLine_GA_BO5 (mRID CONTINGENCY_GA_BO5)."""
    return outage("GA_BO5 outage", GA_BO5_HALVES, "CT mock outage GA_BO5")


def bid(key, direction, volume=150.0, price=10.0, activation_cost=None, reserve_price=None, strategy=None,
        lead_time="P0Y0M0DT0H0M0S"):
    """One power bid spec. volume None: no time point (a bid without volume). activation_cost and
    strategy are written on the PowerBidSchedule, price and reserve_price on the time point."""
    return dict(key=key, direction=direction, volume=volume, price=price, activation_cost=activation_cost,
                reserve_price=reserve_price, strategy=strategy, lead_time=lead_time)


def ra(key, zone, bids, tso=None, kind="preventive", available=True, penalty=1.0, strategy=STRATEGY,
       time_to_implement=None, contingencies=(), name=None):
    """One countertrade RA spec. tso: the NCP file prefix (Belgovia or Galia), default the zone's TSO.
    strategy None: no gLSKStrategy on the RA; penalty None: no penaltyFactor."""
    default_tso = "Galia" if zone == ZONE_GALIA else "Belgovia"
    return dict(key=key, mrid=_uid("ra", key), zone=zone, bids=list(bids), tso=tso or default_tso, kind=kind,
                available=available, penalty=penalty, strategy=strategy, time_to_implement=time_to_implement,
                contingencies=list(contingencies), name=name or f"CT RA {key}")


def default_ras(volume=150.0, penalties=(1.0, 1.0)):
    """One preventive RA per zone, each with an up and a down bid (volume MW). The Belgovia-down /
    Galia-up pair relieves the Belgovia half of TieLine_GA_BO4."""
    return [
        ra("BO", ZONE_BELGOVIA, [bid("BO-up", "up", volume, 12.0, 500.0), bid("BO-down", "down", volume, 8.0, 300.0)],
           penalty=penalties[0], name="CT Belgovia"),
        ra("GA", ZONE_GALIA, [bid("GA-up", "up", volume, 20.0, 400.0), bid("GA-down", "down", volume, 15.0, 250.0)],
           penalty=penalties[1], name="CT Galia"),
    ]


def curative_ras(contingencies=(CONTINGENCY_GA_BO5,), time_to_implement="PT5M", reserve_price=4.0):
    """The same two RAs as curative ones: linked to `contingencies` (default: the outage of TieLine_GA_BO5, which
    build_ct_mock_ncp needs in its `contingencies`; empty: every contingency), with a
    reaction time and a reservation price on every bid."""
    return [
        ra("BO-cur", ZONE_BELGOVIA,
           [bid("BO-cur-up", "up", 120.0, 12.0, reserve_price=reserve_price),
            bid("BO-cur-down", "down", 120.0, 8.0, reserve_price=reserve_price)],
           kind="curative", time_to_implement=time_to_implement, contingencies=contingencies, name="CT Belgovia curative"),
        ra("GA-cur", ZONE_GALIA,
           [bid("GA-cur-up", "up", 120.0, 20.0, reserve_price=reserve_price),
            bid("GA-cur-down", "down", 120.0, 15.0, reserve_price=reserve_price)],
           kind="curative", time_to_implement=time_to_implement, contingencies=contingencies, name="CT Galia curative"),
    ]


def group(key, ras, max_up=None, max_down=None, tso="Belgovia"):
    """A restrictive RemedialActionGroup (CORNET-4838) of the RAs `ras` (ra() specs of the same TSO file) with the
    volume limits maxRegulatingUp / maxRegulatingDown (MW, None: no limit in that direction) at the run timestamp."""
    return dict(key=key, mrid=_uid("group", key), ras=[spec["mrid"] for spec in ras], max_up=max_up, max_down=max_down, tso=tso)


def unknown_strategy_ras(strategy="explicitInstruction"):
    return [ra("BO-unknown", ZONE_BELGOVIA, [bid("BO-unknown-up", "up")], strategy=strategy)]


def mixed_strategy_ras():
    """The RA and its bids declare different strategies (and the bids differ among themselves)."""
    return [
        ra("BO-mixed-ra", ZONE_BELGOVIA, [bid("BO-mixed-ra-up", "up", strategy="proportionalForGenerator")]),
        ra("BO-mixed-bids", ZONE_BELGOVIA,
           [bid("BO-mixed-bids-up", "up", strategy=STRATEGY), bid("BO-mixed-bids-down", "down", strategy="explicitInstruction")],
           strategy=None),
    ]


def bad_zone_ras(zone=ZONE_UNKNOWN):
    """A zone that is not in the Organisation profile (default), or a real zone without a usable unit
    (ZONE_NORDHEIM, ZONE_BRITHEIM)."""
    return [ra("bad-zone", zone, [bid("bad-zone-up", "up")], tso="Belgovia")]


def no_volume_ras():
    return [ra("no-volume", ZONE_BELGOVIA, [bid("no-volume-up", "up", volume=None), bid("no-volume-down", "down", 100.0)])]


def missing_penalty_ras():
    return [ra("no-penalty", ZONE_BELGOVIA, [bid("no-penalty-up", "up")], penalty=None)]


# ---------------------------------------------------------------------------
# XML
# ---------------------------------------------------------------------------

def _ra_xml(spec):
    mrid = spec["mrid"]
    parts = [f"""
  <nc:CountertradeRemedialAction rdf:ID="_{mrid}">
    <cim:IdentifiedObject.mRID>{mrid}</cim:IdentifiedObject.mRID>
    <cim:IdentifiedObject.name>{spec['name']}</cim:IdentifiedObject.name>
    <nc:PowerRemedialAction.BiddingZone rdf:resource="#_{spec['zone']}"/>
    <nc:RemedialAction.normalAvailable>{str(spec['available']).lower()}</nc:RemedialAction.normalAvailable>
    <nc:RemedialAction.kind rdf:resource="{ENUM}RemedialActionKind.{spec['kind']}"/>"""]
    if spec["strategy"]:
        parts.append(f'    <nc:CountertradeRemedialAction.gLSKStrategy rdf:resource="{ENUM}GLSKStrategyKind.{spec["strategy"]}"/>')
    if spec["penalty"] is not None:
        parts.append(f"    <nc:RemedialAction.penaltyFactor>{spec['penalty']}</nc:RemedialAction.penaltyFactor>")
    if spec["time_to_implement"]:
        parts.append(f"    <nc:RemedialAction.timeToImplement>{spec['time_to_implement']}</nc:RemedialAction.timeToImplement>")
    parts.append("  </nc:CountertradeRemedialAction>")
    for index, contingency in enumerate(spec["contingencies"]):
        parts.append(f"""  <nc:ContingencyWithRemedialAction rdf:ID="_{_uid('link', mrid, index)}">
    <nc:ContingencyWithRemedialAction.RemedialAction rdf:resource="#_{mrid}"/>
    <nc:ContingencyWithRemedialAction.Contingency rdf:resource="#_{contingency}"/>
  </nc:ContingencyWithRemedialAction>""")
    return "\n".join(parts)


def bid_mrid(spec, bid_spec):
    return _uid("bid", spec["key"], bid_spec["key"])


def _sis_xml(spec):
    parts = []
    for bid_spec in spec["bids"]:
        pbs = bid_mrid(spec, bid_spec)
        activation = (f"\n    <nc:PowerBidSchedule.activationCost>{bid_spec['activation_cost']}</nc:PowerBidSchedule.activationCost>"
                      if bid_spec["activation_cost"] is not None else "")
        strategy = (f'\n    <nc:PowerBidSchedule.gLSKStrategy rdf:resource="{ENUM}GLSKStrategyKind.{bid_spec["strategy"]}"/>'
                    if bid_spec["strategy"] else "")
        parts.append(f"""  <nc:PowerBidSchedule rdf:ID="_{pbs}">
    <cim:IdentifiedObject.mRID>{pbs}</cim:IdentifiedObject.mRID>
    <cim:IdentifiedObject.name>PB {bid_spec['key']}</cim:IdentifiedObject.name>
    <nc:PowerBidSchedule.PowerRemedialAction rdf:resource="#_{spec['mrid']}"/>
    <nc:PowerBidSchedule.currency rdf:resource="https://cim.ucaiug.io/ns#Currency.EUR"/>
    <nc:PowerBidSchedule.direction rdf:resource="{ENUM}BidDirectionKind.{bid_spec['direction']}"/>
    <nc:PowerBidSchedule.leadTime>{bid_spec['lead_time']}</nc:PowerBidSchedule.leadTime>{activation}{strategy}
  </nc:PowerBidSchedule>""")
        if bid_spec["volume"] is not None:
            reserve = (f"\n    <nc:PowerBidScheduleTimePoint.reservePrice>{bid_spec['reserve_price']}</nc:PowerBidScheduleTimePoint.reservePrice>"
                       if bid_spec["reserve_price"] is not None else "")
            parts.append(f"""  <nc:PowerBidScheduleTimePoint rdf:ID="_{_uid('tp', pbs)}">
    <nc:PowerBidScheduleTimePoint.atTime>{RUN_TIME}</nc:PowerBidScheduleTimePoint.atTime>
    <nc:PowerBidScheduleTimePoint.PowerBidSchedule rdf:resource="#_{pbs}"/>
    <nc:PowerBidScheduleTimePoint.p>{bid_spec['volume']}</nc:PowerBidScheduleTimePoint.p>
    <nc:PowerBidScheduleTimePoint.price>{bid_spec['price']}</nc:PowerBidScheduleTimePoint.price>{reserve}
  </nc:PowerBidScheduleTimePoint>""")
    return "\n".join(parts)


def _shs_xml(limit_a):
    """A CurrentLimitSchedule with one time point (PATL in A at the run timestamp) for the Belgovia half
    of TieLine_GA_BO4, appended to the existing Belgovia_SHS.xml."""
    schedule = _uid("shs-schedule")
    return f"""  <nc:CurrentLimitSchedule rdf:ID="_{schedule}">
    <cim:IdentifiedObject.name>CT mock PATL</cim:IdentifiedObject.name>
    <cim:IdentifiedObject.mRID>{schedule}</cim:IdentifiedObject.mRID>
    <nc:CurrentLimitSchedule.CurrentLimit rdf:resource="#_{XNE_OPERATIONAL_LIMIT}"/>
  </nc:CurrentLimitSchedule>
  <nc:CurrentLimitTimePoint rdf:ID="_{_uid('shs-point')}">
    <nc:CurrentLimitTimePoint.CurrentLimitSchedule rdf:resource="#_{schedule}"/>
    <nc:CurrentLimitTimePoint.atTime>{RUN_TIME}</nc:CurrentLimitTimePoint.atTime>
    <nc:CurrentLimitTimePoint.value>{limit_a}</nc:CurrentLimitTimePoint.value>
  </nc:CurrentLimitTimePoint>"""


def _group_ra_xml(spec):
    parts = [f"""  <nc:RemedialActionGroup rdf:ID="_{spec['mrid']}">
    <cim:IdentifiedObject.mRID>{spec['mrid']}</cim:IdentifiedObject.mRID>
    <cim:IdentifiedObject.name>CT group {spec['key']}</cim:IdentifiedObject.name>
  </nc:RemedialActionGroup>"""]
    for ra_mrid in spec["ras"]:
        parts.append(f"""  <nc:RemedialActionDependency rdf:ID="_{_uid('dependency', spec['mrid'], ra_mrid)}">
    <nc:RemedialActionDependency.kind rdf:resource="{ENUM}RemedialActionDependencyKind.restrictive"/>
    <nc:RemedialActionDependency.RemedialActionGroup rdf:resource="#_{spec['mrid']}"/>
    <nc:RemedialActionDependency.RemedialAction rdf:resource="#_{ra_mrid}"/>
  </nc:RemedialActionDependency>""")
    return "\n".join(parts)


def _group_sis_xml(spec):
    limits = "".join(
        f"\n    <nc:RemedialActionGroup.{name}>{value}</nc:RemedialActionGroup.{name}>"
        for name, value in (("maxRegulatingUp", spec["max_up"]), ("maxRegulatingDown", spec["max_down"])) if value is not None
    )
    return f"""  <nc:RemedialActionGroupTimePoint rdf:ID="_{_uid('group-point', spec['mrid'])}">
    <nc:RemedialActionGroupTimePoint.RemedialActionGroup rdf:resource="#_{spec['mrid']}"/>
    <nc:RemedialActionGroupTimePoint.atTime>{RUN_TIME}</nc:RemedialActionGroupTimePoint.atTime>{limits}
  </nc:RemedialActionGroupTimePoint>"""


def _append(data: bytes, block: str) -> bytes:
    text = data.decode("utf-8")
    end = text.rindex("</rdf:RDF>")
    return (text[:end] + block + "\n" + text[end:]).encode("utf-8")


# the countertrade + HVDC scenario: both act in the same run. The Belgovia half of TieLine_GA_BO4 at 100 A needs the
# countertrade pair; TieLine_SD-EH1 at 175 A (the HVDC mock's branch, 212 A in the CGM) still needs the HVDC pair after
# the countertrade move; low penalty factors make both cheaper than PST and RD on their branch
CT_HVDC_PATL_A = 100.0
CT_HVDC_HVDC_PATL_A = 175.0
CT_HVDC_CT_PENALTY = 0.05
CT_HVDC_HVDC_PENALTY = 0.1


def build_ct_and_hvdc_mock_ncp(dest):
    """The mock NCP of countertrade and HVDC acting together: the default countertrade RAs (penalty factor
    CT_HVDC_CT_PENALTY, PATL CT_HVDC_PATL_A) on top of the HVDC mock (default HVDC RAs with penalty factor
    CT_HVDC_HVDC_PENALTY, PATL CT_HVDC_HVDC_PATL_A of TieLine_SD-EH1). Returns the zip."""
    import hvdc_mock

    dest = Path(dest)
    hvdc_ras = [dict(spec, penalty=CT_HVDC_HVDC_PENALTY) for spec in hvdc_mock.default_ras()]
    hvdc_zip = hvdc_mock.build_hvdc_mock_ncp(dest.with_name(dest.stem + "_hvdc.zip"), ras=hvdc_ras, patl_a=CT_HVDC_HVDC_PATL_A)
    return build_ct_mock_ncp(
        dest, ras=default_ras(penalties=(CT_HVDC_CT_PENALTY, CT_HVDC_CT_PENALTY)), patl_a=CT_HVDC_PATL_A, source_zip=hvdc_zip,
    )


def _fixed_entry(name):
    """A zip entry with a fixed time stamp and attributes, so two builds of the same mock are byte-identical
    (writestr with a plain name stamps the current time)."""
    entry = zipfile.ZipInfo(name, date_time=(1980, 1, 1, 0, 0, 0))
    entry.external_attr = 0o644 << 16
    return entry


def build_ct_mock_ncp(dest, ras=None, patl_a=DEFAULT_PATL_A, source_zip=_MOCK_NX_NCP_ZIP, extra_ra_xml=None, groups=(), contingencies=()):
    """Write the mock NCP zip to `dest` and return it. ras: see default_ras (a list of ra() specs);
    patl_a: PATL (A) of the Belgovia half of TieLine_GA_BO4 at 1030Z, written into Belgovia_SHS.xml
    (None: the SHS file is not changed); extra_ra_xml: {TSO: text} appended to {TSO}_RA.xml; groups: group()
    specs, written into the RA file (members) and the SIS file (limits) of their TSO; contingencies: outage()
    specs, written into Belgovia_CO.xml."""
    ras = default_ras() if ras is None else ras
    ra_blocks, sis_blocks = {}, {}
    for spec in ras:
        ra_blocks.setdefault(spec["tso"], []).append(_ra_xml(spec))
        sis_blocks.setdefault(spec["tso"], []).append(_sis_xml(spec))
    for spec in groups:
        ra_blocks.setdefault(spec["tso"], []).append(_group_ra_xml(spec))
        sis_blocks.setdefault(spec["tso"], []).append(_group_sis_xml(spec))
    dest = Path(dest)
    with zipfile.ZipFile(source_zip) as source, zipfile.ZipFile(dest, "w") as out:
        names = set(source.namelist())
        for item in source.infolist():
            data = source.read(item.filename)
            stem, _, profile = item.filename.removesuffix(".xml").partition("_")
            if profile == "RA" and stem in ra_blocks:
                data = _append(data, "\n".join(ra_blocks[stem]) + (extra_ra_xml or {}).get(stem, ""))
            elif profile == "SIS" and stem in sis_blocks:
                data = _append(data, "\n".join(sis_blocks[stem]))
            elif item.filename == "Belgovia_CO.xml" and contingencies:
                data = _append(data, "\n".join(contingency_xml(c["mrid"], c["lines"], c["name"]) for c in contingencies))
            elif item.filename == "Belgovia_SHS.xml" and patl_a is not None:
                data = _append(data, _shs_xml(patl_a))
            out.writestr(_fixed_entry(item.filename), data)
        missing = [f"{tso}_{profile}.xml" for tso in ra_blocks for profile in ("RA", "SIS") if f"{tso}_{profile}.xml" not in names]
        if missing:
            raise ValueError(f"the source NCP zip has no {missing}")
    return dest
