"""tests/test_rao_milp_builder_ct.py - the preventive countertrade (CT) block of milp_builder.py
(docs/countertrade_ra_specs.md C4-C6).

Grid of the tests: one monitored branch B1 loaded with 1100 A (PATL 1000 A). Zone A has the units A1 and A2,
zone B the units B1 and B2 (A units 300 MW, B units 100 MW, limits 0-400). The CT RA of zone A has a down bid with the weights
A1 0.8, A2 0.2; the CT RA of zone B an up bid with the weights B1 0.5, B2 0.5. Sensitivities of B1 in A/MW:
A1 0.4, A2 0.2, B1 -0.1, B2 -0.1, so one MW of the pair (A down, B up) lowers B1 by 0.8 x 0.4 + 0.2 x 0.2 +
0.1 = 0.46 A, and 100 A of relief need 217.39 MW of each bid.
"""
import logging

import pyomo.environ as pyo
import pytest
from pyomo.core.expr.visitor import identify_variables

from data_model import (
    AcVerificationStatus, AEType, AssessedElement, BidDirection, PowerBid, RAKind, RDUnit, UnitCost,
)
from helpers import _solve
from milp.milp_builder import NxMilpInputs, RdMilpInputs, _rd_unit_status, build_n0_milp_model
from post_milp import n0_results_export

UP, DOWN = BidDirection.UP, BidDirection.DOWN
TS = "1030Z"
SENSITIVITY = {("B1", "A1"): 0.4, ("B1", "A2"): 0.2, ("B1", "B1"): -0.1, ("B1", "B2"): -0.1}
WEIGHTS_A_DOWN = {"A1": 0.8, "A2": 0.2}
WEIGHTS_B_UP = {"B1": 0.5, "B2": 0.5}
RELIEF_PER_MW = 0.46


def _ae(patl_ka=1.0):
    return AssessedElement(
        mrid="AE_B1", name="AE B1", tso="T", ae_type=AEType.SECURED, branch_mrid="B1", secured_for_region=None,
        scanned_for_region=None, exclusion_reason=None, patl_ka={TS: patl_ka}, branch_side=1,
    )


def _units(ra, gus, ct, penalty=1.0, tso="T", available=True):
    return [
        RDUnit(
            mrid=ra, name=ra, tso=tso, gu_mrid=gu, gu_name=gu, available=available, kind=RAKind.PREVENTIVE,
            initial_p=100.0, max_p=400.0, min_p=0.0, raise_ramp_rate=None, lower_ramp_rate=None,
            penalty_factor=penalty, countertrade=ct,
        ) for gu in gus
    ]


def _bid(mrid, ra, direction, volume, price=0.0, activation=None):
    return PowerBid(
        mrid=mrid, ra_mrid=ra, direction=direction, available_mw={TS: volume}, price_eur_mw=price, penalty_factor=0.0,
        lead_time_h=0.0, activation_cost_eur=activation, min_energy_mwh=None, max_energy_mwh=None, step_size_mw=None,
    )


def _generators(**overrides):
    data = {
        gu: {"target_p": 300.0 if gu.startswith("A") else 100.0, "max_p": 400.0, "min_p": 0.0, "connected": True, "name": gu}
        for gu in ("A1", "A2", "B1", "B2")
    }
    for gu, values in overrides.items():
        data[gu] = {**data[gu], **values}
    return data


def _inputs(rd_units=(), rd_bids=(), glsk=None, ct_a_penalty=1.0, ct_b_penalty=1.0, volume=300.0, generators=None,
            extra_units=(), extra_bids=(), bid_participation=None, sensitivity=None, activation=None, **kwargs):
    """CT RA 'CT_A' (down bid 'BID_A_DOWN', price 8) and CT RA 'CT_B' (up bid 'BID_B_UP', price 20) plus optional RD."""
    units = _units("CT_A", ["A1", "A2"], True, ct_a_penalty) + _units("CT_B", ["B1", "B2"], True, ct_b_penalty)
    bids = [
        _bid("BID_A_DOWN", "CT_A", DOWN, volume, 8.0, activation), _bid("BID_B_UP", "CT_B", UP, volume, 20.0, activation),
    ]
    participation = {"BID_A_DOWN": dict(WEIGHTS_A_DOWN), "BID_B_UP": dict(WEIGHTS_B_UP)}
    participation.update(bid_participation or {})
    values = dict(
        rd_list=units + list(rd_units) + list(extra_units), bid_list=bids + list(rd_bids) + list(extra_bids),
        glsk=glsk or {}, sensitivity_rd_n0_pruned=dict(SENSITIVITY if sensitivity is None else sensitivity),
        generator_data=generators or _generators(), penalty_reference_rd_pra=0.0, bid_participation=participation,
        penalty_reference_ct_pra=100.0, penalty_reference_ct_cra=100.0,
    )
    values.update(kwargs)
    return RdMilpInputs(**values)


def _build(rd_inputs, patl_ka=1.0, loading=1100.0, overload_penalty=1e6):
    return build_n0_milp_model(
        [_ae(patl_ka)], TS, lf_initial={"B1": {1: loading}}, penalty_cost_overload_n0=overload_penalty, rd_inputs=rd_inputs,
    )


def _solved(rd_inputs, **kwargs):
    return _solve(_build(rd_inputs, **kwargs))


def _named(model):
    return {name: pyo.value(expression) for name, expression in model.objective_penalty_term_expressions.items()}


# ---------------------------------------------------------------------------
# weights, relief, balance, limits, cost
# ---------------------------------------------------------------------------

def test_the_weights_of_each_bid_are_in_the_net_injection_of_the_units():
    model = _solved(_inputs())
    down, up = pyo.value(model.rd_volume_downward["BID_A_DOWN"]), pyo.value(model.rd_volume_upward["BID_B_UP"])
    assert down == pytest.approx(100.0 / RELIEF_PER_MW, rel=1e-6) and up == pytest.approx(down, rel=1e-6)
    net = {gu: pyo.value(model.rd_net_injection_g[gu]) for gu in ("A1", "A2", "B1", "B2")}
    assert net["A1"] == pytest.approx(-0.8 * down) and net["A2"] == pytest.approx(-0.2 * down)
    assert net["B1"] == pytest.approx(0.5 * up) and net["B2"] == pytest.approx(0.5 * up)


def test_the_countertrade_pair_relieves_the_overloaded_branch():
    model = _solved(_inputs())
    effect = pyo.value(model.rd_effect_on_branch["B1"])
    assert 1100.0 + effect == pytest.approx(1000.0, abs=1e-4)
    assert pyo.value(model.overload_slack_n0["B1"]) == pytest.approx(0.0, abs=1e-6)


def test_the_global_balance_of_the_countertrade_injections_is_zero():
    model = _solved(_inputs())
    assert sum(pyo.value(model.rd_net_injection_g[gu]) for gu in model.gu_ids) == pytest.approx(0.0, abs=1e-9)
    assert hasattr(model, "rd_balancing_n0")


def test_the_unit_limits_bind_on_the_countertrade_total():
    # A1 may fall by 10 MW only (target 60, Pmin 50): the pair is limited to 10 / 0.8 = 12.5 MW and the rest is overload
    model = _solved(_inputs(generators=_generators(A1={"target_p": 60.0, "min_p": 50.0})))
    assert pyo.value(model.rd_volume_downward["BID_A_DOWN"]) == pytest.approx(12.5, abs=1e-6)
    assert 60.0 + pyo.value(model.rd_net_injection_g["A1"]) == pytest.approx(50.0, abs=1e-6)
    assert pyo.value(model.overload_slack_n0["B1"]) == pytest.approx(100.0 - RELIEF_PER_MW * 12.5, abs=1e-4)


def test_the_cost_is_the_sum_of_its_named_terms_and_the_objective_is_the_sum_of_the_terms():
    model = _solved(_inputs(activation=250.0))
    volume = 100.0 / RELIEF_PER_MW
    terms = _named(model)
    assert terms["ct_pra_penalty_cost"] == pytest.approx(1.0 * 100.0 * 2 * volume, rel=1e-6)
    assert terms["ct_pra_energy_cost"] == pytest.approx((8.0 + 20.0) * volume, rel=1e-6)
    assert terms["ct_bid_activation_cost"] == pytest.approx(500.0)
    assert pyo.value(model.objective) == pytest.approx(sum(terms.values()), rel=1e-9)
    assert not any(name in terms for name in ("bid_activation_cost", "startup_cost", "shutdown_cost"))


@pytest.mark.parametrize("factor, expected_penalty", [(0.0, 0.0), (2.0, 2.0 * 100.0)])
def test_the_penalty_factor_scales_the_penalty_cost(factor, expected_penalty):
    model = _solved(_inputs(ct_a_penalty=factor, ct_b_penalty=0.0))
    volume = 100.0 / RELIEF_PER_MW
    assert _named(model)["ct_pra_penalty_cost"] == pytest.approx(expected_penalty * volume, rel=1e-6)


def test_a_bid_with_no_participation_has_volume_zero():
    model = _build(_inputs(bid_participation={"BID_B_UP": {}}))
    assert model.rd_volume_upward["BID_B_UP"].ub == 0.0 and model.rd_volume_downward["BID_B_UP"].ub == 0.0


def test_a_negative_weight_names_the_countertrade_bid():
    with pytest.raises(ValueError, match="Weights of countertrade bid BID_A_DOWN: generating unit A1"):
        _build(_inputs(bid_participation={"BID_A_DOWN": {"A1": -0.1, "A2": 1.1}}))


def test_the_participation_of_the_bid_replaces_the_glsk_of_its_ra():
    model = _solved(_inputs(glsk={"CT_A": {"A1": 1.0}}))
    assert pyo.value(model.rd_net_injection_g["A2"]) == pytest.approx(0.2 * pyo.value(model.rd_volume_downward["BID_A_DOWN"]) * -1)


# ---------------------------------------------------------------------------
# RD and CT together
# ---------------------------------------------------------------------------

def _rd_pair():
    """An RD RA on A1 with a down bid of 8 MW (free) and an RD RA on B1 with an up bid (free): the cheapest relief."""
    units = _units("RD_A", ["A1"], False, 0.0) + _units("RD_B", ["B1"], False, 0.0)
    bids = [_bid("BID_RD_A", "RD_A", DOWN, 8.0), _bid("BID_RD_B", "RD_B", UP, 8.0)]
    return units, bids, {"RD_A": {"A1": 1.0}, "RD_B": {"B1": 1.0}}


def _shared_model(**generators):
    """RD takes 8 MW of the room of A1 (fixed); countertrade gets the rest of the room."""
    units, bids, glsk = _rd_pair()
    rd_inputs = _inputs(units, bids, glsk, penalty_reference_rd_pra=5.0, generators=_generators(A1={"target_p": 60.0, "min_p": 50.0}))
    model = _build(rd_inputs)
    model.rd_volume_downward["BID_RD_A"].fix(8.0)
    return rd_inputs, _solve(model)


def test_rd_and_ct_share_one_total_per_unit():
    _, model = _shared_model()
    assert pyo.value(model.rd_volume_downward["BID_RD_A"]) == pytest.approx(8.0, abs=1e-6)
    assert pyo.value(model.rd_volume_downward["BID_A_DOWN"]) == pytest.approx(2.0 / 0.8, abs=1e-6)   # 10 MW of room minus 8 MW of RD
    assert pyo.value(model.rd_net_injection_g["A1"]) == pytest.approx(-10.0, abs=1e-6)
    variables = {v.name for v in identify_variables(model.pmax_pmin_constraint["A1"].body)}
    assert {"rd_volume_downward[BID_RD_A]", "rd_volume_downward[BID_A_DOWN]"} <= variables


def test_the_rd_result_files_leave_the_countertrade_bids_out_and_the_residual_is_zero():
    rd_inputs, model = _shared_model()
    assert model.ct_bid_ids == frozenset({"BID_A_DOWN", "BID_B_UP"})
    status = AcVerificationStatus.NOT_APPLICABLE
    rd_results = n0_results_export.extract_rd_results(
        model, rd_inputs.rd_list, rd_inputs.bid_list, 5.0, status, "", None, TS, None,
    )
    assert set(rd_results) == {"BID_RD_A", "BID_RD_B"}
    units_result = n0_results_export.extract_results_generating_units(
        model, rd_inputs.rd_list, status, "", glsk=rd_inputs.glsk, rd_results=rd_results, timestamp=TS,
        ct_bid_participation=rd_inputs.bid_participation,
    )
    assert set(units_result) == {"A1", "B1"}
    ct_down = pyo.value(model.rd_volume_downward["BID_A_DOWN"])
    assert units_result["A1"]["rd_volume_net_mw"] == pytest.approx(-8.0, abs=1e-6)
    assert units_result["A1"]["ct_volume_net_mw"] == pytest.approx(-0.8 * ct_down, abs=1e-6)
    assert units_result["A1"]["result_production_mw"] == pytest.approx(60.0 - 8.0 - 0.8 * ct_down, abs=1e-6)
    without_ct = n0_results_export.extract_results_generating_units(
        model, rd_inputs.rd_list, status, "", glsk=rd_inputs.glsk, rd_results=rd_results, timestamp=TS,
    )
    assert "ct_volume_net_mw" not in without_ct["A1"]          # no countertrade run: no column
    summary = n0_results_export.extract_results_summary(
        model, objective_value=pyo.value(model.objective), rd_results=rd_results, ra_types=["rd", "countertrade"],
    )
    assert summary["objective_residual_eur"] == pytest.approx(0.0, abs=1e-6)
    assert summary["sum_rd_volume_downward_mw"] == pytest.approx(8.0, abs=1e-6)


def _rd_cost_part(model):
    """The objective without its named terms (no overload is left: slack 0): the RD bid cost (penalty and price)."""
    assert pyo.value(model.overload_slack_n0["B1"]) == pytest.approx(0.0, abs=1e-9)
    return pyo.value(model.objective) - sum(_named(model).values())


def test_the_countertrade_cost_terms_are_not_in_the_rd_cost():
    # the same RD bids at the same volumes cost the same with and without countertrade bids next to them; the
    # countertrade bids pay only their own named terms
    units = _units("RD_A", ["A1"], False, 1.0) + _units("RD_B", ["B1"], False, 1.0)
    bids = [_bid("BID_RD_A", "RD_A", DOWN, 8.0, 3.0, 40.0), _bid("BID_RD_B", "RD_B", UP, 8.0, 5.0, 60.0)]
    glsk = {"RD_A": {"A1": 1.0}, "RD_B": {"B1": 1.0}}
    with_ct = _build(_inputs(units, bids, glsk, penalty_reference_rd_pra=5.0, activation=250.0))
    rd_only = _build(RdMilpInputs(
        rd_list=units, bid_list=bids, glsk=glsk, sensitivity_rd_n0_pruned=dict(SENSITIVITY),
        generator_data=_generators(), penalty_reference_rd_pra=5.0,
    ), loading=900.0)                                                         # no overload: the RD bids alone
    for model in (with_ct, rd_only):
        model.rd_volume_downward["BID_RD_A"].fix(8.0)
        model.rd_volume_upward["BID_RD_B"].fix(8.0)
        _solve(model)
    assert pyo.value(with_ct.rd_volume_downward["BID_A_DOWN"]) > 1.0          # countertrade is used next to RD
    assert _rd_cost_part(with_ct) == pytest.approx(_rd_cost_part(rd_only), rel=1e-9)
    assert _rd_cost_part(rd_only) == pytest.approx((1.0 * 5.0 + 3.0) * 8.0 + (1.0 * 5.0 + 5.0) * 8.0, rel=1e-9)
    assert _named(with_ct)["bid_activation_cost"] == pytest.approx(_named(rd_only)["bid_activation_cost"]) == pytest.approx(100.0)
    assert _named(with_ct)["ct_bid_activation_cost"] == pytest.approx(500.0)


# ---------------------------------------------------------------------------
# several CT RAs in one zone, several bids of one RA (C4.4)
# ---------------------------------------------------------------------------

def test_two_ct_ras_of_one_zone_keep_their_own_weights_and_share_the_unit_totals():
    # CT_A (A1 0.8, A2 0.2) and CT_A2 (A1 0.3, A2 0.7), both down; A1 has 10 MW of room down (target 60, Pmin 50)
    units = _units("CT_A2", ["A1", "A2"], True)
    bids = [_bid("BID_A2_DOWN", "CT_A2", DOWN, 300.0, 8.0)]
    rd_inputs = _inputs(
        extra_units=units, extra_bids=bids, bid_participation={"BID_A2_DOWN": {"A1": 0.3, "A2": 0.7}},
        generators=_generators(A1={"target_p": 60.0, "min_p": 50.0}),
    )
    model = _build(rd_inputs)
    model.rd_volume_downward["BID_A_DOWN"].fix(10.0)                      # 8 MW of A1's room
    _solve(model)
    first, second = 10.0, pyo.value(model.rd_volume_downward["BID_A2_DOWN"])
    assert second == pytest.approx(2.0 / 0.3, abs=1e-6)                   # the rest of A1's room, at CT_A2's own weight
    assert pyo.value(model.rd_net_injection_g["A1"]) == pytest.approx(-(0.8 * first + 0.3 * second), abs=1e-6)
    assert pyo.value(model.rd_net_injection_g["A2"]) == pytest.approx(-(0.2 * first + 0.7 * second), abs=1e-6)
    variables = {v.name for v in identify_variables(model.pmax_pmin_constraint["A1"].body)}
    assert {"rd_volume_downward[BID_A_DOWN]", "rd_volume_downward[BID_A2_DOWN]"} <= variables


def test_two_bids_of_one_ra_in_one_direction_both_act_with_the_weights_of_the_ra():
    # the first bid (price 8) is capped at 100 MW, so the second (price 9) gives the rest of the 217.39 MW of relief
    second = _bid("BID_A_DOWN_2", "CT_A", DOWN, 300.0, 9.0)
    model = _build(_inputs(extra_bids=[second], bid_participation={"BID_A_DOWN_2": dict(WEIGHTS_A_DOWN)}))
    model.rd_volume_downward["BID_A_DOWN"].setub(100.0)
    _solve(model)
    first_volume, second_volume = (pyo.value(model.rd_volume_downward[b]) for b in ("BID_A_DOWN", "BID_A_DOWN_2"))
    assert first_volume == pytest.approx(100.0, abs=1e-6) and second_volume == pytest.approx(100.0 / RELIEF_PER_MW - 100.0, abs=1e-4)
    for gu, weight in WEIGHTS_A_DOWN.items():
        assert pyo.value(model.rd_net_injection_g[gu]) == pytest.approx(-weight * (first_volume + second_volume), abs=1e-6)


# ---------------------------------------------------------------------------
# the CT effect in every monitored row (C6.3, C7.4)
# ---------------------------------------------------------------------------

SENSITIVITY_S1 = {("S1", "A1"): 0.1, ("S1", "A2"): 0.3, ("S1", "B1"): -0.2, ("S1", "B2"): -0.2}
TATL_B1 = {"B1": {"tatl_limit_ampere": 1200.0, "tatl_duration_seconds": 600, "side": 1, "was_corrected": False}}


def _scanned_ae():
    return AssessedElement(
        mrid="AE_S1", name="AE S1", tso="T", ae_type=AEType.SCANNED, branch_mrid="S1", secured_for_region=None,
        scanned_for_region=None, exclusion_reason=None, patl_ka={TS: 1.0}, branch_side=1,
    )


def _rows_nx(sensitivity_both):
    return NxMilpInputs(
        lf_nx={"CO1": {"B1": {1: 1100.0}, "S1": {1: 600.0}}}, sensitivity_pst_nx={},
        sensitivity_rd_nx={"CO1": dict(sensitivity_both)}, penalty_cost_overload_nx_patl=1e6, tatl_data=dict(TATL_B1),
        tatl_fallback_duration_seconds=600,
    )


def _coefficient(body, name):
    from pyomo.repn import generate_standard_repn
    repn = generate_standard_repn(body)
    return sum(c for v, c in zip(repn.linear_vars, repn.linear_coefs) if v.name == name)


# A per MW of each bid's volume: the bid's weights times the unit sensitivities (down bids inject with a minus sign)
A_DOWN_B1 = -(0.8 * 0.4 + 0.2 * 0.2)
B_UP_B1 = 0.5 * -0.1 + 0.5 * -0.1
A_DOWN_S1 = -(0.8 * 0.1 + 0.2 * 0.3)


def test_the_preventive_ct_effect_is_in_the_scanned_n0_and_every_n_x_row():
    sensitivity = {**SENSITIVITY, **SENSITIVITY_S1}
    model = build_n0_milp_model(
        [_ae(), _scanned_ae()], TS, lf_initial={"B1": {1: 1100.0}, "S1": {1: 600.0}}, penalty_cost_overload_n0=1e6,
        rd_inputs=_inputs(sensitivity=sensitivity), nx_inputs=_rows_nx(sensitivity),
    )
    down = "rd_volume_downward[BID_A_DOWN]"
    assert _coefficient(model.xne_loading_n0["B1"].body, down) == pytest.approx(A_DOWN_B1)
    assert _coefficient(model.scanned_element_n0["S1"].body, down) == pytest.approx(A_DOWN_S1)
    assert _coefficient(model.nx_patl_loading["B1", "CO1"].body, down) == pytest.approx(A_DOWN_B1)
    assert _coefficient(model.nx_tatl_loading["B1", "CO1"].body, down) == pytest.approx(A_DOWN_B1)
    assert _coefficient(model.nx_scanned_loading["S1", "CO1"].body, down) == pytest.approx(A_DOWN_S1)
    assert _coefficient(model.nx_patl_loading["B1", "CO1"].body, "rd_volume_upward[BID_B_UP]") == pytest.approx(B_UP_B1)


def _curative_rows_model():
    sensitivity = {**SENSITIVITY, **SENSITIVITY_S1}
    rd_inputs = _cur_inputs()
    model = build_n0_milp_model(
        [_ae(), _scanned_ae()], TS, lf_initial={"B1": {1: 500.0}, "S1": {1: 600.0}}, penalty_cost_overload_n0=1e6,
        rd_inputs=rd_inputs, nx_inputs=_rows_nx(sensitivity),
    )
    return model


def test_the_curative_ct_effect_is_in_the_patl_and_scanned_rows_and_not_in_the_tatl_row():
    model = _curative_rows_model()
    down = "curative_rd_volume_downward[BID_A_DOWN,CO1]"
    assert _coefficient(model.nx_patl_loading["B1", "CO1"].body, down) == pytest.approx(A_DOWN_B1)
    assert _coefficient(model.nx_scanned_loading["S1", "CO1"].body, down) == pytest.approx(A_DOWN_S1)
    names = {v.name for v in identify_variables(model.nx_tatl_loading["B1", "CO1"].body)}
    assert not any(name.startswith("curative_rd_volume") for name in names)            # R11: the TATL row is preventive only


def test_criterion_4_uses_the_curative_ct_effect():
    model = _solve(_curative_rows_model())
    down = pyo.value(model.curative_rd_volume_downward["BID_A_DOWN", "CO1"])
    up = pyo.value(model.curative_rd_volume_upward["BID_B_UP", "CO1"])
    assert down > 1.0 and up == pytest.approx(down, rel=1e-6)
    assert model.nx_curative_effect_ampere("B1", "CO1") == pytest.approx(A_DOWN_B1 * down + B_UP_B1 * up, rel=1e-9)
    assert model.nx_curative_effect_ampere("B1", "CO1") == pytest.approx(-100.0, abs=1e-4)      # 1100 A down to the PATL


# ---------------------------------------------------------------------------
# on/off units
# ---------------------------------------------------------------------------

def _on_off_inputs(extra_rd_bid_volume=50.0):
    """A2 (50 MW, Pmin 20) can be shut down by an RD down bid of 50 MW (shut-down cost 10): a binary unit that is
    also in the weights of the CT bid of zone A."""
    units = _units("RD_A2", ["A2"], False, 0.0)
    bids = [_bid("BID_RD_A2", "RD_A2", DOWN, extra_rd_bid_volume)]
    return _inputs(
        units, bids, {"RD_A2": {"A2": 1.0}}, generators=_generators(A2={"target_p": 50.0, "min_p": 20.0}),
        unit_costs={"A2": UnitCost(shutdown_cost_eur=10.0)}, sensitivity={**SENSITIVITY, ("B1", "A2"): 1.0},
    )


def test_the_one_sided_rows_exist_only_for_the_countertrade_units_with_a_binary():
    model = _build(_on_off_inputs())
    assert set(model.rd_binary_gu_ids) == {"A2"} and set(model.ct_on_off_unit_ids) == {"A2"}
    assert hasattr(model, "ct_on_off_up") and hasattr(model, "ct_on_off_down")
    assert len(_build(_inputs()).ct_on_off_unit_ids) == 0


def test_a_unit_that_rd_shuts_down_receives_no_countertrade_volume():
    model = _build(_on_off_inputs())
    model.rd_unit_on["A2"].fix(0)
    _solve(model)
    assert pyo.value(model.rd_volume_downward["BID_A_DOWN"]) == pytest.approx(0.0, abs=1e-9)
    assert 50.0 + pyo.value(model.rd_net_injection_g["A2"]) == pytest.approx(0.0, abs=1e-6)


def test_a_unit_that_stays_on_can_receive_countertrade_volume():
    model = _build(_on_off_inputs())
    model.rd_unit_on["A2"].fix(1)
    _solve(model)
    assert pyo.value(model.rd_volume_downward["BID_A_DOWN"]) > 1.0


def _status_inputs(participation, rd_up_volume=0.0, target=0.0, pmin=30.0):
    """A unit U1 with the given set point and Pmin, in the weights of one CT up bid and, optionally, one RD up bid."""
    units = _units("CT_X", ["U1"], True)
    bids = [_bid("BID_CT_UP", "CT_X", UP, 100.0)]
    glsk = {}
    if rd_up_volume:
        units += _units("RD_X", ["U1"], False)
        bids.append(_bid("BID_RD_UP", "RD_X", UP, rd_up_volume))
        glsk["RD_X"] = {"U1": 1.0}
    return RdMilpInputs(
        rd_list=units, bid_list=bids, glsk=glsk, sensitivity_rd_n0_pruned={},
        generator_data={"U1": {"target_p": target, "max_p": 200.0, "min_p": pmin, "connected": True}},
        unit_costs={"U1": UnitCost(startup_cost_eur=100.0)}, bid_participation={"BID_CT_UP": participation},
    )


def test_a_countertrade_bid_does_not_make_a_unit_startable():
    status = _rd_unit_status(_status_inputs({"U1": 1.0}), TS)["U1"]
    assert not status.initially_on and status.unit_class == "fixed_off"


def test_an_rd_bid_makes_the_same_unit_startable():
    status = _rd_unit_status(_status_inputs({"U1": 1.0}, rd_up_volume=100.0), TS)["U1"]
    assert status.unit_class == "startable"


def test_a_countertrade_only_unit_between_zero_and_pmin_gets_pmin_set_to_its_production():
    status = _rd_unit_status(_status_inputs({"U1": 1.0}, target=30.0, pmin=50.0), TS)["U1"]
    assert status.initially_on and status.pmin_mw == pytest.approx(30.0) and status.unit_class == "continuous"


def test_a_running_countertrade_only_unit_is_continuous_and_cannot_be_shut_down():
    status = _rd_unit_status(_status_inputs({"U1": 1.0}, target=60.0, pmin=50.0), TS)["U1"]
    assert status.unit_class == "continuous" and status.pmin_mw == 50.0


# ---------------------------------------------------------------------------
# RA groups and RA counts
# ---------------------------------------------------------------------------

def test_a_restrictive_group_caps_the_volume_of_a_countertrade_bid():
    groups = {"G1": {"name": "G1", "ra_mrids": ["CT_A"], "max_regulating_up": None, "max_regulating_down": 50.0}}
    model = _solved(_inputs(ra_groups=groups))
    assert pyo.value(model.rd_volume_downward["BID_A_DOWN"]) == pytest.approx(50.0, abs=1e-6)
    assert hasattr(model, "ra_group_volume_downward_limit")


def test_countertrade_ras_count_in_the_ra_count_limit():
    model = _build(_inputs(
        max_ra_count_per_timestamp_tso={"T": 1}, ra_limit_constraint_hard=False, ra_limit_penalty=10.0,
    ))
    assert set(model.ra_mrids) == {"CT_A", "CT_B"} and hasattr(model, "ra_count_limit_per_timestamp")
    _solve(model)
    assert pyo.value(model.ra_count_slack_per_timestamp["T"]) == pytest.approx(1.0, abs=1e-6)


# ---------------------------------------------------------------------------
# no countertrade: nothing changes
# ---------------------------------------------------------------------------

def test_an_rd_model_has_no_countertrade_component():
    units, bids, glsk = _rd_pair()
    rd_inputs = RdMilpInputs(
        rd_list=units, bid_list=bids, glsk=glsk, sensitivity_rd_n0_pruned=dict(SENSITIVITY),
        generator_data=_generators(), penalty_reference_rd_pra=5.0,
    )
    model = _solved(rd_inputs)
    assert model.ct_bid_ids == frozenset()
    assert not any(hasattr(model, name) for name in ("rd_only_net_injection_g", "ct_on_off_up", "ct_on_off_down", "ct_on_off_unit_ids"))
    assert not any(name.startswith("ct_") for name in model.objective_penalty_term_expressions)


# ---------------------------------------------------------------------------
# curative countertrade (docs/countertrade_ra_specs.md C7)
# ---------------------------------------------------------------------------

def _cur_units(ra, gus, links=("CO1",), reaction=None, penalty=1.0, kind=RAKind.CURATIVE, ct=True):
    return [
        RDUnit(
            mrid=ra, name=ra, tso="T", gu_mrid=gu, gu_name=gu, available=True, kind=kind, initial_p=100.0, max_p=400.0,
            min_p=0.0, raise_ramp_rate=None, lower_ramp_rate=None, penalty_factor=penalty,
            linked_contingency_mrids=list(links), reaction_time_minutes=reaction, countertrade=ct,
        ) for gu in gus
    ]


def _cur_bid(mrid, ra, direction, volume=300.0, price=0.0, reserve=None):
    bid = _bid(mrid, ra, direction, volume, price)
    bid.reserve_price_eur_mw = reserve
    return bid


def _cur_inputs(links=("CO1",), reaction=None, reserve=None, generators=None, extra_units=(), extra_bids=(), glsk=None,
                participation=None, penalty=1.0, **kwargs):
    """CT RAs 'CT_A' (curative down bid, price 8) and 'CT_B' (curative up bid, price 20), both linked to `links`."""
    units = _cur_units("CT_A", ["A1", "A2"], links, reaction, penalty) + _cur_units("CT_B", ["B1", "B2"], links, reaction, penalty)
    bids = [_cur_bid("BID_A_DOWN", "CT_A", DOWN, 300.0, 8.0, reserve), _cur_bid("BID_B_UP", "CT_B", UP, 300.0, 20.0, reserve)]
    bid_participation = {"BID_A_DOWN": dict(WEIGHTS_A_DOWN), "BID_B_UP": dict(WEIGHTS_B_UP)}
    bid_participation.update(participation or {})
    values = dict(
        rd_list=units + list(extra_units), bid_list=bids + list(extra_bids), glsk=glsk or {},
        sensitivity_rd_n0_pruned={}, generator_data=generators or _generators(), penalty_reference_rd_pra=0.0,
        bid_participation=bid_participation, penalty_reference_ct_pra=100.0, penalty_reference_ct_cra=50.0,
    )
    values.update(kwargs)
    return RdMilpInputs(**values)


def _cur_nx(tatl_duration_s=None):
    tatl = {"B1": {"tatl_limit_ampere": 1000.0, "tatl_duration_seconds": tatl_duration_s, "side": 1, "was_corrected": False}} \
        if tatl_duration_s is not None else None
    return NxMilpInputs(
        lf_nx={"CO1": {"B1": {1: 1100.0}}, "CO2": {"B1": {1: 900.0}}},
        sensitivity_pst_nx={}, sensitivity_rd_nx={co: dict(SENSITIVITY) for co in ("CO1", "CO2")},
        penalty_cost_overload_nx_patl=1e6, tatl_data=tatl, tatl_fallback_duration_seconds=600,
    )


def _cur_build(rd_inputs, nx_inputs=None):
    return build_n0_milp_model(
        [_ae()], TS, lf_initial={"B1": {1: 500.0}}, penalty_cost_overload_n0=1e6, rd_inputs=rd_inputs,
        nx_inputs=nx_inputs or _cur_nx(),
    )


def _acts_in(model, branch, contingency, bid):
    names = {v.name for v in identify_variables(model.nx_patl_loading[branch, contingency].body)}
    return any(name.endswith(f"[{bid},{contingency}]") for name in names)


def test_a_curative_ct_ra_acts_only_in_its_linked_contingency():
    model = _cur_build(_cur_inputs(links=("CO1",)))
    assert sorted(model.curative_bid_contingency_pairs) == [("BID_A_DOWN", "CO1"), ("BID_B_UP", "CO1")]
    assert _acts_in(model, "B1", "CO1", "BID_A_DOWN") and ("B1", "CO2") in model.nx_branch_contingency_pairs
    assert not _acts_in(model, "B1", "CO2", "BID_A_DOWN")


def test_a_curative_ct_ra_without_a_link_acts_in_every_contingency():
    model = _cur_build(_cur_inputs(links=()))
    assert sorted(model.curative_bid_contingency_pairs) == [
        ("BID_A_DOWN", "CO1"), ("BID_A_DOWN", "CO2"), ("BID_B_UP", "CO1"), ("BID_B_UP", "CO2"),
    ]
    assert _acts_in(model, "B1", "CO2", "BID_B_UP")


def test_the_curative_pair_relieves_the_contingency_and_the_balance_holds_in_each_contingency():
    model = _solve(_cur_build(_cur_inputs(links=())))
    volume = 100.0 / RELIEF_PER_MW
    assert pyo.value(model.curative_rd_volume_downward["BID_A_DOWN", "CO1"]) == pytest.approx(volume, rel=1e-6)
    assert pyo.value(model.curative_rd_volume_upward["BID_B_UP", "CO1"]) == pytest.approx(volume, rel=1e-6)
    assert pyo.value(model.nx_patl_overload_slack["B1", "CO1"]) == pytest.approx(0.0, abs=1e-6)
    for co in ("CO1", "CO2"):
        total = sum(pyo.value(model.curative_rd_net_injection_g[gu, c]) for gu, c in model.curative_gu_contingency_pairs if c == co)
        assert total == pytest.approx(0.0, abs=1e-9)
    assert pyo.value(model.curative_rd_volume_downward["BID_A_DOWN", "CO2"]) == pytest.approx(0.0, abs=1e-9)


def test_curative_countertrade_is_never_applied_to_the_network():
    from milp.post_ra_congestion_check import extract_rd_target_p_solution
    rd_inputs = _cur_inputs()
    model = _solve(_cur_build(rd_inputs))
    assert not hasattr(model, "rd_net_injection_g") and extract_rd_target_p_solution(model, rd_inputs.generator_data) == {}


def _weights_of_zone_b_at_pmax(direction=UP):
    """The weights of zone B (B1, B2 at their Pmax of 400 MW) for `direction`, with the log line of the RA."""
    from data_model import CtZoneUnit
    from pre_milp.ct_weights import compute_ct_weights
    units = [CtZoneUnit(gu, f"U-{gu}", gu, 400.0, 0.0, 400.0) for gu in ("B1", "B2")]
    return compute_ct_weights(units, direction, label="countertrade RA CT_B")


def _empty_direction_lines(caplog):
    """The log lines about the empty up direction of CT_B / BID_B_UP (other lines on the bid, e.g. its reservation
    price, are not about the direction)."""
    return [
        m for m in (r.getMessage() for r in caplog.records)
        if ("BID_B_UP" in m or "CT_B" in m) and any(k in m for k in ("no unit", "fixed", "GLSK", "operation"))
    ]


def test_a_curative_ct_bid_without_a_unit_that_can_move_is_fixed_to_zero_with_one_log_line(caplog):
    # C3.7 / R4: zone B has no room up, so its curative up bid is fixed to 0 in every contingency; the only log
    # line is the one of the weights (once per RA and direction), the MILP adds none
    from milp import milp_builder
    milp_builder.reset_run_log_state()
    with caplog.at_level(logging.INFO):
        weights = _weights_of_zone_b_at_pmax()
        model = _cur_build(_cur_inputs(links=(), participation={"BID_B_UP": weights.pf}))
    assert weights.pf == {}
    for co in ("CO1", "CO2"):
        assert model.curative_rd_volume_upward["BID_B_UP", co].fixed and model.curative_rd_volume_upward["BID_B_UP", co].value == 0.0
    lines = _empty_direction_lines(caplog)
    assert len(lines) == 1 and "no unit can move up" in lines[0] and "fixed to 0" in lines[0]


def test_an_empty_preventive_direction_is_logged_once(caplog):
    from milp import milp_builder
    milp_builder.reset_run_log_state()
    with caplog.at_level(logging.INFO):
        weights = _weights_of_zone_b_at_pmax()
        model = _build(_inputs(bid_participation={"BID_B_UP": weights.pf}))
    assert model.rd_volume_upward["BID_B_UP"].ub == 0.0 and model.rd_volume_downward["BID_B_UP"].ub == 0.0
    lines = _empty_direction_lines(caplog)
    assert len(lines) == 1 and "no unit can move up" in lines[0]


def test_an_empty_rd_glsk_still_logs_its_own_line(caplog):
    # the RD line is unchanged: an RD bid whose GLSK has no modelled unit keeps its "empty GLSK" line
    from milp import milp_builder
    milp_builder.reset_run_log_state()
    units, bids, glsk = _rd_pair()
    with caplog.at_level(logging.INFO):
        _build(_inputs(units, bids, {"RD_A": {"X9": 1.0}, "RD_B": glsk["RD_B"]}))
    assert any("BID_RD_A" in r.getMessage() and "empty GLSK" in r.getMessage() for r in caplog.records)


def test_the_curative_gate_row_holds_a_ct_bid_whose_units_all_have_an_on_off_binary():
    # R4: a curative CT bid on A2 only (a unit that the preventive RD can shut down) gets the gate row
    # volume <= available x u(A2); with A2 shut down the bid moves nothing
    rd_units = _units("RD_A2", ["A2"], False, 0.0) + _units("RD_B1", ["B1"], False, 0.0)
    rd_inputs = _cur_inputs(
        participation={"BID_A_DOWN": {"A2": 1.0}},
        extra_units=rd_units, extra_bids=[_bid("BID_RD_A2", "RD_A2", DOWN, 50.0), _bid("BID_RD_B1", "RD_B1", UP, 50.0)],
        glsk={"RD_A2": {"A2": 1.0}, "RD_B1": {"B1": 1.0}},
        generators=_generators(A2={"target_p": 50.0, "min_p": 20.0}), unit_costs={"A2": UnitCost(shutdown_cost_eur=10.0)},
    )
    model = _cur_build(rd_inputs)
    assert ("BID_A_DOWN", "CO1") in set(model.curative_rd_unit_gate_index)
    assert model.curative_rd_gating_units["BID_A_DOWN"] == ["A2"]
    model.rd_unit_on["A2"].fix(0)
    _solve(model)
    assert pyo.value(model.curative_rd_volume_downward["BID_A_DOWN", "CO1"]) == pytest.approx(0.0, abs=1e-9)


@pytest.mark.parametrize("reaction_minutes, acts", [(5.0, True), (10.0, True), (15.0, False), (None, True)])
def test_the_reaction_time_decides_on_which_branch_a_curative_ct_bid_acts(reaction_minutes, acts):
    model = _cur_build(_cur_inputs(reaction=reaction_minutes), _cur_nx(tatl_duration_s=600))
    assert _acts_in(model, "B1", "CO1", "BID_A_DOWN") is acts


def test_a_branch_without_tatl_data_uses_the_fallback_duration_for_countertrade_too():
    assert _acts_in(_cur_build(_cur_inputs(reaction=5.0)), "B1", "CO1", "BID_A_DOWN")
    assert not _acts_in(_cur_build(_cur_inputs(reaction=15.0)), "B1", "CO1", "BID_A_DOWN")


def test_the_curative_cost_uses_the_cra_reference_and_the_reservation_price():
    model = _solve(_cur_build(_cur_inputs(reserve=4.0)))
    volume = 100.0 / RELIEF_PER_MW
    terms = _named(model)
    assert terms["ct_cra_penalty_cost"] == pytest.approx(1.0 * 50.0 * 2 * volume, rel=1e-6)      # CRA reference 50, not PRA 100
    assert terms["ct_cra_reservation_cost"] == pytest.approx(4.0 * 2 * volume, rel=1e-6)
    assert pyo.value(model.objective) == pytest.approx(sum(terms.values()), rel=1e-9)


def test_without_a_reserve_price_the_energy_price_is_the_reservation_price():
    model = _solve(_cur_build(_cur_inputs(reserve=None)))
    volume = 100.0 / RELIEF_PER_MW
    assert _named(model)["ct_cra_reservation_cost"] == pytest.approx((8.0 + 20.0) * volume, rel=1e-6)


def test_the_curative_maximum_is_charged_once_over_the_contingencies():
    model = _solve(_cur_build(_cur_inputs(links=())))
    volume = 100.0 / RELIEF_PER_MW
    assert _named(model)["ct_cra_penalty_cost"] == pytest.approx(1.0 * 50.0 * 2 * volume, rel=1e-6)   # CO1 only, not CO1 + CO2


def test_the_curative_rd_result_rows_leave_the_countertrade_bids_out():
    rd_inputs = _cur_inputs()
    model = _solve(_cur_build(rd_inputs))
    assert model.ct_curative_bid_ids == frozenset({"BID_A_DOWN", "BID_B_UP"})
    assert n0_results_export.extract_curative_rd_results(model, rd_inputs.rd_list, rd_inputs.bid_list, 5.0) == []


def test_curative_rd_and_ct_share_one_curative_total_per_unit():
    rd_units = _cur_units("RD_C", ["A1"], ("CO1",), None, 0.0, ct=False)
    rd_inputs = _cur_inputs(
        extra_units=rd_units, extra_bids=[_cur_bid("BID_RD_C", "RD_C", DOWN, 8.0)], glsk={"RD_C": {"A1": 1.0}},
        generators=_generators(A1={"target_p": 60.0, "min_p": 50.0}),
    )
    model = _cur_build(rd_inputs)
    model.curative_rd_volume_downward["BID_RD_C", "CO1"].fix(8.0)
    _solve(model)
    names = {v.name for v in identify_variables(model.curative_pmax_pmin_constraint["A1"].body)}
    assert {"max_curative_rd_volume_downward[BID_RD_C]", "max_curative_rd_volume_downward[BID_A_DOWN]"} <= names
    assert pyo.value(model.curative_rd_volume_downward["BID_A_DOWN", "CO1"]) == pytest.approx(2.0 / 0.8, abs=1e-6)


def test_a_curative_ct_bid_cannot_use_a_unit_that_the_preventive_rd_shuts_down():
    rd_units = _units("RD_A2", ["A2"], False, 0.0) + _units("RD_B1", ["B1"], False, 0.0)   # shut A2 down, B1 balances
    rd_inputs = _cur_inputs(
        extra_units=rd_units, extra_bids=[_bid("BID_RD_A2", "RD_A2", DOWN, 50.0), _bid("BID_RD_B1", "RD_B1", UP, 50.0)],
        glsk={"RD_A2": {"A2": 1.0}, "RD_B1": {"B1": 1.0}},
        generators=_generators(A2={"target_p": 50.0, "min_p": 20.0}), unit_costs={"A2": UnitCost(shutdown_cost_eur=10.0)},
    )
    model = _cur_build(rd_inputs)
    assert "A2" in set(model.curative_on_off_unit_ids)
    model.rd_unit_on["A2"].fix(0)
    _solve(model)
    assert pyo.value(model.curative_rd_volume_downward["BID_A_DOWN", "CO1"]) == pytest.approx(0.0, abs=1e-9)
    assert pyo.value(model.max_curative_rd_volume_downward["BID_A_DOWN"]) == pytest.approx(0.0, abs=1e-9)
