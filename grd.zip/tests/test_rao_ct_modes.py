"""
test_rao_ct_modes.py — countertrade in the three calculation modes and together with the other RA types
(docs/countertrade_ra_specs.md C3.5, C8): run_pipeline.main() on the generated mock (tests/ct_mock.py).
ac_iterative: sensitivities refreshed every iteration, the weights fixed; ac_single_pass: one pass; dc: DC
sensitivities, one pass. The set points travel in the same dictionary as the RD ones (apply, restore).
"""
import csv
from types import SimpleNamespace

import pyomo.environ as pyo
import pytest
from pyomo.core.expr.visitor import identify_variables

import ct_mock
import hvdc_mock
from helpers import run_pipeline_on_fixture_inputs

BELGOVIA_BO4 = ct_mock.BRANCH_GA_BO4_BELGOVIA
ORIGINAL_P = {
    ct_mock.BO_G1: 52.8181, ct_mock.BO_G2: 78.9071, ct_mock.GA_G1: 705.637, ct_mock.GA_G2: 180.0, ct_mock.GA_G3: 180.0,
}
DC_PATL_A = 70.0       # the DC model loads the Belgovia half of TieLine_GA_BO4 with 84.8 A (the AC model with 124.1 A)
# the RD-only ac_single_pass run on the same mock and PATL ends 1.42 A above the PATL (measured 20 Oct 2026: one
# linearised pass, the load flow is not linear); countertrade must not leave more than that plus a small margin
RD_ONLY_SINGLE_PASS_RESIDUAL_A = 1.42
SINGLE_PASS_MARGIN_A = 0.1
# curative runs: the outage of TieLine_GA_BO5 raises the Belgovia half of GA_BO4 to 225.4 A (AC) and 158.8 A (DC);
# the PATL is above the N-0 current and below the N-1 current in each kind of calculation
CURATIVE_PATL_BY_MODE = {"ac_iterative": ct_mock.CURATIVE_PATL_A, "dc": 140.0}


def _read_csv(path):
    with open(path, encoding="utf-8", newline="") as f:
        return list(csv.DictReader(f))


def _summary(output_dir):
    return {row["metric"]: row["value"] for row in _read_csv(output_dir / "results_summary.csv")}


def _run(tmp_path, mode, ra_types=("countertrade",), patl_a=ct_mock.DEFAULT_PATL_A, nx=False, source_zip=None, ncp_zip=None,
         extra_hooks=None, **mock_kwargs):
    """One run with the models (and the RD inputs each was built from), the set points handed to the network and the
    CT inputs of every build recorded. ncp_zip: a ready NCP zip instead of the countertrade mock; extra_hooks:
    called with (run_pipeline module, monkeypatch) after the recording hooks."""
    tmp_path.mkdir(parents=True, exist_ok=True)
    kwargs = {"source_zip": source_zip} if source_zip is not None else {}
    ncp = ncp_zip or ct_mock.build_ct_mock_ncp(tmp_path / "ncp.zip", patl_a=patl_a, **kwargs, **mock_kwargs)
    record = SimpleNamespace(models=[], rd_inputs=[], applied=[], ct_inputs=[])

    def hooks(rp, monkeypatch):
        loop = rp.ac_convergence_loop
        build, apply, build_at_state = loop.build_n0_milp_model, loop.apply_preventive_solution_to_network, loop.build_model_at_state

        def keeping_build(*args, **kw):
            model = build(*args, **kw)
            record.models.append(model)
            record.rd_inputs.append(kw.get("rd_inputs"))
            return model

        def recording_apply(network, pst_tap_solution, rd_target_p_solution):
            record.applied.append(dict(rd_target_p_solution))
            return apply(network, pst_tap_solution=pst_tap_solution, rd_target_p_solution=rd_target_p_solution)

        def recording_build_at_state(*args, **kw):
            record.ct_inputs.append(kw.get("ct_inputs"))
            return build_at_state(*args, **kw)

        monkeypatch.setattr(loop, "build_n0_milp_model", keeping_build)
        monkeypatch.setattr(loop, "apply_preventive_solution_to_network", recording_apply)
        monkeypatch.setattr(loop, "build_model_at_state", recording_build_at_state)
        # single_pass and dc_pass call build_model_at_state through their own import
        for module in (rp.single_pass, rp.dc_pass):
            monkeypatch.setattr(module, "build_model_at_state", recording_build_at_state)
        if extra_hooks is not None:
            extra_hooks(rp, monkeypatch)

    run = run_pipeline_on_fixture_inputs(
        tmp_path / "run", ncp, enable_nx_analysis=nx, ra_types=ra_types, calculation_mode=mode, customize_pipeline=hooks,
    )
    record.output_dir = run.output_dir
    return record


def _final_changes(record):
    """{unit: final target_p - original} of the last solution handed to the network."""
    last = record.applied[-1]
    return {gu: last[gu] - ORIGINAL_P[gu] for gu in ORIGINAL_P if gu in last}


@pytest.fixture(scope="module", params=["ac_iterative", "ac_single_pass", "dc"])
def mode_run(request, tmp_path_factory):
    patl = DC_PATL_A if request.param == "dc" else ct_mock.DEFAULT_PATL_A
    result = _run(tmp_path_factory.mktemp(request.param), request.param, patl_a=patl)
    result.mode = request.param
    return result


def test_each_mode_relieves_the_branch_with_belgovia_down_and_galia_up(mode_run):
    change = _final_changes(mode_run)
    belgovia = change[ct_mock.BO_G1] + change[ct_mock.BO_G2]
    galia = change[ct_mock.GA_G1] + change[ct_mock.GA_G2] + change[ct_mock.GA_G3]
    assert belgovia < -20.0 and galia > 20.0 and belgovia + galia == pytest.approx(0.0, abs=1e-6)
    # the remaining-capacity weights act on the units: the down weights in Belgovia, the up weights in Galia
    assert change[ct_mock.BO_G1] / belgovia == pytest.approx(ct_mock.EXPECTED_WEIGHTS[("Belgovia", "down")][ct_mock.BO_G1], abs=1e-6)
    assert change[ct_mock.GA_G1] / galia == pytest.approx(ct_mock.EXPECTED_WEIGHTS[("Galia", "up")][ct_mock.GA_G1], abs=1e-6)


def test_the_ac_check_after_each_mode(mode_run):
    row = [r for r in _read_csv(mode_run.output_dir / "lf_post_n0.csv") if r["branch_mrid"] == BELGOVIA_BO4][-1]    # the last iteration
    before, after = float(row["i_ka_before"]), float(row["i_ka_after"])
    assert row["solution_applied_to_network"] == "true"
    model = mode_run.models[-1]
    if mode_run.mode == "ac_iterative":
        # the loop converges onto the PATL (0.01 % for the load flow tolerance)
        assert after <= ct_mock.DEFAULT_PATL_A / 1000.0 * 1.0001
        assert _summary(mode_run.output_dir)["ac_verification_status"] == "CONVERGED"
    elif mode_run.mode == "ac_single_pass":
        # one linearised pass: the AC check may stay above the PATL by the same residual as RD in a single pass
        assert after <= (ct_mock.DEFAULT_PATL_A + RD_ONLY_SINGLE_PASS_RESIDUAL_A + SINGLE_PASS_MARGIN_A) / 1000.0
        assert after < before
    else:
        # dc: the DC model relieves the DC current (exact for the DC load flow, which is linear) to the DC PATL ...
        assert pyo.value(model.overload_slack_n0[BELGOVIA_BO4]) == pytest.approx(0.0, abs=1e-9)
        assert pyo.value(model.xne_loading_n0[BELGOVIA_BO4].body) <= DC_PATL_A + 1e-6
        assert before * 1000.0 > DC_PATL_A                                   # the DC current before: an overload
        # ... and the AC check of the applied state is below the original AC current (reported only, D-specs)
        assert after < ct_mock.INITIAL_CURRENT_A / 1000.0


def test_the_objective_is_the_sum_of_the_terms_in_each_mode(mode_run):
    summary = _summary(mode_run.output_dir)
    assert float(summary["objective_residual_eur"]) == pytest.approx(0.0, abs=1e-6)
    assert summary["calculation_mode"] == mode_run.mode and summary["ra_types"] == "countertrade"
    model = mode_run.models[-1]
    terms = {name: pyo.value(expression) for name, expression in model.objective_penalty_term_expressions.items()}
    assert pyo.value(model.objective) == pytest.approx(sum(terms.values()), rel=1e-9)


def test_in_ac_iterative_the_weights_are_the_same_in_every_iteration(mode_run):
    if mode_run.mode != "ac_iterative":
        pytest.skip("iterations exist in ac_iterative only")
    assert len(mode_run.models) >= 3 and len(mode_run.ct_inputs) == len(mode_run.models)
    first = mode_run.ct_inputs[0]
    assert all(inputs is first for inputs in mode_run.ct_inputs)            # passed unchanged, never recomputed
    expected = {}
    for (zone, direction), weights in ct_mock.EXPECTED_WEIGHTS.items():
        bid = ct_mock._uid("bid", "BO" if zone == "Belgovia" else "GA", f"{'BO' if zone == 'Belgovia' else 'GA'}-{direction}")
        expected[bid] = weights
    for bid, weights in expected.items():
        assert first.bid_participation[bid] == pytest.approx(weights, abs=1e-6)
    # and the net injection of every build follows them: units move in proportion to the same weights
    for model in mode_run.models:
        bo_down = ct_mock._uid("bid", "BO", "BO-down")
        volume = pyo.value(model.rd_volume_downward[bo_down])
        if volume > 1e-6:
            assert pyo.value(model.rd_net_injection_g[ct_mock.BO_G1]) == pytest.approx(
                -volume * ct_mock.EXPECTED_WEIGHTS[("Belgovia", "down")][ct_mock.BO_G1], abs=1e-6)


def test_the_dc_mode_uses_dc_sensitivities_and_one_pass(mode_run):
    if mode_run.mode != "dc":
        pytest.skip("dc only")
    assert len(mode_run.models) == 1 and _summary(mode_run.output_dir)["calculation_mode"] == "dc"


def test_a_dc_run_without_a_dc_overload_leaves_the_set_points_unchanged(tmp_path):
    result = _run(tmp_path, "dc", patl_a=None)
    assert all(abs(solution.get(gu, ORIGINAL_P[gu]) - ORIGINAL_P[gu]) < 1e-9 for solution in result.applied for gu in ORIGINAL_P)
    model = result.models[-1]
    assert sum(abs(pyo.value(model.rd_net_injection_g[gu])) for gu in model.gu_ids) == pytest.approx(0.0, abs=1e-9)


# ---------------------------------------------------------------------------
# write-back: apply and restore through the RD dictionary
# ---------------------------------------------------------------------------

def test_the_ct_set_points_are_applied_and_restored_like_the_rd_ones():
    from pre_milp import cgmes_loader
    from milp.post_ra_congestion_check import apply_preventive_solution_to_network, restore_network_state
    from helpers import FIXTURE_CGM_ZIP

    network = cgmes_loader.load_cgm(FIXTURE_CGM_ZIP)
    solution = {ct_mock.BO_G1: ORIGINAL_P[ct_mock.BO_G1] - 20.0, ct_mock.GA_G1: ORIGINAL_P[ct_mock.GA_G1] + 20.0}
    _, previous = apply_preventive_solution_to_network(network, pst_tap_solution={}, rd_target_p_solution=solution)
    generators = network.get_generators()
    assert generators.loc[ct_mock.BO_G1, "target_p"] == pytest.approx(solution[ct_mock.BO_G1])
    assert generators.loc[ct_mock.GA_G1, "target_p"] == pytest.approx(solution[ct_mock.GA_G1])
    restore_network_state(network, previous_taps={}, previous_target_p=previous)
    generators = network.get_generators()
    assert generators.loc[ct_mock.BO_G1, "target_p"] == pytest.approx(ORIGINAL_P[ct_mock.BO_G1], abs=1e-4)
    assert generators.loc[ct_mock.GA_G1, "target_p"] == pytest.approx(ORIGINAL_P[ct_mock.GA_G1], abs=1e-4)


# ---------------------------------------------------------------------------
# coexistence with the other RA types
# ---------------------------------------------------------------------------

def test_pst_rd_hvdc_and_countertrade_run_together(tmp_path):
    hvdc_zip = hvdc_mock.build_hvdc_mock_ncp(tmp_path / "hvdc.zip")
    result = _run(tmp_path / "all", "ac_single_pass", ra_types=("pst", "rd", "hvdc", "countertrade"), source_zip=hvdc_zip)
    summary = _summary(result.output_dir)
    assert summary["ra_types"] == "pst+rd+hvdc+countertrade"
    names = {p.name for p in result.output_dir.glob("*")}
    assert {"results_pst.csv", "results_preventive_rd.csv", "results_hvdc.csv"} <= names
    model = result.models[-1]
    # every block is in the one model: PST taps, RD and CT bids on the same variables, the HVDC set points
    assert hasattr(model, "tap_change_upward") and hasattr(model, "hvdc_change")
    rd_bids = [b for b in model.bid_ids if b not in model.ct_bid_ids]
    assert rd_bids and len(model.ct_bid_ids) == 4
    assert float(summary["objective_residual_eur"]) == pytest.approx(0.0, abs=1e-6)
    # the HVDC and countertrade terms are wired into the one objective, and the HVDC row is the model's HVDC terms (here
    # PST and RD relieve the branch, so both are 0; their values are checked where they act)
    terms = {name: pyo.value(expression) for name, expression in model.objective_penalty_term_expressions.items()}
    assert {"hvdc_pra_penalty_cost", "ct_pra_penalty_cost", "ct_pra_energy_cost"} <= set(terms)
    hvdc = sum(value for name, value in terms.items() if name.startswith("hvdc_"))
    assert float(summary["sum_hvdc_penalty_cost_eur"]) == pytest.approx(hvdc, rel=1e-9, abs=1e-9)


@pytest.fixture(scope="module")
def ct_and_hvdc(tmp_path_factory):
    """pst+rd+hvdc+countertrade in ac_iterative on the mock where countertrade and HVDC both act
    (ct_mock.build_ct_and_hvdc_mock_ncp)."""
    work = tmp_path_factory.mktemp("ct_and_hvdc")
    ncp = ct_mock.build_ct_and_hvdc_mock_ncp(work / "ncp.zip")
    return _run(work, "ac_iterative", ra_types=("pst", "rd", "hvdc", "countertrade"), ncp_zip=ncp)


def test_countertrade_and_hvdc_both_act_in_the_same_solve(ct_and_hvdc):
    # the final solve holds both (cumulative against the original network): an HVDC change and countertrade volume
    last = ct_and_hvdc.models[-1]
    assert pyo.value(last.objective_penalty_term_expressions["hvdc_pra_penalty_cost"]) > 0.0
    assert pyo.value(last.rd_cumulative_volume_term[ct_mock._uid("bid", "BO", "BO-down")]) > 1.0
    hvdc_rows = _read_csv(ct_and_hvdc.output_dir / "results_hvdc.csv")
    ct_rows = _read_csv(ct_and_hvdc.output_dir / "results_countertrade.csv")
    assert all(abs(float(r["change_mw"])) > 0.1 for r in hvdc_rows) and len(hvdc_rows) == 2
    assert sum(float(r["volume_mw"]) for r in ct_rows) > 2.0


def test_the_hvdc_pair_is_balanced_on_its_own_and_rd_plus_ct_balance(ct_and_hvdc):
    hvdc_rows = _read_csv(ct_and_hvdc.output_dir / "results_hvdc.csv")
    assert sum(float(r["change_mw"]) for r in hvdc_rows) == pytest.approx(0.0, abs=1e-6)                 # dg1 + dg2 = 0
    for model in ct_and_hvdc.models:
        assert sum(pyo.value(model.hvdc_change[u]) for u in model.hvdc_unit_ids) == pytest.approx(0.0, abs=1e-6)
        # the global balance holds the RD and CT injections of the units, no HVDC variable
        names = {v.name for v in identify_variables(model.rd_balancing_n0.body)}
        assert names and not any(name.startswith("hvdc") for name in names)
        assert any(name.startswith("rd_volume_") and ct_mock._uid("bid", "BO", "BO-down") in name for name in names)
        assert sum(pyo.value(model.rd_net_injection_g[gu]) for gu in model.gu_ids) == pytest.approx(0.0, abs=1e-6)
        assert not {r["ei_mrid"] for r in hvdc_rows} & set(model.gu_ids)


def test_the_hvdc_and_ct_costs_are_separate_terms_and_the_rows_match_the_files(ct_and_hvdc):
    model = ct_and_hvdc.models[-1]
    terms = {name: pyo.value(expression) for name, expression in model.objective_penalty_term_expressions.items()}
    assert terms["hvdc_pra_penalty_cost"] > 0.0 and terms["ct_pra_penalty_cost"] > 0.0 and terms["ct_pra_energy_cost"] > 0.0
    summary = _summary(ct_and_hvdc.output_dir)
    # the objective is the named terms (HVDC, countertrade, overloads, ...) plus the PST and RD bid costs
    unnamed = float(summary["sum_pst_penalty_cost_eur"]) + float(summary["sum_rd_cost_eur"])
    assert pyo.value(model.objective) == pytest.approx(sum(terms.values()) + unnamed, rel=1e-9)
    assert float(summary["objective_residual_eur"]) == pytest.approx(0.0, abs=1e-6)
    hvdc_rows = _read_csv(ct_and_hvdc.output_dir / "results_hvdc.csv")
    ct_rows = _read_csv(ct_and_hvdc.output_dir / "results_countertrade.csv")
    assert float(summary["sum_hvdc_penalty_cost_eur"]) == pytest.approx(sum(float(r["penalty_cost_eur"]) for r in hvdc_rows), rel=1e-9)
    assert float(summary["sum_hvdc_penalty_cost_eur"]) == pytest.approx(terms["hvdc_pra_penalty_cost"], rel=1e-9)
    ct_cost = sum(float(r["price_cost_eur"]) + float(r["penalty_cost_eur"]) + float(r["activation_cost_eur"]) for r in ct_rows)
    assert float(summary["sum_ct_cost_eur"]) == pytest.approx(ct_cost, rel=1e-9)
    assert float(summary["sum_pra_penalty_cost_ct_eur"]) == pytest.approx(sum(float(r["penalty_cost_eur"]) for r in ct_rows), rel=1e-9)
    for direction in ("up", "down"):
        assert float(summary[f"sum_ct_volume_{direction}ward_mw"]) == pytest.approx(
            sum(float(r["volume_mw"]) for r in ct_rows if r["direction"] == direction), rel=1e-9)


def test_both_branches_are_below_their_patl_after_the_ac_check(ct_and_hvdc):
    import run_pipeline
    assert _summary(ct_and_hvdc.output_dir)["ac_verification_status"] == "CONVERGED"
    rows = _read_csv(ct_and_hvdc.output_dir / "lf_post_n0.csv")
    # the loop stops when the AC overload changes by less than max_change_overload (criterion 3): a converged state may
    # keep a remaining AC overload below that value
    tolerance_a = float(run_pipeline.MAX_CHANGE_OVERLOAD)
    for branch, patl in ((BELGOVIA_BO4, ct_mock.CT_HVDC_PATL_A), (hvdc_mock.XNE_BRANCH, ct_mock.CT_HVDC_HVDC_PATL_A)):
        last = [r for r in rows if r["branch_mrid"] == branch][-1]
        assert float(last["i_ka_after"]) * 1000.0 <= patl + tolerance_a


def test_countertrade_with_hvdc_only(tmp_path):
    hvdc_zip = hvdc_mock.build_hvdc_mock_ncp(tmp_path / "hvdc.zip")
    result = _run(tmp_path / "run", "ac_iterative", ra_types=("hvdc", "countertrade"), source_zip=hvdc_zip)
    summary = _summary(result.output_dir)
    assert summary["ra_types"] == "hvdc+countertrade"
    assert "results_hvdc.csv" in {p.name for p in result.output_dir.glob("*")}
    # the countertrade summary row is the sum of every countertrade term of the model (countertrade acts here)
    terms = {name: pyo.value(expression) for name, expression in result.models[-1].objective_penalty_term_expressions.items()}
    ct = sum(value for name, value in terms.items() if name.startswith("ct_"))
    assert ct > 0.0 and terms["ct_bid_activation_cost"] > 0.0
    assert float(summary["sum_ct_cost_eur"]) == pytest.approx(ct, rel=1e-9)
    assert float(summary["objective_residual_eur"]) == pytest.approx(0.0, abs=1e-6)


# ---------------------------------------------------------------------------
# convergence criteria and the iteration log count the countertrade MW
# ---------------------------------------------------------------------------

def test_the_criteria_count_the_countertrade_megawatts(mode_run):
    if mode_run.mode != "ac_iterative":
        pytest.skip("iterations exist in ac_iterative only")
    rows = _read_csv(mode_run.output_dir / "results_iteration_history.csv")
    first = float(rows[0]["sum_abs_rd_change_mw"])
    volume = pyo.value(mode_run.models[0].rd_volume_downward[ct_mock._uid("bid", "BO", "BO-down")])
    assert first == pytest.approx(2.0 * volume, rel=1e-6) and float(rows[0]["max_abs_rd_change_mw"]) > 0.0
    assert rows[0]["criterion_1_met"] == "False"                     # 142.9 MW moved is above the threshold
    assert rows[-1]["criterion_1_met"] == "True" and rows[-1]["criterion_3_met"] == "True" and rows[-1]["converged"] == "True"


def test_the_iteration_log_line_shows_the_countertrade_volume(tmp_path, caplog):
    import logging
    with caplog.at_level(logging.INFO):
        _run(tmp_path, "ac_iterative")
    lines = [r.getMessage() for r in caplog.records if "] Iteration" in r.getMessage()]
    assert len(lines) >= 3 and all("countertrade:" in line and "MW up" in line and "MW down" in line for line in lines)
    assert "countertrade: 71." in lines[0]


def test_the_iteration_log_line_has_no_countertrade_text_without_countertrade(tmp_path, caplog):
    import logging
    with caplog.at_level(logging.INFO):
        run_pipeline_on_fixture_inputs(
            tmp_path, ct_mock.build_ct_mock_ncp(tmp_path / "ncp.zip", ras=[], patl_a=None), enable_nx_analysis=False,
            ra_types=("rd",), calculation_mode="ac_iterative",
        )
    lines = [r.getMessage() for r in caplog.records if "] Iteration" in r.getMessage()]
    assert lines and not any("countertrade" in line for line in lines)


# ---------------------------------------------------------------------------
# rd + countertrade in ac_iterative: RD moves a unit of a countertrade zone (GA-G1) between the builds
# ---------------------------------------------------------------------------

@pytest.fixture(scope="module")
def rd_and_ct_iterative(tmp_path_factory):
    """Countertrade bids of 20 MW only, so RD gives the rest of the relief; RD moves GA-G1 up, a unit of the Galia
    countertrade RA, so the set points of Galia change unevenly between the builds."""
    return _run(tmp_path_factory.mktemp("rd_ct_iterative"), "ac_iterative", ra_types=("rd", "countertrade"),
                ras=ct_mock.default_ras(volume=20.0))


def _rd_part_by_unit(output_dir):
    """{unit: RD movement (MW)} from results_preventive_rd.csv and glsk_resolved.csv: glsk factor x the net volume of every
    RD bid against the original network."""
    glsk = {}
    for row in _read_csv(output_dir / "glsk_resolved.csv"):
        glsk.setdefault(row["ra_mrid"], {})[row["gu_mrid"]] = float(row["participation_factor"])
    part = {}
    for row in _read_csv(output_dir / "results_preventive_rd.csv"):
        for gu, factor in glsk.get(row["ra_mrid"], {}).items():
            part[gu] = part.get(gu, 0.0) + factor * float(row["rd_volume_net_mw"])
    return part


def _ct_part_by_unit(output_dir):
    """{unit: countertrade movement (MW)} from results_countertrade.csv and countertrade_glsk_resolved.csv: the weight of
    the bid's RA and direction x the bid volume (up +, down -)."""
    weights = {}
    for row in _read_csv(output_dir / "countertrade_glsk_resolved.csv"):
        if row["gu_mrid"]:
            weights.setdefault((row["ra_mrid"], row["direction"]), {})[row["gu_mrid"]] = float(row["participation_factor"])
    part = {}
    for row in _read_csv(output_dir / "results_countertrade.csv"):
        signed = float(row["volume_mw"]) * (1.0 if row["direction"] == "up" else -1.0)
        for gu, factor in weights.get((row["ra_mrid"], row["direction"]), {}).items():
            part[gu] = part.get(gu, 0.0) + factor * signed
    return part


def _check_unit_file(output_dir, final_set_points):
    """results_generating_units.csv of a run with countertrade: RD column = RD part, CT column = CT part, production =
    initial + RD + CT = the set point handed to the network last. Returns (RD part, CT part)."""
    rd_part, ct_part = _rd_part_by_unit(output_dir), _ct_part_by_unit(output_dir)
    rows = {r["gu_mrid"]: r for r in _read_csv(output_dir / "results_generating_units.csv")}
    header = list(next(iter(rows.values())))
    assert header.index("ct_volume_net_mw") == header.index("rd_penalty_cost_eur") + 1      # right after the RD columns
    for gu, row in rows.items():
        assert float(row["rd_volume_net_mw"]) == pytest.approx(rd_part.get(gu, 0.0), abs=1e-6), gu
        assert float(row["ct_volume_net_mw"]) == pytest.approx(ct_part.get(gu, 0.0), abs=1e-6), gu
        production = float(row["initial_production_mw"]) + rd_part.get(gu, 0.0) + ct_part.get(gu, 0.0)
        assert float(row["result_production_mw"]) == pytest.approx(production, abs=1e-6), gu
        assert float(row["result_production_mw"]) == pytest.approx(final_set_points.get(gu, production), abs=1e-6), gu
    return rd_part, ct_part


def test_the_unit_file_splits_rd_and_ct_and_shows_the_final_dispatch_in_ac_iterative(rd_and_ct_iterative):
    assert len(rd_and_ct_iterative.models) >= 2
    rd_part, ct_part = _check_unit_file(rd_and_ct_iterative.output_dir, rd_and_ct_iterative.applied[-1])
    assert rd_part[ct_mock.GA_G1] > 1.0 and ct_part[ct_mock.GA_G1] > 1.0      # GA-G1: moved by RD and by countertrade
    assert rd_part.get(ct_mock.BO_G1, 0.0) == 0.0 and ct_part[ct_mock.BO_G1] < -1.0      # BO-G1: countertrade only


CT_ONLY_UNITS = (ct_mock.GA_G2, ct_mock.GA_G3)


@pytest.fixture(scope="module")
def ct_only_units_iterative(tmp_path_factory):
    """rd+countertrade in ac_iterative where GA-G2 and GA-G3 have no RD: they are left out of every RD glsk (an RD
    RA left without a unit acts on nothing), so they are countertrade-only units of the Galia RA."""
    def without_rd_on_ga_g2_g3(rp, monkeypatch):
        resolve = rp.glsk_resolver.resolve_glsk

        def filtered(*args, **kwargs):
            result = {}
            for ra, participation in resolve(*args, **kwargs).items():
                kept = {gu: factor for gu, factor in participation.items() if gu not in CT_ONLY_UNITS}
                if kept:
                    result[ra] = kept
            return result

        monkeypatch.setattr(rp.glsk_resolver, "resolve_glsk", filtered)

    return _run(tmp_path_factory.mktemp("ct_only_units"), "ac_iterative", ra_types=("rd", "countertrade"),
                ras=ct_mock.default_ras(volume=20.0), extra_hooks=without_rd_on_ga_g2_g3)


def test_ct_only_units_are_listed_after_the_rd_units_with_their_countertrade_movement(ct_only_units_iterative):
    output = ct_only_units_iterative.output_dir
    rows = _read_csv(output / "results_generating_units.csv")
    order = [r["gu_mrid"] for r in rows]
    rd_units = {r["gu_mrid"] for r in _read_csv(output / "glsk_resolved.csv")}
    assert not set(CT_ONLY_UNITS) & rd_units and set(CT_ONLY_UNITS) <= set(order)
    # the RD units first, then the countertrade-only units, each sorted like the existing rows
    assert order == sorted(u for u in order if u in rd_units) + sorted(u for u in order if u not in rd_units)
    _, ct_part = _check_unit_file(output, ct_only_units_iterative.applied[-1])       # production = initial + RD + CT
    by_unit = {r["gu_mrid"]: r for r in rows}
    for gu in CT_ONLY_UNITS:
        row = by_unit[gu]
        assert ct_part[gu] > 0.1 and float(row["ct_volume_net_mw"]) == pytest.approx(ct_part[gu], abs=1e-6)
        assert float(row["rd_volume_net_mw"]) == 0.0 and float(row["rd_cost_eur"]) == 0.0 and float(row["rd_penalty_cost_eur"]) == 0.0
        assert float(row["result_production_mw"]) == pytest.approx(ORIGINAL_P[gu] + ct_part[gu], abs=1e-6)
        assert float(row["initial_production_mw"]) == pytest.approx(ORIGINAL_P[gu], abs=1e-4) and row["tso"] == "TSO-Galia"


def test_the_ct_column_sums_to_the_net_ct_volume_of_each_zone(ct_only_units_iterative):
    output = ct_only_units_iterative.output_dir
    zone_of_unit = {r["gu_mrid"]: r["zone_mrid"] for r in _read_csv(output / "countertrade_glsk_resolved.csv") if r["gu_mrid"]}
    net_by_zone = {}
    for row in _read_csv(output / "results_countertrade.csv"):
        signed = float(row["volume_mw"]) * (1.0 if row["direction"] == "up" else -1.0)
        net_by_zone[row["zone_mrid"]] = net_by_zone.get(row["zone_mrid"], 0.0) + signed
    rows = _read_csv(output / "results_generating_units.csv")
    by_zone = {}
    for row in rows:
        zone = zone_of_unit.get(row["gu_mrid"])
        if zone is not None:
            by_zone[zone] = by_zone.get(zone, 0.0) + float(row["ct_volume_net_mw"])
    assert net_by_zone[ct_mock.ZONE_GALIA] > 1.0 and net_by_zone[ct_mock.ZONE_BELGOVIA] < -1.0
    assert by_zone == pytest.approx(net_by_zone, abs=1e-6)                    # every unit of the zones is in the file
    assert sum(float(r["ct_volume_net_mw"]) for r in rows) == pytest.approx(sum(net_by_zone.values()), abs=1e-6)


def test_the_weights_of_every_build_are_the_original_ones_although_rd_moves_a_shared_unit(rd_and_ct_iterative):
    galia_up = ct_mock._uid("bid", "GA", "GA-up")
    expected = ct_mock.EXPECTED_WEIGHTS[("Galia", "up")]
    largest_difference = 0.0
    for rd_inputs in rd_and_ct_iterative.rd_inputs:
        assert rd_inputs.bid_participation[galia_up] == pytest.approx(expected, abs=1e-12)
        # what a recomputation from the set points of this build would give (remaining capacity up)
        room = {gu: rd_inputs.generator_data[gu]["max_p"] - rd_inputs.generator_data[gu]["target_p"] for gu in expected}
        recomputed = {gu: value / sum(room.values()) for gu, value in room.items()}
        largest_difference = max(largest_difference, max(abs(recomputed[gu] - expected[gu]) for gu in expected))
    # the scenario tells fixed from recomputed weights: a later build's set points give other weights
    assert largest_difference > 1e-2


# ---------------------------------------------------------------------------
# curative countertrade in ac_iterative and dc (ac_single_pass: test_rao_ct_pipeline.py)
# ---------------------------------------------------------------------------

@pytest.fixture(scope="module", params=["ac_iterative", "dc"])
def curative_mode_run(request, tmp_path_factory):
    result = _run(
        tmp_path_factory.mktemp(f"cur_{request.param}"), request.param, nx=True, patl_a=CURATIVE_PATL_BY_MODE[request.param],
        ras=ct_mock.curative_ras(), contingencies=[ct_mock.ga_bo5_outage()],
    )
    result.mode = request.param
    return result


def test_curative_countertrade_relieves_the_contingency_in_each_mode(curative_mode_run):
    model = curative_mode_run.models[-1]
    co = ct_mock.CONTINGENCY_GA_BO5
    down = pyo.value(model.curative_rd_volume_downward[ct_mock._uid("bid", "BO-cur", "BO-cur-down"), co])
    up = pyo.value(model.curative_rd_volume_upward[ct_mock._uid("bid", "GA-cur", "GA-cur-up"), co])
    assert down > 1.0 and up == pytest.approx(down, rel=1e-6)
    assert pyo.value(model.nx_patl_overload_slack[BELGOVIA_BO4, co]) == pytest.approx(0.0, abs=1e-6)
    assert pyo.value(model.nx_patl_loading[BELGOVIA_BO4, co].body) <= CURATIVE_PATL_BY_MODE[curative_mode_run.mode] + 1e-6
    for contingency in set(model.curative_rd_contingency_ids):
        total = sum(pyo.value(model.curative_rd_net_injection_g[gu, c]) for gu, c in model.curative_gu_contingency_pairs if c == contingency)
        assert total == pytest.approx(0.0, abs=1e-6)
    assert float(_summary(curative_mode_run.output_dir)["objective_residual_eur"]) == pytest.approx(0.0, abs=1e-6)
    assert len(_read_csv(curative_mode_run.output_dir / "results_curative_countertrade.csv")) == 4


def test_curative_countertrade_is_not_applied_to_the_network_in_each_mode(curative_mode_run):
    for solution in curative_mode_run.applied:
        assert all(abs(solution.get(gu, ORIGINAL_P[gu]) - ORIGINAL_P[gu]) < 1e-9 for gu in ORIGINAL_P)
    assert not hasattr(curative_mode_run.models[-1], "rd_net_injection_g")
