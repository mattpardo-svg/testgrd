"""
ncp_header.py - profile and creator of an NCP file, read from its header.

The header is the first md:FullModel or dcat:Dataset of the file. The profile is its dcat:keyword (AE, CO, RA, SIS, SHS,
SSI, IAM, PS, ER; CD for the organisation file, OR for its object registry), else the profile name in a
dcterms:conformsTo URL (".../<Profile>/<version>" or ".../<Profile>-EU/<version>"). The creator is the last path
segment of dcterms:creator (the EIC of the sending TSO). A file that is not XML or has no header gives None.
"""

from __future__ import annotations

import xml.etree.ElementTree as ET
from dataclasses import dataclass
from pathlib import Path
from typing import Optional

KEYWORD_PROFILES = ("AE", "CO", "RA", "SIS", "SHS", "SSI", "IAM", "PS", "ER")
_PROFILE_BY_NAME = {
    "AssessedElement": "AE",
    "Contingency": "CO",
    "RemedialAction": "RA",
    "StateInstructionSchedule": "SIS",
    "SteadyStateHypothesisSchedule": "SHS",
    "SteadyStateInstruction": "SSI",
    "ImpactAssessmentMatrix": "IAM",
    "PlannedSchedule": "PS",
    "EquipmentReliability": "ER",
    "ObjectRegistry": "OR",
}
_HEADER_TAGS = ("FullModel", "Dataset")
_DCAT_KEYWORD = "{http://www.w3.org/ns/dcat#}keyword"
_DCTERMS = "{http://purl.org/dc/terms/}"
_RDF_RESOURCE = "{http://www.w3.org/1999/02/22-rdf-syntax-ns#}resource"


@dataclass(frozen=True)
class NcpHeader:
    profile: Optional[str]          # keyword of the profile, "CD", "OR", or None when the header names none
    creator: Optional[str]          # last path segment of dcterms:creator, None when missing


def _profile_of_url(url: str) -> Optional[str]:
    parts = url.rstrip("#/").split("/")
    if len(parts) < 2:
        return None
    return _PROFILE_BY_NAME.get(parts[-2].removesuffix("-EU"))


def _profile(keywords: list[str], conforms_to: list[str]) -> Optional[str]:
    if "OR" in keywords:
        return "OR"
    for keyword in keywords:
        if keyword in KEYWORD_PROFILES:
            return keyword
    if "CD" in keywords:
        return "CD"
    for url in conforms_to:
        profile = _profile_of_url(url)
        if profile is not None:
            return profile
    return None


def read_header(path: Path) -> Optional[NcpHeader]:
    """The header of an NCP file (stops reading at the end of the header), None for a file without one."""
    keywords: list[str] = []
    conforms_to: list[str] = []
    creator: Optional[str] = None
    depth = 0
    in_header = False
    try:
        for event, element in ET.iterparse(str(path), events=("start", "end")):
            local = element.tag.rsplit("}", 1)[-1]
            if event == "start":
                depth += 1
                if depth == 2 and local in _HEADER_TAGS:
                    in_header = True
                continue
            depth -= 1
            if in_header and depth == 1:
                break
            if not in_header:
                if depth == 1:
                    return None           # the first object is not a header
                continue
            if element.tag == _DCAT_KEYWORD and (element.text or "").strip():
                keywords.append(element.text.strip())
            elif element.tag == f"{_DCTERMS}conformsTo":
                conforms_to.append(element.get(_RDF_RESOURCE, ""))
            elif element.tag == f"{_DCTERMS}creator":
                value = element.get(_RDF_RESOURCE) or (element.text or "")
                creator = value.rstrip("/").rsplit("/", 1)[-1].strip() or None
    except (ET.ParseError, OSError, UnicodeDecodeError):
        return None
    if not in_header:
        return None
    return NcpHeader(profile=_profile(keywords, conforms_to), creator=creator)
