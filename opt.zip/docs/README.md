# RAO prototype

Iterative MILP remedial action optimisation (security-constrained, N-0 and N-X) on CGMES data.
Stack: Python, pypowsybl (load flow, sensitivities, security analysis), Pyomo (`ConcreteModel`), HiGHS (`appsi_highs`).

## Scope
- Single timestamp: preventive PST, redispatch and HVDC set points (`ra_types: hvdc`, two EquivalentInjection units per link in a balanced group), N-X security constraints (secured and scanned elements), curative PST, redispatch and HVDC.
- Multi-timestamp work lives on a separate branch and is out of scope here.

## Flow
1. Load the grid model (CGMES), parse the NCP files (assessed elements, contingencies, remedial actions, bids).
2. Initial load flow and N-X security analysis; sensitivities (PST, redispatch, HVDC) for N-0 and N-X.
3. Build and solve the MILP; apply the result to the grid model; new load flow.
4. Convergence check; refresh baselines and sensitivities; repeat (inner loop).
5. Completeness check for newly congested pairs (outer loop).
6. Write results (CSV files, run log).

## Run and test (from the repo root)
- Run: `python src/rao/run_pipeline.py`. Modules import each other flat, so `python -m` does not apply.
- Input: real data goes into `input/` (one `cgm*.zip` and one `ncp*.zip`), placed by hand; prefix match, case-insensitive, exactly one of each. They are extracted to `input/_extracted_cgm` and `input/_extracted_ncp`. For a mock run copy `tests/fixtures/CGM_package.zip` and `NCP_generic.zip` into `input/`.
- Output: `output/` (CSV files and `run_log.txt`). Registered output files are deleted at the start of each run. Every result file carries the run status (`ac_verification_status`, including `SOLVER_NON_OPTIMAL`); the files only ever describe what was applied to the network (`docs/User_Guide.md`).
- Config: `src/rao/config/rao_config.yaml` and `load_flow_config.yaml`. The `*.default.yaml` files hold the documented defaults; a missing key raises `ConfigKeyError`. Performance keys (defaults keep the earlier behaviour): `performance.lf_thread_count` (OpenLoadFlow threads of the security and sensitivity analyses, 1), `performance.solver_time_limit_seconds` and `performance.solver_mip_rel_gap` (HiGHS, null = not set; a stop at the time limit ends the run as `SOLVER_NON_OPTIMAL`), `outputs.write_nx_sensitivity_csvs` (true; false skips `sensitivity_pst_nx.csv` and `sensitivity_rd_nx.csv`).
- Tests: `python -m pytest tests -q`. They need nothing outside `tests/`: the ReliCapGrid case is built from `tests/fixtures/CGM_package.zip` and `NCP_generic.zip` (`tests/helpers.py`, `fixture_instance_root`, `build_fixture_input_folder`); no test reads `input/`.

## Environment
Python 3.12.9 (first line of `requirements.txt`). Install with `pip install -r requirements.txt` (pinned versions, GUI packages in their own section at the end; known good: pypowsybl 1.15.0, Pyomo 6.10.1, highspy 1.15.1 (solver `appsi_highs`), rdflib 7.6.0, PyYAML 6.0.3, pandas 3.0.3, numpy 2.5.1).
pypowsybl quirks: the permanent-limit sentinel is -1 in `get_operational_limits()` but 2147483647 in security-analysis violations; a cold-start load flow can fail where a warm start converges.

## Code layout (`src/rao`, 31 modules)
- `run_pipeline.py`: orchestrator (config, input zips, phases, exports). `data_model.py`: dataclasses, enums and `select_by_side` (the one per-side value picker). `output_file_registry.py`: the 32 output names, renames, stale-file delete.
- `pre_milp/`: `cgmes_loader`, `ncp_loader`, `ncp_parser`, `tso_name_resolver`, `glsk_resolver`, `scanned_elements`, `n0_sensitivity`, `nx_security_analysis` (N-X load flow, TATL), `nx_sensitivity`, `cra_preprocessing` (curative PST availability and curative PST groups), `pst_bounds`, `pst_groups`, `sensitivity_checks` (guard and reuse of the last valid sensitivities), `lf_parameters`, `inventory_summary`, `workflow_gates`, `dc_conversion` (the one MW to ampere conversion of calculation mode `dc`: factor table, `dc_power_factor`), `hvdc_units` (HVDC units and groups: structure checks, operating limits, solved-network check, EI description warning).
- `milp/`: `milp_builder` (Pyomo model), `milp_solver`, `ac_convergence_loop` (nested loops, convergence, cycle exit, and the build and apply steps both calculation modes share), `single_pass` (calculation mode `ac_single_pass` and its final check), `dc_pass` (calculation mode `dc`: one pass, final AC check), `operating_point_state`, `post_ra_congestion_check`.
- `post_milp/`: `n0_results_export`, `nx_results_export`.
- `src/rao_pages/`: Streamlit pages of the RAO GUI (main run page, load flow settings, RAO settings) that prepare inputs and config for `run_pipeline.py` and show its outputs; they never modify it.
- `tests/` (37 test files, `fixtures/`; `conftest.py` has the fixtures, `helpers.py` the shared test builders): one `test_rao_<module>.py` per source module, so the test layout mirrors the code layout. `milp_builder` has four files by model block (`test_rao_milp_builder.py` core, results, RA limits, scanned elements; `_pst`, `_rd`, `_nx`). `test_rao_cra_preprocessing.py` also covers `pst_bounds` and `pst_groups`; `test_rao_run_pipeline.py` has the fast `run_pipeline` tests and `test_rao_run_pipeline_end_to_end.py` the tests that run `main()`; `test_rao_single_pass.py` covers `single_pass` and the `ra_types` / `calculation_mode` runs; `test_rao_dc_conversion.py` (conversion, unit), `test_rao_dc_mode.py` (DC calculation steps and GUI) and `test_rao_dc_pass.py` (runs of `main()` in `dc`) cover calculation mode `dc`; six `test_rao_hvdc_*.py` files cover `ra_types: hvdc` (`_parser`, `_sensitivity`, `_milp`, `_loop`, `_pipeline` runs of `main()` in the three modes, `_gui_config`) on the mock NCP generated by `tests/hvdc_mock.py`; `test_rao_frozen_imports.py` checks the frozen names (the GUI imports some of them).

## Docs
- `docs/DECISIONS.md`: decisions and reasons. `docs/ASSUMPTIONS.md`: assumptions and what is still to verify on real data. `docs/CHANGELOG.md`: what changed. `docs/User_Guide.md`: how to run and what the output files contain. `docs/Next_Steps.md`: next steps. `docs/Spec_Coverage.md`: spec coverage per CORNET / BUC item, deviations and deferred items.
- `reference/`: the specification in `reference/spec/` (the functional specification `specs.md` and implemented requirement specs); contributors may read it. The other reference files (`reference/technical/`, `reference/release_plan/`) are background only, not working documents.
