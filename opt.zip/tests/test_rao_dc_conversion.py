"""tests/test_rao_dc_conversion.py - pre_milp/dc_conversion.py: the one MW -> A conversion of the DC mode
(docs/dc_mode_specs.md D2), the factor table and dc_power_factor checks."""

import logging
import math

import pytest

from pre_milp import dc_conversion
from pre_milp.dc_conversion import DcCurrentConverter, P_REF_TOLERANCE_MW


@pytest.fixture(scope="module")
def network():
    import pypowsybl as pp

    # lines at 400 kV (S2VL1-S3VL1, S3VL1-S4VL1); transformer TWT: side 1 225 kV, side 2 400 kV
    return pp.network.create_four_substations_node_breaker_network()


def _converter(network, table=None, pf=1.0):
    return DcCurrentConverter.from_network(network, pf, table or {"default": 1.0})


def test_100_mw_at_400_kv_gives_144_3_ampere(network):
    converter = _converter(network)

    assert converter.current("LINE_S2S3", 1, 100.0) == pytest.approx(144.33756729740645, rel=1e-12)
    assert converter.current("LINE_S2S3", 2, -100.0) == pytest.approx(144.33756729740645, rel=1e-12)  # magnitude


def test_a_transformer_uses_the_nominal_voltage_of_each_side(network):
    converter = _converter(network)

    assert converter.current("TWT", 1, 100.0) == pytest.approx(100 * 1000 / (math.sqrt(3) * 225.0))
    assert converter.current("TWT", 2, 100.0) == pytest.approx(100 * 1000 / (math.sqrt(3) * 400.0))


def test_the_power_factor_divides_the_current(network):
    converter = _converter(network, pf=0.9)

    assert converter.current("LINE_S2S3", 1, 100.0) == pytest.approx(144.33756729740645 / 0.9)


def test_a_factor_per_voltage_level_changes_only_the_sides_of_that_level(network):
    plain = _converter(network)
    scaled = _converter(network, {"default": 1.0, 225: 1.2})

    assert scaled.current("TWT", 1, 100.0) == pytest.approx(1.2 * plain.current("TWT", 1, 100.0))
    assert scaled.current("TWT", 2, 100.0) == plain.current("TWT", 2, 100.0)
    assert scaled.current("LINE_S2S3", 1, 100.0) == plain.current("LINE_S2S3", 1, 100.0)
    assert scaled.levels_with_factor == 1  # S1VL1 only


def test_a_numeric_string_key_from_the_gui_settings_json_matches(network):
    scaled = _converter(network, {"default": 1.0, "400": 0.5})

    assert scaled.current("LINE_S2S3", 1, 100.0) == pytest.approx(0.5 * 144.33756729740645)
    assert scaled.levels_with_factor == 4  # S1VL2, S2VL1, S3VL1, S4VL1


def test_the_default_applies_to_levels_without_an_entry_and_the_unmatched_levels_are_logged_once(network, caplog):
    with caplog.at_level(logging.INFO, logger=dc_conversion.log.name):
        converter = _converter(network, {"default": 1.5, 400: 1.0})

    assert converter.current("TWT", 1, 100.0) == pytest.approx(1.5 * 100 * 1000 / (math.sqrt(3) * 225.0))
    messages = [r.getMessage() for r in caplog.records if "no entry" in r.getMessage()]
    assert len(messages) == 1 and "225" in messages[0]


def test_flows_and_sensitivities_share_one_scale(network):
    converter = _converter(network, {"default": 1.0, 400: 1.25})

    assert converter.scale("LINE_S2S3", 1) == converter.current("LINE_S2S3", 1, 1.0)
    assert converter.sensitivity("LINE_S2S3", 1, 2.0, 50.0) == pytest.approx(2.0 * converter.scale("LINE_S2S3", 1))


@pytest.mark.parametrize("p_ref, sign", [(50.0, 1.0), (-50.0, -1.0)])
def test_the_sensitivity_takes_the_sign_of_the_reference_flow(network, p_ref, sign):
    converter = _converter(network)

    pst = converter.sensitivity("TWT", 2, -0.31, p_ref)       # MW per degree
    injection = converter.sensitivity("TWT", 1, 0.4, p_ref)   # MW per MW

    assert pst == pytest.approx(sign * -0.31 * 1000 / (math.sqrt(3) * 400.0))
    assert injection == pytest.approx(sign * 0.4 * 1000 / (math.sqrt(3) * 225.0))


def test_a_zero_reference_flow_gives_sign_plus_one_and_one_log_line(network, caplog):
    converter = _converter(network)

    with caplog.at_level(logging.INFO, logger=dc_conversion.log.name):
        first = converter.sensitivity("LINE_S2S3", 1, -2.0, 0.0)
        second = converter.sensitivity("LINE_S3S4", 1, -2.0, P_REF_TOLERANCE_MW / 2)
        # a negative reference inside the tolerance has no usable sign either: +1, not -1
        third = converter.sensitivity("LINE_S3S4", 1, -2.0, -P_REF_TOLERANCE_MW / 2)

    assert first == pytest.approx(-2.0 * converter.scale("LINE_S2S3", 1)) and second < 0
    assert third == pytest.approx(-2.0 * converter.scale("LINE_S3S4", 1))
    assert converter.sensitivity("LINE_S3S4", 1, -2.0, -2 * P_REF_TOLERANCE_MW) > 0  # outside it: sign -1
    assert len([r for r in caplog.records if "no sign" in r.getMessage()]) == 1


def test_nan_stays_nan_and_an_unknown_side_is_nan(network):
    converter = _converter(network)

    assert math.isnan(converter.current("LINE_S2S3", 1, float("nan")))
    assert math.isnan(converter.sensitivity("LINE_S2S3", 1, 1.0, float("nan")))
    assert math.isnan(converter.current("NO_SUCH_BRANCH", 1, 10.0))


def test_flows_to_currents_keeps_the_lf_shape(network):
    converter = _converter(network)

    result = converter.flows_to_currents({"TWT": {1: 100.0, 2: float("nan")}})

    assert set(result) == {"TWT"} and set(result["TWT"]) == {1, 2}
    assert result["TWT"][1] > 0 and math.isnan(result["TWT"][2])


@pytest.mark.parametrize("value", [0, -1.0, True, None, "1.0", float("inf")])
def test_dc_power_factor_must_be_a_number_above_zero(value):
    with pytest.raises(ValueError, match="dc_power_factor"):
        dc_conversion.validate_dc_power_factor(value, "x")


def test_a_valid_dc_power_factor_is_returned_as_a_float():
    assert dc_conversion.validate_dc_power_factor(1, "x") == 1.0 and dc_conversion.validate_dc_power_factor(0.9, "x") == 0.9
