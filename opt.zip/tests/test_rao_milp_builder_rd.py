"""tests/test_rao_milp_builder_rd.py - tests for the RD blocks of milp_builder.py.

Sections: preventive and curative RD blocks, RD availability, curative RD cost, curative RD lead time, curative RD without preventive RD.
"""

import logging
import sys
import pyomo.environ as pyo
import pytest

from pathlib import Path
from data_model import (
    AcVerificationStatus,
    AEType,
    AssessedElement,
    BidDirection,
    PST,
    PowerBid,
    RAKind,
    RDUnit,
)
from milp.milp_builder import (
    PstMilpInputs,
    RdMilpInputs,
    build_n0_milp_model,
    NxMilpInputs,
    _compute_radp,
    _timestamp_is_usable,
    _compute_earliest_usable_timestamp,
)
from helpers import (
    _bid_rd_cost as _bid,
    _unit,
    _make_ae,
    BIDS,
    PENALTY_FACTOR,
    REFERENCE as REFERENCE_curative_rd_cost,
    _solved_model,
)
from text_encoding import TEXT_ENCODING  # noqa: E402

REPO_SRC = Path(__file__).resolve().parents[1] / "src" / "rao"


def _make_ae_costs(branch_mrid: str, side: int, patl_ka: float, timestamp: str = "1030Z") -> AssessedElement:
    return AssessedElement(
        mrid=f"AE_{branch_mrid}", name=f"AE {branch_mrid}", tso="TestTSO",
        ae_type=AEType.SECURED, branch_mrid=branch_mrid,
        secured_for_region=None, scanned_for_region=None, exclusion_reason=None,
        patl_ka={timestamp: patl_ka}, branch_side=side,
    )


def _make_pst_costs(mrid: str, r0: int = 0) -> PST:
    return PST(
        mrid=mrid, name=mrid, tso="TestTSO", available=True, kind=RAKind.PREVENTIVE,
        penalty_factor=1.0, low_step=-10, high_step=10, r0=r0,
        operating_tap_min=-10, operating_tap_max=10, group_id=None,
    )


def _make_rd_unit_costs(mrid: str, gu_mrid: str, tso: str = "TestTSO", penalty_factor: float = 1.0) -> RDUnit:
    return RDUnit(
        mrid=mrid, name=mrid, tso=tso, gu_mrid=gu_mrid, gu_name=gu_mrid,
        available=True, kind=RAKind.PREVENTIVE, initial_p=50.0, max_p=100.0, min_p=0.0,
        raise_ramp_rate=None, lower_ramp_rate=None, penalty_factor=penalty_factor,
    )


def _make_bid_costs(mrid: str, ra_mrid: str, direction: BidDirection, available_mw: dict, price_eur_mw: float = 10.0) -> PowerBid:
    return PowerBid(
        mrid=mrid, ra_mrid=ra_mrid, direction=direction, available_mw=available_mw,
        price_eur_mw=price_eur_mw, penalty_factor=0.0, lead_time_h=0.0,
        activation_cost_eur=None, min_energy_mwh=None, max_energy_mwh=None, step_size_mw=None,
    )


def test_pst_only_has_no_rd_cost_terms():
    """Given a PST-only workflow, When the model is built, Then no RD cost
    terms exist (structurally confirmed via absence of rd_volume_upward)."""
    ae_list = [_make_ae_costs("BRANCH1", side=1, patl_ka=1.0)]
    pst_inputs = PstMilpInputs(
        pst_list=[_make_pst_costs("PST1")], pst_tap_bounds={"PST1": (-10, 10)},
        pst_group_equality_pairs=[], sensitivity_pst_n0_pruned={("BRANCH1", "PST1"): 5.0},
        pst_degrees_per_tap={"PST1": 1.5}, penalty_reference_pst_pra=10.0,
    )

    model = build_n0_milp_model(
        ae_list, "1030Z", lf_initial={"BRANCH1": {1: 500.0}},
        penalty_cost_overload_n0=1000.0, pst_inputs=pst_inputs,
    )

    assert not hasattr(model, "rd_volume_upward")


def test_rd_empty_glsk_guard_has_no_rd_cost_terms():
    """RD inputs with the empty-GLSK guard firing: no RD cost terms."""
    ae_list = [_make_ae_costs("BRANCH1", side=1, patl_ka=1.0)]
    rd_inputs = RdMilpInputs(
        rd_list=[_make_rd_unit_costs("RA1", "GU1")],
        bid_list=[_make_bid_costs("BID1", "RA1", BidDirection.UP, {"1030Z": 20.0})],
        glsk={"RA1": {}},
        sensitivity_rd_n0_pruned={("BRANCH1", "GU1"): -10.0},
        generator_data={"GU1": {"target_p": 50.0, "max_p": 100.0, "min_p": 0.0, "name": "GU1"}},
        penalty_reference_rd_pra=5.0,
    )

    model = build_n0_milp_model(
        ae_list, "1030Z", lf_initial={"BRANCH1": {1: 500.0}},
        penalty_cost_overload_n0=1000.0, rd_inputs=rd_inputs,
    )

    assert not hasattr(model, "rd_volume_upward")


def test_cheaper_bid_preferred_when_both_resolve_the_same_congestion():
    """Two RD units relieving the same branch equally, at 10 and 20 EUR/MW: a real solve
    prefers the cheaper bid. GU3 (zero sensitivity, zero cost) is the balancing partner."""
    ae_list = [_make_ae_costs("BRANCH1", side=1, patl_ka=1.0)]
    rd_inputs = RdMilpInputs(
        rd_list=[
            _make_rd_unit_costs("RA_CHEAP", "GU_CHEAP"),
            _make_rd_unit_costs("RA_EXPENSIVE", "GU_EXPENSIVE"),
            _make_rd_unit_costs("RA_BALANCE", "GU_BALANCE"),
        ],
        bid_list=[
            _make_bid_costs("BID_CHEAP", "RA_CHEAP", BidDirection.UP, {"1030Z": 30.0}, price_eur_mw=10.0),
            _make_bid_costs("BID_EXPENSIVE", "RA_EXPENSIVE", BidDirection.UP, {"1030Z": 30.0}, price_eur_mw=20.0),
            _make_bid_costs("BID_BALANCE", "RA_BALANCE", BidDirection.DOWN, {"1030Z": 60.0}, price_eur_mw=0.0),
        ],
        glsk={"RA_CHEAP": {"GU_CHEAP": 1.0}, "RA_EXPENSIVE": {"GU_EXPENSIVE": 1.0}, "RA_BALANCE": {"GU_BALANCE": 1.0}},
        # GU_CHEAP and GU_EXPENSIVE have IDENTICAL sensitivity to BRANCH1, only the price
        # differs; GU_BALANCE has none (pure balancing partner)
        sensitivity_rd_n0_pruned={
            ("BRANCH1", "GU_CHEAP"): -10.0,
            ("BRANCH1", "GU_EXPENSIVE"): -10.0,
        },
        generator_data={
            "GU_CHEAP": {"target_p": 50.0, "max_p": 100.0, "min_p": 0.0, "name": "GU_CHEAP"},
            "GU_EXPENSIVE": {"target_p": 50.0, "max_p": 100.0, "min_p": 0.0, "name": "GU_EXPENSIVE"},
            "GU_BALANCE": {"target_p": 50.0, "max_p": 100.0, "min_p": 0.0, "name": "GU_BALANCE"},
        },
        penalty_reference_rd_pra=0.0,  # isolate price effect — no penalty component
    )

    # 1050 A against 1000 A PATL -> 50 A overload; either unit alone could
    # supply the needed 5 MW (10 A/MW), so the solver has a genuine choice.
    model = build_n0_milp_model(
        ae_list, "1030Z", lf_initial={"BRANCH1": {1: 1050.0}},
        penalty_cost_overload_n0=1000.0, rd_inputs=rd_inputs,
    )

    solver = pyo.SolverFactory("appsi_highs")
    result = solver.solve(model)
    assert str(result.solver.termination_condition) in ("optimal", "TerminationCondition.optimal")

    cheap_volume = pyo.value(model.rd_volume_upward["BID_CHEAP"])
    expensive_volume = pyo.value(model.rd_volume_upward["BID_EXPENSIVE"])

    assert cheap_volume >= 5.0 - 1e-6  # cheap bid fully dispatched to clear the overload
    assert expensive_volume < 1e-6      # expensive bid left untouched


def test_extract_rd_results_writes_empty_csv_when_rd_inert(tmp_path):
    """A model without RD components (empty-GLSK guard): extract_rd_results still creates the
    CSV, header row only."""
    from post_milp.n0_results_export import extract_rd_results

    ae_list = [_make_ae_costs("BRANCH1", side=1, patl_ka=1.0)]
    rd_inputs = RdMilpInputs(
        rd_list=[_make_rd_unit_costs("RA1", "GU1")],
        bid_list=[_make_bid_costs("BID1", "RA1", BidDirection.UP, {"1030Z": 20.0})],
        glsk={"RA1": {}},  # empty-GLSK guard fires
        sensitivity_rd_n0_pruned={("BRANCH1", "GU1"): -10.0},
        generator_data={"GU1": {"target_p": 50.0, "max_p": 100.0, "min_p": 0.0, "name": "GU1"}},
    )

    model = build_n0_milp_model(
        ae_list, "1030Z", lf_initial={"BRANCH1": {1: 500.0}},
        penalty_cost_overload_n0=1000.0, rd_inputs=rd_inputs,
    )
    assert not hasattr(model, "rd_volume_upward")  # confirm guard fired

    output_path = tmp_path / "results_preventive_rd.csv"
    result = extract_rd_results(
        model, rd_list=rd_inputs.rd_list, bid_list=rd_inputs.bid_list,
        penalty_reference_rd_pra=100.0, timestamp="1030Z", output_path=output_path,
        ac_verification_status=AcVerificationStatus.CONVERGED,
        ac_verification_termination_reason="test fixture",
    )

    assert result == {}
    assert output_path.exists(), "results_preventive_rd.csv must be written even when RD is inert"
    with open(output_path, encoding=TEXT_ENCODING) as f:
        header = f.readline().strip()
    assert "ra_mrid" in header  # header row present, even with zero data rows


def test_rd_penalty_factor_and_per_tso_override_affect_extracted_cost():
    """Given a bid with rd_penalty_factor=2.0 on an RA whose TSO has a
    penalty_reference_rd_pra_per_tso override, When the model is solved and
    results are extracted via extract_rd_results, Then the extracted
    penalty_cost_eur reflects the RA-level penalty_factor and the
    TSO-specific override — not the PowerBid-level penalty_factor (a
    different field, unused here) and not the global default."""
    from post_milp.n0_results_export import extract_rd_results

    ae_list = [_make_ae_costs("BRANCH1", side=1, patl_ka=1.0)]
    rd_inputs = RdMilpInputs(
        rd_list=[
            _make_rd_unit_costs("RA1", "GU1", tso="TSO-Special", penalty_factor=2.0),
            _make_rd_unit_costs("RA2", "GU2", tso="TSO-Special"),  # balancing partner
        ],
        bid_list=[
            # bid caps EXACTLY match the 3 MW needed: one deterministic optimal dispatch
            _make_bid_costs("BID1", "RA1", BidDirection.UP, {"1030Z": 3.0}, price_eur_mw=0.0),
            _make_bid_costs("BID2", "RA2", BidDirection.DOWN, {"1030Z": 3.0}, price_eur_mw=0.0),
        ],
        glsk={"RA1": {"GU1": 1.0}, "RA2": {"GU2": 1.0}},
        sensitivity_rd_n0_pruned={("BRANCH1", "GU1"): -10.0},  # GU2: no entry, 0 sensitivity
        generator_data={
            "GU1": {"target_p": 50.0, "max_p": 100.0, "min_p": 0.0, "name": "GU1"},
            "GU2": {"target_p": 50.0, "max_p": 100.0, "min_p": 0.0, "name": "GU2"},
        },
        penalty_reference_rd_pra=100.0,  # global default -- should NOT be used
        penalty_reference_rd_pra_per_tso={"TSO-Special": 5.0},  # should be used instead
    )

    # 1030 A against 1000 A PATL -> 30 A overload -> exactly 3 MW needed
    # (10 A/MW), matching BID1's 3.0 MW cap exactly.
    model = build_n0_milp_model(
        ae_list, "1030Z", lf_initial={"BRANCH1": {1: 1030.0}},
        penalty_cost_overload_n0=1000.0, rd_inputs=rd_inputs,
    )

    solver = pyo.SolverFactory("appsi_highs")
    result = solver.solve(model)
    assert str(result.solver.termination_condition) in ("optimal", "TerminationCondition.optimal")

    rd_results = extract_rd_results(
        model, rd_list=rd_inputs.rd_list, bid_list=rd_inputs.bid_list,
        penalty_reference_rd_pra=rd_inputs.penalty_reference_rd_pra,
        penalty_reference_rd_pra_per_tso=rd_inputs.penalty_reference_rd_pra_per_tso,
        timestamp="1030Z",
        ac_verification_status=AcVerificationStatus.CONVERGED,
        ac_verification_termination_reason="test fixture",
    )

    assert "BID1" in rd_results
    assert abs(rd_results["BID1"]["rd_volume_net_mw"] - 3.0) < 1e-6
    # penalty_factor(2.0) * per_tso_override(5.0) * volume(3.0) = 30.0 --
    # NOT penalty_reference_rd_pra(100.0), confirming the override is used.
    expected_penalty_cost = 2.0 * 5.0 * 3.0
    assert abs(rd_results["BID1"]["penalty_cost_eur"] - expected_penalty_cost) < 1e-6


REPO_SRC = Path(__file__).resolve().parents[1] / "src" / "rao"


def _make_ae_balancing(branch_mrid: str, side: int, patl_ka: float, timestamp: str = "1030Z") -> AssessedElement:
    return AssessedElement(
        mrid=f"AE_{branch_mrid}", name=f"AE {branch_mrid}", tso="TestTSO",
        ae_type=AEType.SECURED, branch_mrid=branch_mrid,
        secured_for_region=None, scanned_for_region=None, exclusion_reason=None,
        patl_ka={timestamp: patl_ka}, branch_side=side,
    )


def _make_pst_balancing(mrid: str, r0: int = 0) -> PST:
    return PST(
        mrid=mrid, name=mrid, tso="TestTSO", available=True, kind=RAKind.PREVENTIVE,
        penalty_factor=1.0, low_step=-10, high_step=10, r0=r0,
        operating_tap_min=-10, operating_tap_max=10, group_id=None,
    )


def _make_rd_unit_balancing(mrid: str, gu_mrid: str) -> RDUnit:
    return RDUnit(
        mrid=mrid, name=mrid, tso="TestTSO", gu_mrid=gu_mrid, gu_name=gu_mrid,
        available=True, kind=RAKind.PREVENTIVE, initial_p=50.0, max_p=100.0, min_p=0.0,
        raise_ramp_rate=None, lower_ramp_rate=None,
    )


def _make_bid_balancing(mrid: str, ra_mrid: str, direction: BidDirection, available_mw: dict) -> PowerBid:
    return PowerBid(
        mrid=mrid, ra_mrid=ra_mrid, direction=direction, available_mw=available_mw,
        price_eur_mw=10.0, penalty_factor=0.0, lead_time_h=0.0,
        activation_cost_eur=None, min_energy_mwh=None, max_energy_mwh=None, step_size_mw=None,
    )


def test_pst_only_has_no_balancing_constraint():
    """Given a PST-only workflow, When the model is built, Then no
    rd_balancing_n0 constraint is added."""
    ae_list = [_make_ae_balancing("BRANCH1", side=1, patl_ka=1.0)]
    pst_inputs = PstMilpInputs(
        pst_list=[_make_pst_balancing("PST1")], pst_tap_bounds={"PST1": (-10, 10)},
        pst_group_equality_pairs=[], sensitivity_pst_n0_pruned={("BRANCH1", "PST1"): 5.0},
        pst_degrees_per_tap={"PST1": 1.5}, penalty_reference_pst_pra=10.0,
    )

    model = build_n0_milp_model(
        ae_list, "1030Z", lf_initial={"BRANCH1": {1: 500.0}},
        penalty_cost_overload_n0=1000.0, pst_inputs=pst_inputs,
    )

    assert not hasattr(model, "rd_balancing_n0")


def test_rd_empty_glsk_guard_has_no_balancing_constraint():
    """Given RD inputs are provided but the empty-GLSK guard fires (no
    rd_net_injection_g on the model), When the model is built, Then no
    rd_balancing_n0 constraint is added — hasattr(model,
    'rd_net_injection_g') correctly gates this even though rd_inputs
    itself is not None."""
    ae_list = [_make_ae_balancing("BRANCH1", side=1, patl_ka=1.0)]
    rd_inputs = RdMilpInputs(
        rd_list=[_make_rd_unit_balancing("RA1", "GU1")],
        bid_list=[_make_bid_balancing("BID1", "RA1", BidDirection.UP, {"1030Z": 20.0})],
        glsk={"RA1": {}},  # real dataset shape: empty participation
        sensitivity_rd_n0_pruned={("BRANCH1", "GU1"): -10.0},
        generator_data={"GU1": {"target_p": 50.0, "max_p": 100.0, "min_p": 0.0, "name": "GU1"}},
    )

    model = build_n0_milp_model(
        ae_list, "1030Z", lf_initial={"BRANCH1": {1: 500.0}},
        penalty_cost_overload_n0=1000.0, rd_inputs=rd_inputs,
    )

    assert not hasattr(model, "rd_net_injection_g")
    assert not hasattr(model, "rd_balancing_n0")


def test_rd_only_balancing_constraint_exists_and_holds_when_solved():
    """RD-only model with GU1 (on the overloaded branch) and GU2 (no sensitivity entry):
    rd_balancing_n0 exists, GU1 resolves the branch and |sum(rd_net_injection_g)| < 0.01 MW,
    so GU2 moves opposite GU1 only to balance."""
    ae_list = [_make_ae_balancing("BRANCH1", side=1, patl_ka=1.0)]
    rd_inputs = RdMilpInputs(
        rd_list=[_make_rd_unit_balancing("RA1", "GU1"), _make_rd_unit_balancing("RA2", "GU2")],
        bid_list=[
            _make_bid_balancing("BID_UP_1", "RA1", BidDirection.UP, {"1030Z": 30.0}),
            _make_bid_balancing("BID_DOWN_2", "RA2", BidDirection.DOWN, {"1030Z": 30.0}),
        ],
        glsk={"RA1": {"GU1": 1.0}, "RA2": {"GU2": 1.0}},
        # GU2 has NO sensitivity entry (0.0 via .get() in rd_effect_on_branch): it affects only
        # the balance sum
        sensitivity_rd_n0_pruned={("BRANCH1", "GU1"): -10.0},
        generator_data={
            "GU1": {"target_p": 50.0, "max_p": 100.0, "min_p": 0.0, "name": "GU1"},
            "GU2": {"target_p": 50.0, "max_p": 100.0, "min_p": 0.0, "name": "GU2"},
        },
    )

    # Overloaded by 50 A -> needs 5 MW upward from GU1 to clear.
    model = build_n0_milp_model(
        ae_list, "1030Z", lf_initial={"BRANCH1": {1: 1050.0}},
        penalty_cost_overload_n0=1000.0, rd_inputs=rd_inputs,
    )

    assert hasattr(model, "rd_balancing_n0")

    solver = pyo.SolverFactory("appsi_highs")
    result = solver.solve(model)
    assert str(result.solver.termination_condition) in ("optimal", "TerminationCondition.optimal")

    net_gu1 = pyo.value(model.rd_net_injection_g["GU1"])
    net_gu2 = pyo.value(model.rd_net_injection_g["GU2"])

    assert net_gu1 >= 5.0 - 1e-6  # GU1 dispatched enough to clear the branch
    assert abs(net_gu1 + net_gu2) < 0.01  # balancing forces GU2 to offset GU1
    assert abs(net_gu2 - (-net_gu1)) < 1e-6  # GU2 moved opposite, purely to balance

    overload_1 = pyo.value(model.overload_slack_n0["BRANCH1"])
    assert overload_1 < 1e-6


def test_pst_and_rd_together_balancing_constraint_only_covers_rd():
    """Given a PST+RD workflow, When the model is built, Then
    rd_balancing_n0 exists and sums only over gu_ids (RD generating units),
    not PST taps — PST is entirely absent from this constraint's terms."""
    ae_list = [_make_ae_balancing("BRANCH1", side=1, patl_ka=1.0)]
    pst_inputs = PstMilpInputs(
        pst_list=[_make_pst_balancing("PST1")], pst_tap_bounds={"PST1": (-10, 10)},
        pst_group_equality_pairs=[], sensitivity_pst_n0_pruned={("BRANCH1", "PST1"): -5.0},
        pst_degrees_per_tap={"PST1": 1.0}, penalty_reference_pst_pra=1.0,
    )
    rd_inputs = RdMilpInputs(
        rd_list=[_make_rd_unit_balancing("RA1", "GU1")],
        bid_list=[_make_bid_balancing("BID1", "RA1", BidDirection.UP, {"1030Z": 20.0})],
        glsk={"RA1": {"GU1": 1.0}},
        sensitivity_rd_n0_pruned={("BRANCH1", "GU1"): -10.0},
        generator_data={"GU1": {"target_p": 50.0, "max_p": 100.0, "min_p": 0.0, "name": "GU1"}},
    )

    model = build_n0_milp_model(
        ae_list, "1030Z", lf_initial={"BRANCH1": {1: 500.0}},
        penalty_cost_overload_n0=1000.0, pst_inputs=pst_inputs, rd_inputs=rd_inputs,
    )

    assert hasattr(model, "rd_balancing_n0")
    balancing_expr_vars = {v.name for v in model.rd_balancing_n0.body.args} if hasattr(model.rd_balancing_n0.body, "args") else set()
    # the balancing constraint has no tap terms: one (RD-scoped) balancing constraint even
    # with PST present
    assert len(list(model.component_objects(pyo.Constraint))) >= 1
    assert "rd_balancing_n0" in [c.name for c in model.component_objects(pyo.Constraint)]


REPO_SRC = Path(__file__).resolve().parents[1] / "src" / "rao"


REPO_ROOT = Path(__file__).resolve().parents[1]


def _make_ae_r36(branch_mrid: str, side: int = 1, patl_ka: float = 1.0,
             ae_type=AEType.SECURED, timestamp: str = "1030Z") -> AssessedElement:
    return AssessedElement(
        mrid=f"AE_{branch_mrid}", name=f"AE {branch_mrid}", tso="TestTSO",
        ae_type=ae_type, branch_mrid=branch_mrid,
        secured_for_region=None, scanned_for_region=None, exclusion_reason=None,
        patl_ka={timestamp: patl_ka}, branch_side=side,
    )


def _make_rd_unit_r36(mrid: str, gu_mrid: str, kind=RAKind.PREVENTIVE,
                   linked_contingency_mrids=None, linked_xne_mrids=None) -> RDUnit:
    return RDUnit(
        mrid=mrid, name=mrid, tso="TestTSO", gu_mrid=gu_mrid, gu_name=gu_mrid,
        available=True, kind=kind, initial_p=50.0, max_p=100.0, min_p=0.0,
        raise_ramp_rate=None, lower_ramp_rate=None,
        linked_contingency_mrids=linked_contingency_mrids or [],
        linked_xne_mrids=linked_xne_mrids or [],
    )


def _make_bid_r36(mrid: str, ra_mrid: str, direction: BidDirection, available_mw: dict) -> PowerBid:
    return PowerBid(
        mrid=mrid, ra_mrid=ra_mrid, direction=direction, available_mw=available_mw,
        price_eur_mw=10.0, penalty_factor=0.0, lead_time_h=0.0,
        activation_cost_eur=None, min_energy_mwh=None, max_energy_mwh=None, step_size_mw=None,
    )


def _with_curative_balancing_partner(rd_inputs, direction, contingencies, available_mw=1000.0):
    """rd_inputs plus a free curative partner bid (penalty factor 0, price 0, no sensitivity, on
    its own unit GU_BAL) in `direction`, linked to `contingencies`: the per-contingency curative
    balance (CORNET-574) needs a counterpart before a lone curative bid can move."""
    partner = RDUnit(
        mrid="RD_BAL", name="RD_BAL", tso="TestTSO", gu_mrid="GU_BAL", gu_name="GU_BAL",
        available=True, kind=RAKind.CURATIVE, initial_p=500.0, max_p=2000.0, min_p=0.0,
        raise_ramp_rate=None, lower_ramp_rate=None, penalty_factor=0.0,
        linked_contingency_mrids=list(contingencies), linked_xne_mrids=[],
    )
    partner_bid = PowerBid(
        mrid="BID_BAL", ra_mrid="RD_BAL", direction=direction, available_mw={"1030Z": available_mw},
        price_eur_mw=0.0, penalty_factor=0.0, lead_time_h=0.0,
        activation_cost_eur=None, min_energy_mwh=None, max_energy_mwh=None, step_size_mw=None,
    )
    rd_inputs.rd_list = [*rd_inputs.rd_list, partner]
    rd_inputs.bid_list = [*rd_inputs.bid_list, partner_bid]
    rd_inputs.glsk = {**rd_inputs.glsk, "RD_BAL": {"GU_BAL": 1.0}}
    rd_inputs.generator_data = {
        **rd_inputs.generator_data, "GU_BAL": {"target_p": 500.0, "max_p": 2000.0, "min_p": 0.0},
    }
    return rd_inputs


# ---------------------------------------------------------------------------
# _add_rd_block — preventive-filter correction
# ---------------------------------------------------------------------------

def test_add_rd_block_excludes_curative_bids_from_preventive_variables():
    """A preventive and a curative RD unit/bid with the same GLSK, rd_inputs only (no
    nx_inputs): preventive rd_volume_upward/downward exist only for the preventive bid."""
    ae_list = [_make_ae_r36("BRANCH1")]
    rd_inputs = RdMilpInputs(
        rd_list=[
            _make_rd_unit_r36("RD1", "GU1", kind=RAKind.PREVENTIVE),
            _make_rd_unit_r36("RD2", "GU1", kind=RAKind.CURATIVE, linked_contingency_mrids=["CO1"]),
        ],
        bid_list=[
            _make_bid_r36("BID1", "RD1", BidDirection.UP, {"1030Z": 50.0}),
            _make_bid_r36("BID2", "RD2", BidDirection.UP, {"1030Z": 30.0}),
        ],
        glsk={"RD1": {"GU1": 1.0}, "RD2": {"GU1": 1.0}},
        sensitivity_rd_n0_pruned={("BRANCH1", "GU1"): 0.3},
        generator_data={"GU1": {"target_p": 50.0, "max_p": 100.0, "min_p": 0.0}},
        penalty_reference_rd_pra=10.0,
    )

    model = build_n0_milp_model(
        ae_list, "1030Z", lf_initial={"BRANCH1": {1: 500.0}},
        penalty_cost_overload_n0=1000.0, rd_inputs=rd_inputs,
    )

    assert list(model.bid_ids) == ["BID1"]
    assert "BID2" not in list(model.bid_ids)


# ---------------------------------------------------------------------------
# Generator on/off (F2): offline unit with Pmin > 0
# ---------------------------------------------------------------------------

def _offline_unit_model(up_available_mw, unit_costs=None, lf_branch=500.0):
    """GU_OFF: PROD 0, Pmin 50, Pmax 200, one preventive up bid (10 EUR/MW, relieves BRANCH1 by
    1 A/MW); GU_DN: running at 500 MW with a free preventive down bid of 300 MW (balance
    partner, no effect on BRANCH1). BRANCH1 (PATL 1000 A) carries lf_branch A in N-0."""
    units = [
        RDUnit(mrid=ra, name=ra, tso="TestTSO", gu_mrid=gu, gu_name=gu, available=True,
               kind=RAKind.PREVENTIVE, initial_p=p, max_p=pmax, min_p=pmin,
               raise_ramp_rate=None, lower_ramp_rate=None)
        for ra, gu, p, pmin, pmax in (("RD_OFF", "GU_OFF", 0.0, 50.0, 200.0), ("RD_DN", "GU_DN", 500.0, 0.0, 1000.0))
    ]
    bids = [_make_bid_r36("BID_OFF", "RD_OFF", BidDirection.UP, {"1030Z": up_available_mw}),
            _make_bid_r36("BID_DN", "RD_DN", BidDirection.DOWN, {"1030Z": 300.0})]
    bids[1].price_eur_mw = 0.0
    rd_inputs = RdMilpInputs(
        rd_list=units, bid_list=bids, glsk={"RD_OFF": {"GU_OFF": 1.0}, "RD_DN": {"GU_DN": 1.0}},
        sensitivity_rd_n0_pruned={("BRANCH1", "GU_OFF"): -1.0},
        generator_data={
            "GU_OFF": {"target_p": 0.0, "max_p": 200.0, "min_p": 50.0, "connected": True},
            "GU_DN": {"target_p": 500.0, "max_p": 1000.0, "min_p": 0.0, "connected": True},
        },
        penalty_reference_rd_pra=0.0,
        **({"unit_costs": unit_costs} if unit_costs is not None else {}),
    )
    return build_n0_milp_model(
        [_make_ae_r36("BRANCH1", patl_ka=1.0)], "1030Z", lf_initial={"BRANCH1": {1: lf_branch}},
        penalty_cost_overload_n0=1000.0, rd_inputs=rd_inputs,
    )


def _termination(model):
    return str(pyo.SolverFactory("appsi_highs").solve(model, load_solutions=False).solver.termination_condition)


@pytest.mark.parametrize("up_available_mw", [100.0, 30.0])
def test_an_offline_unit_without_start_up_cost_stays_off_and_the_model_is_feasible(up_available_mw):
    """F2 rule 10: before the on/off fix this model forced the offline unit to at least Pmin
    (a free start-up, up bid 100 MW) or was infeasible (up bid 30 MW < Pmin). Now the unit
    without a start-up cost is FIXED_OFF: it stays at 0 and the model solves."""
    model = _offline_unit_model(up_available_mw=up_available_mw)
    assert model.rd_unit_status["GU_OFF"].unit_class == "fixed_off"
    assert _termination(model) == "optimal"
    pyo.SolverFactory("appsi_highs").solve(model)
    assert pyo.value(model.rd_volume_upward["BID_OFF"]) == pytest.approx(0.0, abs=1e-9)


def _on_off_model(units, bids, sensitivity, lf_branch, unit_costs=None, nx_inputs=None,
                  penalty_n0=1000.0, glsk_override=None):
    """units: [(ra, gu, kind, PROD, Pmin, Pmax, linked contingencies)]; bids: [(bid, ra,
    direction, MW, price, activation cost)]; sensitivity: {gu: A/MW on BRANCH1 in N-0}.
    BRANCH1: PATL 1000 A, lf_branch A in N-0. Penalty references 0: costs are prices only.
    GLSK: {ra: {gu: 1.0}} per unit row, entries of glsk_override replace an RA's GLSK
    (a multi-unit or an empty GLSK)."""
    rd_list = [
        RDUnit(mrid=ra, name=ra, tso="TestTSO", gu_mrid=gu, gu_name=gu, available=True, kind=kind,
               initial_p=p, max_p=pmax, min_p=pmin, raise_ramp_rate=None, lower_ramp_rate=None,
               penalty_factor=0.0, linked_contingency_mrids=list(cos))
        for ra, gu, kind, p, pmin, pmax, cos in units
    ]
    bid_list = []
    for bid_mrid, ra, direction, mw, price, activation in bids:
        bid = _make_bid_r36(bid_mrid, ra, direction, {"1030Z": mw})
        bid.price_eur_mw, bid.activation_cost_eur = price, activation
        bid_list.append(bid)
    rd_inputs = RdMilpInputs(
        rd_list=rd_list, bid_list=bid_list,
        glsk={**{ra: {gu: 1.0} for ra, gu, *_ in units}, **(glsk_override or {})},
        sensitivity_rd_n0_pruned={("BRANCH1", gu): s for gu, s in sensitivity.items()},
        generator_data={gu: {"target_p": p, "max_p": pmax, "min_p": pmin, "connected": True}
                        for _ra, gu, _k, p, pmin, pmax, _c in units},
        penalty_reference_rd_pra=0.0, unit_costs=unit_costs,
    )
    model = build_n0_milp_model(
        [_make_ae_r36("BRANCH1", patl_ka=1.0)], "1030Z", lf_initial={"BRANCH1": {1: lf_branch}},
        penalty_cost_overload_n0=penalty_n0, rd_inputs=rd_inputs, nx_inputs=nx_inputs,
    )
    assert _termination(model) == "optimal"
    pyo.SolverFactory("appsi_highs").solve(model)
    model.test_rd_inputs = rd_inputs   # for the result extractors in the tests
    return model


P = RAKind.PREVENTIVE
C = RAKind.CURATIVE
UP, DOWN = BidDirection.UP, BidDirection.DOWN
# a running balance partner with free up and down bids and no effect on BRANCH1
_PARTNER_UNITS = [("RD_BU", "GU_B", P, 500.0, 0.0, 2000.0, []), ("RD_BD", "GU_B", P, 500.0, 0.0, 2000.0, [])]
_PARTNER_BIDS = [("BID_BU", "RD_BU", UP, 500.0, 0.0, None), ("BID_BD", "RD_BD", DOWN, 500.0, 0.0, None)]


def _start_up_model(startup_cost):
    """GU_OFF (PROD 0, Pmin 50) relieves the 100 A overload of BRANCH1 by 1 A/MW."""
    from data_model import UnitCost
    costs = {"GU_OFF": UnitCost(startup_cost_eur=startup_cost)} if startup_cost is not None else {}
    return _on_off_model(
        [("RD_OFF", "GU_OFF", P, 0.0, 50.0, 200.0, []), *_PARTNER_UNITS],
        [("BID_OFF", "RD_OFF", UP, 150.0, 10.0, None), *_PARTNER_BIDS],
        {"GU_OFF": -1.0}, lf_branch=1100.0, unit_costs=costs,
    )


def test_an_offline_unit_with_a_start_up_cost_can_be_started_and_pays_it():
    """F2 rule 4 / O1: the start-up cost enters the objective exactly once, times B_ON."""
    model = _start_up_model(5000.0)
    assert model.rd_unit_status["GU_OFF"].unit_class == "startable"
    assert pyo.value(model.rd_unit_on["GU_OFF"]) == pytest.approx(1.0)
    assert pyo.value(model.rd_volume_upward["BID_OFF"]) == pytest.approx(100.0, abs=1e-6)
    assert pyo.value(model.objective_penalty_term_expressions["startup_cost"]) == pytest.approx(5000.0)
    assert pyo.value(model.objective) == pytest.approx(5000.0 + 10.0 * 100.0, abs=1e-6)


def test_an_offline_unit_without_a_start_up_cost_is_not_started():
    """F2 rule 4 (BUC 14#103 4765): no cost, no start-up; the overload stays in the slack."""
    model = _start_up_model(None)
    assert model.rd_unit_status["GU_OFF"].unit_class == "fixed_off"
    assert pyo.value(model.rd_volume_upward["BID_OFF"]) == pytest.approx(0.0, abs=1e-9)
    assert pyo.value(model.overload_slack_n0["BRANCH1"]) == pytest.approx(100.0, abs=1e-6)
    assert "startup_cost" not in model.objective_penalty_term_expressions


def test_a_start_up_needs_pmin_within_the_sum_of_the_units_upward_volumes():
    """F2 rule 12: two up bids of 30 MW each reach Pmin 50 together; one alone would not."""
    from data_model import UnitCost
    model = _on_off_model(
        [("RD_O1", "GU_OFF", P, 0.0, 50.0, 200.0, []), ("RD_O2", "GU_OFF", P, 0.0, 50.0, 200.0, []), *_PARTNER_UNITS],
        [("BID_O1", "RD_O1", UP, 30.0, 10.0, None), ("BID_O2", "RD_O2", UP, 30.0, 10.0, None), *_PARTNER_BIDS],
        {"GU_OFF": -1.0}, lf_branch=1100.0, unit_costs={"GU_OFF": UnitCost(startup_cost_eur=100.0)},
    )
    assert model.rd_unit_status["GU_OFF"].unit_class == "startable"
    assert pyo.value(model.rd_unit_on["GU_OFF"]) == pytest.approx(1.0)


def _shut_down_model(shutdown_cost, down_mw=80.0, curative=False):
    """GU_ON (PROD 80, Pmin 50, Pmax 200): 1 A/MW less on BRANCH1 (70 A overloaded) per MW
    down. Continuous it would go to 10 MW (< Pmin): the choice is Pmin (30 A relief) or 0."""
    from data_model import UnitCost
    costs = {"GU_ON": UnitCost(shutdown_cost_eur=shutdown_cost)} if shutdown_cost is not None else {}
    units = [("RD_ON", "GU_ON", P, 80.0, 50.0, 200.0, []), *_PARTNER_UNITS]
    bids = [("BID_ON", "RD_ON", DOWN, down_mw, 5.0, None), *_PARTNER_BIDS]
    nx_inputs = None
    if curative:
        units += [("RD_CUR", "GU_ON", C, 80.0, 50.0, 200.0, ["CO1"]), ("RD_CB", "GU_B", C, 500.0, 0.0, 2000.0, ["CO1"])]
        bids += [("BID_CUR", "RD_CUR", UP, 40.0, 1.0, None), ("BID_CB", "RD_CB", DOWN, 40.0, 0.0, None)]
        nx_inputs = NxMilpInputs(
            lf_nx={"CO1": {"BRANCH1": {1: 1100.0}}}, sensitivity_pst_nx={},
            sensitivity_rd_nx={"CO1": {("BRANCH1", "GU_ON"): -1.0}}, penalty_cost_overload_nx_patl=10.0,
        )
    return _on_off_model(units, bids, {"GU_ON": 1.0}, lf_branch=1070.0, unit_costs=costs, nx_inputs=nx_inputs)


def test_an_online_unit_with_a_shut_down_cost_can_be_shut_down_and_pays_it():
    """F2 rule 5 / O1: shut down (P = 0, never between 0 and Pmin) and pay the cost once."""
    model = _shut_down_model(1000.0)
    assert model.rd_unit_status["GU_ON"].unit_class == "stoppable"
    assert pyo.value(model.rd_unit_on["GU_ON"]) == pytest.approx(0.0)
    assert pyo.value(model.rd_volume_downward["BID_ON"]) == pytest.approx(80.0, abs=1e-6)
    assert pyo.value(model.objective_penalty_term_expressions["shutdown_cost"]) == pytest.approx(1000.0)


@pytest.mark.parametrize("shutdown_cost, down_mw", [(None, 80.0), (1000.0, 60.0)])
def test_no_shut_down_without_a_cost_or_when_the_down_bid_does_not_reach_zero(shutdown_cost, down_mw):
    """F2 rule 5: no cost, or PROD - max RD- > 0: the unit stays continuous at >= Pmin."""
    model = _shut_down_model(shutdown_cost, down_mw=down_mw)
    assert model.rd_unit_status["GU_ON"].unit_class == "continuous"
    assert pyo.value(model.rd_volume_downward["BID_ON"]) == pytest.approx(30.0, abs=1e-6)   # down to Pmin 50
    assert "shutdown_cost" not in model.objective_penalty_term_expressions


def test_a_curative_bid_on_a_unit_shut_down_preventively_gets_no_volume():
    """R4 / F2 rule 6: the unit is off after the preventive actions -> no curative volume."""
    model = _shut_down_model(1000.0, curative=True)
    assert pyo.value(model.rd_unit_on["GU_ON"]) == pytest.approx(0.0)
    assert pyo.value(model.curative_rd_volume_upward["BID_CUR", "CO1"]) == pytest.approx(0.0, abs=1e-9)


def test_a_curative_bid_on_a_unit_started_preventively_can_be_used():
    """R4: initially off, started by a preventive action -> the curative bid acts. N-0 needs
    60 MW on GU_OFF (start-up); CO1 needs 200 MW, of which the preventive bid gives at most 150,
    so the cheaper curative bid is used in full (40 MW) after the solve."""
    from data_model import UnitCost
    nx_inputs = NxMilpInputs(
        lf_nx={"CO1": {"BRANCH1": {1: 1200.0}}}, sensitivity_pst_nx={},
        sensitivity_rd_nx={"CO1": {("BRANCH1", "GU_OFF"): -1.0}}, penalty_cost_overload_nx_patl=1000.0,
    )
    model = _on_off_model(
        [("RD_OFF", "GU_OFF", P, 0.0, 50.0, 200.0, []), *_PARTNER_UNITS,
         ("RD_CUR", "GU_OFF", C, 0.0, 50.0, 200.0, ["CO1"]), ("RD_CB", "GU_B", C, 500.0, 0.0, 2000.0, ["CO1"])],
        [("BID_OFF", "RD_OFF", UP, 150.0, 10.0, None), *_PARTNER_BIDS,
         ("BID_CUR", "RD_CUR", UP, 40.0, 1.0, None), ("BID_CB", "RD_CB", DOWN, 40.0, 0.0, None)],
        {"GU_OFF": -1.0}, lf_branch=1060.0, unit_costs={"GU_OFF": UnitCost(startup_cost_eur=100.0)},
        nx_inputs=nx_inputs,
    )
    assert pyo.value(model.rd_unit_on["GU_OFF"]) == pytest.approx(1.0)
    assert not model.curative_rd_volume_upward["BID_CUR", "CO1"].fixed
    assert ("BID_CUR", "CO1") in set(model.curative_rd_unit_gate_index)
    assert model.curative_rd_gating_units["BID_CUR"] == ["GU_OFF"]
    assert pyo.value(model.curative_rd_volume_upward["BID_CUR", "CO1"]) == pytest.approx(40.0, abs=1e-6)
    assert pyo.value(model.curative_rd_volume_upward["BID_CUR", "CO1"]) > 0.0


@pytest.mark.parametrize("pmin", [0.0, -100.0])
def test_a_connected_unit_at_zero_with_pmin_at_most_zero_is_on_and_continuous(pmin):
    """F2 rule 1 / 3, R4: PROD 0 with Pmin <= 0 counts as on (curative allowed), no binary."""
    rd_inputs = _base_rd_inputs_r36(target_p=0.0, min_p=pmin)
    nx_inputs = NxMilpInputs(
        lf_nx={"CO1": {"BRANCH1": {1: 900.0}}}, sensitivity_pst_nx={},
        sensitivity_rd_nx={"CO1": {("BRANCH1", "GU1"): 0.3}}, penalty_cost_overload_nx_patl=500.0,
    )
    model = build_n0_milp_model(
        [_make_ae_r36("BRANCH1")], "1030Z", lf_initial={"BRANCH1": {1: 500.0}},
        penalty_cost_overload_n0=1000.0, rd_inputs=rd_inputs, nx_inputs=nx_inputs,
    )
    assert not model.curative_rd_volume_upward["BID1", "CO1"].fixed
    status = model.rd_unit_status if hasattr(model, "rd_unit_status") else None
    from milp.milp_builder import _rd_unit_status
    unit = (status or _rd_unit_status(rd_inputs, "1030Z"))["GU1"]
    assert unit.initially_on and unit.unit_class == "continuous"


def test_a_running_unit_below_pmin_gets_pmin_set_to_its_production(caplog):
    """F2 rule 11: Pmin > 0 and 0 < PROD < Pmin -> Pmin := PROD (one log line); no forced move."""
    with caplog.at_level(logging.INFO):
        model = _on_off_model(
            [("RD_LOW", "GU_LOW", P, 30.0, 50.0, 200.0, []), *_PARTNER_UNITS],
            [("BID_LOW", "RD_LOW", UP, 100.0, 10.0, None), *_PARTNER_BIDS],
            {}, lf_branch=500.0,
        )
    assert model.rd_unit_status["GU_LOW"].pmin_mw == pytest.approx(30.0)
    assert pyo.value(model.rd_volume_upward["BID_LOW"]) == pytest.approx(0.0, abs=1e-9)
    assert sum("Pmin set to PROD" in r.getMessage() and "GU_LOW" in r.getMessage() for r in caplog.records) == 1


def test_unit_3a3b27be_keeps_its_negative_pmin():
    """F2 rule 11 regression: PROD 52.8 and Pmin -100 (real unit 3a3b27be) is not adjusted."""
    from milp.milp_builder import _rd_unit_status
    rd_inputs = RdMilpInputs(
        rd_list=[_make_rd_unit_r36("RD1", "3a3b27be")],
        bid_list=[_make_bid_r36("BID1", "RD1", BidDirection.UP, {"1030Z": 40.0})],
        glsk={"RD1": {"3a3b27be": 1.0}}, sensitivity_rd_n0_pruned={},
        generator_data={"3a3b27be": {"target_p": 52.8181, "max_p": 200.0, "min_p": -100.0, "connected": True}},
    )
    unit = _rd_unit_status(rd_inputs, "1030Z")["3a3b27be"]
    assert unit.pmin_mw == -100.0 and unit.unit_class == "continuous" and unit.initially_on


def _single_unit_status(prod, pmin, pmax=200.0):
    from milp.milp_builder import _rd_unit_status
    rd_inputs = RdMilpInputs(
        rd_list=[_make_rd_unit_r36("RD1", "GU1")],
        bid_list=[_make_bid_r36("BID1", "RD1", BidDirection.UP, {"1030Z": 40.0})],
        glsk={"RD1": {"GU1": 1.0}}, sensitivity_rd_n0_pruned={},
        generator_data={"GU1": {"target_p": prod, "max_p": pmax, "min_p": pmin, "connected": True}},
    )
    return _rd_unit_status(rd_inputs, "1030Z")["GU1"]


def test_a_production_of_1e_9_mw_counts_as_zero(caplog):
    """F2 rule 1 [review]: |PROD| <= 1e-6 MW is 0: the unit with Pmin > 0 is off (no start-up
    cost: fixed off) and its Pmin is not set to PROD."""
    from milp import milp_builder
    milp_builder.reset_run_log_state()
    with caplog.at_level(logging.INFO):
        unit = _single_unit_status(prod=1e-9, pmin=50.0)
    assert not unit.initially_on and unit.unit_class == "fixed_off"
    assert unit.pmin_mw == 50.0 and unit.original_p_mw == 0.0
    assert not any("Pmin set to PROD" in r.getMessage() for r in caplog.records)


def test_a_unit_with_pmin_above_pmax_gives_a_warning_naming_it(caplog):
    """F2 rule 3 [review]: Pmin > Pmax is warned about at build time, naming the unit."""
    from milp import milp_builder
    milp_builder.reset_run_log_state()
    with caplog.at_level(logging.WARNING):
        _single_unit_status(prod=80.0, pmin=150.0, pmax=100.0)
    assert any("GU1" in r.getMessage() and "above Pmax" in r.getMessage()
               for r in caplog.records if r.levelno == logging.WARNING)


def test_a_preventive_bid_with_an_empty_glsk_has_volume_zero():
    """F2 rule 13 [review]: a preventive bid whose GLSK is empty (e.g. all units unconnected)
    gets both upper bounds 0, even with price 0 (no free, meaningless volume)."""
    model = _on_off_model(
        [("RD_A", "GU_A", P, 100.0, 0.0, 200.0, []), *_PARTNER_UNITS],
        [("BID_A", "RD_A", UP, 50.0, 0.0, None), *_PARTNER_BIDS],
        {}, lf_branch=500.0, glsk_override={"RD_A": {}},
    )
    assert model.rd_volume_upward["BID_A"].ub == 0.0 and model.rd_volume_downward["BID_A"].ub == 0.0
    assert pyo.value(model.rd_volume_upward["BID_A"]) == pytest.approx(0.0, abs=1e-9)


def test_the_reported_original_network_has_no_shut_down_cost():
    """F2 rule 14 [review]: the non-convergent path reports the original network
    (describe_original_network): a unit that is initially on is on there, so
    sum_shutdown_cost_eur is 0 although the solve shut the unit down."""
    from milp.ac_convergence_loop import describe_original_network
    from post_milp.n0_results_export import extract_results_summary
    model = _shut_down_model(1000.0)
    assert pyo.value(model.rd_unit_on["GU_ON"]) == pytest.approx(0.0)      # the solve shut it down
    describe_original_network(model)
    assert pyo.value(model.rd_unit_on["GU_ON"]) == 1
    summary = extract_results_summary(model, objective_value=pyo.value(model.objective))
    assert summary["sum_shutdown_cost_eur"] == 0.0
    assert summary["sum_startup_cost_eur"] == 0.0


def test_the_log_lines_are_written_again_after_a_run_reset(caplog):
    """F2 rule 15 [review]: the once-per-run log lines (here Pmin := PROD and the reservePrice
    fallback) are not repeated within a run, and are written again after reset_run_log_state
    (run_pipeline.main calls it at the start of every run)."""
    from milp import milp_builder

    def lines():
        caplog.clear()
        with caplog.at_level(logging.INFO):
            _single_unit_status(prod=30.0, pmin=50.0)
            milp_builder.curative_rd_reservation_price_eur_mw(_make_bid_r36("BID_LOG", "RD1", UP, {"1030Z": 1.0}))
        messages = [r.getMessage() for r in caplog.records]
        return (sum("Pmin set to PROD" in m for m in messages),
                sum("has no reservePrice" in m and "BID_LOG" in m for m in messages))

    milp_builder.reset_run_log_state()
    assert lines() == (1, 1)
    assert lines() == (0, 0)          # same run: not repeated
    milp_builder.reset_run_log_state()
    assert lines() == (1, 1)          # next run: written again


@pytest.mark.parametrize("direction", [UP, DOWN])
def test_a_bid_with_an_activation_cost_pays_it_once_when_used(direction):
    """O1 / BUC 14#102: activation cost x B_act, once, for a used bid (either direction)."""
    sign = -1.0 if direction == UP else 1.0
    model = _on_off_model(
        [("RD_A", "GU_A", P, 100.0, 0.0, 200.0, []), *_PARTNER_UNITS],
        [("BID_A", "RD_A", direction, 50.0, 2.0, 300.0), *_PARTNER_BIDS],
        {"GU_A": sign}, lf_branch=1020.0,
    )
    used = pyo.value(model.rd_volume_upward["BID_A"] + model.rd_volume_downward["BID_A"])
    assert used == pytest.approx(20.0, abs=1e-6)
    assert pyo.value(model.objective_penalty_term_expressions["bid_activation_cost"]) == pytest.approx(300.0)


def test_an_unused_bid_pays_no_activation_cost_and_a_zero_cost_bid_has_no_binary():
    model = _on_off_model(
        [("RD_A", "GU_A", P, 100.0, 0.0, 200.0, []), *_PARTNER_UNITS],
        [("BID_A", "RD_A", UP, 50.0, 2.0, 300.0), *_PARTNER_BIDS],
        {"GU_A": -1.0}, lf_branch=500.0,   # no overload: the bid is not used
    )
    assert pyo.value(model.objective_penalty_term_expressions["bid_activation_cost"]) == pytest.approx(0.0, abs=1e-9)
    assert list(model.rd_activation_bid_ids) == ["BID_A"]     # the partner bids (cost None / 0) have none


def test_the_summary_csv_reports_shut_down_and_activation_costs_and_the_identity_holds(tmp_path):
    """O1 reporting: a shut-down (cost 1000) by a bid with an activation cost (300): both sums
    are non-zero in results_summary.csv and the objective residual is 0."""
    from data_model import UnitCost
    from post_milp.n0_results_export import extract_rd_results, extract_results_summary, write_results_summary_csv
    model = _on_off_model(
        [("RD_ON", "GU_ON", P, 80.0, 50.0, 200.0, []), *_PARTNER_UNITS],
        [("BID_ON", "RD_ON", DOWN, 80.0, 5.0, 300.0), *_PARTNER_BIDS],
        {"GU_ON": 1.0}, lf_branch=1070.0, unit_costs={"GU_ON": UnitCost(shutdown_cost_eur=1000.0)},
    )
    rd_inputs = model.test_rd_inputs
    rd_results = extract_rd_results(model, rd_inputs.rd_list, rd_inputs.bid_list, 0.0,
                                    AcVerificationStatus.CONVERGED, "stable")
    path = tmp_path / "results_summary.csv"
    write_results_summary_csv(
        extract_results_summary(model, objective_value=pyo.value(model.objective), rd_results=rd_results), path,
    )
    import csv
    with open(path, newline="", encoding=TEXT_ENCODING) as f:
        summary = {row["metric"]: row["value"] for row in csv.DictReader(f)}
    assert float(summary["sum_shutdown_cost_eur"]) == pytest.approx(1000.0)
    assert float(summary["sum_bid_activation_cost_eur"]) == pytest.approx(300.0)
    assert float(summary["sum_startup_cost_eur"]) == 0.0
    assert float(summary["objective_residual_eur"]) == pytest.approx(0.0, abs=1e-6)


def _multi_unit_curative_model(prod_x, prod_y, startup_cost):
    """A curative up bid (40 MW) on GLSK {GU_X 0.5, GU_Y 0.5} relieves BRANCH1 under CO1 (1100 A,
    PATL 1000 A) by 1 A/MW, with a free curative down partner on GU_B. GU_X and GU_Y: Pmin 20,
    Pmax 100, each with a preventive up bid (100 MW, 100 EUR/MW: dearer than the 10 EUR/A it would
    save under CO1) that could start it, and the given start-up cost (None: none); no N-0
    overload, so neither a start-up nor a preventive move pays."""
    from data_model import UnitCost
    costs = ({gu: UnitCost(startup_cost_eur=startup_cost) for gu in ("GU_X", "GU_Y")}
             if startup_cost is not None else {})
    nx_inputs = NxMilpInputs(
        lf_nx={"CO1": {"BRANCH1": {1: 1100.0}}}, sensitivity_pst_nx={},
        sensitivity_rd_nx={"CO1": {("BRANCH1", "GU_X"): -1.0, ("BRANCH1", "GU_Y"): -1.0}},
        penalty_cost_overload_nx_patl=10.0,
    )
    return _on_off_model(
        [("RD_PX", "GU_X", P, prod_x, 20.0, 100.0, []), ("RD_PY", "GU_Y", P, prod_y, 20.0, 100.0, []),
         ("RD_CM", "GU_X", C, prod_x, 20.0, 100.0, ["CO1"]), *_PARTNER_UNITS,
         ("RD_CB", "GU_B", C, 500.0, 0.0, 2000.0, ["CO1"])],
        [("BID_PX", "RD_PX", UP, 100.0, 100.0, None), ("BID_PY", "RD_PY", UP, 100.0, 100.0, None),
         ("BID_CM", "RD_CM", UP, 40.0, 1.0, None), *_PARTNER_BIDS, ("BID_CB", "RD_CB", DOWN, 40.0, 0.0, None)],
        {}, lf_branch=500.0, unit_costs=costs, nx_inputs=nx_inputs,
        glsk_override={"RD_CM": {"GU_X": 0.5, "GU_Y": 0.5}},
    )


@pytest.mark.parametrize("prod_x, prod_y, startup_cost, fixed, volume", [
    (50.0, 50.0, 1e6, False, 40.0),   # both on: allowed and used in full
    (50.0, 0.0, 1e6, False, 0.0),     # one on: the gate allows it, GU_Y's R7 row (off) keeps its share 0
    (0.0, 0.0, 1e6, False, 0.0),      # none on (both could be started, neither is): gate sum of binaries = 0
    (0.0, 0.0, None, True, 0.0),      # none on and neither can be started: blocked statically
])
def test_a_multi_unit_curative_bid_acts_if_at_least_one_unit_is_on_initially(prod_x, prod_y, startup_cost, fixed, volume):
    """R4 rule 5 (multi-unit curative): allowed if at least one unit of the GLSK is on after the
    preventive actions (volume <= available x sum of the on/off binaries, a continuous unit
    that is on counting 1), 0 if none is. Solved, asserted on the result."""
    model = _multi_unit_curative_model(prod_x, prod_y, startup_cost)
    assert model.curative_rd_volume_upward["BID_CM", "CO1"].fixed is fixed
    assert pyo.value(model.curative_rd_volume_upward["BID_CM", "CO1"]) == pytest.approx(volume, abs=1e-6)
    assert pyo.value(model.nx_patl_overload_slack["BRANCH1", "CO1"]) == pytest.approx(100.0 - volume, abs=1e-6)
    if prod_x == 0.0 and startup_cost is not None:
        assert model.curative_rd_gating_units["BID_CM"] == ["GU_X", "GU_Y"]
        assert pyo.value(model.rd_unit_on["GU_X"]) + pyo.value(model.rd_unit_on["GU_Y"]) == pytest.approx(0.0)


def test_the_curative_gate_row_alone_keeps_a_multi_unit_bid_whose_units_are_all_off_at_zero():
    """R4 rule 5 [review]: BID_CM {GU_X 0.5, GU_Y 0.5}, both units off (startable, not started):
    the gate row volume <= 40 x (u_X + u_Y) exists and binds at 0. The per-unit R7 rows of the
    two off units would also hold the bid at 0 (the gate is redundant with them for a bid whose
    units are all off), so they are switched off here: the gate alone keeps the volume at 0, and
    without the gate the bid is used (40 MW)."""
    model = _multi_unit_curative_model(0.0, 0.0, 1e6)
    gate = model.curative_rd_unit_gate["BID_CM", "CO1"]
    assert model.curative_rd_gating_units["BID_CM"] == ["GU_X", "GU_Y"]
    for name in ("curative_on_off_lower", "curative_on_off_upper",
                 "curative_on_off_up_maxima", "curative_on_off_down_maxima"):
        for unit in ("GU_X", "GU_Y"):
            getattr(model, name)[unit].deactivate()
    solver = pyo.SolverFactory("appsi_highs")
    assert str(solver.solve(model).solver.termination_condition) == "optimal"
    assert pyo.value(model.rd_unit_on["GU_X"]) + pyo.value(model.rd_unit_on["GU_Y"]) == pytest.approx(0.0)
    assert pyo.value(model.curative_rd_volume_upward["BID_CM", "CO1"]) == pytest.approx(0.0, abs=1e-9)
    assert pyo.value(gate.body) == pytest.approx(pyo.value(gate.upper), abs=1e-9)     # binding
    gate.deactivate()
    assert str(solver.solve(model).solver.termination_condition) == "optimal"
    assert pyo.value(model.curative_rd_volume_upward["BID_CM", "CO1"]) == pytest.approx(40.0, abs=1e-6)


def test_up_and_down_curative_bids_cannot_cancel_on_an_off_unit():
    """F2 rule 7 [review] (cancellation): up bid X {A 0.5, B 0.5} under CO1 and down bid Y {B 0.5,
    C 0.5} under CO2, A and C on, B off (startable, not started). The net R7 row of B alone
    allows M_X = M_Y (B +20 MW in CO1, -20 MW in CO2); the one-sided rows hold both maxima at 0,
    so X and Y are not used. Without the one-sided rows both would be used in full."""
    from data_model import UnitCost
    both = ["CO1", "CO2"]
    nx_inputs = NxMilpInputs(
        lf_nx={c: {"BRANCH1": {1: 1100.0}} for c in both}, sensitivity_pst_nx={},
        sensitivity_rd_nx={"CO1": {("BRANCH1", "GU_A"): -1.0, ("BRANCH1", "GU_OFF"): -1.0},
                           "CO2": {("BRANCH1", "GU_C"): 1.0, ("BRANCH1", "GU_OFF"): 1.0}},
        penalty_cost_overload_nx_patl=10.0,
    )
    model = _on_off_model(
        [("RD_PA", "GU_A", P, 50.0, 0.0, 200.0, []), ("RD_POFF", "GU_OFF", P, 0.0, 20.0, 100.0, []),
         ("RD_PC", "GU_C", P, 50.0, 0.0, 200.0, []), *_PARTNER_UNITS,
         ("RD_X", "GU_A", C, 50.0, 0.0, 200.0, ["CO1"]), ("RD_Y", "GU_C", C, 50.0, 0.0, 200.0, ["CO2"]),
         ("RD_CBU", "GU_B", C, 500.0, 0.0, 2000.0, both), ("RD_CBD", "GU_B", C, 500.0, 0.0, 2000.0, both)],
        [("BID_POFF", "RD_POFF", UP, 100.0, 100.0, None), *_PARTNER_BIDS,
         ("BID_X", "RD_X", UP, 40.0, 1.0, None), ("BID_Y", "RD_Y", DOWN, 40.0, 1.0, None),
         ("BID_CBU", "RD_CBU", UP, 100.0, 0.0, None), ("BID_CBD", "RD_CBD", DOWN, 100.0, 0.0, None)],
        {}, lf_branch=500.0, unit_costs={"GU_OFF": UnitCost(startup_cost_eur=1e6)}, nx_inputs=nx_inputs,
        glsk_override={"RD_X": {"GU_A": 0.5, "GU_OFF": 0.5}, "RD_Y": {"GU_OFF": 0.5, "GU_C": 0.5}},
    )
    assert model.rd_unit_status["GU_OFF"].unit_class == "startable"
    assert pyo.value(model.rd_unit_on["GU_OFF"]) == pytest.approx(0.0)
    assert pyo.value(model.curative_rd_volume_upward["BID_X", "CO1"]) == pytest.approx(0.0, abs=1e-9)
    assert pyo.value(model.curative_rd_volume_downward["BID_Y", "CO2"]) == pytest.approx(0.0, abs=1e-9)
    up_row, down_row = model.curative_on_off_up_maxima["GU_OFF"], model.curative_on_off_down_maxima["GU_OFF"]
    for row in (up_row, down_row):                                    # exist and bind (0 <= Pmax x 0)
        assert pyo.value(row.body) == pytest.approx(pyo.value(row.upper), abs=1e-9)
    assert set(model.curative_on_off_up_maxima) == {"GU_OFF"}         # only units with a binary
    # the same model without the one-sided rows: the net row alone lets X and Y cancel on GU_OFF
    up_row.deactivate()
    down_row.deactivate()
    assert str(pyo.SolverFactory("appsi_highs").solve(model).solver.termination_condition) == "optimal"
    assert pyo.value(model.rd_unit_on["GU_OFF"]) == pytest.approx(0.0)
    assert pyo.value(model.curative_rd_volume_upward["BID_X", "CO1"]) == pytest.approx(40.0, abs=1e-6)
    assert pyo.value(model.curative_rd_volume_downward["BID_Y", "CO2"]) == pytest.approx(40.0, abs=1e-6)


# ---------------------------------------------------------------------------
# F2 rule 9: on/off binaries per unit inside multi-unit bids
# ---------------------------------------------------------------------------

def _multi_unit_preventive_model(startup_cost, lf_branch, bid_mw=100.0, single_bid_mw=None, sensitivity=None):
    """A preventive up bid BID_M (bid_mw, 10 EUR/MW) on GLSK {GU_MA 0.5, GU_MB 0.5}: GU_MA runs
    (PROD 100, Pmin 0), GU_MB is off (PROD 0, Pmin 20, Pmax 100) with the given start-up cost.
    single_bid_mw: also a single-unit up bid BID_SB on GU_MB. BRANCH1 (PATL 1000 A) carries
    lf_branch A; by default each MW of BID_M relieves 1 A (both units -1 A/MW)."""
    from data_model import UnitCost
    units = [("RD_M", "GU_MA", P, 100.0, 0.0, 500.0, []), ("RD_MB", "GU_MB", P, 0.0, 20.0, 100.0, []),
             *_PARTNER_UNITS]
    bids = [("BID_M", "RD_M", UP, bid_mw, 10.0, None), *_PARTNER_BIDS]
    if single_bid_mw is not None:
        bids.append(("BID_SB", "RD_MB", UP, single_bid_mw, 10.0, None))
    return _on_off_model(
        units, bids, sensitivity or {"GU_MA": -1.0, "GU_MB": -1.0}, lf_branch=lf_branch,
        unit_costs={"GU_MB": UnitCost(startup_cost_eur=startup_cost)} if startup_cost is not None else {},
        glsk_override={"RD_M": {"GU_MA": 0.5, "GU_MB": 0.5}},
    )


@pytest.mark.parametrize("startup_cost, lf_branch, volume", [
    (500.0, 1010.0, 40.0),     # 10 A over: 10 MW would do, but B on needs 0.5 v >= 20 -> 40 MW and the start-up
    (500.0, 1060.0, 60.0),     # 60 A over: 60 MW, B on at 30 MW
    (1e7, 1010.0, 0.0),        # start-up too expensive: 0, never 10 MW (B would be between 0 and Pmin)
])
def test_a_multi_unit_bid_with_an_off_unit_is_0_or_at_least_pmin_over_the_factor(startup_cost, lf_branch, volume):
    """F2 rule 9 (multi-unit): GLSK {A 0.5, B 0.5}, B off with Pmin 20 and a start-up cost: the
    bid volume is 0 or at least 40 MW; with >= 40 MW B is started and pays its start-up cost once."""
    model = _multi_unit_preventive_model(startup_cost, lf_branch)
    assert model.rd_unit_status["GU_MB"].unit_class == "startable"
    v = pyo.value(model.rd_volume_upward["BID_M"])
    assert v == pytest.approx(volume, abs=1e-6)
    assert v < 1e-6 or v >= 40.0 - 1e-6
    started = pyo.value(model.rd_unit_on["GU_MB"])
    assert started == pytest.approx(1.0 if volume else 0.0)
    assert pyo.value(model.objective_penalty_term_expressions["startup_cost"]) == pytest.approx(startup_cost * started)


def test_a_multi_unit_bid_with_an_off_unit_without_a_start_up_cost_is_0_and_feasible():
    """F2 rule 9 (multi-unit): no start-up cost for B -> B cannot be started, the bid is blocked,
    the model solves (before: B forced up to Pmin, or infeasible) and the overload stays."""
    model = _multi_unit_preventive_model(None, 1060.0)
    assert model.rd_unit_status["GU_MB"].unit_class == "fixed_off"
    assert pyo.value(model.rd_volume_upward["BID_M"]) == pytest.approx(0.0, abs=1e-9)
    assert pyo.value(model.overload_slack_n0["BRANCH1"]) == pytest.approx(60.0, abs=1e-6)


def test_a_unit_in_a_single_and_a_multi_unit_bid_is_judged_on_both_injections():
    """F2 rule 9 (multi-unit): B is in BID_SB (alone, 15 MW) and BID_M ({A 0.5, B 0.5}, 20 MW): only
    together (15 + 10 >= Pmin 20) can B be started. Only B relieves BRANCH1 (22 A over): B is
    started on both bids and the start-up cost is charged once."""
    from pyomo.core.expr.visitor import identify_variables
    model = _multi_unit_preventive_model(100.0, 1022.0, bid_mw=20.0, single_bid_mw=15.0,
                                         sensitivity={"GU_MB": -1.0})
    assert model.rd_unit_status["GU_MB"].unit_class == "startable"
    lower_row = {v.name for v in identify_variables(model.rd_unit_on_lower["GU_MB"].body)}
    assert {"rd_volume_upward[BID_SB]", "rd_volume_upward[BID_M]"} <= lower_row
    assert pyo.value(model.rd_unit_on["GU_MB"]) == pytest.approx(1.0)
    output = pyo.value(model.rd_unit_output_after_preventive["GU_MB"])
    assert output == pytest.approx(pyo.value(model.rd_volume_upward["BID_SB"]) + 0.5 * pyo.value(model.rd_volume_upward["BID_M"]))
    assert output >= 22.0 - 1e-6
    assert pyo.value(model.objective_penalty_term_expressions["startup_cost"]) == pytest.approx(100.0)


def test_a_multi_unit_bid_whose_share_cannot_reach_pmin_is_blocked_with_one_log_line(caplog):
    """F2 rule 9 static check: GLSK {A 0.5, B 0.5}, B off with Pmin 20, bid 30 MW: B gets at most
    15 MW, so the bid is blocked before the solve, the model is feasible and one log line names
    unit B and the reason."""
    from milp import milp_builder
    milp_builder.reset_run_log_state()
    with caplog.at_level(logging.INFO):
        model = _multi_unit_preventive_model(500.0, 1060.0, bid_mw=30.0)
    assert model.rd_unit_status["GU_MB"].unit_class == "fixed_off"
    assert model.rd_volume_upward["BID_M"].ub == 0.0
    assert pyo.value(model.rd_volume_upward["BID_M"]) == pytest.approx(0.0, abs=1e-9)
    lines = [r.getMessage() for r in caplog.records if "BID_M" in r.getMessage() and "blocked" in r.getMessage()]
    assert len(lines) == 1
    assert "GU_MB" in lines[0] and "Pmin unreachable within the bid volume" in lines[0]


def test_the_curative_balance_holds_for_a_bid_the_reaction_time_filter_keeps_off_a_branch():
    """R15 rule 4: BID1 (15 min) is off BRANCH_A's constraint (TATL 10 min) and on BRANCH_B's
    (20 min); its volume still enters the per-contingency balance, which holds in the solve."""
    from pyomo.core.expr.visitor import identify_variables
    model = _reaction_time_model(15.0, {"BRANCH_A": 600, "BRANCH_B": 1200})
    assert not _bid_acts_on(model, "BRANCH_A") and _bid_acts_on(model, "BRANCH_B")
    balance_variables = {v.name for v in identify_variables(model.curative_rd_balancing["CO1"].body)}
    assert "curative_rd_volume_upward[BID1,CO1]" in balance_variables
    assert str(pyo.SolverFactory("appsi_highs").solve(model).solver.termination_condition) == "optimal"
    up = pyo.value(model.curative_rd_volume_upward["BID1", "CO1"])
    assert up > 1e-6                                    # used for BRANCH_B
    assert pyo.value(model.curative_rd_volume_downward["BID_BAL", "CO1"]) == pytest.approx(up, abs=1e-6)


# ---------------------------------------------------------------------------
# R7 (CORNET-4614): per-unit Pmin/Pmax with the exact curative maxima
# ---------------------------------------------------------------------------

def _r7_model(curative_bids, preventive_up_mw=20.0):
    """GU_X: PROD 100, Pmin 50, Pmax 150, a preventive up bid fixed at preventive_up_mw
    (balanced by GU_B). curative_bids: [(bid, direction, {contingency: MW fixed})] on GU_X,
    balanced by a free curative partner on GU_BAL. No objective incentive: only feasibility."""
    contingencies = sorted({c for _b, _d, volumes in curative_bids for c in volumes})
    units = [("RD_PX", "GU_X", P, 100.0, 50.0, 150.0, []), *_PARTNER_UNITS]
    bids = [("BID_PX", "RD_PX", UP, 100.0, 0.0, None), *_PARTNER_BIDS]
    for bid_mrid, direction, volumes in curative_bids:
        units.append((f"RA_{bid_mrid}", "GU_X", C, 100.0, 50.0, 150.0, sorted(volumes)))
        bids.append((bid_mrid, f"RA_{bid_mrid}", direction, 100.0, 0.0, None))
    units += [("RD_CBU", "GU_BAL", C, 500.0, 0.0, 2000.0, contingencies),
              ("RD_CBD", "GU_BAL", C, 500.0, 0.0, 2000.0, contingencies)]
    bids += [("BID_CBU", "RD_CBU", UP, 500.0, 0.0, None), ("BID_CBD", "RD_CBD", DOWN, 500.0, 0.0, None)]
    rd_list = [
        RDUnit(mrid=ra, name=ra, tso="TestTSO", gu_mrid=gu, gu_name=gu, available=True, kind=kind,
               initial_p=p, max_p=pmax, min_p=pmin, raise_ramp_rate=None, lower_ramp_rate=None,
               penalty_factor=0.0, linked_contingency_mrids=list(cos))
        for ra, gu, kind, p, pmin, pmax, cos in units
    ]
    bid_list = []
    for bid_mrid, ra, direction, mw, price, _activation in bids:
        bid = _make_bid_r36(bid_mrid, ra, direction, {"1030Z": mw})
        bid.price_eur_mw = price
        bid_list.append(bid)
    gus = {gu: (p, pmin, pmax) for _ra, gu, _k, p, pmin, pmax, _c in units}
    rd_inputs = RdMilpInputs(
        rd_list=rd_list, bid_list=bid_list, glsk={ra: {gu: 1.0} for ra, gu, *_ in units},
        sensitivity_rd_n0_pruned={},
        generator_data={gu: {"target_p": p, "max_p": pmax, "min_p": pmin} for gu, (p, pmin, pmax) in gus.items()},
        penalty_reference_rd_pra=0.0,
    )
    nx_inputs = NxMilpInputs(
        lf_nx={c: {"BRANCH1": {1: 500.0}} for c in contingencies}, sensitivity_pst_nx={},
        sensitivity_rd_nx={c: {} for c in contingencies}, penalty_cost_overload_nx_patl=1.0,
    )
    model = build_n0_milp_model(
        [_make_ae_r36("BRANCH1", patl_ka=1.0)], "1030Z", lf_initial={"BRANCH1": {1: 500.0}},
        penalty_cost_overload_n0=1.0, rd_inputs=rd_inputs, nx_inputs=nx_inputs,
    )
    model.rd_volume_upward["BID_PX"].fix(preventive_up_mw)
    for bid_mrid, direction, volumes in curative_bids:
        variable = model.curative_rd_volume_upward if direction == UP else model.curative_rd_volume_downward
        for co, mw in volumes.items():
            variable[bid_mrid, co].fix(mw)
    return model


def test_the_spec_example_is_rejected_by_the_per_unit_constraint():
    """R7 worked example: 100 + 20 preventive; bid X up 25 (c1) / 5 (c2), bid Y up 0 (c1) /
    20 (c2): 120 + 25 + 20 = 165 > Pmax 150 -> infeasible. Per contingency it would have
    been 145 and 140 (accepted)."""
    plan = [("X", UP, {"c1": 25.0, "c2": 5.0}), ("Y", UP, {"c1": 0.0, "c2": 20.0})]
    model = _r7_model(plan)
    assert _termination(model) != "optimal"
    # the cause is the per-unit R7 row of GU_X: without it the same plan solves ...
    model = _r7_model(plan)
    model.curative_pmax_pmin_constraint["GU_X"].deactivate()
    assert _termination(model) == "optimal"
    # ... and so does the plan without the preventive +20 (100 + 25 + 20 = 145 <= 150)
    assert _termination(_r7_model(plan, preventive_up_mw=0.0)) == "optimal"


@pytest.mark.parametrize("c1_mw, feasible", [(25.0, True), (35.0, False)])
def test_a_single_bid_on_a_unit_gives_the_per_contingency_result(c1_mw, feasible):
    """One bid on the unit: sum of maxima = its own maximum = the worst contingency, so the
    per-unit row accepts exactly what the per-contingency rows accepted (120 + 25 <= 150,
    120 + 35 > 150)."""
    model = _r7_model([("X", UP, {"c1": c1_mw, "c2": 5.0})])
    assert (_termination(model) == "optimal") is feasible


def test_the_curative_maxima_cannot_be_inflated():
    """R7 rule 4: with the volumes fixed and the objective replaced by 'maximise every max
    variable' (cost 0 on the max), each max equals its bid's largest volume over the
    contingencies, and the inactive direction stays 0."""
    model = _r7_model([("X", UP, {"c1": 25.0, "c2": 5.0}), ("Y", DOWN, {"c1": 0.0, "c2": 10.0, "c3": 4.0})])
    model.objective.deactivate()
    model.inflate = pyo.Objective(
        expr=sum(model.max_curative_rd_volume_upward[b] + model.max_curative_rd_volume_downward[b]
                 for b in model.bid_ids_curative),
        sense=pyo.maximize,
    )
    assert _termination(model) == "optimal"
    pyo.SolverFactory("appsi_highs").solve(model)
    assert pyo.value(model.max_curative_rd_volume_upward["X"]) == pytest.approx(25.0, abs=1e-6)
    assert pyo.value(model.max_curative_rd_volume_downward["X"]) == pytest.approx(0.0, abs=1e-9)
    assert pyo.value(model.max_curative_rd_volume_downward["Y"]) == pytest.approx(10.0, abs=1e-6)
    assert pyo.value(model.max_curative_rd_volume_upward["Y"]) == pytest.approx(0.0, abs=1e-9)


def test_one_binary_per_contingency_of_a_bid_with_several_and_none_for_a_single_one():
    """R7 rule 7: binaries only for bids with more than one contingency, one per contingency."""
    model = _r7_model([("X", UP, {"c1": 1.0, "c2": 1.0, "c3": 1.0}), ("Y", UP, {"c1": 1.0})])
    assert sorted(model.curative_max_choice_pairs) == [("BID_CBD", "c1"), ("BID_CBD", "c2"), ("BID_CBD", "c3"),
                                                       ("BID_CBU", "c1"), ("BID_CBU", "c2"), ("BID_CBU", "c3"),
                                                       ("X", "c1"), ("X", "c2"), ("X", "c3")]
    assert list(model.curative_single_contingency_bid_ids) == ["Y"]


def test_a_negative_participation_factor_is_an_error_naming_the_unit():
    """R7 rule 5 [review]: the run stops with an error naming the RA and the unit."""
    rd_inputs = _base_rd_inputs_r36()
    rd_inputs.glsk = {"RD1": {"GU1": -0.5}}
    with pytest.raises(ValueError, match="RD1.*GU1.*negative participation factor"):
        build_n0_milp_model(
            [_make_ae_r36("BRANCH1")], "1030Z", lf_initial={"BRANCH1": {1: 500.0}},
            penalty_cost_overload_n0=1000.0, rd_inputs=rd_inputs,
        )


# ---------------------------------------------------------------------------
# Curative RD MILP block — synthetic
# ---------------------------------------------------------------------------

def _base_rd_inputs_r36(kind=RAKind.CURATIVE, linked_contingency_mrids=None, target_p=50.0, min_p=0.0):
    return RdMilpInputs(
        rd_list=[_make_rd_unit_r36("RD1", "GU1", kind=kind, linked_contingency_mrids=linked_contingency_mrids or ["CO1"])],
        bid_list=[_make_bid_r36("BID1", "RD1", BidDirection.UP, {"1030Z": 40.0})],
        glsk={"RD1": {"GU1": 1.0}},
        sensitivity_rd_n0_pruned={},
        generator_data={"GU1": {"target_p": target_p, "max_p": 100.0, "min_p": min_p}},
        penalty_reference_rd_pra=10.0,
    )


def test_curative_rd_gated_independently_of_preventive_rd_success():
    """rd_inputs with ONLY a curative bid (_add_rd_block's empty-bid guard returns False) and
    nx_inputs: the curative RD variables still exist (gated only on rd_inputs)."""
    ae_list = [_make_ae_r36("BRANCH1")]
    rd_inputs = _base_rd_inputs_r36()
    nx_inputs = NxMilpInputs(
        lf_nx={"CO1": {"BRANCH1": {1: 900.0}}},
        sensitivity_pst_nx={},
        sensitivity_rd_nx={"CO1": {("BRANCH1", "GU1"): 0.3}},
        penalty_cost_overload_nx_patl=500.0,
    )

    model = build_n0_milp_model(
        ae_list, "1030Z", lf_initial={"BRANCH1": {1: 500.0}},
        penalty_cost_overload_n0=1000.0, rd_inputs=rd_inputs, nx_inputs=nx_inputs,
    )

    assert not hasattr(model, "rd_volume_upward")  # preventive block never fired (no preventive bids)
    assert hasattr(model, "curative_rd_volume_upward")
    assert ("BID1", "CO1") in list(model.curative_bid_contingency_pairs)


def _three_contingency_nx_inputs():
    return NxMilpInputs(
        lf_nx={co: {"BRANCH1": {1: 900.0}} for co in ("CO1", "CO2", "CO3")},
        sensitivity_pst_nx={},
        sensitivity_rd_nx={co: {("BRANCH1", "GU1"): 0.3} for co in ("CO1", "CO2", "CO3")},
        penalty_cost_overload_nx_patl=500.0,
    )


@pytest.mark.parametrize("linked, expected_contingencies", [
    ([], ["CO1", "CO2", "CO3"]),  # no contingency link: every usable contingency
    (["CO2"], ["CO2"]),           # linked to one of three: only that one
])
def test_curative_rd_contingency_link_decides_the_bid_contingency_pairs(linked, expected_contingencies):
    """BUC 14#106: a curative RD RA without a contingency link acts in every contingency with
    a usable N-X result; a linked RA only in its linked contingencies."""
    rd_inputs = RdMilpInputs(
        rd_list=[_make_rd_unit_r36("RD1", "GU1", kind=RAKind.CURATIVE, linked_contingency_mrids=linked)],
        bid_list=[_make_bid_r36("BID1", "RD1", BidDirection.UP, {"1030Z": 40.0})],
        glsk={"RD1": {"GU1": 1.0}},
        sensitivity_rd_n0_pruned={},
        generator_data={"GU1": {"target_p": 50.0, "max_p": 100.0, "min_p": 0.0}},
        penalty_reference_rd_pra=10.0,
    )

    model = build_n0_milp_model(
        [_make_ae_r36("BRANCH1")], "1030Z", lf_initial={"BRANCH1": {1: 500.0}},
        penalty_cost_overload_n0=1000.0, rd_inputs=rd_inputs, nx_inputs=_three_contingency_nx_inputs(),
    )

    assert sorted(model.curative_bid_contingency_pairs) == [("BID1", co) for co in expected_contingencies]


def _curative_balance_model(with_down_partner):
    """CO1 and CO2 overload BRANCH1 by 50 A; each curative MW up on GU1 relieves 10 A."""
    rd_inputs = RdMilpInputs(
        rd_list=[_make_rd_unit_r36("RD1", "GU1", kind=RAKind.CURATIVE, linked_contingency_mrids=["CO1", "CO2"])],
        bid_list=[_make_bid_r36("BID1", "RD1", BidDirection.UP, {"1030Z": 40.0})],
        glsk={"RD1": {"GU1": 1.0}},
        sensitivity_rd_n0_pruned={},
        generator_data={"GU1": {"target_p": 50.0, "max_p": 100.0, "min_p": 0.0}},
        penalty_reference_rd_pra=10.0,
    )
    if with_down_partner:
        rd_inputs = _with_curative_balancing_partner(rd_inputs, BidDirection.DOWN, ["CO1", "CO2"])
    nx_inputs = NxMilpInputs(
        lf_nx={co: {"BRANCH1": {1: 1050.0}} for co in ("CO1", "CO2")},
        sensitivity_pst_nx={},
        sensitivity_rd_nx={co: {("BRANCH1", "GU1"): -10.0} for co in ("CO1", "CO2")},
        penalty_cost_overload_nx_patl=1_000_000.0,
    )
    model = build_n0_milp_model(
        [_make_ae_r36("BRANCH1", patl_ka=1.0)], "1030Z", lf_initial={"BRANCH1": {1: 500.0}},
        penalty_cost_overload_n0=1_000_000.0, rd_inputs=rd_inputs, nx_inputs=nx_inputs,
    )
    assert str(pyo.SolverFactory("appsi_highs").solve(model).solver.termination_condition) == "optimal"
    return model


def test_lone_curative_up_bid_cannot_move_without_a_counterpart():
    """CORNET-574: one curative up bid and no down bid in the contingency gives 0 volume, so
    the overload stays in the PATL slack."""
    model = _curative_balance_model(with_down_partner=False)
    for co in ("CO1", "CO2"):
        assert pyo.value(model.curative_rd_volume_upward["BID1", co]) == pytest.approx(0.0, abs=1e-9)
        assert pyo.value(model.nx_patl_overload_slack["BRANCH1", co]) == pytest.approx(50.0, abs=1e-6)


def test_curative_up_and_down_bids_on_two_units_balance_per_contingency():
    """CORNET-574: an up bid on GU1 and a down bid on GU_BAL are equal in every contingency."""
    model = _curative_balance_model(with_down_partner=True)
    assert sorted(model.curative_rd_balancing.keys()) == ["CO1", "CO2"]
    for co in ("CO1", "CO2"):
        up = pyo.value(model.curative_rd_volume_upward["BID1", co])
        down = pyo.value(model.curative_rd_volume_downward["BID_BAL", co])
        assert up == pytest.approx(5.0, abs=1e-6)
        assert down == pytest.approx(up, abs=1e-6)


def _reaction_time_model(reaction_time_minutes, tatl_data, tatl_fallback_duration_seconds=600,
                         scanned_branches=()):
    """A curative up bid on GU1 (with a balancing partner) acting on BRANCH_A and BRANCH_B
    under CO1; tatl_data gives each branch's TATL duration (None: not in tatl_data);
    scanned_branches are SCANNED assessed elements."""
    unit = _make_rd_unit_r36("RD1", "GU1", kind=RAKind.CURATIVE, linked_contingency_mrids=["CO1"])
    unit.reaction_time_minutes = reaction_time_minutes
    rd_inputs = _with_curative_balancing_partner(RdMilpInputs(
        rd_list=[unit],
        bid_list=[_make_bid_r36("BID1", "RD1", BidDirection.UP, {"1030Z": 40.0})],
        glsk={"RD1": {"GU1": 1.0}},
        sensitivity_rd_n0_pruned={},
        generator_data={"GU1": {"target_p": 50.0, "max_p": 100.0, "min_p": 0.0}},
        penalty_reference_rd_pra=10.0,
    ), BidDirection.DOWN, ["CO1"])
    nx_inputs = NxMilpInputs(
        lf_nx={"CO1": {"BRANCH_A": {1: 1050.0}, "BRANCH_B": {1: 1050.0}}},
        sensitivity_pst_nx={},
        sensitivity_rd_nx={"CO1": {("BRANCH_A", "GU1"): -10.0, ("BRANCH_B", "GU1"): -10.0}},
        penalty_cost_overload_nx_patl=1000.0,
        tatl_data={
            branch: {"tatl_limit_ampere": 1000.0, "tatl_duration_seconds": seconds, "side": 1, "was_corrected": False}
            for branch, seconds in tatl_data.items()
        },
        tatl_fallback_duration_seconds=tatl_fallback_duration_seconds,
    )
    return build_n0_milp_model(
        [_make_ae_r36(branch, patl_ka=1.0,
                      ae_type=AEType.SCANNED if branch in scanned_branches else AEType.SECURED)
         for branch in ("BRANCH_A", "BRANCH_B")], "1030Z",
        lf_initial={"BRANCH_A": {1: 500.0}, "BRANCH_B": {1: 500.0}},
        penalty_cost_overload_n0=1000.0, rd_inputs=rd_inputs, nx_inputs=nx_inputs,
        # soft: without a preventive RA the hard N-0 scanned row would be a constant
        scanned_element_constraint_hard=False,
    )


def _bid_acts_on(model, branch_mrid):
    from pyomo.core.expr.visitor import identify_variables
    names = {v.name for v in identify_variables(model.nx_patl_loading[branch_mrid, "CO1"].body)}
    return 'curative_rd_volume_upward[BID1,CO1]' in names


@pytest.mark.parametrize("reaction_time_minutes, acts_on_a, acts_on_b", [
    (15.0, False, True),   # 15 min > 10 min TATL of A, <= 20 min of B
    (10.0, True, True),    # equal to the duration: available
    (None, True, True),    # no timeToImplement: reaction time 0, available everywhere
])
def test_curative_rd_enters_a_branch_only_if_its_reaction_time_fits_the_tatl_duration(
    reaction_time_minutes, acts_on_a, acts_on_b,
):
    """CORNET-613: a curative RD RA is considered for a branch only if timeToImplement <= the
    branch's TATL duration."""
    model = _reaction_time_model(reaction_time_minutes, {"BRANCH_A": 600, "BRANCH_B": 1200})
    assert _bid_acts_on(model, "BRANCH_A") is acts_on_a
    assert _bid_acts_on(model, "BRANCH_B") is acts_on_b


@pytest.mark.parametrize("fallback_seconds, acts", [(600, False), (1200, True)])
def test_a_branch_without_tatl_data_uses_the_configured_fallback_duration(fallback_seconds, acts):
    """BRANCH_B has no tatl_data entry: its duration is tatl_fallback_duration_seconds, so a
    15 min reaction time acts on it only with a fallback of at least 15 min."""
    model = _reaction_time_model(15.0, {"BRANCH_A": 1200}, tatl_fallback_duration_seconds=fallback_seconds)
    assert _bid_acts_on(model, "BRANCH_A")
    assert _bid_acts_on(model, "BRANCH_B") is acts


def test_a_scanned_branch_uses_the_fallback_duration_in_the_milp_and_in_the_csv(tmp_path):
    """R9 rule 10 [review]: BRANCH_B is scanned (never in tatl_data), so its duration is the 600 s
    fallback; a 15 min RA is not available there - in the MILP (its term is not in the scanned
    row) and in rd_cra_availability.csv, which the pipeline writes with the same helper over
    every monitored branch."""
    from pyomo.core.expr.visitor import identify_variables
    from milp.milp_builder import _get_monitored_branch_limits_and_ae_types
    from pre_milp.cra_preprocessing import compute_rd_cra_availability
    model = _reaction_time_model(15.0, {"BRANCH_A": 1200}, scanned_branches=("BRANCH_B",))
    assert ("BRANCH_B", "CO1") in set(model.nx_scanned_branch_contingency_pairs)
    scanned_row = {v.name for v in identify_variables(model.nx_scanned_loading["BRANCH_B", "CO1"].body)}
    assert "curative_rd_volume_upward[BID1,CO1]" not in scanned_row
    assert _bid_acts_on(model, "BRANCH_A")
    assert model.rd_cra_availability[("RD1", "BRANCH_B")] == {
        "reaction_time_minutes": 15.0, "tatl_duration_seconds": 600, "available": False}

    # the pipeline's call (run_pipeline: every monitored branch, config fallback)
    ae_list = [_make_ae_r36("BRANCH_A"), _make_ae_r36("BRANCH_B", ae_type=AEType.SCANNED)]
    monitored, _types = _get_monitored_branch_limits_and_ae_types(ae_list, "1030Z", {"BRANCH_A": {1: 500.0}, "BRANCH_B": {1: 500.0}})
    unit = _make_rd_unit_r36("RD1", "GU1", kind=RAKind.CURATIVE)
    unit.reaction_time_minutes = 15.0
    output = tmp_path / "rd_cra_availability.csv"
    compute_rd_cra_availability([unit], {"BRANCH_A": {"tatl_duration_seconds": 1200}}, output_path=output,
                                branch_mrids=list(monitored), fallback_duration_seconds=600)
    lines = output.read_text(encoding=TEXT_ENCODING).splitlines()
    assert "RD1,BRANCH_B,15.0,600,False" in lines and "RD1,BRANCH_A,15.0,1200,True" in lines


@pytest.mark.parametrize("reserve_price, expected_per_mw", [(3.0, 10.0 + 3.0), (None, 10.0 + 10.0)])
def test_curative_cost_uses_the_reserve_price_else_the_energy_price_with_a_log_line(
    reserve_price, expected_per_mw, caplog,
):
    """O1 / BUC 14#43: (penalty factor x reference + reservePrice) x max volume; without a
    reservePrice the energy price (10 EUR/MW) is used and the fallback is logged."""
    from milp import milp_builder
    milp_builder._last_logged_values.pop("reserve_price_fallback_BID1", None)
    unit = _make_rd_unit_r36("RD1", "GU1", kind=RAKind.CURATIVE, linked_contingency_mrids=["CO1"])
    bid = _make_bid_r36("BID1", "RD1", BidDirection.UP, {"1030Z": 40.0})
    bid.reserve_price_eur_mw = reserve_price
    rd_inputs = _with_curative_balancing_partner(RdMilpInputs(
        rd_list=[unit], bid_list=[bid], glsk={"RD1": {"GU1": 1.0}}, sensitivity_rd_n0_pruned={},
        generator_data={"GU1": {"target_p": 50.0, "max_p": 100.0, "min_p": 0.0}},
        penalty_reference_rd_pra=10.0,
    ), BidDirection.DOWN, ["CO1"])
    rd_inputs.bid_list[-1].reserve_price_eur_mw = 0.0     # the free partner: no fallback line
    nx_inputs = NxMilpInputs(
        lf_nx={"CO1": {"BRANCH1": {1: 1050.0}}}, sensitivity_pst_nx={},
        sensitivity_rd_nx={"CO1": {("BRANCH1", "GU1"): -10.0}}, penalty_cost_overload_nx_patl=1_000_000.0,
    )
    with caplog.at_level(logging.INFO):
        model = build_n0_milp_model(
            [_make_ae_r36("BRANCH1", patl_ka=1.0)], "1030Z", lf_initial={"BRANCH1": {1: 500.0}},
            penalty_cost_overload_n0=1_000_000.0, rd_inputs=rd_inputs, nx_inputs=nx_inputs,
        )
    assert str(pyo.SolverFactory("appsi_highs").solve(model).solver.termination_condition) == "optimal"
    assert pyo.value(model.max_curative_rd_volume_upward["BID1"]) == pytest.approx(5.0, abs=1e-6)
    assert pyo.value(model.objective) == pytest.approx(expected_per_mw * 5.0, abs=1e-6)
    fallback_lines = [r for r in caplog.records if "has no reservePrice" in r.getMessage() and "BID1" in r.getMessage()]
    assert len(fallback_lines) == (1 if reserve_price is None else 0)


def test_the_summary_reports_the_start_up_cost_and_the_objective_identity_holds():
    """O1 reporting (spec 2629): sum_startup_cost_eur, sum_shutdown_cost_eur and
    sum_bid_activation_cost_eur are summary metrics and part of the objective identity."""
    from post_milp.n0_results_export import extract_rd_results, extract_results_summary
    model = _start_up_model(5000.0)
    rd_inputs_rd_list = [
        RDUnit(mrid=ra, name=ra, tso="TestTSO", gu_mrid=gu, gu_name=gu, available=True, kind=P,
               initial_p=p, max_p=pmax, min_p=pmin, raise_ramp_rate=None, lower_ramp_rate=None, penalty_factor=0.0)
        for ra, gu, _k, p, pmin, pmax, _c in [("RD_OFF", "GU_OFF", P, 0.0, 50.0, 200.0, []), *_PARTNER_UNITS]
    ]
    bids = []
    for bid_mrid, ra, direction, mw, price, activation in [("BID_OFF", "RD_OFF", UP, 150.0, 10.0, None), *_PARTNER_BIDS]:
        bid = _make_bid_r36(bid_mrid, ra, direction, {"1030Z": mw})
        bid.price_eur_mw, bid.activation_cost_eur = price, activation
        bids.append(bid)
    rd_results = extract_rd_results(model, rd_inputs_rd_list, bids, 0.0, AcVerificationStatus.CONVERGED, "stable")
    summary = extract_results_summary(model, objective_value=pyo.value(model.objective), rd_results=rd_results)
    assert summary["sum_startup_cost_eur"] == pytest.approx(5000.0)
    assert summary["sum_shutdown_cost_eur"] == 0.0 and summary["sum_bid_activation_cost_eur"] == 0.0
    assert summary["objective_residual_eur"] == pytest.approx(0.0, abs=1e-6)


def test_generator_not_in_operation_fixes_curative_volume_to_zero():
    """R4: a curative RD unit that is off (PROD 0 with Pmin > 0, F2 status) and not started
    preventively: curative_rd_volume_upward == 0 in every contingency."""
    ae_list = [_make_ae_r36("BRANCH1")]
    rd_inputs = _base_rd_inputs_r36(target_p=0.0, min_p=20.0)
    nx_inputs = NxMilpInputs(
        lf_nx={"CO1": {"BRANCH1": {1: 900.0}}},
        sensitivity_pst_nx={},
        sensitivity_rd_nx={"CO1": {("BRANCH1", "GU1"): 0.3}},
        penalty_cost_overload_nx_patl=500.0,
    )

    model = build_n0_milp_model(
        ae_list, "1030Z", lf_initial={"BRANCH1": {1: 500.0}},
        penalty_cost_overload_n0=1000.0, rd_inputs=rd_inputs, nx_inputs=nx_inputs,
    )

    assert model.curative_rd_volume_upward["BID1", "CO1"].fixed
    assert pyo.value(model.curative_rd_volume_upward["BID1", "CO1"]) == 0.0
    assert model.curative_rd_volume_downward["BID1", "CO1"].fixed


def test_generator_in_operation_allows_activation_up_to_bid_bound():
    """The second half of the same acceptance criteria: a unit with
    initial_production > 0 CAN be activated curatively up to its
    max_curative_rd_volume_upward (here, the bid's own available_mw)."""
    ae_list = [_make_ae_r36("BRANCH1", patl_ka=1.0)]
    rd_inputs = _with_curative_balancing_partner(_base_rd_inputs_r36(target_p=50.0), BidDirection.DOWN, ["CO1"])
    nx_inputs = NxMilpInputs(
        lf_nx={"CO1": {"BRANCH1": {1: 1050.0}}},  # 50A overload
        sensitivity_pst_nx={},
        sensitivity_rd_nx={"CO1": {("BRANCH1", "GU1"): -10.0}},  # A per MW
        penalty_cost_overload_nx_patl=1_000_000.0,
    )

    model = build_n0_milp_model(
        ae_list, "1030Z", lf_initial={"BRANCH1": {1: 500.0}},
        penalty_cost_overload_n0=1_000_000.0, rd_inputs=rd_inputs, nx_inputs=nx_inputs,
    )

    assert not model.curative_rd_volume_upward["BID1", "CO1"].fixed
    assert pyo.value(model.curative_rd_volume_upward["BID1", "CO1"].ub) == 40.0  # bid's available_mw

    solver = pyo.SolverFactory("appsi_highs")
    result = solver.solve(model)
    assert str(result.solver.termination_condition) == "optimal"
    # 5 MW * 10 A/MW = 50A clears the overload; bounded by 40 MW available.
    curative_volume = pyo.value(model.curative_rd_volume_upward["BID1", "CO1"])
    assert curative_volume > 0.0
    assert curative_volume <= 40.0 + 1e-6
    assert pyo.value(model.nx_patl_overload_slack["BRANCH1", "CO1"]) == pytest.approx(0.0, abs=1e-6)


def test_max_curative_rd_volume_bounds_across_contingencies():
    """One bid linked to two contingencies needing different curative volumes:
    max_curative_rd_volume_upward is at least the larger of the two (a max, not a sum)."""
    ae_list = [_make_ae_r36("BRANCH1", patl_ka=1.0)]
    rd_inputs = _with_curative_balancing_partner(RdMilpInputs(
        rd_list=[_make_rd_unit_r36("RD1", "GU1", kind=RAKind.CURATIVE, linked_contingency_mrids=["CO1", "CO2"])],
        bid_list=[_make_bid_r36("BID1", "RD1", BidDirection.UP, {"1030Z": 40.0})],
        glsk={"RD1": {"GU1": 1.0}},
        sensitivity_rd_n0_pruned={},
        generator_data={"GU1": {"target_p": 50.0, "max_p": 100.0, "min_p": 0.0}},
        penalty_reference_rd_pra=10.0,
    ), BidDirection.DOWN, ["CO1", "CO2"])
    nx_inputs = NxMilpInputs(
        lf_nx={
            "CO1": {"BRANCH1": {1: 1050.0}},  # needs 5 MW
            "CO2": {"BRANCH1": {1: 1020.0}},  # needs 2 MW
        },
        sensitivity_pst_nx={},
        sensitivity_rd_nx={
            "CO1": {("BRANCH1", "GU1"): -10.0},
            "CO2": {("BRANCH1", "GU1"): -10.0},
        },
        penalty_cost_overload_nx_patl=1_000_000.0,
    )

    model = build_n0_milp_model(
        ae_list, "1030Z", lf_initial={"BRANCH1": {1: 500.0}},
        penalty_cost_overload_n0=1_000_000.0, rd_inputs=rd_inputs, nx_inputs=nx_inputs,
    )

    solver = pyo.SolverFactory("appsi_highs")
    result = solver.solve(model)
    assert str(result.solver.termination_condition) == "optimal"

    volume_co1 = pyo.value(model.curative_rd_volume_upward["BID1", "CO1"])
    volume_co2 = pyo.value(model.curative_rd_volume_upward["BID1", "CO2"])
    max_volume = pyo.value(model.max_curative_rd_volume_upward["BID1"])

    assert max_volume >= volume_co1 - 1e-6
    assert max_volume >= volume_co2 - 1e-6
    assert volume_co1 >= 5.0 - 1e-6
    assert volume_co2 >= 2.0 - 1e-6


def test_combined_pmax_pmin_respects_preventive_plus_curative():
    """A preventive and a curative bid on one generating unit: the COMBINED preventive +
    curative injection respects Pmax."""
    ae_list = [_make_ae_r36("BRANCH1", patl_ka=1.0), _make_ae_r36("BRANCH2", patl_ka=1.0)]
    rd_inputs = _with_curative_balancing_partner(RdMilpInputs(
        rd_list=[
            _make_rd_unit_r36("RD1", "GU1", kind=RAKind.PREVENTIVE),
            _make_rd_unit_r36("RD2", "GU1", kind=RAKind.CURATIVE, linked_contingency_mrids=["CO1"]),
        ],
        bid_list=[
            _make_bid_r36("BID1", "RD1", BidDirection.UP, {"1030Z": 40.0}),
            _make_bid_r36("BID2", "RD2", BidDirection.UP, {"1030Z": 40.0}),
        ],
        glsk={"RD1": {"GU1": 1.0}, "RD2": {"GU1": 1.0}},
        sensitivity_rd_n0_pruned={("BRANCH2", "GU1"): 0.0},
        generator_data={"GU1": {"target_p": 90.0, "max_p": 100.0, "min_p": 0.0}},  # only 10 MW headroom
        penalty_reference_rd_pra=0.0,
    ), BidDirection.DOWN, ["CO1"])
    nx_inputs = NxMilpInputs(
        lf_nx={"CO1": {"BRANCH1": {1: 1200.0}}},  # wants a LOT of curative help
        sensitivity_pst_nx={},
        sensitivity_rd_nx={"CO1": {("BRANCH1", "GU1"): -10.0}},
        penalty_cost_overload_nx_patl=1_000_000.0,
    )

    model = build_n0_milp_model(
        ae_list, "1030Z", lf_initial={"BRANCH1": {1: 500.0}, "BRANCH2": {1: 500.0}},
        penalty_cost_overload_n0=1_000_000.0, rd_inputs=rd_inputs, nx_inputs=nx_inputs,
    )

    solver = pyo.SolverFactory("appsi_highs")
    result = solver.solve(model)
    assert str(result.solver.termination_condition) == "optimal"

    preventive_volume = pyo.value(model.rd_volume_upward["BID1"])
    curative_volume = pyo.value(model.curative_rd_volume_upward["BID2", "CO1"])
    # Combined injection must not exceed the 10 MW headroom to max_p=100:
    assert preventive_volume + curative_volume <= 10.0 + 1e-6


REPO_SRC = Path(__file__).resolve().parents[1] / "src" / "rao"


def _make_ae_leadtime(branch_mrid: str, side: int, patl_ka: float, timestamp: str = "1030Z") -> AssessedElement:
    return AssessedElement(
        mrid=f"AE_{branch_mrid}", name=f"AE {branch_mrid}", tso="TestTSO",
        ae_type=AEType.SECURED, branch_mrid=branch_mrid,
        secured_for_region=None, scanned_for_region=None, exclusion_reason=None,
        patl_ka={timestamp: patl_ka}, branch_side=side,
    )


def _make_rd_unit_leadtime(mrid: str, gu_mrid: str) -> RDUnit:
    return RDUnit(
        mrid=mrid, name=mrid, tso="TestTSO", gu_mrid=gu_mrid, gu_name=gu_mrid,
        available=True, kind=RAKind.PREVENTIVE, initial_p=50.0, max_p=1000.0, min_p=0.0,
        raise_ramp_rate=None, lower_ramp_rate=None,
    )


def _make_bid_leadtime(mrid: str, ra_mrid: str, direction: BidDirection, available_mw: dict,
              price_eur_mw: float = 0.0, lead_time_h: float = 0.0) -> PowerBid:
    return PowerBid(
        mrid=mrid, ra_mrid=ra_mrid, direction=direction, available_mw=available_mw,
        price_eur_mw=price_eur_mw, penalty_factor=0.0, lead_time_h=lead_time_h,
        activation_cost_eur=None, min_energy_mwh=None, max_energy_mwh=None, step_size_mw=None,
    )


# ---------------------------------------------------------------------------
# Time-arithmetic helpers
# ---------------------------------------------------------------------------

def test_compute_radp_uses_raart_directly_when_given():
    """Given raart is provided, When radp is computed, Then radp = raart
    exactly, per the spec's own acceptance-criteria example."""
    assert _compute_radp("2200Z", "0030Z") == "2200Z"


def test_compute_radp_defaults_to_one_hour_before_timestamp():
    """raart None: radp is one hour before `timestamp` (hourly timestamp list)."""
    assert _compute_radp(None, "1030Z") == "0930Z"


def test_compute_radp_default_wraps_across_midnight():
    """Given raart is None and timestamp is close to midnight, When radp
    is computed, Then day wraparound is handled correctly."""
    assert _compute_radp(None, "0030Z") == "2330Z"


def test_timestamp_usable_spec_confirmed_boundary_example():
    """RADP=23:30, lead_time=3h -> cutoff 02:30, exactly on the 0230Z boundary -> 0230Z is
    blocked, the first usable timestamp is 0330Z."""
    timestamp_list = ["0030Z", "0130Z", "0230Z", "0330Z"]
    radp = "2330Z"
    lead = 3.0

    results = {t: _timestamp_is_usable(radp, lead, t) for t in timestamp_list}
    assert results == {"0030Z": False, "0130Z": False, "0230Z": False, "0330Z": True}
    assert _compute_earliest_usable_timestamp(radp, lead, timestamp_list) == "0330Z"


def test_timestamp_usable_second_confirmed_example():
    """RADP=22:00, lead_time=3h -> cutoff 01:00 (not on a boundary) -> the first timestamp
    strictly after it is 0130Z."""
    timestamp_list = ["0030Z", "0130Z", "0230Z", "0330Z"]
    radp = "2200Z"
    lead = 3.0

    assert _timestamp_is_usable(radp, lead, "0030Z") is False
    assert _timestamp_is_usable(radp, lead, "0130Z") is True
    assert _compute_earliest_usable_timestamp(radp, lead, timestamp_list) == "0130Z"


def test_earliest_usable_timestamp_none_when_lead_time_exceeds_list():
    """Given a lead time so long that no timestamp in the list is usable,
    When earliest usable timestamp is computed, Then it returns None
    rather than raising or returning a bogus value."""
    timestamp_list = ["0030Z", "0130Z"]
    result = _compute_earliest_usable_timestamp("0030Z", 100.0, timestamp_list)
    assert result is None


def test_zero_lead_time_is_usable_at_any_timestamp_strictly_after_radp():
    """bid_lead_time_hours=0: usable at any timestamp STRICTLY after radp; a timestamp equal
    to radp is not usable."""
    assert _timestamp_is_usable("0030Z", 0.0, "0030Z") is False
    assert _timestamp_is_usable("0030Z", 0.0, "0130Z") is True


# ---------------------------------------------------------------------------
# MILP-level: bounds actually tightened for the single build_n0_milp_model timestamp
# ---------------------------------------------------------------------------

def test_bid_with_unmet_lead_time_gets_zero_upper_bounds():
    """A bid whose lead time is not met at the model's `timestamp`: both upper bounds are 0.0,
    whatever its available_mw."""
    ae_list = [_make_ae_leadtime("BRANCH1", side=1, patl_ka=1.0, timestamp="0230Z")]
    rd_inputs = RdMilpInputs(
        rd_list=[_make_rd_unit_leadtime("RA1", "GU1"), _make_rd_unit_leadtime("RA_BALANCE", "GU_BALANCE")],
        bid_list=[
            # lead_time_h=3, raart="2330Z" (fixed via RdMilpInputs.raart) ->
            # at timestamp="0230Z", cutoff falls exactly on 0230Z -> blocked.
            _make_bid_leadtime("BID1", "RA1", BidDirection.UP, {"0230Z": 20.0}, lead_time_h=3.0),
            _make_bid_leadtime("BID_BALANCE", "RA_BALANCE", BidDirection.DOWN, {"0230Z": 20.0}),
        ],
        glsk={"RA1": {"GU1": 1.0}, "RA_BALANCE": {"GU_BALANCE": 1.0}},
        sensitivity_rd_n0_pruned={("BRANCH1", "GU1"): -10.0},
        generator_data={
            "GU1": {"target_p": 50.0, "max_p": 200.0, "min_p": 0.0, "name": "GU1"},
            "GU_BALANCE": {"target_p": 50.0, "max_p": 200.0, "min_p": 0.0, "name": "GU_BALANCE"},
        },
        raart="2330Z",
    )

    model = build_n0_milp_model(
        ae_list, "0230Z", lf_initial={"BRANCH1": {1: 500.0}},
        penalty_cost_overload_n0=1000.0, rd_inputs=rd_inputs,
    )

    assert model.rd_volume_upward["BID1"].ub == 0.0
    assert model.rd_volume_downward["BID1"].ub == 0.0


def test_bid_with_met_lead_time_keeps_available_mw_bound():
    """Given a bid whose lead time IS satisfied by the model's own
    `timestamp`, When the model is built, Then its upper bound remains
    the normal available_mw-derived bound, unaffected by lead time logic."""
    ae_list = [_make_ae_leadtime("BRANCH1", side=1, patl_ka=1.0, timestamp="0330Z")]
    rd_inputs = RdMilpInputs(
        rd_list=[_make_rd_unit_leadtime("RA1", "GU1"), _make_rd_unit_leadtime("RA_BALANCE", "GU_BALANCE")],
        bid_list=[
            # same lead_time_h=3, raart="2330Z", timestamp="0330Z": strictly after the 02:30
            # cutoff -> usable
            _make_bid_leadtime("BID1", "RA1", BidDirection.UP, {"0330Z": 20.0}, lead_time_h=3.0),
            _make_bid_leadtime("BID_BALANCE", "RA_BALANCE", BidDirection.DOWN, {"0330Z": 20.0}),
        ],
        glsk={"RA1": {"GU1": 1.0}, "RA_BALANCE": {"GU_BALANCE": 1.0}},
        sensitivity_rd_n0_pruned={("BRANCH1", "GU1"): -10.0},
        generator_data={
            "GU1": {"target_p": 50.0, "max_p": 200.0, "min_p": 0.0, "name": "GU1"},
            "GU_BALANCE": {"target_p": 50.0, "max_p": 200.0, "min_p": 0.0, "name": "GU_BALANCE"},
        },
        raart="2330Z",
    )

    model = build_n0_milp_model(
        ae_list, "0330Z", lf_initial={"BRANCH1": {1: 500.0}},
        penalty_cost_overload_n0=1000.0, rd_inputs=rd_inputs,
    )

    assert model.rd_volume_upward["BID1"].ub == 20.0
    assert model.rd_volume_downward["BID1"].ub == 0.0


def test_bid_with_no_lead_time_is_unaffected():
    """A bid with lead_time_h=0 (default): bounds come from available_mw only."""
    ae_list = [_make_ae_leadtime("BRANCH1", side=1, patl_ka=1.0)]
    rd_inputs = RdMilpInputs(
        rd_list=[_make_rd_unit_leadtime("RA1", "GU1")],
        bid_list=[_make_bid_leadtime("BID1", "RA1", BidDirection.UP, {"1030Z": 20.0}, lead_time_h=0.0)],
        glsk={"RA1": {"GU1": 1.0}},
        sensitivity_rd_n0_pruned={("BRANCH1", "GU1"): -10.0},
        generator_data={"GU1": {"target_p": 50.0, "max_p": 100.0, "min_p": 0.0, "name": "GU1"}},
    )

    model = build_n0_milp_model(
        ae_list, "1030Z", lf_initial={"BRANCH1": {1: 500.0}},
        penalty_cost_overload_n0=1000.0, rd_inputs=rd_inputs,
    )

    assert model.rd_volume_upward["BID1"].ub == 20.0


def test_solved_model_respects_lead_time_bound():
    """A bid blocked by lead time and a balancing partner: solved, the blocked bid dispatches
    0.0 and does not resolve the overload."""
    ae_list = [_make_ae_leadtime("BRANCH1", side=1, patl_ka=1.0, timestamp="0230Z")]
    rd_inputs = RdMilpInputs(
        rd_list=[_make_rd_unit_leadtime("RA1", "GU1"), _make_rd_unit_leadtime("RA_BALANCE", "GU_BALANCE")],
        bid_list=[
            _make_bid_leadtime("BID1", "RA1", BidDirection.UP, {"0230Z": 20.0}, lead_time_h=3.0),
            _make_bid_leadtime("BID_BALANCE", "RA_BALANCE", BidDirection.DOWN, {"0230Z": 20.0}),
        ],
        glsk={"RA1": {"GU1": 1.0}, "RA_BALANCE": {"GU_BALANCE": 1.0}},
        sensitivity_rd_n0_pruned={("BRANCH1", "GU1"): -10.0},
        generator_data={
            "GU1": {"target_p": 50.0, "max_p": 200.0, "min_p": 0.0, "name": "GU1"},
            "GU_BALANCE": {"target_p": 50.0, "max_p": 200.0, "min_p": 0.0, "name": "GU_BALANCE"},
        },
        raart="2330Z",
    )

    # 50 A overload -> 5 MW needed; BID1 could supply it but is blocked.
    model = build_n0_milp_model(
        ae_list, "0230Z", lf_initial={"BRANCH1": {1: 1050.0}},
        penalty_cost_overload_n0=1000.0, rd_inputs=rd_inputs,
    )

    solver = pyo.SolverFactory("appsi_highs")
    result = solver.solve(model)
    assert str(result.solver.termination_condition) in ("optimal", "TerminationCondition.optimal")

    assert pyo.value(model.rd_volume_upward["BID1"]) == 0.0
    assert pyo.value(model.overload_slack_n0["BRANCH1"]) > 1e-6  # unresolved, as expected


# ---------------------------------------------------------------------------
# extract_lead_time_results
# ---------------------------------------------------------------------------

def test_extract_lead_time_results_empty_bid_list_writes_header_only_csv(tmp_path):
    """Given bid_list is empty, When extract_lead_time_results is called
    with an output_path, Then it returns {} AND still writes a
    header-only CSV."""
    from post_milp.n0_results_export import extract_lead_time_results

    output_path = tmp_path / "results_lead_times.csv"
    result = extract_lead_time_results(
        bid_list=[], timestamp_list=["0030Z", "0130Z"], timestamp="0030Z", output_path=output_path,
        ac_verification_status=AcVerificationStatus.CONVERGED,
        ac_verification_termination_reason="test fixture",
    )

    assert result == {}
    assert output_path.exists()
    with open(output_path, encoding=TEXT_ENCODING) as f:
        header = f.readline().strip()
    assert "bid_mrid" in header


def test_extract_lead_time_results_reports_confirmed_spec_example():
    """radp=23:30 via raart, lead_time=3h: earliest_usable_timestamp is 0330Z, as
    _compute_earliest_usable_timestamp."""
    from post_milp.n0_results_export import extract_lead_time_results

    bid_list = [_make_bid_leadtime("BID1", "RA1", BidDirection.UP, {"0330Z": 20.0}, lead_time_h=3.0)]
    timestamp_list = ["0030Z", "0130Z", "0230Z", "0330Z"]

    results = extract_lead_time_results(
        bid_list=bid_list, timestamp_list=timestamp_list, raart="2330Z", timestamp="0030Z",
        ac_verification_status=AcVerificationStatus.CONVERGED,
        ac_verification_termination_reason="test fixture",
    )

    assert results["BID1"]["radp"] == "2330Z"
    assert results["BID1"]["bid_lead_time_hours"] == 3.0
    assert results["BID1"]["earliest_usable_timestamp"] == "0330Z"


def test_extract_lead_time_results_zero_lead_time_bid_reported_too():
    """Given a bid with no lead time restriction, When results are
    extracted, Then it is still reported (not omitted), consistent with
    the 'report everything, not just restricted bids' convention."""
    from post_milp.n0_results_export import extract_lead_time_results

    bid_list = [_make_bid_leadtime("BID1", "RA1", BidDirection.UP, {"0030Z": 20.0}, lead_time_h=0.0)]
    timestamp_list = ["0030Z", "0130Z"]

    results = extract_lead_time_results(
        bid_list=bid_list, timestamp_list=timestamp_list, raart="0030Z", timestamp="0030Z",
        ac_verification_status=AcVerificationStatus.CONVERGED,
        ac_verification_termination_reason="test fixture",
    )

    assert "BID1" in results
    assert results["BID1"]["bid_lead_time_hours"] == 0.0


# ===========================================================================
# RD availability
# ===========================================================================

REFERENCE = 10.0


def _units_and_bids(kind, off_available=False):
    """RD_OFF is the CHEAPER one (price 1) but unavailable; RD_OK costs 50."""
    rd_list, bid_list, glsk, generator_data = [], [], {}, {}
    for suffix, price, available in (("OK", 50.0, True), ("OFF", 1.0, off_available)):
        unit = _unit(f"RD_{suffix}", f"GU_{suffix}")
        unit.kind = kind
        unit.available = available
        rd_list.append(unit)
        bid_list.append(_bid(f"BID_{suffix}", f"RD_{suffix}", BidDirection.UP, price))
        glsk[f"RD_{suffix}"] = {f"GU_{suffix}": 1.0}   # the unavailable unit HAS a GLSK entry here
        generator_data[f"GU_{suffix}"] = {"target_p": 50.0, "max_p": 200.0, "min_p": 0.0}
    return rd_list, bid_list, glsk, generator_data


def _solve(model):
    assert str(pyo.SolverFactory("appsi_highs").solve(model).solver.termination_condition) == "optimal"
    return model


def _preventive_model(off_available=False, **rd_kwargs):
    """N-0: BRANCH1 overloaded by 10 A; each MW up on either unit gives -1 A."""
    rd_list, bid_list, glsk, generator_data = _units_and_bids(RAKind.PREVENTIVE, off_available)
    # preventive RD must balance: a free-priced DOWN unit with no effect on the branch
    down_unit = _unit("RD_DN", "GU_DN")
    down_unit.kind = RAKind.PREVENTIVE
    rd_list.append(down_unit)
    bid_list.append(_bid("BID_DN", "RD_DN", BidDirection.DOWN, 0.0))
    glsk["RD_DN"] = {"GU_DN": 1.0}
    generator_data["GU_DN"] = {"target_p": 50.0, "max_p": 200.0, "min_p": 0.0}
    rd_inputs = RdMilpInputs(
        rd_list=rd_list, bid_list=bid_list, glsk=glsk,
        sensitivity_rd_n0_pruned={("BRANCH1", "GU_OK"): -1.0, ("BRANCH1", "GU_OFF"): -1.0},
        generator_data=generator_data, penalty_reference_rd_pra=REFERENCE, **rd_kwargs,
    )
    return build_n0_milp_model(
        [_make_ae("BRANCH1")], "1030Z", lf_initial={"BRANCH1": {1: 1010.0}},
        penalty_cost_overload_n0=1_000_000.0, rd_inputs=rd_inputs,
    )


def _curative_model(off_available=False):
    """N-X: BRANCH1 overloaded by 10 A under CO1; each MW up gives -1 A."""
    rd_list, bid_list, glsk, generator_data = _units_and_bids(RAKind.CURATIVE, off_available)
    rd_inputs = _with_curative_balancing_partner(RdMilpInputs(
        rd_list=rd_list, bid_list=bid_list, glsk=glsk, sensitivity_rd_n0_pruned={},
        generator_data=generator_data, penalty_reference_rd_pra=REFERENCE,
    ), BidDirection.DOWN, ["CO1"])
    nx_inputs = NxMilpInputs(
        lf_nx={"CO1": {"BRANCH1": {1: 1010.0}}}, sensitivity_pst_nx={},
        sensitivity_rd_nx={"CO1": {("BRANCH1", "GU_OK"): -1.0, ("BRANCH1", "GU_OFF"): -1.0}},
        penalty_cost_overload_nx_patl=1_000_000.0,
    )
    return build_n0_milp_model(
        [_make_ae("BRANCH1")], "1030Z", lf_initial={"BRANCH1": {1: 500.0}},
        penalty_cost_overload_n0=1_000_000.0, rd_inputs=rd_inputs, nx_inputs=nx_inputs,
    )


# ---- preventive --------------------------------------------------------------

def test_available_cheaper_unit_is_used_control_case():
    model = _solve(_preventive_model(off_available=True))
    assert pyo.value(model.rd_volume_upward["BID_OFF"]) == pytest.approx(10.0, abs=1e-6)
    assert pyo.value(model.objective) == pytest.approx((10.0 + 1.0) * 10.0 + 10.0 * 10.0, abs=1e-6)


def test_unavailable_preventive_rd_gets_no_bid_variables_and_no_cost():
    """An unavailable (cheaper) unit's bid gets no variables: the available unit at 60 EUR/MW
    is dispatched, not the unavailable one at 11."""
    model = _solve(_preventive_model())
    assert sorted(model.bid_ids) == ["BID_DN", "BID_OK"]
    assert pyo.value(model.rd_volume_upward["BID_OK"]) == pytest.approx(10.0, abs=1e-6)
    assert pyo.value(model.objective) == pytest.approx((10.0 + 50.0) * 10.0 + 10.0 * 10.0, abs=1e-6)


def test_unavailable_preventive_rd_has_no_ra_count_variable():
    """ra_activated (and so the TSO's RA count) does not include the unavailable RA."""
    model = _preventive_model(max_ra_count_per_timestamp_tso={"TestTSO": 5})
    assert sorted(model.ra_mrids) == ["RD_DN", "RD_OK"]


def test_unavailable_preventive_rd_is_not_in_the_group_volume_limit():
    """The group cap does not sum the unavailable unit's bid."""
    model = _preventive_model(
        ra_groups={"GROUP1": {"ra_mrids": ["RD_OK", "RD_OFF"], "max_regulating_up": 100.0,
                              "max_regulating_down": None}},
    )
    (constraint,) = [c for c in model.ra_group_volume_upward_limit.values()]
    assert "BID_OFF" not in str(constraint.body) and "BID_OK" in str(constraint.body)


# ---- curative ----------------------------------------------------------------

def test_available_cheaper_curative_unit_is_used_control_case():
    model = _solve(_curative_model(off_available=True))
    assert pyo.value(model.curative_rd_volume_upward["BID_OFF", "CO1"]) == pytest.approx(10.0, abs=1e-6)


def test_unavailable_curative_rd_gets_no_variables_and_no_cost():
    """An unavailable curative bid gets no variables (it would relieve the overload at 11
    EUR/MW instead of 60)."""
    model = _solve(_curative_model())
    assert sorted(model.curative_bid_contingency_pairs) == [("BID_BAL", "CO1"), ("BID_OK", "CO1")]
    assert sorted(model.bid_ids_curative) == ["BID_BAL", "BID_OK"]
    assert pyo.value(model.objective) == pytest.approx((10.0 + 50.0) * 10.0, abs=1e-6)


def test_curative_block_absent_when_the_only_curative_unit_is_unavailable():
    rd_list, bid_list, glsk, generator_data = _units_and_bids(RAKind.CURATIVE)
    rd_list, bid_list = rd_list[1:], bid_list[1:]          # only RD_OFF (unavailable)
    rd_inputs = RdMilpInputs(
        rd_list=rd_list, bid_list=bid_list, glsk=glsk, sensitivity_rd_n0_pruned={},
        generator_data=generator_data, penalty_reference_rd_pra=REFERENCE,
    )
    nx_inputs = NxMilpInputs(
        lf_nx={"CO1": {"BRANCH1": {1: 1010.0}}}, sensitivity_pst_nx={},
        sensitivity_rd_nx={"CO1": {("BRANCH1", "GU_OFF"): -1.0}}, penalty_cost_overload_nx_patl=1000.0,
    )
    model = build_n0_milp_model(
        [_make_ae("BRANCH1")], "1030Z", lf_initial={"BRANCH1": {1: 500.0}},
        penalty_cost_overload_n0=1000.0, rd_inputs=rd_inputs, nx_inputs=nx_inputs,
    )
    assert not hasattr(model, "curative_bid_contingency_pairs")


# ===========================================================================
# Curative RD cost
# ===========================================================================

# (bid, direction, price EUR/MW, MW needed in CO1, MW needed in CO2)
# The binding contingency differs inside each direction, so dropping ANY max-linking row
# changes the optimum.


def test_curative_rd_cost_uses_own_price_and_max_over_contingencies():
    model = _solved_model()
    expected_cost = 0.0
    for bid_mrid, direction, price, need_co1, need_co2 in BIDS:
        active = (model.max_curative_rd_volume_upward if direction == BidDirection.UP
                  else model.max_curative_rd_volume_downward)
        assert pyo.value(active[bid_mrid]) == pytest.approx(max(need_co1, need_co2), abs=1e-6), bid_mrid
        expected_cost += (PENALTY_FACTOR * REFERENCE_curative_rd_cost + price) * max(need_co1, need_co2)
    assert expected_cost == pytest.approx(240 + 320 + 420 + 350)
    assert pyo.value(model.objective) == pytest.approx(expected_cost, abs=1e-6)


def test_curative_rd_inactive_direction_contributes_zero():
    model = _solved_model()
    for bid_mrid, direction, *_ in BIDS:
        inactive = (model.max_curative_rd_volume_downward if direction == BidDirection.UP
                    else model.max_curative_rd_volume_upward)
        assert pyo.value(inactive[bid_mrid]) == pytest.approx(0.0, abs=1e-9), bid_mrid


# ===========================================================================
# Curative RD lead time
# ===========================================================================

AVAILABLE_MW = 40.0


def _model(lead_time_h, raart=None, direction=BidDirection.UP):
    unit = RDUnit(
        mrid="RD1", name="RD1", tso="TestTSO", gu_mrid="GU1", gu_name="GU1", available=True,
        kind=RAKind.CURATIVE, initial_p=50.0, max_p=100.0, min_p=0.0,
        raise_ramp_rate=None, lower_ramp_rate=None,
        linked_contingency_mrids=["CO1"], linked_xne_mrids=[],
    )
    bid = PowerBid(
        mrid="BID1", ra_mrid="RD1", direction=direction, available_mw={"1030Z": AVAILABLE_MW},
        price_eur_mw=10.0, penalty_factor=0.0, lead_time_h=lead_time_h,
        activation_cost_eur=None, min_energy_mwh=None, max_energy_mwh=None, step_size_mw=None,
    )
    partner_direction = BidDirection.DOWN if direction == BidDirection.UP else BidDirection.UP
    rd_inputs = _with_curative_balancing_partner(RdMilpInputs(
        rd_list=[unit], bid_list=[bid], glsk={"RD1": {"GU1": 1.0}}, sensitivity_rd_n0_pruned={},
        generator_data={"GU1": {"target_p": 50.0, "max_p": 100.0, "min_p": 0.0}},
        penalty_reference_rd_pra=10.0, raart=raart,
    ), partner_direction, ["CO1"])
    sign = -10.0 if direction == BidDirection.UP else 10.0
    nx_inputs = NxMilpInputs(
        lf_nx={"CO1": {"BRANCH1": {1: 1050.0}}},  # 50 A over PATL
        sensitivity_pst_nx={}, sensitivity_rd_nx={"CO1": {("BRANCH1", "GU1"): sign}},
        penalty_cost_overload_nx_patl=1_000_000.0,
    )
    model = build_n0_milp_model(
        [_make_ae("BRANCH1")], "1030Z", lf_initial={"BRANCH1": {1: 500.0}},
        penalty_cost_overload_n0=1_000_000.0, rd_inputs=rd_inputs, nx_inputs=nx_inputs,
    )
    return model


def _solve_curative_rd_lead_time(model):
    result = pyo.SolverFactory("appsi_highs").solve(model)
    assert str(result.solver.termination_condition) == "optimal"


def test_blocked_timestamp_forces_curative_volumes_to_zero():
    """raart 1000Z + 3 h = 1300Z > 1030Z -> blocked: both curative bounds are 0 and the model
    does not use the bid (available_mw is 40)."""
    model = _model(lead_time_h=3.0, raart="1000Z")
    assert pyo.value(model.curative_rd_volume_upward["BID1", "CO1"].ub) == 0.0
    assert pyo.value(model.curative_rd_volume_downward["BID1", "CO1"].ub) == 0.0
    _solve_curative_rd_lead_time(model)
    assert pyo.value(model.curative_rd_volume_upward["BID1", "CO1"]) == pytest.approx(0.0, abs=1e-9)
    # the blocked bid cannot relieve the overload
    assert pyo.value(model.nx_patl_overload_slack["BRANCH1", "CO1"]) == pytest.approx(50.0, abs=1e-6)


def test_blocked_down_bid_is_also_forced_to_zero():
    model = _model(lead_time_h=3.0, raart="1000Z", direction=BidDirection.DOWN)
    assert pyo.value(model.curative_rd_volume_downward["BID1", "CO1"].ub) == 0.0
    _solve_curative_rd_lead_time(model)
    assert pyo.value(model.nx_patl_overload_slack["BRANCH1", "CO1"]) == pytest.approx(50.0, abs=1e-6)


def test_variables_and_rows_stay_in_the_model_when_blocked():
    model = _model(lead_time_h=3.0, raart="1000Z")
    assert ("BID1", "CO1") in list(model.curative_bid_contingency_pairs)
    assert "GU1" in list(model.curative_pmax_pmin_constraint.keys())
    assert "BID1" in list(model.bid_ids_curative)
    assert not model.curative_rd_volume_upward["BID1", "CO1"].fixed  # bound, not fix


def test_lead_time_zero_is_unchanged():
    model = _model(lead_time_h=0.0, raart="1000Z")
    assert pyo.value(model.curative_rd_volume_upward["BID1", "CO1"].ub) == AVAILABLE_MW
    _solve_curative_rd_lead_time(model)
    assert pyo.value(model.nx_patl_overload_slack["BRANCH1", "CO1"]) == pytest.approx(0.0, abs=1e-6)


def test_satisfied_lead_time_is_unchanged():
    """raart 0500Z + 3 h = 0800Z < 1030Z -> usable."""
    model = _model(lead_time_h=3.0, raart="0500Z")
    assert pyo.value(model.curative_rd_volume_upward["BID1", "CO1"].ub) == AVAILABLE_MW
    _solve_curative_rd_lead_time(model)
    assert pyo.value(model.nx_patl_overload_slack["BRANCH1", "CO1"]) == pytest.approx(0.0, abs=1e-6)


@pytest.mark.parametrize("lead_time_h, usable", [(0.5, True), (1.0, False), (3.0, False)])
def test_default_radp_is_one_hour_before_and_cutoff_on_boundary_blocks(lead_time_h, usable):
    """No raart -> radp 0930Z. 0.5 h -> cutoff 1000Z < 1030Z usable; 1 h ->
    cutoff exactly 1030Z blocks that timestamp (strict >, same as preventive)."""
    model = _model(lead_time_h=lead_time_h, raart=None)
    expected_ub = AVAILABLE_MW if usable else 0.0
    assert pyo.value(model.curative_rd_volume_upward["BID1", "CO1"].ub) == expected_ub


# ===========================================================================
# Curative RD without preventive RD
# ===========================================================================

def _unit_curative_rd_without_preventive_rd(kind, available=True, mrid="RD1"):
    return RDUnit(
        mrid=mrid, name=mrid, tso="TestTSO", gu_mrid="GU1", gu_name="GU1", available=available,
        kind=kind, initial_p=50.0, max_p=100.0, min_p=0.0, raise_ramp_rate=None, lower_ramp_rate=None,
        linked_contingency_mrids=["CO1"], linked_xne_mrids=[],
    )


# ---- 2. builder level --------------------------------------------------------

def _curative_only_rd_model(with_rd_inputs=True):
    rd_inputs = _with_curative_balancing_partner(RdMilpInputs(
        rd_list=[_unit_curative_rd_without_preventive_rd(RAKind.CURATIVE)],
        bid_list=[PowerBid(
            mrid="BID1", ra_mrid="RD1", direction=BidDirection.UP, available_mw={"1030Z": 40.0},
            price_eur_mw=10.0, penalty_factor=0.0, lead_time_h=0.0,
            activation_cost_eur=None, min_energy_mwh=None, max_energy_mwh=None, step_size_mw=None,
        )],
        glsk={"RD1": {"GU1": 1.0}}, sensitivity_rd_n0_pruned={},
        generator_data={"GU1": {"target_p": 50.0, "max_p": 100.0, "min_p": 0.0}},
        penalty_reference_rd_pra=10.0,
    ), BidDirection.DOWN, ["CO1"]) if with_rd_inputs else None
    nx_inputs = NxMilpInputs(
        lf_nx={"CO1": {"BRANCH1": {1: 1050.0}}},
        sensitivity_pst_nx={}, sensitivity_rd_nx={"CO1": {("BRANCH1", "GU1"): -10.0}},
        penalty_cost_overload_nx_patl=1000.0,
    )
    model = build_n0_milp_model(
        [_make_ae("BRANCH1")], "1030Z", lf_initial={"BRANCH1": {1: 500.0}},
        penalty_cost_overload_n0=1000.0, rd_inputs=rd_inputs, nx_inputs=nx_inputs,
    )
    assert str(pyo.SolverFactory("appsi_highs").solve(model).solver.termination_condition) == "optimal"
    return model


def test_curative_only_rd_scenario_solves_uses_bid_and_nx_block_links_it():
    with_rd = _curative_only_rd_model(True)
    without_rd = _curative_only_rd_model(False)

    # no preventive RD anywhere in the model
    assert not hasattr(with_rd, "rd_volume_upward")
    assert not hasattr(with_rd, "rd_net_injection_g")
    # the curative bid is used: 5 MW x 10 A/MW clears the 50 A overload
    used = pyo.value(with_rd.curative_rd_volume_upward["BID1", "CO1"])
    assert used == pytest.approx(5.0, abs=1e-6)
    # the N-X PATL row links it: with the bid the slack is 0, without it 50 A
    assert pyo.value(with_rd.nx_patl_overload_slack["BRANCH1", "CO1"]) == pytest.approx(0.0, abs=1e-6)
    assert pyo.value(without_rd.nx_patl_overload_slack["BRANCH1", "CO1"]) == pytest.approx(50.0, abs=1e-6)
    # cost = (penalty_factor*ref + price) * max volume = (10 + 10) * 5
    assert pyo.value(with_rd.objective) == pytest.approx(100.0, abs=1e-6)
