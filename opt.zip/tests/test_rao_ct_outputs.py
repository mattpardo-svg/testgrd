"""
test_rao_ct_outputs.py — the countertrade result files and summary rows (docs/countertrade_ra_specs.md C11):
file contents against the MILP results, the registry, no CT files without countertrade, the zone exchange
(pairing of the five GA_BO ties, DC flows in the dc mode, an unpaired tie skipped) and the summary residual.
"""
import csv
import logging
from types import SimpleNamespace

import pyomo.environ as pyo
import pytest

import ct_mock
from helpers import FIXTURE_CGM_ZIP, run_pipeline_on_fixture_inputs
from post_milp import ct_results_export
from pre_milp.ct_units import CtZone

CT_FILES = {
    "results_countertrade.csv", "results_curative_countertrade.csv", "countertrade_glsk_resolved.csv",
    "ct_cra_availability.csv", "results_net_positions.csv", "results_zone_exchange.csv",
}
CO = ct_mock.CONTINGENCY_GA_BO5


def _read_csv(path):
    with open(path, encoding="utf-8", newline="") as f:
        return list(csv.DictReader(f))


def _summary(output_dir):
    return {row["metric"]: row["value"] for row in _read_csv(output_dir / "results_summary.csv")}


def _run(tmp_path, mode="ac_single_pass", ra_types=("countertrade",), nx=False, prepare_output_dir=None, **mock_kwargs):
    tmp_path.mkdir(parents=True, exist_ok=True)
    ncp = ct_mock.build_ct_mock_ncp(tmp_path / "ncp.zip", **mock_kwargs)
    models = []

    def keep_models(rp, monkeypatch):
        build = rp.ac_convergence_loop.build_n0_milp_model

        def keeping_build(*args, **kwargs):
            model = build(*args, **kwargs)
            models.append(model)
            return model

        monkeypatch.setattr(rp.ac_convergence_loop, "build_n0_milp_model", keeping_build)

    run = run_pipeline_on_fixture_inputs(
        tmp_path / "run", ncp, enable_nx_analysis=nx, ra_types=ra_types, calculation_mode=mode,
        customize_pipeline=keep_models, prepare_output_dir=prepare_output_dir,
    )
    return SimpleNamespace(output_dir=run.output_dir, models=models)


@pytest.fixture(scope="module")
def preventive(tmp_path_factory):
    return _run(tmp_path_factory.mktemp("ct_out_prev"))


@pytest.fixture(scope="module")
def curative(tmp_path_factory):
    return _run(
        tmp_path_factory.mktemp("ct_out_cur"), ras=ct_mock.curative_ras(), nx=True, patl_a=ct_mock.CURATIVE_PATL_A,
        contingencies=[ct_mock.ga_bo5_outage()],
    )


def _names(output_dir):
    return {p.name for p in output_dir.glob("*")}


# ---------------------------------------------------------------------------
# which files exist
# ---------------------------------------------------------------------------

def test_a_countertrade_run_writes_the_preventive_files_and_no_curative_ones_without_n_x(preventive):
    names = _names(preventive.output_dir) & CT_FILES
    assert names == {"results_countertrade.csv", "countertrade_glsk_resolved.csv", "results_net_positions.csv", "results_zone_exchange.csv"}


def test_a_curative_countertrade_run_with_n_x_adds_the_curative_files(curative):
    assert _names(curative.output_dir) & CT_FILES == CT_FILES


def test_without_countertrade_in_ra_types_no_countertrade_file_and_no_summary_row_exists(tmp_path):
    def stale(output_dir):
        (output_dir / "results_countertrade.csv").write_text("stale\n", encoding="utf-8")

    result = _run(tmp_path, ra_types=("rd",), patl_a=None, prepare_output_dir=stale)
    assert not _names(result.output_dir) & CT_FILES                     # also the stale file of an earlier run is removed
    assert not any("_ct_" in key or key.startswith("sum_ct") for key in _summary(result.output_dir))


def test_the_countertrade_files_are_registered():
    from output_file_registry import OUTPUT_FILE_REGISTRY
    assert CT_FILES <= set(OUTPUT_FILE_REGISTRY)


def test_every_file_of_a_countertrade_run_is_registered(preventive, curative):
    from output_file_registry import OUTPUT_FILE_REGISTRY, RENAMED_OUTPUT_FILES
    allowed = set(OUTPUT_FILE_REGISTRY) | set(RENAMED_OUTPUT_FILES)
    for run in (preventive, curative):
        assert _names(run.output_dir) - allowed == set()


def test_the_files_are_utf8_without_a_byte_order_mark(curative):
    for name in CT_FILES:
        data = (curative.output_dir / name).read_bytes()
        assert not data.startswith(b"\xef\xbb\xbf")
        data.decode("utf-8")


# ---------------------------------------------------------------------------
# results_countertrade.csv, the weights, the net positions
# ---------------------------------------------------------------------------

def test_results_countertrade_matches_the_milp_result(preventive):
    model = preventive.models[-1]
    rows = {r["bid_mrid"]: r for r in _read_csv(preventive.output_dir / "results_countertrade.csv")}
    assert set(rows) == set(model.ct_bid_ids) and len(rows) == 4
    bo_down = ct_mock._uid("bid", "BO", "BO-down")
    volume = pyo.value(model.rd_volume_downward[bo_down])
    row = rows[bo_down]
    assert row["tso"] == "TSO-Belgovia" and row["zone_name"] == "BZ-Belgovia" and row["direction"] == "down"
    assert float(row["volume_mw"]) == pytest.approx(volume, rel=1e-9)
    assert float(row["price_cost_eur"]) == pytest.approx(8.0 * volume, rel=1e-9)
    assert float(row["penalty_cost_eur"]) == pytest.approx(1.0 * 100.0 * volume, rel=1e-9)
    assert float(row["activation_cost_eur"]) == 300.0
    unused = rows[ct_mock._uid("bid", "BO", "BO-up")]
    assert float(unused["volume_mw"]) == 0.0 and float(unused["activation_cost_eur"]) == 0.0
    assert row["ac_verification_status"] == "SINGLE_PASS"


def test_the_rows_add_up_to_the_countertrade_part_of_the_objective(preventive):
    rows = _read_csv(preventive.output_dir / "results_countertrade.csv")
    total = sum(float(r["price_cost_eur"]) + float(r["penalty_cost_eur"]) + float(r["activation_cost_eur"]) for r in rows)
    model = preventive.models[-1]
    assert total == pytest.approx(pyo.value(model.objective), rel=1e-9)
    assert total == pytest.approx(float(_summary(preventive.output_dir)["sum_ct_cost_eur"]), rel=1e-9)


def test_the_glsk_file_holds_the_weights_of_every_ra_and_direction_without_an_iteration_column(preventive):
    rows = _read_csv(preventive.output_dir / "countertrade_glsk_resolved.csv")
    assert set(rows[0]) == {"ra_mrid", "direction", "gu_mrid", "strategy", "participation_factor", "tso", "zone_mrid", "zone_name", "timestamp"}
    assert {r["strategy"] for r in rows} == {ct_mock.STRATEGY}
    found = {}
    for r in rows:
        zone = "Belgovia" if r["zone_name"] == "BZ-Belgovia" else "Galia"
        found.setdefault((zone, r["direction"]), {})[r["gu_mrid"]] = float(r["participation_factor"])
    assert set(found) == set(ct_mock.EXPECTED_WEIGHTS)
    for key, weights in ct_mock.EXPECTED_WEIGHTS.items():
        assert found[key] == pytest.approx(weights, abs=1e-6)


def test_the_net_positions_follow_the_countertrade_volumes_and_balance(preventive):
    rows = {r["zone_name"]: r for r in _read_csv(preventive.output_dir / "results_net_positions.csv")}
    volume = pyo.value(preventive.models[-1].rd_volume_downward[ct_mock._uid("bid", "BO", "BO-down")])
    assert float(rows["BZ-Belgovia"]["ct_change_mw"]) == pytest.approx(-volume, abs=1e-6)
    assert float(rows["BZ-Galia"]["ct_change_mw"]) == pytest.approx(volume, abs=1e-6)
    assert all(float(r["rd_change_mw"]) == 0.0 for r in rows.values())
    assert sum(float(r["total_change_mw"]) for r in rows.values()) == pytest.approx(0.0, abs=1e-6)
    assert rows["BZ-Belgovia"]["tso"] == "TSO-Belgovia"


def test_the_net_positions_show_the_rd_part_separately(tmp_path):
    result = _run(tmp_path, ra_types=("rd", "countertrade"), patl_a=60.0)
    rows = _read_csv(result.output_dir / "results_net_positions.csv")
    assert all(abs(float(r["rd_change_mw"]) + float(r["ct_change_mw"]) - float(r["total_change_mw"])) < 1e-6 for r in rows)
    assert sum(float(r["total_change_mw"]) for r in rows) == pytest.approx(0.0, abs=1e-6)


# ---------------------------------------------------------------------------
# summary
# ---------------------------------------------------------------------------

def test_the_summary_rows_and_the_residual_with_rd_and_countertrade(tmp_path):
    result = _run(tmp_path, ra_types=("rd", "countertrade"))
    summary = _summary(result.output_dir)
    rows = _read_csv(result.output_dir / "results_countertrade.csv")
    up = sum(float(r["volume_mw"]) for r in rows if r["direction"] == "up")
    down = sum(float(r["volume_mw"]) for r in rows if r["direction"] == "down")
    assert float(summary["sum_ct_volume_upward_mw"]) == pytest.approx(up, rel=1e-9)
    assert float(summary["sum_ct_volume_downward_mw"]) == pytest.approx(down, rel=1e-9)
    assert float(summary["sum_pra_penalty_cost_ct_eur"]) == pytest.approx(sum(float(r["penalty_cost_eur"]) for r in rows), rel=1e-9)
    assert float(summary["sum_cra_penalty_cost_ct_eur"]) == 0.0 and float(summary["sum_cra_reservation_cost_ct_eur"]) == 0.0
    assert float(summary["objective_residual_eur"]) == pytest.approx(0.0, abs=1e-6)
    assert summary["ra_types"] == "rd+countertrade"
    # the RD rows do not contain the countertrade cost
    assert float(summary["sum_rd_cost_eur"]) + float(summary["sum_ct_cost_eur"]) <= float(summary["objective_value"]) + 1e-6


# ---------------------------------------------------------------------------
# curative files
# ---------------------------------------------------------------------------

def test_the_curative_file_has_one_row_per_bid_and_contingency_with_the_cost_repeated(curative):
    rows = _read_csv(curative.output_dir / "results_curative_countertrade.csv")
    assert len(rows) == 4 and {r["contingency_mrid"] for r in rows} == {CO}
    used = {r["bid_mrid"]: r for r in rows if float(r["curative_volume_mw"]) > 0.0}
    assert len(used) == 2
    model = curative.models[-1]
    for row in used.values():
        assert float(row["max_curative_volume_mw"]) == pytest.approx(float(row["curative_volume_mw"]), rel=1e-9)
        assert float(row["penalty_cost_eur"]) == pytest.approx(1.0 * 100.0 * float(row["max_curative_volume_mw"]), rel=1e-9)
        assert float(row["reservation_cost_eur"]) == pytest.approx(4.0 * float(row["max_curative_volume_mw"]), rel=1e-9)
    summary = _summary(curative.output_dir)
    assert float(summary["sum_cra_penalty_cost_ct_eur"]) == pytest.approx(sum(float(r["penalty_cost_eur"]) for r in rows), rel=1e-9)
    assert float(summary["sum_cra_reservation_cost_ct_eur"]) == pytest.approx(sum(float(r["reservation_cost_eur"]) for r in rows), rel=1e-9)
    assert float(summary["objective_residual_eur"]) == pytest.approx(0.0, abs=1e-6)
    assert pyo.value(model.objective) == pytest.approx(float(summary["objective_value"]), rel=1e-9)


def test_the_availability_file_gives_the_reaction_time_rule_with_its_reason(curative, tmp_path):
    rows = _read_csv(curative.output_dir / "ct_cra_availability.csv")
    assert rows and all(r["available"] == "True" and r["reason"] == "" for r in rows)
    late = _run(
        tmp_path, ras=ct_mock.curative_ras(time_to_implement="PT20M"), nx=True, patl_a=ct_mock.CURATIVE_PATL_A,
        contingencies=[ct_mock.ga_bo5_outage()],
    )
    rows = _read_csv(late.output_dir / "ct_cra_availability.csv")
    assert rows and all(r["available"] == "False" and r["reason"] == ct_results_export.REASON_REACTION_TIME for r in rows)
    assert {r["tso"] for r in rows} == {"TSO-Belgovia", "TSO-Galia"} and {r["reaction_time_minutes"] for r in rows} == {"20.0"}


# ---------------------------------------------------------------------------
# zone exchange
# ---------------------------------------------------------------------------

BELGOVIA_AREA = "50487bb8-be6d-42a8-9358-cc0bbfe6cfa7"       # the CGM ControlAreas of the two zones
GALIA_AREA = "b20c892a-a5d2-4378-8744-c2cfea79d0be"


def _ga_bo_exchange(mode):
    """The exchange Galia -> Belgovia over the five GA_BO ties from a fresh network and the load flow of `mode`: per
    tie the mean of the flow entering Belgovia and the negative of the flow entering Galia."""
    import run_pipeline
    from pre_milp import cgmes_loader

    network = cgmes_loader.load_cgm(FIXTURE_CGM_ZIP)
    if mode == "dc":
        cgmes_loader.run_initial_dc_loadflow(
            network, use_reactive_limits=run_pipeline.USE_REACTIVE_LIMITS, extra_lf_params=run_pipeline.EXTRA_LF_PARAMS)
    else:
        cgmes_loader.run_initial_loadflow(
            network, use_reactive_limits=run_pipeline.USE_REACTIVE_LIMITS, extra_lf_params=run_pipeline.EXTRA_LF_PARAMS)
    by_name = {}
    for row in ct_results_export.read_area_boundaries(network):
        if row["name"].startswith("TieLine_GA_BO"):
            by_name.setdefault(row["name"], {})[row["area"]] = row["p"]
    assert sorted(by_name) == [f"TieLine_GA_BO{i}" for i in range(1, 6)]
    assert all(set(halves) == {BELGOVIA_AREA, GALIA_AREA} for halves in by_name.values())
    return sum((halves[BELGOVIA_AREA] - halves[GALIA_AREA]) / 2.0 for halves in by_name.values())


def test_the_exchange_pairs_the_five_ga_bo_ties_and_reports_the_relief(preventive):
    rows = _read_csv(preventive.output_dir / "results_zone_exchange.csv")
    pair = next(r for r in rows if {r["zone_a_name"], r["zone_b_name"]} == {"BZ-Galia", "BZ-Belgovia"})
    assert pair["tie_count"] == "5" and pair["load_flow"] == "AC" and pair["tso_a"] and pair["tso_b"]
    assert pair["zone_a_mrid"] == ct_mock.ZONE_GALIA                  # the zone with the smaller mRID is a
    assert float(pair["exchange_before_mw"]) == pytest.approx(_ga_bo_exchange("ac"), abs=1e-6)
    # Belgovia down / Galia up: the flow Galia -> Belgovia grows by about the countertrade volume
    volume = pyo.value(preventive.models[-1].rd_volume_downward[ct_mock._uid("bid", "BO", "BO-down")])
    assert 0.9 * volume < float(pair["change_mw"]) < 1.05 * volume
    assert float(pair["exchange_after_mw"]) - float(pair["exchange_before_mw"]) == pytest.approx(float(pair["change_mw"]), abs=1e-9)


def test_in_the_dc_mode_both_states_come_from_dc_load_flows(tmp_path):
    result = _run(tmp_path, mode="dc", patl_a=70.0)
    pair = next(r for r in _read_csv(result.output_dir / "results_zone_exchange.csv")
                if {r["zone_a_name"], r["zone_b_name"]} == {"BZ-Galia", "BZ-Belgovia"})
    assert pair["load_flow"] == "DC" and pair["tie_count"] == "5"
    assert float(pair["exchange_before_mw"]) == pytest.approx(_ga_bo_exchange("dc"), abs=1e-6)
    assert abs(float(pair["exchange_before_mw"]) - _ga_bo_exchange("ac")) > 0.5        # DC flows: no losses, no reactive part
    assert float(pair["change_mw"]) > 20.0

def _zones():
    return {
        "Z1": CtZone("Z1", "BZ-One", ["A1"]), "Z2": CtZone("Z2", "BZ-Two", ["A2"]), "Z3": CtZone("Z3", "BZ-Three", ["A3"]),
    }


def _boundary(area, name, p):
    return {"area": area, "element": f"E-{area}-{name}", "name": name, "p": p}


def test_a_tie_without_a_partner_is_skipped_with_a_log_line(caplog):
    before = [
        _boundary("A1", "T1", 10.0), _boundary("A2", "T1", -10.0),             # paired
        _boundary("A1", "LONE", 5.0),                                          # no partner half
        _boundary("A1", "T2", 20.0), _boundary("A2", "T2", 5.0),               # flows not opposite
        _boundary("A1", "T3", 7.0), _boundary("A9", "T3", -7.0),               # the other area is in no zone
    ]
    after = [_boundary("A1", "T1", 14.0), _boundary("A2", "T1", -14.0)] + before[2:]
    with caplog.at_level(logging.INFO):
        rows = ct_results_export.compute_zone_exchange(before, after, _zones(), {"Z1": "TSO-One", "Z2": "TSO-Two"})
    assert len(rows) == 1
    row = rows[0]
    assert (row["zone_a_name"], row["zone_b_name"], row["tie_count"]) == ("BZ-One", "BZ-Two", 1)
    assert row["exchange_before_mw"] == pytest.approx(-10.0) and row["exchange_after_mw"] == pytest.approx(-14.0)
    assert row["change_mw"] == pytest.approx(-4.0) and (row["tso_a"], row["tso_b"]) == ("TSO-One", "TSO-Two")
    message = next(r.getMessage() for r in caplog.records if "zone exchange" in r.getMessage())
    assert "1 tie(s) paired" in message and "LONE" in message and "T2" in message


def test_a_tie_that_is_paired_in_one_state_only_is_left_out():
    before = [_boundary("A1", "T1", 10.0), _boundary("A2", "T1", -10.0)]
    after = [_boundary("A1", "T1", 14.0)]
    assert ct_results_export.compute_zone_exchange(before, after, _zones(), {}) == []


def test_the_exchange_sums_the_ties_of_one_zone_pair_and_keeps_the_pairs_apart():
    before = [
        _boundary("A1", "T1", 10.0), _boundary("A2", "T1", -10.0), _boundary("A1", "T2", 4.0), _boundary("A2", "T2", -4.0),
        _boundary("A2", "T3", 3.0), _boundary("A3", "T3", -3.0),
    ]
    rows = ct_results_export.compute_zone_exchange(before, before, _zones(), {})
    by_pair = {(r["zone_a_name"], r["zone_b_name"]): r for r in rows}
    assert by_pair[("BZ-One", "BZ-Two")]["tie_count"] == 2 and by_pair[("BZ-One", "BZ-Two")]["exchange_before_mw"] == pytest.approx(-14.0)
    assert by_pair[("BZ-Two", "BZ-Three")]["exchange_before_mw"] == pytest.approx(-3.0)
    assert all(r["change_mw"] == 0.0 for r in rows)


# ---------------------------------------------------------------------------
# units at their limits (C5.2)
# ---------------------------------------------------------------------------

def test_a_unit_that_reaches_its_limit_with_countertrade_is_logged(caplog):
    from test_rao_milp_builder_ct import _generators, _inputs, _solved

    model = _solved(_inputs(generators=_generators(A1={"target_p": 60.0, "min_p": 50.0})))
    model.rd_baseline_target_p_mw = {gu: _generators()[gu]["target_p"] for gu in model.gu_ids}
    model.rd_baseline_target_p_mw["A1"] = 60.0
    with caplog.at_level(logging.INFO):
        hits = ct_results_export.log_units_at_limits(model)
    assert hits == [("A1", "Pmin")]
    assert sum("A1 reaches Pmin" in r.getMessage() for r in caplog.records) == 1


def test_no_unit_is_logged_when_no_limit_is_reached(caplog):
    from test_rao_milp_builder_ct import _inputs, _solved

    model = _solved(_inputs())
    model.rd_baseline_target_p_mw = {"A1": 300.0, "A2": 300.0, "B1": 100.0, "B2": 100.0}
    assert ct_results_export.log_units_at_limits(model) == []
