"""tests/test_rao_dc_pass.py - runs of run_pipeline.main() in calculation_mode dc (docs/dc_mode_specs.md
D1, D5, D7, D10): the calculation counts, the outputs, the final AC check and its failure paths,
the correction factors, and the AC modes next to it."""

import collections
import csv
import math

import pytest

from helpers import _FIXTURES, _MOCK_NX_CGM_ZIP, _MOCK_NX_NCP_ZIP, run_pipeline_on_fixture_inputs
from milp import dc_pass, single_pass
from text_encoding import TEXT_ENCODING  # noqa: E402

GENERIC_NCP_ZIP = _FIXTURES / "NCP_generic.zip"


def _csv_rows(path):
    with open(path, newline="", encoding=TEXT_ENCODING) as handle:
        return list(csv.DictReader(handle))


def _summary(output_dir):
    return {row["metric"]: row["value"] for row in _csv_rows(output_dir / "results_summary.csv")}


def spied_dc_run(work_dir, ncp_zip, nx, ra_types=("pst", "rd"), mode="dc", extra_customize=None):
    """One main() run with spies. Returns (output dir, counts, models, lf_n0 the model was built on,
    the dc_converter flags of the security-analysis calls)."""
    counts = collections.Counter()
    models, built_on, security_calls = [], [], []

    def customize(rp, monkeypatch):
        import milp.ac_convergence_loop as acl

        def wrap(obj, name, key, record=None):
            real = getattr(obj, name)

            def spy(*args, **kwargs):
                counts[key] += 1
                result = real(*args, **kwargs)
                if record is not None:
                    record(args, kwargs, result)
                return result
            monkeypatch.setattr(obj, name, spy)

        wrap(acl, "build_n0_milp_model", "build", lambda a, k, r: models.append(r))
        wrap(dc_pass, "build_model_at_state", "dc_build_at_state", lambda a, k, r: built_on.append(k["lf_before"]))
        wrap(dc_pass, "solve_n0_milp_model", "dc_solve")
        wrap(dc_pass, "apply_solution_and_refresh", "dc_apply")
        wrap(single_pass, "_run_ac_loadflow", "final_ac_load_flow")        # the AC backend's load flow
        wrap(dc_pass, "_run_ac_loadflow", "fallback_start_ac_load_flow")    # the extra one, failure path only
        wrap(acl, "_run_ac_loadflow", "loop_ac_load_flow")
        wrap(acl, "_refresh_n0_sensitivities", "sensitivity_refresh")
        wrap(rp, "compute_lf_nx", "security_analysis", lambda a, k, r: security_calls.append("dc_converter" in k))
        wrap(rp, "compute_sensitivities_nx", "nx_sensitivities")
        wrap(rp.n0_sensitivity, "compute_sensitivity_pst_n0", "n0_pst_sensitivity")
        wrap(rp.n0_sensitivity, "compute_sensitivity_rd_n0", "n0_rd_sensitivity")
        wrap(rp.post_ra_congestion_check, "find_new_congested_pairs", "find_new_pairs")
        wrap(rp.cgmes_loader, "run_initial_loadflow", "initial_ac_load_flow")
        wrap(rp.cgmes_loader, "run_initial_dc_loadflow", "initial_dc_load_flow")
        wrap(single_pass, "run_single_pass", "single_pass_function")
        if extra_customize is not None:
            extra_customize(rp, monkeypatch)

    result = run_pipeline_on_fixture_inputs(
        work_dir, ncp_zip, nx, customize_pipeline=customize, ra_types=ra_types, calculation_mode=mode,
    )
    return result.output_dir, counts, models, built_on, security_calls


# ===========================================================================
# Runs on the mock and the generic input: ra_types x N-X off / on
# ===========================================================================

@pytest.mark.parametrize("ncp_name", ["mock", "generic"])
@pytest.mark.parametrize("nx", [False, True])
@pytest.mark.parametrize("ra_types", [("pst",), ("rd",), ("pst", "rd")])
def test_a_dc_run_finishes_with_one_build_one_solve_one_apply_and_one_final_ac_check(tmp_path, ncp_name, nx, ra_types):
    ncp_zip = _MOCK_NX_NCP_ZIP if ncp_name == "mock" else GENERIC_NCP_ZIP

    output_dir, counts, _, _, security_calls = spied_dc_run(tmp_path, ncp_zip, nx, ra_types)

    assert counts["initial_dc_load_flow"] == 1 and counts["initial_ac_load_flow"] == 0  # D1.1
    assert counts["build"] == 1 and counts["dc_solve"] == 1 and counts["dc_apply"] == 1
    assert counts["final_ac_load_flow"] == 1                       # the final check, direct jump converged
    assert counts["fallback_start_ac_load_flow"] == 0 and counts["loop_ac_load_flow"] == 0  # no extra calculation
    assert counts["sensitivity_refresh"] == 0 and counts["find_new_pairs"] == 0
    assert counts["single_pass_function"] == 0
    # one DC security analysis (initial) and one AC security analysis (final check) with N-X on
    assert security_calls == ([True, False] if nx else [])
    summary = _summary(output_dir)
    assert summary["calculation_mode"] == "dc" and summary["ra_types"] == "+".join(ra_types)
    assert summary["ac_verification_status"] == "SINGLE_PASS"
    assert summary["final_check_basis"] == "ac" and summary["final_check_evaluated"] == "True"
    assert summary["final_check_nx_evaluated"] == str(nx)
    assert len(_csv_rows(output_dir / "results_iteration_history.csv")) == 1
    assert (output_dir / "results_completeness_iterations.csv").exists() is nx


# ===========================================================================
# Outputs, factors, basis rows
# ===========================================================================

@pytest.fixture(scope="module")
def dc_run(tmp_path_factory):
    return spied_dc_run(tmp_path_factory.mktemp("dc_run"), _MOCK_NX_NCP_ZIP, True)


@pytest.fixture(scope="module")
def single_pass_run(tmp_path_factory):
    return spied_dc_run(tmp_path_factory.mktemp("ac_single_pass"), _MOCK_NX_NCP_ZIP, True, mode="ac_single_pass")


def test_the_dc_run_writes_the_files_of_the_single_pass(dc_run, single_pass_run):
    dc_files = {p.name for p in dc_run[0].iterdir()}
    assert dc_files == {p.name for p in single_pass_run[0].iterdir()}
    history = _csv_rows(dc_run[0] / "results_iteration_history.csv")
    assert len(history) == 1 and history[0]["converged_by"] == "n/a" and history[0]["solution_applied"] == "True"
    assert [r["completeness_iteration"] for r in _csv_rows(dc_run[0] / "results_completeness_iterations.csv")] == ["0"]
    assert {r["ac_verification_status"] for r in _csv_rows(dc_run[0] / "results_pst.csv")} == {"SINGLE_PASS"}
    assert {r["solution_applied_to_network"] for r in _csv_rows(dc_run[0] / "lf_post_n0.csv")} == {"true"}


def test_the_dc_summary_rows_are_written_in_dc_mode_only(dc_run, single_pass_run):
    summary = _summary(dc_run[0])

    assert summary["dc_power_factor"] == "1.0"
    assert summary["dc_voltage_levels_with_factor"] == "0"
    assert summary["lf_basecase_basis"] == "dc" and summary["original_network_currents_basis"] == "dc"
    assert "final_check_reason" not in summary  # on failure only
    for kind in ("n0", "nx_patl", "nx_tatl", "nx_scanned"):
        assert f"final_check_{kind}_overload_a" in summary
    ac_summary = _summary(single_pass_run[0])
    for key in ("dc_power_factor", "dc_voltage_levels_with_factor", "lf_basecase_basis",
                "original_network_currents_basis", "final_check_basis", "final_check_evaluated"):
        assert key not in ac_summary, key


def test_lf_n0_in_dc_mode_has_no_nan_current_for_a_branch_of_the_model(dc_run):
    _, _, models, built_on, _ = dc_run
    lf_before = built_on[0]

    assert sum(1 for per_side in lf_before.values() for v in per_side.values() if math.isnan(v)) < 0.1 * 2 * len(lf_before)
    for branch_mrid in models[0].branch_ids:
        side = models[0].overload_monitoring["n0"][branch_mrid][0]
        assert lf_before[branch_mrid][side] == lf_before[branch_mrid][side]


def test_the_correction_factor_scales_the_currents_of_the_original_network_files(tmp_path_factory):
    def with_factor(factor):
        def customize(rp, monkeypatch):
            monkeypatch.setattr(rp, "DC_CURRENT_FACTOR_TABLE", {"default": factor})
        return spied_dc_run(
            tmp_path_factory.mktemp(f"factor_{factor}"), _MOCK_NX_NCP_ZIP, False, ("pst",), extra_customize=customize,
        )

    plain, scaled = with_factor(1.0), with_factor(1.25)

    plain_rows = {r["branch_mrid"]: float(r["i_ka"]) for r in _csv_rows(plain[0] / "lf_basecase.csv")}
    scaled_rows = {r["branch_mrid"]: float(r["i_ka"]) for r in _csv_rows(scaled[0] / "lf_basecase.csv")}
    assert plain_rows.keys() == scaled_rows.keys()
    compared = 0
    for branch_mrid, value in plain_rows.items():
        if value > 0:
            assert scaled_rows[branch_mrid] == pytest.approx(1.25 * value, rel=1e-12)
            compared += 1
    assert compared > 100


def test_a_factor_for_a_voltage_level_is_counted_in_the_summary(tmp_path):
    def customize(rp, monkeypatch):
        monkeypatch.setattr(rp, "DC_CURRENT_FACTOR_TABLE", {"default": 1.0, "400": 1.1, 220: 1.2})

    output_dir, *_ = spied_dc_run(tmp_path, _MOCK_NX_NCP_ZIP, False, ("pst",), extra_customize=customize)

    assert int(_summary(output_dir)["dc_voltage_levels_with_factor"]) > 0


def test_a_factor_on_one_voltage_level_scales_only_the_branches_of_that_level(tmp_path_factory):
    from pre_milp import cgmes_loader

    def with_table(table):
        def customize(rp, monkeypatch):
            monkeypatch.setattr(rp, "DC_CURRENT_FACTOR_TABLE", table)
        output_dir, *_ = spied_dc_run(
            tmp_path_factory.mktemp("level_factor"), _MOCK_NX_NCP_ZIP, False, ("pst",), extra_customize=customize,
        )
        return output_dir

    plain_dir, scaled_dir = with_table({"default": 1.0}), with_table({"default": 1.0, 220: 1.3})

    network = cgmes_loader.load_cgm(cgm_zip_override=_MOCK_NX_CGM_ZIP)
    nominal_v = network.get_voltage_levels()["nominal_v"]
    kv = {
        branch_mrid: (nominal_v[row["voltage_level1_id"]], nominal_v[row["voltage_level2_id"]])
        for table in (network.get_lines(), network.get_2_windings_transformers())
        for branch_mrid, row in table.iterrows()
    }
    plain = {r["branch_mrid"]: float(r["i_ka"]) for r in _csv_rows(plain_dir / "lf_basecase.csv")}
    scaled = {r["branch_mrid"]: float(r["i_ka"]) for r in _csv_rows(scaled_dir / "lf_basecase.csv")}
    at_220 = [b for b, value in plain.items() if kv[b] == (220.0, 220.0) and value > 0]
    elsewhere = [b for b, value in plain.items() if 220.0 not in kv[b] and value == value]
    assert len(at_220) >= 10 and len(elsewhere) > 100
    for branch_mrid in at_220:
        assert scaled[branch_mrid] == pytest.approx(1.3 * plain[branch_mrid], rel=1e-12)
    for branch_mrid in elsewhere:
        assert scaled[branch_mrid] == plain[branch_mrid]
    assert int(_summary(scaled_dir)["dc_voltage_levels_with_factor"]) == int((nominal_v == 220.0).sum())


@pytest.mark.parametrize("mode", ["ac_single_pass", "ac_iterative"])
def test_the_ac_modes_ignore_an_invalid_dc_power_factor_and_factor_table(tmp_path, mode):
    def invalid_dc_settings(rp, monkeypatch):
        monkeypatch.setattr(rp, "DC_POWER_FACTOR", 0.0)
        monkeypatch.setattr(rp, "DC_CURRENT_FACTOR_TABLE", {"default": -1.0})

    output_dir, counts, *_ = spied_dc_run(
        tmp_path, _MOCK_NX_NCP_ZIP, False, ("pst",), mode=mode, extra_customize=invalid_dc_settings,
    )

    summary = _summary(output_dir)
    assert summary["calculation_mode"] == mode and "dc_power_factor" not in summary
    assert counts["initial_dc_load_flow"] == 0


# ===========================================================================
# Failure paths of the final AC check (D5)
# ===========================================================================

def test_a_final_ac_load_flow_that_does_not_converge_keeps_the_dc_solution_and_the_run_goes_on(tmp_path):
    def non_convergent(rp, monkeypatch):
        import milp.ac_convergence_loop as acl
        monkeypatch.setattr(single_pass, "_run_ac_loadflow", lambda *args, **kwargs: (False, "FAILED", None))
        monkeypatch.setattr(acl, "_apply_changes_incrementally", lambda *args, **kwargs: (False, "FAILED", 1))

    output_dir, counts, models, _, security_calls = spied_dc_run(
        tmp_path, _MOCK_NX_NCP_ZIP, True, extra_customize=non_convergent,
    )

    summary = _summary(output_dir)
    assert summary["ac_verification_status"] == "SINGLE_PASS"
    assert summary["final_check_evaluated"] == "False" and summary["final_check_basis"] == "ac"
    assert "AC load flow did not converge" in summary["final_check_reason"]
    assert not any(key.startswith("final_check_n0") or key.startswith("final_check_nx") for key in summary)  # no overload rows
    assert summary["objective_value"] != ""                                  # the solved model is reported
    assert getattr(models[0], "no_applied_solution", False) is False
    assert counts["fallback_start_ac_load_flow"] == 1                       # the extra load flow for the start voltages
    assert security_calls == [True]                                          # no final-check security analysis
    moved = [r for r in _csv_rows(output_dir / "results_pst.csv") if float(r["tap_change_result"]) != 0]
    rd_rows = [r for r in _csv_rows(output_dir / "results_generating_units.csv") if float(r["rd_volume_net_mw"]) != 0]
    assert moved or rd_rows  # the DC solution (PST taps / RD volumes) is in the files
    assert {r["solution_applied_to_network"] for r in _csv_rows(output_dir / "lf_post_n0.csv")} == {"false"}


def test_after_a_failed_final_check_the_n_x_files_show_the_model_prediction_not_the_initial_state(tmp_path):
    """D5.3a: no N-X load flow describes the DC solution, so the post-PRA / after columns are the
    model's prediction (lf_nx_final None), never the initial DC state next to moved PST taps."""
    final_states = {}

    def non_convergent(rp, monkeypatch):
        import milp.ac_convergence_loop as acl
        monkeypatch.setattr(single_pass, "_run_ac_loadflow", lambda *args, **kwargs: (False, "FAILED", None))
        monkeypatch.setattr(acl, "_apply_changes_incrementally", lambda *args, **kwargs: (False, "FAILED", 1))
        for name in ("export_nx_loadings_csv", "export_nx_scanned_elements_csv"):
            real = getattr(rp.nx_results_export, name)

            def spy(*args, _real=real, _name=name, **kwargs):
                final_states[_name] = kwargs["lf_nx_final"]
                return _real(*args, **kwargs)
            monkeypatch.setattr(rp.nx_results_export, name, spy)

    output_dir, *_ = spied_dc_run(tmp_path, _MOCK_NX_NCP_ZIP, True, extra_customize=non_convergent)

    assert final_states == {"export_nx_loadings_csv": None, "export_nx_scanned_elements_csv": None}
    rows = _csv_rows(output_dir / "results_nx_loadings.csv")
    assert rows
    for row in rows:
        assert row["loading_pct_nx_post_pra"] == row["loading_pct_nx_post_pra_model"]
        assert float(row["loading_pct_nx_post_pra_model_diff_pct"]) == 0.0
    # the PST moves of the DC solution show in the post-PRA column
    assert any(row["loading_pct_nx_post_pra"] != row["loading_pct_nx_initial"] for row in rows)


def test_a_configured_previous_values_start_becomes_uniform_for_the_first_ac_load_flow():
    import pypowsybl as pp

    previous = pp.loadflow.VoltageInitMode.PREVIOUS_VALUES
    parameters = {"voltage_init_mode": previous, "distributed_slack": True}

    checked = dc_pass.ac_check_parameters(parameters)

    assert checked == {"voltage_init_mode": pp.loadflow.VoltageInitMode.UNIFORM_VALUES, "distributed_slack": True}
    assert parameters["voltage_init_mode"] == previous  # the pipeline's parameters stay as configured


def test_a_dc_run_with_previous_values_finishes_its_final_ac_check(tmp_path):
    """After a DC load flow every bus voltage is NaN: a PREVIOUS_VALUES start of the final AC load
    flow would fail ("Voltage magnitude is undefined"); ac_check_parameters starts it from
    UNIFORM_VALUES."""
    import pypowsybl as pp

    def previous_values(rp, monkeypatch):
        monkeypatch.setattr(rp, "EXTRA_LF_PARAMS", {
            **rp.EXTRA_LF_PARAMS, "voltage_init_mode": pp.loadflow.VoltageInitMode.PREVIOUS_VALUES,
        })

    output_dir, counts, *_ = spied_dc_run(tmp_path, _MOCK_NX_NCP_ZIP, True, extra_customize=previous_values)

    assert _summary(output_dir)["final_check_evaluated"] == "True"
    assert counts["final_ac_load_flow"] == 1 and counts["fallback_start_ac_load_flow"] == 0


def test_the_incremental_fallback_runs_from_the_voltages_of_one_extra_ac_load_flow(tmp_path):
    """The direct jump fails once; the extra AC load flow at the unmodified state gives the voltages
    the warm-started fallback needs (all bus voltages are NaN after the DC load flow)."""
    def first_direct_jump_fails(rp, monkeypatch):
        real = single_pass._run_ac_loadflow
        calls = []

        def failing_once(*args, **kwargs):
            calls.append(1)
            return (False, "FAILED", None) if len(calls) == 1 else real(*args, **kwargs)
        monkeypatch.setattr(single_pass, "_run_ac_loadflow", failing_once)

    output_dir, counts, _, _, security_calls = spied_dc_run(
        tmp_path, _MOCK_NX_NCP_ZIP, True, extra_customize=first_direct_jump_fails,
    )

    summary = _summary(output_dir)
    assert summary["final_check_evaluated"] == "True"
    assert counts["fallback_start_ac_load_flow"] == 1
    assert security_calls == [True, False]
    assert {r["solution_applied_to_network"] for r in _csv_rows(output_dir / "lf_post_n0.csv")} == {"true"}


def test_without_start_voltages_the_fallback_is_skipped_and_the_dc_solution_is_kept(tmp_path):
    def nothing_converges(rp, monkeypatch):
        monkeypatch.setattr(single_pass, "_run_ac_loadflow", lambda *args, **kwargs: (False, "FAILED", None))
        monkeypatch.setattr(dc_pass, "_run_ac_loadflow", lambda *args, **kwargs: (False, "FAILED", None))

    output_dir, *_ = spied_dc_run(tmp_path, _MOCK_NX_NCP_ZIP, False, extra_customize=nothing_converges)

    summary = _summary(output_dir)
    assert summary["final_check_evaluated"] == "False" and "no_start_voltages" in summary["final_check_reason"]


def test_a_solve_that_is_not_optimal_reports_the_original_network_without_any_ac_calculation(tmp_path):
    from milp.milp_solver import MilpNotOptimalError

    def not_optimal(rp, monkeypatch):
        def raise_not_optimal(*args, **kwargs):
            raise MilpNotOptimalError("infeasible (test)")
        monkeypatch.setattr(dc_pass, "solve_n0_milp_model", raise_not_optimal)

    output_dir, counts, models, _, security_calls = spied_dc_run(
        tmp_path, _MOCK_NX_NCP_ZIP, True, extra_customize=not_optimal,
    )

    summary = _summary(output_dir)
    assert summary["ac_verification_status"] == "SOLVER_NON_OPTIMAL"
    assert summary["objective_value"] == ""
    assert summary["final_check_evaluated"] == "False" and "not optimal" in summary["final_check_reason"]
    assert counts["dc_apply"] == 0 and counts["final_ac_load_flow"] == 0 and security_calls == [True]
    assert getattr(models[0], "no_applied_solution", False) is True
    assert all(float(row["tap_change_result"]) == 0 for row in _csv_rows(output_dir / "results_pst.csv"))


def test_a_dc_load_flow_that_does_not_converge_stops_the_run(tmp_path):
    import pypowsybl

    def not_converging(rp, monkeypatch):
        status = type("Status", (), {"name": "FAILED"})()
        monkeypatch.setattr(
            pypowsybl.loadflow, "run_dc", lambda *args, **kwargs: [type("Component", (), {"status": status})()],
        )

    with pytest.raises(RuntimeError, match="DC load flow did not converge"):
        spied_dc_run(tmp_path, _MOCK_NX_NCP_ZIP, False, extra_customize=not_converging)


# ===========================================================================
# The AC modes do not run any DC calculation
# ===========================================================================

def test_the_ac_single_pass_uses_no_dc_calculation(single_pass_run):
    _, counts, _, _, security_calls = single_pass_run

    assert counts["initial_dc_load_flow"] == 0 and counts["initial_ac_load_flow"] == 1
    assert counts["single_pass_function"] == 1 and counts["dc_apply"] == 0
    assert security_calls == [False, False]


def test_the_dc_pass_ignores_unusual_caps_and_thresholds(tmp_path):
    def unusual(rp, monkeypatch):
        monkeypatch.setattr(rp, "MAX_LINEARISATION_ITERATIONS", 1)
        monkeypatch.setattr(rp, "MAX_COMPLETENESS_ITERATIONS", 1)
        for name in ("MAX_CHANGE_RA_SUM_THRESHOLD", "MAX_CHANGE_RA", "MAX_CHANGE_OVERLOAD"):
            monkeypatch.setattr(rp, name, 1e9)

    output_dir, counts, *_ = spied_dc_run(tmp_path, _MOCK_NX_NCP_ZIP, False, extra_customize=unusual)

    assert counts["build"] == 1 and _summary(output_dir)["ac_verification_status"] == "SINGLE_PASS"
