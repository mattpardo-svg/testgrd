"""
test_rao_ct_config.py — the countertrade ra_type: configuration, validation and GUI
(docs/countertrade_ra_specs.md C1.2, C9, C10): the two penalty references, the ra_types checks, the GUI toggle and
inputs, saved settings that predate the keys, the temp config the GUI writes, and the validation warnings of a
run on the mock.
"""
import json
import logging
from pathlib import Path

import pytest
import yaml

import ct_mock
import run_pipeline
from helpers import run_pipeline_on_fixture_inputs
from test_rao_dc_mode import _gui_common, _page
from text_encoding import TEXT_ENCODING

CONFIG_DIR = Path(__file__).resolve().parents[1] / "src" / "rao" / "config"


def _load(name):
    return yaml.safe_load((CONFIG_DIR / name).read_text(encoding=TEXT_ENCODING))


# ---------------------------------------------------------------------------
# ra_types and the penalty references
# ---------------------------------------------------------------------------

def test_both_config_files_hold_the_countertrade_references_equal_to_the_rd_reference():
    for name in ("rao_config.default.yaml", "rao_config.yaml"):
        costs = _load(name)["penalty_costs"]
        assert costs["penalty_reference_ct_pra"] == costs["penalty_reference_rd_pra"]
        assert costs["penalty_reference_ct_cra"] == costs["penalty_reference_rd_pra"]


def test_the_default_ra_types_do_not_include_countertrade():
    assert _load("rao_config.default.yaml")["workflow_toggles"]["ra_types"] == ["pst", "rd"]


def test_the_countertrade_references_are_returned_as_floats():
    config = _load("rao_config.default.yaml")
    config["penalty_costs"].update(penalty_reference_ct_pra=7, penalty_reference_ct_cra=0)
    assert run_pipeline.validate_ct_penalty_references(config, Path("/x/rao_config.yaml")) == (7.0, 0.0)


@pytest.mark.parametrize("key", ["penalty_reference_ct_pra", "penalty_reference_ct_cra"])
@pytest.mark.parametrize("bad", [-1.0, "10", None, True])
def test_a_bad_countertrade_reference_names_key_value_and_file(key, bad):
    config = _load("rao_config.default.yaml")
    config["penalty_costs"][key] = bad
    with pytest.raises(ValueError, match=f"penalty_costs.{key}.*must be a number >= 0"):
        run_pipeline.validate_ct_penalty_references(config, Path("/x/rao_config.yaml"))


def test_a_missing_countertrade_reference_is_a_config_key_error():
    config = _load("rao_config.default.yaml")
    del config["penalty_costs"]["penalty_reference_ct_cra"]
    with pytest.raises(run_pipeline.ConfigKeyError, match="penalty_costs.penalty_reference_ct_cra"):
        run_pipeline.validate_ct_penalty_references(config, Path("/x/rao_config.yaml"))


def test_the_references_are_checked_only_when_countertrade_is_in_ra_types():
    """A config that predates the keys stays valid for every run without countertrade."""
    config = _load("rao_config.default.yaml")
    del config["penalty_costs"]["penalty_reference_ct_pra"]
    del config["penalty_costs"]["penalty_reference_ct_cra"]
    run_pipeline.validate_config_ranges(config, Path("/x/rao_config.yaml"))
    config["workflow_toggles"]["ra_types"] = ["rd", "countertrade"]
    with pytest.raises(run_pipeline.ConfigKeyError, match="penalty_reference_ct_pra"):
        run_pipeline.validate_config_ranges(config, Path("/x/rao_config.yaml"))


def test_a_bad_reference_stops_a_countertrade_config_but_not_another_one():
    config = _load("rao_config.default.yaml")
    config["penalty_costs"]["penalty_reference_ct_pra"] = -5.0
    run_pipeline.validate_config_ranges(config, Path("/x/rao_config.yaml"))         # countertrade is not in ra_types
    config["workflow_toggles"]["ra_types"] = ["countertrade"]
    with pytest.raises(ValueError, match="penalty_reference_ct_pra"):
        run_pipeline.validate_config_ranges(config, Path("/x/rao_config.yaml"))


@pytest.mark.parametrize("value", [
    ["countertrade"], ["pst", "countertrade"], ["rd", "countertrade"], ["hvdc", "countertrade"],
    ["countertrade", "rd", "pst", "hvdc"],
])
def test_countertrade_combines_with_every_other_type(value):
    assert run_pipeline.validate_ra_types(value, "x") == value


def test_a_duplicate_countertrade_and_an_unknown_type_are_refused():
    with pytest.raises(ValueError, match="duplicate"):
        run_pipeline.validate_ra_types(["countertrade", "countertrade"], "x")
    with pytest.raises(ValueError, match=r"\['countertrades'\] not yet supported"):
        run_pipeline.validate_ra_types(["countertrades"], "x")


def test_the_two_config_files_keep_the_same_key_tree():
    def tree(node):
        return {k: tree(v) if isinstance(v, dict) else None for k, v in node.items()}
    assert tree(_load("rao_config.default.yaml")) == tree(_load("rao_config.yaml"))


# ---------------------------------------------------------------------------
# GUI
# ---------------------------------------------------------------------------

def test_the_main_page_has_a_countertrade_toggle_that_is_off_by_default():
    page = _page("1_Main.py")
    page.run()

    assert not page.exception
    assert page.toggle(key="toggle_countertrade").value is False
    assert page.toggle(key="toggle_pst").value is True and page.toggle(key="toggle_hvdc").value is False


def test_switching_every_ra_type_off_shows_the_error_naming_countertrade():
    page = _page("1_Main.py")
    page.run()
    for key in ("toggle_pst", "toggle_rd", "toggle_hvdc", "toggle_countertrade"):
        page.toggle(key=key).set_value(False)
    page.run()

    assert any("countertrade" in e.value for e in page.error)


def test_countertrade_alone_is_a_valid_selection():
    page = _page("1_Main.py")
    page.run()
    for key in ("toggle_pst", "toggle_rd"):
        page.toggle(key=key).set_value(False)
    page.toggle(key="toggle_countertrade").set_value(True)
    page.run()

    assert not page.exception and not any("Select at least one" in e.value for e in page.error)


def test_the_countertrade_result_files_are_grouped_with_the_rd_and_hvdc_files(tmp_path):
    (tmp_path / "output").mkdir()
    for name in (
        "results_countertrade.csv", "results_net_positions.csv", "results_zone_exchange.csv",
        "results_curative_countertrade.csv", "countertrade_glsk_resolved.csv", "ct_cra_availability.csv",
    ):
        (tmp_path / "output" / name).write_text("a\n", encoding=TEXT_ENCODING)
    page = _page("1_Main.py")
    page.session_state["run_complete"] = True
    page.session_state["run_exit_code"] = 0
    page.session_state["tmpdir"] = tmp_path
    page.run()

    assert not page.exception
    labels = {expander.label for expander in page.expander}
    assert "N-0 results (3 file(s))" in labels and "Other (3 file(s))" in labels


def test_the_settings_page_shows_the_two_countertrade_references_with_the_defaults():
    page = _page("3_RAO_Settings.py")
    page.run()

    assert not page.exception
    values = {element.label: element.value for element in page.number_input}
    assert values["penalty_reference_ct_pra"] == 100.0 and values["penalty_reference_ct_cra"] == 100.0


def test_saved_settings_without_the_countertrade_keys_get_the_defaults(tmp_path, monkeypatch):
    gui = _gui_common()
    saved = {"rao_config": {"penalty_costs": {"penalty_reference_rd_pra": 55.0}}, "load_flow_config": {}}
    settings_file = tmp_path / "settings.json"
    settings_file.write_text(json.dumps(saved), encoding=TEXT_ENCODING)
    monkeypatch.setattr(gui, "SETTINGS_FILE_PATH", settings_file)

    costs = gui.load_settings()["rao_config"]["penalty_costs"]

    assert costs["penalty_reference_rd_pra"] == 55.0
    assert costs["penalty_reference_ct_pra"] == costs["penalty_reference_ct_cra"] == 100.0


def test_the_gui_temp_config_with_countertrade_passes_the_pipeline_checks():
    gui = _gui_common()
    rao_config = {section: dict(values) for section, values in gui.DEFAULT_RAO_CONFIG.items()}
    rao_config["workflow_toggles"]["ra_types"] = ["rd", "countertrade"]
    rao_config["penalty_costs"]["penalty_reference_ct_cra"] = 12.5

    tmpdir = gui.build_temp_run_dir(b"cgm", b"ncp", rao_config, gui.DEFAULT_LOAD_FLOW_CONFIG)
    try:
        path = tmpdir / "src" / "rao" / "config" / "rao_config.yaml"
        written = yaml.safe_load(path.read_text(encoding=TEXT_ENCODING))
        run_pipeline.validate_config_ranges(written, path)
    finally:
        gui.cleanup_temp_run_dir(tmpdir)

    assert written["workflow_toggles"]["ra_types"] == ["rd", "countertrade"]
    assert run_pipeline.validate_ct_penalty_references(written, path) == (100.0, 12.5)


# ---------------------------------------------------------------------------
# the workflow label and the validation warnings of a run on the mock
# ---------------------------------------------------------------------------

def _label(caplog):
    lines = [r.getMessage() for r in caplog.records if "MILP construction, solve, and AC verification loop" in r.getMessage()]
    return lines[0].split("(")[-1].split(")")[0] if lines else None


@pytest.mark.parametrize("ra_types, label", [(("countertrade",), "CT"), (("rd", "countertrade"), "RD+CT"), (("rd",), "RD-only")])
def test_the_workflow_label_names_countertrade(tmp_path, caplog, ra_types, label):
    ncp = ct_mock.build_ct_mock_ncp(tmp_path / "ncp.zip")
    with caplog.at_level(logging.INFO):
        run_pipeline_on_fixture_inputs(
            tmp_path / "run", ncp, enable_nx_analysis=False, ra_types=ra_types, calculation_mode="ac_single_pass",
        )
    assert _label(caplog) == label


def test_every_validation_warning_of_the_spec_is_written_and_the_good_ra_still_runs(tmp_path, caplog, monkeypatch):
    from pre_milp import ct_units

    original = ct_units.read_generator_table

    def galia_at_pmax(network):
        table = original(network)
        for gu in (ct_mock.GA_G1, ct_mock.GA_G2, ct_mock.GA_G3):
            table[gu].prod = table[gu].pmax                 # Galia cannot move up
        return table

    monkeypatch.setattr(ct_units, "read_generator_table", galia_at_pmax)
    ras = (
        ct_mock.default_ras() + ct_mock.unknown_strategy_ras() + ct_mock.mixed_strategy_ras() + ct_mock.bad_zone_ras()
        + [ct_mock.ra("nordheim", ct_mock.ZONE_NORDHEIM, [ct_mock.bid("nordheim-up", "up")])]
        + ct_mock.missing_penalty_ras() + ct_mock.no_volume_ras()
    )
    ncp = ct_mock.build_ct_mock_ncp(tmp_path / "ncp.zip", ras=ras)
    with caplog.at_level(logging.WARNING):
        run_pipeline_on_fixture_inputs(
            tmp_path / "run", ncp, enable_nx_analysis=False, ra_types=("countertrade",), calculation_mode="ac_single_pass",
        )
    warnings = [r.getMessage() for r in caplog.records if r.levelno >= logging.WARNING]

    def has(*parts):
        return any(all(part in message for part in parts) for message in warnings)

    assert has("IGNORED", "explicitInstruction", "not implemented")                  # not implemented strategy
    assert has("IGNORED", "different gLSKStrategy")                                  # mixed strategies
    assert has("DROPPED", "not in the Organisation profile")                         # zone not found
    assert has("DROPPED", "has no generating unit")                                  # zone without units
    assert has("has no volume")                                                      # bid without volume
    assert has("no unit can move up", "fixed to 0")                                  # no unit left in a direction
    assert has("no RemedialAction.penaltyFactor", "1.0")                             # missing penaltyFactor
    assert (tmp_path / "run" / "output" / "results_summary.csv").exists()            # the usable RAs ran
