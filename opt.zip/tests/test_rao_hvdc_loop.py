"""
test_rao_hvdc_loop.py — HVDC in the shared loop code (docs/hvdc_ra_specs.md H9): the refresh of the
N-0 sensitivities at the applied state, the model built at that state, the write-back dictionary and
the iteration log line. Fakes instead of a network.
"""
import logging

import pytest

from data_model import HvdcUnit, RAKind
from milp import ac_convergence_loop
from milp.ac_convergence_loop import _log_iteration_summary, _refresh_n0_sensitivities, build_model_at_state
from milp.milp_builder import HvdcMilpInputs
from milp.operating_point_state import OperatingPointState
from milp.post_ra_congestion_check import extract_hvdc_target_p_solution

TS = "1030Z"


def _unit(mrid, ei, kind=RAKind.PREVENTIVE):
    return HvdcUnit(mrid=mrid, name=mrid, tso="TSO-A", ei_mrid=ei, available=True, kind=kind, penalty_factor=1.0,
                    group_mrid="G")


def _hvdc_inputs():
    return HvdcMilpInputs(
        units=[_unit("U1", "E1"), _unit("U2", "E2")], limits={"U1": (-500.0, 500.0), "U2": (-500.0, 500.0)},
        original_p_mw={"E1": 100.0, "E2": 50.0}, current_p_mw={"E1": 100.0, "E2": 50.0},
        sensitivity_hvdc_n0={("B1", "E1"): -2.0}, penalty_reference_pra=10.0,
    )


def _state(hvdc_n0=None):
    return OperatingPointState.at_original_network(
        [], {"E1": {"target_p": 100.0}, "E2": {"target_p": 50.0}}, {"B1": {1: 120.0, 2: 120.0}}, None, {}, {},
        monitored_branches_n0={"B1"}, sensitivity_hvdc_n0=hvdc_n0 if hvdc_n0 is not None else {("B1", "E1"): -2.0},
        sensitivity_hvdc_nx={},
    )


class TestRefreshOfTheN0Sensitivities:
    def test_the_hvdc_sensitivities_are_recomputed_at_the_applied_state(self, monkeypatch):
        calls = []

        def fake(network, ei_mrids, ae_flat_list, timestamp, **kwargs):
            calls.append((sorted(ei_mrids), kwargs["lf_initial"], kwargs["extra_lf_params"]["voltage_init_mode"]))
            kwargs["guard_out"].clear()
            return {("B1", "E1"): -2.5, ("B1", "E2"): 0.1}

        monkeypatch.setattr(ac_convergence_loop, "compute_sensitivity_hvdc_n0", fake)
        state = _state()
        state.current_lf_n0 = {"B1": {1: 111.0, 2: 111.0}}
        failure = _refresh_n0_sensitivities(
            state, None, [], [], [], TS, 0.0, 0.0, False, {}, allowed=({"B1"}, set(), set()), hvdc_inputs=_hvdc_inputs(),
        )
        assert failure is None
        assert state.sensitivity_hvdc_n0 == {("B1", "E1"): -2.5, ("B1", "E2"): 0.1}
        assert calls[0][0] == ["E1", "E2"] and calls[0][1] == {"B1": {1: 111.0, 2: 111.0}}
        assert "PREVIOUS_VALUES" in str(calls[0][2])                           # warm start, as the RD refresh

    def test_an_invalid_branch_gets_the_last_valid_hvdc_set(self, monkeypatch):
        def fake(network, ei_mrids, ae_flat_list, timestamp, **kwargs):
            kwargs["guard_out"].update({"B1": "zero reference current"})
            return {("B1", "E1"): 0.0, ("B1", "E2"): 0.0}

        monkeypatch.setattr(ac_convergence_loop, "compute_sensitivity_hvdc_n0", fake)
        state = _state({("B1", "E1"): -2.0})
        failure = _refresh_n0_sensitivities(
            state, None, [], [], [], TS, 0.0, 0.0, False, {}, allowed=({"B1"}, set(), set()), hvdc_inputs=_hvdc_inputs(),
        )
        assert failure is None
        assert state.sensitivity_hvdc_n0 == {("B1", "E1"): -2.0}
        assert state.stale_reused_n0 == {"B1": "stale_reused"}

    def test_no_hvdc_inputs_leave_the_hvdc_state_alone(self, monkeypatch):
        monkeypatch.setattr(ac_convergence_loop, "compute_sensitivity_hvdc_n0",
                            lambda *a, **k: pytest.fail("HVDC sensitivities requested without HVDC inputs"))
        state = _state()
        before = dict(state.sensitivity_hvdc_n0)
        assert _refresh_n0_sensitivities(state, None, [], [], [], TS, 0.0, 0.0, False, {}, allowed=({"B1"}, set(), set())) is None
        assert state.sensitivity_hvdc_n0 == before


class TestBuildAtTheOperatingPoint:
    @staticmethod
    def _build(state, hvdc_inputs):
        from data_model import AEType, AssessedElement

        ae = [AssessedElement(mrid="AE-B1", name="B1", tso="TSO-A", ae_type=AEType.SECURED, branch_mrid="B1",
                              secured_for_region=None, scanned_for_region=None, exclusion_reason=None,
                              patl_ka={TS: 0.1}, branch_side=1)]
        model, _psts, _gen = build_model_at_state(
            state, None, pst_list=[], rd_list=[], ae_flat_list=ae, timestamp=TS, lf_before=state.current_lf_n0,
            pst_tap_bounds={}, pst_group_equality_pairs=[], pst_degrees_per_tap={}, penalty_reference_pst_pra=0.0,
            penalty_reference_pst_pra_per_tso=None, penalty_reference_rd_pra=0.0, penalty_reference_rd_pra_per_tso=None,
            penalty_cost_overload_n0=10000.0, generator_data={"E1": {"target_p": 100.0}, "E2": {"target_p": 50.0}},
            bid_list=[], glsk={}, ra_groups=None, raart=None, max_ra_count_per_timestamp_tso=None,
            max_ra_count_per_timeframe_tso=None, ra_limit_penalty=0.0, ra_limit_constraint_hard=True,
            min_loading_threshold_pct=0.0, pst_taping_discrete=True, max_taps_per_tso=6, max_taps_per_tso_overrides=None,
            scanned_element_constraint_hard=True, scanned_element_penalty_eur_per_ka=0.0, unit_costs=None,
            hvdc_inputs=hvdc_inputs,
        )
        return model

    def test_the_model_uses_the_set_points_and_sensitivities_of_the_state(self):
        state = _state({("B1", "E1"): -7.0})
        state.current_target_p_by_gu.update(E1=104.0, E2=46.0)         # an earlier iteration moved the pair by 4 MW
        model = self._build(state, _hvdc_inputs())
        assert model.hvdc_info["U1"]["p_current_mw"] == 104.0 and model.hvdc_info["U1"]["p_original_mw"] == 100.0
        assert model.hvdc_info["U2"]["p_current_mw"] == 46.0
        model.hvdc_dp_up["U1"].set_value(1.0)
        model.hvdc_dp_down["U1"].set_value(0.0)
        model.hvdc_dp_up["U2"].set_value(0.0)
        model.hvdc_dp_down["U2"].set_value(1.0)
        import pyomo.environ as pyo
        assert pyo.value(model.hvdc_effect_on_branch["B1"]) == pytest.approx(-7.0)       # the state's sensitivity, not the input's

    def test_without_hvdc_inputs_and_nothing_else_the_builder_has_nothing_to_optimise(self):
        with pytest.raises(ValueError, match="hvdc_inputs"):
            self._build(_state(), None)


class TestWriteBackAndLog:
    def test_the_solution_dictionary_has_the_hvdc_eis_only(self):
        state = _state()
        model = TestBuildAtTheOperatingPoint._build(state, _hvdc_inputs())
        for variable in (model.hvdc_dp_up, model.hvdc_dp_down):
            for index in variable:
                variable[index].set_value(0.0)
        assert extract_hvdc_target_p_solution(model) == {"E1": 100.0, "E2": 50.0}

    def test_the_iteration_line_reports_hvdc_on_its_own_and_not_as_redispatch(self, caplog):
        import pyomo.environ as pyo

        class Model:
            pass

        original = {"E1": 100.0, "E2": 50.0, "G": 10.0}
        solution = {"E1": 110.0, "E2": 40.0}
        with caplog.at_level(logging.INFO):
            _log_iteration_summary("T", 1, 1, Model(), {}, {}, {}, solution, {}, original, "direct jump",
                                   hvdc_ei_mrids=frozenset({"E1", "E2"}))
        line = caplog.records[-1].message
        assert "RD activated=0 generating unit(s) (0.0 MW redispatched)" in line
        assert "HVDC activated=2 unit(s) (10.0 MW moved per side)" in line

    def test_the_line_is_unchanged_without_hvdc(self, caplog):
        class Model:
            pass

        with caplog.at_level(logging.INFO):
            _log_iteration_summary("T", 1, 1, Model(), {}, {}, {}, {"G": 15.0}, {}, {"G": 10.0}, "direct jump")
        assert "HVDC" not in caplog.records[-1].message
        assert "RD activated=1 generating unit(s)" in caplog.records[-1].message


class TestCycleExitAndSnapshots:
    def test_the_snapshot_holds_the_hvdc_set_point_change_of_the_ei(self):
        state = _state()
        state.record_applied_solution({}, {"E1": 112.0, "E2": 38.0}, {}, {"B1": {1: 100.0, 2: 100.0}})
        assert state.solution_snapshots[-1]["net_rd_mw"] == {"E1": 12.0, "E2": -12.0}

    def test_a_repetition_that_differs_only_in_the_hvdc_set_points_is_not_a_cycle(self):
        from milp.operating_point_state import find_cyclic_repetition

        zero = {"tap": {}, "net_rd_mw": {"E1": 0.0, "E2": 0.0}}
        moved = {"tap": {}, "net_rd_mw": {"E1": 12.0, "E2": -12.0}}
        # the newest solution against an earlier one: equal HVDC set points -> cycle, different -> none
        same = [zero, moved, {"tap": {}, "net_rd_mw": {"E1": 5.0, "E2": -5.0}}, {"tap": {}, "net_rd_mw": {"E1": 12.0, "E2": -12.0}}]
        assert find_cyclic_repetition(same, 0.5) == (1, 0.0)
        different = [zero, moved, {"tap": {}, "net_rd_mw": {"E1": 5.0, "E2": -5.0}}, {"tap": {}, "net_rd_mw": {"E1": 20.0, "E2": -20.0}}]
        assert find_cyclic_repetition(different, 0.5) is None

    def test_a_cycle_of_the_hvdc_set_points_keeps_the_member_with_the_lowest_overload(self):
        from milp.ac_convergence_loop import select_best_cycle_member

        # (iteration, total AC overload A, cumulative cost): the lowest overload wins, ties by the lowest cost
        assert select_best_cycle_member([(1, 12.0, 100.0), (2, 3.0, 400.0), (3, 3.0, 300.0)]) == 3