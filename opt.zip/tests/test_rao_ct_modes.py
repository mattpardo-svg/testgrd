"""
test_rao_ct_modes.py — countertrade in the three calculation modes and together with the other RA types
(docs/countertrade_ra_specs.md C3.5, C8): run_pipeline.main() on the generated mock (tests/ct_mock.py).
ac_iterative: sensitivities refreshed every iteration, the weights fixed; ac_single_pass: one pass; dc: DC
sensitivities, one pass. The set points travel in the same dictionary as the RD ones (apply, restore).
"""
import csv
from types import SimpleNamespace

import pyomo.environ as pyo
import pytest

import ct_mock
import hvdc_mock
from helpers import run_pipeline_on_fixture_inputs

BELGOVIA_BO4 = ct_mock.BRANCH_GA_BO4_BELGOVIA
ORIGINAL_P = {
    ct_mock.BO_G1: 52.8181, ct_mock.BO_G2: 78.9071, ct_mock.GA_G1: 705.637, ct_mock.GA_G2: 180.0, ct_mock.GA_G3: 180.0,
}
DC_PATL_A = 70.0       # the DC model loads the Belgovia half of TieLine_GA_BO4 with 84.8 A (the AC model with 124.1 A)


def _read_csv(path):
    with open(path, encoding="utf-8", newline="") as f:
        return list(csv.DictReader(f))


def _summary(output_dir):
    return {row["metric"]: row["value"] for row in _read_csv(output_dir / "results_summary.csv")}


def _run(tmp_path, mode, ra_types=("countertrade",), patl_a=ct_mock.DEFAULT_PATL_A, nx=False, source_zip=None):
    """One run with the models, the set points handed to the network and the CT inputs of every build recorded."""
    tmp_path.mkdir(parents=True, exist_ok=True)
    kwargs = {"source_zip": source_zip} if source_zip is not None else {}
    ncp = ct_mock.build_ct_mock_ncp(tmp_path / "ncp.zip", patl_a=patl_a, **kwargs)
    record = SimpleNamespace(models=[], applied=[], ct_inputs=[])

    def hooks(rp, monkeypatch):
        loop = rp.ac_convergence_loop
        build, apply, build_at_state = loop.build_n0_milp_model, loop.apply_preventive_solution_to_network, loop.build_model_at_state

        def keeping_build(*args, **kw):
            model = build(*args, **kw)
            record.models.append(model)
            return model

        def recording_apply(network, pst_tap_solution, rd_target_p_solution):
            record.applied.append(dict(rd_target_p_solution))
            return apply(network, pst_tap_solution=pst_tap_solution, rd_target_p_solution=rd_target_p_solution)

        def recording_build_at_state(*args, **kw):
            record.ct_inputs.append(kw.get("ct_inputs"))
            return build_at_state(*args, **kw)

        monkeypatch.setattr(loop, "build_n0_milp_model", keeping_build)
        monkeypatch.setattr(loop, "apply_preventive_solution_to_network", recording_apply)
        monkeypatch.setattr(loop, "build_model_at_state", recording_build_at_state)
        # single_pass and dc_pass call build_model_at_state through their own import
        for module in (rp.single_pass, rp.dc_pass):
            monkeypatch.setattr(module, "build_model_at_state", recording_build_at_state)

    run = run_pipeline_on_fixture_inputs(
        tmp_path / "run", ncp, enable_nx_analysis=nx, ra_types=ra_types, calculation_mode=mode, customize_pipeline=hooks,
    )
    record.output_dir = run.output_dir
    return record


def _final_changes(record):
    """{unit: final target_p - original} of the last solution handed to the network."""
    last = record.applied[-1]
    return {gu: last[gu] - ORIGINAL_P[gu] for gu in ORIGINAL_P if gu in last}


@pytest.fixture(scope="module", params=["ac_iterative", "ac_single_pass", "dc"])
def mode_run(request, tmp_path_factory):
    patl = DC_PATL_A if request.param == "dc" else ct_mock.DEFAULT_PATL_A
    result = _run(tmp_path_factory.mktemp(request.param), request.param, patl_a=patl)
    result.mode = request.param
    return result


def test_each_mode_relieves_the_branch_with_belgovia_down_and_galia_up(mode_run):
    change = _final_changes(mode_run)
    belgovia = change[ct_mock.BO_G1] + change[ct_mock.BO_G2]
    galia = change[ct_mock.GA_G1] + change[ct_mock.GA_G2] + change[ct_mock.GA_G3]
    assert belgovia < -20.0 and galia > 20.0 and belgovia + galia == pytest.approx(0.0, abs=1e-6)
    # the remaining-capacity weights act on the units: the down weights in Belgovia, the up weights in Galia
    assert change[ct_mock.BO_G1] / belgovia == pytest.approx(ct_mock.EXPECTED_WEIGHTS[("Belgovia", "down")][ct_mock.BO_G1], abs=1e-6)
    assert change[ct_mock.GA_G1] / galia == pytest.approx(ct_mock.EXPECTED_WEIGHTS[("Galia", "up")][ct_mock.GA_G1], abs=1e-6)


def test_the_ac_check_after_each_mode(mode_run):
    row = [r for r in _read_csv(mode_run.output_dir / "lf_post_n0.csv") if r["branch_mrid"] == BELGOVIA_BO4][-1]    # the last iteration
    before, after = float(row["i_ka_before"]), float(row["i_ka_after"])
    assert row["solution_applied_to_network"] == "true"
    if mode_run.mode == "ac_iterative":
        assert after <= 0.110 * 1.0001
        assert _summary(mode_run.output_dir)["ac_verification_status"] == "CONVERGED"
    elif mode_run.mode == "ac_single_pass":
        assert after <= 0.110 * 1.02 and after < before - 0.010
    else:
        # the DC model relieves its own (DC) value; the AC check of the applied state is below the original AC current
        assert after < ct_mock.INITIAL_CURRENT_A / 1000.0


def test_the_objective_is_the_sum_of_the_terms_in_each_mode(mode_run):
    summary = _summary(mode_run.output_dir)
    assert float(summary["objective_residual_eur"]) == pytest.approx(0.0, abs=1e-6)
    assert summary["calculation_mode"] == mode_run.mode and summary["ra_types"] == "countertrade"
    model = mode_run.models[-1]
    terms = {name: pyo.value(expression) for name, expression in model.objective_penalty_term_expressions.items()}
    assert pyo.value(model.objective) == pytest.approx(sum(terms.values()), rel=1e-9)


def test_in_ac_iterative_the_weights_are_the_same_in_every_iteration(mode_run):
    if mode_run.mode != "ac_iterative":
        pytest.skip("iterations exist in ac_iterative only")
    assert len(mode_run.models) >= 3 and len(mode_run.ct_inputs) == len(mode_run.models)
    first = mode_run.ct_inputs[0]
    assert all(inputs is first for inputs in mode_run.ct_inputs)            # passed unchanged, never recomputed
    expected = {}
    for (zone, direction), weights in ct_mock.EXPECTED_WEIGHTS.items():
        bid = ct_mock._uid("bid", "BO" if zone == "Belgovia" else "GA", f"{'BO' if zone == 'Belgovia' else 'GA'}-{direction}")
        expected[bid] = weights
    for bid, weights in expected.items():
        assert first.bid_participation[bid] == pytest.approx(weights, abs=1e-6)
    # and the net injection of every build follows them: units move in proportion to the same weights
    for model in mode_run.models:
        bo_down = ct_mock._uid("bid", "BO", "BO-down")
        volume = pyo.value(model.rd_volume_downward[bo_down])
        if volume > 1e-6:
            assert pyo.value(model.rd_net_injection_g[ct_mock.BO_G1]) == pytest.approx(
                -volume * ct_mock.EXPECTED_WEIGHTS[("Belgovia", "down")][ct_mock.BO_G1], abs=1e-6)


def test_the_dc_mode_uses_dc_sensitivities_and_one_pass(mode_run):
    if mode_run.mode != "dc":
        pytest.skip("dc only")
    assert len(mode_run.models) == 1 and _summary(mode_run.output_dir)["calculation_mode"] == "dc"


def test_a_dc_run_without_a_dc_overload_leaves_the_set_points_unchanged(tmp_path):
    result = _run(tmp_path, "dc", patl_a=None)
    assert all(abs(solution.get(gu, ORIGINAL_P[gu]) - ORIGINAL_P[gu]) < 1e-9 for solution in result.applied for gu in ORIGINAL_P)
    model = result.models[-1]
    assert sum(abs(pyo.value(model.rd_net_injection_g[gu])) for gu in model.gu_ids) == pytest.approx(0.0, abs=1e-9)


# ---------------------------------------------------------------------------
# write-back: apply and restore through the RD dictionary
# ---------------------------------------------------------------------------

def test_the_ct_set_points_are_applied_and_restored_like_the_rd_ones():
    from pre_milp import cgmes_loader
    from milp.post_ra_congestion_check import apply_preventive_solution_to_network, restore_network_state
    from helpers import FIXTURE_CGM_ZIP

    network = cgmes_loader.load_cgm(FIXTURE_CGM_ZIP)
    solution = {ct_mock.BO_G1: ORIGINAL_P[ct_mock.BO_G1] - 20.0, ct_mock.GA_G1: ORIGINAL_P[ct_mock.GA_G1] + 20.0}
    _, previous = apply_preventive_solution_to_network(network, pst_tap_solution={}, rd_target_p_solution=solution)
    generators = network.get_generators()
    assert generators.loc[ct_mock.BO_G1, "target_p"] == pytest.approx(solution[ct_mock.BO_G1])
    assert generators.loc[ct_mock.GA_G1, "target_p"] == pytest.approx(solution[ct_mock.GA_G1])
    restore_network_state(network, previous_taps={}, previous_target_p=previous)
    generators = network.get_generators()
    assert generators.loc[ct_mock.BO_G1, "target_p"] == pytest.approx(ORIGINAL_P[ct_mock.BO_G1], abs=1e-4)
    assert generators.loc[ct_mock.GA_G1, "target_p"] == pytest.approx(ORIGINAL_P[ct_mock.GA_G1], abs=1e-4)


# ---------------------------------------------------------------------------
# coexistence with the other RA types
# ---------------------------------------------------------------------------

def test_pst_rd_hvdc_and_countertrade_run_together(tmp_path):
    hvdc_zip = hvdc_mock.build_hvdc_mock_ncp(tmp_path / "hvdc.zip")
    result = _run(tmp_path / "all", "ac_single_pass", ra_types=("pst", "rd", "hvdc", "countertrade"), source_zip=hvdc_zip)
    summary = _summary(result.output_dir)
    assert summary["ra_types"] == "pst+rd+hvdc+countertrade"
    names = {p.name for p in result.output_dir.glob("*")}
    assert {"results_pst.csv", "results_preventive_rd.csv", "results_hvdc.csv"} <= names
    model = result.models[-1]
    # every block is in the one model: PST taps, RD and CT bids on the same variables, the HVDC set points
    assert hasattr(model, "tap_change_upward") and hasattr(model, "hvdc_change")
    rd_bids = [b for b in model.bid_ids if b not in model.ct_bid_ids]
    assert rd_bids and len(model.ct_bid_ids) == 4
    assert float(summary["objective_residual_eur"]) == pytest.approx(0.0, abs=1e-6)
    assert float(summary["sum_hvdc_penalty_cost_eur"]) >= 0.0


def test_countertrade_with_hvdc_only(tmp_path):
    hvdc_zip = hvdc_mock.build_hvdc_mock_ncp(tmp_path / "hvdc.zip")
    result = _run(tmp_path / "run", "ac_iterative", ra_types=("hvdc", "countertrade"), source_zip=hvdc_zip)
    assert _summary(result.output_dir)["ra_types"] == "hvdc+countertrade"
    assert "results_hvdc.csv" in {p.name for p in result.output_dir.glob("*")}


# ---------------------------------------------------------------------------
# convergence criteria and the iteration log count the countertrade MW
# ---------------------------------------------------------------------------

def test_the_criteria_count_the_countertrade_megawatts(mode_run):
    if mode_run.mode != "ac_iterative":
        pytest.skip("iterations exist in ac_iterative only")
    rows = _read_csv(mode_run.output_dir / "results_iteration_history.csv")
    first = float(rows[0]["sum_abs_rd_change_mw"])
    volume = pyo.value(mode_run.models[0].rd_volume_downward[ct_mock._uid("bid", "BO", "BO-down")])
    assert first == pytest.approx(2.0 * volume, rel=1e-6) and float(rows[0]["max_abs_rd_change_mw"]) > 0.0
    assert rows[0]["criterion_1_met"] == "False"                     # 142.9 MW moved is above the threshold
    assert rows[-1]["criterion_1_met"] == "True" and rows[-1]["criterion_3_met"] == "True" and rows[-1]["converged"] == "True"


def test_the_iteration_log_line_shows_the_countertrade_volume(tmp_path, caplog):
    import logging
    with caplog.at_level(logging.INFO):
        _run(tmp_path, "ac_iterative")
    lines = [r.getMessage() for r in caplog.records if "] Iteration" in r.getMessage()]
    assert len(lines) >= 3 and all("countertrade:" in line and "MW up" in line and "MW down" in line for line in lines)
    assert "countertrade: 71." in lines[0]


def test_the_iteration_log_line_has_no_countertrade_text_without_countertrade(tmp_path, caplog):
    import logging
    with caplog.at_level(logging.INFO):
        run_pipeline_on_fixture_inputs(
            tmp_path, ct_mock.build_ct_mock_ncp(tmp_path / "ncp.zip", ras=[], patl_a=None), enable_nx_analysis=False,
            ra_types=("rd",), calculation_mode="ac_iterative",
        )
    lines = [r.getMessage() for r in caplog.records if "] Iteration" in r.getMessage()]
    assert lines and not any("countertrade" in line for line in lines)