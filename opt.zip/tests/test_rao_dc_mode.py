"""tests/test_rao_dc_mode.py - calculation_mode dc (docs/dc_mode_specs.md): the DC calculation
steps on the fixture CGM (load flow, security analysis, sensitivities) and the DC pipeline runs.

Sections: DC load flow and initial currents, DC N-X security analysis, DC sensitivities,
runs of main() (added with the DC pipeline path).
"""

import math
from types import SimpleNamespace

import pytest

import run_pipeline
from helpers import _MOCK_NX_CGM_ZIP
from pre_milp import cgmes_loader, dc_conversion
from text_encoding import TEXT_ENCODING  # noqa: E402


def _load():
    return cgmes_loader.load_cgm(cgm_zip_override=_MOCK_NX_CGM_ZIP)


def _converter(network, table=None):
    return dc_conversion.DcCurrentConverter.from_network(
        network, run_pipeline.DC_POWER_FACTOR, table or {"default": 1.0},
    )


# ===========================================================================
# DC load flow and initial currents
# ===========================================================================

@pytest.fixture(scope="module")
def dc_state():
    network = _load()
    target_p_before = network.get_generators()["target_p"].copy()
    cgmes_loader.run_initial_dc_loadflow(
        network, use_reactive_limits=run_pipeline.USE_REACTIVE_LIMITS, extra_lf_params=run_pipeline.EXTRA_LF_PARAMS,
    )
    return network, target_p_before


@pytest.fixture(scope="module")
def ac_lf_initial():
    network = _load()
    cgmes_loader.run_initial_loadflow(
        network, use_reactive_limits=run_pipeline.USE_REACTIVE_LIMITS, extra_lf_params=run_pipeline.EXTRA_LF_PARAMS,
    )
    return cgmes_loader.build_lf_initial(network)


def test_target_p_is_unchanged_after_the_dc_load_flow_with_distributed_slack(dc_state):
    network, target_p_before = dc_state

    assert run_pipeline.EXTRA_LF_PARAMS["distributed_slack"] is True
    target_p_after = network.get_generators()["target_p"]
    assert len(target_p_after) == 113
    assert float((target_p_after - target_p_before).abs().max()) == 0.0


def test_the_ac_build_of_the_initial_currents_is_all_nan_after_a_dc_load_flow(dc_state):
    """The silent-NaN trap the DC variant avoids: i1/i2 do not exist after run_dc."""
    network, _ = dc_state

    lf = cgmes_loader.build_lf_initial(network)

    assert all(math.isnan(v) for per_side in lf.values() for v in per_side.values())


def test_lf_n0_in_dc_mode_has_no_nan_current_for_a_connected_branch_side(dc_state, ac_lf_initial):
    network, _ = dc_state

    lf = cgmes_loader.build_lf_initial(network, dc_converter=_converter(network))

    assert set(lf) == set(ac_lf_initial)
    nan_dc = {(b, s) for b, per_side in lf.items() for s, v in per_side.items() if math.isnan(v)}
    nan_ac = {(b, s) for b, per_side in ac_lf_initial.items() for s, v in per_side.items() if math.isnan(v)}
    assert nan_dc == nan_ac  # only the disconnected sides are NaN, exactly as in AC
    assert len(nan_dc) < sum(len(v) for v in lf.values()) / 10
    assert all(v >= 0.0 for per_side in lf.values() for v in per_side.values() if v == v)


def test_dc_currents_at_factor_one_equal_the_pypowsybl_dc_security_analysis_pre_contingency_currents(dc_state):
    """Regression of the formula against the investigation: |P| x 1000 / (sqrt(3) x V_nom x pf)."""
    import pypowsybl as pp
    from pre_milp.lf_parameters import build_security_analysis_parameters

    network, _ = dc_state
    lf = cgmes_loader.build_lf_initial(network, dc_converter=_converter(network))
    lines = network.get_lines()
    analysis = pp.security.create_analysis()
    analysis.add_single_element_contingency(lines.index[0], "c0")
    analysis.add_monitored_elements(branch_ids=list(lf))
    result = analysis.run_dc(
        network, parameters=build_security_analysis_parameters(
            run_pipeline.USE_REACTIVE_LIMITS, run_pipeline.EXTRA_LF_PARAMS),
    )
    pre = result.branch_results.xs("", level="contingency_id").droplevel("operator_strategy_id")
    pre = pre[~pre.index.duplicated()]

    compared = 0
    for branch_mrid, row in pre.iterrows():
        for side in (1, 2):
            if row[f"i{side}"] == row[f"i{side}"]:
                assert lf[branch_mrid][side] == pytest.approx(row[f"i{side}"], abs=1e-9)
                compared += 1
    assert compared > 300


# ===========================================================================
# DC N-X security analysis and DC sensitivities (N-0 and N-X)
# ===========================================================================

TIMESTAMP = "1030Z"


def _ae(branch_mrid, side=1, patl_ka=5.0):
    from data_model import AEType, AssessedElement
    return AssessedElement(
        mrid=f"ae-{branch_mrid}", name="a", tso="T", ae_type=AEType.SECURED, branch_mrid=branch_mrid,
        secured_for_region=None, scanned_for_region=None, exclusion_reason=None,
        patl_ka={TIMESTAMP: patl_ka}, branch_side=side,
    )


def _contingency(line_mrid):
    from data_model import Contingency, ContingencyType
    return Contingency(
        mrid=f"co-{line_mrid}", name="co", tso="T", contingency_type=ContingencyType.ORDINARY,
        must_study={TIMESTAMP: True}, equipment_mrids=[line_mrid],
    )


def _pst(mrid):
    from data_model import PST, RAKind
    return PST(
        mrid=mrid, name="pst", tso="T", available=True, kind=RAKind.PREVENTIVE, penalty_factor=1.0, low_step=-10,
        high_step=10, r0=0, operating_tap_min=-10, operating_tap_max=10, group_id=None,
    )


def _rd(gu_mrid):
    from data_model import RAKind, RDUnit
    return RDUnit(
        mrid=f"rd-{gu_mrid}", name="rd", tso="T", gu_mrid=gu_mrid, gu_name="gu", available=True, kind=RAKind.PREVENTIVE,
        initial_p=10.0, max_p=100.0, min_p=0.0, raise_ramp_rate=None, lower_ramp_rate=None,
    )


def _dc_network():
    network = _load()
    cgmes_loader.run_initial_dc_loadflow(
        network, use_reactive_limits=run_pipeline.USE_REACTIVE_LIMITS, extra_lf_params=run_pipeline.EXTRA_LF_PARAMS,
    )
    return network


@pytest.fixture(scope="module")
def dc_case():
    """The DC network with its converter, converted initial currents and 60 monitored lines."""
    network = _dc_network()
    converter = _converter(network)
    lf = cgmes_loader.build_lf_initial(network, dc_converter=converter)
    # lines with a flow on both sides: the others (dead ends, islands) are not in the analysis results
    lines = [b for b in network.get_lines().index if all(v == v for v in lf[b].values())]
    return SimpleNamespace(
        network=network, converter=converter, lf=lf, branches=lines[:60], lines=lines,
        ae=[_ae(b) for b in lines[:60]],
    )


def _nx_inputs(case, contingency_lines):
    contingencies = [_contingency(line) for line in contingency_lines]
    return contingencies, case.ae


def _pypowsybl_dc_branch_results(case, contingency_lines):
    """branch_results of pypowsybl's own DC security analysis (with its i1/i2) for these outages."""
    import pypowsybl as pp
    from pre_milp.lf_parameters import build_security_analysis_parameters

    analysis = pp.security.create_analysis()
    for line in contingency_lines:
        analysis.add_single_element_contingency(line, f"co-{line}")
    analysis.add_monitored_elements(branch_ids=case.branches)
    return analysis.run_dc(
        case.network, parameters=build_security_analysis_parameters(
            run_pipeline.USE_REACTIVE_LIMITS, run_pipeline.EXTRA_LF_PARAMS),
    ).branch_results


def test_the_dc_n_x_currents_apply_the_factor_of_the_nominal_voltage_of_each_side(dc_case):
    """With factors != 1.0 the N-X currents are our formula on the DC p1/p2: pypowsybl's own i1/i2
    (factor 1.0 by construction) times the factor of the side's nominal voltage. Taking i1/i2
    from pypowsybl would lose the factors."""
    from pre_milp.nx_security_analysis import compute_lf_nx

    network = dc_case.network
    table = {"default": 1.25, 400: 0.8}
    contingency_lines = dc_case.lines[60:62]
    contingencies, ae = _nx_inputs(dc_case, contingency_lines)

    lf_nx, _ = compute_lf_nx(
        network, contingencies, ae, TIMESTAMP, lf_initial=dc_case.lf,
        use_reactive_limits=run_pipeline.USE_REACTIVE_LIMITS, extra_lf_params=run_pipeline.EXTRA_LF_PARAMS,
        dc_converter=_converter(network, table),
    )

    reference = _pypowsybl_dc_branch_results(dc_case, contingency_lines)
    nominal_v = network.get_voltage_levels()["nominal_v"]
    lines = network.get_lines()
    factors_seen = set()
    for contingency in contingencies:
        rows = reference.xs(contingency.mrid, level="contingency_id").droplevel("operator_strategy_id")
        rows = rows[~rows.index.duplicated()]
        for branch_mrid, per_side in lf_nx[contingency.mrid].items():
            for side in (1, 2):
                kv = float(nominal_v[lines.loc[branch_mrid, f"voltage_level{side}_id"]])
                factor = table.get(kv, table["default"])
                factors_seen.add(factor)
                assert per_side[side] == pytest.approx(factor * rows.loc[branch_mrid, f"i{side}"], rel=1e-9)
    assert factors_seen == {1.25, 0.8}


def test_the_dc_n_x_currents_equal_the_pypowsybl_dc_security_analysis_and_have_no_nan(dc_case):
    from pre_milp.nx_security_analysis import compute_lf_nx

    contingency_lines = dc_case.lines[60:64]
    contingencies, ae = _nx_inputs(dc_case, contingency_lines)

    lf_nx, skipped = compute_lf_nx(
        dc_case.network, contingencies, ae, TIMESTAMP, lf_initial=dc_case.lf,
        use_reactive_limits=run_pipeline.USE_REACTIVE_LIMITS, extra_lf_params=run_pipeline.EXTRA_LF_PARAMS,
        dc_converter=dc_case.converter,
    )

    assert not skipped and set(lf_nx) == {c.mrid for c in contingencies}
    reference = _pypowsybl_dc_branch_results(dc_case, contingency_lines)
    compared = 0
    for contingency in contingencies:
        rows = reference.xs(contingency.mrid, level="contingency_id").droplevel("operator_strategy_id")
        rows = rows[~rows.index.duplicated()]
        for branch_mrid, per_side in lf_nx[contingency.mrid].items():
            assert all(v == v and v >= 0.0 for v in per_side.values())  # no NaN, magnitudes
            for side in (1, 2):
                assert per_side[side] == pytest.approx(rows.loc[branch_mrid, f"i{side}"], abs=1e-9)
                compared += 1
    assert compared > 200


def test_the_dc_n_0_pst_sensitivity_is_in_ampere_per_degree_and_passes_the_guard(dc_case):
    from pre_milp.n0_sensitivity import compute_sensitivity_pst_n0

    network = dc_case.network
    pst_id = str(network.get_phase_tap_changers().index[0])
    guard = {}
    sensitivity = compute_sensitivity_pst_n0(
        network, [_pst(pst_id)], dc_case.ae, TIMESTAMP, lf_initial=dc_case.lf, guard_out=guard,
        use_reactive_limits=run_pipeline.USE_REACTIVE_LIMITS, extra_lf_params=run_pipeline.EXTRA_LF_PARAMS,
        dc_converter=dc_case.converter,
    )

    assert guard == {}  # the converted DC reference equals the converted DC load flow
    assert len(sensitivity) == len(dc_case.branches) and all(v == v for v in sensitivity.values())
    # finite difference: one tap step in a DC load flow (linear in the phase shift)
    steps = network.get_phase_tap_changer_steps().loc[pst_id].sort_index()
    row = network.get_phase_tap_changers().loc[pst_id]
    tap, low, high = int(row["tap"]), int(row["low_tap"]), int(row["high_tap"])
    new_tap = tap + 1 if tap < high else tap - 1
    degrees = steps["alpha"].iloc[new_tap - low] - steps["alpha"].iloc[tap - low]
    moved = _dc_network()
    moved.update_phase_tap_changers(id=pst_id, tap=new_tap)
    cgmes_loader.run_initial_dc_loadflow(
        moved, use_reactive_limits=run_pipeline.USE_REACTIVE_LIMITS, extra_lf_params=run_pipeline.EXTRA_LF_PARAMS,
    )
    lf_moved = cgmes_loader.build_lf_initial(moved, dc_converter=dc_case.converter)
    compared = 0
    for (branch_mrid, _), value in sensitivity.items():
        difference = (lf_moved[branch_mrid][1] - dc_case.lf[branch_mrid][1]) / degrees
        if abs(value) > 1e-3:
            assert difference == pytest.approx(value, rel=0.03, abs=1e-3), branch_mrid
            compared += 1
    assert compared >= 10


def test_the_dc_n_0_rd_sensitivity_is_in_ampere_per_mw_and_passes_the_guard(dc_case):
    import statistics
    from pre_milp.n0_sensitivity import compute_sensitivity_rd_n0

    generators = dc_case.network.get_generators()
    gu_id = str(generators.index[generators["target_p"] > 50][0])
    guard = {}
    sensitivity = compute_sensitivity_rd_n0(
        dc_case.network, [_rd(gu_id)], dc_case.ae, TIMESTAMP, lf_initial=dc_case.lf, guard_out=guard,
        use_reactive_limits=run_pipeline.USE_REACTIVE_LIMITS, extra_lf_params=run_pipeline.EXTRA_LF_PARAMS,
        dc_converter=dc_case.converter,
    )

    assert guard == {} and all(v == v for v in sensitivity.values())
    moved = _dc_network()
    moved.update_generators(id=gu_id, target_p=float(generators.loc[gu_id, "target_p"]) + 1.0)
    cgmes_loader.run_initial_dc_loadflow(
        moved, use_reactive_limits=run_pipeline.USE_REACTIVE_LIMITS, extra_lf_params=run_pipeline.EXTRA_LF_PARAMS,
    )
    lf_moved = cgmes_loader.build_lf_initial(moved, dc_converter=dc_case.converter)
    ratios = [
        (lf_moved[b][1] - dc_case.lf[b][1]) / v for (b, _), v in sensitivity.items() if abs(v) > 1e-2
    ]
    assert len(ratios) >= 10
    assert statistics.median(ratios) == pytest.approx(1.0, abs=0.05)  # one MW moved (a current can change sign)


def test_the_dc_n_x_sensitivities_pass_the_guard_and_use_the_reference_sign_of_each_contingency(dc_case):
    import pypowsybl as pp
    from pre_milp.nx_security_analysis import compute_lf_nx
    from pre_milp.nx_sensitivity import compute_sensitivities_nx

    network = dc_case.network
    contingencies, ae = _nx_inputs(dc_case, dc_case.lines[60:63])
    lf_nx, _ = compute_lf_nx(
        network, contingencies, ae, TIMESTAMP, lf_initial=dc_case.lf,
        use_reactive_limits=run_pipeline.USE_REACTIVE_LIMITS, extra_lf_params=run_pipeline.EXTRA_LF_PARAMS,
        dc_converter=dc_case.converter,
    )
    pst_ids = [str(t) for t in network.get_phase_tap_changers().index[:2]]
    generators = network.get_generators()
    gu_id = str(generators.index[generators["target_p"] > 50][0])
    pst_guard, rd_guard, pst_ref, rd_ref = {}, {}, {}, {}

    sensitivity_pst, sensitivity_rd = compute_sensitivities_nx(
        network, contingencies, [_pst(p) for p in pst_ids], [_rd(gu_id)], ae, TIMESTAMP,
        lf_nx=lf_nx, lf_initial=dc_case.lf, use_reactive_limits=run_pipeline.USE_REACTIVE_LIMITS,
        extra_lf_params=run_pipeline.EXTRA_LF_PARAMS, pst_guard_out=pst_guard, rd_guard_out=rd_guard,
        pst_reference_out=pst_ref, rd_reference_out=rd_ref, dc_converter=dc_case.converter,
    )

    assert pst_guard == {} and rd_guard == {}
    assert set(sensitivity_pst) == set(sensitivity_rd) == {c.mrid for c in contingencies}
    for contingency in contingencies:
        assert sensitivity_pst[contingency.mrid] and sensitivity_rd[contingency.mrid]
        assert all(v == v for v in sensitivity_pst[contingency.mrid].values())
        # the guard compares the reference currents with the load flow: they are the same numbers
        for branch_mrid, reference in rd_ref[contingency.mrid].items():
            assert reference == pytest.approx(lf_nx[contingency.mrid][branch_mrid][1], rel=1e-9, abs=1e-9)
    # finite difference under the first contingency, branch by branch: line out, one MW more at the
    # unit. dI/dP = sign(P_ref) x dP/dP x scale, so a branch with a negative post-contingency flow
    # gives ratio -1 if the sign of its own reference is lost. The ratios are within a few % of 1
    # (the slack is distributed slightly differently by the two analyses, see sensitivity_checks).
    first = contingencies[0]
    outage_line = first.equipment_mrids[0]

    def with_outage(extra):
        copy = _load()
        copy.update_lines(id=outage_line, connected1=False, connected2=False)
        extra(copy)
        cgmes_loader.run_initial_dc_loadflow(
            copy, use_reactive_limits=run_pipeline.USE_REACTIVE_LIMITS, extra_lf_params=run_pipeline.EXTRA_LF_PARAMS,
        )
        return copy, cgmes_loader.build_lf_initial(copy, dc_converter=dc_case.converter)

    base_network, base = with_outage(lambda copy: None)
    _, moved = with_outage(lambda copy: copy.update_generators(
        id=gu_id, target_p=float(generators.loc[gu_id, "target_p"]) + 1.0))
    p_ref = base_network.get_lines()["p1"]
    compared, negative = 0, 0
    for (branch_mrid, _), value in sensitivity_rd[first.mrid].items():
        if abs(value) <= 1e-2 or branch_mrid not in base or base[branch_mrid][1] != base[branch_mrid][1]:
            continue
        ratio = (moved[branch_mrid][1] - base[branch_mrid][1]) / value
        assert ratio == pytest.approx(1.0, abs=0.1), (branch_mrid, p_ref[branch_mrid], ratio)
        compared += 1
        negative += p_ref[branch_mrid] < -1.0
    assert compared >= 10 and negative >= 1


def test_the_ac_n_x_guard_keeps_its_1_percent_tolerance_and_only_dc_gets_5_percent():
    from pre_milp import nx_sensitivity
    from pre_milp import sensitivity_checks as checks

    assert checks.NX_RELATIVE_TOLERANCE == 0.01 and checks.DC_NX_RELATIVE_TOLERANCE == 0.05
    ac_tolerance = nx_sensitivity._guard_tolerance(None)
    dc_tolerance = nx_sensitivity._guard_tolerance(object())
    assert ac_tolerance == {} and dc_tolerance == {"tolerance": checks.DC_NX_RELATIVE_TOLERANCE}
    # a 2 % deviation of the reference stops the contingency in AC, not in DC
    lf_nx, reference, sides = {"co": {"b": {1: 100.0, 2: 100.0}}}, {"co": {"b": 102.0}}, {"b": 1}
    assert set(checks.find_invalid_nx_contingencies(reference, set(), lf_nx, sides, **ac_tolerance)) == {"co"}
    assert checks.find_invalid_nx_contingencies(reference, set(), lf_nx, sides, **dc_tolerance) == {}


# ===========================================================================
# GUI
# ===========================================================================

def _gui_common():
    import sys
    from helpers import REPO_ROOT

    pytest.importorskip("streamlit")
    rao_pages = str(REPO_ROOT / "src" / "rao_pages")
    if rao_pages not in sys.path:
        sys.path.insert(0, rao_pages)
    import _gui_common
    return _gui_common


def _page(name):
    from helpers import REPO_ROOT

    pytest.importorskip("streamlit")
    from streamlit.testing.v1 import AppTest
    return AppTest.from_file(str(REPO_ROOT / "src" / "rao_pages" / name), default_timeout=60)


def test_dc_is_selectable_on_the_main_page_and_kept_for_the_next_run():
    gui = _gui_common()
    page = _page("1_Main.py")
    page.run()

    assert not page.exception
    assert list(page.selectbox(key="calculation_mode_select").options) == ["ac_iterative", "ac_single_pass", "dc"]
    page.selectbox(key="calculation_mode_select").set_value("dc").run()
    assert page.session_state[gui.CALCULATION_MODE_STATE_KEY] == "dc"
    assert not any("not available" in c.value for c in page.caption)


@pytest.mark.parametrize("mode, greyed", [("dc", True), ("ac_single_pass", True), ("ac_iterative", False)])
def test_the_settings_page_greys_out_the_loop_settings_in_dc_as_in_single_pass(mode, greyed):
    gui = _gui_common()
    page = _page("3_RAO_Settings.py")
    page.session_state[gui.CALCULATION_MODE_STATE_KEY] = mode
    page.run()

    assert not page.exception
    disabled = {element.label: element.disabled for element in page.number_input}
    for name in ("max_change_ra_sum_threshold", "max_change_ra", "max_change_overload",
                 "max_linearisation_iterations", "max_completeness_iterations"):
        assert disabled[name] is greyed, name
    assert disabled["incremental_ac_fallback_max_steps"] is False


def test_the_gui_temp_config_round_trip_keeps_dc_and_the_factor_table():
    gui = _gui_common()
    rao_config = {section: dict(values) for section, values in gui.DEFAULT_RAO_CONFIG.items()}
    rao_config["workflow_toggles"]["calculation_mode"] = "dc"
    rao_config["dc_mode"] = {"current_factor_by_nominal_voltage_kv": {"default": 1.0, "400": 1.1}}  # JSON gives text keys

    tmpdir = gui.build_temp_run_dir(b"cgm", b"ncp", rao_config, gui.DEFAULT_LOAD_FLOW_CONFIG)
    try:
        import yaml
        path = tmpdir / "src" / "rao" / "config" / "rao_config.yaml"
        written = yaml.safe_load(path.read_text(encoding=TEXT_ENCODING))
        run_pipeline.validate_config_ranges(written, path)  # the pipeline accepts what the GUI wrote
        run_pipeline.validate_load_flow_config(
            yaml.safe_load((path.parent / "load_flow_config.yaml").read_text(encoding=TEXT_ENCODING)), path,
        )
    finally:
        gui.cleanup_temp_run_dir(tmpdir)

    assert written["workflow_toggles"]["calculation_mode"] == "dc"
    assert written["dc_mode"]["current_factor_by_nominal_voltage_kv"] == {"default": 1.0, "400": 1.1}


def test_the_factor_table_is_read_from_the_config_file_and_never_frozen_into_the_saved_settings(tmp_path, monkeypatch):
    import json

    gui = _gui_common()
    saved = {"rao_config": {"dc_mode": {"current_factor_by_nominal_voltage_kv": {"default": 9.0}},
                            "thresholds": {"max_change_ra": 3.0}}, "load_flow_config": {}}
    settings_file = tmp_path / "settings.json"
    settings_file.write_text(json.dumps(saved), encoding=TEXT_ENCODING)
    monkeypatch.setattr(gui, "SETTINGS_FILE_PATH", settings_file)

    settings = gui.load_settings()

    assert settings["rao_config"]["thresholds"]["max_change_ra"] == 3.0       # saved settings still apply
    assert settings["rao_config"]["dc_mode"] == gui.DEFAULT_RAO_CONFIG["dc_mode"] != saved["rao_config"]["dc_mode"]


def test_saving_the_settings_never_writes_the_factor_table(tmp_path, monkeypatch):
    import json

    gui = _gui_common()
    settings_file = tmp_path / "settings.json"
    monkeypatch.setattr(gui, "SETTINGS_FILE_PATH", settings_file)
    rao_config = {section: dict(values) for section, values in gui.DEFAULT_RAO_CONFIG.items()}

    gui.save_settings(rao_config, gui.DEFAULT_LOAD_FLOW_CONFIG)

    written = json.loads(settings_file.read_text(encoding=TEXT_ENCODING))
    assert "dc_mode" not in written["rao_config"] and "thresholds" in written["rao_config"]
    assert "dc_mode" in rao_config  # the caller's settings are not changed


def _saved_load_flow_settings(gui, tmp_path, monkeypatch, dc_power_factor):
    import json

    settings_file = tmp_path / "settings.json"
    settings_file.write_text(json.dumps({"rao_config": {}, "load_flow_config": {"dc_power_factor": dc_power_factor}}),
                             encoding=TEXT_ENCODING)
    monkeypatch.setattr(gui, "SETTINGS_FILE_PATH", settings_file)


@pytest.mark.parametrize("saved", [0.0, -0.5, None, True, "0.9"])
def test_a_saved_dc_power_factor_that_is_not_above_zero_becomes_one_with_a_note(tmp_path, monkeypatch, saved):
    """The Load Flow page accepted 0.0 before (minimum 0.0); such settings must not stop the page
    or the runs."""
    gui = _gui_common()
    _saved_load_flow_settings(gui, tmp_path, monkeypatch, saved)

    settings = gui.load_settings()

    assert settings["load_flow_config"]["dc_power_factor"] == 1.0
    assert len(settings["notes"]) == 1 and "dc_power_factor" in settings["notes"][0]
    assert run_pipeline.validate_load_flow_config(settings["load_flow_config"], "settings") == 1.0


def test_a_valid_saved_dc_power_factor_is_kept_without_a_note(tmp_path, monkeypatch):
    gui = _gui_common()
    _saved_load_flow_settings(gui, tmp_path, monkeypatch, 0.9)

    settings = gui.load_settings()

    assert settings["load_flow_config"]["dc_power_factor"] == 0.9 and settings["notes"] == []


def test_the_load_flow_page_opens_with_a_saved_dc_power_factor_of_zero_and_shows_the_note(tmp_path, monkeypatch):
    gui = _gui_common()
    _saved_load_flow_settings(gui, tmp_path, monkeypatch, 0.0)
    page = _page("2_Load_Flow_Settings.py")

    page.run()

    assert not page.exception
    assert any("dc_power_factor" in warning.value for warning in page.warning)
    assert next(e for e in page.number_input if e.label == "dc_power_factor").value == 1.0


def test_the_load_flow_page_does_not_accept_a_zero_dc_power_factor():
    page = _page("2_Load_Flow_Settings.py")
    page.run()

    assert not page.exception
    widget = next(e for e in page.number_input if e.label == "dc_power_factor")
    assert widget.min > 0
