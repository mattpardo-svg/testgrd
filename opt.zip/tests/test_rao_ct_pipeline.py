"""
test_rao_ct_pipeline.py — countertrade end to end on the generated mock (tests/ct_mock.py,
docs/countertrade_ra_specs.md C6, C12): run_pipeline.main() on CGM_package.zip + the mock NCP.
Sections: the preventive model and the curative model in ac_single_pass; the other calculation modes
are covered in test_rao_ct_modes.py.
"""
import csv
import logging
from types import SimpleNamespace

import pyomo.environ as pyo
import pytest
from pyomo.core.expr.visitor import identify_variables

import ct_mock
from helpers import _MOCK_NX_NCP_ZIP, run_pipeline_on_fixture_inputs

BELGOVIA_BO4 = ct_mock.BRANCH_GA_BO4_BELGOVIA
DEFAULT_PATL_KA = ct_mock.DEFAULT_PATL_A / 1000.0


def _read_csv(path):
    with open(path, encoding="utf-8", newline="") as f:
        return list(csv.DictReader(f))


def _summary(output_dir):
    return {row["metric"]: row["value"] for row in _read_csv(output_dir / "results_summary.csv")}


def _run(tmp_path, ras=None, ra_types=("countertrade",), mode="ac_single_pass", nx=False, ncp_zip=None, **mock_kwargs):
    """One pipeline run; returns the output folder, the models built and the log records of the CT modules."""
    tmp_path.mkdir(parents=True, exist_ok=True)
    ncp = ncp_zip or ct_mock.build_ct_mock_ncp(tmp_path / "ncp.zip", ras=ras, **mock_kwargs)
    models = []

    def keep_models(rp, monkeypatch):
        build = rp.ac_convergence_loop.build_n0_milp_model

        def keeping_build(*args, **kwargs):
            model = build(*args, **kwargs)
            models.append(model)
            return model

        monkeypatch.setattr(rp.ac_convergence_loop, "build_n0_milp_model", keeping_build)

    run = run_pipeline_on_fixture_inputs(
        tmp_path / "run", ncp, enable_nx_analysis=nx, ra_types=ra_types, calculation_mode=mode, customize_pipeline=keep_models,
    )
    return SimpleNamespace(output_dir=run.output_dir, models=models)


@pytest.fixture(scope="module")
def ct_only(tmp_path_factory):
    return _run(tmp_path_factory.mktemp("ct_only"))


def _bids_by_direction(model):
    """{(zone, direction): bid mRID} of the default mock: the bid names are in the mock spec."""
    return {name: ct_mock._uid("bid", *name.split("/")) for name in ("BO/BO-up", "BO/BO-down", "GA/GA-up", "GA/GA-down")}


def _volume(model, mock_name):
    bid = _bids_by_direction(model)[mock_name]
    return pyo.value(model.rd_volume_upward[bid]) - pyo.value(model.rd_volume_downward[bid])


# ---------------------------------------------------------------------------
# relief, balance, limits, cost
# ---------------------------------------------------------------------------

def test_belgovia_down_and_galia_up_relieve_the_lowered_ga_bo4(ct_only):
    model = ct_only.models[-1]
    belgovia_down, galia_up = -_volume(model, "BO/BO-down"), _volume(model, "GA/GA-up")
    assert belgovia_down == pytest.approx(galia_up, abs=1e-6) and belgovia_down == pytest.approx(71.5, abs=1.5)
    assert _volume(model, "BO/BO-up") == pytest.approx(0.0, abs=1e-9) and _volume(model, "GA/GA-down") == pytest.approx(0.0, abs=1e-9)
    row = next(r for r in _read_csv(ct_only.output_dir / "lf_post_n0.csv") if r["branch_mrid"] == BELGOVIA_BO4)
    assert float(row["i_ka_before"]) == pytest.approx(0.12411, abs=1e-4)
    # one linearised pass: the AC check shows the remaining error of about a tenth of the relief
    assert float(row["i_ka_after"]) < float(row["i_ka_before"]) - 0.010
    assert float(row["i_ka_after"]) <= DEFAULT_PATL_KA * 1.02
    assert row["solution_applied_to_network"] == "true"


def test_the_net_injection_of_the_units_follows_the_remaining_capacity_weights(ct_only):
    model = ct_only.models[-1]
    volume = -_volume(model, "BO/BO-down")
    expected = {gu: -volume * w for gu, w in ct_mock.EXPECTED_WEIGHTS[("Belgovia", "down")].items()}
    expected.update({gu: volume * w for gu, w in ct_mock.EXPECTED_WEIGHTS[("Galia", "up")].items()})
    assert {gu: pyo.value(model.rd_net_injection_g[gu]) for gu in model.gu_ids} == pytest.approx(expected, abs=1e-4)
    assert sum(pyo.value(model.rd_net_injection_g[gu]) for gu in model.gu_ids) == pytest.approx(0.0, abs=1e-6)


def test_the_unit_limits_hold_in_the_solution(ct_only):
    model = ct_only.models[-1]
    for gu in model.gu_ids:
        target = model.rd_baseline_target_p_mw[gu]
        status = model.rd_unit_status[gu]
        total = target + pyo.value(model.rd_net_injection_g[gu])
        assert status.pmin_mw - 1e-6 <= total <= status.pmax_mw + 1e-6


def test_the_cost_and_the_objective_are_the_sum_of_the_terms_and_the_residual_is_zero(ct_only):
    model = ct_only.models[-1]
    terms = {name: pyo.value(expression) for name, expression in model.objective_penalty_term_expressions.items()}
    volume = -_volume(model, "BO/BO-down")
    assert terms["ct_pra_penalty_cost"] == pytest.approx(1.0 * 100.0 * 2 * volume, rel=1e-6)
    assert terms["ct_pra_energy_cost"] == pytest.approx((8.0 + 20.0) * volume, rel=1e-6)
    assert terms["ct_bid_activation_cost"] == pytest.approx(300.0 + 400.0)
    assert pyo.value(model.objective) == pytest.approx(sum(terms.values()), rel=1e-9)
    summary = _summary(ct_only.output_dir)
    assert float(summary["objective_residual_eur"]) == pytest.approx(0.0, abs=1e-6)
    assert float(summary["objective_value"]) == pytest.approx(pyo.value(model.objective), rel=1e-9)
    assert summary["ra_types"] == "countertrade"


def test_a_countertrade_only_run_writes_no_rd_result_files(ct_only):
    names = {p.name for p in ct_only.output_dir.glob("*")}
    assert not names & {
        "results_preventive_rd.csv", "results_generating_units.csv", "results_preventive_rd_ra_count.csv",
        "results_preventive_rd_ra_groups.csv", "results_lead_times.csv", "glsk_resolved.csv", "rd_cra_availability.csv",
    }
    assert "results_summary.csv" in names


# ---------------------------------------------------------------------------
# RD together with CT, ra_types combinations
# ---------------------------------------------------------------------------

def test_rd_and_countertrade_share_the_belgovia_units(tmp_path):
    result = _run(tmp_path, ra_types=("rd", "countertrade"))
    model = result.models[-1]
    for gu in (ct_mock.BO_G1, ct_mock.BO_G2):
        variables = {v.name for v in identify_variables(model.pmax_pmin_constraint[gu].body)}
        assert any(name.startswith("rd_volume_") and ct_mock._uid("bid", "BO", "BO-down") in name for name in variables)
    rd_bids = [b for b in model.bid_ids if b not in model.ct_bid_ids]
    assert rd_bids and set(model.ct_bid_ids) == {ct_mock._uid("bid", ra, name) for ra, name in (
        ("BO", "BO-up"), ("BO", "BO-down"), ("GA", "GA-up"), ("GA", "GA-down"))}
    # the RD files hold the RD bids only
    rows = _read_csv(result.output_dir / "results_preventive_rd.csv")
    assert {r["bid_mrid"] for r in rows} == set(rd_bids)
    assert not {r["bid_mrid"] for r in rows} & set(model.ct_bid_ids)
    units = {r["gu_mrid"] if "gu_mrid" in r else next(iter(r.values())) for r in _read_csv(result.output_dir / "results_generating_units.csv")}
    assert float(_summary(result.output_dir)["objective_residual_eur"]) == pytest.approx(0.0, abs=1e-6)
    assert units


def test_pst_and_countertrade_run_together(tmp_path):
    result = _run(tmp_path, ra_types=("pst", "countertrade"))
    assert _summary(result.output_dir)["ra_types"] == "pst+countertrade"
    assert "results_pst.csv" in {p.name for p in result.output_dir.glob("*")}
    assert any(hasattr(m, "ct_bid_ids") and m.ct_bid_ids for m in result.models)


def test_without_countertrade_in_ra_types_the_ct_ras_of_the_ncp_change_nothing(tmp_path):
    original = _run(tmp_path / "original", ra_types=("rd",), ncp_zip=_MOCK_NX_NCP_ZIP)
    with_ct = _run(tmp_path / "with_ct", ra_types=("rd",), patl_a=None)      # patl_a None: the SHS file stays the original
    for name in ("results_preventive_rd.csv", "results_summary.csv", "results_generating_units.csv", "lf_post_n0.csv"):
        assert (original.output_dir / name).read_bytes() == (with_ct.output_dir / name).read_bytes(), name


# ---------------------------------------------------------------------------
# restrictive groups, penalty factors, bids without volume
# ---------------------------------------------------------------------------

def test_a_restrictive_group_caps_the_countertrade_bid(tmp_path):
    ras = ct_mock.default_ras()
    result = _run(tmp_path, ras, groups=[ct_mock.group("cap", [ras[0]], max_down=30.0)])
    model = result.models[-1]
    assert hasattr(model, "ra_group_volume_downward_limit")
    assert -_volume(model, "BO/BO-down") == pytest.approx(30.0, abs=1e-6)


def test_penalty_factor_zero_and_two_scale_the_penalty_cost(tmp_path):
    for factors, expected in (((0.0, 0.0), 0.0), ((2.0, 2.0), 2.0)):
        result = _run(tmp_path / str(expected), ct_mock.default_ras(penalties=factors))
        model = result.models[-1]
        volume = -_volume(model, "BO/BO-down")
        assert pyo.value(model.objective_penalty_term_expressions["ct_pra_penalty_cost"]) == pytest.approx(
            expected * 100.0 * 2 * volume, rel=1e-6, abs=1e-9,
        )


def test_a_bid_without_volume_cannot_be_used(tmp_path):
    ras = [ct_mock.ra("no-volume", ct_mock.ZONE_BELGOVIA, [ct_mock.bid("nv-up", "up", volume=None), ct_mock.bid("nv-down", "down", 100.0)])]
    ras += [ct_mock.default_ras()[1]]
    result = _run(tmp_path, ras)
    model = result.models[-1]
    up = ct_mock._uid("bid", "no-volume", "nv-up")
    assert pyo.value(model.rd_volume_upward[up]) == pytest.approx(0.0, abs=1e-9) and model.rd_volume_upward[up].ub == 0.0


# ---------------------------------------------------------------------------
# negative cases: no usable CT RA
# ---------------------------------------------------------------------------

@pytest.mark.parametrize("name, ras", [
    ("unknown", ct_mock.unknown_strategy_ras()),
    ("mixed", ct_mock.mixed_strategy_ras()),
    ("zone_without_units", ct_mock.bad_zone_ras(ct_mock.ZONE_NORDHEIM)),
    ("zone_not_found", ct_mock.bad_zone_ras()),
])
def test_no_usable_countertrade_ra_ends_the_run_gracefully(tmp_path, caplog, name, ras):
    with caplog.at_level(logging.INFO):
        result = _run(tmp_path, ras)
    names = {p.name for p in result.output_dir.glob("*")}
    assert "lf_basecase.csv" in names and "results_summary.csv" not in names and result.models == []
    messages = [r.getMessage() for r in caplog.records]
    assert any("has anything to optimise" in m for m in messages)
    assert any("countertrade" in m and "nothing to this run" in m for m in messages)


def test_all_units_at_pmax_give_an_up_bid_of_volume_zero(tmp_path, monkeypatch):
    from pre_milp import ct_units

    original = ct_units.read_generator_table

    def at_pmax(network):
        table = original(network)
        for gu in (ct_mock.GA_G1, ct_mock.GA_G2, ct_mock.GA_G3):
            table[gu].prod = table[gu].pmax
        return table

    monkeypatch.setattr(ct_units, "read_generator_table", at_pmax)
    result = _run(tmp_path)
    model = result.models[-1] if result.models else None
    # Galia cannot move up: its up bid is bounded to 0; the run goes on with the rest
    if model is not None:
        galia_up = ct_mock._uid("bid", "GA", "GA-up")
        assert model.rd_volume_upward[galia_up].ub == 0.0


# ---------------------------------------------------------------------------
# curative countertrade (N-X on), ac_single_pass
# ---------------------------------------------------------------------------

CO = ct_mock.CONTINGENCY_GA_BO5
CURATIVE_BIDS = [ct_mock._uid("bid", ra, name) for ra, name in (
    ("BO-cur", "BO-cur-up"), ("BO-cur", "BO-cur-down"), ("GA-cur", "GA-cur-up"), ("GA-cur", "GA-cur-down"))]


def _curative_run(tmp_path, ras=None, ra_types=("countertrade",)):
    return _run(
        tmp_path, ras or ct_mock.curative_ras(), ra_types=ra_types, nx=True, patl_a=ct_mock.CURATIVE_PATL_A,
        contingencies=[ct_mock.ga_bo5_outage()],
    )


@pytest.fixture(scope="module")
def curative(tmp_path_factory):
    return _curative_run(tmp_path_factory.mktemp("ct_curative"))


def _cur_volume(model, name, contingency=CO):
    bid = ct_mock._uid("bid", *name.split("/"))
    return (pyo.value(model.curative_rd_volume_upward[bid, contingency])
            - pyo.value(model.curative_rd_volume_downward[bid, contingency]))


def test_the_curative_terms_are_in_the_rows_of_the_linked_contingency_only(curative):
    model = curative.models[-1]
    assert sorted(model.curative_bid_contingency_pairs) == sorted((bid, CO) for bid in CURATIVE_BIDS)
    for (branch, contingency) in model.nx_branch_contingency_pairs:
        names = {v.name for v in identify_variables(model.nx_patl_loading[branch, contingency].body)}
        curative = {n for n in names if n.startswith("curative_rd_volume")}
        assert all(n.endswith(f",{CO}]") for n in curative)
        if contingency != CO:
            assert not curative


def test_the_curative_pair_relieves_the_contingency(curative):
    model = curative.models[-1]
    down, up = -_cur_volume(model, "BO-cur/BO-cur-down"), _cur_volume(model, "GA-cur/GA-cur-up")
    assert down == pytest.approx(up, abs=1e-6) and down > 50.0
    row = next(r for r in _read_csv(curative.output_dir / "results_nx_loadings.csv")
               if r["contingency_mrid"] == CO and r["branch_mrid"] == BELGOVIA_BO4)
    assert float(row["i_ka_nx_initial"]) == pytest.approx(ct_mock.N1_CURRENT_A / 1000.0, abs=1e-3)
    assert float(row["loading_pct_nx_initial"]) > 110.0
    assert float(row["loading_pct_nx_post_pra_cra"]) <= 100.0 + 1e-6 and float(row["slack_patl"]) == pytest.approx(0.0, abs=1e-6)


def test_curative_actions_are_never_applied_to_the_network(curative):
    row = next(r for r in _read_csv(curative.output_dir / "lf_post_n0.csv") if r["branch_mrid"] == BELGOVIA_BO4)
    assert float(row["i_ka_after"]) == pytest.approx(float(row["i_ka_before"]), abs=1e-9)
    assert not hasattr(curative.models[-1], "rd_net_injection_g")


def test_the_curative_cost_is_the_sum_of_its_terms_and_the_residual_is_zero(curative):
    model = curative.models[-1]
    terms = {name: pyo.value(expression) for name, expression in model.objective_penalty_term_expressions.items()}
    volume = -_cur_volume(model, "BO-cur/BO-cur-down")
    assert terms["ct_cra_penalty_cost"] == pytest.approx(1.0 * 100.0 * 2 * volume, rel=1e-6)
    assert terms["ct_cra_reservation_cost"] == pytest.approx(4.0 * 2 * volume, rel=1e-6)
    assert pyo.value(model.objective) == pytest.approx(sum(terms.values()), rel=1e-9)
    assert float(_summary(curative.output_dir)["objective_residual_eur"]) == pytest.approx(0.0, abs=1e-6)


def test_a_reaction_time_above_the_tatl_duration_keeps_the_curative_ra_off_the_branch(tmp_path):
    result = _curative_run(tmp_path, ct_mock.curative_ras(time_to_implement="PT20M"))
    model = result.models[-1]
    assert _cur_volume(model, "BO-cur/BO-cur-down") == pytest.approx(0.0, abs=1e-9)
    assert pyo.value(model.nx_patl_overload_slack[BELGOVIA_BO4, CO]) == pytest.approx(ct_mock.N1_CURRENT_A - ct_mock.CURATIVE_PATL_A, abs=0.2)


def test_a_curative_ra_without_a_link_is_available_in_every_contingency(tmp_path):
    result = _curative_run(tmp_path, ct_mock.curative_ras(contingencies=()))
    model = result.models[-1]
    contingencies = {c for _, c in model.curative_bid_contingency_pairs}
    assert CO in contingencies and len(contingencies) > 5
    used = [c for c in contingencies if abs(_cur_volume(model, "BO-cur/BO-cur-down", c)) > 1e-6]
    assert CO in used


def test_the_curative_rd_files_stay_rd_only_with_countertrade_in_the_run(tmp_path):
    result = _curative_run(tmp_path, ct_mock.curative_ras(), ra_types=("rd", "countertrade"))
    rows = _read_csv(result.output_dir / "results_curative_rd.csv")
    assert not {r["bid_mrid"] for r in rows} & set(CURATIVE_BIDS)
    assert float(_summary(result.output_dir)["objective_residual_eur"]) == pytest.approx(0.0, abs=1e-6)