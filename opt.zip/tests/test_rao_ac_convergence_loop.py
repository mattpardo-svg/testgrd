"""tests/test_rao_ac_convergence_loop.py - tests for ac_convergence_loop.py.

Sections: the AC verification loop, convergence criteria, cyclic repetition and cycle exit, the completeness (outer) loop, the N-0 sensitivity refresh, and the solve history.
"""

import sys
import types
import pytest
import milp.ac_convergence_loop as _acl_module
import importlib
import csv

from pathlib import Path
from data_model import AEType, AssessedElement, PST, RAKind, AcVerificationStatus
from post_milp.n0_results_export import (
    write_pst_results_csv,
    write_results_rd_csv,
    write_results_ra_count_csv,
    write_results_ra_groups_csv,
    write_results_lead_times_csv,
)
from milp import ac_convergence_loop as acl, operating_point_state
from helpers import Scenario, _NESTED_OVERRIDES, _run_nested
from types import SimpleNamespace
from text_encoding import TEXT_ENCODING  # noqa: E402

def run_post_rao_linearisation_loop(**kwargs):
    """Test adapter: the PST-only call shape of these tests on run_post_rao_ac_verification_loop;
    returns (N-0 load flow, PST result rows, {})."""
    kwargs.setdefault("rd_list", [])
    kwargs.setdefault("sensitivity_rd_n0", {})
    kwargs.setdefault("penalty_reference_rd_pra", 0.0)
    kwargs.setdefault("generator_data", {})
    lf_current, _model, pst_rows, _reason = _acl_module.run_post_rao_ac_verification_loop(**kwargs)
    return lf_current, pst_rows, {}


class DummyPyomoExpression:
    def __init__(self, left, right=None, op=None):
        self.left = left
        self.right = right
        self.op = op

    def __add__(self, other):
        return DummyPyomoExpression(self, other, "+")

    def __radd__(self, other):
        return DummyPyomoExpression(other, self, "+")

    def __sub__(self, other):
        return DummyPyomoExpression(self, other, "-")

    def __rsub__(self, other):
        return DummyPyomoExpression(other, self, "-")

    def __mul__(self, other):
        return DummyPyomoExpression(self, other, "*")

    def __rmul__(self, other):
        return DummyPyomoExpression(other, self, "*")

    def __le__(self, other):
        return DummyPyomoExpression(self, other, "<=")

    def __ge__(self, other):
        return DummyPyomoExpression(self, other, ">=")

    def __eq__(self, other):
        return DummyPyomoExpression(self, other, "==")


class DummyPyomoVar:
    def __init__(self, *args, domain=None):
        self.domain = domain
        self._items = {}
        self.value = 0.0

    def __getitem__(self, key):
        if key not in self._items:
            var = DummyPyomoVar(domain=self.domain)
            var.value = 0.0
            self._items[key] = var
        return self._items[key]

    def __add__(self, other):
        return DummyPyomoExpression(self, other, "+")

    def __radd__(self, other):
        return DummyPyomoExpression(other, self, "+")

    def __sub__(self, other):
        return DummyPyomoExpression(self, other, "-")

    def __rsub__(self, other):
        return DummyPyomoExpression(other, self, "-")

    def __mul__(self, other):
        return DummyPyomoExpression(self, other, "*")

    def __rmul__(self, other):
        return DummyPyomoExpression(other, self, "*")

    def __le__(self, other):
        return DummyPyomoExpression(self, other, "<=")

    def __ge__(self, other):
        return DummyPyomoExpression(self, other, ">=")

    def __eq__(self, other):
        return DummyPyomoExpression(self, other, "==")


class DummyPyomoSet(list):
    def __init__(self, initialize=None, dimen=1):
        super().__init__(initialize if initialize is not None else [])
        self.dimen = dimen


class DummyPyomoConstraint:
    def __init__(self, *args, rule=None):
        self.rule = rule

    def __iter__(self):
        return iter(())


class DummyPyomoExpressionComponent:
    """Fake for pyo.Expression(index_set, rule=...): build_n0_milp_model's _add_pst_block uses
    it once per iteration; the rule is never evaluated in this harness."""
    def __init__(self, *args, rule=None):
        self.rule = rule


class DummyPyomoObjective:
    def __init__(self, expr=None, sense=None):
        self.expr = expr
        self.sense = sense


class DummySolverResult:
    def __init__(self):
        self.solver = types.SimpleNamespace(termination_condition="optimal")


class DummySolver:
    def solve(self, model, tee=False, load_solutions=True):
        return DummySolverResult()


@pytest.fixture
def fake_pyomo(monkeypatch):
    # not autouse: the real-pyomo tests further down must not get this fake
    fake_env = types.SimpleNamespace()

    class FakePyomo:
        NonNegativeIntegers = object
        NonNegativeReals = object
        minimize = object
        Set = DummyPyomoSet
        Var = DummyPyomoVar
        Constraint = DummyPyomoConstraint
        Expression = DummyPyomoExpressionComponent
        Objective = DummyPyomoObjective
        ConcreteModel = object

    fake_pyomo_pkg = types.ModuleType("pyomo")
    fake_environ_pkg = types.ModuleType("pyomo.environ")

    def fake_value(expr):
        if isinstance(expr, DummyPyomoObjective):
            expr = getattr(expr, "expr", 0.0)
        if hasattr(expr, "value"):
            return getattr(expr, "value")
        if isinstance(expr, DummyPyomoExpression):
            return 0.0
        return expr

    fake_environ_pkg.SolverFactory = lambda name, solver_io=None: DummySolver()
    fake_environ_pkg.value = fake_value
    fake_environ_pkg.NonNegativeIntegers = object
    fake_environ_pkg.NonNegativeReals = object
    fake_environ_pkg.minimize = object
    fake_environ_pkg.Set = DummyPyomoSet
    fake_environ_pkg.Var = DummyPyomoVar
    fake_environ_pkg.Constraint = DummyPyomoConstraint
    fake_environ_pkg.Expression = DummyPyomoExpressionComponent
    fake_environ_pkg.Objective = DummyPyomoObjective
    fake_environ_pkg.ConcreteModel = type("ConcreteModel", (), {
        "solutions": types.SimpleNamespace(load_from=lambda results: None),
        "component_objects": lambda self, *args, **kwargs: [],
    })

    monkeypatch.setitem(sys.modules, "pyomo", fake_pyomo_pkg)
    monkeypatch.setitem(sys.modules, "pyomo.environ", fake_environ_pkg)
    return fake_environ_pkg


class DummyNetwork:
    def __init__(self, i1=900.0, i2=850.0):
        self.ptc_positions = {"p1": 0.0}
        self.loadflow_run_count = 0
        self.update_calls = []  # [(id, tap), ...] — for asserting on apply/revert calls
        self._i1 = i1
        self._i2 = i2

    def update_phase_tap_changers(self, id, tap):
        # pypowsybl's kwarg/column is 'tap', not 'tap_position': a wrong kwarg raises TypeError
        # here instead of being accepted silently
        self.ptc_positions[id] = tap
        self.update_calls.append((id, tap))

    def get_phase_tap_changers(self):
        import pandas as pd
        return pd.DataFrame({"tap": [self.ptc_positions["p1"]]}, index=["p1"])

    # The loop snapshots bus voltages and reads back generator target_p at every
    # iteration; this network has neither (an empty table is the honest answer).
    def get_buses(self):
        import pandas as pd
        return pd.DataFrame({"v_mag": [], "v_angle": []})

    def update_buses(self, id, v_mag, v_angle):
        pass

    def get_generators(self):
        import pandas as pd
        return pd.DataFrame({"target_p": []})

    def get_lines_results(self):
        return types.SimpleNamespace(index=["b1"], loc={"b1": {"i1": self._i1, "i2": self._i2}})

    def get_2_windings_transformers_results(self):
        return types.SimpleNamespace(index=[], loc={})


class DummyLoadflowResult:
    def __init__(self, status_name="CONVERGED"):
        self.status = types.SimpleNamespace(name=status_name)


class DummyPP:
    class loadflow:
        @staticmethod
        def run_ac(network, parameters=None):
            network.loadflow_run_count += 1
            return [DummyLoadflowResult()]

        VoltageInitMode = types.SimpleNamespace(PREVIOUS_VALUES="PREVIOUS_VALUES", UNIFORM_VALUES="UNIFORM_VALUES")
        ComponentMode = types.SimpleNamespace(MAIN_SYNCHRONOUS="MAIN_SYNCHRONOUS", ALL_CONNECTED="ALL_CONNECTED")

        class Parameters:
            """Spy: records the kwargs of its latest construction at class level, so tests
            can check that use_reactive_limits reaches the construction."""
            last_kwargs = None
            all_kwargs: list = []

            def __init__(self, **kwargs):
                DummyPP.loadflow.Parameters.last_kwargs = kwargs
                DummyPP.loadflow.Parameters.all_kwargs.append(kwargs)
                for key, value in kwargs.items():
                    setattr(self, key, value)


@pytest.fixture
def fake_pypowsybl(monkeypatch):
    # not autouse, as fake_pyomo above
    fake_module = types.ModuleType("pypowsybl")
    fake_module.loadflow = DummyPP.loadflow
    monkeypatch.setitem(sys.modules, "pypowsybl", fake_module)
    return fake_module


def _make_pst_r1post(mrid="p1", r0=0, **overrides):
    defaults = dict(
        mrid=mrid, name="PST 1", tso="TSO", available=True, kind=RAKind.PREVENTIVE,
        penalty_factor=1.0, low_step=-10, high_step=10, r0=r0,
        operating_tap_min=-10, operating_tap_max=10, group_id=None,
    )
    defaults.update(overrides)
    return PST(**defaults)


def _make_ae_r1post(branch_mrid="b1", branch_side=1, **overrides):
    defaults = dict(
        mrid="ae1", name="AE 1", tso="TSO", ae_type=AEType.SECURED,
        branch_mrid=branch_mrid, secured_for_region=None, scanned_for_region=None,
        exclusion_reason=None, patl_ka={"1030Z": 1.2}, branch_side=branch_side,
    )
    defaults.update(overrides)
    return AssessedElement(**defaults)


def test_run_post_rao_linearisation_loop_terminates_on_threshold(fake_pyomo, fake_pypowsybl, tmp_path):
    network = DummyNetwork()
    pst_list = [_make_pst_r1post("p1", r0=0)]
    ae_flat_list = [_make_ae_r1post("b1", branch_side=1)]
    lf_initial = {"b1": {1: 900.0, 2: 850.0}}
    pst_tap_bounds = {"p1": (-10, 10)}
    sensitivity_pst_n0 = {("b1", "p1"): 1.0}
    pst_group_equality_pairs = []
    pst_degrees_per_tap = {"p1": 2.0}

    lf_post, pst_results, overload_results = run_post_rao_linearisation_loop(
        network=network,
        pst_list=pst_list,
        ae_flat_list=ae_flat_list,
        timestamp="1030Z",
        lf_initial=lf_initial,
        pst_tap_bounds=pst_tap_bounds,
        sensitivity_pst_n0=sensitivity_pst_n0,
        pst_group_equality_pairs=pst_group_equality_pairs,
        penalty_reference_pst_pra=100.0,
        penalty_cost_overload_n0=1000.0,
        pst_degrees_per_tap=pst_degrees_per_tap,
        min_loading_threshold_pct=0.0,
        pst_taping_discrete=True,
        max_change_ra_sum_threshold=100.0,
        max_linearisation_iterations=1,
        output_path=tmp_path / "lf_post_n0.csv",
    )

    # DummyPyomoVar defaults to value=0.0, so the tap change is 0.0 on iteration 1:
    # the loop converges there. The (empty) solution is still APPLIED and
    # load-flowed before the convergence check (apply first, then check).
    assert pst_results["p1"]["tap_change_result"] == 0
    assert pst_results["p1"]["original_tap_position"] == 0
    assert pst_results["p1"]["result_tap_position"] == 0
    assert (tmp_path / "lf_post_n0.csv").exists()
    assert network.update_calls == [("p1", 0)]
    assert network.loadflow_run_count == 1
    assert lf_post is not None


def test_state_not_pst_r0_carries_the_applied_tap_to_the_next_build(fake_pyomo, fake_pypowsybl, monkeypatch, tmp_path):
    """After an iteration whose tap change is above the threshold (the loop continues), the
    next build starts from the applied tap, not the original one.
    """
    class MovingDummyVar(DummyPyomoVar):
        """A Var whose values differ by iteration, to force a nonzero
        tap_change_result on iteration 1 (forcing the loop past the
        threshold break) and a zero one on iteration 2 (so the loop
        terminates cleanly on iteration 2 rather than needing 10)."""
        pass

    network = DummyNetwork()
    pst_list = [_make_pst_r1post("p1", r0=0)]
    original_r0 = pst_list[0].r0
    ae_flat_list = [_make_ae_r1post("b1", branch_side=1)]
    lf_initial = {"b1": {1: 900.0, 2: 850.0}}
    pst_tap_bounds = {"p1": (-10, 10)}
    sensitivity_pst_n0 = {("b1", "p1"): 1.0}
    pst_degrees_per_tap = {"p1": 2.0}

    # iteration 1's solve reports a tap change above the threshold (fixed value on the first
    # call, zero afterwards)
    import milp.milp_solver as milp_solver_mod
    call_count = {"n": 0}
    fake_solve_start_taps = []
    real_solve = milp_solver_mod.solve_n0_milp_model

    def fake_solve(milp_model, pst_list, timestamp, penalty_reference_pst_pra,
                    penalty_reference_pst_pra_per_tso=None, output_path=None):
        call_count["n"] += 1
        fake_solve_start_taps.append(float(pst_list[0].r0))  # the build's start tap
        if call_count["n"] == 1:
            tap_change = 5.0
            new_tap = pst_list[0].r0 + tap_change
        else:
            tap_change = 0.0
            new_tap = pst_list[0].r0  # the build started from iteration 1's applied tap
        pst_results = {
            "p1": {
                "pst_mrid": "p1", "pst_name": "PST 1", "tso": "TSO",
                "current_tap_position": float(pst_list[0].r0),
                "tap_change_result": tap_change,
                "result_tap_position": float(new_tap),
                "pst_penalty_factor": 1.0, "penalty_reference_pst_pra": 100.0,
                "effective_penalty_cost_per_tap_eur": 100.0,
                "penalty_cost_eur": tap_change * 100.0, "timestamp": timestamp,
            }
        }
        return pst_results, {"b1": 0.0}

    monkeypatch.setattr(milp_solver_mod, "solve_n0_milp_model", fake_solve)
    import milp.ac_convergence_loop as linearisation_mod
    monkeypatch.setattr(linearisation_mod, "solve_n0_milp_model", fake_solve)

    # compute_sensitivity_pst_n0 runs again after iteration 1 and would need a full
    # pypowsybl.sensitivity mock (fake_pypowsybl stubs only .loadflow): echo the same dict
    def fake_compute_sensitivity(network, pst_list, ae_flat_list, timestamp,
                                   lf_initial=None, sensitivity_threshold_pct=0.0,
                                   output_path=None, **_ignored):
        return sensitivity_pst_n0
    monkeypatch.setattr(linearisation_mod, "compute_sensitivity_pst_n0", fake_compute_sensitivity)

    run_post_rao_linearisation_loop(
        network=network,
        pst_list=pst_list,
        ae_flat_list=ae_flat_list,
        timestamp="1030Z",
        lf_initial=lf_initial,
        pst_tap_bounds=pst_tap_bounds,
        sensitivity_pst_n0=sensitivity_pst_n0,
        pst_group_equality_pairs=[],
        penalty_reference_pst_pra=100.0,
        penalty_cost_overload_n0=1000.0,
        pst_degrees_per_tap=pst_degrees_per_tap,
        max_change_ra_sum_threshold=1.0,
        # the fake network never changes the overload, so criterion 4 would stop the loop at
        # iteration 1; this test needs the second build (criterion 4 switched off: delta < 0.0)
        max_change_overload=0.0,
        max_linearisation_iterations=2,
        output_path=tmp_path / "lf_post_n0.csv",
    )

    # after iteration 1 (tap change 5.0 applied, load flow converged) the next build starts
    # from the applied tap, carried by the state; pst.r0 stays the ORIGINAL tap
    assert pst_list[0].r0 == original_r0
    assert fake_solve_start_taps == [float(original_r0), float(original_r0 + 5.0)]
    # the network tap was applied with the 'tap=' kwarg
    assert ("p1", int(original_r0 + 5.0)) in network.update_calls


def test_use_reactive_limits_threads_through_to_run_ac_loadflow_parameters(fake_pyomo, fake_pypowsybl, monkeypatch, tmp_path):
    """Spy: use_reactive_limits passed to run_post_rao_linearisation_loop reaches the
    pp.loadflow.Parameters() of _run_ac_loadflow. Iteration 1 needs a nonzero tap change so
    the loop reaches the post-RA load flow."""
    network = DummyNetwork()
    pst_list = [_make_pst_r1post("p1", r0=0)]
    original_r0 = pst_list[0].r0
    ae_flat_list = [_make_ae_r1post("b1", branch_side=1)]
    lf_initial = {"b1": {1: 900.0, 2: 850.0}}
    pst_tap_bounds = {"p1": (-10, 10)}
    sensitivity_pst_n0 = {("b1", "p1"): 1.0}
    pst_degrees_per_tap = {"p1": 2.0}

    import milp.milp_solver as milp_solver_mod
    call_count = {"n": 0}

    def fake_solve(milp_model, pst_list, timestamp, penalty_reference_pst_pra,
                    penalty_reference_pst_pra_per_tso=None, output_path=None):
        call_count["n"] += 1
        if call_count["n"] == 1:
            tap_change = 5.0
            new_tap = original_r0 + tap_change
        else:
            tap_change = 0.0
            new_tap = pst_list[0].r0
        pst_results = {
            "p1": {
                "pst_mrid": "p1", "pst_name": "PST 1", "tso": "TSO",
                "current_tap_position": float(pst_list[0].r0),
                "tap_change_result": tap_change,
                "result_tap_position": float(new_tap),
                "pst_penalty_factor": 1.0, "penalty_reference_pst_pra": 100.0,
                "effective_penalty_cost_per_tap_eur": 100.0,
                "penalty_cost_eur": tap_change * 100.0, "timestamp": timestamp,
            }
        }
        return pst_results, {"b1": 0.0}

    monkeypatch.setattr(milp_solver_mod, "solve_n0_milp_model", fake_solve)
    import milp.ac_convergence_loop as linearisation_mod
    monkeypatch.setattr(linearisation_mod, "solve_n0_milp_model", fake_solve)

    def fake_compute_sensitivity(network, pst_list, ae_flat_list, timestamp,
                                   lf_initial=None, sensitivity_threshold_pct=0.0,
                                   output_path=None, **_ignored):
        return sensitivity_pst_n0
    monkeypatch.setattr(linearisation_mod, "compute_sensitivity_pst_n0", fake_compute_sensitivity)

    DummyPP.loadflow.Parameters.last_kwargs = None
    DummyPP.loadflow.Parameters.all_kwargs = []

    run_post_rao_linearisation_loop(
        network=network,
        pst_list=pst_list,
        ae_flat_list=ae_flat_list,
        timestamp="1030Z",
        lf_initial=lf_initial,
        pst_tap_bounds=pst_tap_bounds,
        sensitivity_pst_n0=sensitivity_pst_n0,
        pst_group_equality_pairs=[],
        penalty_reference_pst_pra=100.0,
        penalty_cost_overload_n0=1000.0,
        pst_degrees_per_tap=pst_degrees_per_tap,
        max_change_ra_sum_threshold=1.0,
        max_linearisation_iterations=2,
        output_path=tmp_path / "lf_post_n0.csv",
        use_reactive_limits=True,
    )

    assert DummyPP.loadflow.Parameters.all_kwargs[0] == {"use_reactive_limits": True}
    assert all(kwargs["use_reactive_limits"] is True for kwargs in DummyPP.loadflow.Parameters.all_kwargs)


def test_revert_path_uses_correct_tap_kwarg(fake_pyomo, fake_pypowsybl, monkeypatch, tmp_path):
    """A non-convergent post-RA load flow reverts the taps with
    update_phase_tap_changers(id=..., tap=...), the same kwarg as the apply path."""
    network = DummyNetwork()
    pst_list = [_make_pst_r1post("p1", r0=0)]
    ae_flat_list = [_make_ae_r1post("b1", branch_side=1)]
    lf_initial = {"b1": {1: 900.0, 2: 850.0}}
    pst_tap_bounds = {"p1": (-10, 10)}
    sensitivity_pst_n0 = {("b1", "p1"): 1.0}
    pst_degrees_per_tap = {"p1": 2.0}

    import milp.milp_solver as milp_solver_mod
    import milp.ac_convergence_loop as linearisation_mod

    def fake_solve(milp_model, pst_list, timestamp, penalty_reference_pst_pra,
                    penalty_reference_pst_pra_per_tso=None, output_path=None):
        pst_results = {
            "p1": {
                "pst_mrid": "p1", "pst_name": "PST 1", "tso": "TSO",
                "current_tap_position": 0.0, "tap_change_result": 5.0,
                "result_tap_position": 5.0, "pst_penalty_factor": 1.0,
                "penalty_reference_pst_pra": 100.0,
                "effective_penalty_cost_per_tap_eur": 100.0,
                "penalty_cost_eur": 500.0, "timestamp": timestamp,
            }
        }
        return pst_results, {"b1": 0.0}

    monkeypatch.setattr(milp_solver_mod, "solve_n0_milp_model", fake_solve)
    monkeypatch.setattr(linearisation_mod, "solve_n0_milp_model", fake_solve)

    # Force the post-RA load flow to NOT converge, triggering the revert path.
    def non_convergent_run_ac(network, parameters=None):
        network.loadflow_run_count += 1
        return [DummyLoadflowResult(status_name="MAX_ITERATION_REACHED")]

    import pypowsybl as fake_pp_module  # the monkeypatched fake module
    monkeypatch.setattr(fake_pp_module.loadflow, "run_ac", non_convergent_run_ac)

    run_post_rao_linearisation_loop(
        network=network,
        pst_list=pst_list,
        ae_flat_list=ae_flat_list,
        timestamp="1030Z",
        lf_initial=lf_initial,
        pst_tap_bounds=pst_tap_bounds,
        sensitivity_pst_n0=sensitivity_pst_n0,
        pst_group_equality_pairs=[],
        penalty_reference_pst_pra=100.0,
        penalty_cost_overload_n0=1000.0,
        pst_degrees_per_tap=pst_degrees_per_tap,
        max_change_ra_sum_threshold=1.0,
        max_linearisation_iterations=2,
        output_path=tmp_path / "lf_post_n0.csv",
    )

    # the apply call (tap=5) and the revert call (tap=0, the original position), both with
    # 'tap=' (DummyNetwork.update_phase_tap_changers takes (id, tap) only)
    assert ("p1", 5) in network.update_calls
    assert ("p1", 0) in network.update_calls


REPO_SRC = Path(__file__).resolve().parents[1] / "src" / "rao"


def _make_ae_compfix(branch_mrid: str, side: int, patl_ka: float, timestamp: str = "1030Z") -> AssessedElement:
    return AssessedElement(
        mrid=f"AE_{branch_mrid}", name=f"AE {branch_mrid}", tso="TestTSO",
        ae_type=AEType.SECURED, branch_mrid=branch_mrid,
        secured_for_region=None, scanned_for_region=None, exclusion_reason=None,
        patl_ka={timestamp: patl_ka}, branch_side=side,
    )


def _make_pst_compfix(mrid: str, r0: int = 0) -> PST:
    return PST(
        mrid=mrid, name=mrid, tso="TestTSO", available=True, kind=RAKind.PREVENTIVE,
        penalty_factor=1.0, low_step=-10, high_step=10, r0=r0,
        operating_tap_min=-10, operating_tap_max=10, group_id=None,
    )


def test_linearisation_loop_iteration_1_build_succeeds_with_no_overload(fake_pypowsybl):
    """A branch well within PATL and one PST: iteration 1 solves to zero tap change and the
    loop ends via the tap-change threshold, without a TypeError from the
    build_n0_milp_model signature."""
    ae_list = [_make_ae_compfix("BRANCH1", side=1, patl_ka=1.0)]  # 1000 A PATL
    pst_list = [_make_pst_compfix("PST1", r0=0)]

    lf_post, final_pst_results, final_overload_slack = run_post_rao_linearisation_loop(
        network=DummyNetwork(i1=500.0),  # the (zero) solution is applied and load-flowed before the check
        pst_list=pst_list,
        ae_flat_list=ae_list,
        timestamp="1030Z",
        lf_initial={"BRANCH1": {1: 500.0}},  # 50% loading — no overload
        pst_tap_bounds={"PST1": (-10, 10)},
        sensitivity_pst_n0={("BRANCH1", "PST1"): -10.0},
        pst_group_equality_pairs=[],
        penalty_reference_pst_pra=1.0,
        penalty_cost_overload_n0=1000.0,
        pst_degrees_per_tap={"PST1": 1.0},
        max_change_ra_sum_threshold=1.0,
        max_linearisation_iterations=10,
    )

    assert "PST1" in final_pst_results
    assert abs(float(final_pst_results["PST1"]["tap_change_result"])) < 1e-6
    assert final_overload_slack.get("BRANCH1", 0.0) < 1e-6


REPO_SRC = Path(__file__).resolve().parents[1] / "src" / "rao"


REPO_ROOT = Path(__file__).resolve().parents[1]


# Fixed fixtures (input/ is user content and can hold anything):
# _INCREMENTAL_FALLBACK_CGM_ZIP: tests/fixtures/CGM_package.zip, the shared CGM fixture.
# _INCREMENTAL_FALLBACK_NCP_ZIP: NCP_pst_fallback_scenario.zip, a purpose-built NCP set
# that reproduces a two-PST opposite-limits non-convergence (not NCP_generic.zip).
_INCREMENTAL_FALLBACK_CGM_ZIP = Path(__file__).resolve().parent / "fixtures" / "CGM_package.zip"


_INCREMENTAL_FALLBACK_NCP_ZIP = Path(__file__).resolve().parent / "fixtures" / "NCP_pst_fallback_scenario.zip"


def test_incremental_fallback_resolves_real_non_convergent_scenario(tmp_path, caplog):
    """The real pipeline on the fixed non-convergent scenario above, with N-X on: the final AC
    status is NOT REVERTED_NON_CONVERGENT (the incremental fallback, or the direct jump,
    reached a converged state).
    """
    import importlib
    import logging
    import run_pipeline as rp
    importlib.reload(rp)

    if not _INCREMENTAL_FALLBACK_CGM_ZIP.exists() or not _INCREMENTAL_FALLBACK_NCP_ZIP.exists():
        import pytest
        pytest.skip(
            f"{_INCREMENTAL_FALLBACK_CGM_ZIP} and {_INCREMENTAL_FALLBACK_NCP_ZIP} "
            "must both exist for this test — not found, skipping rather than "
            "failing (this dataset is committed separately from this test file)."
        )

    input_dir = tmp_path / "input"
    input_dir.mkdir()
    (input_dir / "cgm.zip").write_bytes(_INCREMENTAL_FALLBACK_CGM_ZIP.read_bytes())
    (input_dir / "ncp.zip").write_bytes(_INCREMENTAL_FALLBACK_NCP_ZIP.read_bytes())

    rp.INPUT_DIR = input_dir
    rp.OUTPUT_DIR = tmp_path / "output"
    rp.ENABLE_NX_ANALYSIS = True

    with caplog.at_level(logging.INFO):
        rp.main()

    pst_csv = (tmp_path / "output" / "results_pst.csv").read_text(encoding=TEXT_ENCODING)
    assert "REVERTED_NON_CONVERGENT" not in pst_csv, (
        "The real known-non-convergent scenario reverted with nothing applied — "
        "the incremental fallback did not resolve it. Full results_pst.csv:\n" + pst_csv
    )
    assert (
        "MAX_ITERATIONS_REACHED" in pst_csv or "CONVERGED" in pst_csv or "CYCLIC_REPETITION" in pst_csv
    ), f"Expected an honest, non-reverted status in results_pst.csv, got:\n{pst_csv}"


REPO_ROOT = Path(__file__).resolve().parents[1]


SRC_ROOT = REPO_ROOT / "src" / "rao"


@pytest.fixture
def run_pipeline_module(tmp_path, monkeypatch, real_input_folder):
    """Fresh import of run_pipeline with OUTPUT_DIR redirected to a tmp directory (kept local
    to this file)."""
    if str(SRC_ROOT) not in sys.path:
        sys.path.insert(0, str(SRC_ROOT))
    if str(REPO_ROOT) not in sys.path:
        sys.path.insert(0, str(REPO_ROOT))

    import run_pipeline as rp
    importlib.reload(rp)
    monkeypatch.setattr(rp, "OUTPUT_DIR", tmp_path)
    # main() reads only input/: real_input_folder (conftest.py) builds it from tests/fixtures
    monkeypatch.setattr(rp, "INPUT_DIR", real_input_folder)
    return rp


# ---------------------------------------------------------------------------
# RD-active runs go through the AC verification loop
# ---------------------------------------------------------------------------

class TestRdActiveRunUsesAcVerification:
    def test_rd_active_uses_ac_verification_loop(self, run_pipeline_module, monkeypatch):
        """With RD active (+ a synthetic PST), run_post_rao_ac_verification_loop is called:
        RD-active runs go through AC verification.
        """
        from data_model import PST, RAKind
        import pre_milp.ncp_parser as ncp_parser_module

        real_parse_psts = ncp_parser_module.parse_psts

        def inject_one_synthetic_preventive_pst(ra_path, tso, cgm_tap_changers, tap_changer_to_transformer, ae_path=None):
            real_result = real_parse_psts(ra_path, tso, cgm_tap_changers, tap_changer_to_transformer, ae_path=ae_path)
            if tso == "TSO-Belgovia":
                synthetic_pst = PST(
                    mrid="SYNTHETIC-PST-FOR-BYPASS-TEST", name="synthetic", tso=tso,
                    available=True, kind=RAKind.PREVENTIVE, penalty_factor=1.0,
                    low_step=-10, high_step=10, r0=0,
                    operating_tap_min=-10, operating_tap_max=10, group_id=None,
                )
                return real_result + [synthetic_pst]
            return real_result

        monkeypatch.setattr(ncp_parser_module, "parse_psts", inject_one_synthetic_preventive_pst)
        monkeypatch.setattr(run_pipeline_module.ncp_parser, "parse_psts", inject_one_synthetic_preventive_pst)

        def fake_compute_sensitivity_pst_n0(*args, **kwargs):
            return {("SYNTHETIC-BRANCH", "SYNTHETIC-PST-FOR-BYPASS-TEST"): 0.0}

        monkeypatch.setattr(
            run_pipeline_module.n0_sensitivity, "compute_sensitivity_pst_n0", fake_compute_sensitivity_pst_n0,
        )
        monkeypatch.setattr(run_pipeline_module, "MAX_CHANGE_RA_SUM_THRESHOLD", 1_000_000_000.0)
        # the loop applies every solution to the network before checking convergence; the
        # synthetic PST does not exist there, so the apply step must not touch the network
        monkeypatch.setattr(
            run_pipeline_module.ac_convergence_loop, "_apply_pst_results_to_network", lambda network, rows: None,
        )

        captured_new_loop_calls = []
        original_new_loop = run_pipeline_module.ac_convergence_loop.run_post_rao_ac_verification_loop

        def spy_new_loop(*args, **kwargs):
            captured_new_loop_calls.append(kwargs)
            return original_new_loop(*args, **kwargs)

        monkeypatch.setattr(
            run_pipeline_module.ac_convergence_loop, "run_post_rao_ac_verification_loop", spy_new_loop,
        )

        run_pipeline_module.RA_TYPES = ["pst", "rd"]
        run_pipeline_module.ENABLE_NX_ANALYSIS = False
        run_pipeline_module.main()

        assert len(captured_new_loop_calls) == 1, (
            f"Expected exactly one call to the AC verification loop, got "
            f"{len(captured_new_loop_calls)}"
        )
        call_kwargs = captured_new_loop_calls[0]
        assert len(call_kwargs["pst_list"]) >= 1, "PST should genuinely be part of this call"
        assert len(call_kwargs["rd_list"]) >= 1, "RD should genuinely be part of this call — this is the actual fix being proven"


# ---------------------------------------------------------------------------
# The convergence check needs BOTH the PST and the RD term. Hand-crafted PST+RD data; the
# network steps (_apply_pst_results_to_network, apply_preventive_solution_to_network,
# _run_ac_loadflow) are faked, the check's own logic is tested.
# ---------------------------------------------------------------------------

class TestRdTermGenuinelyGatesConvergence:
    def test_large_rd_change_prevents_premature_convergence_even_when_pst_converges(self, monkeypatch):
        """The PST term converges on iteration 1 (very high PST threshold) but RD's target_p
        keeps changing by 15 MW per iteration (low RD threshold): the loop does not stop after
        iteration 1, so the RD term takes part in the decision.
        """
        from milp import ac_convergence_loop as acl
        from data_model import AEType, AssessedElement, PST, RDUnit, RAKind, PowerBid, BidDirection

        ae_list = [AssessedElement(
            mrid="AE1", name="a", tso="T", ae_type=AEType.SECURED, branch_mrid="BRANCH1",
            secured_for_region=None, scanned_for_region=None, exclusion_reason=None,
            patl_ka={"1030Z": 1.0}, branch_side=1,
        )]
        pst_list = [PST(
            mrid="PST1", name="PST1", tso="T", available=True, kind=RAKind.PREVENTIVE,
            penalty_factor=1.0, low_step=-10, high_step=10, r0=0,
            operating_tap_min=-10, operating_tap_max=10, group_id=None,
        )]
        rd_list = [RDUnit(
            mrid="RD1", name="RD1", tso="T", gu_mrid="GU1", gu_name="GU1",
            available=True, kind=RAKind.PREVENTIVE, initial_p=50.0, max_p=100.0, min_p=0.0,
            raise_ramp_rate=None, lower_ramp_rate=None, penalty_factor=1.0,
        )]
        # a bid and a GLSK: _add_rd_block needs both, else the RD block is skipped
        bid_list = [PowerBid(
            mrid="BID1", ra_mrid="RD1", direction=BidDirection.UP,
            available_mw={"1030Z": 50.0}, price_eur_mw=10.0, penalty_factor=1.0,
            lead_time_h=0.0, activation_cost_eur=None, min_energy_mwh=None,
            max_energy_mwh=None, step_size_mw=None,
        )]
        glsk = {"RD1": {"GU1": 1.0}}
        generator_data = {"GU1": {"target_p": 50.0, "max_p": 100.0, "min_p": 0.0}}

        # build_n0_milp_model / solve_n0_milp_model / extract_rd_target_p_solution are real;
        # only the network steps are faked (network=None)
        iteration_count = {"n": 0}

        def fake_apply_pst(network, pst_results):
            pass  # no-op: proven separately, not what this test checks

        applied_target_p = {"GU1": 50.0}

        def fake_apply_preventive(network, pst_tap_solution, rd_target_p_solution):
            applied_target_p.update(rd_target_p_solution)   # the fake network really moves
            return {}, {}

        def fake_run_ac_loadflow(network, use_reactive_limits=False, extra_lf_params=None):
            iteration_count["n"] += 1
            return True, "CONVERGED", None  # always "converges", instantly

        def fake_extract_generator_target_p(network):
            return dict(applied_target_p)  # the applied dispatch (a cyclic repetition needs a state that repeats)

        def fake_extract_rd_target_p_solution(model, generator_data):
            # what the convergence check reads: a large, persistent RD change every iteration
            # (set directly; the MILP's RD behaviour is tested elsewhere)
            return {"GU1": float(generator_data["GU1"]["target_p"]) + 15.0}

        monkeypatch.setattr(acl, "_apply_pst_results_to_network", fake_apply_pst)
        monkeypatch.setattr(acl, "apply_preventive_solution_to_network", fake_apply_preventive)
        monkeypatch.setattr(acl, "_run_ac_loadflow", fake_run_ac_loadflow)
        monkeypatch.setattr(acl, "_extract_generator_target_p", fake_extract_generator_target_p)
        monkeypatch.setattr(acl, "extract_rd_target_p_solution", fake_extract_rd_target_p_solution)
        monkeypatch.setattr(acl, "_extract_phase_tap_positions", lambda network: {})
        monkeypatch.setattr(acl, "_snapshot_bus_voltage_state", lambda network: {})
        # the sensitivity/LF refresh after iteration 1 needs a real network: mocked too
        monkeypatch.setattr(acl, "compute_sensitivity_pst_n0", lambda **kwargs: {("BRANCH1", "PST1"): 0.0})
        monkeypatch.setattr(acl, "compute_sensitivity_rd_n0", lambda **kwargs: {("BRANCH1", "GU1"): 0.0})
        monkeypatch.setattr(acl.cgmes_loader, "build_lf_initial", lambda network: {"BRANCH1": {1: 500.0}})

        lf_before, final_model, final_pst_results, termination_reason = acl.run_post_rao_ac_verification_loop(
            network=None,
            pst_list=pst_list,
            rd_list=rd_list,
            ae_flat_list=ae_list,
            timestamp="1030Z",
            lf_initial={"BRANCH1": {1: 500.0}},
            pst_tap_bounds={"PST1": (-10, 10)},
            sensitivity_pst_n0={("BRANCH1", "PST1"): 0.0},
            sensitivity_rd_n0={("BRANCH1", "GU1"): 0.0},
            pst_group_equality_pairs=[],
            penalty_reference_pst_pra=10.0,
            penalty_reference_rd_pra=10.0,
            penalty_cost_overload_n0=1000.0,
            pst_degrees_per_tap={"PST1": 1.0},
            generator_data=generator_data,
            bid_list=bid_list,
            glsk=glsk,
            # PST threshold absurdly high (always met); RD threshold 1.0 MW, never met by the
            # fake 15 MW change
            max_change_ra_sum_threshold=1_000_000.0,
            max_rd_mw_change_threshold=1.0,
            # isolate criterion 2's RD term: max_change_overload=0.0 disables criterion 4
            # (|delta| < 0.0 is never true; this scenario has no overload, so its delta is 0);
            # max_change_ra equals the low RD threshold so criterion 3's RD side fails too
            max_change_ra=1.0,
            max_change_overload=0.0,
            max_linearisation_iterations=3,
        )

        assert termination_reason == "max iterations reached", (
            f"Expected the loop to run all 3 iterations without converging "
            f"(RD term never satisfied), but got: {termination_reason!r}. "
            f"If this says 'tap change and RD MW change thresholds', the RD "
            f"term is being satisfied when it shouldn't be, or isn't being "
            f"checked at all — the exact defect this test exists to catch."
        )
        assert iteration_count["n"] >= 2, (
            "Expected at least 2 real AC load flow calls (i.e. the loop did "
            "NOT stop after iteration 1) — proving RD's own change genuinely "
            "prevented premature convergence, not just ran once and stopped."
        )


REPO_SRC = Path(__file__).resolve().parents[1] / "src" / "rao"


ALL_STATUSES = [
    (AcVerificationStatus.CONVERGED, "remedial action movement and congestion levels stabilized between iterations"),
    (AcVerificationStatus.REVERTED_NON_CONVERGENT, "load flow non-convergent"),
    (AcVerificationStatus.REVERTED_TO_LAST_CONVERGED_STATE,
     "load flow non-convergent - reverted to last converged state"),
    (AcVerificationStatus.MAX_ITERATIONS_REACHED, "max iterations reached"),
    (AcVerificationStatus.CYCLIC_REPETITION, "cyclic repetition of results"),
]


# ===========================================================================
# Convergence criteria and cyclic repetition
# ===========================================================================

CYCLIC_REASON = "cyclic repetition of results"


LIMIT_A = 1000.0


def _overload(current_a: float) -> float:
    return max(0.0, current_a - LIMIT_A)


def _grid_overload_sum(n0_lf: dict, nx_lf: dict) -> float:
    """Independent re-computation of the sum of the AC overloads of the fake grid."""
    total = sum(_overload(per_side[1]) for per_side in n0_lf.values())
    for per_branch in nx_lf.values():
        total += sum(_overload(per_side[1]) for per_side in per_branch.values())
    return total


# ================================================================ (c) per element, not netted
class TestOverloadChangeIsPerElement:
    def test_opposite_changes_of_two_elements_add_up_instead_of_cancelling(self):
        before = {("n0", "A"): 0.0, ("n0", "B"): 10.0}
        now = {("n0", "A"): 5.0, ("n0", "B"): 5.0}   # A +5, B -5
        assert acl.overload_change_ampere(now, before) == pytest.approx(10.0)

    def test_an_element_absent_from_the_previous_state_counts_with_its_full_overload(self):
        assert acl.overload_change_ampere({("n0", "A"): 7.0}, {}) == pytest.approx(7.0)

    def test_identical_overloads_give_zero(self):
        both = {("n0", "A"): 3.0, ("nx_patl", "B", "CO1"): 4.0}
        assert acl.overload_change_ampere(both, dict(both)) == 0.0


class TestElementOverloadsFromTheAcState:
    MONITORING = {
        "n0": {"B1": (1, 1000.0), "B2": (2, 800.0)},
        "nx_patl": {("B2", "CO1"): (1, 1000.0)},
        "nx_tatl": {("B2", "CO1"): (1, 1200.0)},
    }
    LF_N0 = {"B1": {1: 1250.0, 2: 0.0}, "B2": {1: 0.0, 2: 700.0}}
    LF_NX = {"CO1": {"B2": {1: 1100.0, 2: 0.0}}}

    def test_overload_is_the_excess_over_the_limit_of_the_model_clipped_at_zero(self):
        overloads = acl.element_overloads_ampere(self.MONITORING, self.LF_N0, self.LF_NX, {})
        assert overloads[("n0", "B1")] == pytest.approx(250.0)
        assert overloads[("n0", "B2")] == 0.0                    # side 2: 700 A < 800 A
        assert overloads[("nx_patl", "B2", "CO1")] == pytest.approx(100.0)
        assert overloads[("nx_tatl", "B2", "CO1")] == 0.0       # 1100 A < TATL 1200 A

    def test_the_curative_effect_is_added_to_the_n_x_current_but_not_to_the_n_0_current(self):
        curative = {("B2", "CO1"): -60.0}
        overloads = acl.element_overloads_ampere(self.MONITORING, self.LF_N0, self.LF_NX, curative)
        assert overloads[("nx_patl", "B2", "CO1")] == pytest.approx(40.0)
        assert overloads[("n0", "B1")] == pytest.approx(250.0)

    def test_the_curative_effect_is_not_added_to_the_tatl_current(self):
        """The TATL rows bound the state before the curative actions (CORNET-1790)."""
        monitoring = {"nx_tatl": {("B2", "CO1"): (1, 1050.0)}}
        overloads = acl.element_overloads_ampere(monitoring, self.LF_N0, self.LF_NX, {("B2", "CO1"): -60.0})
        assert overloads[("nx_tatl", "B2", "CO1")] == pytest.approx(50.0)   # 1100 - 1050, no -60

    def test_an_element_without_ac_data_is_left_out(self):
        overloads = acl.element_overloads_ampere(self.MONITORING, self.LF_N0, {}, {})
        assert ("nx_patl", "B2", "CO1") not in overloads
        assert ("n0", "B1") in overloads


# ================================================================ the model carries what the criterion needs
class TestModelCarriesTheMonitoredElementsAndLimits:
    def test_limits_and_sides_are_those_of_the_model_constraints(self, monkeypatch):
        scenario = Scenario(monkeypatch, physics_scale=1.0, with_nx=True, loop_overrides={"max_linearisation_iterations": 1})
        scenario.tatl_data = {"B2": {"tatl_limit_ampere": 1200.0, "tatl_duration_seconds": 900, "side": 1}}
        original = scenario.nx_inputs

        def nx_inputs_with_tatl():
            import dataclasses
            return dataclasses.replace(original(), tatl_data=scenario.tatl_data, penalty_cost_overload_nx_tatl=500.0)

        scenario.nx_inputs = nx_inputs_with_tatl
        scenario.last_state, (_, model, _, _) = scenario.run()
        monitoring = model.overload_monitoring
        assert monitoring["n0"] == {"B1": (1, LIMIT_A), "B2": (1, LIMIT_A)}
        assert monitoring["nx_patl"] == {("B1", "CO1"): (1, LIMIT_A), ("B2", "CO1"): (1, LIMIT_A)}
        assert monitoring["nx_tatl"] == {("B2", "CO1"): (1, 1200.0)}
        assert model.nx_curative_effect_ampere("B2", "CO1") == 0.0   # no curative action on this model
        state_after = scenario.last_state
        assert set(state_after.last_curative_effect_ampere) == {("B1", "CO1"), ("B2", "CO1")}


class TestMonitoringUsesTheSideOfTheBranch:
    def test_a_branch_monitored_on_side_2_is_recorded_with_side_2_for_n_0_and_n_x(self, monkeypatch):
        import dataclasses
        from helpers import _ae
        scenario = Scenario(monkeypatch, physics_scale=1.0, with_nx=True, loop_overrides={"max_linearisation_iterations": 1})
        scenario.ae_list = [_ae("B1"), dataclasses.replace(_ae("B2"), branch_side=2)]
        base_n0, base_nx = scenario.grid.n0_lf, scenario.grid.nx_lf
        scenario.grid.n0_lf = lambda: {**base_n0(), "B2": {1: 500.0, 2: 500.0}}
        scenario.grid.nx_lf = lambda: {"CO1": {**base_nx()["CO1"], "B2": {1: 1100.0, 2: 1100.0}}}
        _, (_, model, _, _) = scenario.run()
        assert model.overload_monitoring["n0"] == {"B1": (1, LIMIT_A), "B2": (2, LIMIT_A)}
        assert model.overload_monitoring["nx_patl"][("B2", "CO1")] == (2, LIMIT_A)
        assert model.overload_monitoring["nx_patl"][("B1", "CO1")] == (1, LIMIT_A)


# ================================================================ (a) slack 0 in both solves, AC overload still changing
class TestCriterion4DoesNotFireOnZeroSlackAlone:
    def test_loop_goes_on_while_the_ac_overload_per_element_is_still_changing(self, monkeypatch):
        # the physics reacts at half the strength the sensitivities promise: the model
        # believes the overload is gone (slack 0 in every solve) while the AC overload
        # only halves each iteration
        scenario = Scenario(monkeypatch, physics_scale=0.5, with_nx=True, loop_overrides={"max_change_overload": 1.0})
        state, (_, _, _, reason) = scenario.run()
        history = state.solve_history
        assert history[0]["total_overload"] == 0.0 and history[1]["total_overload"] == 0.0, "premise: slack 0 in both solves"
        assert history[1]["converged"] is False, (
            "criterion 4 declared convergence at iteration 2 on slack 0 == slack 0 although the AC overload is still changing"
        )
        assert history[1]["overload_change_ampere"] > 1.0
        assert history[1]["criterion_4_met"] is False
        assert len(history) > 2


# ================================================================ (b) fires when the per-element changes are small
class TestCriterion4FiresWhenTheAcOverloadHasStopped:
    def test_fires_alone_when_movement_criteria_are_switched_off(self, monkeypatch):
        scenario = Scenario(monkeypatch, physics_scale=1.0, with_nx=True, loop_overrides={
            "max_change_ra_sum_threshold": 0.0, "max_rd_mw_change_threshold": 0.0, "max_change_ra": 0.0,
            "max_change_overload": 1.0,
        })
        state, (_, _, _, reason) = scenario.run()
        last = state.solve_history[-1]
        assert last["converged"] is True and "stabilized" in reason
        assert last["criterion_4_met"] is True and last["overload_change_ampere"] < 1.0
        assert last["criterion_1_met"] is False and last["criterion_3_met"] is False
        assert last["converged_by"] == "criterion_4"
        assert len(state.solve_history) >= 2

    def test_fires_at_iteration_1_when_the_actions_leave_the_ac_overload_unchanged(self, monkeypatch):
        # physics scale 0: the network does not react at all. The model keeps asking
        # for movement (criteria 1 and 3 are false) but the AC overload per element
        # equals state 0.
        scenario = Scenario(monkeypatch, physics_scale=0.0, with_nx=True, loop_overrides={"max_change_overload": 1.0})
        state, (_, _, _, reason) = scenario.run()
        first = state.solve_history[0]
        assert first["sum_abs_tap_change"] > 1.0 or first["sum_abs_rd_change_mw"] > 1.0, "premise: the model moves"
        assert first["overload_change_ampere"] == pytest.approx(0.0, abs=1e-9)
        assert first["criterion_4_met"] is True and first["converged"] is True
        assert first["converged_by"] == "criterion_4"
        assert len(state.solve_history) == 1

    def test_is_not_evaluable_when_the_n_x_refresh_failed(self, monkeypatch):
        scenario = Scenario(monkeypatch, physics_scale=0.0, with_nx=True, loop_overrides={"max_change_overload": 1.0})
        hooks = scenario.hooks()
        hooks.compute_lf_nx = lambda network: {}      # the N-X load flow could not be evaluated
        scenario.hooks = lambda: hooks
        state, _ = scenario.run()
        first = state.solve_history[0]
        assert first["criterion_4_met"] is False, "an unchanged stale N-X baseline must not count as a stabilised overload"


class TestEachMovementCriterionIsAnIndependentAcceptanceCriterion:
    def _run(self, monkeypatch, **overrides):
        loop_overrides = {"max_change_overload": 0.0}      # criterion 4 off
        loop_overrides.update(overrides)
        scenario = Scenario(monkeypatch, physics_scale=1.0, with_nx=False, loop_overrides=loop_overrides)
        state, (_, _, _, reason) = scenario.run()
        return state.solve_history[-1], reason

    def test_criterion_3_alone_stops_the_loop(self, monkeypatch):
        last, reason = self._run(monkeypatch, max_change_ra_sum_threshold=0.0, max_rd_mw_change_threshold=0.0)
        assert last["converged"] is True and "stabilized" in reason
        assert last["converged_by"] == "criterion_3"
        assert last["criterion_1_met"] is False and last["criterion_4_met"] is False

    def test_criteria_1_and_2_alone_stop_the_loop(self, monkeypatch):
        last, reason = self._run(monkeypatch, max_change_ra=0.0)
        assert last["converged"] is True and "stabilized" in reason
        assert last["converged_by"] == "criterion_1"
        assert last["criterion_3_met"] is False and last["criterion_4_met"] is False


# ================================================================ (d) iteration 1 is evaluable against state 0
class TestIteration1AgainstTheInitialAcState:
    def test_value_is_state_0_minus_the_ac_state_after_the_first_applied_solution(self, monkeypatch):
        scenario = Scenario(monkeypatch, physics_scale=1.0, with_nx=True, loop_overrides={
            "max_linearisation_iterations": 1, "max_change_overload": 1.0,
        })
        state0_overload = _grid_overload_sum(scenario.grid.n0_lf(), scenario.grid.nx_lf())
        assert state0_overload == pytest.approx(600.0)    # B1 N-0 250 + (B1,CO1) 250 + (B2,CO1) 100
        state, _ = scenario.run()
        state1_overload = _grid_overload_sum(scenario.grid.n0_lf(), scenario.grid.nx_lf())
        record = state.solve_history[0]
        assert "overload_change_ampere" in record, "criterion 4 is not evaluated at iteration 1"
        assert record["overload_change_ampere"] == pytest.approx(state0_overload - state1_overload, abs=1e-6)
        assert record["criterion_4_met"] is False       # 600 A -> about 0 A is a big change


# ================================================================ (e) cyclic repetition
def _snap(taps: dict, net_rd_mw: dict) -> dict:
    return {"tap": dict(taps), "net_rd_mw": dict(net_rd_mw)}


class TestFindCyclicRepetition:
    A = _snap({"P": 0}, {"G": 0.0})
    B = _snap({"P": 4}, {"G": 40.0})

    def test_a_b_a_is_detected_and_names_the_iteration_it_matches(self):
        a_again = _snap({"P": 0}, {"G": 0.4})
        assert operating_point_state.find_cyclic_repetition([self.A, self.B, a_again], 1.0) == (0, pytest.approx(0.4))

    def test_equal_only_to_the_previous_iteration_is_not_a_cycle(self):
        b_again = _snap({"P": 4}, {"G": 40.2})
        assert operating_point_state.find_cyclic_repetition([self.A, self.B, b_again], 1.0) is None

    def test_needs_at_least_two_applied_iterations(self):
        assert operating_point_state.find_cyclic_repetition([self.A], 1.0) is None
        assert operating_point_state.find_cyclic_repetition([self.A, self.B], 1.0) is None

    def test_a_pst_or_a_unit_that_differs_by_the_threshold_or_more_is_no_match(self):
        taps_differ = _snap({"P": 1}, {"G": 0.0})
        mw_differ = _snap({"P": 0}, {"G": 1.0})
        assert operating_point_state.find_cyclic_repetition([self.A, self.B, taps_differ], 1.0) is None
        assert operating_point_state.find_cyclic_repetition([self.A, self.B, mw_differ], 1.0) is None

    def test_a_unit_missing_from_one_snapshot_counts_as_zero(self):
        assert operating_point_state.find_cyclic_repetition([self.A, self.B, _snap({"P": 0}, {})], 1.0) == (0, 0.0)

    def test_the_closest_earlier_solution_is_reported(self):
        c = _snap({"P": 0}, {"G": 30.0})
        assert operating_point_state.find_cyclic_repetition([self.A, c, self.B, _snap({"P": 0}, {"G": 30.3})], 1.0) == (1, pytest.approx(0.3))


class TestSolutionSnapshots:
    def test_snapshot_0_is_the_original_network_and_each_applied_solve_adds_the_cumulative_solution(self, monkeypatch):
        scenario = Scenario(monkeypatch, physics_scale=1.0)
        state = scenario.new_state()
        state.record_applied_solution(
            applied_tap_by_pst={"PST1": 3}, refreshed_target_p_by_gu={"GU1": 70.0, "GU2": 30.0},
            signed_bid_volume_delta_mw={}, lf_n0_after=scenario.grid.n0_lf(),
        )
        state.record_applied_solution(
            applied_tap_by_pst={"PST1": 1}, refreshed_target_p_by_gu={"GU1": 55.0, "GU2": 45.0},
            signed_bid_volume_delta_mw={}, lf_n0_after=scenario.grid.n0_lf(),
        )
        assert state.solution_snapshots == [
            {"tap": {"PST1": 0}, "net_rd_mw": {"GU1": 0.0, "GU2": 0.0}},
            {"tap": {"PST1": 3}, "net_rd_mw": {"GU1": 20.0, "GU2": -20.0}},
            {"tap": {"PST1": 1}, "net_rd_mw": {"GU1": 5.0, "GU2": -5.0}},
        ]


class TestCyclicRepetitionInTheLoop:
    def _overshooting(self, monkeypatch, **overrides):
        # criteria 1, 3 and 4 off: only the cycle exit and the iteration cap can stop the loop
        loop_overrides = {
            "max_change_ra_sum_threshold": 0.0, "max_rd_mw_change_threshold": 0.0, "max_change_ra": 1.0,
            "max_change_overload": 0.0,
        }
        loop_overrides.update(overrides)
        return Scenario(monkeypatch, physics_scale=2.0, with_nx=False, loop_overrides=loop_overrides)

    def test_an_oscillating_solution_stops_the_loop_with_the_cyclic_status(self, monkeypatch):
        scenario = self._overshooting(monkeypatch)
        state, (_, _, _, reason) = scenario.run()
        assert reason == CYCLIC_REASON, f"loop ended with {reason!r} after {len(state.solve_history)} solves"
        last = state.solve_history[-1]
        assert last["cycle_match_iteration"] is not None
        assert last["converged"] is False and last["solution_applied"] is True
        assert len(state.solve_history) < 10

    def test_the_reported_state_is_the_state_of_the_network(self, monkeypatch):
        scenario = self._overshooting(monkeypatch)
        state, (_, final_model, pst_rows, reason) = scenario.run()
        assert reason == CYCLIC_REASON
        assert pst_rows["PST1"]["result_tap_position"] == scenario.grid.taps["PST1"] == state.current_tap_by_pst["PST1"]
        assert scenario.grid.target_p["GU1"] == pytest.approx(state.current_target_p_by_gu["GU1"])


class TestAnAcceptanceCriterionTakesPrecedenceOverTheCycleExit:
    def test_a_converged_iteration_is_reported_as_converged_even_if_the_solution_also_repeats(self, monkeypatch):
        # force "the solution repeats" from the second applied solve on; the normal run converges there
        monkeypatch.setattr(
            acl, "find_cyclic_repetition", lambda snapshots, threshold: (0, 0.0) if len(snapshots) >= 3 else None,
        )
        scenario = Scenario(monkeypatch, physics_scale=1.0, with_nx=False, loop_overrides={"max_change_overload": 0.0})
        state, (_, _, _, reason) = scenario.run()
        assert "stabilized" in reason and state.solve_history[-1]["converged"] is True
        assert state.solve_history[-1]["cycle_match_iteration"] is None


class TestNoCycleWhenOnlyTheLastIterationRepeats:
    def test_a_solution_equal_to_iteration_k_minus_1_ends_by_the_iteration_cap_not_as_a_cycle(self, monkeypatch):
        scenario = Scenario(monkeypatch, physics_scale=1.0, with_nx=False, loop_overrides={
            "max_change_ra_sum_threshold": 0.0, "max_rd_mw_change_threshold": 0.0, "max_change_ra": 0.0,
            "max_change_overload": 0.0, "max_linearisation_iterations": 4,
        })
        state, (_, _, _, reason) = scenario.run()
        assert reason == "max iterations reached"
        assert all(r["cycle_match_iteration"] is None for r in state.solve_history)


# ===========================================================================
# Cycle exit
# ===========================================================================

MONITORING = {"n0": {"B1": (1, 1000.0), "B2": (1, 1000.0)}}


def _overload_b1(tap, gu1_mw):
    return max(0.0, 1250.0 - 50.0 * tap - 5.0 * (gu1_mw - 50.0) - 1000.0)


def _apply_member(scenario, state, tap, gu1_mw, cost, with_nx=False, curative=None):
    """put the fake network into the member's state and record it as the next applied solve"""
    grid = scenario.grid
    grid.taps["PST1"], grid.target_p["GU1"], grid.target_p["GU2"] = tap, gu1_mw, 100.0 - gu1_mw
    state.record_applied_solution(
        applied_tap_by_pst={"PST1": tap}, refreshed_target_p_by_gu=dict(grid.target_p),
        signed_bid_volume_delta_mw={"BID1": gu1_mw - 50.0 - state.cumulative_signed_volume_mw.get("BID1", 0.0)},
        lf_n0_after=grid.n0_lf(),
    )
    state.annotate_latest_member(
        model=SimpleNamespace(tag=f"model-{len(state.solution_snapshots) - 1}"),
        pst_results={"PST1": {"result_tap_position": tap}},
        lf_nx=grid.nx_lf() if with_nx else None,
        curative_effect=curative if curative is not None else {("B1", "CO1"): float(tap)},
        cost=cost,
    )


def _cycle(monkeypatch, members, with_nx=False):
    """members: [(tap, gu1_mw, cost[, curative effect])] applied in order; returns (scenario, state)"""
    scenario = Scenario(monkeypatch, physics_scale=1.0, with_nx=with_nx)
    state = scenario.new_state()
    for tap, gu1_mw, cost, *curative in members:
        _apply_member(scenario, state, tap, gu1_mw, cost, with_nx=with_nx, curative=curative[0] if curative else None)
    return scenario, state


def _resolve(scenario, state, matched_iteration, **kwargs):
    return acl.resolve_cyclic_repetition(
        state=state, network=object(), matched_iteration=matched_iteration, monitoring=MONITORING,
        nx_hooks=scenario.hooks(), use_reactive_limits=False, extra_lf_params=None, **kwargs,
    )


A, B = (3, 70.0), (1, 55.0)


assert _overload_b1(*A) == 0.0 and _overload_b1(*B) == 175.0


def _assert_network_and_state_describe(scenario, state, tap, gu1_mw):
    grid = scenario.grid
    assert grid.taps["PST1"] == state.current_tap_by_pst["PST1"] == tap
    assert grid.target_p["GU1"] == state.current_target_p_by_gu["GU1"] == pytest.approx(gu1_mw)
    assert grid.target_p["GU2"] == state.current_target_p_by_gu["GU2"] == pytest.approx(100.0 - gu1_mw)
    assert state.current_lf_n0 == grid.n0_lf()
    assert state.solution_snapshots[-1] == {"tap": {"PST1": tap}, "net_rd_mw": {"GU1": gu1_mw - 50.0, "GU2": 50.0 - gu1_mw}}
    assert state.cumulative_signed_volume_mw["BID1"] == pytest.approx(gu1_mw - 50.0)


# ============================================================ selection: A -> B -> A
class TestAThenBThenA:
    def test_the_cycle_ends_on_A_not_on_the_worse_member_B(self, monkeypatch):
        # snapshots: 0 original, 1 = A, 2 = B (higher overload), 3 = A again
        scenario, state = _cycle(monkeypatch, [(*A, 100.0), (*B, 100.0), (*A, 100.0)])
        outcome = _resolve(scenario, state, matched_iteration=1)
        assert outcome.selected_iteration in (1, 3)
        _assert_network_and_state_describe(scenario, state, *A)
        assert state.current_lf_n0["B1"][1] == pytest.approx(1000.0)

    def test_equal_overload_and_cost_ties_go_to_the_latest_member(self, monkeypatch):
        scenario, state = _cycle(monkeypatch, [(*A, 100.0), (*B, 100.0), (*A, 100.0)])
        assert _resolve(scenario, state, matched_iteration=1).selected_iteration == 3

    def test_equal_overload_goes_to_the_lower_cumulative_cost_even_if_it_is_not_the_latest(self, monkeypatch):
        scenario, state = _cycle(monkeypatch, [(*A, 80.0), (*B, 10.0), (*A, 120.0)])
        outcome = _resolve(scenario, state, matched_iteration=1)
        assert outcome.selected_iteration == 1
        assert outcome.model.tag == "model-1" and outcome.pst_results == {"PST1": {"result_tap_position": 3}}
        _assert_network_and_state_describe(scenario, state, *A)

    def test_the_cheaper_cost_of_the_later_member_wins_when_it_is_the_cheaper(self, monkeypatch):
        scenario, state = _cycle(monkeypatch, [(*A, 120.0), (*B, 10.0), (*A, 80.0)])
        assert _resolve(scenario, state, matched_iteration=1).selected_iteration == 3

    def test_a_lower_overload_beats_a_lower_cost(self, monkeypatch):
        # member 2 (B) is the cheapest by far but has the highest overload
        scenario, state = _cycle(monkeypatch, [(*A, 500.0), (*B, 1.0), (*A, 500.0)])
        assert _resolve(scenario, state, matched_iteration=1).selected_iteration in (1, 3)


# ============================================================ a cycle of three members, the middle one best
class TestMiddleMemberBest:
    def test_the_middle_member_is_selected_and_re_applied(self, monkeypatch):
        # snapshots: 0 original, 1 = B, 2 = A (best), 3 = B (matches 1)
        scenario, state = _cycle(monkeypatch, [(*B, 100.0), (*A, 900.0), (*B, 100.0)])
        assert _overload_b1(*A) < _overload_b1(*B)
        outcome = _resolve(scenario, state, matched_iteration=1)
        assert outcome.selected_iteration == 2 and outcome.restored is True
        _assert_network_and_state_describe(scenario, state, *A)
        assert outcome.model.tag == "model-2" and outcome.pst_results == {"PST1": {"result_tap_position": 3}}
        assert len(state.solution_snapshots) == len(state.member_records) == 3, "the state is rewound to the selected member"

    def test_members_before_the_matched_iteration_are_not_candidates(self, monkeypatch):
        # member 1 (A, cost 1) ties member 3 on overload 0 and would win on cost, but lies before
        # the matched iteration 2: members 2 (B), 3 (C) and 4 (B) compete, C wins
        scenario, state = _cycle(monkeypatch, [(*A, 1.0), (*B, 100.0), (4, 80.0, 100.0), (*B, 100.0)])
        outcome = _resolve(scenario, state, matched_iteration=2)
        assert outcome.selected_iteration == 3
        _assert_network_and_state_describe(scenario, state, 4, 80.0)

    def test_the_original_network_is_never_re_applied_when_the_cycle_starts_there(self, monkeypatch):
        # snapshots: 0 original (overload 250), 1 = A (0), 2 = original again: members 0, 1, 2
        scenario, state = _cycle(monkeypatch, [(*A, 100.0), (0, 50.0, 100.0)])
        outcome = _resolve(scenario, state, matched_iteration=0)
        assert outcome.selected_iteration == 1
        _assert_network_and_state_describe(scenario, state, *A)


    def test_the_original_network_is_not_a_candidate_even_if_it_has_the_lowest_overload(self, monkeypatch):
        # snapshots: 0 original (250 A), 1 = worse than the original (400 A), 2 = the original again:
        # member 0 would win on cost (0.0) but has no solved model; member 2 repeats it
        scenario, state = _cycle(monkeypatch, [(-3, 50.0, 100.0), (0, 50.0, 100.0)])
        outcome = _resolve(scenario, state, matched_iteration=0)
        assert outcome.selected_iteration == 2 and outcome.restored is False and outcome.model is not None

    def test_the_curative_effect_of_the_member_counts_in_its_overload(self, monkeypatch):
        # equal N-0 overload (B) in both members; the N-X current of B2 is 1100 A, member 1 has a
        # curative effect of -100 A on it (no overload left), member 2 none (100 A over)
        monitoring = {"n0": {"B1": (1, 1000.0)}, "nx_patl": {("B2", "CO1"): (1, 1000.0)}}
        scenario, state = _cycle(
            monkeypatch,
            [(*B, 100.0, {("B2", "CO1"): -100.0}), (1, 55.0, 100.0, {("B2", "CO1"): 0.0}), (*B, 100.0, {("B2", "CO1"): 0.0})],
            with_nx=True,
        )
        # only member 1 has the curative effect: it has no N-X overload left, members 2 and 3 have 100 A
        state.member_records[1]["lf_nx"] = state.member_records[2]["lf_nx"] = state.member_records[3]["lf_nx"] = (
            {"CO1": {"B2": {1: 1100.0}}}
        )
        outcome = acl.resolve_cyclic_repetition(
            state=state, network=object(), matched_iteration=1, monitoring=monitoring, nx_hooks=scenario.hooks(),
        )
        assert outcome.selected_iteration == 1


# ============================================================ nothing to restore / restore fails
class TestKeepingTheLastMember:
    def test_when_the_newest_member_is_the_best_the_network_is_left_alone(self, monkeypatch):
        scenario, state = _cycle(monkeypatch, [(*B, 100.0), (*A, 100.0), (*A, 90.0)])
        calls_before = scenario.grid.load_flow_calls
        snapshots_before = list(state.solution_snapshots)
        outcome = _resolve(scenario, state, matched_iteration=1)
        assert outcome.selected_iteration == 3 and outcome.restored is False
        assert scenario.grid.load_flow_calls == calls_before
        assert state.solution_snapshots == snapshots_before

    def test_a_non_converging_re_application_reverts_to_the_newest_member_and_says_so(self, monkeypatch, caplog):
        scenario, state = _cycle(monkeypatch, [(*B, 100.0), (*A, 900.0), (*B, 100.0)])
        scenario.grid.fail_load_flow_on_calls = {scenario.grid.load_flow_calls + 1}
        with caplog.at_level("WARNING"):
            outcome = _resolve(scenario, state, matched_iteration=1)
        assert outcome.selected_iteration == 3 and outcome.restored is False
        _assert_network_and_state_describe(scenario, state, *B)
        assert any("did not converge" in r.getMessage() for r in caplog.records)


# ============================================================ what the state and the files see
class TestStateAndFilesDescribeTheSelectedMember:
    def test_the_n_x_baseline_and_the_curative_effect_belong_to_the_selected_member(self, monkeypatch):
        scenario, state = _cycle(monkeypatch, [(*B, 100.0), (*A, 900.0), (*B, 100.0)], with_nx=True)
        _resolve(scenario, state, matched_iteration=1)
        assert state.current_lf_nx == scenario.grid.nx_lf()
        assert state.last_curative_effect_ampere == {("B1", "CO1"): 3.0}
        assert state.sensitivities_stale is True, "the sensitivities still belong to the discarded newest member"

    def test_the_selected_members_model_gives_the_selected_cumulative_redispatch(self, monkeypatch):
        scenario = Scenario(monkeypatch, physics_scale=2.0, with_nx=False, loop_overrides={
            "max_change_ra_sum_threshold": 0.0, "max_rd_mw_change_threshold": 0.0, "max_change_ra": 1.0,
            "max_change_overload": 0.0,
        })
        state, (_, final_model, pst_rows, reason) = scenario.run()
        assert reason == CYCLIC_REASON
        from post_milp import n0_results_export as export
        from helpers import export_status
        rd_rows = export.extract_rd_results(
            final_model, scenario.rd_list, scenario.bid_list, 10.0, export_status(), "x",
        )
        assert rd_rows["BID1"]["rd_volume_net_mw"] == pytest.approx(state.cumulative_signed_volume_mw["BID1"], abs=1e-6)
        assert pst_rows["PST1"]["result_tap_position"] == state.current_tap_by_pst["PST1"] == scenario.grid.taps["PST1"]


# ============================================================ in the loop
class TestInTheLoop:
    def _oscillating(self, monkeypatch, with_nx=False):
        # physics twice as strong as the model: original (250 A over) -> A (0 A) -> original again
        return Scenario(monkeypatch, physics_scale=2.0, with_nx=with_nx, loop_overrides={
            "max_change_ra_sum_threshold": 0.0, "max_rd_mw_change_threshold": 0.0, "max_change_ra": 1.0,
            "max_change_overload": 0.0,
        })

    def test_the_loop_ends_on_the_best_member_of_the_oscillation_not_on_the_last_one(self, monkeypatch):
        scenario = self._oscillating(monkeypatch)
        state, (lf, final_model, pst_rows, reason) = scenario.run()
        assert reason == CYCLIC_REASON
        assert [s["tap"]["PST1"] for s in state.solution_snapshots] == [0, 3], "rewound to the first applied solve"
        assert scenario.grid.taps["PST1"] == 3 and scenario.grid.target_p["GU1"] == pytest.approx(70.0)
        assert state.current_tap_by_pst["PST1"] == 3 and pst_rows["PST1"]["result_tap_position"] == 3
        assert lf == state.current_lf_n0 == scenario.grid.n0_lf()
        import pyomo.environ as pyo
        assert pyo.value(final_model.objective) == pytest.approx(state.solve_history[0]["objective_value"])

    def test_the_cycle_row_records_the_selected_iteration(self, monkeypatch):
        scenario = self._oscillating(monkeypatch)
        state, _ = scenario.run()
        last = state.solve_history[-1]
        assert last["cycle_match_iteration"] == 0 and last["cycle_selected_iteration"] == 1
        assert all(row.get("cycle_selected_iteration") in (None, "") for row in state.solve_history[:-1])

    def test_the_history_csv_has_the_selected_iteration_column(self, monkeypatch, tmp_path):
        from post_milp import n0_results_export as export
        scenario = self._oscillating(monkeypatch)
        state, _ = scenario.run()
        path = tmp_path / "history.csv"
        export.write_iteration_history_csv(state.solve_history, path)
        with open(path, newline="", encoding=TEXT_ENCODING) as handle:
            rows = list(csv.DictReader(handle))
        assert "cycle_selected_iteration" in rows[0]
        assert [row["cycle_selected_iteration"] for row in rows] == [""] * (len(rows) - 1) + ["1"]

    def test_with_the_n_x_model_the_n_x_baseline_is_that_of_the_selected_state(self, monkeypatch):
        scenario = self._oscillating(monkeypatch, with_nx=True)
        state, (_, _, _, reason) = scenario.run()
        assert reason == CYCLIC_REASON
        assert state.current_lf_nx == scenario.grid.nx_lf()
        assert scenario.grid.taps["PST1"] == 3

    def test_the_loop_records_the_cost_model_and_rows_of_every_applied_solve(self, monkeypatch):
        scenario = self._oscillating(monkeypatch)
        state, (_, final_model, pst_rows, _) = scenario.run()
        record = state.member_records[1]
        assert record["cost"] == pytest.approx(state.solve_history[0]["objective_value"]) and record["cost"] > 0.0
        assert record["model"] is final_model and record["pst_results"] is not None
        assert len(state.member_records) == len(state.solution_snapshots) == 2

    def test_the_loop_records_the_n_x_load_flow_and_the_curative_effect_of_every_applied_solve(self, monkeypatch):
        scenario = self._oscillating(monkeypatch, with_nx=True)
        state, _ = scenario.run()
        record = state.member_records[1]
        assert record["lf_nx"] is not None and record["lf_nx"] == state.current_lf_nx
        assert set(record["curative_effect"]) == {("B1", "CO1"), ("B2", "CO1")}
        assert state.member_records[0]["lf_nx"] == state.original_lf_nx

    def test_a_cycle_whose_newest_member_is_the_best_changes_nothing(self, monkeypatch):
        # the oscillation of the other direction is not constructible with the linear grid; the unit
        # tests above cover it, here: the existing cap behaviour without any cycle is untouched
        scenario = Scenario(monkeypatch, physics_scale=1.0, with_nx=False, loop_overrides={
            "max_change_ra_sum_threshold": 0.0, "max_rd_mw_change_threshold": 0.0, "max_change_ra": 0.0,
            "max_change_overload": 0.0, "max_linearisation_iterations": 4,
        })
        state, (_, _, _, reason) = scenario.run()
        assert reason == "max iterations reached"
        assert all(row.get("cycle_selected_iteration") in (None, "") for row in state.solve_history)


# ===========================================================================
# Completeness (outer) loop
# ===========================================================================

class TestCompletenessOuterLoop:
    def test_stops_after_the_first_check_when_no_new_congestion_is_found(self, monkeypatch):
        _, state, _, log_rows, calls = _run_nested(monkeypatch, [0], max_completeness_iterations=5)
        assert len(calls) == 1
        assert [r["completeness_iteration"] for r in log_rows] == [0, 1]
        assert [r["new_constraints_added"] for r in log_rows] == [0, 0]
        assert {r["completeness_iteration"] for r in state.solve_history} == {0}

    def test_runs_the_linearisation_loop_again_when_new_congestion_is_found_then_stops(self, monkeypatch):
        _, state, _, log_rows, calls = _run_nested(monkeypatch, [2, 0], max_completeness_iterations=5)
        assert len(calls) == 2
        assert [(r["completeness_iteration"], r["new_constraints_added"]) for r in log_rows] == [(0, 0), (1, 2), (2, 0)]
        assert {r["completeness_iteration"] for r in state.solve_history} == {0, 1}
        assert state.solve_history[-1]["new_constraints_added"] == 0

    def test_stops_at_max_completeness_iterations_without_full_convergence(self, monkeypatch, caplog):
        import logging
        with caplog.at_level(logging.WARNING):
            _, state, _, log_rows, calls = _run_nested(monkeypatch, [1], max_completeness_iterations=2)
        assert len(calls) == 3                                  # iterations 0, 1 and 2 each end with a check
        assert {r["completeness_iteration"] for r in state.solve_history} == {0, 1, 2}
        assert log_rows[-1]["new_constraints_added"] == 1
        assert any("max_completeness_iterations=2 reached" in r.getMessage() for r in caplog.records)

    def test_total_nx_constraints_include_the_new_pairs_of_each_check(self, monkeypatch):
        _, _, _, log_rows, _ = _run_nested(monkeypatch, [2, 0], max_completeness_iterations=5)
        assert log_rows[1]["total_nx_constraints"] == log_rows[0]["total_nx_constraints"] + 2


class TestCountNxPairs:
    def test_scanned_pairs_are_counted_with_patl_and_tatl_pairs(self):
        """Regression guard for the SNEC bookkeeping gap: scanned pairs count in total_nx_constraints."""
        class FakeModel:
            nx_branch_contingency_pairs = {("b1", "co1")}
            nx_tatl_branch_contingency_pairs = {("b1", "co1"), ("b2", "co1")}
            nx_scanned_branch_contingency_pairs = {("s1", "co1")}

        assert acl._count_nx_pairs(FakeModel()) == 4

    def test_a_model_without_nx_blocks_counts_zero(self):
        assert acl._count_nx_pairs(object()) == 0


# ===========================================================================
# N-0 sensitivity refresh
# ===========================================================================

# ---------------------------------------------------------------------------
# loop level (FakeGrid harness): the N-0 refresh at the applied state
# ---------------------------------------------------------------------------

def _n0_refresh_scenario(monkeypatch, pst_invalid, rd_invalid):
    from milp import ac_convergence_loop as acl
    from helpers import Scenario
    scenario = Scenario(monkeypatch, physics_scale=1.0, with_nx=False, loop_overrides={
        "max_change_ra_sum_threshold": 0.0, "max_rd_mw_change_threshold": 0.0, "max_change_ra": 0.0,
        "max_change_overload": 0.0, "max_linearisation_iterations": 3,
    })

    def fake(sensitivities, invalid):
        def compute(**kwargs):
            if kwargs.get("guard_out") is not None:
                kwargs["guard_out"].clear()
                kwargs["guard_out"].update(invalid)
            return dict(sensitivities)
        return compute

    monkeypatch.setattr(acl, "compute_sensitivity_pst_n0", fake(scenario.sens_pst_n0, pst_invalid))
    monkeypatch.setattr(acl, "compute_sensitivity_rd_n0", fake(scenario.sens_rd_n0, rd_invalid))
    return scenario


def test_the_n_0_refresh_reports_the_invalid_branches_of_both_analyses(monkeypatch, caplog):
    scenario = _n0_refresh_scenario(monkeypatch, {"B1": "zero reference"}, {"B2": "zero reference"})
    with caplog.at_level("WARNING"):
        state, _ = scenario.run()
    assert state.invalid_sensitivity_n0 == {"B1": "zero reference", "B2": "zero reference"}
    counts = [row["invalid_sensitivity_branches_n0"] for row in state.solve_history]
    assert counts[0] == 0 and counts[1:] and all(count == 2 for count in counts[1:])
    warning = [r.getMessage() for r in caplog.records if r.levelname == "WARNING" and "SENSITIVITY GUARD" in r.getMessage()]
    assert warning and "B1" in warning[0] and "B2" in warning[0] and "N-0" in warning[0]


def test_the_n_0_refresh_reports_each_analysis_separately(monkeypatch):
    only_pst, _ = _n0_refresh_scenario(monkeypatch, {"B1": "x"}, {}).run()
    assert list(only_pst.invalid_sensitivity_n0) == ["B1"]
    only_rd, _ = _n0_refresh_scenario(monkeypatch, {}, {"B2": "y"}).run()
    assert list(only_rd.invalid_sensitivity_n0) == ["B2"]


# ===========================================================================
# Completeness limit flag and contingencies lost at a refresh
# ===========================================================================

# ---------------------------------------------------------------------------
# reporting (completeness limit flag, skipped contingency reasons) and the counter of
# contingencies lost per N-X refresh
# ---------------------------------------------------------------------------

def test_the_state_flags_that_the_completeness_iteration_limit_was_reached(monkeypatch):
    from helpers import _run_nested
    _, state, _, _, _ = _run_nested(monkeypatch, [1], max_completeness_iterations=2)
    assert state.completeness_limit_reached is True


def test_the_state_does_not_flag_the_limit_when_completeness_converged(monkeypatch):
    from helpers import _run_nested
    _, state, _, _, _ = _run_nested(monkeypatch, [2, 0], max_completeness_iterations=5)
    assert state.completeness_limit_reached is False


def test_the_iteration_history_counts_the_contingencies_lost_at_each_nx_refresh(monkeypatch):
    from helpers import Scenario
    scenario = Scenario(monkeypatch, physics_scale=0.7, with_nx=True)
    state = scenario.new_state()
    state.current_lf_nx = {**state.current_lf_nx, "CO2": dict(state.current_lf_nx["CO1"])}
    scenario.run(state=state)           # the refreshed N-X load flow only has CO1
    lost = [r["nx_contingencies_lost_at_refresh"] for r in state.solve_history]
    assert lost[0] == 1
    assert all(n == 0 for n in lost[1:])


# ===========================================================================
# Stops without a new applied solution (revert, guard, solver)
# ===========================================================================

REVERT_TO_LAST = "load flow non-convergent - reverted to last converged state"


def _nested_with_failure_in_second_completeness_iteration(monkeypatch, failure):
    """Completeness iteration 0 converges and finds one new pair; the first linearisation
    iteration of completeness iteration 1 then fails in the way `failure` sets up."""
    scenario = Scenario(monkeypatch, physics_scale=1.0, with_nx=True, loop_overrides=dict(_NESTED_OVERRIDES))
    state = scenario.new_state()
    base = scenario.hooks()

    def find_new_pairs(model, lf_nx):
        failure(scenario, monkeypatch)
        return 1

    hooks = acl.NxLoopHooks(
        compute_lf_nx=base.compute_lf_nx, compute_sensitivities_nx=base.compute_sensitivities_nx,
        find_new_pairs=find_new_pairs,
    )
    result = acl.run_nested_rao_loop(
        max_completeness_iterations=1, state=state, nx_hooks=hooks, **scenario.loop_kwargs(),
    )
    return scenario, state, result


def _fail_next_load_flow(scenario, monkeypatch):
    scenario.grid.fail_load_flow_on_calls = {scenario.grid.load_flow_calls + 1}


def _fail_next_n0_refresh(scenario, monkeypatch):
    monkeypatch.setattr(acl, "_refresh_n0_sensitivities", lambda *args, **kwargs: "branch B1: invalid (test)")


class TestALaterCompletenessIterationWithoutItsOwnSolution:
    @pytest.mark.parametrize("failure, reason", [
        (_fail_next_load_flow, REVERT_TO_LAST),
        (_fail_next_n0_refresh, acl.SENSITIVITY_INVALID_REASON),
    ])
    def test_the_last_applied_model_of_the_run_is_returned_and_exported(self, monkeypatch, tmp_path, failure, reason):
        import pyomo.environ as pyo
        from post_milp import n0_results_export as export
        scenario, state, (lf, model, pst_rows, returned_reason, _) = (
            _nested_with_failure_in_second_completeness_iteration(monkeypatch, failure)
        )
        assert returned_reason == reason
        last_applied = [r for r in state.member_records if r["model"] is not None][-1]
        assert model is not None and model is last_applied["model"]
        assert pst_rows["PST1"]["result_tap_position"] == scenario.grid.taps["PST1"] == state.current_tap_by_pst["PST1"]
        summary = export.extract_results_summary(
            model, objective_value=float(pyo.value(model.objective)), pst_list=scenario.pst_list,
            penalty_reference_pst_pra=10.0, output_path=tmp_path / "summary.csv",
        )
        assert summary["objective_value"] == pytest.approx(last_applied["cost"])


def _zero_change_expected(scenario, state, model, pst_rows):
    from post_milp import n0_results_export as export
    from helpers import export_status
    assert getattr(model, "no_applied_solution", False) is True
    assert pst_rows["PST1"]["tap_change_result"] == 0 and pst_rows["PST1"]["last_solve_tap_change"] == 0
    assert pst_rows["PST1"]["result_tap_position"] == state.original_tap_by_pst["PST1"] == scenario.grid.taps["PST1"]
    assert pst_rows["PST1"]["penalty_cost_eur"] == 0.0
    rd_rows = export.extract_rd_results(model, scenario.rd_list, scenario.bid_list, 10.0, export_status(), "x")
    assert all(row["rd_volume_net_mw"] == 0.0 and row["rd_cost_eur"] == 0.0 for row in rd_rows.values())
    summary = export.extract_results_summary(
        model, objective_value=None, pst_list=scenario.pst_list, penalty_reference_pst_pra=10.0, rd_results=rd_rows,
    )
    assert summary["objective_value"] == "" and summary["objective_residual_eur"] == ""
    # the slack is the overload of the original network: B1 carries 1250 A against 1000 A
    assert summary["sum_overload_slack_penalty_n0_eur"] == pytest.approx(1000.0 * 250.0)


class TestRevertToTheOriginalNetworkReportsNoChange:
    def test_files_describe_the_original_network_not_the_rejected_solution(self, monkeypatch):
        scenario = Scenario(monkeypatch, physics_scale=1.0)
        scenario.grid.fail_load_flow_on_calls = {1}
        state, (_, model, pst_rows, reason) = scenario.run()
        assert reason == "load flow non-convergent"
        _zero_change_expected(scenario, state, model, pst_rows)


def _infeasible_at_build(monkeypatch, build_number):
    """Makes build number `build_number` (1-based) genuinely infeasible."""
    import pyomo.environ as pyo
    spy_build = acl.build_n0_milp_model
    builds = []

    def build(*args, **kwargs):
        model = spy_build(*args, **kwargs)
        builds.append(model)
        if len(builds) == build_number:
            model.impossible = pyo.Constraint(expr=model.tap_change_upward["PST1"] <= -1)
        return model

    monkeypatch.setattr(acl, "build_n0_milp_model", build)
    return builds


class TestSolverNonOptimal:
    def test_infeasible_at_iteration_one_stops_with_the_original_network(self, monkeypatch):
        scenario = Scenario(monkeypatch, physics_scale=1.0)
        _infeasible_at_build(monkeypatch, 1)
        state, (_, model, pst_rows, reason) = scenario.run()
        assert reason == acl.SOLVER_NON_OPTIMAL_REASON
        assert AcVerificationStatus.from_termination_reason(reason) is AcVerificationStatus.SOLVER_NON_OPTIMAL
        assert scenario.grid.load_flow_calls == 0
        _zero_change_expected(scenario, state, model, pst_rows)
        assert state.solve_history[-1]["solution_applied"] is False

    def test_infeasible_at_a_later_iteration_keeps_the_last_applied_solution(self, monkeypatch):
        scenario = Scenario(monkeypatch, physics_scale=0.7, loop_overrides={
            "max_change_ra_sum_threshold": 0.0, "max_rd_mw_change_threshold": 0.0, "max_change_ra": 0.0,
            "max_change_overload": 0.0,
        })
        builds = _infeasible_at_build(monkeypatch, 2)
        state, (_, model, pst_rows, reason) = scenario.run()
        assert reason == acl.SOLVER_NON_OPTIMAL_REASON
        assert model is builds[0] and not getattr(model, "no_applied_solution", False)
        assert pst_rows["PST1"]["result_tap_position"] == scenario.grid.taps["PST1"] == state.current_tap_by_pst["PST1"]
        assert [r["solution_applied"] for r in state.solve_history] == [True, False]


class TestCycleExitWhenBothReApplicationsFail:
    def test_the_voltage_snapshot_is_restored_and_the_loop_reports_the_revert(self, monkeypatch, caplog):
        scenario, state = _cycle(monkeypatch, [(*B, 100.0), (*A, 900.0), (*B, 100.0)])
        restored = []
        monkeypatch.setattr(acl, "_snapshot_bus_voltage_state", lambda network: {"bus": (1.0, 0.0)})
        monkeypatch.setattr(acl, "_restore_bus_voltage_state", lambda network, snapshot: restored.append(snapshot))
        calls = scenario.grid.load_flow_calls
        scenario.grid.fail_load_flow_on_calls = {calls + 1, calls + 2}
        with caplog.at_level("ERROR"):
            outcome = _resolve(scenario, state, matched_iteration=1)
        assert outcome.reapply_failed is True and outcome.selected_iteration == 3
        assert restored and restored[-1] == {"bus": (1.0, 0.0)}
        assert any(r.levelname == "ERROR" for r in caplog.records)


class TestEmptyGeneratorReadBack:
    def test_an_empty_target_p_read_back_stops_before_anything_is_applied(self, monkeypatch, caplog):
        scenario = Scenario(monkeypatch, physics_scale=1.0)
        monkeypatch.setattr(acl, "_extract_generator_target_p", lambda network: {})
        with caplog.at_level("ERROR"):
            state, (_, _, _, reason) = scenario.run()
        assert reason == "load flow non-convergent"
        assert scenario.grid.taps == scenario.grid.original_taps
        assert scenario.grid.target_p == scenario.grid.original_target_p
        assert scenario.grid.load_flow_calls == 0
        assert any("target_p" in r.getMessage() for r in caplog.records if r.levelname == "ERROR")


class TestCriterion4WithoutAnNxRefresh:
    def test_an_empty_nx_refresh_never_counts_as_criterion_4(self, monkeypatch, caplog):
        scenario = Scenario(monkeypatch, physics_scale=1.0, with_nx=True, loop_overrides={
            "max_change_ra_sum_threshold": 0.0, "max_rd_mw_change_threshold": 0.0, "max_change_ra": 0.0,
            "max_change_overload": 1e12, "max_linearisation_iterations": 3,
        })
        base = scenario.hooks()
        monkeypatch.setattr(scenario, "hooks", lambda: acl.NxLoopHooks(
            compute_lf_nx=lambda network: {}, compute_sensitivities_nx=base.compute_sensitivities_nx,
            find_new_pairs=base.find_new_pairs,
        ))
        with caplog.at_level("WARNING"):
            state, (_, _, _, reason) = scenario.run()
        assert reason == "max iterations reached"
        assert all(r["criterion_4_met"] is False for r in state.solve_history)
        assert any("Criterion 4 not evaluated" in r.getMessage() for r in caplog.records)
