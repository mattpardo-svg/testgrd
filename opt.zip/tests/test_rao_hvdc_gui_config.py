"""
test_rao_hvdc_gui_config.py — the GUI side of the hvdc ra_type (docs/hvdc_ra_specs.md H7.1, H10.3):
the HVDC toggle on the Main page, the two penalty references on the RAO Settings page, saved
settings that predate the keys, and the temp config the GUI writes for a run.
"""
import json

import yaml

import run_pipeline
from test_rao_dc_mode import _gui_common, _page
from text_encoding import TEXT_ENCODING


def test_the_main_page_has_an_hvdc_toggle_that_is_off_by_default():
    page = _page("1_Main.py")
    page.run()

    assert not page.exception
    assert page.toggle(key="toggle_hvdc").value is False
    assert page.toggle(key="toggle_pst").value is True and page.toggle(key="toggle_rd").value is True


def test_switching_every_ra_type_off_shows_the_error_naming_hvdc():
    page = _page("1_Main.py")
    page.run()
    for key in ("toggle_pst", "toggle_rd", "toggle_hvdc"):
        page.toggle(key=key).set_value(False)
    page.run()

    assert any("HVDC" in e.value for e in page.error)


def test_the_curative_hvdc_file_is_grouped_with_the_curative_pst_and_rd_files(tmp_path):
    """results_curative_hvdc.csv sits where results_curative_pst.csv and results_curative_rd.csv sit ("Other"),
    results_hvdc.csv with the preventive results ("N-0 results")."""
    (tmp_path / "output").mkdir()
    for name in ("results_hvdc.csv", "results_curative_hvdc.csv", "results_curative_pst.csv", "results_curative_rd.csv"):
        (tmp_path / "output" / name).write_text("a\n", encoding=TEXT_ENCODING)
    page = _page("1_Main.py")
    page.session_state["run_complete"] = True
    page.session_state["run_exit_code"] = 0
    page.session_state["tmpdir"] = tmp_path
    page.run()

    assert not page.exception
    labels = {expander.label for expander in page.expander}
    assert "N-0 results (1 file(s))" in labels
    assert "Other (3 file(s))" in labels


def test_the_settings_page_shows_the_two_hvdc_references_with_the_defaults():
    page = _page("3_RAO_Settings.py")
    page.run()

    assert not page.exception
    values = {element.label: element.value for element in page.number_input}
    assert values["penalty_reference_hvdc_pra"] == 100.0
    assert values["penalty_reference_hvdc_cra"] == 100.0


def test_saved_settings_without_the_hvdc_keys_get_the_defaults(tmp_path, monkeypatch):
    gui = _gui_common()
    saved = {"rao_config": {"penalty_costs": {"penalty_reference_rd_pra": 55.0}}, "load_flow_config": {}}
    settings_file = tmp_path / "settings.json"
    settings_file.write_text(json.dumps(saved), encoding=TEXT_ENCODING)
    monkeypatch.setattr(gui, "SETTINGS_FILE_PATH", settings_file)

    costs = gui.load_settings()["rao_config"]["penalty_costs"]

    assert costs["penalty_reference_rd_pra"] == 55.0                       # the saved value still applies
    assert costs["penalty_reference_hvdc_pra"] == costs["penalty_reference_hvdc_cra"] == 100.0


def test_the_gui_temp_config_with_hvdc_passes_the_pipeline_checks():
    gui = _gui_common()
    rao_config = {section: dict(values) for section, values in gui.DEFAULT_RAO_CONFIG.items()}
    rao_config["workflow_toggles"]["ra_types"] = ["pst", "hvdc"]
    rao_config["penalty_costs"]["penalty_reference_hvdc_cra"] = 12.5

    tmpdir = gui.build_temp_run_dir(b"cgm", b"ncp", rao_config, gui.DEFAULT_LOAD_FLOW_CONFIG)
    try:
        path = tmpdir / "src" / "rao" / "config" / "rao_config.yaml"
        written = yaml.safe_load(path.read_text(encoding=TEXT_ENCODING))
        run_pipeline.validate_config_ranges(written, path)
    finally:
        gui.cleanup_temp_run_dir(tmpdir)

    assert written["workflow_toggles"]["ra_types"] == ["pst", "hvdc"]
    assert run_pipeline.validate_hvdc_penalty_references(written, path) == (100.0, 12.5)


class TestInventorySummary:
    def _lines(self, caplog, hvdc_list):
        import logging
        from pre_milp import inventory_summary

        with caplog.at_level(logging.INFO):
            inventory_summary.print_inventory_summary(
                {"t": "TSO-X"}, {"TSO-X": {}}, [], [], [], [], [], ["1030Z"], hvdc_list=hvdc_list,
            )
        return caplog.records[-1].message

    def test_the_hvdc_column_appears_only_with_an_hvdc_list(self, caplog):
        from data_model import HvdcUnit, RAKind

        unit = HvdcUnit(mrid="U", name="U", tso="TSO-X", ei_mrid="E", available=True, kind=RAKind.PREVENTIVE, penalty_factor=1.0)
        with_hvdc = self._lines(caplog, [unit, unit])
        assert "HVDC" in with_hvdc and with_hvdc.splitlines()[-2].rstrip().endswith("2")
        caplog.clear()
        without = self._lines(caplog, None)
        assert "HVDC" not in without