"""operating_point_state.py

One operating-point state for the whole iterative RAO: the ORIGINAL network (frozen) and the
CURRENT one (taps, target_p, N-0 and N-X load flows, sensitivities). Every iteration builds at
the current point, applies the solution, runs a load flow and only then checks convergence, so
all baselines move together. Taps are the applied integer positions:
final = original + sum of the applied deltas.
"""

from __future__ import annotations

import copy
import dataclasses
from dataclasses import dataclass, field
from typing import Optional

from data_model import PST


@dataclass
class OperatingPointState:
    # ---- ORIGINAL network (frozen when the state is created; never written again)
    original_tap_by_pst: dict[str, int]
    original_target_p_by_gu: dict[str, float]
    original_lf_n0: dict[str, dict[int, float]]
    original_lf_nx: Optional[dict[str, dict[str, dict[int, float]]]]

    # ---- CURRENT operating point (written only by the loop, after a converged load flow)
    current_tap_by_pst: dict[str, int]
    current_target_p_by_gu: dict[str, float]
    current_lf_n0: dict[str, dict[int, float]]
    current_lf_nx: Optional[dict[str, dict[str, dict[int, float]]]]
    sensitivity_pst_n0: dict
    sensitivity_rd_n0: dict
    sensitivity_pst_nx: dict
    sensitivity_rd_nx: dict
    # {bid_mrid: signed MW applied so far}; UP bids positive, DOWN bids negative.
    cumulative_signed_volume_mw: dict[str, float] = field(default_factory=dict)
    # one record per MILP solve, in order (results_iteration_history.csv)
    solve_history: list[dict] = field(default_factory=list)
    # True while the sensitivities do not belong to the current operating point
    sensitivities_stale: bool = False
    # Cumulative applied solution after every applied iteration; index 0 = the
    # original network, index k = after the k-th applied solve (cyclic-repetition exit).
    solution_snapshots: list[dict] = field(default_factory=list)
    # Linearised effect (A) of the curative actions of the last applied solve on each
    # (branch, contingency); the post-curative current of the previous state (criterion 4).
    last_curative_effect_ampere: dict = field(default_factory=dict)
    # Per cumulative solution (same index as solution_snapshots; 0 = original network): its AC
    # load flows, curative effect, cost, model, PST rows and cumulative bid volumes (cycle exit).
    member_records: list[dict] = field(default_factory=list)
    # Sensitivity guard: {id: reason} of the contingencies (N-X) and branches (N-0) whose
    # current sensitivities failed; *_ever keeps every failure of the run.
    invalid_sensitivity_nx: dict = field(default_factory=dict)
    invalid_sensitivity_n0: dict = field(default_factory=dict)
    invalid_sensitivity_nx_ever: dict = field(default_factory=dict)
    # True when the completeness (outer) loop ended at max_completeness_iterations without converging
    completeness_limit_reached: bool = False
    # Reuse of the last valid sensitivities: the stores, the source of each set used by the
    # current solve, and the error that stopped the loop.
    last_valid_sensitivity_nx: dict = field(default_factory=dict)       # {co: {"pst": {...}, "rd": {...}}}
    last_valid_sensitivity_n0_pst: dict = field(default_factory=dict)   # {branch: {(branch, pst): value}}
    last_valid_sensitivity_n0_rd: dict = field(default_factory=dict)
    sensitivity_source_nx: dict = field(default_factory=dict)           # {co: "fresh" | "stale_reused"}
    sensitivity_source_nx_ever: dict = field(default_factory=dict)      # "stale_reused" if it ever was
    stale_reused_n0: dict = field(default_factory=dict)                 # {branch: "stale_reused"}
    sensitivity_failure: Optional[str] = None
    # HVDC RAs (docs/hvdc_ra_specs.md H8): sensitivities of the monitored branches to the EI units, in the
    # shape of the RD ones; {} without hvdc. The last-valid stores hold them under the key "hvdc" (N-X, in
    # last_valid_sensitivity_nx) and in last_valid_sensitivity_n0_hvdc (N-0). hvdc_zero_units_nx:
    # {contingency: [EI]} whose sensitivities are exactly zero there (their group is unavailable in it).
    sensitivity_hvdc_n0: dict = field(default_factory=dict)
    sensitivity_hvdc_nx: dict = field(default_factory=dict)
    last_valid_sensitivity_n0_hvdc: dict = field(default_factory=dict)
    hvdc_zero_units_nx: dict = field(default_factory=dict)
    # the HVDC result of the latest N-X sensitivity refresh (written by the refresh hook of run_pipeline,
    # read by the loop): fresh sets and zero units, None / {} before the first refresh
    fresh_sensitivity_hvdc_nx: Optional[dict] = None
    fresh_hvdc_zero_units_nx: dict = field(default_factory=dict)

    # ------------------------------------------------------------------ creation
    @classmethod
    def at_original_network(
        cls,
        pst_list: list[PST],
        generator_data: dict[str, dict],
        lf_n0: dict,
        lf_nx: Optional[dict],
        sensitivity_pst_n0: dict,
        sensitivity_rd_n0: dict,
        sensitivity_pst_nx: Optional[dict] = None,
        sensitivity_rd_nx: Optional[dict] = None,
        network_target_p: Optional[dict[str, float]] = None,
        monitored_branches_n0: Optional[set] = None,
        sensitivity_hvdc_n0: Optional[dict] = None,
        sensitivity_hvdc_nx: Optional[dict] = None,
    ) -> "OperatingPointState":
        """State for a network nothing has been applied to yet. PST taps come from
        pst.r0 (the original tap), generator target_p from generator_data (or, if
        given, from the network itself)."""
        taps = {str(p.mrid): int(p.r0) for p in pst_list}
        target_p = {
            str(gu): float(
                (network_target_p or {}).get(gu, data.get("target_p", data.get("initial_p", 0.0)))
            )
            for gu, data in generator_data.items()
        }
        def _by_branch(values):
            grouped: dict = {branch: {} for branch in (monitored_branches_n0 or ())}
            for key, value in values.items():
                grouped.setdefault(key[0], {})[key] = value
            return grouped

        # the initial sets passed the guard (a failure there stops the run before this point): they
        # are the first "last valid" ones
        last_valid_nx = {
            co: {
                "pst": dict((sensitivity_pst_nx or {}).get(co, {})),
                "rd": dict((sensitivity_rd_nx or {}).get(co, {})),
            }
            for co in set(sensitivity_pst_nx or {}) | set(sensitivity_rd_nx or {}) | set(sensitivity_hvdc_nx or {})
        }
        if sensitivity_hvdc_nx is not None:
            for co, stored in last_valid_nx.items():
                stored["hvdc"] = dict(sensitivity_hvdc_nx.get(co, {}))
        return cls(
            last_valid_sensitivity_nx=last_valid_nx,
            last_valid_sensitivity_n0_pst=_by_branch(sensitivity_pst_n0),
            last_valid_sensitivity_n0_rd=_by_branch(sensitivity_rd_n0),
            original_tap_by_pst=dict(taps),
            original_target_p_by_gu=dict(target_p),
            original_lf_n0=copy.deepcopy(lf_n0),
            original_lf_nx=copy.deepcopy(lf_nx) if lf_nx is not None else None,
            current_tap_by_pst=dict(taps),
            current_target_p_by_gu=dict(target_p),
            current_lf_n0=lf_n0,
            current_lf_nx=lf_nx,
            sensitivity_pst_n0=sensitivity_pst_n0,
            sensitivity_rd_n0=sensitivity_rd_n0,
            sensitivity_pst_nx=sensitivity_pst_nx or {},
            sensitivity_rd_nx=sensitivity_rd_nx or {},
            sensitivity_hvdc_n0=sensitivity_hvdc_n0 or {},
            sensitivity_hvdc_nx=sensitivity_hvdc_nx or {},
            last_valid_sensitivity_n0_hvdc=_by_branch(sensitivity_hvdc_n0 or {}) if sensitivity_hvdc_n0 is not None else {},
        )

    # ------------------------------------------------------------------ views for a MILP build
    def psts_at_current_taps(self, pst_list: list[PST]) -> list[PST]:
        """Copies of the PST objects with r0 = current tap. The caller's objects are
        never mutated, so r0 of the originals stays the original tap."""
        return [
            dataclasses.replace(p, r0=int(self.current_tap_by_pst.get(str(p.mrid), p.r0)))
            for p in pst_list
        ]

    def generator_data_at_current(self, generator_data: dict[str, dict]) -> dict[str, dict]:
        return {
            gu: {**data, "target_p": self.current_target_p_by_gu.get(gu, data.get("target_p", 0.0))}
            for gu, data in generator_data.items()
        }

    # ------------------------------------------------------------------ updates
    def record_applied_solution(
        self,
        applied_tap_by_pst: dict[str, int],
        refreshed_target_p_by_gu: dict[str, float],
        signed_bid_volume_delta_mw: dict[str, float],
        lf_n0_after: dict,
    ) -> None:
        """The loop calls this ONLY after the load flow of the applied solution
        converged."""
        self.current_tap_by_pst.update({str(k): int(v) for k, v in applied_tap_by_pst.items()})
        self.current_target_p_by_gu.update({str(k): float(v) for k, v in refreshed_target_p_by_gu.items()})
        for bid_mrid, delta in signed_bid_volume_delta_mw.items():
            self.cumulative_signed_volume_mw[bid_mrid] = (
                self.cumulative_signed_volume_mw.get(bid_mrid, 0.0) + float(delta)
            )
        self.current_lf_n0 = lf_n0_after
        self.sensitivities_stale = True
        if not self.solution_snapshots:
            self.solution_snapshots.append(self._original_snapshot())
            self.member_records.append({
                "model": None, "pst_results": None, "lf_n0": self.original_lf_n0, "lf_nx": self.original_lf_nx,
                "curative_effect": {}, "cost": 0.0, "cumulative_signed_volume_mw": {},
            })
        self.solution_snapshots.append(self._current_snapshot())
        self.member_records.append({
            "model": None, "pst_results": None, "lf_n0": lf_n0_after, "lf_nx": None,
            "curative_effect": {}, "cost": 0.0,
            "cumulative_signed_volume_mw": dict(self.cumulative_signed_volume_mw),
        })

    def annotate_latest_member(self, **fields) -> None:
        """Fills in what only becomes known after the solution was recorded (model, PST rows,
        N-X load flow, curative effect, cumulative cost) on the newest cumulative solution."""
        self.member_records[-1].update(fields)

    def rewind_to_member(self, index: int, lf_n0: dict, lf_nx: Optional[dict]) -> None:
        """Makes cumulative solution `index` the current operating point again (cyclic-repetition
        exit): taps, target_p, bid volumes, load flows and curative effect are those of that
        solution; later solutions are forgotten; the sensitivities no longer match."""
        snapshot, record = self.solution_snapshots[index], self.member_records[index]
        self.current_tap_by_pst.update({str(k): int(v) for k, v in snapshot["tap"].items()})
        self.current_target_p_by_gu.update({
            gu: self.original_target_p_by_gu[gu] + float(net) for gu, net in snapshot["net_rd_mw"].items()
        })
        self.cumulative_signed_volume_mw = dict(record["cumulative_signed_volume_mw"])
        self.current_lf_n0 = lf_n0
        self.current_lf_nx = lf_nx
        self.last_curative_effect_ampere = dict(record["curative_effect"])
        self.sensitivities_stale = True
        del self.solution_snapshots[index + 1:]
        del self.member_records[index + 1:]

    def _original_snapshot(self) -> dict:
        return {"tap": dict(self.original_tap_by_pst), "net_rd_mw": {gu: 0.0 for gu in self.original_target_p_by_gu}}

    def _current_snapshot(self) -> dict:
        """The cumulative solution: tap per PST and net redispatch per generating unit
        (MW, current target_p minus original target_p)."""
        return {
            "tap": dict(self.current_tap_by_pst),
            "net_rd_mw": {
                gu: self.current_target_p_by_gu.get(gu, original) - original
                for gu, original in self.original_target_p_by_gu.items()
            },
        }

    # ------------------------------------------------------------------ reporting
    def cumulative_tap_change(self, pst_mrid: str) -> int:
        return int(self.current_tap_by_pst[pst_mrid]) - int(self.original_tap_by_pst[pst_mrid])


def find_cyclic_repetition(snapshots: list[dict], threshold: float) -> Optional[tuple[int, float]]:
    """Cyclic repetition: compare the newest cumulative solution with every earlier one
    except the previous iteration (snapshot j = after j applied solves, 0 = original network).
    Distance = max absolute difference over PST taps and net RD MW per unit (missing = 0).
    Returns (j, distance) of the closest earlier solution below `threshold`, or None
    (needs at least three snapshots)."""
    if len(snapshots) < 3:
        return None
    newest = snapshots[-1]
    best: Optional[tuple[int, float]] = None
    for j, earlier in enumerate(snapshots[:-2]):
        distance = max(
            [abs(newest["tap"].get(k, 0) - earlier["tap"].get(k, 0)) for k in set(newest["tap"]) | set(earlier["tap"])]
            + [
                abs(newest["net_rd_mw"].get(k, 0.0) - earlier["net_rd_mw"].get(k, 0.0))
                for k in set(newest["net_rd_mw"]) | set(earlier["net_rd_mw"])
            ]
            + [0.0]
        )
        if distance < float(threshold) and (best is None or distance < best[1]):
            best = (j, float(distance))
    return best
