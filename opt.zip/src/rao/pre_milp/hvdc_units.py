"""hvdc_units.py — HVDC remedial actions without a network: the structural checks of the units
and their balanced groups (docs/hvdc_ra_specs.md H4, H12) and the operating limits of a unit from
its RangeConstraints (H3). Pure functions on the data_model dataclasses.
"""

from __future__ import annotations

import dataclasses
import logging
from pathlib import Path
from typing import Optional

from data_model import HvdcGroup, HvdcRange, HvdcUnit, RAKind

log = logging.getLogger(__name__)

# a technical limit with a magnitude at or above this (pypowsybl gives +-1.797e308 for an
# EquivalentInjection without minP/maxP) is "no limit"
UNBOUNDED_MW = 1e300


def validate_hvdc_structure(
    units: list[HvdcUnit], groups: list[HvdcGroup],
) -> tuple[list[HvdcUnit], list[HvdcGroup]]:
    """Checks the units and balanced groups of all TSOs together (H4.1, H4.5, H4.6, H12) and returns
    (usable units with group_mrid set, usable groups). Groups with the same mRID in several TSO
    files are merged. A balanced group without any HVDC unit is not an HVDC group: it is logged and
    skipped (the balanced kind may serve other remedial action types). Errors (ValueError naming the
    group or unit): an RA mRID parsed twice; an HVDC group with a remedial action that is not an HVDC
    unit; a unit in several HVDC groups (checked over all groups, before any group is dropped); a group
    that does not have exactly two units; a group mixing preventive and curative units or using one EI
    twice; two preventive units on one EI; an available unit without a group. A unit that is not
    available is dropped; a group with an unavailable unit is dropped with both units (the group is
    atomic, H4.4); both are logged."""
    by_mrid: dict[str, HvdcUnit] = {}
    for unit in units:
        if unit.mrid in by_mrid:
            raise ValueError(f"HVDC remedial action {unit.mrid} is defined twice ({by_mrid[unit.mrid].tso}, {unit.tso})")
        by_mrid[unit.mrid] = unit

    merged: dict[str, HvdcGroup] = {}
    for group in groups:
        if group.mrid in merged:
            merged[group.mrid] = dataclasses.replace(
                merged[group.mrid], ra_mrids=sorted(set(merged[group.mrid].ra_mrids) | set(group.ra_mrids)),
            )
        else:
            merged[group.mrid] = dataclasses.replace(group, ra_mrids=sorted(set(group.ra_mrids)))

    # the HVDC groups: a balanced group without any HVDC unit belongs to another RA type
    hvdc_groups: list[HvdcGroup] = []
    for group_mrid in sorted(merged):
        group = merged[group_mrid]
        if not any(ra in by_mrid for ra in group.ra_mrids):
            log.info(
                "balanced RA group %s (%s) has no HVDC unit (remedial actions %s) - not an HVDC group, skipped",
                group.mrid, group.name, group.ra_mrids,
            )
            continue
        foreign = [ra for ra in group.ra_mrids if ra not in by_mrid]
        if foreign:
            raise ValueError(
                f"balanced RA group {group.mrid} ({group.name}) contains remedial action(s) {foreign} that are not "
                f"HVDC units: a balanced group may only hold the two HVDC units of one link"
            )
        hvdc_groups.append(group)

    # one group per unit, over ALL HVDC groups (a group dropped below for an unavailable unit counts too)
    first_group_of_unit: dict[str, str] = {}
    for group in hvdc_groups:
        for ra in group.ra_mrids:
            if ra in first_group_of_unit:
                raise ValueError(f"HVDC unit {ra} is in two balanced groups ({first_group_of_unit[ra]}, {group.mrid})")
            first_group_of_unit[ra] = group.mrid

    dropped: set[str] = set()
    kept_groups: list[HvdcGroup] = []
    group_of_unit: dict[str, str] = {}
    for group in hvdc_groups:
        members = [by_mrid[ra] for ra in group.ra_mrids]
        if any(not unit.available for unit in members):
            dropped.update(unit.mrid for unit in members)
            log.info(
                "HVDC group %s: unit(s) %s not available - the group is atomic, both units are dropped",
                group.mrid, [u.mrid for u in members if not u.available],
            )
            continue
        if len(members) != 2:
            raise ValueError(
                f"balanced RA group {group.mrid} ({group.name}) has {len(members)} HVDC unit(s) {group.ra_mrids}; "
                f"exactly two are required"
            )
        if len({unit.kind for unit in members}) != 1:
            raise ValueError(
                f"balanced RA group {group.mrid} ({group.name}) mixes preventive and curative units {group.ra_mrids}"
            )
        if members[0].ei_mrid == members[1].ei_mrid:
            raise ValueError(
                f"balanced RA group {group.mrid} ({group.name}): both units use the same EquivalentInjection "
                f"{members[0].ei_mrid}"
            )
        for unit in members:
            group_of_unit[unit.mrid] = group.mrid
        kept_groups.append(group)

    # one preventive unit per EI: two would each carry their own range and balance on one set point
    preventive_by_ei: dict[str, list[str]] = {}
    for unit in units:
        if unit.mrid in group_of_unit and unit.kind == RAKind.PREVENTIVE:
            preventive_by_ei.setdefault(unit.ei_mrid, []).append(unit.mrid)
    for ei_mrid, unit_mrids in sorted(preventive_by_ei.items()):
        if len(unit_mrids) > 1:
            raise ValueError(
                f"EquivalentInjection {ei_mrid} is the unit of {len(unit_mrids)} preventive HVDC remedial actions "
                f"{sorted(unit_mrids)}: a set point has one preventive remedial action"
            )

    usable: list[HvdcUnit] = []
    for unit in units:
        if unit.mrid in group_of_unit:
            usable.append(dataclasses.replace(unit, group_mrid=group_of_unit[unit.mrid]))
        elif unit.mrid in dropped or not unit.available:
            log.info("HVDC unit %s (%s) dropped: not available (or its group is)", unit.mrid, unit.name)
        else:
            raise ValueError(
                f"HVDC unit {unit.mrid} ({unit.name}, EquivalentInjection {unit.ei_mrid}) is in no balanced RA group: "
                f"an HVDC unit needs its partner in a RemedialActionGroup with a balanced dependency"
            )
    return usable, kept_groups


def validate_units_not_in_rd_glsk(units: list[HvdcUnit], glsk: dict[str, dict[str, float]]) -> None:
    """H4.6: an EI that is also a generating unit of an RD GLSK is an error (ValueError naming the
    EI, the HVDC unit and the RD remedial action). glsk: {ra_mrid: {generating unit mRID: factor}}."""
    rd_ras_by_unit: dict[str, list[str]] = {}
    for ra_mrid, participation in glsk.items():
        for gu_mrid in participation:
            rd_ras_by_unit.setdefault(str(gu_mrid), []).append(str(ra_mrid))
    for unit in units:
        if unit.ei_mrid in rd_ras_by_unit:
            raise ValueError(
                f"EquivalentInjection {unit.ei_mrid} of HVDC unit {unit.mrid} is also a generating unit of the GLSK of "
                f"RD remedial action(s) {sorted(rd_ras_by_unit[unit.ei_mrid])}: one unit cannot be both"
            )


def _technical_limit(value: Optional[float]) -> Optional[float]:
    if value is None or value != value or abs(float(value)) >= UNBOUNDED_MW:
        return None
    return float(value)


def resolve_operating_limits(
    unit: HvdcUnit,
    p0: float,
    technical_min: Optional[float],
    technical_max: Optional[float],
    ranges: Optional[list[HvdcRange]] = None,
) -> tuple[float, float]:
    """(Pmin_op, Pmax_op) in MW, generation sign, of one unit (H3.2, H3.3).
    p0: the ORIGINAL set point of the CGM. technical_min / technical_max: the EI limits (None or
    a magnitude >= UNBOUNDED_MW = none; a warning is logged when both are missing). ranges: default
    unit.ranges.
    Per side the candidates are the technical limit and every range of that side; the most
    restrictive wins (the lowest maximum, the highest minimum):
      up       absolute v: max candidate v;           incremental v: max candidate p0 + v
      down     absolute v: min candidate v;           incremental v: min candidate p0 - v
      upAndDown absolute v: max |v| and min -|v|;     incremental v: max p0 + v and min p0 - v
    Incremental values are magnitudes (>= 0). Errors (ValueError naming the unit): no bound on a
    side (H3.3), a negative incremental value, or Pmin_op > Pmax_op.
    H3.4: a p0 outside the resolved range widens the range to include p0 (the unit may stay where the
    CGM puts it; without this the hard bounds would force a move, or make the model infeasible), with a
    warning naming the unit, its EI and the original and widened bounds."""
    ranges = unit.ranges if ranges is None else ranges
    tech_min, tech_max = _technical_limit(technical_min), _technical_limit(technical_max)
    if tech_min is None and tech_max is None:
        log.warning(
            "HVDC unit %s (EquivalentInjection %s) has no technical limits (minP/maxP) - the bounds come from the "
            "RangeConstraints only", unit.mrid, unit.ei_mrid,
        )
    maxima = [] if tech_max is None else [tech_max]
    minima = [] if tech_min is None else [tech_min]
    for rng in ranges:
        if rng.value_kind == "incremental":
            if rng.value < 0:
                raise ValueError(
                    f"HVDC unit {unit.mrid}: incremental range {rng.direction} has a negative value {rng.value}; "
                    f"incremental values are magnitudes"
                )
            high, low = p0 + rng.value, p0 - rng.value
        else:
            high, low = (abs(rng.value), -abs(rng.value)) if rng.direction == "upAndDown" else (rng.value, rng.value)
        if rng.direction in ("up", "upAndDown"):
            maxima.append(high)
        if rng.direction in ("down", "upAndDown"):
            minima.append(low)
    if not maxima or not minima:
        raise ValueError(
            f"HVDC unit {unit.mrid} ({unit.name}, EquivalentInjection {unit.ei_mrid}) has no "
            f"{'upper' if not maxima else 'lower'} bound (no technical limit and no RangeConstraint on that side): "
            f"the unit would be unlimited"
        )
    p_max, p_min = min(maxima), max(minima)
    if p_min > p_max:
        raise ValueError(f"HVDC unit {unit.mrid} ({unit.name}): lower limit {p_min} MW is above upper limit {p_max} MW")
    if not p_min <= p0 <= p_max:
        widened = (min(p_min, p0), max(p_max, p0))
        log.warning(
            "HVDC unit %s (EquivalentInjection %s): the CGM set point %.3f MW is outside its range [%.3f, %.3f] MW - "
            "the range is widened to [%.3f, %.3f] MW so that the unit may stay at its set point (H3.4)",
            unit.mrid, unit.ei_mrid, p0, p_min, p_max, widened[0], widened[1],
        )
        p_min, p_max = widened
    return p_min, p_max


# ---------------------------------------------------------------------------
# The units in the network (H2.2, H2.5, H4.3)
# ---------------------------------------------------------------------------

# the synchronous component the load flow solves (component_mode MAIN_SYNCHRONOUS): the largest one
MAIN_SYNCHRONOUS_COMPONENT = 0


def read_unit_network_data(network, units: list[HvdcUnit]) -> dict[str, dict]:
    """{EI mRID: {"name", "p0" (target_p, generation sign, MW), "min_p", "max_p" (the EI limits; +-1.8e308 when the
    CGM gives none), "connected", "in_solved_network", "original_class"}} of the generator behind every
    unit's EquivalentInjection (H2.5). ValueError naming the unit when its EI is not a generator of the
    network. Call after the initial load flow: in_solved_network is True when the unit is connected and its bus
    is in the main synchronous component (pypowsybl returns zero sensitivities for a unit outside it, H8.2)."""
    generators = network.get_generators(all_attributes=True)
    buses = network.get_buses(all_attributes=True)
    data: dict[str, dict] = {}
    missing = []
    for unit in units:
        if unit.ei_mrid in data:
            continue
        if unit.ei_mrid not in generators.index:
            missing.append(unit)
            continue
        row = generators.loc[unit.ei_mrid]
        original_class = str(row.get("CGMES.originalClass", ""))
        if original_class and original_class != "EquivalentInjection":
            log.warning(
                "HVDC unit %s: the network element %s is a %s, not an EquivalentInjection - used as the unit",
                unit.mrid, unit.ei_mrid, original_class,
            )
        bus_id = row.get("bus_id")
        connected = bool(row.get("connected", True)) and isinstance(bus_id, str) and bus_id in buses.index
        component = buses.loc[bus_id, "synchronous_component"] if connected else None
        data[unit.ei_mrid] = {
            "name": str(row.get("name", unit.ei_mrid)),
            "p0": float(row["target_p"]),
            "min_p": float(row["min_p"]),
            "max_p": float(row["max_p"]),
            "connected": connected,
            "in_solved_network": bool(connected and component == MAIN_SYNCHRONOUS_COMPONENT),
            "original_class": original_class,
        }
    if missing:
        raise ValueError(
            "HVDC unit(s) whose EquivalentInjection is not in the CGM: "
            + "; ".join(f"{u.mrid} -> {u.ei_mrid}" for u in missing)
        )
    return data


def check_units_in_solved_network(units: list[HvdcUnit], data: dict[str, dict]) -> None:
    """H4.3: both units of a group must be in the solved main network. ValueError naming every unit that is
    not (disconnected, islanded or in another synchronous area), with the other unit of its group."""
    by_group: dict[Optional[str], list[HvdcUnit]] = {}
    for unit in units:
        by_group.setdefault(unit.group_mrid, []).append(unit)
    problems = []
    for unit in units:
        info = data.get(unit.ei_mrid)
        if info is None or not info["in_solved_network"]:
            partners = [u.mrid for u in by_group.get(unit.group_mrid, []) if u.mrid != unit.mrid]
            reason = "not connected" if info is not None and not info["connected"] else "outside the solved main network"
            problems.append(
                f"{unit.mrid} (EquivalentInjection {unit.ei_mrid}, {reason}; group {unit.group_mrid}, partner {partners})"
            )
    if problems:
        raise ValueError(
            "HVDC unit(s) not in the solved main network - both units of a link must be in it: " + "; ".join(problems)
        )


def warn_ei_without_hvdc_description(units: list[HvdcUnit], eq_dir) -> list[str]:
    """H2.2: a warning (never an error) for every unit whose EquivalentInjection has no description starting
    with "HVDC" - on the EI itself, on one of its Terminals or on the ConnectivityNode of a Terminal. Reads
    the CGM EQ files of `eq_dir` (only those that contain the EI's mRID). Returns the EI mRIDs warned."""
    from pre_milp.ncp_parser import _eq_subjects_of_type, _eq_terms, _frag, _load_graph

    def description(graph, subject) -> str:
        for term in _eq_terms("IdentifiedObject.description"):
            value = graph.value(subject, term)
            if value is not None:
                return str(value)
        return ""

    wanted = {unit.ei_mrid: unit for unit in units}
    described: set[str] = set()
    found: set[str] = set()
    for path in sorted(Path(eq_dir).glob("*_EQ_*.xml")):
        contained = {ei for ei in wanted if ei not in found and ei.encode("utf-8") in path.read_bytes()}
        if not contained:
            continue
        graph = _load_graph(path)
        subjects = {_frag(str(s)): s for s in _eq_subjects_of_type(graph, "EquivalentInjection")}
        terminals_of: dict[object, list] = {}
        for term in _eq_terms("Terminal.ConductingEquipment"):
            for terminal, equipment in graph.subject_objects(term):
                terminals_of.setdefault(equipment, []).append(terminal)
        for ei in contained & set(subjects):
            found.add(ei)
            texts = [description(graph, subjects[ei])]
            for terminal in terminals_of.get(subjects[ei], []):
                texts.append(description(graph, terminal))
                for term in _eq_terms("Terminal.ConnectivityNode"):
                    node = graph.value(terminal, term)
                    if node is not None:
                        texts.append(description(graph, node))
            if any(text.strip().startswith("HVDC") for text in texts):
                described.add(ei)
    warned = []
    for ei in sorted(wanted):
        if ei not in described:
            warned.append(ei)
            log.warning(
                "HVDC unit %s: the description of EquivalentInjection %s (or its terminal / connectivity node) does "
                "not start with \"HVDC\"%s - used as an HVDC unit because the remedial action points to it",
                wanted[ei].mrid, ei, "" if ei in found else " (the EI was not found in the EQ files)",
            )
    return warned