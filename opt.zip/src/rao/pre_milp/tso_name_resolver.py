"""tso_name_resolver.py — TSO names from the CGM EQ files and the Organisation profile.

pypowsybl (cgm-with-subnetworks=false) leaves substation.regionName empty, so the TSO of a
substation is read from Substation -> SubGeographicalRegion -> IdentifiedObject.name.
"""

from __future__ import annotations

import logging
from pathlib import Path
from rdflib import Graph, Namespace, RDF

log = logging.getLogger(__name__)

# CIM namespaces
CIM = Namespace("https://cim.ucaiug.io/ns#")
CIM100 = Namespace("http://iec.ch/TC57/CIM100#")
NC  = Namespace("https://cim4.eu/ns/nc#")


def _cim_terms(local_name: str):
    return [CIM[local_name], CIM100[local_name]]


def _cim_value(g: Graph, subject, local_name: str):
    for term in _cim_terms(local_name):
        value = g.value(subject, term)
        if value is not None:
            return value
    return None


def _subjects_of_type(g: Graph, local_name: str):
    results = set()
    for term in _cim_terms(local_name):
        for subject in g.subjects(RDF.type, term):
            results.add(subject)
    return results


def _build_from_org_file(org_cd_path: Path) -> dict[str, str]:
    """Backward-compatible Org-NineRealms_CD.xml parser — returns TSO map.

    Keeps compatibility with tests that pass the Organisation profile.
    """
    if not org_cd_path.exists():
        raise FileNotFoundError(f"Organisation profile not found: {org_cd_path}")
    g = Graph()
    g.parse(str(org_cd_path), format="xml")

    tso_name: dict[str, str] = {}
    for tso_uri in g.subjects(RDF.type, NC.TransmissionSystemOperator):
        name_lit = g.value(tso_uri, CIM["IdentifiedObject.name"])
        mrid_lit = g.value(tso_uri, CIM["IdentifiedObject.mRID"])
        if name_lit is None:
            log.warning("TransmissionSystemOperator <%s> has no IdentifiedObject.name", tso_uri)
            continue
        key = str(mrid_lit) if mrid_lit is not None else _uri_fragment(str(tso_uri))
        tso_name[key] = str(name_lit)

    tso_name_map: dict[str, str] = {}
    for ca_uri in g.subjects(RDF.type, CIM.ControlArea):
        so_uri = g.value(ca_uri, NC["ControlArea.SystemOperator"])
        if so_uri is None:
            log.warning("ControlArea <%s> has no SystemOperator reference — skipped", ca_uri)
            continue
        so_fragment = _uri_fragment(str(so_uri))
        name = tso_name.get(so_fragment, "")
        if name == "":
            log.warning(
                "ControlArea <%s> SystemOperator <%s> not found in Organisation profile — TSO name set to empty string",
                ca_uri, so_uri,
            )
        tso_name_map[so_fragment] = name
    log.info("TSO_NAME_MAP built from Org file: %d entries (%d non-empty)", len(tso_name_map), sum(1 for v in tso_name_map.values() if v))
    return tso_name_map


def _uri_fragment(uri: str) -> str:
    """Return local fragment after # or last /, stripping leading underscore."""
    fragment = uri.split("#")[-1] if "#" in uri else uri.split("/")[-1]
    return fragment.lstrip("_")


def build_substation_mrid_to_tso(instance_root: Path) -> tuple[dict[str, str], dict[str, str]]:
    """Parse the EQ files under `instance_root`; returns (substation mRID -> TSO name,
    {TSO name: TSO name}). A substation without a SubGeographicalRegion name maps to ""."""
    if not instance_root.exists():
        raise FileNotFoundError(f"Instance root not found: {instance_root}")

    substation_mrid_to_tso: dict[str, str] = {}
    tso_names: dict[str, str] = {}

    # Find EQ files under each TSO folder and commonData
    eq_paths = list(instance_root.glob("**/*_EQ_*.xml")) + list(instance_root.glob("**/*_EQ*.xml"))
    if not eq_paths:
        log.warning("No EQ files found under %s", instance_root)

    for eq in sorted(eq_paths):
        g = Graph()
        try:
            g.parse(str(eq), format="xml")
        except Exception:
            log.debug("Skipping non-XML EQ file: %s", eq)
            continue

        # Map SubGeographicalRegion fragment -> IdentifiedObject.name
        region_name_by_frag: dict[str, str] = {}
        for region in _subjects_of_type(g, "SubGeographicalRegion"):
            name_lit = _cim_value(g, region, "IdentifiedObject.name")
            frag = _uri_fragment(str(region))
            region_name_by_frag[frag] = str(name_lit) if name_lit is not None else ""

        # For each Substation, find its Region reference and resolve to name
        for ss in _subjects_of_type(g, "Substation"):
            mrid_lit = _cim_value(g, ss, "IdentifiedObject.mRID")
            ss_mrid = str(mrid_lit) if mrid_lit is not None else _uri_fragment(str(ss))
            region_ref = (
                _cim_value(g, ss, "Substation.Region")
                or _cim_value(g, ss, "Substation.region")
            )
            if region_ref is None:
                # No region reference → unresolved
                substation_mrid_to_tso[ss_mrid] = ""
                continue
            frag = _uri_fragment(str(region_ref))
            tso_name = region_name_by_frag.get(frag, "")
            substation_mrid_to_tso[ss_mrid] = tso_name
            if tso_name:
                tso_names[tso_name] = tso_name

    log.info("Resolved %d substations to %d TSO names", len(substation_mrid_to_tso), len(tso_names))
    return substation_mrid_to_tso, tso_names


def build_tso_name_map(org_cd_or_instance: Path):
    """TSO mRID -> display name. Given the Organisation profile file, it is parsed directly;
    given the Instance root, commonData/NetworkCode/cimxml/Org-NineRealms_CD.xml is used,
    else the names are inferred from the top-level TSO folders."""
    if org_cd_or_instance.is_file() and org_cd_or_instance.name.endswith("Org-NineRealms_CD.xml"):
        return _build_from_org_file(org_cd_or_instance)

    if org_cd_or_instance.is_dir():
        org_cd_candidate = (
            org_cd_or_instance
            / "commonData"
            / "NetworkCode"
            / "cimxml"
            / "Org-NineRealms_CD.xml"
        )
        if org_cd_candidate.exists():
            return _build_from_org_file(org_cd_candidate)

    # Otherwise assume Instance root or a folder containing EQ files.
    sub2tso, tso_map = build_substation_mrid_to_tso(org_cd_or_instance)
    if tso_map:
        # key -> display name
        return {name: name for name in sorted(tso_map.keys())}

    inferred_tsos = sorted(
        d.name
        for d in org_cd_or_instance.iterdir()
        if d.is_dir() and d.name not in {"commonData", "boundaryData"}
    )
    result = {
        country: f"TSO-{country}" if not country.startswith("TSO-") else country
        for country in inferred_tsos
    }
    log.info(
        "Inferred TSO_NAME_MAP from Instance root: %d entries (%s)",
        len(result), ", ".join(sorted(result.values())),
    )
    return result


if __name__ == "__main__":
    import argparse, sys
    logging.basicConfig(level=logging.INFO, format="%(levelname)s %(message)s")
    parser = argparse.ArgumentParser(description="TSO resolution from EQ files")
    parser.add_argument("instance_root", type=Path, help="Path to Instance/ directory")
    args = parser.parse_args()
    sub2tso, tso_map = build_substation_mrid_to_tso(args.instance_root)
    print("TSO names:")
    for n in sorted(tso_map.keys()):
        print(f"  {n}")
    print(f"\nSubstations resolved: {len(sub2tso)}")
    sys.exit(0)