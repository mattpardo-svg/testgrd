"""ct_results_export.py — the result files of the countertrade RAs (docs/countertrade_ra_specs.md C11).

Files, written only with countertrade in ra_types (every row has the TSO of the RA or zone):
- results_countertrade.csv: one row per preventive CT bid (volume against the original network, price cost,
  penalty cost, activation cost);
- results_curative_countertrade.csv: one row per (curative CT bid, contingency); the penalty and reservation
  cost of a bid (on its maximum volume over the contingencies) are repeated on its rows;
- countertrade_glsk_resolved.csv: the weights of every RA and direction;
- ct_cra_availability.csv: per curative CT RA and branch, the reaction-time rule with its reason;
- results_net_positions.csv: per bidding zone the change of net injection from RD and from CT;
- results_zone_exchange.csv: per zone pair the change of the tie-line flow between the original state and the
  state after the applied results (the two halves of a tie are paired by their element name and opposite flow).
"""

from __future__ import annotations

import csv
import logging
from pathlib import Path
from typing import Optional

from data_model import AcVerificationStatus, BidDirection, CtRa, PowerBid
from milp.milp_builder import _participation_of_bid, curative_rd_reservation_price_eur_mw
from post_milp.n0_results_export import _cumulative_signed_rd_volume_mw
from pre_milp.cra_preprocessing import branch_tatl_duration_seconds, rd_cra_is_available
from pre_milp.ct_units import CtZone
from pre_milp.ct_weights import CtWeights
from text_encoding import TEXT_ENCODING

log = logging.getLogger(__name__)

# a volume below this (MW) is reported as 0 (no "-0.0" and no solver noise in the files)
_ZERO_MW = 1e-9
# the two halves of a tie are paired when their boundary flows are opposite within max(this, 2 % of the larger)
EXCHANGE_PAIRING_TOLERANCE_MW = 1.0
EXCHANGE_PAIRING_TOLERANCE_FRACTION = 0.02
UNASSIGNED_ZONE_NAME = "(no bidding zone)"


def _clean(value: float) -> float:
    return 0.0 if abs(value) < _ZERO_MW else float(value)


def _write(path: Path, header: list[str], rows: list[list], what: str) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    with open(path, "w", newline="", encoding=TEXT_ENCODING) as f:
        writer = csv.writer(f)
        writer.writerow(header)
        writer.writerows(rows)
    log.info("Written %s CSV: %s (%d rows)", what, path, len(rows))


def _status_columns(status: AcVerificationStatus, reason: str) -> list:
    return [status.value, reason]


# ---------------------------------------------------------------------------
# preventive and curative bids
# ---------------------------------------------------------------------------

def extract_ct_results(model, ct_ras: list[CtRa], ct_bids: list[PowerBid], penalty_reference_pra: float) -> list[dict]:
    """One row per preventive CT bid of the solved model (model.ct_bid_ids ∩ model.bid_ids), in the order of
    the bid mRIDs: volume_mw (against the ORIGINAL network, a magnitude: each bid has one direction),
    price_cost_eur = price x volume, penalty_cost_eur = penalty factor x PRA reference x volume,
    activation_cost_eur = the activation cost when the bid is used. [] without CT bids."""
    ct_bid_ids = getattr(model, "ct_bid_ids", frozenset())
    if not ct_bid_ids or not hasattr(model, "bid_ids"):
        return []
    import pyomo.environ as pyo

    ra_by_mrid = {ra.mrid: ra for ra in ct_ras}
    bid_by_mrid = {str(bid.mrid): bid for bid in ct_bids}
    activation_ids = set(getattr(model, "rd_activation_bid_ids", []))
    rows = []
    for bid_mrid in sorted(str(b) for b in model.bid_ids if str(b) in ct_bid_ids):
        bid = bid_by_mrid.get(bid_mrid)
        ra = ra_by_mrid.get(str(bid.ra_mrid)) if bid is not None else None
        if bid is None or ra is None:
            log.warning("MILP model references countertrade bid %s not found in the countertrade RAs — skipped", bid_mrid)
            continue
        volume = _clean(abs(_cumulative_signed_rd_volume_mw(model, bid_mrid)))
        activation = 0.0
        if bid_mrid in activation_ids and float(pyo.value(model.rd_bid_activated[bid_mrid])) > 0.5:
            activation = float(bid.activation_cost_eur or 0.0)
        rows.append({
            "ra_mrid": ra.mrid, "bid_mrid": bid_mrid, "tso": ra.tso, "zone_mrid": ra.zone_mrid, "zone_name": ra.zone_name,
            "direction": bid.direction.value, "volume_mw": volume, "price_eur_mw": float(bid.price_eur_mw),
            "price_cost_eur": float(bid.price_eur_mw) * volume, "penalty_factor": float(ra.penalty_factor),
            "penalty_cost_eur": float(ra.penalty_factor) * float(penalty_reference_pra) * volume,
            "activation_cost_eur": activation,
        })
    return rows


CT_RESULT_COLUMNS = [
    "ra_mrid", "bid_mrid", "tso", "zone_mrid", "zone_name", "direction", "volume_mw", "price_eur_mw", "price_cost_eur",
    "penalty_factor", "penalty_cost_eur", "activation_cost_eur",
]


def write_ct_results_csv(
    rows: list[dict], output_path: Path, timestamp: str, status: AcVerificationStatus, reason: str,
) -> None:
    """results_countertrade.csv; header-only without CT bids."""
    _write(
        output_path, CT_RESULT_COLUMNS + ["timestamp", "ac_verification_status", "ac_verification_termination_reason"],
        [[row[c] for c in CT_RESULT_COLUMNS] + [timestamp] + _status_columns(status, reason) for row in rows],
        "countertrade results",
    )


def extract_curative_ct_results(
    model, ct_ras: list[CtRa], ct_bids: list[PowerBid], penalty_reference_cra: float,
) -> list[dict]:
    """One row per (curative CT bid, contingency) pair of the solved model. curative_volume_mw: the variable of
    the bid's own direction; max_curative_volume_mw: its maximum over the contingencies. penalty_cost_eur
    (penalty factor x CRA reference x the maximum) and reservation_cost_eur (reservation price x the maximum;
    reservePrice, else the energy price) are per bid and repeated on its rows; the cost terms of the objective
    are these once per bid. [] without curative CT bids."""
    ct_curative = getattr(model, "ct_curative_bid_ids", frozenset())
    if not ct_curative or not hasattr(model, "curative_bid_contingency_pairs"):
        return []
    import pyomo.environ as pyo

    ra_by_mrid = {ra.mrid: ra for ra in ct_ras}
    bid_by_mrid = {str(bid.mrid): bid for bid in ct_bids}
    rows = []
    for bid_mrid, co_mrid in sorted(model.curative_bid_contingency_pairs):
        if str(bid_mrid) not in ct_curative:
            continue
        bid = bid_by_mrid.get(str(bid_mrid))
        ra = ra_by_mrid.get(str(bid.ra_mrid)) if bid is not None else None
        if bid is None or ra is None:
            log.warning("MILP model references curative countertrade bid %s not found — skipped", bid_mrid)
            continue
        is_up = bid.direction == BidDirection.UP
        volume_var = model.curative_rd_volume_upward if is_up else model.curative_rd_volume_downward
        max_total = float(pyo.value(model.max_curative_rd_volume_upward[bid_mrid])) + float(
            pyo.value(model.max_curative_rd_volume_downward[bid_mrid])
        )
        reservation_price = curative_rd_reservation_price_eur_mw(bid)
        rows.append({
            "ra_mrid": ra.mrid, "bid_mrid": str(bid_mrid), "tso": ra.tso, "zone_mrid": ra.zone_mrid, "zone_name": ra.zone_name,
            "contingency_mrid": str(co_mrid), "direction": bid.direction.value,
            "curative_volume_mw": _clean(float(pyo.value(volume_var[bid_mrid, co_mrid]))),
            "max_curative_volume_mw": _clean(max_total), "price_eur_mw": float(bid.price_eur_mw),
            "reservation_price_eur_mw": reservation_price, "penalty_factor": float(ra.penalty_factor),
            "penalty_cost_eur": float(ra.penalty_factor) * float(penalty_reference_cra) * max_total,
            "reservation_cost_eur": reservation_price * max_total,
        })
    return rows


CT_CURATIVE_COLUMNS = [
    "ra_mrid", "bid_mrid", "tso", "zone_mrid", "zone_name", "contingency_mrid", "direction", "curative_volume_mw",
    "max_curative_volume_mw", "price_eur_mw", "reservation_price_eur_mw", "penalty_factor", "penalty_cost_eur",
    "reservation_cost_eur",
]


def write_curative_ct_results_csv(
    rows: list[dict], output_path: Path, timestamp: str, status: AcVerificationStatus, reason: str,
) -> None:
    """results_curative_countertrade.csv; header-only without curative CT bids."""
    _write(
        output_path, CT_CURATIVE_COLUMNS + ["timestamp", "ac_verification_status", "ac_verification_termination_reason"],
        [[row[c] for c in CT_CURATIVE_COLUMNS] + [timestamp] + _status_columns(status, reason) for row in rows],
        "curative countertrade results",
    )


# ---------------------------------------------------------------------------
# weights and availability
# ---------------------------------------------------------------------------

def write_ct_glsk_csv(
    weights: dict[tuple[str, BidDirection], CtWeights], ct_ras: list[CtRa], output_path: Path, timestamp: str,
) -> None:
    """countertrade_glsk_resolved.csv: one row per (RA, direction, unit) with the participation factor; a
    direction without a unit gets one row with unit and factor blank, so every direction is listed. The weights
    are the same in every iteration and mode, so there is no iteration column."""
    rows = []
    for ra in sorted(ct_ras, key=lambda r: r.mrid):
        for direction in (BidDirection.UP, BidDirection.DOWN):
            participation = weights[(ra.mrid, direction)].pf if (ra.mrid, direction) in weights else {}
            if not participation:
                rows.append([ra.mrid, direction.value, "", ra.strategy, "", ra.tso, ra.zone_mrid, ra.zone_name, timestamp])
                continue
            for gu_mrid, factor in sorted(participation.items()):
                rows.append([ra.mrid, direction.value, gu_mrid, ra.strategy, factor, ra.tso, ra.zone_mrid, ra.zone_name, timestamp])
    _write(
        output_path,
        ["ra_mrid", "direction", "gu_mrid", "strategy", "participation_factor", "tso", "zone_mrid", "zone_name", "timestamp"],
        rows, "countertrade GLSK",
    )


REASON_REACTION_TIME = "reaction time above the TATL duration of the branch"


def compute_ct_cra_availability(
    ct_ras: list[CtRa], tatl_data: dict, branch_mrids: list[str], fallback_duration_seconds: float,
) -> list[dict]:
    """One row per available curative CT RA and branch: the reaction time against the TATL duration of the branch
    (the rule and the duration of the RD availability file, R9) and, when the RA cannot act there, the reason."""
    rows = []
    for ra in sorted(ct_ras, key=lambda r: r.mrid):
        if not (ra.available and ra.kind.value == "curative"):
            continue
        for branch_mrid in sorted(set(branch_mrids)):
            duration = branch_tatl_duration_seconds(branch_mrid, tatl_data, fallback_duration_seconds)
            available = rd_cra_is_available(ra.reaction_time_minutes, duration)
            rows.append({
                "ra_mrid": ra.mrid, "tso": ra.tso, "zone_mrid": ra.zone_mrid, "zone_name": ra.zone_name,
                "branch_mrid": branch_mrid,
                "reaction_time_minutes": "" if ra.reaction_time_minutes is None else ra.reaction_time_minutes,
                "tatl_duration_seconds": duration, "available": available, "reason": "" if available else REASON_REACTION_TIME,
            })
    return rows


def write_ct_cra_availability_csv(rows: list[dict], output_path: Path) -> None:
    columns = [
        "ra_mrid", "tso", "zone_mrid", "zone_name", "branch_mrid", "reaction_time_minutes", "tatl_duration_seconds",
        "available", "reason",
    ]
    _write(output_path, columns, [[row[c] for c in columns] for row in rows], "countertrade CRA availability")


# ---------------------------------------------------------------------------
# net positions
# ---------------------------------------------------------------------------

def extract_net_positions(
    model, rd_inputs, zone_of_unit: dict[str, str], zones: dict[str, CtZone], tso_of_zone: dict[str, str],
) -> list[dict]:
    """Per bidding zone the change of net injection (MW, against the ORIGINAL network, generation sign) of the
    units of the zone: rd_change_mw from the RD bids, ct_change_mw from the CT bids, total_change_mw their
    sum. Units outside every zone are one extra row (UNASSIGNED_ZONE_NAME). Every zone of a CT RA is listed;
    the sum of total_change_mw over the rows is 0 (the balance)."""
    ct_bid_ids = getattr(model, "ct_bid_ids", frozenset())
    rd_change: dict[str, float] = {}
    ct_change: dict[str, float] = {}
    model_bid_ids = {str(b) for b in getattr(model, "bid_ids", [])}
    for bid in rd_inputs.bid_list:
        bid_mrid = str(bid.mrid)
        if bid_mrid not in model_bid_ids:
            continue
        signed = _cumulative_signed_rd_volume_mw(model, bid_mrid)
        target = ct_change if bid_mrid in ct_bid_ids else rd_change
        for gu_mrid, factor in _participation_of_bid(rd_inputs, bid).items():
            zone = zone_of_unit.get(gu_mrid, "")
            target[zone] = target.get(zone, 0.0) + float(factor) * signed
    zones_of_ct_ras = {zone_of_unit[rd.gu_mrid] for rd in rd_inputs.rd_list if rd.countertrade and rd.gu_mrid in zone_of_unit}
    rows = []
    for zone_mrid in sorted(set(rd_change) | set(ct_change) | zones_of_ct_ras, key=lambda z: (z == "", zones[z].name if z in zones else z)):
        rd, ct = _clean(rd_change.get(zone_mrid, 0.0)), _clean(ct_change.get(zone_mrid, 0.0))
        rows.append({
            "zone_mrid": zone_mrid, "zone_name": zones[zone_mrid].name if zone_mrid in zones else UNASSIGNED_ZONE_NAME,
            "tso": tso_of_zone.get(zone_mrid, ""), "rd_change_mw": rd, "ct_change_mw": ct, "total_change_mw": _clean(rd + ct),
        })
    return rows


def write_net_positions_csv(rows: list[dict], output_path: Path, timestamp: str) -> None:
    columns = ["zone_mrid", "zone_name", "tso", "rd_change_mw", "ct_change_mw", "total_change_mw"]
    _write(output_path, columns + ["timestamp"], [[row[c] for c in columns] + [timestamp] for row in rows], "net positions")


# ---------------------------------------------------------------------------
# zone exchange
# ---------------------------------------------------------------------------

def read_area_boundaries(network) -> list[dict]:
    """The boundary elements of the control areas of the loaded network with their active power from the last
    load flow: [{"area", "element", "name", "p"}]. The p of a boundary is the flow entering the area through the
    element. [] (logged) when the network has no areas or pypowsybl has no boundary table."""
    try:
        boundaries = network.get_areas_boundaries()
    except Exception as exc:    # an older pypowsybl, or a network without areas
        log.warning("countertrade zone exchange: no area boundaries readable (%s)", exc)
        return []
    names = network.get_lines()["name"]
    rows = []
    for area_mrid, row in boundaries.iterrows():
        element = str(row["element"])
        p = float(row["p"])
        if p != p:      # NaN: the element is not in the solved network
            continue
        rows.append({"area": str(area_mrid), "element": element, "name": str(names.get(element, "")), "p": p})
    return rows


def _pair_ties(boundaries: list[dict], area_zone: dict[str, str]) -> tuple[dict, list[str]]:
    """({(tie name, zone a, zone b): (p entering a, p entering b)} for the ties whose two halves are in two zones
    and have opposite flows, [names of the ties that could not be paired])."""
    by_name: dict[str, list[dict]] = {}
    skipped: list[str] = []
    for row in boundaries:
        if row["area"] not in area_zone:
            continue
        if not row["name"]:
            skipped.append(row["element"])
            continue
        by_name.setdefault(row["name"], []).append(row)
    ties: dict = {}
    for name, rows in sorted(by_name.items()):
        if len(rows) != 2 or area_zone[rows[0]["area"]] == area_zone[rows[1]["area"]]:
            skipped.append(name)
            continue
        first, second = sorted(rows, key=lambda r: area_zone[r["area"]])
        tolerance = max(EXCHANGE_PAIRING_TOLERANCE_MW, EXCHANGE_PAIRING_TOLERANCE_FRACTION * max(abs(first["p"]), abs(second["p"])))
        if abs(first["p"] + second["p"]) > tolerance:
            skipped.append(name)
            continue
        ties[(name, area_zone[first["area"]], area_zone[second["area"]])] = (first["p"], second["p"])
    return ties, skipped


def compute_zone_exchange(
    before: list[dict], after: list[dict], zones: dict[str, CtZone], tso_of_zone: dict[str, str],
) -> list[dict]:
    """Per zone pair (ordered by zone mRID) the exchange a -> b, MW, summed over the ties paired in BOTH states:
    exchange_before_mw (original state), exchange_after_mw (state after the applied results), change_mw. The flow
    a -> b of one tie is the mean of the boundary flow entering b and the negative of the one entering a. A
    tie without a partner (halves of different names, flows that are not opposite, an area outside every
    zone) is skipped with one log line."""
    area_zone = {area: zone.mrid for zone in zones.values() for area in zone.control_area_mrids}
    ties_before, skipped_before = _pair_ties(before, area_zone)
    ties_after, skipped_after = _pair_ties(after, area_zone)
    common = sorted(set(ties_before) & set(ties_after))
    skipped = sorted(set(skipped_before) | set(skipped_after) | {key[0] for key in set(ties_before) ^ set(ties_after)})
    log.info(
        "countertrade zone exchange: %d tie(s) paired, %d skipped (no partner half, flows not opposite or an area "
        "outside every zone)%s", len(common), len(skipped), f": {skipped}" if skipped else "",
    )
    pairs: dict[tuple[str, str], dict] = {}
    for key in common:
        name, zone_a, zone_b = key
        entry = pairs.setdefault((zone_a, zone_b), {"before": 0.0, "after": 0.0, "ties": 0})
        for state, ties in (("before", ties_before), ("after", ties_after)):
            p_a, p_b = ties[key]
            entry[state] += (p_b - p_a) / 2.0
        entry["ties"] += 1
    rows = []
    for (zone_a, zone_b), entry in sorted(pairs.items()):
        rows.append({
            "zone_a_mrid": zone_a, "zone_a_name": next((z.name for z in zones.values() if z.mrid == zone_a), zone_a),
            "zone_b_mrid": zone_b, "zone_b_name": next((z.name for z in zones.values() if z.mrid == zone_b), zone_b),
            "tso_a": tso_of_zone.get(zone_a, ""), "tso_b": tso_of_zone.get(zone_b, ""), "tie_count": entry["ties"],
            "exchange_before_mw": entry["before"], "exchange_after_mw": entry["after"],
            "change_mw": _clean(entry["after"] - entry["before"]),
        })
    return rows


def write_zone_exchange_csv(rows: list[dict], output_path: Path, timestamp: str, calculation: str) -> None:
    """results_zone_exchange.csv; calculation names the load flow of both states (AC or DC)."""
    columns = [
        "zone_a_mrid", "zone_a_name", "zone_b_mrid", "zone_b_name", "tso_a", "tso_b", "tie_count",
        "exchange_before_mw", "exchange_after_mw", "change_mw",
    ]
    _write(
        output_path, columns + ["load_flow", "timestamp"],
        [[row[c] for c in columns] + [calculation, timestamp] for row in rows], "zone exchange",
    )


# ---------------------------------------------------------------------------
# units at their limits
# ---------------------------------------------------------------------------

LIMIT_TOLERANCE_MW = 1e-6


def log_units_at_limits(model) -> list[tuple[str, str]]:
    """C5.2: one log line for every unit that takes part in a countertrade bid and whose combined dispatch (RD + CT,
    the last solution) reaches Pmax or Pmin. Returns [(unit, "Pmax" | "Pmin")]."""
    ct_bid_ids = getattr(model, "ct_bid_ids", frozenset())
    if not ct_bid_ids or not hasattr(model, "rd_net_injection_g") or not hasattr(model, "rd_unit_status"):
        return []
    import pyomo.environ as pyo

    hits = []
    for gu_mrid in sorted(str(g) for g in model.gu_ids):
        status = model.rd_unit_status.get(gu_mrid)
        if status is None:
            continue
        total = float(model.rd_baseline_target_p_mw[gu_mrid]) + float(pyo.value(model.rd_net_injection_g[gu_mrid]))
        moved = abs(float(pyo.value(model.rd_net_injection_g[gu_mrid]))) > LIMIT_TOLERANCE_MW
        if moved and total >= status.pmax_mw - LIMIT_TOLERANCE_MW:
            hits.append((gu_mrid, "Pmax"))
            log.info("generating unit %s reaches Pmax %.3f MW (dispatch %.3f MW, redispatch and countertrade together)",
                     gu_mrid, status.pmax_mw, total)
        elif moved and total <= status.pmin_mw + LIMIT_TOLERANCE_MW:
            hits.append((gu_mrid, "Pmin"))
            log.info("generating unit %s reaches Pmin %.3f MW (dispatch %.3f MW, redispatch and countertrade together)",
                     gu_mrid, status.pmin_mw, total)
    return hits
